import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/core/demo_state.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/core/network_resilience.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';

Future<Map<String, dynamic>> guardedAiTransport(
  SessionScope scope,
  AiTransport transport,
  String key,
  Map<String, dynamic> body,
) async {
  if (demoBlocksAi) {
    throw const AiFailure('체험 모드에서는 외부 AI 요청을 보내지 않아요.');
  }
  await scope.verify();
  final response = transport == geminiTransport
      ? await geminiTransport(key, body, scope: scope)
      : await transport(key, body);
  await scope.verify();
  return response;
}

Future<Map<String, dynamic>> geminiTransport(
  String key,
  Map<String, dynamic> body, {
  SessionScope? scope,
}) async {
  if (demoBlocksAi) {
    throw const AiFailure('체험 모드에서는 외부 AI 요청을 보내지 않아요.');
  }
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 20);
  ActiveRequests.add(client);
  final watch = scope?.watch(() => client.close(force: true));
  final deadline = Timer(
    const Duration(seconds: 90),
    () => client.close(force: true),
  );
  try {
    await scope?.verify();
    final request = await client
        .postUrl(
          Uri.parse(
            'https://generativelanguage.googleapis.com/v1beta/models/$aiModel:generateContent',
          ),
        )
        .timeout(const Duration(seconds: 20));
    request.followRedirects = false;
    request.headers.set('x-goog-api-key', key);
    request.headers.contentType = ContentType.json;
    request.write(jsonEncode(body));
    final response = await request.close().timeout(const Duration(seconds: 60));
    final bytes = <int>[];
    await for (final chunk in response.timeout(const Duration(seconds: 30))) {
      bytes.addAll(chunk);
      if (bytes.length > 1000000) throw const AiFailure('AI 응답이 너무 커요.');
    }
    if (response.statusCode == 429) {
      throw const AiFailure(
        'Gemini 사용량 한도에 도달했어요. 잠시 후 또는 일일 한도 초기화 후 다시 시도해 주세요.',
        code: 'quota',
        detail: 'Google의 요청 빈도 또는 일일 사용량 한도에 도달했어요.',
      );
    }
    if (response.statusCode == 400) {
      throw const AiFailure(
        'Gemini가 요청을 거절했어요.',
        code: 'request',
        detail:
            '키가 올바른지, 이 모델을 쓸 수 있는지 AI 설정에서 확인해 주세요.',
      );
    }
    if (response.statusCode == 401 || response.statusCode == 403) {
      throw AiFailure(
        'API 키·프로젝트 권한 또는 요청 지원 여부를 확인해 주세요.',
        code: 'credentials',
        detail: 'HTTP ${response.statusCode} · API 키 또는 프로젝트 접근 권한을 확인해 주세요.',
      );
    }
    if (response.statusCode != 200) {
      throw AiFailure(
        'Gemini 서버가 정상 응답하지 않았어요.',
        code: 'network',
        detail: 'HTTP ${response.statusCode} · 잠시 후 다시 시도해 주세요.',
      );
    }
    return jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
  } on AiFailure {
    rethrow;
  } on FormatException {
    throw const AiFailure(
      'AI 서버 응답 형식을 읽지 못했어요.',
      code: 'response',
      detail: '완전한 응답인지 확인하지 못해 저장하지 않았어요. 기존 일정은 유지해요. 다시 시도할 수 있어요.',
    );
  } on HandshakeException catch (e) {
    throw AiFailure(
      'AI 서버와 보안 연결에 실패했어요.',
      code: 'network',
      detail: networkFailureMessage(e),
    );
  } catch (_) {
    throw const AiFailure(
      'AI 분석 통신을 완료하지 못했어요. 연결을 확인해 주세요.',
      code: 'network',
      detail: '응답이 늦거나 연결이 끊겼어요. 잠시 후 다시 시도해 주세요.',
    );
  } finally {
    deadline.cancel();
    watch?.cancel();
    ActiveRequests.remove(client);
    client.close(force: true);
  }
}

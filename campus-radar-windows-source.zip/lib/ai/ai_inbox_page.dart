import 'package:campus_radar/core/demo_state.dart';
import 'package:campus_radar/core/developer_mode.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/ai/audience_review_groups.dart';
import 'package:campus_radar/ai/ai_review_presentation.dart';
import 'package:campus_radar/schedule/timetable_cancellations_page.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';
import 'package:campus_radar/ai/ai_cancellation_notification.dart';
import 'package:campus_radar/core/transient_message.dart';
import 'package:campus_radar/ai/ai_inbox_repository.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/ai/ai_chat_page.dart';
import 'package:campus_radar/schedule/calendar_draft_page.dart';
import 'package:campus_radar/ai/ai_state_repository.dart';
import 'package:campus_radar/ai/ai_state_models.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/ai/ai_recovery.dart';
import 'package:campus_radar/ai/ai_recovery_page.dart';
import 'package:campus_radar/ai/ai_confirm.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/core/radar_card.dart';
import 'package:campus_radar/core/ui_refresh.dart';
import 'dart:io';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/ai/ai_automation.dart';

class AiInboxPage extends StatefulWidget {
  final bool embedded, home, records, inline, compactReview;
  final String? noticeId, candidateId;
  final String initialFilter;
  final bool showTools;
  final Widget? header;
  const AiInboxPage({
    super.key,
    this.embedded = false,
    this.inline = false,
    this.compactReview = false,
    this.home = false,
    this.records = false,
    this.noticeId,
    this.candidateId,
    this.initialFilter = 'review',
    this.showTools = true,
    this.header,
  });
  @override
  State<AiInboxPage> createState() => _AiInboxState();
}

Future<void> revertAutoApprovedCandidate(
  Store store,
  Map<String, dynamic> row, {
  SessionMark? mark,
}) async {
  final key = row['key'] as String;
  final c = row['candidate'] as ScheduleCandidate;
  final n = row['notice'] as CampusNotice;
  try {
    await mark?.verify(store);
  } on SessionChanged {
    return;
  }
  final repo = AiStateRepository(store);
  if (c.action == 'add') {
    await repo.saveSchedule(
      key,
      ConfirmedSchedule.fromJson({
        'status': 'review',
        'approvalMode': 'reverted',
        'revertedAt': DateTime.now().toUtc().toIso8601String(),
      }),
    );
    await store.db.delete('meta', where: 'id=?', whereArgs: [MetaKey.aiApproval(key)]);
    await store.log('ai', 'AI 일정 자동 반영 취소', n.title);
  } else if (c.action == 'cancel' && c.category == 'class') {
    final cancellations = await readClassCancellations(store);
    final allSlots = decodeSlots(await store.meta(MetaKey.timetableEntries));
    final planned = matchCandidateCancellations(allSlots, n, c);
    final plannedIds = planned.map((x) => x.id).toSet();
    final startDate = c.date;
    final endDate = c.endDate.isNotEmpty ? c.endDate : c.date;
    final removed = cancellations.where((x) {
      if (plannedIds.contains(x.id)) return true;
      final matchNotice =
          x.noticeId == n.id || (x.source == n.title && x.course == n.course);
      if (!matchNotice) return false;
      if (startDate.isNotEmpty) {
        return x.date.compareTo(startDate) >= 0 &&
            x.date.compareTo(endDate) <= 0;
      }
      return false;
    }).toList();
    if (removed.isNotEmpty) {
      final removedIds = removed.map((x) => x.id).toSet();
      await CancellationRepository(store).change(
        (rows) => rows..removeWhere((x) => removedIds.contains(x.id)),
      );
      try {
        await bridge.invokeNative(NativeMethod.refreshWidget);
      } catch (_) {}
      cancellationRefresh.value++;
    }
    await repo.saveSchedule(
      key,
      ConfirmedSchedule.fromJson({
        'status': 'review',
        'approvalMode': 'reverted',
        'revertedAt': DateTime.now().toUtc().toIso8601String(),
      }),
    );
    await store.db.delete('meta', where: 'id=?', whereArgs: [MetaKey.aiApproval(key)]);
    await store.log('ai', 'AI 휴강 자동 반영 취소', n.title);
  }
}

class _AiInboxState extends State<AiInboxPage> with WidgetsBindingObserver {
  Timer? timer;
  bool loading = true, auto = false;
  // Empty-state guidance: without a key nothing will ever arrive here.
  bool hasKey = true;
  String filter = 'review', error = '', recentQuestion = '';
  String? blockedCode;
  AiReviewKind? reviewFilter;
  List<String> damagedRecords = [];
  List<Map<String, dynamic>> candidates = [], jobs = [];

  @override
  void initState() {
    super.initState();
    filter = widget.initialFilter;
    WidgetsBinding.instance.addObserver(this);
    cancellationRefresh.addListener(load);
    load();
    timer = Timer.periodic(const Duration(seconds: 3), (_) {
      if (WidgetsBinding.instance.lifecycleState == AppLifecycleState.resumed) {
        load();
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    cancellationRefresh.removeListener(load);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  bool reading = false;
  Future<void> load() async {
    if (reading || !mounted) return;
    reading = true;
    // Never hold the list on this optional check (secure storage can be
    // slow or absent); the empty-state text updates when it answers.
    if (demoBlocksAi) {
      if (mounted && !hasKey) setState(() => hasKey = true);
    } else {
      unawaited(
        credentials
            .read(key: 'geminiApiKey')
            .then((key) {
              if (mounted && hasKey != (key != null)) {
                setState(() => hasKey = key != null);
              }
            })
            .catchError((_) {}),
      );
    }
    Store? s;
    try {
      s = await Store.open();
      if (!mounted) return;
      mark = await SessionMark.capture(s);
      final snapshot = await AiInboxRepository(s).read();
      if (mounted) {
        setState(() {
          candidates = snapshot.candidates;
          jobs = widget.noticeId == null
              ? snapshot.jobs
              : snapshot.jobs.where((j) => j['id'] == widget.noticeId).toList();
          recentQuestion = snapshot.recentQuestion;
          blockedCode = snapshot.blockedCode;
          damagedRecords = snapshot.damagedRecords;
          auto = snapshot.enabled;
          loading = false;
          error = '';
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          error = '검토함을 읽지 못했어요. 다시 확인해 주세요.';
          loading = false;
        });
      }
    } finally {
      await s?.db.close();
      reading = false;
    }
  }

  SessionMark? mark;
  Future<void> state(String key, ScheduleDecision value) async {
    final s = await Store.open();
    try {
      try {
        await mark?.verify(s);
      } on SessionChanged {
        return;
      }
      final old = await AiStateRepository(s).schedule(key);
      await AiStateRepository(s).saveSchedule(key, old.withDecision(value));
    } finally {
      await s.db.close();
    }
    await load();
  }

  final saving = <String>{};
  Future<void> quickConfirm(
    Map<String, dynamic> row, {
    bool calendar = false,
  }) async {
    final key = row['key'] as String;
    // Claim the row before any await so a double tap cannot confirm twice.
    if (!saving.add(key)) return;
    if (mounted) setState(() {});
    try {
      await _quickConfirm(row, key, calendar: calendar);
    } finally {
      if (mounted) {
        setState(() => saving.remove(key));
      } else {
        saving.remove(key);
      }
    }
  }

  Future<void> _quickConfirm(
    Map<String, dynamic> row,
    String key, {
    bool calendar = false,
  }) async {
    if (!calendar && (row['state'] as Map)['status'] != 'confirmed') {
      final store = await Store.open();
      String? choice;
      try {
        choice = await store.meta(MetaKey.aiCalendarDefault);
      } finally {
        await store.db.close();
      }
      if (choice == null && mounted) {
        final selected = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('일정을 어디에 추가할까요?'),
            content: const Text('다음부터 이 선택을 기본으로 사용해요. AI 설정에서 변경할 수 있어요.'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('앱 일정'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('캘린더에도 추가'),
              ),
            ],
          ),
        );
        if (selected == null) return;
        choice = selected ? 'yes' : 'no';
        final saved = await Store.open();
        try {
          await saved.setMeta(MetaKey.aiCalendarDefault, choice);
        } finally {
          await saved.db.close();
        }
      }
      if (!mounted) return;
      calendar = choice == 'yes';
    }
    final c = row['candidate'] as ScheduleCandidate;
    final n = row['notice'] as CampusNotice;
    if (c.date.isEmpty && (row['state'] as Map)['start'] == null) {
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => CalendarDraftPage(
            courseName: n.course,
            itemKey: key,
            title: '[${courseLabel(n.course)}] ${c.title}',
            description: '공지: ${n.title}\n${c.description}',
            allDay: true,
            closeAfterSave: true,
            saveToCalendar: calendar,
          ),
        ),
      );
      await load();
      return;
    }
    Store? store;
    try {
      store = await Store.open();
      final old = await confirmAiCandidate(
        store,
        key,
        n,
        c,
        calendar: calendar,
      );
      await load();
      if (mounted) {
        showTransientMessage(
          context,
          SnackBar(
            content: Text(
              calendar
                  ? (Platform.isWindows ? '일정 파일을 저장했어요.' : '캘린더에 저장했어요.')
                  : '일정에 추가했어요.',
            ),
            action: calendar
                ? null
                : SnackBarAction(
                    label: '실행 취소',
                    onPressed: () async {
                      final s = await Store.open();
                      try {
                        await mark?.verify(s);
                        // Only undo if nothing was decided since the confirm.
                        final now = await AiStateRepository(s).schedule(key);
                        if (now.toJson()['status'] == 'confirmed') {
                          await AiStateRepository(
                            s,
                          ).saveSchedule(key, ConfirmedSchedule.fromJson(old));
                        }
                      } on SessionChanged {
                        // Logged out or switched account: nothing to undo.
                      } finally {
                        await s.db.close();
                      }
                      await load();
                    },
                  ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        showTransientMessage(
          context,
          SnackBar(
            content: Text(e is AiFailure ? e.message : '일정을 저장하지 못했어요.'),
          ),
        );
      }
    } finally {
      await store?.db.close();
    }
  }

  Future<void> revertAutoApproved(Map<String, dynamic> row) async {
    final s = await Store.open();
    try {
      await revertAutoApprovedCandidate(s, row, mark: mark);
    } finally {
      await s.db.close();
    }
    await load();
    if (mounted) {
      showTransientMessage(context, const SnackBar(content: Text('자동 반영을 취소했어요.')));
    }
  }

  Future<void> pause() async {
    if (demoBlocksAi) {
      if (mounted) {
        showTransientMessage(
          context,
          const SnackBar(content: Text('체험 모드에서는 AI 자동 분석을 실행하지 않아요.')),
        );
      }
      return;
    }
    final s = await Store.open();
    try {
      if (!auto &&
          (await credentials.read(key: 'geminiApiKey') == null ||
              await s.meta(MetaKey.aiConsent) != aiConsentVersion)) {
        if (mounted) {
          showTransientMessage(
            context,
            const SnackBar(content: Text('AI 설정에서 키와 전송 동의를 먼저 저장하세요.')),
          );
        }
        return;
      }
      await s.setAiSetting(AiSetting.aiAuto, auto ? 'no' : 'yes');
      await s.log(
        'ai',
        auto ? 'AI 대기열 일시 중지' : 'AI 대기열 재개',
        '진행 중 요청은 완료 후 중지돼요.',
      );
    } finally {
      await s.db.close();
    }
    if (!auto) {
      await scheduleAiWork();
      unawaited(processAiWork());
    }
    await load();
  }

  Future<void> openRecovery(Map<String, dynamic> job) async {
    final store = await Store.open();
    CampusNotice? notice;
    try {
      notice = (await store.notices())
          .where((n) => n.id == job['id'])
          .firstOrNull;
    } finally {
      await store.db.close();
    }
    if (!mounted) return;
    if (notice == null) {
      showTransientMessage(
        context,
        const SnackBar(content: Text('원문 공지가 현재 수집 목록에 없어요. 공지를 다시 수집해 주세요.')),
      );
      return;
    }
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AiRecoveryPage(notice: notice!, job: job),
      ),
    );
    await load();
  }

  Future<void> retry(String id) async {
    if (!auto) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('대기열을 재개한 뒤 재시도해 주세요.')));
      return;
    }
    final s = await Store.open();
    try {
      final q = jsonDecode(await s.meta(MetaKey.aiQueue(id)) ?? '{}') as Map;
      await s.setMeta(MetaKey.aiCooldown, '0');
      await AiStateRepository(s).saveJob(
        id,
        AiJob.fromJson(q).withStatus(
          AiJobStatus.pending,
          fields: {'attempts': 0, 'retryAt': ''},
        ),
      );
    } finally {
      await s.db.close();
    }
    await scheduleAiWork();
    unawaited(processAiWork());
    await load();
  }

  @override
  Widget build(BuildContext context) {
    final processedCount = candidates.where((r) {
      if (widget.noticeId != null &&
          (r['notice'] as CampusNotice).id != widget.noticeId) {
        return false;
      }
      if (widget.candidateId != null && r['key'] != widget.candidateId) {
        return false;
      }
      return !isPendingReviewCandidate(r);
    }).length;
    final list = candidates.where((r) {
      if (widget.records) return false;
      if (widget.noticeId != null &&
          (r['notice'] as CampusNotice).id != widget.noticeId) {
        return false;
      }
      if (widget.candidateId != null && r['key'] != widget.candidateId) {
        return false;
      }
      final status = (r['state'] as Map)['status'] ?? 'review';
      final matchesFilter = filter == 'all'
          ? true
          : filter == 'review'
          ? isPendingReviewCandidate(r)
          : status == filter;
      return matchesFilter &&
          (filter != 'review' ||
              reviewFilter == null ||
              reviewKind(
                    r['candidate'] as ScheduleCandidate,
                    state: r['state'] as Map,
                  ) ==
                  reviewFilter);
    }).toList();
    if (widget.compactReview) {
      final today = DateTime.now()
          .toUtc()
          .add(const Duration(hours: 9))
          .toIso8601String()
          .substring(0, 10);
      list.sort((a, b) {
        final first = (a['candidate'] as ScheduleCandidate).date;
        final second = (b['candidate'] as ScheduleCandidate).date;
        final firstPast = first.isNotEmpty && first.compareTo(today) < 0;
        final secondPast = second.isNotEmpty && second.compareTo(today) < 0;
        if (firstPast != secondPast) return firstPast ? 1 : -1;
        return first.compareTo(second);
      });
    }
    final content = ListView(
      shrinkWrap: widget.inline,
      primary: widget.inline ? false : null,
      physics: widget.inline
          ? const NeverScrollableScrollPhysics()
          : const AlwaysScrollableScrollPhysics(),
      padding: EdgeInsets.all(widget.inline ? 0 : 20),
      children: [
        if (widget.header != null) widget.header!,
        if (widget.home && widget.showTools) ...[
          Text('무엇을 도와드릴까요?', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          const Text('수집한 공지에서 일정을 찾고, 과제에 대한 질문을 도와드려요.'),
          const SizedBox(height: 16),
          Text(
            '확인할 일정 ${pendingReviewCandidates(candidates).length}개',
            style: Theme.of(context).textTheme.titleLarge,
          ),
        ],
        if (auto &&
            jobs.any(
              (j) =>
                  ['pending', 'running'].contains(j['status']) &&
                  j['waitingForSource'] != true,
            ))
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text(
              '공지 ${jobs.where((j) => ['pending', 'running'].contains(j['status']) && j['waitingForSource'] != true).length}개를 확인하고 있어요 · 연결 오류는 자동 재시도해요',
            ),
          ),
        if (jobs.any((j) => j['waitingForSource'] == true))
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: Text(
              '학교 자동 연결이 꺼져 있어 새 원문 수집을 기다리고 있어요. 저장된 공지 분석은 계속할 수 있어요.',
            ),
          ),
        if (damagedRecords.isNotEmpty && isDeveloperMode)
          RadarExpansionCard(
            leading: const RadarIconBox(icon: Icons.info_outline),
            title: const Text('일부 저장 기록을 표시하지 못했어요'),
            subtitle: const Text('정상 일정은 계속 표시하며, 읽지 못한 원본도 보관해요.'),
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: SelectableText(
                  '진단용 기록 위치\n${damagedRecords.join('\n')}',
                ),
              ),
            ],
          ),
        if (!widget.records &&
            widget.noticeId == null &&
            jobs.any((j) => j['status'] == 'failed'))
          RadarCard(
            margin: const EdgeInsets.only(bottom: 10),
            padding: EdgeInsets.zero,
            child: ListTile(
              leading: RadarIconBox(
                icon: Icons.info_outline,
                iconColor: Theme.of(context).colorScheme.error,
                backgroundColor: Theme.of(
                  context,
                ).colorScheme.error.withValues(alpha: 0.12),
              ),
              title: Text(
                '분석 문제 ${jobs.where((j) => j['status'] == 'failed').length}개',
              ),
              subtitle: const Text('실패 원인 확인 · 원문 보기 · 직접 추가 · 자료 추가 재분석'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () =>
                  navigateTo(context, AiInboxDestination(records: true)),
            ),
          ),
        const SizedBox(height: 12),
        if (widget.compactReview)
          Row(
            children: [
              Expanded(
                child: Text(
                  '확인할 일정 ${list.length}개',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ),
              TextButton(
                onPressed: () => navigateTo(
                  context,
                  const AiInboxDestination(initialFilter: 'all'),
                ),
                child: Text('처리 기록 $processedCount'),
              ),
            ],
          ),
        if (!widget.compactReview &&
            !widget.records &&
            !widget.home &&
            widget.noticeId == null &&
            widget.candidateId == null)
          Wrap(
            spacing: 6,
            children: [
              for (final f in {
                'review': '확인 필요',
                'confirmed': '추가한 일정',
                'hold': '보류',
                'excluded': '제외',
                'all': '전체',
              }.entries)
                ChoiceChip(
                  label: Text(f.value),
                  selected: filter == f.key,
                  onSelected: (_) => setState(() => filter = f.key),
                ),
            ],
          ),
        if (filter == 'review' &&
            !widget.home &&
            !widget.records &&
            widget.candidateId == null)
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                Padding(
                  padding: const EdgeInsets.all(4),
                  child: ChoiceChip(
                    label: const Text('모든 항목'),
                    selected: reviewFilter == null,
                    onSelected: (_) => setState(() => reviewFilter = null),
                  ),
                ),
                for (final kind in AiReviewKind.values)
                  if (candidates.any(
                    (r) =>
                        ((r['state'] as Map)['status'] ?? 'review') ==
                            'review' &&
                        reviewKind(
                              r['candidate'] as ScheduleCandidate,
                              state: r['state'] as Map,
                            ) ==
                            kind,
                  ))
                    Padding(
                      padding: const EdgeInsets.all(4),
                      child: ChoiceChip(
                        label: Text(reviewLabel(kind)),
                        selected: reviewFilter == kind,
                        onSelected: (_) => setState(() => reviewFilter = kind),
                      ),
                    ),
              ],
            ),
          ),
        if (filter == 'review' && !widget.records && widget.candidateId == null)
          AudienceReviewGroups(
            rows: list,
            onChanged: () async {
              if (mounted) setState(() => reviewFilter = null);
              await load();
            },
          ),
        if (loading) const LinearProgressIndicator(),
        if (error.isNotEmpty) Text(error),
        if (!widget.records && !loading && list.isEmpty)
          hasKey
              ? RadarEmptyState(
                  icon: Icons.check_circle_outline,
                  message: '새로 확인할 일정이 없어요.',
                  action: processedCount > 0 && filter == 'review'
                      ? OutlinedButton(
                          onPressed: () {
                            if (widget.compactReview || widget.home) {
                              navigateTo(
                                context,
                                const AiInboxDestination(initialFilter: 'all'),
                              );
                            } else {
                              setState(() => filter = 'all');
                            }
                          },
                          child: const Text('지난 처리 기록 보기'),
                        )
                      : null,
                )
              : RadarCard(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      const RadarIconBox(
                        icon: Icons.auto_awesome_outlined,
                        size: 56,
                        iconSize: 28,
                        radius: 16,
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        '여기는 공지 속 시험·과제 마감·휴강을 AI가 찾아 모아 두는 곳이에요.',
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        '개인 Gemini 키(무료)를 연결하면 새 공지가 올 때마다 채워져요.',
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 14),
                      FilledButton.icon(
                        onPressed: () async {
                          await navigateTo(
                            context,
                            const AiSettingsDestination(),
                          );
                          await load();
                        },
                        icon: const Icon(Icons.key_outlined),
                        label: const Text('Gemini 키 연결하기'),
                      ),
                    ],
                  ),
                ),
        for (final row in widget.home ? list.take(3) : list)
          Builder(
            builder: (context) {
              final n = row['notice'] as CampusNotice,
                  c = row['candidate'] as ScheduleCandidate;
              final st = row['state'] as Map;
              return RadarCard(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      courseLabel(n.course),
                      style: Theme.of(context).textTheme.labelMedium?.copyWith(
                        color: Theme.of(context).colorScheme.primary,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      withoutCoursePrefix(
                        courseEventTitle(
                          st['title'] ?? c.title,
                          n.course,
                          oldLabel: st['courseLabel'] as String?,
                        ),
                        n.course,
                      ),
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${st['date'] ?? (c.date.isEmpty ? '날짜 확인 필요' : c.date)} ${st['start'] != null && st['allDay'] != true
                          ? DateTime.parse(st['start'])
                                .toUtc()
                                .add(const Duration(hours: 9))
                                .toIso8601String()
                                .substring(11, 16)
                          : st['allDay'] == true
                          ? '종일'
                          : c.time} · ${c.action == 'add'
                          ? '새 일정'
                          : c.action == 'change'
                          ? '변경 확인'
                          : '휴강·취소 확인'}',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                    if (row['approvalReview'] is Map &&
                        row['approvalReview']['approved'] == false) ...[
                      const SizedBox(height: 6),
                      Text('수동 검토: ${row['approvalReview']['reason']}'),
                    ],
                    if (st['approvalMode'] == 'automatic' ||
                        (st['status'] == 'confirmed' &&
                            st['calendarSent'] != true) ||
                        st['calendarSent'] == true ||
                        (st['status'] ?? 'review') == 'review' ||
                        (st['status'] == 'excluded' &&
                            st['resolution'] == 'classCancellationApplied') ||
                        st['resolution'] == 'notMyAudience') ...[
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: [
                          if (st['approvalMode'] == 'automatic')
                            const RadarStatusPill(label: '자동 반영됨'),
                          if (st['status'] == 'confirmed' &&
                              st['calendarSent'] != true)
                            const RadarStatusPill(label: '앱에 추가됨 · 캘린더 미전송'),
                          if (st['calendarSent'] == true)
                            RadarStatusPill(
                              label: Platform.isWindows
                                  ? '일정 파일 저장됨'
                                  : '캘린더 전송됨',
                            ),
                          if ((st['status'] ?? 'review') == 'review')
                            RadarStatusPill(
                              label: reviewLabel(reviewKind(c, state: st)),
                            ),
                          if (st['status'] == 'excluded' &&
                              st['resolution'] == 'classCancellationApplied')
                            const RadarStatusPill(label: '시간표에 휴강 반영됨'),
                          if (st['resolution'] == 'notMyAudience')
                            RadarStatusPill(
                              label: '본인 대상 아님',
                              backgroundColor: Theme.of(
                                context,
                              ).colorScheme.surfaceContainerHighest,
                              foregroundColor: Theme.of(
                                context,
                              ).colorScheme.onSurfaceVariant,
                            ),
                        ],
                      ),
                    ],
                    if (st['approvalReason'] is String) ...[
                      const SizedBox(height: 6),
                      Text(st['approvalReason'] as String),
                    ],
                    if ((st['status'] ?? 'review') == 'review') ...[
                      const SizedBox(height: 6),
                      Text(reviewInstruction(c, state: st)),
                    ],
                    if (c.periodLabel.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(c.periodLabel),
                    ],
                    const SizedBox(height: 10),
                    Material(
                      color: Theme.of(context).colorScheme.surfaceContainerLow,
                      borderRadius: BorderRadius.circular(12),
                      clipBehavior: Clip.antiAlias,
                      child: ExpansionTile(
                        title: const Text('근거·공지 원문'),
                        childrenPadding: const EdgeInsets.fromLTRB(
                          14,
                          0,
                          14,
                          10,
                        ),
                        children: [
                          Align(
                            alignment: Alignment.centerLeft,
                            child: SelectableText('${c.description}\n\n${n.body}'),
                          ),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: TextButton(
                              onPressed: () => navigateTo(
                                context,
                                NoticeDestination(notice: n),
                              ),
                              child: const Text('출처 공지 열기'),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                          if (c.action == 'add' && st['status'] != 'confirmed')
                            FilledButton(
                              onPressed: saving.contains(row['key'])
                                  ? null
                                  : () => quickConfirm(row),
                              child: Text(
                                c.date.isEmpty && st['start'] == null
                                    ? '날짜 확인·추가'
                                    : '일정에 추가',
                              ),
                            ),
                          if (c.action == 'add' && st['status'] == 'confirmed')
                            OutlinedButton(
                              onPressed: saving.contains(row['key'])
                                  ? null
                                  : () => quickConfirm(row, calendar: true),
                              child: Text(
                                st['calendarSent'] == true
                                    ? '캘린더 갱신'
                                    : (Platform.isWindows
                                          ? '일정 파일 저장'
                                          : '캘린더 저장'),
                              ),
                            ),
                          if (c.action == 'add')
                            TextButton(
                              onPressed: () async {
                                await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => CalendarDraftPage(
                                      courseName: n.course,
                                      itemKey: row['key'] as String,
                                      closeAfterSave: true,
                                      saveToCalendar:
                                          st['calendarSent'] == true,
                                      title: courseEventTitle(
                                        st['title'] ??
                                            '[${n.course}] ${c.title}',
                                        n.course,
                                        oldLabel: st['courseLabel'] as String?,
                                      ),
                                      description:
                                          '공지: ${n.title}\n${c.description}\nhttps://dcs-learning.cnu.ac.kr/home',
                                      start:
                                          DateTime.tryParse(
                                            st['start'] ?? '',
                                          ) ??
                                          (c.date.isEmpty
                                              ? null
                                              : c.time.isEmpty
                                              ? strictDate(c.date)
                                              : DateTime.parse(
                                                  '${c.date}T${c.time}:00+09:00',
                                                )),
                                      deadline:
                                          st['deadline'] as bool? ?? c.deadline,
                                      end: st.containsKey('end')
                                          ? DateTime.tryParse(st['end'] ?? '')
                                          : c.endInstant,
                                      allDay:
                                          st['allDay'] as bool? ??
                                          c.time.isEmpty,
                                    ),
                                  ),
                                );
                                await load();
                              },
                              child: const Text('수정'),
                            ),
                          if (c.action == 'cancel' &&
                              c.category == 'class' &&
                              !(st['status'] == 'excluded' &&
                                  st['resolution'] ==
                                      'classCancellationApplied'))
                            OutlinedButton.icon(
                              icon: const Icon(Icons.event_busy),
                              label: const Text('시간표에 휴강 반영'),
                              onPressed: () async {
                                CancellationReceipt? receipt;
                                final applied = await editCancellation(
                                  context,
                                  notice: n,
                                  candidate: c,
                                  onApplied: (value) => receipt = value,
                                );
                                if (applied && mounted) {
                                  await finishCandidateCancellation(
                                    this.context,
                                    candidateKey: row['key'] as String,
                                    receipt: receipt,
                                    mark: mark,
                                    onChanged: load,
                                  );
                                }
                              },
                            ),
                          if (c.action != 'add')
                            const Text('기존 캘린더 일정을 직접 확인해 변경·취소를 반영하세요.'),
                          if (st['approvalMode'] == 'automatic')
                            TextButton.icon(
                              icon: const Icon(Icons.undo),
                              label: const Text('반영 취소'),
                              onPressed: () => revertAutoApproved(row),
                            ),
                          PopupMenuButton<String>(
                            tooltip: '일정 더보기',
                            onSelected: (v) => state(
                              row['key'] as String,
                              ScheduleDecision.values.byName(v),
                            ),
                            itemBuilder: (_) => const [
                              PopupMenuItem(value: 'hold', child: Text('보류')),
                              PopupMenuItem(
                                value: 'excluded',
                                child: Text('제외'),
                              ),
                            ],
                          ),
                          if (filter != 'review')
                            TextButton(
                              onPressed: () => state(
                                row['key'] as String,
                                ScheduleDecision.review,
                              ),
                              child: const Text('다시 검토'),
                            ),
                        ],
                      ),
                  ],
                ),
              );
            },
          ),
        if (widget.home && widget.showTools) ...[
          TextButton(
            onPressed: () => navigateTo(context, AiInboxDestination()),
            child: const Text('검토함 전체 보기'),
          ),
          const SizedBox(height: 16),
          const Divider(),
          FilledButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AiChatPage()),
            ),
            icon: const Icon(Icons.chat_bubble_outline),
            label: const Text('공지나 과제에 대해 질문하기'),
          ),
          Wrap(
            spacing: 8,
            children: [
              for (final q in ['이번 주 해야 할 일', '최근 공지 요약', '놓치기 쉬운 일정'])
                ActionChip(
                  label: Text(q),
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AiChatPage(initialQuestion: q),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          RadarSettingTile(
            icon: Icons.history,
            title: '최근 대화',
            subtitle: recentQuestion.isEmpty ? '질문을 시작해 보세요' : recentQuestion,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AiChatPage()),
            ),
          ),
        ],
        const SizedBox(height: 16),
        if (widget.records)
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton(
              onPressed: pause,
              child: Text(auto ? '자동 분석 일시 중지' : '자동 분석 재개'),
            ),
          ),
        if (widget.records) ...[
          const SizedBox(height: 8),
          const SectionHeading('확인 필요한 항목'),
          const SizedBox(height: 8),
          if (!jobs.any((j) => j['status'] == 'failed'))
            const RadarEmptyState(
              icon: Icons.check_circle_outline,
              message: '해결할 분석 문제가 없어요.',
            ),
          for (final j in jobs.where((j) => j['status'] == 'failed'))
            RadarCard(
              margin: const EdgeInsets.only(bottom: 8),
              padding: EdgeInsets.zero,
              child: ListTile(
                leading: RadarIconBox(
                  icon: Icons.error_outline,
                  iconColor: Theme.of(context).colorScheme.error,
                  backgroundColor: Theme.of(
                    context,
                  ).colorScheme.error.withValues(alpha: 0.12),
                ),
                title: Text(j['title'] ?? '공지'),
                subtitle: Text(recoveryExplanation(recoveryCode(j))),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => openRecovery(j),
              ),
            ),
          for (final j in jobs.where(
            (j) => ['pending', 'running'].contains(j['status']),
          ))
            RadarCard(
              margin: const EdgeInsets.only(bottom: 8),
              padding: EdgeInsets.zero,
              child: ListTile(
                leading: const RadarIconBox(icon: Icons.sync),
                title: Text(j['title'] ?? '공지'),
                subtitle: Text(
                  j['status'] == 'running'
                      ? '분석 중'
                      : '자동 재시도 대기 · ${j['error'] ?? ''}',
                ),
                onTap: () => openRecovery(j),
              ),
            ),
          const SizedBox(height: 4),
          RadarExpansionCard(
            leading: const RadarIconBox(icon: Icons.history_outlined),
            title: const Text('완료·제외 기록'),
            children: [
              for (final j in jobs.where(
                (j) => !['failed', 'pending', 'running'].contains(j['status']),
              ))
                ListTile(
                  title: Text(j['title'] ?? '공지'),
                  subtitle: Text(
                    {
                          'done': '완료 · 발견한 일정은 검토함에서 확인',
                          'empty': '확인함, 없음',
                          'excluded': '사용자가 분석 제외',
                          'manual': '사용자가 직접 일정 추가',
                        }[j['status']] ??
                        '${j['status']}',
                  ),
                  onTap: () => openRecovery(j),
                ),
            ],
          ),
        ],
      ],
    );
    if (widget.inline) return content;
    return Scaffold(
      appBar: widget.embedded
          ? null
          : AppBar(
              title: Text(widget.records ? '분석 기록·문제 해결' : '검토함'),
              actions: [
                IconButton(
                  onPressed: () => navigateTo(context, AiSettingsDestination()),
                  icon: const Icon(Icons.tune),
                  tooltip: 'AI 설정',
                ),
                IconButton(
                  onPressed: load,
                  icon: const Icon(Icons.refresh),
                  tooltip: '새로고침',
                ),
              ],
            ),
      body: RefreshIndicator(onRefresh: load, child: content),
    );
  }
}

import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/demo_mode.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/core/adaptive_content.dart';
import 'package:campus_radar/ai/chat_threads.dart';
import 'package:campus_radar/settings/app_help_catalog.dart';
import 'package:campus_radar/settings/app_help_page.dart';
import 'package:campus_radar/home/feature_discovery.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/courses/course_catalog.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:flutter_markdown_plus/flutter_markdown_plus.dart';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:campus_radar/core/radar_card.dart';
import 'package:campus_radar/ai/chat.dart';

String _cleanChatLinkLabel(String s) => s
    .replaceAll(RegExp(r'[*`_\[\]"]'), '')
    .replaceAll(RegExp(r'\s+'), ' ')
    .trim();

bool _isHelpTopicLabel(String label, AppHelpTopic topic) {
  final clean = _cleanChatLinkLabel(label);
  if (clean.isEmpty) return false;
  for (final t in appHelpTopics) {
    if (clean == t.title || clean.contains(t.title)) return true;
  }
  return clean == topic.title ||
      clean.contains('기능 안내') ||
      clean.contains('설정');
}

CampusItem? matchChatTaskItem(
  String rawLabel,
  Iterable<CampusItem> items, {
  Map<String, dynamic>? course,
}) {
  final clean = _cleanChatLinkLabel(displayCourseText(rawLabel));
  if (clean.isEmpty) return null;
  for (final t in appHelpTopics) {
    if (clean == t.title) return null;
  }
  final scopedKey = course == null ? null : courseKey(course);
  final candidates = items.where(
    (i) =>
        !i.isMaterial &&
        (scopedKey == null || courseKey(i.context) == scopedKey),
  );
  for (final item in candidates) {
    final title = _cleanChatLinkLabel(displayCourseText(item.title));
    if (title.isNotEmpty && clean == title) return item;
  }
  for (final item in candidates) {
    final title = _cleanChatLinkLabel(displayCourseText(item.title));
    if (title.length >= 2 &&
        (clean.contains(title) || (clean.length >= 2 && title.contains(clean)))) {
      return item;
    }
  }
  return null;
}

class PreparedChatModelMessage {
  final String markdown;
  final List<AppHelpTopic> relatedHelp;
  const PreparedChatModelMessage(this.markdown, this.relatedHelp);
}

PreparedChatModelMessage prepareModelChatMessage(
  String rawText,
  Iterable<CampusItem> items, {
  Map<String, dynamic>? course,
}) {
  final related = <String, AppHelpTopic>{};
  final linkPattern = RegExp(r'(?<!\!)\[([^\]]+)\]\(([^)\s]+)\)');
  final transformed = displayCourseText(rawText).replaceAllMapped(
    linkPattern,
    (match) {
      final label = match.group(1) ?? '';
      final href = match.group(2) ?? '';
      final matchedTask = matchChatTaskItem(label, items, course: course);
      if (matchedTask != null) {
        return '[$label](campus-radar://task/${Uri.encodeComponent(matchedTask.key)})';
      }
      final help = appHelpLink(href);
      if (help != null) {
        related[help.id] = help;
        if (_isHelpTopicLabel(label, help)) {
          return '';
        }
        return label;
      }
      if (href.startsWith('campus-radar://')) {
        return label;
      }
      return match.group(0)!;
    },
  );
  final cleanedLines = <String>[];
  for (final line in transformed.split('\n')) {
    final trimmed = line
        .replaceAll(RegExp(r'^[\s\-*•·\d.)]+'), '')
        .trim();
    if (trimmed.isEmpty && line.trim().isNotEmpty) {
      continue;
    }
    cleanedLines.add(line);
  }
  final cleaned = cleanedLines
      .join('\n')
      .replaceAll(RegExp(r'\n{3,}'), '\n\n')
      .trim();
  return PreparedChatModelMessage(
    cleaned.isEmpty ? displayCourseText(rawText) : cleaned,
    related.values.toList(),
  );
}

class AiChatPage extends StatefulWidget {
  final Map<String, dynamic>? course;
  const AiChatPage({
    super.key,
    this.course,
    this.embedded = false,
    this.initialQuestion,
  });
  final String? initialQuestion;
  final bool embedded;
  @override
  State<AiChatPage> createState() => _AiChatPageState();
}

class _AiChatPageState extends State<AiChatPage> {
  final input = TextEditingController();
  final scroll = ScrollController();
  List<Map<String, String>> history = [];
  List<CampusItem> chatItems = [];
  Set<String> chatExcluded = {};
  bool loading = true,
      busy = false,
      share = false,
      consent = false,
      hasKey = false;
  String? error;
  bool waiting = false, cancelled = false;
  String? pendingQuestion;
  String threadId = DateTime.now().microsecondsSinceEpoch.toString();
  String get key =>
      'aiChat:${widget.course == null ? 'all' : courseKey(widget.course!)}';
  @override
  void initState() {
    super.initState();
    FeatureDiscovery.record(DiscoverFeature.chat);
    input.text = widget.initialQuestion ?? '';
    unawaited(load());
  }

  @override
  void dispose() {
    input.dispose();
    scroll.dispose();
    super.dispose();
  }

  Future<void> load() async {
    Store? s;
    try {
      s = await Store.open();
      // Previous conversations are available explicitly, not forced into a new visit,
      // except in demo mode where the pre-populated Q&A thread is shown right away.
      final threads = await loadChatThreads(s, key);
      final agreed = await s.meta(MetaKey.aiChatConsent) == '1';
      final savedShare = await s.meta(MetaKey.aiChatShare);
      final loadedItems = await s.items();
      final loadedExcluded = await s.excluded();
      if (!demoBlocksAi) {
        unawaited(
          credentials
              .read(key: 'geminiApiKey')
              .then((geminiKey) {
                if (mounted) {
                  setState(
                    () => hasKey =
                        geminiKey != null && geminiKey.trim().isNotEmpty,
                  );
                }
              })
              .catchError((_) {}),
        );
      }
      if (mounted) {
        setState(() {
          if (demoBlocksAi && threads.isNotEmpty) {
            threadId = threads.first.id;
            history = threads.first.messages;
          } else {
            history = [];
          }
          chatItems = loadedItems;
          chatExcluded = loadedExcluded;
          if (demoBlocksAi) hasKey = true;
          consent = agreed || demoBlocksAi;
          share = savedShare == 'yes';
        });
      }
    } catch (_) {
      if (mounted) setState(() => error = '저장된 대화를 읽지 못했어요.');
    } finally {
      await s?.db.close();
      if (mounted) setState(() => loading = false);
    }
  }

  bool preparing = false;
  Future<void> send() async {
    // Claim before the first await so a double tap cannot send twice.
    if (preparing) return;
    preparing = true;
    try {
      await _send();
    } finally {
      preparing = false;
    }
  }

  Future<void> _send() async {
    if (busy || input.text.trim().isEmpty) return;
    if (demoBlocksAi) {
      final question = input.text.trim();
      final next = [
        ...history,
        {'role': 'user', 'text': question},
        {'role': 'model', 'text': demoChatOfflineReply},
      ];
      final retained = next
          .skip(next.length > 40 ? next.length - 40 : 0)
          .toList();
      final demoStore = await Store.open();
      try {
        await saveChatThread(
          demoStore,
          key,
          ChatThread(
            threadId,
            retained.first['text']!
                .replaceAll('\n', ' ')
                .characters
                .take(48)
                .toString(),
            retained,
          ),
        );
      } finally {
        await demoStore.db.close();
      }
      if (mounted) {
        setState(() {
          history = retained;
          error = null;
          input.clear();
        });
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (scroll.hasClients) {
            scroll.animateTo(
              scroll.position.maxScrollExtent,
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOut,
            );
          }
        });
      }
      return;
    }
    // Without a key every answer fails; say so before the two consent dialogs.
    final geminiKey = await credentials.read(key: 'geminiApiKey');
    if (geminiKey == null || geminiKey.trim().isEmpty) {
      if (!mounted) return;
      final go = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Gemini 키가 필요해요'),
          content: const Text(
            'AI 채팅은 내 Google Gemini 키로 동작해요. AI 설정에서 무료 키를 저장하면 바로 질문할 수 있어요.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('닫기'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('AI 설정 열기'),
            ),
          ],
        ),
      );
      if (go == true && mounted) {
        navigateTo(context, const AiSettingsDestination());
      }
      return;
    }
    final preferenceStore = await Store.open();
    String? savedPreference;
    try {
      savedPreference = await preferenceStore.meta(MetaKey.aiChatShare);
    } finally {
      await preferenceStore.db.close();
    }
    if (savedPreference == null && mounted) {
      final choice = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('과제·공지·시간표를 답변에 활용할까요?'),
          content: const Text(
            '허용하면 수집한 과제·공지 일부와 저장된 시간표를 Gemini에 함께 보내요. 선택은 다음 대화에도 유지되며 참고 자료 메뉴에서 바꿀 수 있어요.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('대화만 보내기'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('참고하기'),
            ),
          ],
        ),
      );
      if (choice == null) return;
      final store = await Store.open();
      try {
        await store.setMeta(MetaKey.aiChatShare, choice ? 'yes' : 'no');
      } finally {
        await store.db.close();
      }
      if (!mounted) return;
      setState(() => share = choice);
    }
    final question = input.text.trim();
    if (busy || question.isEmpty) return;
    if (!mounted) return;
    if (!consent) {
      final accepted = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('AI 채팅 전송 동의'),
          content: const Text(
            '질문과 최근 대화가 개인 키를 통해 Google Gemini로 전송돼요. ‘수집 정보 공유’를 켜면 해당 범위의 과제·콘텐츠와 저장된 공지 본문 일부와 시간표도 함께 전송돼요. 무료 API의 데이터 처리 조건을 확인해 주세요. 로그인 비밀번호와 API 키는 대화 자료에 포함하지 않아요.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('취소'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('동의하고 질문'),
            ),
          ],
        ),
      );
      if (accepted != true) return;
      consent = true;
    }
    setState(() {
      busy = true;
      cancelled = false;
      waiting = true;
      pendingQuestion = question;
      error = null;
    });
    Store? s;
    try {
      s = await Store.open();
      await s.setAiSetting(AiSetting.aiChatConsent, '1');
      final answer = await askCampusAi(
        s,
        history,
        question,
        includeData: share,
        cancelled: () => !mounted || cancelled,
        onProgress: (value) {
          if (mounted) setState(() => waiting = value);
        },
        courseId: widget.course == null ? null : courseKey(widget.course!),
      );
      final next = [
        ...history,
        {'role': 'user', 'text': question},
        {'role': 'model', 'text': answer},
      ];
      final retained = next
          .skip(next.length > 40 ? next.length - 40 : 0)
          .toList();
      await saveChatThread(
        s,
        key,
        ChatThread(
          threadId,
          retained.first['text']!
              .replaceAll('\n', ' ')
              .characters
              .take(48)
              .toString(),
          retained,
        ),
      );
      final loadedItems = await s.items();
      final loadedExcluded = await s.excluded();
      if (mounted) {
        setState(() {
          history = retained;
          chatItems = loadedItems;
          chatExcluded = loadedExcluded;
          input.clear();
        });
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (scroll.hasClients) {
            scroll.animateTo(
              scroll.position.maxScrollExtent,
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOut,
            );
          }
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => error = e is AiFailure ? e.message : '채팅을 완료하지 못했어요.');
      }
    } finally {
      await s?.db.close();
      if (mounted) {
        setState(() {
          busy = false;
          waiting = false;
          pendingQuestion = null;
        });
      }
    }
  }

  void newConversation() {
    if (busy) return;
    setState(() {
      history = [];
      threadId = DateTime.now().microsecondsSinceEpoch.toString();
      error = null;
      input.clear();
    });
  }

  List<String> get _suggestedQuestions => widget.course != null
      ? const [
          '이 과목 공지 요약',
          '오늘 마감 뭐 있어?',
          '다음 수업은 언제야?',
          '이번 주 과제 뭐 있어?',
        ]
      : const [
          '오늘 마감 뭐 있어?',
          '다음 수업은 언제야?',
          '최근 공지 요약해 줘',
          '이번 주 과제 뭐 있어?',
          '이번 주 마감은?',
          'AI 공지 일정을 캘린더에 표시하려면?',
          '위젯은 어떻게 달아?',
          '휴강을 시간표에 반영하려면?',
          'ChatGPT에 내 과제를 연결하려면?',
        ];

  void _applySuggestedQuestion(String question) {
    if (busy || input.text.trim().isNotEmpty) return;
    input.value = TextEditingValue(
      text: question,
      selection: TextSelection.collapsed(offset: question.length),
    );
    if (demoBlocksAi || (hasKey && consent)) {
      unawaited(send());
    }
  }

  Future<void> previousConversations() async {
    try {
      final store = await Store.open();
      late List<ChatThread> threads;
      try {
        threads = await loadChatThreads(store, key);
      } finally {
        await store.db.close();
      }
      if (!mounted) return;
      final selected = await showModalBottomSheet<ChatThread>(
        context: context,
        isScrollControlled: true,
        builder: (ctx) => SafeArea(
          child: SizedBox(
            height: MediaQuery.sizeOf(ctx).height * .65,
            child: Column(
              children: [
                const ListTile(
                  title: Text('이전 대화'),
                  subtitle: Text('선택한 대화만 답변의 맥락으로 사용해요.'),
                ),
                Expanded(
                  child: threads.isEmpty
                      ? const Center(child: Text('저장된 대화가 없어요.'))
                      : ListView.builder(
                          itemCount: threads.length,
                          itemBuilder: (ctx, i) => ListTile(
                            title: Text(
                              threads[i].title,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            subtitle: Text(
                              '${threads[i].messages.length ~/ 2}개 질문',
                            ),
                            trailing: const Icon(Icons.chevron_right),
                            onTap: () => Navigator.pop(ctx, threads[i]),
                          ),
                        ),
                ),
              ],
            ),
          ),
        ),
      );
      if (selected != null && mounted) {
        setState(() {
          threadId = selected.id;
          history = selected.messages;
          error = null;
        });
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (scroll.hasClients) scroll.jumpTo(scroll.position.maxScrollExtent);
        });
      }
    } catch (_) {
      if (mounted) setState(() => error = '이전 대화를 불러오지 못했어요.');
    }
  }

  Future<void> clear() async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('대화를 지울까요?'),
        content: const Text(
          '이 화면에 저장된 대화를 삭제해요. 이미 전송된 데이터는 Google 측 보관 정책을 따라요.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('지우기'),
          ),
        ],
      ),
    );
    if (yes != true) return;
    final s = await Store.open();
    try {
      final threads = await loadChatThreads(s, key);
      threads.removeWhere((t) => t.id == threadId);
      await s.setMeta(
        '$key:threads',
        jsonEncode(threads.map((t) => t.toJson()).toList()),
      );
      if (threadId == 'legacy') await s.setMeta(key, '[]');
      if (mounted) setState(() => history = []);
    } finally {
      await s.db.close();
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: widget.embedded
        ? null
        : AppBar(
            title: Text(
              widget.course == null
                  ? 'AI 채팅'
                  : '${courseLabel('${widget.course!['course_nm']}')} 질문',
            ),
            actions: [
              IconButton(
                tooltip: 'AI 설정',
                onPressed: () => navigateTo(context, AiSettingsDestination()),
                icon: const Icon(Icons.settings_outlined),
              ),
              IconButton(
                tooltip: '대화 지우기',
                onPressed: busy ? null : clear,
                icon: const Icon(Icons.delete_outline),
              ),
            ],
          ),
    body: AdaptiveContent(
      child: SafeArea(
        child: Column(
          children: [
            // Wrapping row: every button stays on screen instead of hiding
            // past the right edge of a sideways scroll.
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
              child: Wrap(
                spacing: 4,
                children: [
                  FilledButton.tonalIcon(
                    onPressed: busy ? null : newConversation,
                    icon: const Icon(Icons.add),
                    label: const Text('새 대화'),
                  ),
                  TextButton.icon(
                    onPressed: busy ? null : previousConversations,
                    icon: const Icon(Icons.history),
                    label: const Text('이전 대화'),
                  ),
                  TextButton.icon(
                    icon: Icon(
                      share
                          ? Icons.library_books_outlined
                          : Icons.chat_bubble_outline,
                      size: 18,
                    ),
                    label: Text(share ? '과제·공지 참고 중' : '참고 자료 선택'),
                    onPressed: busy
                        ? null
                        : () async {
                            final selected = await showModalBottomSheet<bool>(
                              context: context,
                              showDragHandle: true,
                              builder: (ctx) => SafeArea(
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const ListTile(
                                      title: Text('과제·공지·시간표를 답변에 활용할까요?'),
                                      subtitle: Text(
                                        '허용하면 수집 자료 최대 60개·공지 25개·시간표 64칸을 Gemini로 전송해요. 선택을 기억하며, 첨부파일·계정 비밀번호는 보내지 않아요. 이전 대화는 공유 설정과 관계없이 전송돼요.',
                                      ),
                                    ),
                                    ListTile(
                                      title: const Text('과제·공지 참고하기'),
                                      trailing: share
                                          ? const Icon(Icons.check)
                                          : null,
                                      onTap: () => Navigator.pop(ctx, true),
                                    ),
                                    ListTile(
                                      title: const Text('질문과 대화만 보내기'),
                                      trailing: !share
                                          ? const Icon(Icons.check)
                                          : null,
                                      onTap: () => Navigator.pop(ctx, false),
                                    ),
                                  ],
                                ),
                              ),
                            );
                            if (selected == null) return;
                            final store = await Store.open();
                            try {
                              await store.setMeta(
                                MetaKey.aiChatShare,
                                selected ? 'yes' : 'no',
                              );
                            } finally {
                              await store.db.close();
                            }
                            if (mounted) setState(() => share = selected);
                          },
                  ),
                  TextButton.icon(
                    icon: const Icon(Icons.help_outline),
                    label: const Text('기능 가이드'),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute<void>(
                        builder: (_) => const AppHelpPage(),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (widget.embedded)
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: busy ? null : clear,
                  icon: const Icon(Icons.delete_outline),
                  label: const Text('대화 지우기'),
                ),
              ),
            if (share)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: TextButton(
                  onPressed: busy
                      ? null
                      : () async {
                          final s = await Store.open();
                          try {
                            final preview = await chatContext(
                              s,
                              courseId: widget.course == null
                                  ? null
                                  : courseKey(widget.course!),
                            );
                            if (context.mounted) {
                              showDialog<void>(
                                context: context,
                                builder: (ctx) => AlertDialog(
                                  title: const Text('현재 전송 자료'),
                                  content: SingleChildScrollView(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(chatContextSummary(preview)),
                                        ExpansionTile(
                                          tilePadding: EdgeInsets.zero,
                                          title: const Text('원본 데이터 보기'),
                                          children: [SelectableText(preview)],
                                        ),
                                      ],
                                    ),
                                  ),
                                  actions: [
                                    TextButton(
                                      onPressed: () => Navigator.pop(ctx),
                                      child: const Text('닫기'),
                                    ),
                                  ],
                                ),
                              );
                            }
                          } finally {
                            await s.db.close();
                          }
                        },
                  child: const Text('전송 자료 미리보기'),
                ),
              ),
            Expanded(
              child: loading
                  ? const Center(child: CircularProgressIndicator())
                  : ListView(
                      controller: scroll,
                      padding: const EdgeInsets.all(16),
                      children: [
                        if (history.isEmpty)
                          const Padding(
                            padding: EdgeInsets.symmetric(vertical: 12),
                            child: RadarEmptyState(
                              icon: Icons.chat_bubble_outline,
                              message:
                                  '“이번 주에 먼저 할 과제는?”처럼 질문해 보세요. 내 과제에 대한 질문은 참고 자료를 선택해 주세요. AI는 제출이나 일정 변경을 실행하지 않아요.',
                            ),
                          ),
                        ...history.map(
                          (m) => Align(
                            alignment: m['role'] == 'user'
                                ? Alignment.centerRight
                                : Alignment.centerLeft,
                            child: Container(
                              margin: const EdgeInsets.symmetric(vertical: 5),
                              padding: const EdgeInsets.all(14),
                              constraints: const BoxConstraints(maxWidth: 620),
                              decoration: BoxDecoration(
                                color: m['role'] == 'user'
                                    ? Theme.of(
                                        context,
                                      ).colorScheme.primaryContainer
                                    : Theme.of(
                                        context,
                                      ).colorScheme.surfaceContainerLow,
                                borderRadius: BorderRadius.circular(16),
                                border: m['role'] == 'user'
                                    ? null
                                    : Border.all(
                                        color: Theme.of(context)
                                            .colorScheme
                                            .outlineVariant
                                            .withValues(alpha: 0.7),
                                      ),
                              ),
                              child: m['role'] == 'model'
                                  ? Builder(
                                      builder: (context) {
                                        final prepared =
                                            prepareModelChatMessage(
                                              m['text']!,
                                              chatItems,
                                              course: widget.course,
                                            );
                                        return Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            MarkdownBody(
                                              data: prepared.markdown,
                                              selectable: true,
                                              imageBuilder: (uri, title, alt) =>
                                                  Text(alt ?? '이미지'),
                                              onTapLink:
                                                  (text, href, title) async {
                                                    if (href == null) return;
                                                    if (href.startsWith(
                                                      'campus-radar://task/',
                                                    )) {
                                                      final rawKey = Uri
                                                          .decodeComponent(
                                                            href.substring(
                                                              'campus-radar://task/'
                                                                  .length,
                                                            ),
                                                          );
                                                      final item =
                                                          chatItems
                                                              .where(
                                                                (i) =>
                                                                    i.key ==
                                                                    rawKey,
                                                              )
                                                              .firstOrNull ??
                                                          matchChatTaskItem(
                                                            text,
                                                            chatItems,
                                                            course:
                                                                widget.course,
                                                          );
                                                      if (item != null &&
                                                          context.mounted) {
                                                        await navigateTo(
                                                          context,
                                                          TaskDestination(
                                                            item: item,
                                                            excluded:
                                                                chatExcluded
                                                                    .contains(
                                                                      item.key,
                                                                    ),
                                                          ),
                                                        );
                                                      }
                                                      return;
                                                    }
                                                    final taskByLabel =
                                                        matchChatTaskItem(
                                                          text,
                                                          chatItems,
                                                          course: widget.course,
                                                        );
                                                    if (taskByLabel != null &&
                                                        context.mounted) {
                                                      await navigateTo(
                                                        context,
                                                        TaskDestination(
                                                          item: taskByLabel,
                                                          excluded: chatExcluded
                                                              .contains(
                                                                taskByLabel.key,
                                                              ),
                                                        ),
                                                      );
                                                      return;
                                                    }
                                                    final help = appHelpLink(
                                                      href,
                                                    );
                                                    if (help != null) {
                                                      await openHelpGuide(
                                                        context,
                                                        help,
                                                      );
                                                      return;
                                                    }
                                                    final u = Uri.tryParse(
                                                      href,
                                                    );
                                                    if (u == null ||
                                                        u.scheme != 'https' ||
                                                        u.host.isEmpty ||
                                                        u.userInfo.isNotEmpty) {
                                                      return;
                                                    }
                                                    try {
                                                      await bridge.invokeNative(
                                                        NativeMethod
                                                            .openChatLink,
                                                        {'url': u.toString()},
                                                      );
                                                    } catch (_) {
                                                      if (context.mounted) {
                                                        ScaffoldMessenger.of(
                                                          context,
                                                        ).showSnackBar(
                                                          const SnackBar(
                                                            content: Text(
                                                              '링크를 열지 못했어요.',
                                                            ),
                                                          ),
                                                        );
                                                      }
                                                    }
                                                  },
                                            ),
                                            if (prepared
                                                .relatedHelp
                                                .isNotEmpty) ...[
                                              const SizedBox(height: 10),
                                              Text(
                                                '관련 기능',
                                                style: Theme.of(
                                                  context,
                                                ).textTheme.labelSmall,
                                              ),
                                              const SizedBox(height: 4),
                                              Wrap(
                                                spacing: 6,
                                                runSpacing: 6,
                                                children: [
                                                  for (final topic
                                                      in prepared.relatedHelp)
                                                    ActionChip(
                                                      visualDensity:
                                                          VisualDensity.compact,
                                                      label: Text(topic.title),
                                                      onPressed: () =>
                                                          openHelpGuide(
                                                            context,
                                                            topic,
                                                          ),
                                                    ),
                                                ],
                                              ),
                                            ],
                                          ],
                                        );
                                      },
                                    )
                                  : SelectableText(m['text']!),
                            ),
                          ),
                        ),
                      ],
                    ),
            ),
            if (error != null)
              Padding(
                padding: const EdgeInsets.all(12),
                child: Text(
                  error!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error),
                ),
              ),
            if (busy) ...[
              const LinearProgressIndicator(),
              ListTile(
                title: Text(
                  pendingQuestion ?? '',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                subtitle: Text(
                  waiting ? '질문 접수됨 · 앞선 AI 작업이 끝나면 답변해요' : '답변을 만들고 있어요',
                ),
                trailing: waiting
                    ? TextButton(
                        onPressed: () => setState(() => cancelled = true),
                        child: const Text('대기 취소'),
                      )
                    : null,
              ),
            ],
            ValueListenableBuilder<TextEditingValue>(
              valueListenable: input,
              builder: (context, value, _) {
                if (loading ||
                    busy ||
                    history.isNotEmpty ||
                    value.text.trim().isNotEmpty) {
                  return const SizedBox.shrink();
                }
                final suggestions = _suggestedQuestions;
                return Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 4,
                  ),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        for (var i = 0; i < suggestions.length; i++) ...[
                          if (i > 0) const SizedBox(width: 8),
                          ActionChip(
                            label: Text(suggestions[i]),
                            onPressed: () =>
                                _applySuggestedQuestion(suggestions[i]),
                          ),
                        ],
                      ],
                    ),
                  ),
                );
              },
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: TextField(
                      controller: input,
                      enabled: !busy,
                      maxLength: 2000,
                      minLines: 1,
                      maxLines: 4,
                      decoration: const InputDecoration(
                        hintText: '질문 입력',
                        counterText: '',
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    tooltip: '질문 보내기',
                    onPressed: busy ? null : send,
                    icon: const Icon(Icons.send),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(
                '개인 Gemini 키 사용 · 대화별 최근 20개 질문 보관',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

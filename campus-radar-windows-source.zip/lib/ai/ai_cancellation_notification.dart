import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:campus_radar/ai/ai_inbox_repository.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/ai/ai_state_models.dart';
import 'package:campus_radar/ai/ai_state_repository.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/core/notification_gateway.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/core/transient_message.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';
import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'package:campus_radar/schedule/timetable_model.dart';

const cancellationPayloadPrefix = 'CANCEL:';

final cancellationRefresh = ValueNotifier<int>(0);

String cancellationNotificationPayload(String noticeId, String candidateKey) {
  final prefix = 'AI:$noticeId:';
  final id =
      candidateKey.startsWith(prefix) && candidateKey.length > prefix.length
      ? candidateKey.substring(prefix.length)
      : candidateKey;
  return '$cancellationPayloadPrefix${Uri.encodeComponent(noticeId)}:${Uri.encodeComponent(id)}';
}

({String noticeId, String candidateId, String candidateKey})?
parseCancellationNotificationPayload(String? payload) {
  if (payload == null || !payload.startsWith(cancellationPayloadPrefix)) {
    return null;
  }
  final rest = payload.substring(cancellationPayloadPrefix.length);
  final sep = rest.indexOf(':');
  if (sep <= 0 || sep >= rest.length - 1) return null;
  final rawNotice = rest.substring(0, sep);
  final rawCandidate = rest.substring(sep + 1);
  if (rawCandidate.contains(':')) return null;
  try {
    final noticeId = Uri.decodeComponent(rawNotice);
    final candidateId = Uri.decodeComponent(rawCandidate);
    if (noticeId.isEmpty || candidateId.isEmpty) return null;
    final candidateKey = candidateId.startsWith('AI:$noticeId:')
        ? candidateId
        : 'AI:$noticeId:$candidateId';
    return (
      noticeId: noticeId,
      candidateId: candidateId,
      candidateKey: candidateKey,
    );
  } on ArgumentError {
    return null;
  }
}

/// Matches saved timetable slots for [notice] using the same course/section
/// rules as CancellationEditor. Throws FormatException on ambiguous sections.
List<ClassSlot> matchNoticeCourseSlots(
  List<ClassSlot> allSlots,
  CampusNotice notice,
) {
  var data = allSlots
      .where(
        (s) =>
            s.weekday >= 1 &&
            s.weekday <= 7 &&
            s.start >= 0 &&
            s.end < 1440 &&
            s.end > s.start &&
            s.course.isNotEmpty &&
            !s.courseKey.startsWith('personal:'),
      )
      .toList();
  final id = notice.context['course_id'],
      section = notice.context['class_no'];
  if (id != null &&
      section != null &&
      '$id'.isNotEmpty &&
      '$section'.isNotEmpty) {
    return data.where((e) => e.courseKey == '$id:$section').toList();
  }
  final target = notice.course.replaceAll(RegExp(r'\s+'), '');
  if (target.isEmpty) return const [];
  data = data
      .where((e) => e.course.replaceAll(RegExp(r'\s+'), '') == target)
      .toList();
  if (data.map((e) => e.courseKey).toSet().length > 1) {
    throw const FormatException(
      '같은 이름의 분반이 여러 개예요. 공지 과목과 시간표 연결을 확인해 주세요.',
    );
  }
  return data;
}

Set<String> preselectedCancellationSlotIds(
  List<ClassSlot> courseSlots,
  DateTime start,
  DateTime end, {
  String candidateTime = '',
}) {
  final weekdayMatched = courseSlots
      .where((e) => planCancellations([e], {e.id}, start, end).isNotEmpty)
      .toList();
  if (candidateTime.isNotEmpty) {
    final timeMatched = weekdayMatched
        .where((e) => slotTime(e.start) == candidateTime)
        .toList();
    if (timeMatched.isNotEmpty) {
      return timeMatched.map((e) => e.id).toSet();
    }
  }
  return weekdayMatched.map((e) => e.id).toSet();
}

List<ClassCancellation> matchCandidateCancellations(
  List<ClassSlot> allSlots,
  CampusNotice notice,
  ScheduleCandidate candidate,
) {
  if (candidate.category != 'class' || candidate.action != 'cancel') {
    return const [];
  }
  final start = strictDate(candidate.date);
  if (start == null) return const [];
  final end = candidate.endDate.isEmpty
      ? start
      : strictDate(candidate.endDate);
  if (end == null ||
      end.isBefore(start) ||
      end.difference(start).inDays > 365) {
    return const [];
  }
  List<ClassSlot> courseSlots;
  try {
    courseSlots = matchNoticeCourseSlots(allSlots, notice);
  } on FormatException {
    return const [];
  }
  if (courseSlots.isEmpty) return const [];
  final selected = preselectedCancellationSlotIds(
    courseSlots,
    start,
    end,
    candidateTime: candidate.time,
  );
  if (selected.isEmpty) return const [];
  return planCancellations(
    courseSlots,
    selected,
    start,
    end,
    source: notice.title,
  );
}

({String title, String body}) formatCancellationNotification(
  CampusNotice notice,
  List<ClassCancellation> planned,
) {
  final rawCourse = notice.course.trim().isNotEmpty
      ? notice.course.trim()
      : planned.first.course;
  final title = '휴강 감지: ${courseLabel(rawCourse)}';
  final dates = planned.map((c) => c.date).toSet().toList()..sort();
  String dayLabel(String iso) {
    final d = strictDate(iso)!;
    return '${d.month}월 ${d.day}일(${weekNames[d.weekday - 1]})';
  }

  final when = dates.length == 1
      ? dayLabel(dates.first)
      : '${dayLabel(dates.first)}~${dayLabel(dates.last)}';
  return (title: title, body: '$when 수업 · 눌러서 시간표에 반영');
}

Future<bool> cancellationNotificationsPermitted() async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  AndroidFlutterLocalNotificationsPlugin? android;
  try {
    android = notifications
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >();
  } catch (_) {
    android = null;
  }
  final desktop = Platform.isWindows && android == null;
  if (desktop) {
    return prefs.getBool(PrefKey.desktopNotifications) ?? true;
  }
  if (Platform.isIOS) {
    try {
      return (await notifications
                  .resolvePlatformSpecificImplementation<
                    IOSFlutterLocalNotificationsPlugin
                  >()
                  ?.checkPermissions())
              ?.isEnabled ??
          false;
    } catch (_) {
      return false;
    }
  }
  return await android?.areNotificationsEnabled() ?? false;
}

typedef CancellationNotifier =
    Future<bool> Function({
      required String key,
      required String title,
      required String body,
      required String payload,
    });

Future<bool> showCancellationNotification({
  required String key,
  required String title,
  required String body,
  required String payload,
}) async {
  await ensureNotificationsInitialized();
  if (!await cancellationNotificationsPermitted()) return false;
  await notifications.show(
    id: notificationId('cancel:$key'),
    title: title,
    body: body,
    notificationDetails: cancellationNoticeStyle,
    payload: payload,
  );
  return true;
}

Future<int> notifyConfirmedCancellations(
  Store store,
  CampusNotice notice,
  List<ScheduleCandidate> candidates, {
  CancellationNotifier notifier = showCancellationNotification,
}) async {
  if (!candidates.any((c) => c.category == 'class' && c.action == 'cancel')) {
    return 0;
  }
  final job = await AiStateRepository(store).job(notice.id);
  if (job.isUserDecision) return 0;
  List<ClassSlot> allSlots;
  try {
    allSlots = decodeSlots(await store.meta(MetaKey.timetableEntries));
  } catch (_) {
    return 0;
  }
  if (allSlots.isEmpty) return 0;
  final existingCancelledIds = (await readClassCancellations(
    store,
  )).map((c) => c.id).toSet();
  final repo = AiStateRepository(store);
  var sent = 0;
  for (final candidate in candidates) {
    if (candidate.category != 'class' || candidate.action != 'cancel') {
      continue;
    }
    final key = candidateKey(notice, candidate);
    final state = await repo.schedule(key);
    final stateJson = state.toJson();
    if (state.decision == ScheduleDecision.excluded ||
        stateJson['resolution'] == 'classCancellationApplied' ||
        stateJson['resolution'] == 'notMyAudience') {
      continue;
    }
    final planned = matchCandidateCancellations(allSlots, notice, candidate);
    if (planned.isEmpty) continue;
    if (planned.every((p) => existingCancelledIds.contains(p.id))) {
      continue;
    }
    final plannedIds = (planned.map((p) => p.id).toList()..sort()).join(',');
    final candidateNotifiedKey = MetaKey.aiCancelNotified(key);
    final plannedNotifiedKey = MetaKey.aiCancelNotified(
      '${notice.id}:$plannedIds',
    );
    if (await store.meta(candidateNotifiedKey) != null ||
        await store.meta(plannedNotifiedKey) != null) {
      continue;
    }
    final message = formatCancellationNotification(notice, planned);
    final payload = cancellationNotificationPayload(notice.id, key);
    try {
      if (!await notifier(
        key: key,
        title: message.title,
        body: message.body,
        payload: payload,
      )) {
        continue;
      }
      final stamp = DateTime.now().toUtc().toIso8601String();
      await store.setMeta(candidateNotifiedKey, stamp);
      await store.setMeta(plannedNotifiedKey, stamp);
      await store.log(
        'notification',
        '휴강 감지 알림 발송 요청',
        '${message.title} · ${message.body}',
      );
      sent++;
    } catch (e) {
      await store.log(
        'notification',
        '휴강 감지 알림 요청 실패',
        withCause('${notice.title} · 다음 분석 확인 때 다시 시도해요.', e),
      );
    }
  }
  return sent;
}

typedef ResolvedCancellationTarget = ({
  CampusNotice notice,
  ScheduleCandidate candidate,
  String candidateKey,
  SessionMark mark,
});

Future<ResolvedCancellationTarget?> resolveCancellationNotificationTarget(
  String? payload,
) async {
  final parsed = parseCancellationNotificationPayload(payload);
  if (parsed == null) return null;
  final store = await Store.open();
  try {
    // Logged out or blocked session: fall back to the review inbox.
    try {
      await SessionScope.capture(store);
    } on SessionChanged {
      return null;
    }
    final mark = await SessionMark.capture(store);
    final notices = await store.notices();
    final snapshot = await AiInboxRepository(store).read();
    final match = snapshot.candidates.where((row) {
      final n = row['notice'] as CampusNotice;
      final c = row['candidate'] as ScheduleCandidate;
      final k = row['key'] as String;
      return n.id == parsed.noticeId &&
          (k == parsed.candidateKey || k == parsed.candidateId) &&
          c.category == 'class' &&
          c.action == 'cancel';
    }).firstOrNull;
    if (match == null) {
      await store.log(
        'notification',
        '휴강 알림 대상 없음',
        '후보가 없거나 변경되어 검토함을 열어요.',
      );
      return null;
    }
    final savedNotice = match['notice'] as CampusNotice;
    final currentNotice = notices
        .where((n) => n.id == savedNotice.id)
        .firstOrNull;
    final notice = currentNotice ?? savedNotice;
    final candidate = match['candidate'] as ScheduleCandidate;
    await store.log(
      'notification',
      '휴강 알림 열기',
      '${courseLabel(notice.course)} · ${candidate.title}',
    );
    return (
      notice: notice,
      candidate: candidate,
      candidateKey: match['key'] as String,
      mark: mark,
    );
  } finally {
    await store.db.close();
  }
}

Future<SessionMark?> markCandidateCancellationApplied(
  String candidateKey, {
  SessionMark? mark,
}) async {
  final s = await Store.open();
  try {
    try {
      if (mark != null && mark.epoch != null) {
        await mark.verify(s);
      } else if (mark != null) {
        if (await s.meta(MetaKey.sessionBlocked) == 'yes' ||
            await credentials.read(key: 'id') != mark.account) {
          throw SessionChanged();
        }
      }
    } on SessionChanged {
      return null;
    }
    final repo = AiStateRepository(s);
    final excluded = (await repo.schedule(
      candidateKey,
    )).withDecision(ScheduleDecision.excluded);
    await repo.saveSchedule(
      candidateKey,
      ConfirmedSchedule.fromJson({
        ...excluded.toJson(),
        'resolution': 'classCancellationApplied',
      }),
    );
    return await SessionMark.capture(s);
  } finally {
    await s.db.close();
  }
}

Future<void> undoCandidateCancellation(
  BuildContext? context,
  CancellationReceipt receipt,
  String candidateKey, {
  SessionMark? mark,
  Future<void> Function()? onChanged,
}) async {
  final s = await Store.open();
  try {
    await mark?.verify(s);
    await CancellationRepository(s).undo(receipt);
    final old = await AiStateRepository(s).schedule(candidateKey);
    await AiStateRepository(
      s,
    ).saveSchedule(candidateKey, old.withDecision(ScheduleDecision.review));
    try {
      await bridge.invokeNative(NativeMethod.refreshWidget);
    } catch (_) {
      // Widgets refresh on the next app start or sync anyway.
    }
    cancellationRefresh.value++;
    await onChanged?.call();
  } catch (e) {
    if (context != null && context.mounted) {
      showTransientMessage(
        context,
        SnackBar(
          content: Text(
            e is FormatException
                ? e.message
                : '실행 취소하지 못했어요. 휴강 목록에서 확인해 주세요.',
          ),
        ),
      );
    }
  } finally {
    await s.db.close();
  }
}

Future<void> finishCandidateCancellation(
  BuildContext? context, {
  required String candidateKey,
  required CancellationReceipt? receipt,
  SessionMark? mark,
  Future<void> Function()? onChanged,
}) async {
  final activeMark = await markCandidateCancellationApplied(
    candidateKey,
    mark: mark,
  );
  if (activeMark == null) return;
  cancellationRefresh.value++;
  await onChanged?.call();
  if (context != null && context.mounted && receipt != null) {
    showTransientMessage(
      context,
      SnackBar(
        content: const Text('선택한 수업에 휴강을 반영했어요'),
        action: SnackBarAction(
          label: '실행 취소',
          onPressed: () => undoCandidateCancellation(
            context,
            receipt,
            candidateKey,
            mark: activeMark,
            onChanged: onChanged,
          ),
        ),
      ),
    );
  }
}

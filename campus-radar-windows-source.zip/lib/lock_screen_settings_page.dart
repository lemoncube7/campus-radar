import 'native_contract.dart';
import 'native_bridge.dart';
import 'ui_refresh.dart';
import 'dart:async';
import 'package:flutter/material.dart';

class LockScreenSettingsPage extends StatefulWidget {
  const LockScreenSettingsPage({super.key});
  @override
  State<LockScreenSettingsPage> createState() => _LockScreenSettingsPageState();
}

class _LockScreenSettingsPageState extends State<LockScreenSettingsPage>
    with WidgetsBindingObserver {
  bool enabled = false, allowed = false, details = false, busy = true;
  String mode = 'compact', position = 'right';
  double cardWidth = 270,
      cardHeight = 380,
      cardX = 100,
      cardY = 50,
      opacity = 80;
  String? error;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    unawaited(load());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) unawaited(load());
  }

  Future<void> load() async {
    try {
      final s =
          await bridge.invokeNativeMap<String, dynamic>(
            NativeMethod.lockSettings,
          ) ??
          {};
      if (mounted) {
        setState(() {
          enabled = s['enabled'] == true;
          allowed = s['allowed'] == true;
          details = s['details'] == true;
          mode = s['mode'] ?? 'compact';
          position = s['position'] ?? 'right';
          cardWidth = (s['width'] as num?)?.toDouble() ?? 270;
          cardHeight = (s['height'] as num?)?.toDouble() ?? 380;
          cardX =
              (s['x'] as num?)?.toDouble() ?? (position == 'left' ? 0 : 100);
          cardY = (s['y'] as num?)?.toDouble() ?? 50;
          opacity = (s['opacity'] as num?)?.toDouble() ?? 80;
          busy = false;
          error = null;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          busy = false;
          error = '기기 설정을 읽지 못했습니다.';
        });
      }
    }
  }

  Future<void> save(bool value) async {
    setState(() => busy = true);
    try {
      await bridge.invokeNative(NativeMethod.lockConfigure, {
        'enabled': value,
        'mode': mode,
        'details': details,
        'position': position,
        'width': cardWidth.round(),
        'height': cardHeight.round(),
        'x': cardX.round(),
        'y': cardY.round(),
        'opacity': opacity.round(),
      });
      await load();
    } catch (_) {
      if (mounted) {
        setState(() {
          error = '접근성 설정에서 캠퍼스레이더 잠금화면을 켠 후 다시 시도해 주세요.';
          busy = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('잠금화면 정보')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const SectionHeading('카드 미리보기', subtitle: '예시 화면 · 실제 과제 정보가 아닙니다.'),
        Container(
          height: 230,
          decoration: BoxDecoration(
            color: const Color(0xff263642),
            borderRadius: BorderRadius.circular(24),
          ),
          padding: const EdgeInsets.all(12),
          child: LayoutBuilder(
            builder: (context, box) => Align(
              alignment: mode == 'compact'
                  ? Alignment(cardX / 50 - 1, cardY / 50 - 1)
                  : Alignment.center,
              child: Container(
                width: mode == 'compact'
                    ? (cardWidth / 360 * box.maxWidth).clamp(120, box.maxWidth)
                    : box.maxWidth,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(
                    alpha: mode == 'compact' ? opacity / 100 : 0.96,
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: DefaultTextStyle(
                  style: const TextStyle(color: Colors.black, fontSize: 13),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (mode != 'compact')
                        const Text(
                          '먼저 확인할 일',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      Text(details ? '컴프2 · 실습 과제' : '미완료 항목 2개'),
                      const SizedBox(height: 6),
                      const Text('오늘 23:59 · 4시간 남음'),
                      if (mode == 'full')
                        const Padding(
                          padding: EdgeInsets.only(top: 12),
                          child: Text('스와이프해 잠금화면 보기'),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          '휴대전화를 잠그고 화면을 켜면 마지막 수집한 과제 정보를 표시합니다. 잠금 해제를 대신하지 않으며, 화면을 켜거나 다른 앱 사용 중에 강제로 띄우지 않습니다.',
        ),
        const SizedBox(height: 16),
        SwitchListTile(
          title: const Text('잠금화면 카드 사용'),
          subtitle: const Text('접근성 서비스가 켜져 있어야 합니다. 기본값은 꺼짐입니다.'),
          value: enabled,
          onChanged: busy ? null : save,
        ),
        if (!allowed)
          FilledButton(
            onPressed: () => bridge.invokeNative(NativeMethod.lockPermission),
            child: const Text('접근성 서비스 설정 열기'),
          ),
        const SizedBox(height: 16),
        DropdownButtonFormField<String>(
          key: ValueKey('mode:$mode'),
          initialValue: mode,
          decoration: const InputDecoration(labelText: '표시 방식'),
          items: const [
            DropdownMenuItem(value: 'compact', child: Text('작은 카드')),
            DropdownMenuItem(value: 'full', child: Text('전체 카드')),
          ],
          onChanged: busy
              ? null
              : (v) async {
                  setState(() => mode = v!);
                  await save(enabled);
                },
        ),
        const SizedBox(height: 16),
        SwitchListTile(
          title: const Text('과목명·과제명 표시'),
          subtitle: const Text(
            '끄면 개수만 표시합니다. 켜면 잠금 상태에서도 주변 사람이 내용을 볼 수 있습니다.',
          ),
          value: details,
          onChanged: busy
              ? null
              : (v) async {
                  setState(() => details = v);
                  await save(enabled);
                },
        ),
        if (mode == 'compact') ...[
          _adjuster(
            '배경 불투명도',
            opacity,
            0,
            100,
            '${opacity.round()}% · 글자는 선명하게 유지',
            (v) => opacity = v,
          ),
          const Text('작은 카드 크기와 위치'),
          const Text('화면 가장자리 안에서 배치됩니다. 내용이 길면 카드 안을 스크롤할 수 있습니다.'),
          _adjuster(
            '카드 폭',
            cardWidth,
            180,
            360,
            '${cardWidth.round()}',
            (v) => cardWidth = v,
          ),
          _adjuster(
            '카드 높이',
            cardHeight,
            180,
            640,
            '${cardHeight.round()}',
            (v) => cardHeight = v,
          ),
          _adjuster(
            '가로 위치',
            cardX,
            0,
            100,
            '${cardX.round()}% · 왼쪽 → 오른쪽',
            (v) => cardX = v,
          ),
          _adjuster(
            '세로 위치',
            cardY,
            0,
            100,
            '${cardY.round()}% · 위 → 아래',
            (v) => cardY = v,
          ),
        ] else
          const Text('전체 카드는 어느 방향으로든 스와이프하면 닫힙니다. 원래 잠금화면에서 잠금을 해제하세요.'),
        if (error != null) Text(error!),
        const SizedBox(height: 16),
        const Text(
          '접근성에서 ‘캠퍼스레이더 잠금화면’을 직접 켜 주세요. 화면 내용 읽기·입력 조작은 요청하지 않습니다. 작은 카드는 가로 스와이프로, 전체 카드는 어느 방향으로든 스와이프해 숨깁니다. 세로 스크롤로 카드 내용을 볼 수 있습니다.',
        ),
      ],
    ),
  );

  Widget _adjuster(
    String label,
    double value,
    double min,
    double max,
    String description,
    void Function(double) update,
  ) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const SizedBox(height: 16),
      Text('$label · $description'),
      Slider(
        semanticFormatterCallback: (v) => '$label ${v.round()}',
        value: value.clamp(min, max),
        min: min,
        max: max,
        divisions: ((max - min) / 10).round(),
        onChanged: busy ? null : (v) => setState(() => update(v)),
        onChangeEnd: busy ? null : (_) => save(enabled),
      ),
    ],
  );
}

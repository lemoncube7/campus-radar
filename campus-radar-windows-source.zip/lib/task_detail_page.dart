import 'native_contract.dart';
import 'calendar_draft_page.dart';
import 'changes_page.dart';
import 'task_presentation.dart';
import 'native_bridge.dart';
import 'app_credentials.dart';
import 'course_labels.dart';
import 'campus_models.dart';
import 'media_widgets.dart';
import 'ui_refresh.dart';
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'campus.dart';
import 'services.dart';

class DetailPage extends StatefulWidget {
  final CampusItem item;
  final bool excluded;
  const DetailPage({super.key, required this.item, this.excluded = false});
  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  bool busy = false;
  late bool excluded;
  @override
  void initState() {
    super.initState();
    excluded = widget.excluded;
  }

  Future<void> toggleExcluded() async {
    if (!excluded) {
      final accepted = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('목록에서 제외할까요?'),
          content: const Text(
            '이 기기의 목록에서 숨기고 해당 항목의 알림을 취소합니다. 제외 항목 보기에서 다시 복구할 수 있습니다.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('취소'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('제외'),
            ),
          ],
        ),
      );
      if (accepted != true) return;
    }
    setState(() => busy = true);
    try {
      await excludeItem(widget.item, !excluded);
      if (mounted) {
        setState(() => excluded = !excluded);
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('변경하지 못했습니다. 다시 시도해 주세요.')),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> go() async {
    setState(() => busy = true);
    final client = CampusClient();
    try {
      final id = await credentials.read(key: 'id'),
          pw = await credentials.read(key: 'pw');
      if (id == null || pw == null) throw CampusException('포털을 다시 연결해 주세요.');
      await client.login(id, pw);
      final navigation = await client.navigation(widget.item);
      await bridge.invokeNative(NativeMethod.openCampus, navigation);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              e is CampusException ? e.message : '사이버캠퍼스를 열지 못했습니다.',
            ),
          ),
        );
      }
    } finally {
      client.close();
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final i = widget.item;
    return Scaffold(
      appBar: AppBar(
        title: Text(i.type == 'LR' ? '과제 상세' : '콘텐츠 상세'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (_) => toggleExcluded(),
            itemBuilder: (_) => [
              PopupMenuItem(
                value: 'visibility',
                child: Text(excluded ? '목록에 복구' : '목록에서 제외'),
              ),
            ],
          ),
        ],
      ),
      bottomNavigationBar: PinnedAction(
        child: FilledButton.icon(
          onPressed: busy ? null : go,
          icon: const Icon(Icons.open_in_new),
          label: Text(busy ? '연결 중…' : '사이버캠퍼스 열기'),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Text(courseLabel(i.course)),
          const SizedBox(height: 8),
          Text(
            i.title,
            style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: deadlineBackground(i),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              deadlineLabel(i),
              style: TextStyle(
                color: deadlineColor(i, context),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              Chip(label: Text(statusText(i))),
              Chip(label: Text(remainingText(i))),
            ],
          ),
          if (Platform.isAndroid || Platform.isIOS)
            TextButton.icon(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => CalendarDraftPage(
                    itemKey: i.key,
                    title: i.title,
                    deadlineCourse: i.course,
                    description:
                        '마감 일정 · 한국 시간\n${i.body}\nhttps://dcs-learning.cnu.ac.kr/home',
                    start: i.due,
                    deadline: true,
                  ),
                ),
              ),
              icon: const Icon(Icons.event_available),
              label: Text(Platform.isWindows ? '일정 파일 저장' : '캘린더에 전송'),
            ),

          TextButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ChangesPage(itemKey: i.key)),
            ),
            icon: const Icon(Icons.history),
            label: const Text('이 항목의 변경 이력'),
          ),
          if (excluded) const Text('목록에서 제외됨 · 알림 꺼짐'),
          Text(i.due == null ? '마감 미확인' : '마감 ${formatDate(i.due!)}'),
          const SizedBox(height: 20),
          CampusBodyView(
            body: i.body.isEmpty ? '상세 내용은 사이버캠퍼스에서 확인하세요.' : i.body,
            bodyHtml: i.bodyHtml,
            media: i.media,
          ),
          const SizedBox(height: 28),
          const Text(
            '제출·완료 상태는 마지막 수집 기준입니다. 콘텐츠는 해당 강의의 학습 항목으로 연결합니다.',
            style: TextStyle(fontSize: 12),
          ),
        ],
      ),
    );
  }
}

import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/home/feature_discovery.dart';
import 'package:flutter/material.dart';
import 'package:campus_radar/tasks/task_display_preferences.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/services.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/core/radar_card.dart';
import 'package:campus_radar/core/ui_refresh.dart';

class TaskCleanupSettings extends StatefulWidget {
  const TaskCleanupSettings({super.key});
  @override
  State<TaskCleanupSettings> createState() => _TaskCleanupState();
}

class _TaskCleanupState extends State<TaskCleanupSettings> {
  String policy = 'confirm';
  bool notify = true, busy = true;
  String? error;
  @override
  void initState() {
    super.initState();
    FeatureDiscovery.record(DiscoverFeature.tasks);
    load();
    loadTaskDisplayPreferences().catchError((_) {});
  }

  Future<void> load() async {
    Store? s;
    try {
      s = await Store.open();
      final p = await s.meta(MetaKey.overduePolicy) ?? 'confirm';
      final n = await s.meta(MetaKey.notifyNonAttendance) != 'no';
      if (mounted) {
        setState(() {
          policy = p;
          notify = n;
          busy = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          busy = false;
          error = '설정을 읽지 못했어요.';
        });
      }
    } finally {
      await s?.db.close();
    }
  }

  Future<void> save(String p, bool n) async {
    setState(() => busy = true);
    Store? s;
    try {
      s = await Store.open();
      await s.setMeta(MetaKey.overduePolicy, p);
      await s.setMeta(MetaKey.notifyNonAttendance, n ? 'yes' : 'no');
      await reconcile(s);
      await bridge.invokeNative(NativeMethod.refreshWidget);
      if (mounted) {
        setState(() {
          policy = p;
          notify = n;
          error = null;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() => error = '설정 저장 또는 알림 갱신을 완료하지 못했어요. 다시 확인해 주세요.');
      }
    } finally {
      await s?.db.close();
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> hideNonAttendance() async {
    setState(() => busy = true);
    Store? s;
    try {
      s = await Store.open();
      final excluded = await s.excluded();
      final items = (await s.items()).where(
        (i) =>
            i.type == 'LV' &&
            i.attendanceRequired == false &&
            !excluded.contains(i.key),
      );
      var count = 0;
      for (final item in items) {
        await s.setTaskExcluded(item.key, true);
        count++;
      }
      await s.log('system', '출석 미반영 콘텐츠 숨김', '$count개 · 숨김 목록에서 복구할 수 있어요.');
      await reconcile(s);
      await bridge.invokeNative(NativeMethod.refreshWidget);
      if (mounted) {
        setState(() => error = '$count개를 숨겼어요. 할 일 탭의 숨김 목록에서 복구할 수 있어요.');
      }
    } catch (_) {
      if (mounted) setState(() => error = '일부 항목을 숨기지 못했어요. 목록을 확인해 주세요.');
    } finally {
      await s?.db.close();
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final muted = Theme.of(context).textTheme.bodySmall?.copyWith(
      color: Theme.of(context).colorScheme.onSurfaceVariant,
    );
    return Scaffold(
      appBar: AppBar(title: const Text('할 일 표시·정리')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          RadarCard(
            margin: const EdgeInsets.only(bottom: 16),
            padding: EdgeInsets.zero,
            child: ValueListenableBuilder<bool>(
              valueListenable: showWaitingAssignments,
              builder: (context, shown, _) => SwitchListTile(
                secondary: const RadarIconBox(
                  icon: Icons.hourglass_bottom_outlined,
                ),
                title: const Text('제출 시작 전 과제 보기'),
                subtitle: const Text(
                  '켜면 할 일 탭의 제출 전 과제에서 볼 수 있어요. 수집은 유지하며, 시작 전 과제를 하루 요약과 마감 알림에는 포함하지 않아요.',
                ),
                value: shown,
                onChanged: (value) async {
                  try {
                    await saveShowWaitingAssignments(value);
                  } catch (_) {
                    if (mounted) {
                      setState(() => error = '제출 대기 표시 설정을 저장하지 못했어요.');
                    }
                  }
                },
              ),
            ),
          ),
          const SectionHeading('마감 지난 항목'),
          const SizedBox(height: 10),
          RadarCard(
            margin: const EdgeInsets.only(bottom: 16),
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                DropdownButtonFormField<String>(
                  key: ValueKey(policy),
                  initialValue: policy,
                  decoration: const InputDecoration(labelText: '정리 방식'),
                  items: const [
                    DropdownMenuItem(
                      value: 'confirm',
                      child: Text('확인하고 숨기기 버튼 표시'),
                    ),
                    DropdownMenuItem(
                      value: 'day',
                      child: Text('마감 24시간 후 자동 숨김'),
                    ),
                    DropdownMenuItem(
                      value: 'immediate',
                      child: Text('마감 즉시 자동 숨김'),
                    ),
                  ],
                  onChanged: busy ? null : (v) => save(v!, notify),
                ),
                const SizedBox(height: 12),
                Text(
                  '학교의 제출·완료 상태는 바꾸지 않아요. 숨김 목록에서 복구할 수 있어요. 자동 숨김은 마감이 연장되면 다시 표시되며, 직접 복구한 항목은 같은 마감일 동안 자동으로 숨기지 않아요.',
                  style: muted,
                ),
              ],
            ),
          ),
          RadarCard(
            margin: const EdgeInsets.only(bottom: 12),
            padding: EdgeInsets.zero,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SwitchListTile(
                  secondary: const RadarIconBox(
                    icon: Icons.notifications_paused_outlined,
                  ),
                  title: const Text('출석 미반영 콘텐츠도 마감 알림'),
                  subtitle: const Text(
                    '학교에서 명시적으로 미반영으로 표시한 콘텐츠만 해당해요. 미확인 콘텐츠는 기존대로 알려요.',
                  ),
                  value: notify,
                  onChanged: busy ? null : (v) => save(policy, v),
                ),
                const Divider(height: 1),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      OutlinedButton.icon(
                        onPressed: busy ? null : hideNonAttendance,
                        icon: const Icon(Icons.visibility_off_outlined),
                        label: const Text('현재 출석 미반영 콘텐츠 숨기기'),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        '현재 수집된 미반영 콘텐츠만 숨겨요. 새 콘텐츠를 자동으로 숨기지는 않으며, 미확인 항목은 유지해요.',
                        style: muted,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (error != null)
            Text(
              error!,
              style: TextStyle(color: Theme.of(context).colorScheme.error),
            ),
        ],
      ),
    );
  }
}

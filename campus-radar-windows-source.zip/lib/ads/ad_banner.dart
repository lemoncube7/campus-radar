import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:campus_radar/core/demo_state.dart';

/// Ads are shown only in the Galaxy Store build with ads on:
///   flutter build apk --release -P galaxyStore=true -P ads=true \
///     --dart-define=STORE=galaxy --dart-define=ADS=on \
///     [-P admobAppId=ca-app-pub-...~...] [--dart-define=AD_UNIT=ca-app-pub-.../...]
/// Without AD_UNIT, Google's public test banner is used. Every other build
/// (GitHub APK, iOS, Windows) never shows or loads an ad.
const adsEnabled = bool.fromEnvironment('ADS_ON') ||
    String.fromEnvironment('ADS') == 'on';
const _adUnit = String.fromEnvironment('AD_UNIT');

/// Screens that hide the banner (settings, AI chat input, demo) set this.
final adBannerSuppressed = ValueNotifier<int>(0);

class AdBanner extends StatelessWidget {
  const AdBanner({super.key});

  @override
  Widget build(BuildContext context) {
    if (!adsEnabled || kIsWeb || !Platform.isAndroid) {
      return const SizedBox.shrink();
    }
    return ValueListenableBuilder<int>(
      valueListenable: adBannerSuppressed,
      builder: (context, suppressed, _) => ValueListenableBuilder<bool>(
        valueListenable: demoModeNotifier,
        builder: (context, _, _) {
          if (suppressed > 0 || isDemoActive) return const SizedBox.shrink();
          // Standard 320x50 banner. The view gets only the ad unit id: no
          // app data (courses, posts, school) is passed to the ad SDK.
          return SafeArea(
            top: false,
            child: SizedBox(
              height: 50,
              child: AndroidView(
                viewType: 'campus_radar/ad_banner',
                creationParams: {if (_adUnit.isNotEmpty) 'unit': _adUnit},
                creationParamsCodec: const StandardMessageCodec(),
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Wrap a screen that must not show ads (settings, AI chat).
class NoAdScope extends StatefulWidget {
  final Widget child;
  const NoAdScope({super.key, required this.child});
  @override
  State<NoAdScope> createState() => _NoAdScopeState();
}

class _NoAdScopeState extends State<NoAdScope> {
  @override
  void initState() {
    super.initState();
    adBannerSuppressed.value++;
  }

  @override
  void dispose() {
    adBannerSuppressed.value--;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.child;
}

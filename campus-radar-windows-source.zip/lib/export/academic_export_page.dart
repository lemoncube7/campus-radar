import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/core/developer_mode.dart';
import 'dart:convert';
import 'package:campus_radar/campus/academic_attachment.dart';
import 'package:campus_radar/campus/material_catalog.dart';
import 'package:campus_radar/campus/media_cache.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:campus_radar/export/academic_export.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/core/radar_card.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/core/ui_refresh.dart';
import 'package:campus_radar/schedule/timetable_share.dart';

const serverlessPluginUrl =
    'https://chatgpt.com/plugins/plugins_6ae725ec935c8191903961d3fe1a1868';

class AcademicExportPage extends StatefulWidget {
  const AcademicExportPage({super.key});
  @override
  State<AcademicExportPage> createState() => _ExportState();
}

class _ExportState extends State<AcademicExportPage> {
  bool consent = false, busy = false;
  String? error, saved;
  AcademicExport? bundle;
  String? bundleEpoch;
  bool includeLinks = true,
      includeCachedText = false,
      markdown = false,
      checking = false;
  int checked = 0;
  List<StudyMaterial> attachmentRows = [];
  final selectedOriginals = <String>{};
  String? attachmentEpoch;
  Future<void> loadAttachments() async {
    Store? s;
    try {
      s = await Store.open();
      final scope = await SessionScope.capture(s);
      final rows = (await studyMaterials(
        s,
      )).where((m) => m.media != null).toList();
      await scope.verify();
      if (mounted) {
        setState(() {
          attachmentRows = rows;
          attachmentEpoch = scope.epoch;
          selectedOriginals.clear();
          bundle = null;
        });
      }
    } catch (_) {
      if (mounted) setState(() => error = '첨부 목록을 읽지 못했어요. 다시 시도해 주세요.');
    } finally {
      await s?.db.close();
    }
  }

  Future<void> checkLinks() async {
    if (checking || busy || !consent) return;
    setState(() {
      checking = true;
      checked = 0;
      bundle = null;
    });
    Store? s;
    try {
      s = await Store.open();
      final scope = await SessionScope.capture(s);
      final materials = (await studyMaterials(
        s,
      )).where((m) => m.media != null).take(30).toList();
      final checks = <String, dynamic>{};
      for (final m in materials) {
        if (!mounted) break;
        final result = await probeAnonymousAttachment(m.media!);
        await scope.verify();
        checks[m.id] = result;
        if (mounted) setState(() => checked++);
      }
      await scope.verify();
      await s.setMeta(MetaKey.academicLinkChecks, jsonEncode(checks));
      if (mounted) {
        setState(
          () => saved = '링크 $checked개를 확인했어요. 파일 전체나 AI 도구 읽기를 확인한 결과는 아니에요.',
        );
      }
    } catch (_) {
      if (mounted) setState(() => error = '링크 확인을 마치지 못했어요. 기존 자료는 유지했어요.');
    } finally {
      await s?.db.close();
      if (mounted) setState(() => checking = false);
    }
  }

  Future<void> prepare() async {
    setState(() {
      busy = true;
      error = null;
      bundle = null;
      saved = null;
    });
    Store? s;
    try {
      s = await Store.open();
      final scope = await SessionScope.capture(s);
      var id = await s.meta(MetaKey.academicExportProfile);
      if (id == null) {
        id = newShareId();
        await s.setMeta(MetaKey.academicExportProfile, id);
      }
      final texts = <String, AttachmentText>{},
          originals = <String, List<int>>{};
      final warnings = <String>[];
      if (includeCachedText || selectedOriginals.isNotEmpty) {
        if (selectedOriginals.isNotEmpty && attachmentEpoch != scope.epoch) {
          throw SessionChanged();
        }
        if (scope.account == null) {
          throw const FormatException('먼저 계정을 연결해 주세요.');
        }
        final cache = await MediaCache.open(scope.account!);
        var extracted = 0, totalOriginal = 0;
        final extractedFiles = <String, AttachmentText>{};
        for (final m in (await studyMaterials(
          s,
        )).where((m) => m.media != null)) {
          final local = await cache.local(m.media!);
          if (local == null) {
            if (selectedOriginals.contains(m.id)) {
              warnings.add('${m.name}: 기기에 저장된 원본이 없어 포함하지 못했어요.');
            }
            continue;
          }
          if (includeCachedText && extractedFiles.containsKey(local.path)) {
            texts[m.id] = extractedFiles[local.path]!;
          } else if (includeCachedText && extracted < 10) {
            try {
              texts[m.id] = await extractAttachmentText(local, m.name);
            } catch (_) {
              texts[m.id] = const AttachmentText('', '기기에서 추출 실패 · 원본 확인 필요');
            }
            extractedFiles[local.path] = texts[m.id]!;
            extracted++;
          }
          if (selectedOriginals.contains(m.id)) {
            final length = await local.length();
            if (length > 10 * 1024 * 1024 ||
                totalOriginal + length > 20 * 1024 * 1024) {
              throw const FormatException('선택 원본은 파일당 10MB, 합계 20MB까지예요.');
            }
            final ext = m.name.split('.').last.toLowerCase();
            if (!RegExp(r'^[a-z0-9]{1,8}$').hasMatch(ext)) {
              throw const FormatException('확장자를 확인할 수 없는 원본이에요.');
            }
            originals['원본/${m.id.substring(0, 16)}.$ext'] = await local
                .readAsBytes();
            totalOriginal += length;
          }
          await cache.verifySession();
          await scope.verify();
        }
        if (includeCachedText) {
          warnings.add(
            '기기에 저장된 첨부 중 최대 10개만 텍스트 추출해요. 추출 실패/그림/표/누락 범위를 첨부 인덱스에서 확인하세요.',
          );
        }
      }
      Map<String, Map<String, dynamic>> checks = {};
      try {
        checks =
            (jsonDecode(await s.meta(MetaKey.academicLinkChecks) ?? '{}')
                    as Map)
                .map(
                  (k, v) => MapEntry('$k', Map<String, dynamic>.from(v as Map)),
                );
      } catch (_) {
        warnings.add('저장된 링크 검사 결과를 읽지 못했어요.');
      }
      final result = await buildAcademicExport(
        s,
        id,
        includeLinks: includeLinks,
        markdown: markdown,
        linkChecks: checks,
        attachmentTexts: texts,
        originals: originals,
        attachmentWarnings: warnings,
      );
      await scope.verify();
      if (mounted) {
        setState(() {
          bundle = result;
          bundleEpoch = scope.epoch;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(
          () => error = e is FormatException
              ? e.message
              : '자료를 준비하지 못했어요. 기존 파일은 변경하지 않았어요.',
        );
      }
    } finally {
      await s?.db.close();
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> share() async {
    final data = bundle;
    if (data == null || busy) return;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final check = await Store.open();
      try {
        final scope = await SessionScope.capture(check);
        if (scope.epoch != bundleEpoch ||
            await check.meta(MetaKey.academicExportProfile) != data.profileId) {
          throw SessionChanged();
        }
      } finally {
        await check.db.close();
      }
      final folder = Directory(
        '${(await getTemporaryDirectory()).path}/academic-export',
      );
      await folder.create(recursive: true);
      final file = File('${folder.path}/campus-radar-academic.zip');
      await file.writeAsBytes(data.zip(), flush: true);
      if (Platform.isAndroid || Platform.isIOS) {
        await bridge.invokeNative(NativeMethod.shareAcademicExport, {
          'path': file.path,
        });
        if (mounted) {
          setState(() => saved = '공유 창을 열었어요. 전송 완료 여부는 선택한 앱에서 확인해 주세요.');
        }
      } else {
        if (mounted) setState(() => saved = 'ZIP 저장 위치: ${file.path}');
      }
    } catch (_) {
      if (mounted) setState(() => error = '파일 공유 창을 열지 못했어요. 다시 시도해 주세요.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('AI 도우미용 자료 내보내기')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        RadarCard(
          margin: const EdgeInsets.only(bottom: 14),
          padding: const EdgeInsets.all(16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const RadarIconBox(icon: Icons.folder_zip_outlined),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '내 과목 자료를 문서나 ZIP으로 만들어 다른 AI 앱에 넣을 수 있어요. 로그인 없이 돼요.',
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '내 저장소에서 AI 도우미와 연결',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '캠퍼스레이더 전용 서버 없이 Google Drive 등 내가 고른 저장소에 자료를 두고 ChatGPT·Claude 같은 AI 앱이 읽게 해요.',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        RadarGroupCard(
          margin: const EdgeInsets.only(bottom: 12),
          children: [
            SwitchListTile(
              title: const Text('저장된 첨부에서 텍스트 추출'),
              subtitle: const Text(
                '로그인 없이 기기에 저장된 파일(최대 10개 · TXT/HWPX/PPTX/DOCX, PDF는 Android 15 이상)에서 글자만 꺼내요. 그림·표 배치는 빠질 수 있어요.',
              ),
              value: includeCachedText,
              onChanged: busy || checking
                  ? null
                  : (v) => setState(() {
                      includeCachedText = v;
                      bundle = null;
                    }),
            ),
            SwitchListTile(
              title: const Text('문서(.md)로 만들기'),
              subtitle: const Text('로그인 없이 바로 쓰기 좋은 문서(.md) 형식으로 만들어요'),
              value: markdown,
              onChanged: busy || checking
                  ? null
                  : (v) => setState(() {
                      markdown = v;
                      bundle = null;
                    }),
            ),
          ],
        ),
        const RadarGroupCard(
          margin: EdgeInsets.only(bottom: 12),
          children: [
            ListTile(
              leading: RadarIconBox(icon: Icons.looks_one_outlined),
              title: Text('학업 자료 묶음 만들기'),
              subtitle: Text(
                '과제·콘텐츠 상태, 공지 제목/본문, 자료 본문·첨부 목록, 저장된 강의계획서, 시간표·휴강을 한데 정리해요.',
              ),
            ),
            ListTile(
              leading: RadarIconBox(icon: Icons.looks_two_outlined),
              title: Text('Drive로 보내기 또는 ZIP 풀기'),
              subtitle: Text(
                '전용 폴더에 압축을 풀고 “캠퍼스레이더 시작.txt”를 포함해 올려 주세요. 새로 올릴 때는 같은 폴더의 이전 파일을 바꿔 주세요.',
              ),
            ),
            ListTile(
              leading: RadarIconBox(icon: Icons.looks_3_outlined),
              title: Text('다른 AI 앱과 연결하기'),
              subtitle: Text(
                'ChatGPT: 캠퍼스레이더 학업 도우미와 ChatGPT용 묶음을 연결해요. Claude: Claude용 묶음(ZIP)을 올리고 Google Drive로 연결해요. 처음에는 시작 문서 위치를 알려 주세요.',
              ),
            ),
          ],
        ),
        OutlinedButton.icon(
          onPressed: () => launchUrl(
            Uri.parse(serverlessPluginUrl),
            mode: LaunchMode.externalApplication,
          ),
          icon: const Icon(Icons.extension_outlined),
          label: const Text('ChatGPT 학업 도우미 열기'),
        ),
        const SizedBox(height: 10),
        const RadarPageIntro(
          '이 화면은 파일을 직접 저장해 꺼내 쓰는 수동 내보내기예요. 자동 올리기는 설정의 Drive 자동 연결에서 별도로 켤 수 있어요. Drive 외에도 문서(.md)나 텍스트를 읽는 다른 AI 앱에서 쓸 수 있고, 링크만으로 AI가 원본을 읽지 못할 수 있어요.',
        ),
        RadarGroupCard(
          margin: const EdgeInsets.only(bottom: 12),
          children: [
            CheckboxListTile(
              value: consent,
              onChanged: busy || checking
                  ? null
                  : (v) => setState(() {
                      consent = v == true;
                      if (!consent) bundle = null;
                    }),
              title: const Text('내보낼 학업 자료의 범위를 확인했어요'),
              subtitle: const Text(
                '원문 주소와 본문에 개인정보가 있을 수 있어요. 미리보기 후 비공개 폴더에 보관하세요. 계정·쿠키·키·점수표·개인 일정·친구 시간표는 제외해요.',
              ),
            ),
            SwitchListTile(
              title: const Text('학교 원본 링크 포함'),
              subtitle: const Text(
                '직접 파일 주소만 포함해요. 주소에 학번 등 식별자가 들어갈 수 있으니 비공개로 보관하세요.',
              ),
              value: includeLinks,
              onChanged: busy || checking
                  ? null
                  : (v) => setState(() {
                      includeLinks = v;
                      bundle = null;
                    }),
            ),
          ],
        ),
        if (isDeveloperMode) ...[
          OutlinedButton(
            onPressed: consent && !busy && !checking ? checkLinks : null,
            child: Text(
              checking ? '링크 확인 중 · $checked개' : '세션 없이 링크 접근 확인 · 최대 30개',
            ),
          ),
          const SizedBox(height: 10),
        ],
        RadarExpansionCard(
          leading: const RadarIconBox(icon: Icons.attach_file_outlined),
          title: const Text('원본을 선택해서 포함 · 최대 5개'),
          subtitle: const Text('기기에 저장된 파일만 · 파일당 10MB/합계 20MB'),
          onExpansionChanged: (open) {
            if (open && attachmentRows.isEmpty) loadAttachments();
          },
          childrenPadding: const EdgeInsets.only(bottom: 8),
          children: [
            if (attachmentRows.isEmpty)
              const ListTile(title: Text('첨부가 없거나 목록을 불러오는 중이에요.')),
            for (final m in attachmentRows)
              CheckboxListTile(
                title: Text(m.name),
                subtitle: Text('${m.course} · ${m.title}'),
                value: selectedOriginals.contains(m.id),
                onChanged: busy || checking
                    ? null
                    : (v) => setState(() {
                        if (v == true) {
                          if (selectedOriginals.length >= 5) {
                            error = '원본은 최대 5개까지 선택해 주세요.';
                            return;
                          }
                          selectedOriginals.add(m.id);
                        } else {
                          selectedOriginals.remove(m.id);
                        }
                        bundle = null;
                      }),
              ),
          ],
        ),
        const SizedBox(height: 4),
        FilledButton.icon(
          onPressed: consent && !busy && !checking ? prepare : null,
          icon: const Icon(Icons.inventory_2_outlined),
          label: Text(busy ? '준비 중…' : '자료 만들고 미리보기'),
        ),
        if (error != null) ...[
          const SizedBox(height: 8),
          Text(
            error!,
            style: TextStyle(color: Theme.of(context).colorScheme.error),
          ),
        ],
        if (bundle != null) ...[
          const SizedBox(height: 14),
          SectionHeading(
            '문서 ${bundle!.documents.length}개 · 선택 원본 ${bundle!.originals.length}개',
          ),
          const SizedBox(height: 8),
          RadarGroupCard(
            margin: const EdgeInsets.only(bottom: 12),
            children: [
              for (final doc in bundle!.documents.entries)
                ListTile(
                  leading: const RadarIconBox(icon: Icons.description_outlined),
                  title: Text(doc.key),
                  subtitle: Text('${doc.value.length}자'),
                  trailing: const Icon(Icons.preview_outlined),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute<void>(
                      builder: (_) => Scaffold(
                        appBar: AppBar(title: Text(doc.key)),
                        body: SingleChildScrollView(
                          padding: const EdgeInsets.all(20),
                          child: SelectableText(doc.value),
                        ),
                      ),
                    ),
                  ),
                ),
              for (final e in bundle!.originals.entries)
                ListTile(
                  leading: const RadarIconBox(icon: Icons.attach_file),
                  title: Text(e.key),
                  subtitle: Text('${e.value.length}바이트 · ZIP에 원본 포함'),
                ),
            ],
          ),
          FilledButton.icon(
            onPressed: busy ? null : share,
            icon: const Icon(Icons.ios_share),
            label: const Text('ZIP 파일 공유·저장'),
          ),
          const SizedBox(height: 8),
          OutlinedButton(
            onPressed: () => Clipboard.setData(
              const ClipboardData(
                text:
                    '내 저장소의 캠퍼스레이더 시작.txt를 먼저 읽고 내 수업·과제·시간표 질문에 답해 줘. 자료 수집 시각도 확인해 줘.',
              ),
            ),
            child: const Text('GPT 첫 연결 안내문 복사'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () async {
              await Clipboard.setData(
                const ClipboardData(
                  text:
                      '내 Google Drive에서 CAMPUS_RADAR_START_V1 표식이 있는 캠퍼스레이더 시작 문서를 먼저 읽고 내 수업·과제·시간표 질문에 답해 줘. 실제 수집 시각과 출처를 확인하고 읽지 못한 자료를 추측하지 마.',
                ),
              );
              if (mounted) setState(() => saved = 'Claude용 안내문을 복사했어요.');
            },
            icon: const Icon(Icons.copy),
            label: const Text('Claude 첫 연결 안내문 복사'),
          ),
        ],
        if (saved != null) ...[
          const SizedBox(height: 8),
          SelectableText(saved!),
        ],
      ],
    ),
  );
}

import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/demo_state.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:campus_radar/campus/media_cache.dart';
import 'package:campus_radar/campus/campus_session.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/adaptive_content.dart';
import 'package:campus_radar/campus/material_catalog.dart';
import 'package:campus_radar/courses/media_widgets.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/courses/course_list_card.dart';

class MaterialsPage extends StatefulWidget {
  final String? course;
  final bool embedded, active;
  const MaterialsPage({
    super.key,
    this.course,
    this.embedded = false,
    this.active = true,
  });
  @override
  State<MaterialsPage> createState() => _MaterialsPageState();
}

class _MaterialsPageState extends State<MaterialsPage> {
  List<StudyMaterial> rows = [];
  final savedStates = <String, String>{};
  String query = '', kind = '', sortMode = 'title';
  bool loading = true, started = false, sortDescending = false;
  String? error;
  @override
  void initState() {
    super.initState();
    if (widget.active) load();
  }

  @override
  void didUpdateWidget(MaterialsPage old) {
    super.didUpdateWidget(old);
    if (widget.active && !started) load();
  }

  Future<void> load() async {
    started = true;
    Store? s;
    try {
      s = await Store.open();
      final data = mergedStudyMaterials(await studyMaterials(s));
      if (mounted) {
        setState(() {
          rows = data;
          loading = false;
          error = null;
        });
      }
      if (!isDemoActive) {
        try {
          final viewer = await pcDriveMode();
          final account = viewer
              ? 'drive-viewer'
              : await credentials.read(key: 'id');
          if (account != null) {
            final cache = viewer
                ? await MediaCache.openViewer()
                : await MediaCache.open(account);
            for (final m in data.where((m) => m.media != null)) {
              savedStates[m.id] = await cache.status(m.media!);
            }
          }
        } catch (_) {
          for (final m in data.where((m) => m.media != null)) {
            savedStates[m.id] = '저장 상태 확인 불가';
          }
        }
      }
      if (mounted) {
        setState(() {
          rows = data;
          error = null;
        });
      }
    } catch (_) {
      if (mounted) setState(() => error = '자료 목록을 읽지 못했어요.');
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      final prefSortMode = prefs.getString('materialsSortMode');
      final prefSortDesc = prefs.getBool('materialsSortDescending');
      if (mounted) {
        setState(() {
          if (prefSortMode != null) sortMode = prefSortMode;
          if (prefSortDesc != null) sortDescending = prefSortDesc;
        });
      }
    } finally {
      await s?.db.close();
      if (mounted) setState(() => loading = false);
    }
  }

  Widget materialTile(StudyMaterial m) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final ext = (m.media != null && m.media!.name.contains('.'))
        ? m.media!.name.split('.').last.toLowerCase()
        : '';

    Color badgeColor;
    IconData badgeIcon;
    String badgeLabel;

    if (m.media == null && m.externalUrl.isNotEmpty) {
      badgeColor = const Color(0xff00897b);
      badgeIcon = Icons.link_rounded;
      badgeLabel = '링크';
    } else if (ext == 'pdf') {
      badgeColor = const Color(0xffd32f2f);
      badgeIcon = Icons.picture_as_pdf_rounded;
      badgeLabel = 'PDF';
    } else if (ext == 'ppt' || ext == 'pptx') {
      badgeColor = const Color(0xffe65100);
      badgeIcon = Icons.slideshow_rounded;
      badgeLabel = 'PPT';
    } else if (ext == 'hwp' || ext == 'hwpx') {
      badgeColor = const Color(0xff1976d2);
      badgeIcon = Icons.description_rounded;
      badgeLabel = '한글';
    } else if (ext == 'doc' || ext == 'docx') {
      badgeColor = const Color(0xff283593);
      badgeIcon = Icons.article_rounded;
      badgeLabel = 'DOC';
    } else if (ext == 'zip') {
      badgeColor = const Color(0xfff57c00);
      badgeIcon = Icons.folder_zip_rounded;
      badgeLabel = 'ZIP';
    } else if (m.media != null) {
      badgeColor = colorScheme.secondary;
      badgeIcon = Icons.insert_drive_file_rounded;
      badgeLabel = ext.isEmpty ? '파일' : ext.toUpperCase();
    } else {
      badgeColor = colorScheme.primary;
      badgeIcon = Icons.notes_rounded;
      badgeLabel = '본문';
    }

    final isSaved = savedStates[m.id] == '기기 저장됨';
    final stateText = savedStates[m.id];
    final copyUrl = (m.media?.url ?? '').isNotEmpty
        ? m.media!.url
        : m.externalUrl.isNotEmpty
        ? m.externalUrl
        : 'https://dcs-learning.cnu.ac.kr/home';

    return CourseListCard(
      icon: badgeIcon,
      color: badgeColor,
      badgeLabel: badgeLabel,
      title: m.title.isEmpty ? m.name : m.title,
      trailing: copyUrl.isEmpty
          ? null
          : Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.copy, size: 18),
                  tooltip: '링크 복사',
                  visualDensity: VisualDensity.compact,
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: copyUrl));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('자료 링크를 복사했어요.')),
                    );
                  },
                ),
                Icon(
                  Icons.arrow_forward_ios_rounded,
                  size: 13,
                  color: colorScheme.outlineVariant,
                ),
              ],
            ),
      onLongPress: copyUrl.isEmpty
          ? null
          : () {
              Clipboard.setData(ClipboardData(text: copyUrl));
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('자료 링크를 복사했어요.')),
              );
            },
      details: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6.5, vertical: 2),
              decoration: BoxDecoration(
                color: colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(5),
              ),
              child: Text(
                courseLabel(m.course),
                style: theme.textTheme.labelSmall?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                  fontSize: 10.5,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(width: 6),
            if (m.media != null)
              Expanded(
                child: Text(
                  m.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: colorScheme.onSurfaceVariant,
                    fontSize: 11.5,
                  ),
                ),
              ),
            if (isSaved) ...[
              const SizedBox(width: 4),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 6,
                  vertical: 1.5,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xff2e7d32).withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(5),
                ),
                child: const Text(
                  '저장됨',
                  style: TextStyle(
                    color: Color(0xff2e7d32),
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ] else if (stateText != null && stateText.isNotEmpty) ...[
              const SizedBox(width: 4),
              Text(
                stateText,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: colorScheme.outline,
                  fontSize: 10.5,
                ),
              ),
            ],
          ],
        ),
      ],
      onTap: () async {
        await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (detailContext) => Scaffold(
              appBar: AppBar(
                title: Text(m.name),
                actions: [
                  IconButton(
                    icon: const Icon(Icons.copy),
                    tooltip: '링크 복사',
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: copyUrl));
                      ScaffoldMessenger.of(detailContext).showSnackBar(
                        const SnackBar(content: Text('자료 링크를 복사했어요.')),
                      );
                    },
                  ),
                ],
              ),
              body: ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  Text('${courseLabel(m.course)} · ${m.title}'),
                  if (m.externalUrl.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 8, bottom: 8),
                      child: FilledButton.icon(
                        onPressed: () => launchUrl(
                          Uri.parse(m.externalUrl),
                          mode: LaunchMode.externalApplication,
                        ),
                        icon: const Icon(Icons.open_in_new),
                        label: const Text('외부 링크 열기'),
                      ),
                    ),
                  if (m.media != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 8, bottom: 8),
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          if (isDemoActive) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text(demoMediaMessage)),
                            );
                            return;
                          }
                          if (m.media!.form.isNotEmpty) {
                            if (mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text(
                                    '암호화 전송 자료예요. 기기 저장본 또는 Google Drive "캠퍼스레이더/자료/과목" 폴더에서 확인해 주세요.',
                                  ),
                                ),
                              );
                            }
                            return;
                          }
                          final u = Uri.tryParse(m.media!.url);
                          if (u != null) {
                            await launchUrl(
                              u,
                              mode: LaunchMode.externalApplication,
                            );
                          }
                        },
                        icon: Icon(
                          m.media!.form.isNotEmpty
                              ? Icons.lock_outline
                              : Icons.open_in_browser,
                        ),
                        label: Text(
                          m.media!.form.isNotEmpty
                              ? '${m.media!.name} (암호화 원본 안내)'
                              : '${m.media!.name} 학교 원본 열기',
                        ),
                      ),
                    ),
                  CampusBodyView(
                    body: m.body,
                    bodyHtml: '',
                    media: m.media == null ? const [] : [m.media!],
                  ),
                ],
              ),
            ),
          ),
        );
        if (mounted) await load();
      },
    );
  }

  Future<void> _onRefreshPressed() async {
    await load();
    if (!mounted) return;
    if (isDemoActive) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            isAgentSimulation
                ? '새로 확인했어요 · 바뀐 항목이 없어요.'
                : '체험 모드에서는 학교에서 새로 받지 않아요.',
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.active) return const SizedBox.shrink();
    final list = rows
        .where(
          (m) =>
              (widget.course == null || m.course == widget.course) &&
              (kind.isEmpty || m.sourceType == kind) &&
              '${m.name} ${m.title} ${m.course} ${courseLabel(m.course)}'
                  .toLowerCase()
                  .contains(query.toLowerCase()),
        )
        .toList();
    list.sort((a, b) {
      if (sortMode == 'date') {
        final aDate = a.date ?? DateTime.utc(2000);
        final bDate = b.date ?? DateTime.utc(2000);
        final c = bDate.compareTo(aDate);
        if (c != 0) return sortDescending ? -c : c;
      }
      if (widget.course == null) {
        final c = a.course.compareTo(b.course);
        if (c != 0) return c;
      }
      final t = naturalCompare(a.title, b.title);
      if (t != 0) return sortDescending ? -t : t;
      final n = naturalCompare(a.name, b.name);
      return sortDescending ? -n : n;
    });
    final content = AdaptiveContent(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          if (widget.embedded)
            Row(
              children: [
                const Expanded(child: Text('공지·과제·콘텐츠·자료실 자료')),
                IconButton(
                  tooltip: '지금 확인',
                  onPressed: _onRefreshPressed,
                  icon: const Icon(Icons.refresh),
                ),
              ],
            ),
          TextField(
            decoration: const InputDecoration(
              labelText: '파일·제목·과목 검색',
              prefixIcon: Icon(Icons.search),
            ),
            onChanged: (v) => setState(() => query = v),
          ),
          Wrap(
            spacing: 8,
            children: [
              for (final e in const {
                '': '전체',
                'LS': '자료실',
                'NT': '공지',
                'LV': '콘텐츠',
                'LR': '과제',
              }.entries)
                ChoiceChip(
                  label: Text(e.value),
                  selected: kind == e.key,
                  onSelected: (_) => setState(() => kind = e.key),
                ),
            ],
          ),
          if (loading) const LinearProgressIndicator(),
          if (error != null) Text(error!),
          Row(
            children: [
              Expanded(
                child: Text(
                  '${list.length}개 · ${sortMode == "date" ? "게시일순" : "주차순"}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ),
              PopupMenuButton<String>(
                tooltip: '정렬 기준',
                initialValue: sortMode,
                onSelected: (v) async {
                  setState(() => sortMode = v);
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setString('materialsSortMode', v);
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 6,
                    vertical: 4,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.sort, size: 18),
                      const SizedBox(width: 4),
                      Text(
                        sortMode == 'date' ? '게시일순' : '주차순',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                itemBuilder: (context) => const [
                  PopupMenuItem(value: 'title', child: Text('주차/이름순')),
                  PopupMenuItem(value: 'date', child: Text('게시일순 (최신 등록 우선)')),
                ],
              ),
              IconButton(
                tooltip: sortMode == 'date'
                    ? (sortDescending ? '과거순 (오래된 자료 먼저)' : '최신순 (최근 자료 먼저)')
                    : (sortDescending ? '내림차순 (최신주차 먼저)' : '오름차순 (1주차부터)'),
                onPressed: () async {
                  setState(() => sortDescending = !sortDescending);
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setBool(
                    'materialsSortDescending',
                    sortDescending,
                  );
                },
                icon: Icon(
                  sortMode == 'date'
                      ? (sortDescending
                            ? Icons.arrow_upward
                            : Icons.arrow_downward)
                      : (sortDescending
                            ? Icons.arrow_downward
                            : Icons.arrow_upward),
                  size: 20,
                ),
              ),
            ],
          ),
          for (final m in list) materialTile(m),
          if (!loading && list.isEmpty)
            const Text(
              '현재 조건에 해당하는 자료가 없어요. 본문·첨부가 아직 수집되지 않았다면 학교 수집 또는 해당 상세 화면에서 확인해 주세요.',
            ),
        ],
      ),
    );
    if (widget.embedded) return content;
    return Scaffold(
      appBar: AppBar(
        title: const Text('자료 모아보기'),
        actions: [
          IconButton(
            tooltip: '지금 확인',
            onPressed: _onRefreshPressed,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: content,
    );
  }
}

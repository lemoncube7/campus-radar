import 'package:campus_radar/core/storage_keys.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:flutter/material.dart';

const courseAccentColors = [
  Color(0xff4566b0),
  Color(0xff2a8d80),
  Color(0xffc36b43),
  Color(0xff8f62b5),
  Color(0xff3e84b8),
  Color(0xffb55880),
];
const coursePickerColors = [
  ...courseAccentColors,
  Color(0xffb52b44),
  Color(0xff7a792c),
  Color(0xff64748b),
  Color(0xffb9811c),
  Color(0xff267aaf),
  Color(0xff7353a6),
];
final courseColorOverrides = <String, int>{};
Future<void> loadCourseColors() async {
  final prefs = await SharedPreferences.getInstance();
  final raw = prefs.getString(PrefKey.courseColorOverrides);
  if (raw == null) {
    courseColorOverrides.clear();
    return;
  }
  try {
    final data = jsonDecode(raw) as Map;
    courseColorOverrides
      ..clear()
      ..addAll({
        for (final e in data.entries)
          if (e.value is int) '${e.key}': e.value as int,
      });
  } catch (_) {
    /* retain last good colors */
  }
}

Future<void> saveCourseColor(String key, Color? color) async {
  final next = Map<String, int>.from(courseColorOverrides);
  if (color == null) {
    next.remove(key);
  } else {
    next[key] = color.toARGB32();
  }
  final prefs = await SharedPreferences.getInstance();
  if (!await prefs.setString(PrefKey.courseColorOverrides, jsonEncode(next))) {
    throw StateError('색상을 저장하지 못했어요.');
  }
  courseColorOverrides
    ..clear()
    ..addAll(next);
}

Color courseAccent(String key) {
  if (courseColorOverrides.containsKey(key)) {
    return Color(courseColorOverrides[key]!);
  }
  var value = 0;
  for (final unit in key.codeUnits) {
    value = (31 * value + unit) & 0x7fffffff;
  }
  return courseAccentColors[value % courseAccentColors.length];
}

/// Screen readers say a plain color word instead of a hex code.
String spokenColorName(Color c) {
  final hsv = HSVColor.fromColor(c);
  if (hsv.saturation < 0.35) return '회색';
  final h = hsv.hue;
  if (h < 15 || h >= 340) return '빨강';
  if (h < 30) return '주황';
  if (h < 45) return '황금색';
  if (h < 70) return hsv.value < 0.6 ? '올리브' : '노랑';
  if (h < 160) return '초록';
  if (h < 195) return '청록';
  if (h < 215) return hsv.saturation < 0.72 ? '하늘색' : '파랑';
  if (h < 230) return '진한 파랑';
  if (h < 255) return '남색';
  if (h < 300) return h < 270 || hsv.value < 0.68 ? '진한 보라' : '보라';
  return '분홍';
}

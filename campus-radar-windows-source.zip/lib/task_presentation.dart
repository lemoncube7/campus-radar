import 'course_labels.dart';
import 'campus_models.dart';
import 'course_colors.dart';
import 'package:flutter/material.dart';

class DesktopTaskPreview extends StatelessWidget {
  final CampusItem item;
  final VoidCallback close, open;
  const DesktopTaskPreview({
    super.key,
    required this.item,
    required this.close,
    required this.open,
  });
  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.fromLTRB(0, 16, 16, 16),
    child: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  courseLabel(item.course),
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ),
              IconButton(
                tooltip: '선택 닫기',
                onPressed: close,
                icon: const Icon(Icons.close),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(item.title, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          Text(item.due == null ? '마감 미확인' : koreanTime(item.due!)),
          Text(
            '${remainingText(item)} · ${statusText(item)}',
            style: TextStyle(color: deadlineColor(item, context)),
          ),
          const Divider(height: 32),
          Expanded(
            child: SingleChildScrollView(
              child: SelectableText(
                item.body.isEmpty
                    ? '상세 화면에서 원문을 불러와 확인할 수 있습니다.'
                    : textOf(item.body),
              ),
            ),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: open,
            icon: const Icon(Icons.open_in_new),
            label: const Text('상세 내용·강의실 바로가기'),
          ),
        ],
      ),
    ),
  );
}

class RadarTaskCard extends StatelessWidget {
  final CampusItem item;
  final bool excluded;
  final VoidCallback onTap;
  final VoidCallback? onVisibilityToggle;
  const RadarTaskCard({
    super.key,
    required this.item,
    this.excluded = false,
    required this.onTap,
    this.onVisibilityToggle,
  });
  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final accent = deadlineColor(item, context);
    final courseColor = courseAccent('${item.courseId}:${item.classNo}');
    final urgent =
        deadlineState(item.due) == DeadlineState.withinDay ||
        deadlineState(item.due) == DeadlineState.overdue;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: IntrinsicHeight(
          child: Row(
            children: [
              Container(
                width: 4,
                color: urgent && !item.done
                    ? accent
                    : colors.primary.withValues(alpha: .3),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Wrap(
                        spacing: 10,
                        runSpacing: 6,
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 3,
                            ),
                            decoration: BoxDecoration(
                              color: courseColor.withValues(alpha: .12),
                              borderRadius: BorderRadius.circular(7),
                            ),
                            child: Text(
                              courseLabel(item.course),
                              style: TextStyle(
                                color:
                                    Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Color.lerp(courseColor, Colors.white, .45)
                                    : courseColor,
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          Text(
                            remainingText(item),
                            style: TextStyle(
                              color: urgent ? accent : colors.onSurfaceVariant,
                              fontSize: 12,
                              fontWeight: urgent
                                  ? FontWeight.w700
                                  : FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 9),
                      Text(
                        item.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.titleMedium
                            ?.copyWith(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 7),
                      Text(
                        '${item.type == 'LR' ? '과제' : '콘텐츠'} · ${item.due == null ? '마감 미확인' : formatDate(item.due!)}',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: colors.onSurfaceVariant,
                        ),
                      ),
                      if (excluded || item.done || item.status == 'unknown')
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(
                            excluded ? '목록에서 제외됨' : statusText(item),
                            style: TextStyle(color: accent, fontSize: 12),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
              if (onVisibilityToggle != null)
                PopupMenuButton<String>(
                  tooltip: '항목 메뉴',
                  onSelected: (_) => onVisibilityToggle?.call(),
                  itemBuilder: (_) => [
                    PopupMenuItem(
                      value: 'visibility',
                      child: Text(excluded ? '목록에 복구' : '목록에서 숨기기'),
                    ),
                  ],
                )
              else
                Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: Icon(
                    Icons.chevron_right,
                    size: 20,
                    color: colors.onSurfaceVariant,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

String formatDate(DateTime date) {
  final d = date.toUtc().add(const Duration(hours: 9));
  return '${d.month}/${d.day} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')} (한국 시간)';
}

String statusText(CampusItem i) => i.status == 'unknown'
    ? '상태 확인 불가'
    : i.done
    ? (i.type == 'LR' ? '제출 완료' : '완료')
    : (i.type == 'LR' ? '미제출' : '미완료');

String deadlineLabel(CampusItem item) {
  if (item.done) return '완료';
  return switch (deadlineState(item.due)) {
    DeadlineState.overdue => '기한 지남',
    DeadlineState.withinDay => '1일 이내 남음',
    DeadlineState.remaining => '아직 남음',
    DeadlineState.unknown => '기한 미확인',
  };
}

Color deadlineColor(CampusItem item, [BuildContext? context]) {
  if (context != null && Theme.of(context).brightness == Brightness.dark) {
    if (item.done) return const Color(0xff8fd4b5);
    return switch (deadlineState(item.due)) {
      DeadlineState.overdue => const Color(0xffffa8a0),
      DeadlineState.withinDay => const Color(0xffffc080),
      DeadlineState.remaining => const Color(0xff91cbc5),
      DeadlineState.unknown => const Color(0xffb9c7ca),
    };
  }
  if (item.done) return Colors.green.shade800;
  return switch (deadlineState(item.due)) {
    DeadlineState.overdue => Colors.red.shade800,
    DeadlineState.withinDay => Colors.orange.shade900,
    DeadlineState.remaining => Colors.blue.shade800,
    DeadlineState.unknown => Colors.grey.shade700,
  };
}

Color deadlineBackground(CampusItem item, [BuildContext? context]) {
  if (context != null) return Theme.of(context).colorScheme.surface;
  if (item.done) return Colors.green.shade50;
  return switch (deadlineState(item.due)) {
    DeadlineState.overdue => Colors.red.shade50,
    DeadlineState.withinDay => Colors.orange.shade50,
    DeadlineState.remaining => Colors.blue.shade50,
    DeadlineState.unknown => Colors.grey.shade100,
  };
}

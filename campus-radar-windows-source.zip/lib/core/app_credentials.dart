import 'package:campus_radar/core/demo_state.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

const _secureStorage = FlutterSecureStorage(
  // v10 ignores encryptedSharedPreferences and migrates its data on first access.
  aOptions: AndroidOptions(),
  iOptions: IOSOptions(
    accessibility: KeychainAccessibility.first_unlock_this_device,
  ),
);

/// Blocks all reads/writes/deletes to real OS secure storage while demo mode
/// is active, except the Gemini key in agent simulation, which goes to its
/// own entry.
String? _simKey(String key) =>
    isAgentSimulation && key == 'geminiApiKey' ? agentSimGeminiKey : null;

class AppCredentials {
  const AppCredentials();

  Future<String?> read({required String key}) async {
    if (isDemoActive) {
      final sim = _simKey(key);
      return sim == null ? null : _secureStorage.read(key: sim);
    }
    return _secureStorage.read(key: key);
  }

  Future<void> write({required String key, required String? value}) async {
    if (isDemoActive) {
      final sim = _simKey(key);
      if (sim != null) await _secureStorage.write(key: sim, value: value);
      return;
    }
    return _secureStorage.write(key: key, value: value);
  }

  Future<void> delete({required String key}) async {
    if (isDemoActive) {
      final sim = _simKey(key);
      if (sim != null) await _secureStorage.delete(key: sim);
      return;
    }
    return _secureStorage.delete(key: key);
  }

  Future<void> deleteAll() async {
    if (isDemoActive) return;
    return _secureStorage.deleteAll();
  }

  /// Drops the agent-simulation key; called when demo mode ends.
  Future<void> clearAgentSimKey() =>
      _secureStorage.delete(key: agentSimGeminiKey);

  Future<Map<String, String>> readAll() async {
    if (isDemoActive) return const <String, String>{};
    return _secureStorage.readAll();
  }
}

const credentials = AppCredentials();

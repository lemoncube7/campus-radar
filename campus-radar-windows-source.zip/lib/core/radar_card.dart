import 'package:flutter/material.dart';

/// Rounded tinted icon container used across modern Campus Radar cards and rows.
class RadarIconBox extends StatelessWidget {
  final IconData icon;
  final Color? backgroundColor;
  final Color? iconColor;
  final double size;
  final double iconSize;
  final double radius;

  const RadarIconBox({
    super.key,
    required this.icon,
    this.backgroundColor,
    this.iconColor,
    this.size = 40,
    this.iconSize = 20,
    this.radius = 12,
  });

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final fg = iconColor ?? colors.primary;
    final bg = backgroundColor ?? fg.withValues(alpha: 0.12);
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
      ),
      alignment: Alignment.center,
      child: Icon(icon, size: iconSize, color: fg),
    );
  }
}

/// Consistent hairline-bordered surface card matching the New UI style.
class RadarCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final Color? color;
  final Color? borderColor;
  final VoidCallback? onTap;

  const RadarCard({
    super.key,
    required this.child,
    this.padding,
    this.margin,
    this.color,
    this.borderColor,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final inner = padding == null
        ? child
        : Padding(padding: padding!, child: child);
    return Card(
      margin: margin,
      color: color,
      clipBehavior: Clip.antiAlias,
      shape: borderColor == null
          ? null
          : RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: BorderSide(color: borderColor!),
            ),
      child: onTap == null
          ? inner
          : InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: onTap,
              child: inner,
            ),
    );
  }
}

/// Card wrapping a single navigation or info row with an optional icon box.
class RadarSettingTile extends StatelessWidget {
  final IconData? icon;
  final Color? iconColor;
  final Color? iconBackgroundColor;
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;
  final bool isThreeLine;

  const RadarSettingTile({
    super.key,
    this.icon,
    this.iconColor,
    this.iconBackgroundColor,
    required this.title,
    this.subtitle,
    this.trailing,
    this.onTap,
    this.isThreeLine = false,
  });

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    return RadarCard(
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        isThreeLine: isThreeLine,
        leading: icon == null
            ? null
            : RadarIconBox(
                icon: icon!,
                iconColor: iconColor,
                backgroundColor: iconBackgroundColor,
              ),
        title: Text(
          title,
          style: textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
        ),
        subtitle: subtitle == null
            ? null
            : Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Text(
                  subtitle!,
                  style: textTheme.bodySmall?.copyWith(
                    color: colors.onSurfaceVariant,
                  ),
                ),
              ),
        trailing:
            trailing ??
            (onTap == null
                ? null
                : Icon(
                    Icons.chevron_right_rounded,
                    color: colors.onSurfaceVariant,
                  )),
        onTap: onTap,
      ),
    );
  }
}

/// Groups multiple settings rows, switches, or checkboxes into one bordered Card.
class RadarGroupCard extends StatelessWidget {
  final List<Widget> children;
  final EdgeInsetsGeometry? margin;

  const RadarGroupCard({super.key, required this.children, this.margin});

  @override
  Widget build(BuildContext context) {
    final items = <Widget>[];
    for (var i = 0; i < children.length; i++) {
      if (i > 0) {
        items.add(const Divider(height: 1, indent: 16, endIndent: 16));
      }
      items.add(children[i]);
    }
    return RadarCard(
      margin: margin,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: items,
      ),
    );
  }
}

/// ExpansionTile wrapped in a hairline-bordered Card without harsh divider lines.
class RadarExpansionCard extends StatelessWidget {
  final Key? tileKey;
  final Widget title;
  final Widget? subtitle;
  final Widget? leading;
  final bool initiallyExpanded;
  final ValueChanged<bool>? onExpansionChanged;
  final List<Widget> children;
  final EdgeInsetsGeometry childrenPadding;

  const RadarExpansionCard({
    super.key,
    this.tileKey,
    required this.title,
    this.subtitle,
    this.leading,
    this.initiallyExpanded = false,
    this.onExpansionChanged,
    required this.children,
    this.childrenPadding = const EdgeInsets.fromLTRB(16, 0, 16, 16),
  });

  @override
  Widget build(BuildContext context) => RadarCard(
    child: ExpansionTile(
      key: tileKey,
      leading: leading,
      title: title,
      subtitle: subtitle,
      initiallyExpanded: initiallyExpanded,
      onExpansionChanged: onExpansionChanged,
      childrenPadding: childrenPadding,
      expandedCrossAxisAlignment: CrossAxisAlignment.stretch,
      children: children,
    ),
  );
}

/// Compact rounded pill badge used for status tags and counts.
class RadarStatusPill extends StatelessWidget {
  final String label;
  final IconData? icon;
  final Color? backgroundColor;
  final Color? foregroundColor;

  const RadarStatusPill({
    super.key,
    required this.label,
    this.icon,
    this.backgroundColor,
    this.foregroundColor,
  });

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final bg = backgroundColor ?? colors.surfaceContainerHighest;
    final fg = foregroundColor ?? colors.onSurfaceVariant;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 13, color: fg),
            const SizedBox(width: 4),
          ],
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: fg,
            ),
          ),
        ],
      ),
    );
  }
}

/// Muted explanatory lead text at the top of subpages and settings screens.
class RadarPageIntro extends StatelessWidget {
  final String text;
  final EdgeInsetsGeometry padding;

  const RadarPageIntro(
    this.text, {
    super.key,
    this.padding = const EdgeInsets.only(bottom: 12),
  });

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Padding(
      padding: padding,
      child: Text(
        text,
        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
          color: colors.onSurfaceVariant,
        ),
      ),
    );
  }
}

/// Consistent empty-state card with tinted icon box, message, and optional CTA.
class RadarEmptyState extends StatelessWidget {
  final IconData icon;
  final String message;
  final String? detail;
  final Widget? action;

  const RadarEmptyState({
    super.key,
    required this.icon,
    required this.message,
    this.detail,
    this.action,
  });

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    return RadarCard(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          RadarIconBox(icon: icon, size: 48, iconSize: 24, radius: 14),
          const SizedBox(height: 12),
          Text(
            message,
            textAlign: TextAlign.center,
            style: textTheme.bodyMedium?.copyWith(
              color: colors.onSurface,
              fontWeight: FontWeight.w500,
            ),
          ),
          if (detail != null) ...[
            const SizedBox(height: 6),
            Text(
              detail!,
              textAlign: TextAlign.center,
              style: textTheme.bodySmall?.copyWith(
                color: colors.onSurfaceVariant,
              ),
            ),
          ],
          if (action != null) ...[const SizedBox(height: 14), action!],
        ],
      ),
    );
  }
}

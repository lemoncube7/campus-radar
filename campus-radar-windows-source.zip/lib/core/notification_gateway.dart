import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;

final notifications = FlutterLocalNotificationsPlugin();
int notificationId(String key) {
  final b = sha256.convert(utf8.encode(key)).bytes;
  return ((b[0] << 24) | (b[1] << 16) | (b[2] << 8) | b[3]) & 0x7fffffff;
}

/// Notification buttons (Android). Both open the app at a screen; the
/// payload of a tap and the button share one router (openItem).
const taskListAction = AndroidNotificationAction(
  notificationActionTasks,
  '할 일 목록',
  showsUserInterface: true,
  cancelNotification: true,
);
const reviewAction = AndroidNotificationAction(
  notificationActionReview,
  '공지 일정 검토함',
  showsUserInterface: true,
  cancelNotification: true,
);
const applyCancellationAction = AndroidNotificationAction(
  notificationActionApplyCancellation,
  '시간표에 반영',
  showsUserInterface: true,
  cancelNotification: true,
);
const notificationActionTasks = 'open_tasks';
const notificationActionReview = 'open_review';
const notificationActionApplyCancellation = 'apply_cancellation';

/// Where a notification response should go: a button wins over the
/// notification's own payload.
String? notificationTarget(String? actionId, String? payload) =>
    switch (actionId) {
      notificationActionTasks => '_tasks',
      notificationActionReview => '_review',
      notificationActionApplyCancellation => payload,
      _ => payload,
    };

const noticeStyle = NotificationDetails(
  windows: WindowsNotificationDetails(),
  iOS: DarwinNotificationDetails(),
  android: AndroidNotificationDetails(
    'assignments',
    '과제·콘텐츠 알림',
    channelDescription: '새 과제와 마감 하루 전 알림',
    importance: Importance.high,
    priority: Priority.high,
    actions: [taskListAction],
  ),
);

const cancellationNoticeStyle = NotificationDetails(
  windows: WindowsNotificationDetails(),
  iOS: DarwinNotificationDetails(
    presentAlert: true,
    presentBadge: true,
    presentSound: false,
  ),
  android: AndroidNotificationDetails(
    'materials_catalog',
    '강의 자료 및 공지',
    channelDescription: '강의자료실 파일 등록 및 일반 공지 알림',
    icon: 'ic_stat_radar',
    importance: Importance.defaultImportance,
    priority: Priority.defaultPriority,
    enableVibration: false,
    playSound: false,
    actions: [applyCancellationAction],
  ),
);

bool _notificationsInitialized = false;

Future<void> ensureNotificationsInitialized() async {
  if (_notificationsInitialized) return;
  await initNotifications();
}

Future<void> initNotifications({void Function(String?)? onTap}) async {
  tzdata.initializeTimeZones();
  await notifications.initialize(
    settings: const InitializationSettings(
      windows: WindowsInitializationSettings(
        appName: 'Campus Radar',
        appUserModelId: 'CampusRadar.Desktop',
        guid: 'b145528f-3d6a-4d94-b532-1be39e636b50',
      ),
      android: AndroidInitializationSettings('ic_stat_radar'),
      iOS: DarwinInitializationSettings(
        requestAlertPermission: false,
        requestBadgePermission: false,
        requestSoundPermission: false,
      ),
    ),
    onDidReceiveNotificationResponse: (r) =>
        onTap?.call(notificationTarget(r.actionId, r.payload)),
  );
  _notificationsInitialized = true;
}

Future<void> requestNotificationPermission() async {
  if (Platform.isIOS) {
    await notifications
        .resolvePlatformSpecificImplementation<
          IOSFlutterLocalNotificationsPlugin
        >()
        ?.requestPermissions(alert: true, badge: true, sound: true);
  } else {
    await notifications
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >()
        ?.requestNotificationsPermission();
  }
}

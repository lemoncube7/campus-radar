String schoolDay(DateTime now) => now
    .toUtc()
    .add(const Duration(hours: 9))
    .toIso8601String()
    .substring(0, 10);

/// Today in Korea as a plain date, so screens agree with the 오늘 tab even when
/// the device clock is in another time zone.
DateTime schoolToday([DateTime? now]) {
  final k = (now ?? DateTime.now()).toUtc().add(const Duration(hours: 9));
  return DateTime(k.year, k.month, k.day);
}

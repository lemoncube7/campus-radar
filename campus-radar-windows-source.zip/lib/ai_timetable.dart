import 'ai_timetable_rules.dart';
import 'app_storage.dart';
import 'campus_models.dart';
import 'timetable_model.dart';

/// Send only saved, valid class slots. No raw syllabus, portal identifiers or credentials.
Future<Map<String, dynamic>> aiTimetableContext(
  Store store, {
  CampusNotice? notice,
  String? courseId,
  DateTime? now,
}) async {
  List<ClassSlot> slots;
  try {
    slots = decodeSlots(await store.meta('timetableEntries'));
  } catch (_) {
    slots = [];
  }
  slots = slots
      .where(
        (s) =>
            s.weekday >= 1 &&
            s.weekday <= 7 &&
            s.start >= 0 &&
            s.end < 1440 &&
            s.end > s.start &&
            s.course.isNotEmpty,
      )
      .toList();
  final id = notice?.context['course_id'],
      section = notice?.context['class_no'];
  if (notice != null) {
    if (id != null && section != null) {
      slots = slots.where((s) => s.courseKey == '$id:$section').toList();
    } else {
      final named = slots
          .where(
            (s) =>
                s.course.replaceAll(RegExp(r'\s+'), '') ==
                notice.course.replaceAll(RegExp(r'\s+'), ''),
          )
          .toList();
      slots = named.map((s) => s.courseKey).toSet().length == 1 ? named : [];
    }
  } else if (courseId != null) {
    slots = slots.where((s) => s.courseKey == courseId).toList();
  }
  slots.sort(
    (a, b) => '${a.course}:${a.weekday}:${a.start}'.compareTo(
      '${b.course}:${b.weekday}:${b.start}',
    ),
  );
  slots = slots.take(notice == null ? 64 : 24).toList();
  final reference = notice == null
      ? (now ?? DateTime.now()).toUtc()
      : notice.published?.toUtc();
  final school = reference?.add(const Duration(hours: 9));
  final mapped = <Map<String, dynamic>>[];
  for (final row in slots.indexed) {
    final s = row.$2;
    final next = school == null
        ? null
        : nextClassStart(school, s.weekday, s.start);
    mapped.add({
      'id': 'T${row.$1 + 1}',
      'course': s.course,
      'weekday': s.weekday,
      'start': slotTime(s.start),
      'end': slotTime(s.end),
      'room': s.room,
      if (next != null) 'nextDate': schoolDate(next),
    });
  }
  final occurrences = <Map<String, dynamic>>[];
  if (school != null) {
    for (var offset = 0; offset < 15; offset++) {
      final day = DateTime.utc(
        school.year,
        school.month,
        school.day,
      ).add(Duration(days: offset));
      for (final s in mapped.where((s) => s['weekday'] == day.weekday)) {
        final start = DateTime.parse('${schoolDate(day)}T${s['start']}:00Z');
        if (!start.isAfter(school)) continue;
        occurrences.add({
          'slotId': s['id'],
          'course': s['course'],
          'date': schoolDate(day),
          'start': s['start'],
          'end': s['end'],
          'room': s['room'],
        });
      }
    }
    occurrences.sort(
      (a, b) =>
          '${a['date']} ${a['start']}'.compareTo('${b['date']} ${b['start']}'),
    );
  }
  return {
    'referenceAt': reference?.toIso8601String(),
    'referenceBasis': notice == null ? '현재 시각' : '공지 게시 시각',
    'timezone': 'Asia/Seoul',
    'savedAt': await store.meta('timetableSavedAt'),
    'limits':
        '사용자가 저장한 정규 시간표. 휴강·보강·학기 종료를 자동 반영한 실제 출석 일정이 아님. 공지의 명시 날짜·시각 우선.',
    'slots': mapped,
    'upcoming': occurrences.take(64).toList(),
  };
}

import 'navigation_contract.dart';
import 'native_contract.dart';
import 'ai_daily_card.dart';
import 'task_presentation.dart';
import 'today_classes_card.dart';
import 'app_storage.dart';
import 'native_bridge.dart';
import 'notification_gateway.dart';
import 'course_labels.dart';
import 'campus_models.dart';
import 'dart:io';
import 'ios_features.dart';
import 'ai_automation.dart';
import 'package:flutter/material.dart';
import 'services.dart';

class DailySummaryPage extends StatefulWidget {
  final bool settings;
  const DailySummaryPage({super.key, this.settings = false});
  @override
  State<DailySummaryPage> createState() => _DailySummaryPageState();
}

class _DailySummaryPageState extends State<DailySummaryPage> {
  List<CampusItem> items = [];
  bool enabled = false, loading = true;
  int hour = 18, minute = 0, fresh = 0;
  String? last, error;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final settings = await bridge.invokeNativeMap<String, dynamic>(
        NativeMethod.dailySettings,
      );
      final store = await Store.open();
      try {
        final excluded = await store.excluded();
        final now = DateTime.now().toUtc();
        final list = (await store.items())
            .where((i) => i.availableAt(now) && !excluded.contains(i.key))
            .toList();
        final today = now.add(const Duration(hours: 9));
        var count = 0;
        for (final i in list.where((i) => i.type == 'LR')) {
          final discovered = DateTime.tryParse(
            await store.meta('discovered:${i.key}') ?? '',
          )?.toUtc().add(const Duration(hours: 9));
          if (discovered != null && DateUtils.isSameDay(today, discovered)) {
            count++;
          }
        }
        final stamp = await store.meta('lastSuccess');
        if (mounted) {
          setState(() {
            items = list;
            fresh = count;
            last = stamp;
            enabled = settings?['enabled'] == true;
            hour = settings?['hour'] ?? 18;
            minute = settings?['minute'] ?? 0;
            loading = false;
            error = null;
          });
        }
      } finally {
        await store.db.close();
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          error = '요약을 불러오지 못했습니다.';
          loading = false;
        });
      }
    }
  }

  Future<void> save(bool value, int h, int m) async {
    try {
      if (value) await requestNotificationPermission();
      await bridge.invokeNative(NativeMethod.setDailySettings, {
        'enabled': value,
        'hour': h,
        'minute': m,
      });
      await scheduleSummaryWarmup(h, m, value);
      if (Platform.isIOS) await updateIosFeatures();
      await logNotification(
        value ? '데일리 요약 예약' : '데일리 요약 해제',
        value
            ? '기기 현지 시각 ${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')} · 절전 시 지연될 수 있습니다.'
            : '요약 알림을 끕니다.',
      );
      if (mounted) {
        setState(() {
          enabled = value;
          hour = h;
          minute = m;
          error = null;
        });
      }
    } catch (_) {
      if (mounted) setState(() => error = '요약 설정을 저장하지 못했습니다.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now().toUtc();
    final today = now.add(const Duration(hours: 9));
    final pending = items.where((i) => i.status == 'pending').toList();
    final todayCount = pending
        .where(
          (i) =>
              i.due != null &&
              i.due!.isAfter(now) &&
              DateUtils.isSameDay(
                today,
                i.due!.toUtc().add(const Duration(hours: 9)),
              ),
        )
        .length;
    final within = pending
        .where((i) => deadlineState(i.due, now: now) == DeadlineState.withinDay)
        .length;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.settings ? '데일리 알림 설정' : '데일리 요약'),
        actions: [
          if (!widget.settings)
            IconButton(
              tooltip: '데일리 알림 설정',
              onPressed: () =>
                  navigateTo(context, SummaryDestination(settings: true)),
              icon: const Icon(Icons.notifications_outlined),
            ),
          IconButton(
            onPressed: load,
            icon: const Icon(Icons.refresh),
            tooltip: '새로고침',
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          if (loading) const LinearProgressIndicator(),
          if (error != null) Text(error!),
          if (!widget.settings) ...[
            if (Platform.isAndroid) const TodayClassesCard(),
            Text(
              '오늘 마감 $todayCount개 · 24시간 이내 $within개',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            Text('전체 미완료 ${pending.length}개 · 오늘 새 과제 $fresh개'),
            const SizedBox(height: 12),
            Text(
              last == null
                  ? '아직 수집 기록이 없습니다.'
                  : '마지막 확인 ${formatDate(DateTime.parse(last!))}',
            ),
            const Text(
              '마지막 수집 정보를 기준으로 집계합니다. 시작 전·비공개·제외 항목은 포함하지 않습니다. 전체 미완료에는 기한이 지난 항목도 포함합니다.',
              style: TextStyle(fontSize: 12),
            ),
            const AiDailyCard(),
          ],
          if (widget.settings) ...[
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('매일 요약 알림'),
              subtitle: const Text('처음에는 꺼져 있습니다. 원하는 시각을 고른 뒤 켜세요.'),
              value: enabled,
              onChanged: loading ? null : (v) => save(v, hour, minute),
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('알림 시각'),
              subtitle: const Text('기기 현지 시각 · 절전 상태에 따라 늦어질 수 있습니다.'),
              trailing: Text(
                '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}',
              ),
              onTap: () async {
                final t = await showTimePicker(
                  context: context,
                  initialTime: TimeOfDay(hour: hour, minute: minute),
                );
                if (t != null) await save(enabled, t.hour, t.minute);
              },
            ),
            OutlinedButton.icon(
              onPressed: () async {
                try {
                  await requestNotificationPermission();
                  if (Platform.isIOS) {
                    await updateIosFeatures(test: true);
                  } else {
                    await bridge.invokeNative(NativeMethod.testDailySummary);
                  }
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('현재 목록으로 요약 알림을 요청했습니다. 알림 로그를 확인하세요.'),
                      ),
                    );
                  }
                } catch (_) {
                  if (mounted) setState(() => error = '요약 알림을 요청하지 못했습니다.');
                }
              },
              icon: const Icon(Icons.notifications_outlined),
              label: const Text('현재 요약 알림 테스트'),
            ),
            if (Platform.isAndroid)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text(
                  '홈 화면을 길게 누른 뒤 위젯에서 ‘캠퍼스레이더 과제 현황’을 추가할 수 있어요. 위젯은 가까운 마감부터 최대 4개를 표시하고, 누르면 상세를 엽니다.',
                ),
              ),
            if (Platform.isIOS)
              const Text(
                'iPhone은 마지막 수집 내용을 기준으로 앞으로 7회 요약 알림을 예약합니다. 수집할 때 갱신하며, AI 분석은 앱 사용 중 준비된 유효한 요약이 있을 때 반영됩니다. 홈 화면 위젯은 현재 Android 전용입니다.',
              ),
          ],
          if (!widget.settings) ...[
            const Divider(),
            for (final i in pending)
              Card(
                color: deadlineBackground(i, context),
                child: ListTile(
                  title: Text(i.title),
                  subtitle: Text(
                    '${courseLabel(i.course)} · ${remainingText(i)}',
                  ),
                  onTap: () => navigateTo(context, TaskDestination(item: i)),
                ),
              ),
          ],
        ],
      ),
    );
  }
}

import 'package:campus_radar/core/radar_card.dart';
import 'package:campus_radar/settings/deadline_settings_page.dart';
import 'package:flutter/material.dart';
import 'package:campus_radar/home/daily_summary_page.dart';
import 'package:campus_radar/schedule/timetable_page.dart';
import 'package:campus_radar/settings/permissions_page.dart';
import 'package:campus_radar/ai/ai_settings_page.dart';
import 'package:campus_radar/campus/deadline_reminders.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';

/// Subtitles show what is set now ("1일 전 · 3시간 전", "18:00 켜짐"), so a
/// change made in the setup wizard is visible here without opening each page.
class NotificationSettingsPage extends StatefulWidget {
  const NotificationSettingsPage({super.key});
  @override
  State<NotificationSettingsPage> createState() =>
      _NotificationSettingsPageState();
}

class _NotificationSettingsPageState extends State<NotificationSettingsPage> {
  String? deadline, classes, daily;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    String? c, s;
    // No database here: the label copy is written where the leads are saved.
    final d = await rememberedDeadlineLeads();
    try {
      final t = await bridge.invokeNativeMap<String, dynamic>(
        NativeMethod.timetableSettings,
      );
      if (t != null) {
        c = [
          t['enabled'] == true ? '수업 ${t['lead'] ?? 30}분 전 켜짐' : '수업 전 꺼짐',
          t['midnight'] == true ? '자정 요약 켜짐' : '자정 요약 꺼짐',
        ].join(' · ');
      }
    } catch (_) {}
    try {
      final m = await bridge.invokeNativeMap<String, dynamic>(
        NativeMethod.dailySettings,
      );
      if (m != null) {
        final h = (m['hour'] ?? 18) as int, mi = (m['minute'] ?? 0) as int;
        final at =
            '${h.toString().padLeft(2, '0')}:${mi.toString().padLeft(2, '0')}';
        s = m['enabled'] == true ? '매일 $at 켜짐' : '꺼짐 · 켜면 매일 $at';
      }
    } catch (_) {}
    if (mounted) {
      setState(() {
        deadline = d;
        classes = c;
        daily = s;
      });
    }
  }

  Future<void> open(Widget page) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
    await load();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('알림 설정')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const RadarPageIntro(
          '새 과제·공지와 마감 알림은 수집 상태와 기기 알림 권한을 따라요.',
        ),
        RadarSettingTile(
          icon: Icons.alarm_outlined,
          title: '마감 알림 시점',
          subtitle: deadline ?? '여러 시점 선택 · 기본 하루 전',
          onTap: () => open(const DeadlineSettingsPage()),
        ),
        RadarSettingTile(
          icon: Icons.verified_user_outlined,
          title: '알림·백그라운드 권한',
          subtitle: '알림 허용 · 배터리 제한 · 정확한 알림',
          onTap: () => open(const PermissionsPage()),
        ),
        RadarSettingTile(
          icon: Icons.schedule_outlined,
          title: '수업 전·자정 알림',
          subtitle: classes ?? '수업 15·30·60분 전 · 자정의 오늘 수업과 과제',
          onTap: () => open(const TimetablePage(initialMode: 2)),
        ),
        RadarSettingTile(
          icon: Icons.summarize_outlined,
          title: '하루 요약 알림',
          subtitle: daily ?? '원하는 시각에 오늘의 과제 현황 받기',
          onTap: () => open(const DailySummaryPage(settings: true)),
        ),
        RadarSettingTile(
          icon: Icons.auto_awesome_outlined,
          title: '요약에 AI 사용',
          subtitle: '알림 시각과 별개로 요약 문장 생성을 설정해요.',
          onTap: () => open(const AiSettingsPage()),
        ),
      ],
    ),
  );
}

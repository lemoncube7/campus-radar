import 'package:campus_radar/core/radar_card.dart';
import 'package:campus_radar/settings/system_widget_page.dart';
import 'package:flutter/material.dart';
import 'package:campus_radar/settings/lock_screen_settings_page.dart';
import 'package:campus_radar/settings/widget_text_page.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/core/demo_mode.dart';

/// Asks the launcher to pin the timetable widget and always says what
/// happened: the pin prompt, the manual path, or why demo mode skips it.
Future<String> pinTimetableWidgetMessage() async {
  if (isDemoActive && !isAgentSimulation) {
    return '체험 모드에서는 위젯을 추가하지 않아요. 실제 계정으로 쓸 때 추가할 수 있어요.';
  }
  bool? added;
  try {
    added = await bridge.invokeNative<bool>(NativeMethod.pinTimetableWidget);
  } catch (_) {}
  return added == true
      ? '홈 화면에 뜬 창에서 [추가]를 눌러 주세요.'
      : '홈 화면 빈 곳을 길게 누른 뒤 위젯 → 캠퍼스레이더 시간표를 추가하세요.';
}

Future<String> pinRadarWidgetMessage() async {
  if (isDemoActive && !isAgentSimulation) {
    return '체험 모드에서는 위젯을 추가하지 않아요. 실제 계정으로 쓸 때 추가할 수 있어요.';
  }
  bool? added;
  try {
    added = await bridge.invokeNative<bool>(NativeMethod.pinRadarWidget);
  } catch (_) {}
  return added == true
      ? '홈 화면에 뜬 창에서 [추가]를 눌러 주세요.'
      : '홈 화면 빈 곳을 길게 누른 뒤 위젯 → 캠퍼스레이더 과제 현황을 추가하세요.';
}

Future<String> pinCompactWidgetMessage() async {
  if (isDemoActive && !isAgentSimulation) {
    return '체험 모드에서는 위젯을 추가하지 않아요. 실제 계정으로 쓸 때 추가할 수 있어요.';
  }
  bool? added;
  try {
    added = await bridge.invokeNative<bool>(NativeMethod.pinCompactWidget);
  } catch (_) {}
  return added == true
      ? '홈 화면에 뜬 창에서 [추가]를 눌러 주세요.'
      : '홈 화면 빈 곳을 길게 누른 뒤 위젯 → 캠퍼스레이더 수업·마감 (잠금화면용)을 추가하세요.';
}

class WidgetSettingsPage extends StatelessWidget {
  const WidgetSettingsPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('위젯·잠금화면')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const RadarPageIntro(
          '홈 화면 위젯과 잠금화면 카드로 앱을 열지 않고 다음 수업·마감을 봐요.',
        ),
        RadarSettingTile(
          icon: Icons.checklist,
          title: '과제·콘텐츠 위젯',
          subtitle:
              '휴대전화 홈 화면을 길게 누르고 위젯에서 캠퍼스레이더 과제 현황을 선택하세요. 항목은 상세, 배경은 전체 할 일로 연결돼요.',
          isThreeLine: true,
          trailing: const Icon(Icons.add_to_home_screen_outlined),
          onTap: () async {
            final text = await pinRadarWidgetMessage();
            if (context.mounted) {
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(SnackBar(content: Text(text)));
            }
          },
        ),
        RadarSettingTile(
          icon: Icons.calendar_view_week,
          title: '시간표 위젯 추가',
          subtitle: '과목 탭의 주간 시간표에서 만든 수업을 표시해요.',
          trailing: const Icon(Icons.add_to_home_screen_outlined),
          onTap: () async {
            final text = await pinTimetableWidgetMessage();
            if (context.mounted) {
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(SnackBar(content: Text(text)));
            }
          },
        ),
        RadarSettingTile(
          icon: Icons.widgets_outlined,
          title: '시스템 잠금화면 위젯',
          subtitle: 'LockStar·지원 기기 · 접근성 권한 없이 배치',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const SystemWidgetPage()),
          ),
        ),
        RadarSettingTile(
          icon: Icons.lock_outline,
          title: '잠금화면 카드 · 접근성 방식',
          subtitle: '접근성 권한 · 전체/작은 카드 · 위치·투명도',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const LockScreenSettingsPage()),
          ),
        ),
        RadarSettingTile(
          icon: Icons.text_fields,
          title: '글씨 크기',
          subtitle: '과제 위젯 · 시간표 · 잠금화면',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const WidgetTextPage()),
          ),
        ),
      ],
    ),
  );
}

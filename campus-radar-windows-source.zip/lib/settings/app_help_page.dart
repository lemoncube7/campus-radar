import 'package:flutter/material.dart';
import 'package:campus_radar/core/radar_card.dart';
import 'package:campus_radar/settings/app_help_catalog.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';

class AppHelpPage extends StatefulWidget {
  final bool autofocus;
  const AppHelpPage({super.key, this.autofocus = false});
  @override
  State<AppHelpPage> createState() => _AppHelpState();
}

/// English words people type for Korean feature names.
const _aliases = {
  'widget': '위젯',
  'lock': '잠금화면',
  '잠금': '잠금화면',
  'calendar': '캘린더',
  'drive': '드라이브',
  'google': '드라이브',
  'notification': '알림',
  'alarm': '알림',
  'push': '알림',
  'timetable': '시간표',
  'schedule': '시간표',
  'class': '수업',
  'cancel': '휴강',
  'chat': 'ai',
  'gemini': 'ai',
  'gpt': 'chatgpt',
  'export': '내보내기',
  '내보내기': '내보내기',
  'zip': '내보내기',
  'md': '내보내기',
  '문서': '내보내기',
  'board': '자유게시판',
  'dark': '다크',
  'night': '다크',
  'theme': '다크',
  '다크': '다크',
  '어둡게': '다크',
  '어두운': '다크',
  '야간': '다크',
  '테마': '다크',
  'hide': '숨김',
  'hidden': '숨김',
  'restore': '숨김',
  '숨김': '숨김',
  '숨긴': '숨김',
  '숨기기': '숨김',
  '복구': '숨김',
  '복원': '숨김',
  'log': '활동 로그',
  'logs': '활동 로그',
  'history': '활동 로그',
  '로그': '활동 로그',
  '기록': '활동 로그',
};

bool helpTopicMatches(AppHelpTopic t, String query) {
  final q = query.trim().toLowerCase();
  if (q.isEmpty) return true;
  final text =
      '${t.title} ${t.description} ${t.steps.join(' ')} ${t.keywords.join(' ')}'
          .toLowerCase();
  if (text.contains(q)) return true;
  final hasKorean = q.runes.any((r) => r > 127);
  return _aliases.entries.any(
    (e) =>
        (e.key == q ||
            (e.key.startsWith(q) && (hasKorean ? q.length >= 2 : q.length >= 3))) &&
        text.contains(e.value),
  );
}

class _AppHelpState extends State<AppHelpPage> {
  String query = '';
  @override
  Widget build(BuildContext context) {
    final found = appHelpTopics.where((t) => helpTopicMatches(t, query)).toList();
    return Scaffold(
    appBar: AppBar(title: const Text('기능 가이드')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        TextField(
          autofocus: widget.autofocus,
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search),
            hintText: '찾는 기능 검색 — 예: 다크, 위젯, 휴강',
          ),
          onChanged: (v) => setState(() => query = v.trim().toLowerCase()),
        ),
        const SizedBox(height: 16),
        const RadarPageIntro(
          '원하는 기능을 고르면 필요한 설정을 순서대로 열어드려요. AI 키 없이도 안내를 볼 수 있어요.',
        ),
        if (found.isEmpty)
          const RadarEmptyState(
            icon: Icons.search_off_rounded,
            message: '찾는 기능이 없어요. "알림", "위젯", "시간표", "휴강", "드라이브"처럼 짧은 단어로 찾아 보세요.',
          ),
        for (final t in found)
          RadarSettingTile(
            icon: Icons.help_outline_rounded,
            title: t.title,
            subtitle: t.description,
            onTap: () => openHelpGuide(context, t),
          ),
      ],
    ),
  );
  }
}

Future<void> openHelpGuide(BuildContext context, AppHelpTopic topic) async {
  await Navigator.push(
    context,
    MaterialPageRoute<void>(builder: (_) => AppHelpGuide(topic: topic)),
  );
}

class AppHelpGuide extends StatefulWidget {
  final AppHelpTopic topic;
  const AppHelpGuide({super.key, required this.topic});
  @override
  State<AppHelpGuide> createState() => _GuideState();
}

class _GuideState extends State<AppHelpGuide> {
  int step = 0;
  List<(String, HelpTool)> get actions => switch (widget.topic.id) {
    'ai-calendar' => [
      ('AI 설정 열기', HelpTool.ai),
      ('캘린더 설정 열기', HelpTool.calendarSettings),
      ('검토함 열기', HelpTool.review),
      ('캘린더 열기', HelpTool.calendar),
    ],
    'ai' => [
      ('AI 설정 열기', HelpTool.ai),
      ('공지 모아보기 열기', HelpTool.notices),
      ('검토함 열기', HelpTool.review),
    ],
    'timetable' => [
      ('시간표 열기', HelpTool.timetable),
      ('수업 알림 설정 열기', HelpTool.classNotifications),
    ],
    'notifications' => [
      ('알림 설정 열기', HelpTool.notifications),
      ('알림·백그라운드 권한 열기', HelpTool.permissions),
    ],
    'widgets' => [('위젯 설정 열기', HelpTool.widgets)],
    'collection' => [
      ('학교 연결·수집 열기', HelpTool.background),
      ('활동 로그 열기', HelpTool.history),
    ],
    'appearance' => [('화면 설정 열기', HelpTool.appearance)],
    'drive' => [
      ('Drive 연결 열기', HelpTool.drive),
      ('자료 내보내기 열기', HelpTool.academicExport),
    ],
    'materials' => [('자료 모아보기 열기', HelpTool.materials)],
    'app-notices' => [('공지 목록 열기', HelpTool.appNotices)],
    _ => [('할 일 표시 설정 열기', HelpTool.tasks)],
  };
  @override
  Widget build(BuildContext context) {
    final topic = widget.topic;
    // A topic may have more steps than buttons; reuse the last button.
    final action = actions[step.clamp(0, actions.length - 1)];
    return Scaffold(
      appBar: AppBar(title: Text(topic.title)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          RadarPageIntro(topic.description),
          RadarCard(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    RadarStatusPill(
                      label: '${step + 1} / ${topic.steps.length}',
                      backgroundColor: Theme.of(
                        context,
                      ).colorScheme.primaryContainer,
                      foregroundColor: Theme.of(
                        context,
                      ).colorScheme.onPrimaryContainer,
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: (step + 1) / topic.steps.length,
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  topic.steps[step],
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 16),
                FilledButton.icon(
                  icon: const Icon(Icons.open_in_new),
                  label: Text(action.$1),
                  onPressed: () =>
                      navigateTo(context, HelpToolDestination(action.$2)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          const RadarPageIntro(
            '설정 화면에서 선택한 뒤 뒤로 오면 안내를 이어갈 수 있어요. 안내를 넘기는 것만으로 설정이 변경되지는 않아요.',
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 12,
            children: [
              if (step > 0)
                TextButton(
                  onPressed: () => setState(() => step--),
                  child: const Text('이전 단계'),
                ),
              FilledButton.tonal(
                onPressed: () {
                  if (step + 1 < topic.steps.length) {
                    setState(() => step++);
                  } else {
                    Navigator.pop(context);
                  }
                },
                child: Text(step + 1 < topic.steps.length ? '다음 단계' : '안내 닫기'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

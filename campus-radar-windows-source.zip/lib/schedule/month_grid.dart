import 'package:flutter/material.dart';

/// Month calendar with a dot under each day that has something on it.
/// [marks] maps 'yyyy-MM-dd' to how many dots (1~3) and [colors] picks
/// each dot's color; the built-in date picker cannot show either.
class MonthGrid extends StatelessWidget {
  final DateTime month, selected, today;
  final Map<String, List<Color>> marks;
  final ValueChanged<DateTime> onSelect;
  final ValueChanged<DateTime> onMonth;
  const MonthGrid({
    super.key,
    required this.month,
    required this.selected,
    required this.today,
    required this.marks,
    required this.onSelect,
    required this.onMonth,
  });

  static String dayKey(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final first = DateTime(month.year, month.month);
    final days = DateTime(month.year, month.month + 1, 0).day;
    // Sunday-first grid, like most Korean calendars.
    final lead = first.weekday % 7;
    final cells = lead + days;
    final rows = (cells / 7).ceil();
    bool same(DateTime a, DateTime b) =>
        a.year == b.year && a.month == b.month && a.day == b.day;
    return Column(
      children: [
        Row(
          children: [
            IconButton(
              tooltip: '이전 달',
              icon: const Icon(Icons.chevron_left),
              onPressed: () => onMonth(DateTime(month.year, month.month - 1)),
            ),
            Expanded(
              child: Text(
                '${month.year}년 ${month.month}월',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.titleMedium,
              ),
            ),
            IconButton(
              tooltip: '다음 달',
              icon: const Icon(Icons.chevron_right),
              onPressed: () => onMonth(DateTime(month.year, month.month + 1)),
            ),
          ],
        ),
        Row(
          children: [
            for (final (i, w) in const ['일', '월', '화', '수', '목', '금', '토']
                .indexed)
              Expanded(
                child: Text(
                  w,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 12,
                    color: i == 0
                        ? scheme.error
                        : i == 6
                        ? scheme.primary
                        : scheme.onSurfaceVariant,
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 4),
        for (var r = 0; r < rows; r++)
          Row(
            children: [
              for (var c = 0; c < 7; c++)
                Expanded(
                  child: Builder(
                    builder: (context) {
                      final n = r * 7 + c - lead + 1;
                      if (n < 1 || n > days) return const SizedBox(height: 48);
                      final d = DateTime(month.year, month.month, n);
                      final dots = marks[dayKey(d)] ?? const <Color>[];
                      final isSelected = same(d, selected);
                      final isToday = same(d, today);
                      return Semantics(
                        button: true,
                        selected: isSelected,
                        label:
                            '${d.month}월 ${d.day}일${isToday ? ' 오늘' : ''}${dots.isEmpty ? '' : ' 일정 ${dots.length}종류'}',
                        excludeSemantics: true,
                        child: InkWell(
                          customBorder: const CircleBorder(),
                          onTap: () => onSelect(d),
                          child: SizedBox(
                            height: 48,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  width: 32,
                                  height: 32,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: isSelected ? scheme.primary : null,
                                    border: isToday && !isSelected
                                        ? Border.all(color: scheme.primary)
                                        : null,
                                  ),
                                  child: Text(
                                    '$n',
                                    style: TextStyle(
                                      color: isSelected
                                          ? scheme.onPrimary
                                          : c == 0
                                          ? scheme.error
                                          : null,
                                      fontWeight: isToday
                                          ? FontWeight.bold
                                          : null,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    for (final color in dots.take(3))
                                      Container(
                                        width: 5,
                                        height: 5,
                                        margin: const EdgeInsets.symmetric(
                                          horizontal: 1,
                                        ),
                                        decoration: BoxDecoration(
                                          color: color,
                                          shape: BoxShape.circle,
                                        ),
                                      ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
            ],
          ),
      ],
    );
  }
}

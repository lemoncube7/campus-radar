import 'package:campus_radar/core/school_time.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';
import 'package:campus_radar/core/transient_message.dart';
import 'package:flutter/material.dart';
import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/ai/ai_cancellation_notification.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/core/radar_card.dart';
import 'package:campus_radar/core/session_scope.dart';

Future<bool> editCancellation(
  BuildContext context, {
  CampusNotice? notice,
  ScheduleCandidate? candidate,
  void Function(CancellationReceipt)? onApplied,
  String? initialSlotId,
  DateTime? initialDate,
}) async =>
    await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => CancellationEditor(
          notice: notice,
          candidate: candidate,
          onApplied: onApplied,
          initialSlotId: initialSlotId,
          initialDate: initialDate,
        ),
      ),
    ) ??
    false;

Future<bool> removeClassCancellation(
  BuildContext context,
  String id, {
  Future<void> Function()? onChanged,
  void Function(String)? onError,
}) async {
  final s = await Store.open();
  try {
    final receipt = await CancellationRepository(
      s,
    ).change((rows) => rows..removeWhere((c) => c.id == id));
    try {
      await bridge.invokeNative(NativeMethod.refreshWidget);
    } catch (e) {
      await systemLog('위젯 갱신 대기', '휴강 해제는 저장했어요. 위젯은 다음 실행 때 갱신돼요.', kind: 'app', error: e);
    }
    if (context.mounted) {
      showTransientMessage(
        context,
        SnackBar(
          content: const Text('휴강을 해제했어요'),
          action: SnackBarAction(
            label: '실행 취소',
            onPressed: () => undoClassCancellation(
              context,
              receipt,
              onChanged: onChanged,
              onError: onError,
            ),
          ),
        ),
      );
    }
    await onChanged?.call();
    return true;
  } catch (e) {
    onError?.call('휴강을 해제하지 못했어요. 다시 확인해 주세요.');
    await systemLog('휴강 해제 실패', '휴강을 해제하지 못했어요.', kind: 'app', error: e);
    return false;
  } finally {
    await s.db.close();
  }
}

Future<void> undoClassCancellation(
  BuildContext context,
  CancellationReceipt receipt, {
  Future<void> Function()? onChanged,
  void Function(String)? onError,
}) async {
  final s = await Store.open();
  try {
    await CancellationRepository(s).undo(receipt);
    try {
      await bridge.invokeNative(NativeMethod.refreshWidget);
    } catch (e) {
      await systemLog('위젯 갱신 대기', '휴강 실행 취소는 저장했어요. 위젯은 다음 실행 때 갱신돼요.', kind: 'app', error: e);
    }
    await onChanged?.call();
  } catch (e) {
    onError?.call(
      e is FormatException ? e.message : '실행 취소하지 못했어요. 다시 확인해 주세요.',
    );
    await systemLog('휴강 실행 취소 실패', '휴강 해제를 되돌리지 못했어요.', kind: 'app', error: e);
  } finally {
    await s.db.close();
  }
}

class TimetableCancellationsPage extends StatefulWidget {
  const TimetableCancellationsPage({super.key});
  @override
  State<TimetableCancellationsPage> createState() => _CancellationsState();
}

class _CancellationsState extends State<TimetableCancellationsPage> {
  List<ClassCancellation> rows = [];
  String? error;
  String? recoveryNotice;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final s = await Store.open();
    try {
      final data = await CancellationRepository(s).read();
      if (mounted) {
        setState(() {
          rows = data.entries;
          error = null;
          recoveryNotice = data.recovered
              ? '저장된 정상 휴강 정보로 표시하고 있어요. 읽지 못한 원본은 보관해요.'
              : data.invalidRows > 0
              ? '일부 휴강 기록을 읽지 못했지만 정상 휴강은 유지했어요.'
              : null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => error = '휴강 목록을 읽지 못했어요.');
      await systemLog('휴강 목록 읽기 실패', '휴강 목록을 읽지 못했어요.', kind: 'app', error: e);
    } finally {
      await s.db.close();
    }
  }

  Future<void> remove(String id) => removeClassCancellation(
    context,
    id,
    onChanged: load,
    onError: (msg) {
      if (mounted) setState(() => error = msg);
    },
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('휴강 추가·해제')),
    floatingActionButton: FloatingActionButton.extended(
      onPressed: () async {
        await editCancellation(context);
        await load();
      },
      icon: const Icon(Icons.add),
      label: const Text('휴강 추가'),
    ),
    body: ListView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
      children: [
        const Text(
          '정규 시간표는 유지하고 선택한 날짜의 수업만 제외해요. 오늘 수업·수업 알림·이번 주 시간표 위젯에 함께 반영돼요.',
        ),
        if (error != null) Text(error!),
        if (recoveryNotice != null) Text(recoveryNotice!),
        if (rows.isEmpty)
          const Padding(
            padding: EdgeInsets.only(top: 12),
            child: RadarEmptyState(
              icon: Icons.event_busy_outlined,
              message: '적용한 휴강이 없어요.',
            ),
          ),
        for (final c in rows)
          RadarCard(
            margin: const EdgeInsets.only(bottom: 10),
            padding: EdgeInsets.zero,
            child: ListTile(
              title: Text('${c.date} · ${c.course}'),
              subtitle: Text(c.source.isEmpty ? '직접 추가' : c.source),
              trailing: TextButton(
                onPressed: () => remove(c.id),
                child: const Text('휴강 해제'),
              ),
            ),
          ),
      ],
    ),
  );
}

class CancellationEditor extends StatefulWidget {
  final CampusNotice? notice;
  final ScheduleCandidate? candidate;
  final void Function(CancellationReceipt)? onApplied;
  final String? initialSlotId;
  final DateTime? initialDate;
  const CancellationEditor({
    super.key,
    this.notice,
    this.candidate,
    this.onApplied,
    this.initialSlotId,
    this.initialDate,
  });
  @override
  State<CancellationEditor> createState() => _CancellationEditorState();
}

class _CancellationEditorState extends State<CancellationEditor> {
  List<ClassSlot> rows = [];
  final selected = <String>{};
  bool busy = true;
  String? error;
  SessionScope? scope;
  late DateTimeRange dates;
  /// "slotId|date" of cancellations already saved, so reopening an applied
  /// notice says so instead of offering the same change again.
  Set<String> applied = {};
  @override
  void initState() {
    super.initState();
    final start =
        DateTime.tryParse(widget.candidate?.date ?? '') ??
        widget.initialDate ??
        schoolToday();
    final end = DateTime.tryParse(widget.candidate?.endDate ?? '') ?? start;
    dates = DateTimeRange(start: start, end: end.isBefore(start) ? start : end);
    load();
  }

  Future<void> load() async {
    final s = await Store.open();
    try {
      scope = await SessionScope.capture(s);
      var data = decodeSlots(await s.meta(MetaKey.timetableEntries));
      try {
        applied = {
          for (final c in (await CancellationRepository(s).read()).entries)
            '${c.slotId}|${c.date}',
        };
      } catch (_) {}
      final n = widget.notice;
      if (n != null) {
        data = matchNoticeCourseSlots(data, n);
      }
      if (mounted) {
        setState(() {
          rows = data;
          busy = false;
          if (widget.initialSlotId != null &&
              data.any((s) => s.id == widget.initialSlotId)) {
            selected.add(widget.initialSlotId!);
          } else {
            selected.addAll(
              preselectedCancellationSlotIds(
                data,
                dates.start,
                dates.end,
                candidateTime: widget.candidate?.time ?? '',
              ),
            );
          }
        });
      }
    } catch (e) {
      await systemLog('휴강 편집 시간표 읽기 실패', '휴강을 고를 시간표를 읽지 못했어요.', kind: 'app', error: e);
      if (mounted) {
        setState(() {
          busy = false;
          // Keep specific guidance (e.g. several sections share the name);
          // retrying would not help those.
          error = e is FormatException
              ? e.message
              : '시간표를 읽지 못했어요. 다시 열어 주세요.';
        });
      }
    } finally {
      await s.db.close();
    }
  }

  Future<void> save() async {
    if (selected.isEmpty) return;
    setState(() => busy = true);
    final s = await Store.open();
    try {
      final currentScope = await SessionScope.capture(s);
      if (currentScope.account != scope?.account ||
          currentScope.epoch != scope?.epoch) {
        throw SessionChanged();
      }
      if (dates.duration.inDays > 365) {
        throw const FormatException('휴강 범위는 1년 이내로 선택해 주세요.');
      }
      final planned = planCancellations(
        rows,
        selected,
        dates.start,
        dates.end,
        source: widget.notice?.title ?? '',
        noticeId: widget.notice?.id ?? '',
        noticeTitle: widget.notice?.title ?? '',
      );
      if (planned.isEmpty) {
        throw const FormatException('선택한 날짜에 해당 요일의 수업이 없어요.');
      }
      await currentScope.verify();
      final receipt = await CancellationRepository(s).apply(planned);
      // From here the cancellation is saved: a failing log write must not
      // turn it into a "could not save" message.
      try {
        await s.log('app', '날짜별 휴강 적용', '${planned.length}개 수업');
      } catch (_) {
        // The saved cancellation stands; the activity line is best-effort.
      }
      var refreshFailed = false;
      try {
        await bridge.invokeNative(NativeMethod.refreshWidget);
      } catch (e) {
        refreshFailed = true;
        await systemLog('위젯 갱신 대기', '휴강은 저장했어요. 위젯·알림은 다음 실행 때 갱신돼요.', kind: 'app', error: e);
      }
      widget.onApplied?.call(receipt);
      if (mounted && refreshFailed) {
        showTransientMessage(
          context,
          const SnackBar(
            content: Text('휴강은 저장했어요. 위젯·알림 갱신은 다음 앱 실행 때 다시 확인해 주세요.'),
          ),
        );
      }
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        setState(
          () => error = e is FormatException
              ? e.message
              : '휴강을 저장하지 못했어요. 다시 확인해 주세요.',
        );
      }
      await systemLog('휴강 저장 실패', '휴강을 저장하지 못했어요.', kind: 'app', error: e);
    } finally {
      await s.db.close();
      if (mounted) setState(() => busy = false);
    }
  }

  /// Classes the current date range and checkboxes would actually cancel;
  /// the apply button stays off until there is at least one.
  List<ClassCancellation> get planned => planCancellations(
    rows,
    selected,
    dates.start,
    dates.end,
  );
  bool get alreadyApplied =>
      planned.isNotEmpty &&
      planned.every((c) => applied.contains('${c.slotId}|${c.date}'));

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('시간표에 휴강 반영')),
    bottomNavigationBar: SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: FilledButton(
          onPressed:
              busy || selected.isEmpty || planned.isEmpty || alreadyApplied
              ? null
              : save,
          child: Text(
            alreadyApplied ? '이미 시간표에 반영됐어요' : '선택한 날짜·수업에 휴강 적용',
          ),
        ),
      ),
    ),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        if (widget.notice != null) ...[
          Text(
            widget.notice!.title,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 10),
          RadarExpansionCard(
            leading: const RadarIconBox(icon: Icons.article_outlined),
            title: const Text('공지 근거 보기'),
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: SelectableText(widget.candidate?.evidence ?? ''),
              ),
            ],
          ),
        ],
        RadarPageIntro(
          widget.notice == null
              ? '휴강할 날짜와 수업을 골라 주세요. 선택한 날짜의 수업 알림과 카운트다운이 제외돼요.'
              : '공지의 날짜와 대상 수업을 확인해 주세요. 선택한 날짜의 수업 알림과 카운트다운이 제외돼요.',
        ),
        if (!busy && selected.isNotEmpty)
          RadarCard(
            margin: const EdgeInsets.only(bottom: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  alreadyApplied ? '이미 반영된 휴강' : '적용될 수업',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 6),
                for (final c in planned) Text('${c.date} · ${c.course}'),
                if (planned.isEmpty)
                  const Text(
                    '고른 날짜에는 선택한 요일의 수업이 없어요. 날짜나 수업을 바꿔 주세요.',
                  ),
                const SizedBox(height: 6),
                Text(
                  '선택한 날짜 외의 정규 수업은 유지해요.',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        RadarExpansionCard(
          leading: const RadarIconBox(icon: Icons.event_busy_outlined),
          title: const Text('날짜·대상 수업 수정'),
          initiallyExpanded: widget.notice == null || selected.isEmpty,
          childrenPadding: const EdgeInsets.only(bottom: 8),
          children: [
            ListTile(
              title: const Text('휴강 날짜'),
              subtitle: Text(
                '${classDate(dates.start)} ~ ${classDate(dates.end)}',
              ),
              trailing: const Icon(Icons.date_range),
              onTap: busy
                  ? null
                  : () async {
                      final d = await showDateRangePicker(
                        context: context,
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2100),
                        initialDateRange: dates,
                      );
                      if (d != null && mounted) {
                        if (d.duration.inDays > 365) {
                          setState(() => error = '휴강 범위는 1년 이내로 선택해 주세요.');
                          return;
                        }
                        setState(() => dates = d);
                      }
                    },
            ),
            for (final e in rows)
              CheckboxListTile(
                title: Text(e.course),
                subtitle: Text(
                  '${weekNames[e.weekday - 1]} ${slotTime(e.start)}–${slotTime(e.end)}',
                ),
                value: selected.contains(e.id),
                onChanged: busy
                    ? null
                    : (v) => setState(
                        () => v == true
                            ? selected.add(e.id)
                            : selected.remove(e.id),
                      ),
              ),
          ],
        ),
        if (busy) const LinearProgressIndicator(),
        if (error != null) Text(error!),
        if (!busy && rows.isEmpty)
          const RadarEmptyState(
            icon: Icons.event_available_outlined,
            message: '연결할 수업이 없어요. 먼저 시간표를 만들고 과목을 확인해 주세요.',
          ),
      ],
    ),
  );
}

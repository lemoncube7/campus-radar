import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/courses/course_catalog.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/courses/course_colors.dart';
import 'package:campus_radar/schedule/timetable_cancellations_page.dart';
import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:campus_radar/schedule/timetable_model.dart';

class TimetableGrid extends StatelessWidget {
  final List<ClassSlot> entries;
  final List<ClassCancellation> cancellations;
  final bool readOnly;
  final Future<void> Function()? onChanged;
  final DateTime? nowOverride;
  const TimetableGrid({
    super.key,
    required this.entries,
    this.cancellations = const [],
    this.readOnly = false,
    this.onChanged,
    this.nowOverride,
  });
  @override
  Widget build(BuildContext context) {
    final days = math.max(
      5,
      entries.fold<int>(1, (a, e) => math.max(a, e.weekday)),
    );
    final first = entries.fold<int>(9, (a, e) => math.min(a, e.start ~/ 60));
    final last = entries.fold<int>(
      18,
      (a, e) => math.max(a, (e.end + 59) ~/ 60),
    );
    const hour = 58.0, left = 34.0, header = 32.0;
    final now = nowOverride ?? DateTime.now().toUtc().add(const Duration(hours: 9));
    final minute = now.hour * 60 + now.minute;
    final lanes = timetableLanes(entries);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final column = math.max(1.0, (constraints.maxWidth - left) / days);
          final compact = column < 85;
          return SizedBox(
            width: left + days * column,
            height: header + (last - first) * hour,
            child: Stack(
              children: [
                if (now.weekday <= days)
                  Positioned(
                    left: left + (now.weekday - 1) * column,
                    top: 0,
                    width: column,
                    height: header + (last - first) * hour,
                    child: ColoredBox(
                      color: Theme.of(
                        context,
                      ).colorScheme.primary.withValues(alpha: 0.05),
                    ),
                  ),
                for (var day = 1; day <= days; day++)
                  Positioned(
                    left: left + (day - 1) * column,
                    top: 0,
                    width: column,
                    child: Center(
                      child: Text(
                        weekNames[day - 1],
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                for (var h = first; h <= last; h++) ...[
                  Positioned(
                    left: 0,
                    top: header + (h - first) * hour - 7,
                    child: Text(
                      '${h.toString().padLeft(2, '0')}:00',
                      style: Theme.of(context).textTheme.labelSmall,
                    ),
                  ),
                  Positioned(
                    left: left,
                    right: 0,
                    top: header + (h - first) * hour,
                    child: Divider(
                      height: 1,
                      color: Theme.of(context).dividerColor,
                    ),
                  ),
                ],
                for (final e in entries) ...[
                  Builder(
                    builder: (context) {
                      final position = lanes[e.id]!;
                      final width = column / position.count;
                      final color = courseAccent(e.courseKey);
                      final monday = weekMonday(now);
                      final slotDate = monday.add(Duration(days: e.weekday - 1));
                      final slotDateStr = classDate(slotDate);
                      final todayStr = classDate(
                        DateTime(now.year, now.month, now.day),
                      );
                      bool matchesSlot(ClassCancellation c) {
                        if (c.slotId == e.id) return true;
                        final parsed = DateTime.tryParse(c.date);
                        return c.course == e.course &&
                            parsed != null &&
                            parsed.weekday == e.weekday;
                      }
                      final cancel = cancellations
                          .where(
                            (c) => matchesSlot(c) && c.date == slotDateStr,
                          )
                          .firstOrNull;
                      final upcomingCancel =
                          (cancellations
                                  .where(
                                    (c) =>
                                        matchesSlot(c) &&
                                        c.date != slotDateStr &&
                                        c.date.compareTo(todayStr) >= 0,
                                  )
                                  .toList()
                                ..sort((a, b) => a.date.compareTo(b.date)))
                              .firstOrNull;
                      String? upcomingLabel;
                      if (cancel == null && upcomingCancel != null) {
                        final nextMonday = monday.add(const Duration(days: 7));
                        final nextSunday = monday.add(const Duration(days: 13));
                        final d = DateTime.tryParse(upcomingCancel.date);
                        if (d != null &&
                            !d.isBefore(nextMonday) &&
                            !d.isAfter(nextSunday)) {
                          upcomingLabel =
                              '다음 주 ${weekNames[e.weekday - 1]} 휴강';
                        } else if (d != null) {
                          upcomingLabel = '${d.month}/${d.day} 휴강';
                        } else {
                          upcomingLabel = '${upcomingCancel.date} 휴강';
                        }
                      }
                      final label = courseLabel(e.course);
                      final hasAlias = label != e.course;
                      final availWidth = math.max(
                        1.0,
                        width - 5 - (compact ? 6 : 10),
                      );
                      final baseSize = compact ? 11.0 : 12.0;
                      final step1Size = compact ? 9.5 : 10.5;
                      final step2Size = compact ? 8.0 : 9.0;
                      final stepDown =
                          label.characters.length * baseSize > availWidth;
                      bool leavesSingleTrailingChar(double fontSize) {
                        final style = Theme.of(context).textTheme.labelSmall
                            ?.copyWith(
                              fontWeight: FontWeight.w600,
                              fontSize: fontSize,
                              height: 1.15,
                            );
                        final tp = TextPainter(
                          text: TextSpan(text: label, style: style),
                          textDirection: Directionality.of(context),
                          maxLines: 2,
                        )..layout(maxWidth: availWidth);
                        final lines = tp.computeLineMetrics();
                        if (lines.length >= 2) {
                          final line1End = tp
                              .getPositionForOffset(
                                Offset(availWidth, lines.first.height / 2),
                              )
                              .offset;
                          final remaining = label.length - line1End;
                          tp.dispose();
                          if (remaining == 1) return true;
                        } else {
                          tp.dispose();
                        }
                        for (final factor in const [1.0, 0.85]) {
                          final perLine = math.max(
                            1,
                            (availWidth / (fontSize * factor)).floor(),
                          );
                          if (label.characters.length > perLine &&
                              label.characters.length - perLine == 1) {
                            return true;
                          }
                        }
                        return false;
                      }

                      var titleSize = stepDown ? step1Size : baseSize;
                      if (!hasAlias &&
                          stepDown &&
                          leavesSingleTrailingChar(step1Size)) {
                        titleSize = leavesSingleTrailingChar(step2Size)
                            ? (compact ? 7.2 : 8.2)
                            : step2Size;
                      }
                      return Positioned(
                        left:
                            left +
                            (e.weekday - 1) * column +
                            position.lane * width +
                            1,
                        top: header + (e.start - first * 60) / 60 * hour + 1,
                        width: width - 2,
                        height: math.max(12, (e.end - e.start) / 60 * hour - 2),
                        child: Tooltip(
                          message:
                              '${cancel != null ? "[휴강] " : upcomingLabel != null ? "[$upcomingLabel] " : ""}$label\n${slotTime(e.start)}–${slotTime(e.end)} ${e.room}',
                          child: Material(
                            color: Colors.transparent,
                            child: Ink(
                              decoration: BoxDecoration(
                                color: cancel != null
                                    ? Colors.red.withValues(alpha: 0.18)
                                    : color.withValues(alpha: 0.32),
                                borderRadius: BorderRadius.circular(7),
                                border: Border(
                                  left: BorderSide(
                                    color: cancel != null ? Colors.red : color,
                                    width: 3,
                                  ),
                                ),
                              ),
                              child: InkWell(
                                borderRadius: BorderRadius.circular(7),
                                onTap: () => showClass(
                                  context,
                                  e,
                                  cancellation: cancel ?? upcomingCancel,
                                  date: cancel == null && upcomingCancel != null
                                      ? DateTime.tryParse(
                                              upcomingCancel.date,
                                            ) ??
                                            slotDate
                                      : slotDate,
                                ),
                                child: Padding(
                                  padding: EdgeInsets.all(compact ? 3 : 5),
                                  child: ClipRect(
                                    child: SingleChildScrollView(
                                      physics:
                                          const NeverScrollableScrollPhysics(),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          if (cancel != null)
                                            Container(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                    horizontal: 3,
                                                    vertical: 1,
                                                  ),
                                              margin: const EdgeInsets.only(
                                                bottom: 2,
                                              ),
                                              decoration: BoxDecoration(
                                                color: Colors.red.shade700,
                                                borderRadius:
                                                    BorderRadius.circular(3),
                                              ),
                                              child: const Text(
                                                '휴강',
                                                style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 9,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            ),
                                          Text(
                                            label,
                                            style: Theme.of(context)
                                                .textTheme
                                                .labelSmall
                                                ?.copyWith(
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: titleSize,
                                                  height: 1.15,
                                                  decoration: cancel != null
                                                      ? TextDecoration
                                                            .lineThrough
                                                      : null,
                                                ),
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          if (!compact)
                                            Text(
                                              '${slotTime(e.start)}–${slotTime(e.end)}\n${e.room}',
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .labelSmall
                                                  ?.copyWith(
                                                    fontSize: 10,
                                                    height: 1.15,
                                                  ),
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          if (upcomingLabel != null)
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                top: 2,
                                              ),
                                              child: Text(
                                                upcomingLabel,
                                                style: TextStyle(
                                                  color: Colors.red.shade700,
                                                  fontSize: 8.5,
                                                  fontWeight: FontWeight.w600,
                                                  height: 1.1,
                                                ),
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ],
                if (now.weekday <= days &&
                    minute >= first * 60 &&
                    minute <= last * 60)
                  Positioned(
                    left: left + (now.weekday - 1) * column,
                    top: header + (minute - first * 60) / 60 * hour,
                    width: column,
                    child: const Divider(
                      color: Colors.red,
                      height: 1,
                      thickness: 2,
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }

  Future<void> showClass(
    BuildContext context,
    ClassSlot e, {
    ClassCancellation? cancellation,
    DateTime? date,
  }) async {
    final now = nowOverride ?? DateTime.now().toUtc().add(const Duration(hours: 9));
    final todayStr = classDate(DateTime(now.year, now.month, now.day));
    bool matchesSlot(ClassCancellation c) {
      if (c.slotId == e.id) return true;
      final parsed = DateTime.tryParse(c.date);
      return c.course == e.course &&
          parsed != null &&
          parsed.weekday == e.weekday;
    }

    final activeCancellation =
        cancellation ??
        (cancellations
                .where((c) => matchesSlot(c) && c.date.compareTo(todayStr) >= 0)
                .toList()
              ..sort((a, b) => a.date.compareTo(b.date)))
            .firstOrNull;
    final cancelDate = activeCancellation == null
        ? null
        : DateTime.tryParse(activeCancellation.date);
    final cancelStatusLabel = activeCancellation == null
        ? null
        : cancelDate != null
        ? '${cancelDate.month}/${cancelDate.day} 휴강 반영됨'
        : '${activeCancellation.date} 휴강 반영됨';

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheet) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      courseLabel(e.course),
                      style: Theme.of(sheet).textTheme.titleLarge,
                    ),
                  ),
                  if (activeCancellation != null)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: Theme.of(sheet).colorScheme.errorContainer,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        '휴강 (휴강으로 인식됨)',
                        style: TextStyle(
                          color: Theme.of(sheet).colorScheme.onErrorContainer,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  IconButton(
                    tooltip: '닫기',
                    onPressed: () => Navigator.pop(sheet),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Theme.of(sheet).colorScheme.surfaceContainerLow,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: Theme.of(
                      sheet,
                    ).colorScheme.outlineVariant.withValues(alpha: 0.45),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${date != null ? "${date.month}월 ${date.day}일(" : ""}${weekNames[e.weekday - 1]}${date != null ? ") " : " "}${slotTime(e.start)}–${slotTime(e.end)}',
                      style: Theme.of(sheet).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(e.room.isEmpty ? '강의실 미확인' : e.room),
                    const SizedBox(height: 6),
                    Text(
                      '${readOnly
                          ? '주간 시간표 사본'
                          : e.courseKey.startsWith('personal:')
                          ? '개인 반복 일정'
                          : '강의계획서 기준'}${e.source.isEmpty
                          ? ''
                          : e.source == 'demo'
                          ? ' · 예시 데이터'
                          : ' · ${e.source}'}',
                      style: Theme.of(sheet).textTheme.bodySmall?.copyWith(
                        color: Theme.of(sheet).colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              if (activeCancellation != null) ...[
                const SizedBox(height: 16),
                Text(
                  cancelStatusLabel!,
                  style: TextStyle(
                    color: Theme.of(sheet).colorScheme.error,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),
                if (activeCancellation.noticeId.isNotEmpty)
                  FilledButton.tonalIcon(
                    icon: const Icon(Icons.description_outlined),
                    label: Text(
                      activeCancellation.noticeTitle.isNotEmpty
                          ? '근거 공지 보기: ${activeCancellation.noticeTitle}'
                          : '근거 공지 보기',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    onPressed: () async {
                      final store = await Store.open();
                      CampusNotice? notice;
                      try {
                        notice = (await store.notices())
                            .where((n) => n.id == activeCancellation.noticeId)
                            .firstOrNull;
                      } finally {
                        await store.db.close();
                      }
                      if (!sheet.mounted) return;
                      if (notice != null) {
                        Navigator.pop(sheet);
                        if (context.mounted) {
                          navigateTo(
                            context,
                            NoticeDestination(notice: notice),
                          );
                        }
                      } else {
                        ScaffoldMessenger.of(sheet).showSnackBar(
                          const SnackBar(
                            content: Text('원문 공지를 찾지 못했어요.'),
                          ),
                        );
                      }
                    },
                  )
                else
                  Text(
                    activeCancellation.source.isNotEmpty
                        ? '직접 추가된 휴강 (${activeCancellation.source})'
                        : '직접 추가된 휴강',
                    style: TextStyle(
                      color: Theme.of(sheet).colorScheme.error,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                if (!readOnly) ...[
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    icon: const Icon(Icons.event_available_outlined),
                    label: const Text('휴강 해제'),
                    onPressed: () async {
                      Navigator.pop(sheet);
                      if (context.mounted) {
                        await removeClassCancellation(
                          context,
                          activeCancellation.id,
                          onChanged: onChanged,
                        );
                      }
                    },
                  ),
                ],
              ] else if (!readOnly && !e.courseKey.startsWith('personal:')) ...[
                const SizedBox(height: 16),
                OutlinedButton.icon(
                  icon: const Icon(Icons.event_busy_outlined),
                  label: const Text('이 수업 휴강 추가'),
                  onPressed: () async {
                    Navigator.pop(sheet);
                    if (context.mounted) {
                      await editCancellation(
                        context,
                        initialSlotId: e.id,
                        initialDate: date,
                      );
                      await onChanged?.call();
                    }
                  },
                ),
              ],
              const SizedBox(height: 20),
              if (!readOnly && !e.courseKey.startsWith('personal:'))
                FilledButton(
                  onPressed: () async {
                    final store = await Store.open();
                    Map<String, dynamic>? course;
                    try {
                      course = (await readCourses(
                        store,
                      )).where((c) => courseKey(c) == e.courseKey).firstOrNull;
                    } finally {
                      await store.db.close();
                    }
                    if (!sheet.mounted) return;
                    if (course == null) {
                      ScaffoldMessenger.of(sheet).showSnackBar(
                        const SnackBar(
                          content: Text('과목 정보를 찾지 못했어요. 새로고침 후 확인해 주세요.'),
                        ),
                      );
                      return;
                    }
                    Navigator.pop(sheet);
                    if (context.mounted) {
                      navigateTo(context, CourseDestination(course: course));
                    }
                  },
                  child: const Text('과목 보기'),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

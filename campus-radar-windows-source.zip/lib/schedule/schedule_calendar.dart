import 'package:campus_radar/core/school_time.dart';
import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'package:flutter/material.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/schedule/schedule_repository.dart';
import 'package:campus_radar/schedule/timetable_grid.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/schedule/detected_schedules_page.dart';
import 'package:campus_radar/schedule/month_grid.dart';
import 'package:campus_radar/schedule/calendar_draft_page.dart';
import 'package:campus_radar/core/radar_card.dart';

class ScheduleCalendar extends StatefulWidget {
  final DateTime? initialSelected;
  final Future<ScheduleSnapshot> Function()? snapshotLoader;
  const ScheduleCalendar({
    super.key,
    this.initialSelected,
    this.snapshotLoader,
  });
  @override
  State<ScheduleCalendar> createState() => _ScheduleCalendarState();
}

class _ScheduleCalendarState extends State<ScheduleCalendar> {
  late DateTime selected = widget.initialSelected ?? schoolToday();
  late DateTime month = DateTime(selected.year, selected.month);
  /// Month grid, or one list of everything in the next 30 days.
  bool agenda = false;
  ScheduleSnapshot? data;
  SessionMark? mark;
  String? error;
  DateTime? until;
  bool restored = false;
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!restored) {
      final saved = widget.initialSelected != null
          ? null
          : PageStorage.maybeOf(
              context,
            )?.readState(context, identifier: 'scheduleDate');
      if (saved is DateTime) {
        selected = saved;
        month = DateTime(saved.year, saved.month);
      }
      restored = true;
    }
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (widget.snapshotLoader != null) {
      try {
        final result = await widget.snapshotLoader!();
        if (mounted) {
          setState(() {
            data = result;
            error = null;
          });
        }
      } catch (_) {
        if (mounted) setState(() => error = '저장된 일정을 읽지 못했어요. 다시 확인해 주세요.');
      }
      return;
    }
    Store? store;
    try {
      store = await Store.open();
      final captured = await SessionMark.capture(store);
      final result = await ScheduleRepository(store).read();
      mark = captured;
      if (mounted) setState(() => data = result);
      DateTime? end;
      try {
        final settings = await bridge
            .invokeNativeMap<String, dynamic>(NativeMethod.timetableSettings)
            .timeout(const Duration(seconds: 2));
        end = DateTime.tryParse(settings?['until'] as String? ?? '');
      } catch (_) {
        // Without native settings, classes show with no end date.
      }
      if (mounted) {
        setState(() {
          data = result;
          until = end;
          error = null;
        });
      }
    } catch (_) {
      if (mounted) setState(() => error = '저장된 일정을 읽지 못했어요. 다시 확인해 주세요.');
    } finally {
      await store?.db.close();
    }
  }

  static String dayKey(DateTime d) => MonthGrid.dayKey(d);

  List<CampusItem> tasksOn(String day) {
    final list =
        data?.tasks
            .where((i) {
              final due = effectiveDue(i);
              return due != null && koreanDate(due) == day;
            })
            .toList() ??
        [];
    list.sort((a, b) {
      final aDue = effectiveDue(a) ?? a.due ?? DateTime.utc(2100);
      final bDue = effectiveDue(b) ?? b.due ?? DateTime.utc(2100);
      final c = aDue.compareTo(bDue);
      return c != 0 ? c : a.title.compareTo(b.title);
    });
    return list;
  }

  /// Dot colors per day of the shown month: deadlines, then added schedules.
  Map<String, List<Color>> monthMarks(ColorScheme scheme) {
    final out = <String, List<Color>>{};
    final days = DateTime(month.year, month.month + 1, 0).day;
    for (var n = 1; n <= days; n++) {
      final k = dayKey(DateTime(month.year, month.month, n));
      final dots = <Color>[
        if (tasksOn(k).isNotEmpty) scheme.error,
        if (confirmedOnDay(data?.events ?? [], k).isNotEmpty) scheme.primary,
      ];
      if (dots.isNotEmpty) out[k] = dots;
    }
    return out;
  }

  void pick(DateTime d) {
    PageStorage.maybeOf(
      context,
    )?.writeState(context, d, identifier: 'scheduleDate');
    setState(() {
      selected = d;
      month = DateTime(d.year, d.month);
      agenda = false;
    });
  }

  /// Short edit sheet for an added schedule: move it or delete it.
  Future<void> editEvent(Map<String, dynamic> row) async {
    final st = row['state'] as Map;
    final n = row['notice'] as CampusNotice;
    final c = row['candidate'] as ScheduleCandidate;
    final key = row['key'] as String;
    final choice = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const RadarIconBox(icon: Icons.event_note_outlined),
                title: Text(st['title'] as String? ?? c.title),
                subtitle: Text('${courseLabel(n.course)} · 공지: ${n.title}'),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.edit_calendar_outlined),
                title: const Text('날짜·시간 바꾸기'),
                onTap: () => Navigator.pop(ctx, 'edit'),
              ),
              ListTile(
                leading: const Icon(Icons.article_outlined),
                title: const Text('근거 공지 보기'),
                onTap: () => Navigator.pop(ctx, 'source'),
              ),
              ListTile(
                leading: const Icon(Icons.delete_outline),
                title: const Text('일정 삭제'),
                onTap: () => Navigator.pop(ctx, 'delete'),
              ),
            ],
          ),
        ),
      ),
    );
    if (!mounted || choice == null) return;
    if (choice == 'edit') {
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => CalendarDraftPage(
            courseName: n.course,
            itemKey: key,
            title: withoutCoursePrefix(
              st['title'] as String? ?? c.title,
              n.course,
            ),
            description: '공지: ${n.title}\n${c.description}',
            start: DateTime.tryParse(st['start'] as String? ?? ''),
            // Keep the original length (a 90-minute exam stays 90 minutes).
            end: DateTime.tryParse(st['end'] as String? ?? ''),
            allDay: st['allDay'] == true,
            closeAfterSave: true,
            saveToCalendar: st['calendarSent'] == true,
          ),
        ),
      );
    } else if (choice == 'source') {
      await navigateTo(
        context,
        AiInboxDestination(initialFilter: 'all', candidateId: key),
      );
    } else {
      await deleteDetectedSchedule(
        context,
        key,
        mark: mark,
        calendarSent: st['calendarSent'] == true,
      );
    }
    await load();
  }

  Widget eventTile(Map<String, dynamic> row) {
    final st = row['state'] as Map;
    final n = row['notice'] as CampusNotice;
    final c = row['candidate'] as ScheduleCandidate;
    final at = st['allDay'] == true
        ? '종일'
        : (DateTime.tryParse(st['start'] as String? ?? '')
                  ?.toUtc()
                  .add(const Duration(hours: 9))
                  .toIso8601String()
                  .substring(11, 16) ??
              c.time);
    return RadarCard(
      margin: const EdgeInsets.only(bottom: 8),
      padding: EdgeInsets.zero,
      child: ListTile(
        leading: const RadarIconBox(icon: Icons.event_available),
        title: Text(
          '[${courseLabel(n.course)}] ${withoutCoursePrefix((st['title'] as String? ?? c.title).replaceFirst(RegExp(r'^\[[^\]]+\]\s*'), ''), n.course)}',
        ),
        subtitle: Text(
          '$at · ${st['approvalMode'] == 'automatic' ? '자동 추가' : '추가한 일정'} · ${st['calendarSent'] == true ? '캘린더 전송됨' : '앱 일정'}',
        ),
        trailing: IconButton(
          tooltip: '일정 삭제',
          icon: const Icon(Icons.delete_outline),
          onPressed: () async {
            final deleted = await deleteDetectedSchedule(
              context,
              row['key'] as String,
              mark: mark,
              calendarSent: st['calendarSent'] == true,
            );
            if (deleted) await load();
          },
        ),
        onTap: () => editEvent(row),
      ),
    );
  }

  Widget taskTile(CampusItem item) => RadarCard(
    margin: const EdgeInsets.only(bottom: 8),
    padding: EdgeInsets.zero,
    child: ListTile(
      leading: const RadarIconBox(icon: Icons.checklist),
      title: Text(item.title),
      subtitle: Text(
        '${courseLabel(item.course)} · ${koreanTime(effectiveDue(item) ?? item.due!)} 마감${extraDeadline(item) != null ? ' (추가 제출)' : ''}',
      ),
      onTap: () async {
        await navigateTo(context, TaskDestination(item: item));
        await load();
      },
    ),
  );

  /// Everything dated in the next 30 days, grouped by day.
  List<Widget> agendaList() {
    final start = schoolToday();
    final out = <Widget>[];
    for (var i = 0; i < 30; i++) {
      final d = DateTime(start.year, start.month, start.day + i);
      final k = dayKey(d);
      final t = tasksOn(k);
      final e = confirmedOnDay(data?.events ?? [], k);
      if (t.isEmpty && e.isEmpty) continue;
      out.add(
        Padding(
          padding: const EdgeInsets.only(top: 12, bottom: 4),
          child: InkWell(
            onTap: () => pick(d),
            child: Text(
              '${d.month}월 ${d.day}일 (${const ['월', '화', '수', '목', '금', '토', '일'][d.weekday - 1]})${i == 0 ? ' · 오늘' : ''}',
              style: Theme.of(context).textTheme.titleSmall,
            ),
          ),
        ),
      );
      out.addAll([
        for (final x in t) taskTile(x),
        for (final x in e) eventTile(x),
      ]);
    }
    if (out.isEmpty && data != null) {
      out.add(
        const Padding(
          padding: EdgeInsets.only(top: 12),
          child: RadarEmptyState(
            icon: Icons.event_available_outlined,
            message: '앞으로 30일 동안 마감이나 추가한 일정이 없어요.',
          ),
        ),
      );
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    final day =
        '${selected.year}-${selected.month.toString().padLeft(2, '0')}-${selected.day.toString().padLeft(2, '0')}';
    final tasks = tasksOn(day);
    final events = confirmedOnDay(data?.events ?? [], day);
    final classes =
        (until != null &&
            selected.isAfter(
              DateTime(until!.year, until!.month, until!.day, 23, 59),
            ))
        ? <ClassSlot>[]
        : (data?.classes ?? [])
              .where((s) => s.weekday == selected.weekday)
              .toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                agenda
                    ? '앞으로 30일의 마감과 추가한 일정'
                    : '점은 마감과 추가한 일정 · 날짜를 누르면 그날 수업도 보여요',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              SegmentedButton<bool>(
                segments: const [
                  ButtonSegment(
                    value: false,
                    icon: Icon(Icons.calendar_month_outlined),
                    label: Text('월간'),
                  ),
                  ButtonSegment(
                    value: true,
                    icon: Icon(Icons.view_agenda_outlined),
                    label: Text('다가오는 일정'),
                  ),
                ],
                selected: {agenda},
                onSelectionChanged: (v) => setState(() => agenda = v.first),
              ),
            ],
          ),
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: load,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              children: [
                if (agenda) ...[
                  if (data == null && error == null)
                    const LinearProgressIndicator(),
                  ...agendaList(),
                ] else ...[
                  MonthGrid(
                    month: month,
                    selected: selected,
                    today: schoolToday(),
                    marks: monthMarks(Theme.of(context).colorScheme),
                    onSelect: pick,
                    onMonth: (m) => setState(() => month = m),
                  ),
                  Wrap(
                    spacing: 12,
                    children: [
                      _Legend(Theme.of(context).colorScheme.error, '마감'),
                      _Legend(
                        Theme.of(context).colorScheme.primary,
                        '추가한 일정',
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${selected.month}월 ${selected.day}일',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  if (error != null) ...[
                    Text(error!),
                    TextButton(onPressed: load, child: const Text('다시 확인')),
                  ],
                  if (data == null && error == null)
                    const LinearProgressIndicator(),
                  if (data != null &&
                      tasks.isEmpty &&
                      events.isEmpty &&
                      classes.isEmpty)
                    const RadarEmptyState(
                      icon: Icons.event_note_outlined,
                      message: '저장된 일정이 없어요.',
                    ),
                  for (final item in tasks) taskTile(item),
                  for (final row in events) eventTile(row),
                  for (final c in classes)
                    Builder(
                      builder: (context) {
                        final cancel = cancellationForSlotOnDate(
                          c,
                          data?.cancellations ?? [],
                          selected,
                        );
                        return RadarCard(
                          margin: const EdgeInsets.only(bottom: 8),
                          padding: EdgeInsets.zero,
                          child: ListTile(
                            leading: RadarIconBox(
                              icon: cancel == null
                                  ? Icons.school_outlined
                                  : Icons.event_busy_outlined,
                              iconColor: cancel == null
                                  ? null
                                  : Theme.of(context).colorScheme.error,
                              backgroundColor: cancel == null
                                  ? null
                                  : Theme.of(
                                      context,
                                    ).colorScheme.error.withValues(alpha: 0.12),
                            ),
                            title: Text(
                              courseLabel(c.course),
                              style: cancel == null
                                  ? null
                                  : const TextStyle(
                                      decoration: TextDecoration.lineThrough,
                                    ),
                            ),
                            subtitle: Text(
                              cancel == null
                                  ? '${slotTime(c.start)}–${slotTime(c.end)} · ${c.room.isEmpty ? '강의실 미확인' : c.room}'
                                  : '${slotTime(c.start)}–${slotTime(c.end)} · 휴강${cancel.noticeTitle.isNotEmpty ? ' (${cancel.noticeTitle})' : ''}',
                            ),
                            trailing: cancel == null
                                ? null
                                : RadarStatusPill(
                                    label: '휴강',
                                    backgroundColor: Theme.of(
                                      context,
                                    ).colorScheme.errorContainer,
                                    foregroundColor: Theme.of(
                                      context,
                                    ).colorScheme.onErrorContainer,
                                  ),
                            onTap: () => TimetableGrid(
                              entries: data?.classes ?? [],
                              cancellations: data?.cancellations ?? [],
                            ).showClass(context, c),
                          ),
                        );
                      },
                    ),
                  if (classes.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text(
                        '수업은 저장된 강의계획서의 반복 시간 기준이에요. 휴강·보강은 과목 공지를 확인하세요.',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                ],
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _Legend extends StatelessWidget {
  final Color color;
  final String label;
  const _Legend(this.color, this.label);
  @override
  Widget build(BuildContext context) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Container(
        width: 8,
        height: 8,
        decoration: BoxDecoration(color: color, shape: BoxShape.circle),
      ),
      const SizedBox(width: 4),
      Text(label, style: const TextStyle(fontSize: 12)),
    ],
  );
}

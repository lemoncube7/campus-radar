import 'dart:io';

import 'package:path_provider/path_provider.dart';

import 'package:campus_radar/campus/material_catalog.dart';
import 'package:campus_radar/campus/media_cache.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/export/academic_export.dart';

/// Windows: a tidy, read-only copy of the collected material in the user's
/// Documents folder, browsable in Explorer:
///
///   문서\캠퍼스레이더\
///     학업 현황.txt · 시간표.txt
///     <과목>\
///       과목 정리.txt            (과제·공지·자료 본문)
///       자료\<원본 파일>
///       자유게시판\글 목록.txt · <첨부 원본>
///
/// Only originals already on this PC are copied (nothing is downloaded here).
/// Files are rewritten only when their size changed. The app never reads this
/// folder back, so deleting it is harmless; the next refresh rebuilds it.
class LocalLibrary {
  static const folderName = '캠퍼스레이더';

  static Future<Directory> root() async {
    final docs = await getApplicationDocumentsDirectory();
    return Directory('${docs.path}${Platform.pathSeparator}$folderName');
  }

  /// Rebuilds the folder from [store] and the attachment [cache].
  /// Returns how many files were written.
  static Future<int> sync(Store store, MediaCache cache, {String profileId = 'local'}) async {
    final base = await root();
    await base.create(recursive: true);
    var written = 0;

    Future<void> writeText(String rel, String text) async {
      final f = File(_join(base.path, rel));
      await f.parent.create(recursive: true);
      if (await f.exists() && await f.readAsString() == text) return;
      await f.writeAsString(text, flush: true);
      written++;
    }

    Future<void> copyFile(File src, String rel) async {
      final dst = File(_join(base.path, rel));
      await dst.parent.create(recursive: true);
      if (await dst.exists() && await dst.length() == await src.length()) return;
      await src.copy(dst.path);
      written++;
    }

    final bundle = await buildAcademicExport(
      store,
      profileId,
      includeLinks: true,
      exportFreeboard: true,
    );
    for (final e in bundle.documents.entries) {
      final name = e.key;
      if (!name.endsWith('.txt') && !name.endsWith('.md')) continue;
      if (name.startsWith('과목/첨부_')) continue; // extracted text; originals go to 자료
      if (name.startsWith('과목/')) {
        final file = name.substring('과목/'.length).replaceAll(RegExp(r'\.(txt|md)$'), '');
        if (file.endsWith('_자유게시판')) {
          final course = file.substring(0, file.length - '_자유게시판'.length);
          await writeText('$course/자유게시판/글 목록.txt', e.value);
        } else {
          await writeText('$file/과목 정리.txt', e.value);
        }
      } else if (!name.contains('/')) {
        await writeText(name, e.value);
      }
    }

    final materials = await studyMaterials(store);
    final paths = resolveDriveAttachmentPaths(materials);
    for (final m in materials) {
      final media = m.media;
      if (media == null) continue;
      final local = await cache.local(media);
      if (local == null) continue;
      final path = paths[m.id];
      final course = path?.safeCourse ?? safeCourseFolderName(m.course);
      final file = path?.fileName ?? safeAttachmentFileName(media.name);
      await copyFile(local, '$course/자료/$file');
    }

    for (final post in await store.freeboardPosts()) {
      final course = safeCourseFolderName(post.course);
      for (final media in post.media) {
        final local = await cache.local(media);
        if (local == null) continue;
        await copyFile(local, '$course/자유게시판/${safeAttachmentFileName(media.name)}');
      }
    }
    return written;
  }

  /// Opens the folder in Explorer.
  static Future<void> open() async {
    final dir = await root();
    await dir.create(recursive: true);
    await Process.run('explorer', [dir.path]);
  }

  static String _join(String base, String rel) =>
      '$base${Platform.pathSeparator}${rel.replaceAll('/', Platform.pathSeparator)}';
}

import 'dart:convert';
import 'dart:io';

import 'package:campus_radar/ai/ai_inbox_repository.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/demo_state.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Pure data builders for Android lock-free widget snapshots.
class WidgetSnapshotPayload {
  static Map<String, dynamic> buildSnapshot({
    required List<CampusItem> items,
    required Set<String> excludedKeys,
    required String? lastSuccess,
    required bool connected,
    required Map<String, String> metaEntries,
    DateTime? now,
  }) {
    final current = now ?? DateTime.now().toUtc();
    final activeItems = items
        .where((i) => !excludedKeys.contains(i.key) && i.availableAt(current))
        .map((i) => i.toJson())
        .toList();

    final discovered = <String, String>{};
    for (final entry in metaEntries.entries) {
      if (entry.key.startsWith('discovered:')) {
        discovered[entry.key] = entry.value;
      }
    }

    return {
      'items': activeItems,
      'last': lastSuccess ?? '',
      'discovered': discovered,
      'connected': connected,
    };
  }
}

/// Confirmed notice-detected events (exams, make-up classes, ...) in the next
/// [days] Korean days, soonest first, for the daily-summary sentence. Task
/// candidates are skipped: those deadlines already come from the task list.
List<Map<String, String>> briefEvents(
  List<Map<String, dynamic>> rows,
  DateTime now, {
  int days = 7,
}) {
  final k = now.toUtc().add(const Duration(hours: 9));
  final first = k.toIso8601String().substring(0, 10);
  final last = k.add(Duration(days: days)).toIso8601String().substring(0, 10);
  final out = <Map<String, String>>[];
  for (final r in rows) {
    final st = r['state'];
    final c = r['candidate'];
    if (st is! Map || c is! ScheduleCandidate) continue;
    if (st['status'] != 'confirmed' || c.category == 'task') continue;
    final date = st['date'] as String? ?? c.date;
    if (date.length != 10 || date.compareTo(first) < 0 || date.compareTo(last) > 0) {
      continue;
    }
    final notice = r['notice'];
    out.add({
      'date': date,
      'time': c.time,
      'title': c.title,
      'course': notice is CampusNotice ? notice.course : '',
    });
  }
  out.sort((a, b) => '${a['date']} ${a['time']}'.compareTo('${b['date']} ${b['time']}'));
  return out.take(5).toList();
}

/// Publishes a JSON snapshot of items, metadata, and timetable into SharedPreferences
/// so Android AppWidgets and background receivers can read data instantly without
/// touching SQLite or contending for DB locks (eliminating widget ANRs).
Future<void> publishAndroidWidgetSnapshot(
  Store store, {
  SharedPreferences? prefs,
  DateTime? now,
}) async {
  // Agent simulation feeds widgets and test notifications the example data;
  // demo exit restores SharedPreferences, so the real snapshot comes back.
  if (demoBlocksNotifications) return;
  if (!Platform.isAndroid && prefs == null) return;
  try {
    final p = prefs ?? await SharedPreferences.getInstance();
    final items = await store.items();
    final excluded = await store.excluded();
    final lastSuccess = await store.meta(MetaKey.lastSuccess);
    final initialized = await store.meta('initialized');
    final isConnected = initialized == 'yes' || isAgentSimulation;

    final metaRows = await store.db.query('meta');
    final metaEntries = {
      for (final r in metaRows)
        r['id'] as String: r['value'] as String,
    };

    final snapshot = WidgetSnapshotPayload.buildSnapshot(
      items: items,
      excludedKeys: excluded,
      lastSuccess: lastSuccess,
      connected: isConnected,
      metaEntries: metaEntries,
      now: now,
    );

    try {
      snapshot['events'] = briefEvents(
        (await AiInboxRepository(store).read()).candidates,
        now ?? DateTime.now(),
      );
    } catch (_) {}
    await p.setString(PrefKey.widgetSnapshotJson, jsonEncode(snapshot));

    final timetable = metaEntries[MetaKey.timetableEntries];
    if (timetable != null && timetable.isNotEmpty) {
      await p.setString(PrefKey.widgetTimetableJson, timetable);
    }
  } catch (_) {
    // Best effort: Android widget falls back to SQLite campus.db if snapshot is missing
  }
}

/// Cleans up widget snapshot cache on account disconnect or reset.
Future<void> clearAndroidWidgetSnapshot({SharedPreferences? prefs}) async {
  if (isDemoActive) return;
  if (!Platform.isAndroid && prefs == null) return;
  try {
    final p = prefs ?? await SharedPreferences.getInstance();
    await p.remove(PrefKey.widgetSnapshotJson);
    await p.remove(PrefKey.widgetTimetableJson);
  } catch (_) {}
}

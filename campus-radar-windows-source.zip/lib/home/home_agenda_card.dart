import 'dart:async';
import 'package:flutter/material.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/ai/ai_inbox_repository.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/home/home_navigation.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/core/radar_card.dart';
import 'package:campus_radar/ai/ai_cancellation_notification.dart';

class HomeAgendaCard extends StatefulWidget {
  final bool compact;
  final int refreshToken;
  const HomeAgendaCard({
    super.key,
    this.compact = false,
    this.refreshToken = 0,
  });
  @override
  State<HomeAgendaCard> createState() => _HomeAgendaState();
}

class _HomeAgendaState extends State<HomeAgendaCard> {
  List<Map<String, dynamic>> upcoming = [];
  int review = 0;
  int failed = 0;
  bool reading = false;
  Timer? timer;
  @override
  void initState() {
    super.initState();
    cancellationRefresh.addListener(load);
    load();
    timer = Timer.periodic(const Duration(seconds: 15), (_) => load());
  }

  @override
  void didUpdateWidget(covariant HomeAgendaCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.refreshToken != widget.refreshToken) {
      unawaited(load());
    }
  }

  @override
  void dispose() {
    timer?.cancel();
    cancellationRefresh.removeListener(load);
    super.dispose();
  }

  Future<void> load() async {
    if (reading || !mounted) return;
    reading = true;
    Store? store;
    try {
      store = await Store.open();
      if (!mounted) return;
      final snapshot = await AiInboxRepository(store).read();
      final today = DateTime.now()
          .toUtc()
          .add(const Duration(hours: 9))
          .toIso8601String()
          .substring(0, 10);
      final rows =
          snapshot.candidates.where((r) {
            final st = r['state'] as Map;
            final c = r['candidate'] as ScheduleCandidate;
            return st['status'] == 'confirmed' &&
                ((st['date'] as String? ?? c.date).compareTo(today) >= 0);
          }).toList()..sort(
            (a, b) => '${a['state']['start'] ?? a['candidate'].date}'.compareTo(
              '${b['state']['start'] ?? b['candidate'].date}',
            ),
          );
      if (mounted) {
        setState(() {
          upcoming = rows.take(3).toList();
          failed = snapshot.jobs.where((j) => j['status'] == 'failed').length;
          review = pendingReviewCandidates(snapshot.candidates).length;
        });
      }
    } catch (_) {
    } finally {
      await store?.db.close();
      reading = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.compact) {
      final today = DateTime.now()
          .toUtc()
          .add(const Duration(hours: 9))
          .toIso8601String()
          .substring(0, 10);
      final events = upcoming
          .where(
            (r) =>
                (r['state']['date'] ??
                    (r['candidate'] as ScheduleCandidate).date) ==
                today,
          )
          .take(1)
          .toList();
      return Column(
        children: [
          if (review + failed > 0)
            RadarCard(
              margin: const EdgeInsets.only(bottom: 8),
              padding: EdgeInsets.zero,
              child: ListTile(
                leading: const RadarIconBox(icon: Icons.fact_check_outlined),
                title: Text('검토함 · 확인할 일정 $review개'),
                subtitle: failed > 0 ? Text('분석 실패 $failed개') : null,
                trailing: Icon(
                  Icons.chevron_right_rounded,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
                onTap: () async {
                  await navigateTo(
                    context,
                    AiInboxDestination(records: review == 0),
                  );
                  await load();
                },
              ),
            ),
          for (final row in events)
            RadarCard(
              margin: const EdgeInsets.only(bottom: 8),
              padding: EdgeInsets.zero,
              child: ListTile(
                leading: RadarIconBox(
                  icon: Icons.event_outlined,
                  iconColor: Theme.of(context).colorScheme.secondary,
                ),
                title: Text(
                  (row['state']['title'] as String?) ??
                      (row['candidate'] as ScheduleCandidate).title,
                ),
                subtitle: const Text('오늘의 추가 일정'),
                onTap: () => homeNavigation.value = const HomeRequest(
                  view: ScheduleView.calendar,
                ),
              ),
            ),
        ],
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (failed > 0)
          RadarCard(
            margin: const EdgeInsets.only(bottom: 8),
            padding: EdgeInsets.zero,
            child: ListTile(
              leading: RadarIconBox(
                icon: Icons.info_outline,
                iconColor: Theme.of(context).colorScheme.error,
                backgroundColor: Theme.of(
                  context,
                ).colorScheme.error.withValues(alpha: 0.12),
              ),
              title: Text('정리가 멈춘 공지 $failed개'),
              subtitle: const Text('원인과 해결 방법을 확인해 주세요.'),
              trailing: Icon(
                Icons.chevron_right_rounded,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
              onTap: () async {
                await navigateTo(
                  context,
                  const AiInboxDestination(records: true),
                );
                await load();
              },
            ),
          ),
        if (review > 0)
          RadarCard(
            margin: const EdgeInsets.only(bottom: 8),
            padding: EdgeInsets.zero,
            child: ListTile(
              leading: const RadarIconBox(icon: Icons.fact_check_outlined),
              title: Text('확인할 일정 $review개'),
              subtitle: const Text('날짜·조건을 확인하고 일정에 추가하세요.'),
              trailing: Icon(
                Icons.chevron_right_rounded,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
              onTap: () => homeNavigation.value = const HomeRequest(
                view: ScheduleView.review,
              ),
            ),
          ),
        if (upcoming.isNotEmpty) ...[
          Row(
            children: [
              Expanded(
                child: Text(
                  '다가오는 일정',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
              ),

              TextButton(
                onPressed: () => homeNavigation.value = const HomeRequest(
                  view: ScheduleView.calendar,
                ),
                child: const Text('전체 보기'),
              ),
            ],
          ),
          for (final row in upcoming)
            Builder(
              builder: (context) {
                final n = row['notice'] as CampusNotice;
                final c = row['candidate'] as ScheduleCandidate;
                final st = row['state'] as Map;
                return RadarCard(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: EdgeInsets.zero,
                  child: ListTile(
                    leading: RadarIconBox(
                      icon: Icons.event_outlined,
                      iconColor: Theme.of(context).colorScheme.secondary,
                    ),
                    title: Text(
                      courseEventTitle(
                        st['title'] as String? ?? c.title,
                        n.course,
                        oldLabel: st['courseLabel'] as String?,
                      ),
                    ),
                    subtitle: Text(
                      '${st['date'] ?? c.date} · ${st['approvalMode'] == 'automatic' ? '자동 추가됨' : '추가한 일정'}',
                    ),
                    onTap: () async {
                      await navigateTo(
                        context,
                        AiInboxDestination(
                          initialFilter: 'all',
                          candidateId: row['key'] as String,
                        ),
                      );
                      await load();
                    },
                  ),
                );
              },
            ),
        ],
      ],
    );
  }
}

import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/ai/ai_daily_card.dart';
import 'package:campus_radar/tasks/task_presentation.dart';
import 'package:campus_radar/schedule/today_classes_card.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/notification_gateway.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'dart:io';
import 'package:campus_radar/platform/ios_features.dart';
import 'package:campus_radar/ai/ai_automation.dart';
import 'package:campus_radar/core/demo_mode.dart';
import 'package:flutter/material.dart';
import 'package:campus_radar/core/radar_card.dart';
import 'package:campus_radar/campus/services.dart';

class DailySummaryPage extends StatefulWidget {
  final bool settings;
  const DailySummaryPage({super.key, this.settings = false});
  @override
  State<DailySummaryPage> createState() => _DailySummaryPageState();
}

class _DailySummaryPageState extends State<DailySummaryPage> {
  List<CampusItem> items = [];
  bool enabled = false, loading = true;
  int hour = 18, minute = 0, fresh = 0;
  String? last, error;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final settings = await bridge.invokeNativeMap<String, dynamic>(
        NativeMethod.dailySettings,
      );
      final store = await Store.open();
      try {
        final excluded = await store.excluded();
        final now = DateTime.now().toUtc();
        final list = (await store.items())
            .where((i) => i.availableAt(now) && !excluded.contains(i.key))
            .toList();
        final today = now.add(const Duration(hours: 9));
        var count = 0;
        for (final i in list.where((i) => i.type == 'LR')) {
          final discovered = DateTime.tryParse(
            await store.meta(MetaKey.discovered(i.key)) ?? '',
          )?.toUtc().add(const Duration(hours: 9));
          if (discovered != null && DateUtils.isSameDay(today, discovered)) {
            count++;
          }
        }
        final stamp = await store.meta(MetaKey.lastSuccess);
        if (mounted) {
          setState(() {
            items = list;
            fresh = count;
            last = stamp;
            enabled = settings?['enabled'] == true;
            hour = settings?['hour'] ?? 18;
            minute = settings?['minute'] ?? 0;
            loading = false;
            error = null;
          });
        }
      } finally {
        await store.db.close();
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          error = '요약을 불러오지 못했어요.';
          loading = false;
        });
      }
    }
  }

  Future<void> save(bool value, int h, int m) async {
    try {
      if (value) await requestNotificationPermission();
      await bridge.invokeNative(NativeMethod.setDailySettings, {
        'enabled': value,
        'hour': h,
        'minute': m,
      });
      await scheduleSummaryWarmup(h, m, value);
      if (Platform.isIOS) await updateIosFeatures();
      await logNotification(
        value ? '하루 요약 예약' : '하루 요약 해제',
        value
            ? '기기 현지 시각 ${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')} · 절전 시 지연될 수 있어요.'
            : '요약 알림을 꺼요.',
      );
      if (mounted && demoBlocksNotifications) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text(demoNotificationMessage)));
      }
      if (mounted) {
        setState(() {
          enabled = value;
          hour = h;
          minute = m;
          error = null;
        });
      }
    } catch (_) {
      if (mounted) setState(() => error = '요약 설정을 저장하지 못했어요.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now().toUtc();
    final today = now.add(const Duration(hours: 9));
    final pending = items.where((i) => i.openTask).toList();
    final todayCount = pending
        .where(
          (i) =>
              i.due != null &&
              i.due!.isAfter(now) &&
              DateUtils.isSameDay(
                today,
                i.due!.toUtc().add(const Duration(hours: 9)),
              ),
        )
        .length;
    final within = pending
        .where((i) => deadlineState(i.due, now: now) == DeadlineState.withinDay)
        .length;
    // With nothing due soon, the most useful line is what comes next.
    final upcoming =
        pending.where((i) => i.due != null && i.due!.isAfter(now)).toList()
          ..sort((a, b) => a.due!.compareTo(b.due!));
    final next = upcoming.firstOrNull;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.settings ? '하루 요약 알림 설정' : '하루 요약'),
        actions: [
          if (!widget.settings)
            IconButton(
              tooltip: '하루 요약 알림 설정',
              onPressed: () =>
                  navigateTo(context, SummaryDestination(settings: true)),
              icon: const Icon(Icons.notifications_outlined),
            ),
          IconButton(
            onPressed: load,
            icon: const Icon(Icons.refresh),
            tooltip: '새로고침',
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          if (loading) const LinearProgressIndicator(),
          if (error != null) Text(error!),
          if (!widget.settings) ...[
            if (Platform.isAndroid || Platform.isIOS) const TodayClassesCard(),
            RadarCard(
              margin: const EdgeInsets.only(bottom: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    todayCount == 0 && within == 0
                        ? '오늘은 마감이 없어요'
                        : '오늘 마감 $todayCount개 · 24시간 이내 $within개',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  if (todayCount == 0 && within == 0 && next != null) ...[
                    const SizedBox(height: 6),
                    Text(
                      '다음 마감 · ${courseLabel(next.course)} ${next.title} · ${remainingText(next, now: now)}',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                  ],
                  const SizedBox(height: 6),
                  Text('${openCountLabel(pending, now)} · 오늘 새 과제 $fresh개'),
                  const SizedBox(height: 10),
                  Text(
                    last == null
                        ? '아직 수집 기록이 없어요.'
                        : '마지막 확인 ${formatDate(DateTime.parse(last!))}',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '시작 전·비공개·숨긴 항목은 빼고 셌어요.',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
            const AiDailyCard(),
          ],
          if (widget.settings) ...[
            const RadarPageIntro(
              '매일 정한 시각에 오늘 마감·24시간 이내 항목과 수업 요약을 알림으로 받아봐요.',
            ),
            RadarGroupCard(
              margin: const EdgeInsets.only(bottom: 12),
              children: [
                SwitchListTile(
                  secondary: const RadarIconBox(
                    icon: Icons.summarize_outlined,
                  ),
                  title: const Text('하루 요약 알림'),
                  subtitle: Text(
                    enabled ? '매일 고른 시각에 알려요.' : '꺼져 있어요. 원하는 시각을 고른 뒤 켜세요.',
                  ),
                  value: enabled,
                  onChanged: loading ? null : (v) => save(v, hour, minute),
                ),
                ListTile(
                  leading: const RadarIconBox(icon: Icons.schedule_outlined),
                  title: const Text('알림 시각'),
                  subtitle: const Text('기기 현지 시각 · 절전 상태에 따라 늦어질 수 있어요.'),
                  trailing: RadarStatusPill(
                    label:
                        '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}',
                  ),
                  onTap: () async {
                    final t = await showTimePicker(
                      context: context,
                      initialTime: TimeOfDay(hour: hour, minute: minute),
                    );
                    if (t != null) await save(enabled, t.hour, t.minute);
                  },
                ),
              ],
            ),
            OutlinedButton.icon(
              onPressed: () async {
                try {
                  await requestNotificationPermission();
                  if (Platform.isIOS) {
                    await updateIosFeatures(test: true);
                  } else {
                    await bridge.invokeNative(NativeMethod.testDailySummary);
                  }
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          demoBlocksNotifications
                              ? demoNotificationMessage
                              : '현재 목록으로 요약 알림을 보냈어요. 잠시 뒤 알림 창을 확인하세요.',
                        ),
                      ),
                    );
                  }
                } catch (_) {
                  if (mounted) setState(() => error = '요약 알림을 요청하지 못했어요.');
                }
              },
              icon: const Icon(Icons.notifications_outlined),
              label: const Text('현재 요약 알림 테스트'),
            ),
            if (Platform.isIOS)
              const Text(
                'iPhone은 마지막 수집 내용을 기준으로 앞으로 7회 요약 알림을 예약해요. 수집할 때 갱신하며, AI 분석은 앱 사용 중 준비된 유효한 요약이 있을 때 반영돼요. 홈 화면 위젯은 현재 Android 전용이에요.',
              ),
          ],
          if (!widget.settings) ...[
            const Divider(),
            for (final i in pending)
              Card(
                color: deadlineBackground(i, context),
                child: ListTile(
                  title: Text(i.title),
                  subtitle: Text(
                    '${courseLabel(i.course)} · ${remainingText(i)}',
                  ),
                  onTap: () => navigateTo(context, TaskDestination(item: i)),
                ),
              ),
          ],
        ],
      ),
    );
  }
}

import 'dart:io';
import 'package:flutter/material.dart';

import 'package:campus_radar/core/demo_state.dart';
import 'package:campus_radar/home/feature_recommendation.dart';
import 'package:campus_radar/home/setup_checklist.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/home/home_agenda_card.dart';
import 'package:campus_radar/home/modern_task_card.dart';
import 'package:campus_radar/home/today_hero_briefing.dart';
import 'package:campus_radar/notices/notice_pages.dart';
import 'package:campus_radar/schedule/today_classes_card.dart';
import 'package:campus_radar/updates/update_page.dart';
import 'package:campus_radar/updates/app_notices.dart';
import 'package:campus_radar/home/important_notice_card.dart';

/// Clean, modular mobile-first view for the 'Today' home tab.
/// Replaces the monolithic ListView in main.dart with clear visual hierarchy,
/// unified hero briefing, modern task cards, and non-intrusive alert banners.
class MobileTodayView extends StatelessWidget {
  final DateTime now;
  final List<CampusItem> pendingItems;
  /// Same number as the 할 일 tab's 전체 pill, so the two screens agree.
  final int? openCount;
  final int? overdueCount;
  final int urgentCount;
  final int todayCount;
  final Set<String> excludedKeys;
  final Set<String> visibilityBusy;
  final bool isBusy;
  final String? syncPhase;
  final String? lastSyncTime;
  final Map<String, dynamic>? availableUpdate;
  final List<String> powerWarnings;
  final List<CampusNotice> homeNotices;
  final List<AppNotice> importantNotices;
  final int localRevision;
  final VoidCallback onRefresh;
  final VoidCallback onShowAllTasks;
  final VoidCallback onShowUrgentTasks;
  final void Function(CampusItem item) onTaskTap;
  final void Function(CampusItem item) onTaskVisibilityToggle;
  final void Function(String id)? onDismissNotice;
  final void Function(String url)? onOpenNoticeUrl;

  const MobileTodayView({
    super.key,
    required this.now,
    required this.pendingItems,
    this.openCount,
    this.overdueCount,
    required this.urgentCount,
    required this.todayCount,
    required this.excludedKeys,
    required this.visibilityBusy,
    required this.isBusy,
    this.syncPhase,
    this.lastSyncTime,
    this.availableUpdate,
    this.powerWarnings = const [],
    this.homeNotices = const [],
    this.importantNotices = const [],
    required this.localRevision,
    required this.onRefresh,
    required this.onShowAllTasks,
    required this.onShowUrgentTasks,
    required this.onTaskTap,
    required this.onTaskVisibilityToggle,
    this.onDismissNotice,
    this.onOpenNoticeUrl,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final overdue =
        overdueCount ??
        pendingItems.where((i) {
          final eff = effectiveDue(i, now: now);
          return eff != null && !eff.isAfter(now);
        }).length;

    final unreadNotices = homeNotices
        .where(
          (n) =>
              !n.read &&
              n.published != null &&
              now.difference(n.published!).inHours <= 48,
        )
        .toList();

    return RefreshIndicator(
      onRefresh: () async => onRefresh(),
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: EdgeInsets.fromLTRB(
          16,
          12,
          16,
          80 + MediaQuery.paddingOf(context).bottom,
        ),
        children: [
          // 1. Unified Hero Briefing Card
          TodayHeroBriefing(
            now: now,
            urgentCount: urgentCount,
            todayCount: todayCount,
            pendingCount: openCount ?? pendingItems.length,
            overdueCount:
                overdueCount ??
                pendingItems.where((i) {
                  final eff = effectiveDue(i, now: now);
                  return eff != null && !eff.isAfter(now);
                }).length,
            lastSyncTime: lastSyncTime,
            isSyncing: isBusy,
            syncPhase: syncPhase,
            onSyncPressed: onRefresh,
            onUrgentPressed: onShowUrgentTasks,
          ),
          const SizedBox(height: 12),

          // Important App Notices
          for (final notice in importantNotices) ...[
            ImportantNoticeCard(
              notice: notice,
              onDismiss: () => onDismissNotice?.call(notice.id),
              onOpenUrl: onOpenNoticeUrl,
            ),
            const SizedBox(height: 8),
          ],

          // 2. Compact Alert Banners (Update, Power warnings)
          if (availableUpdate != null) ...[
            _CompactBanner(
              icon: Icons.system_update_rounded,
              title: '새 업데이트 사용 가능',
              subtitle:
                  '${availableUpdate!['versionName']} (${availableUpdate!['channel'] ?? 'stable'})',
              color: colorScheme.secondaryContainer,
              textColor: colorScheme.onSecondaryContainer,
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const UpdatePage()),
              ),
            ),
            const SizedBox(height: 8),
          ],

          // Setup checklist (absorbs the battery warning, which used to be a
          // banner that did nothing when tapped).
          if (!isDemoActive) ...[
            SetupChecklistCard(
              powerWarnings: powerWarnings,
              revision: localRevision,
            ),
            const SizedBox(height: 8),
          ],

          // 3. Section: Top Priority Tasks ("먼저 할 일")
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 12, 4, 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Wrap(
                    crossAxisAlignment: WrapCrossAlignment.center,
                    spacing: 8,
                    runSpacing: 4,
                    children: [
                      Text(
                        '먼저 할 일',
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                          letterSpacing: -0.3,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: colorScheme.surfaceContainerHighest,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          '${pendingItems.length}',
                          style: theme.textTheme.labelSmall?.copyWith(
                            color: colorScheme.onSurfaceVariant,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      if (overdue > 0)
                        Text(
                          '· 마감 지남 $overdue개는 할 일 탭에',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: colorScheme.onSurfaceVariant,
                          ),
                        ),
                    ],
                  ),
                ),
                TextButton(
                  onPressed: onShowAllTasks,
                  style: TextButton.styleFrom(
                    visualDensity: VisualDensity.compact,
                  ),
                  child: const Text('전체 보기'),
                ),
              ],
            ),
          ),

          // Task items (up to 4 priority items) or Clean Empty State
          if (pendingItems.isEmpty)
            _EmptyTaskPlaceholder()
          else
            ...pendingItems
                .take(4)
                .map(
                  (item) => ModernTaskCard(
                    item: item,
                    excluded: excludedKeys.contains(item.key),
                    onTap: () => onTaskTap(item),
                    onVisibilityToggle: visibilityBusy.contains(item.key)
                        ? null
                        : () => onTaskVisibilityToggle(item),
                  ),
                ),

          const SizedBox(height: 16),

          // 4. Section: Today's Classes & Timeline
          if (Platform.isAndroid || Platform.isIOS)
            TodayClassesCard(
              key: ValueKey('classes:$lastSyncTime:$localRevision'),
              refreshToken: localRevision,
              compact: true,
              deadlines: [
                for (final i in pendingItems)
                  if (effectiveDue(i, now: now) != null &&
                      effectiveDue(i, now: now)!.isAfter(now) &&
                      effectiveDue(i, now: now)!.difference(now).inHours < 48)
                    (
                      at: effectiveDue(i, now: now)!,
                      label: i.title,
                      onTap: () => onTaskTap(i),
                    ),
              ],
            ),

          const SizedBox(height: 12),

          // 5. Section: Recent Notices (Shown if unread exists)
          if (unreadNotices.isNotEmpty)
            Card(
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
                side: BorderSide(
                  color: colorScheme.outlineVariant.withValues(alpha: 0.4),
                ),
              ),
              color: colorScheme.surfaceContainerLow,
              child: ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: colorScheme.primary.withValues(alpha: 0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.campaign_rounded,
                    color: colorScheme.primary,
                    size: 20,
                  ),
                ),
                title: Text(
                  '최근 미확인 공지 ${unreadNotices.length}개',
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                subtitle: Text(
                  unreadNotices.first.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: colorScheme.onSurfaceVariant,
                  ),
                ),
                trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 14),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const NoticesPage()),
                ),
              ),
            ),

          const SizedBox(height: 12),

          // 6. Section: Home Agenda Card
          HomeAgendaCard(
            key: ValueKey('agenda:$lastSyncTime:$localRevision'),
            compact: true,
          ),

          // 7. Weekly feature tip: the same card as in 더보기, shown where
          // people actually look (rotates; "추천 끄기" turns it off).
          if (!isDemoActive) ...[
            const SizedBox(height: 12),
            const FeatureRecommendation(),
          ],
        ],
      ),
    );
  }
}

class _CompactBanner extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final Color textColor;
  final VoidCallback onTap;

  const _CompactBanner({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.textColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            Icon(icon, size: 18, color: textColor),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: theme.textTheme.labelMedium?.copyWith(
                      color: textColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: textColor.withValues(alpha: 0.8),
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.chevron_right_rounded,
              size: 16,
              color: textColor.withValues(alpha: 0.7),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyTaskPlaceholder extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 20),
      margin: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerLowest,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: colorScheme.outlineVariant.withValues(alpha: 0.4),
        ),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: colorScheme.primaryContainer.withValues(alpha: 0.4),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.check_circle_outline_rounded,
              size: 32,
              color: colorScheme.primary,
            ),
          ),
          const SizedBox(height: 14),
          Text(
            '앞으로 마감할 과제가 없어요!',
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            '모든 할 일을 마쳤거나 예정된 마감이 없습니다.',
            style: theme.textTheme.bodySmall?.copyWith(
              color: colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}

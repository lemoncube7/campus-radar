import 'app_storage.dart';
import 'ai_inbox_repository.dart';
import 'campus_models.dart';
import 'ai_protocol.dart';
import 'timetable_model.dart';

class ScheduleSnapshot {
  final List<CampusItem> tasks;
  final List<Map<String, dynamic>> events;
  final List<ClassSlot> classes;
  const ScheduleSnapshot(this.tasks, this.events, this.classes);
}

String koreanDate(DateTime time) => time
    .toUtc()
    .add(const Duration(hours: 9))
    .toIso8601String()
    .substring(0, 10);
List<Map<String, dynamic>> confirmedOnDay(
  List<Map<String, dynamic>> rows,
  String day,
) => rows.where((r) {
  final st = r['state'] as Map;
  final c = r['candidate'] as ScheduleCandidate;
  if (st['status'] != 'confirmed') return false;
  final start = st['date'] as String? ?? c.date;
  final end = DateTime.tryParse(st['end'] as String? ?? '');
  var finish = end == null
      ? c.endDate
      : (st['allDay'] == true
            ? end
                  .subtract(const Duration(days: 1))
                  .toIso8601String()
                  .substring(0, 10)
            : koreanDate(end.subtract(const Duration(microseconds: 1))));
  if (finish.isEmpty) finish = start;
  return start.compareTo(day) <= 0 && finish.compareTo(day) >= 0;
}).toList();

class ScheduleRepository {
  final Store store;
  const ScheduleRepository(this.store);
  Future<ScheduleSnapshot> read() async {
    final excluded = await store.excluded();
    final tasks = (await store.items())
        .where(
          (i) =>
              i.availableAt(DateTime.now().toUtc()) &&
              !excluded.contains(i.key) &&
              !i.done,
        )
        .toList();
    final inbox = await AiInboxRepository(store).read();
    return ScheduleSnapshot(
      tasks,
      inbox.candidates,
      decodeSlots(await store.meta('timetableEntries')),
    );
  }
}

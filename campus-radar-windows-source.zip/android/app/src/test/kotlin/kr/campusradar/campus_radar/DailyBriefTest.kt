package kr.campusradar.campus_radar

import org.junit.Assert.assertEquals
import org.junit.Test

class DailyBriefTest {
    private fun lesson(start: Int, course: String, cancelled: Boolean = false) =
        DailyBrief.Lesson(start, course, cancelled)

    private fun task(days: Int, time: String, course: String, title: String) =
        DailyBrief.Task(days, time, course, title)

    @Test
    fun todayWithClassesCancellationAndOneDeadline() {
        val s = DailyBrief.sentence(
            tomorrow = false,
            lessons = listOf(lesson(780, "미적분학"), lesson(540, "글쓰기와표현", cancelled = true), lesson(900, "일반화학")),
            tasks = listOf(task(0, "23:59", "데이터과학입문", "퀴즈 정리 제출"), task(3, "18:00", "일반화학", "실험 보고서")),
        )
        assertEquals(
            "오늘 남은 수업 2개, 다음은 13:00 미적분학. 글쓰기와표현은(는) 휴강. 오늘 마감 1개(데이터과학입문 퀴즈 정리 제출, 23:59).",
            s,
        )
    }

    @Test
    fun eveningLooksAtTomorrowAndNextDeadline() {
        val s = DailyBrief.sentence(
            tomorrow = true,
            lessons = listOf(lesson(660, "미적분학"), lesson(540, "데이터과학입문")),
            tasks = listOf(task(2, "23:59", "창의설계프로젝트", "시연 영상 제출")),
        )
        assertEquals(
            "내일 수업 2개, 첫 수업은 09:00 데이터과학입문. 내일 마감은 없고 가장 가까운 건 2일 뒤 창의설계프로젝트 시연 영상 제출.",
            s,
        )
    }

    @Test
    fun emptyDayAndAllCancelled() {
        assertEquals("오늘 수업은 없어요. 남은 마감은 없어요.", DailyBrief.sentence(false, emptyList(), emptyList()))
        assertEquals(
            "오늘 수업은 모두 휴강이에요. 오늘 마감 2개(가장 이른 건 12:00 일반화학).",
            DailyBrief.sentence(
                false,
                listOf(lesson(540, "글쓰기와표현", cancelled = true)),
                listOf(task(0, "12:00", "일반화학", "예습"), task(0, "23:59", "미적분학", "과제")),
            ),
        )
    }
    @Test
    fun soonestEventJoinsTheSentence() {
        val s = DailyBrief.sentence(
            tomorrow = false,
            lessons = listOf(lesson(780, "미적분학")),
            tasks = emptyList(),
            events = listOf(
                DailyBrief.Event(5, "", "글쓰기와표현", "발표"),
                DailyBrief.Event(2, "10:00", "일반화학", "중간고사"),
            ),
        )
        assertEquals("오늘 남은 수업 1개, 다음은 13:00 미적분학. 일정: 모레 10:00 일반화학 중간고사 외 1개. 남은 마감은 없어요.", s)
    }

}

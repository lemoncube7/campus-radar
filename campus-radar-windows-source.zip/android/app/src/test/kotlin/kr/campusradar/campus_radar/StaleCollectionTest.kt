package kr.campusradar.campus_radar

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.Instant

class StaleCollectionTest {
    private val now = Instant.parse("2026-11-13T12:00:00Z")

    @Test
    fun withinADayIsFine() {
        assertNull(StaleCollection.staleDays(now.minusSeconds(23 * 3600), now))
        assertNull(StaleCollection.staleDays(null, now))
        assertNull(StaleCollection.staleDays(now.plusSeconds(60), now))
    }

    @Test
    fun countsWholeDays() {
        assertEquals(1L, StaleCollection.staleDays(now.minusSeconds(25 * 3600), now))
        assertEquals(3L, StaleCollection.staleDays(now.minusSeconds(73 * 3600), now))
    }
}

package kr.campusradar.campus_radar

import android.app.*
import android.os.Build
import android.content.*
import android.database.sqlite.SQLiteDatabase
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.*
import java.time.*

class TimetableReceiver:BroadcastReceiver(){
 override fun onReceive(context:Context,intent:Intent){
  val pending=goAsync()
  Thread {
   try {
    try {
     when(intent.action) {
      "kr.campusradar.CLASS" -> sendClass(context,intent.getStringExtra("slot")?:"")
      "kr.campusradar.MIDNIGHT" -> sendMidnight(context)
     }
    } finally {
     // Also refreshes LockStar after sendClass records the countdown token.
     // The countdown end broadcast reaches this refresh without sending an alert.
     TimetableWidget.updateAll(context)
    }
    schedule(context,true)
   } catch(e:Exception) {
    RadarData.logError(context,"시간표 알림 확인 실패","${intent.action?.substringAfterLast('.')} · 앱에서 시간표 설정을 다시 확인해 주세요.",e,"notification")
   } finally {
    pending.finish()
   }
  }.start()
 }
 companion object{
  fun settings(c:Context):Map<String,Any>{val p=c.getSharedPreferences("radar_timetable",0);return mapOf("exactAllowed" to (Build.VERSION.SDK_INT<31||c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()),"enabled" to p.getBoolean("enabled",false),"midnight" to p.getBoolean("midnight",false),"lead" to p.getInt("lead",30),"countdownAfter" to p.getInt("countdownAfter",0),"until" to p.getString("until","").orEmpty())}
  fun configure(c:Context,enabled:Boolean,midnight:Boolean,lead:Int,until:String,countdownAfter:Int=0){require(lead in listOf(15,30,60));LocalDate.parse(until);c.getSharedPreferences("radar_timetable",0).edit().putBoolean("enabled",enabled).putBoolean("midnight",midnight).putInt("lead",lead).putInt("countdownAfter",countdownAfter.coerceIn(0,120)).putString("until",until).apply();schedule(c,true)}
  private fun entries(c:Context):List<JSONObject> = RadarData.timetableEntries(c)
  private fun intent(c:Context,id:Int,action:String,slot:String=""):PendingIntent=PendingIntent.getBroadcast(c,id,Intent(c,TimetableReceiver::class.java).setAction(action).putExtra("slot",slot),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  private fun set(c:Context,at:Long,pi:PendingIntent){val am=c.getSystemService(AlarmManager::class.java);try{if(Build.VERSION.SDK_INT<31||am.canScheduleExactAlarms()){am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);return}}catch(_:SecurityException){};am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi)}
  @Synchronized fun schedule(c:Context,force:Boolean=false){
   val p=c.getSharedPreferences("radar_timetable",0)
   val rows=entries(c)
   val stamp=rows.toString()+settings(c).toString()+TimetableCancellations.read(c).toString()
   if(!force&&p.getString("stamp","")==stamp)return
   val am=c.getSystemService(AlarmManager::class.java)
   p.getStringSet("ids",emptySet()).orEmpty().forEach{am.cancel(intent(c,it.toInt(),"kr.campusradar.CLASS"))}
   am.cancel(intent(c,8100,"kr.campusradar.MIDNIGHT"));val now=ZonedDateTime.now(RadarData.schoolZone);val until=ClassTimeLogic.parseUntil(p.getString("until",""))?:now.toLocalDate().minusDays(1)
   val ids=mutableSetOf<String>()
   if(p.getBoolean("enabled",false))for(row in rows){
    val at=ClassTimeLogic.next(row.getInt("weekday"),row.getInt("start"),p.getInt("lead",30),now,until)?:continue
    val id=8200+(row.getString("id").hashCode() and 0x3fffffff);ids.add(id.toString())
    set(c,at.toInstant().toEpochMilli(),intent(c,id,"kr.campusradar.CLASS",row.getString("id")))
   }
   if(p.getBoolean("midnight",false))set(c,ClassTimeLogic.nextMidnight(now).toInstant().toEpochMilli(),intent(c,8100,"kr.campusradar.MIDNIGHT"))
   p.edit().putStringSet("ids",ids).putString("stamp",stamp).apply()
  }
  private fun notify(c:Context,id:Int,title:String,body:String):Boolean{
   val manager=NotificationManagerCompat.from(c);if(!manager.areNotificationsEnabled()){RadarData.log(c,"시간표 알림 건너뜀","알림 권한이 꺼져 있어요.");return false}
   c.getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("class_reminders","수업·자정 알림",NotificationManager.IMPORTANCE_HIGH))
   val n=NotificationCompat.Builder(c,"class_reminders").setSmallIcon(R.drawable.ic_stat_radar).setContentTitle(title).setContentText(body.lineSequence().firstOrNull()).setStyle(NotificationCompat.BigTextStyle().bigText(body)).setContentIntent(RadarData.launch(c,"_timetable",id)).setAutoCancel(true).build()
   return try{manager.notify(id,n);RadarData.log(c,"$title 발송 요청",body);true}catch(_:SecurityException){RadarData.log(c,"시간표 알림 건너뜀","알림 권한을 확인해 주세요.");false}
  }
  private fun clock(n:Int)="%02d:%02d".format(n/60,n%60)
  fun sendClass(c:Context,key:String){
   val p=c.getSharedPreferences("radar_timetable",0);if(!p.getBoolean("enabled",false))return
   val now=ZonedDateTime.now(RadarData.schoolZone);val until=ClassTimeLogic.parseUntil(p.getString("until",""))?:return;if(now.toLocalDate().isAfter(until))return
   val row=entries(c).firstOrNull{it.optString("id")==key}?:return
   // The next occurrence today or tomorrow: deriving the date from now+lead
   // dropped a late-night class whose (inexact) alarm arrived a bit late.
   val start=listOf(0L,1L).map{now.toLocalDate().plusDays(it).atStartOfDay(RadarData.schoolZone).plusMinutes(row.getInt("start").toLong())}
    .firstOrNull{it.dayOfWeek.value==row.getInt("weekday")&&it.isAfter(now)}?:return
   if(Duration.between(now,start).toMinutes()>p.getInt("lead",30)+2)return
   val isCancelled=TimetableCancellations.cancelled(c,row,start.toLocalDate())
   val token="$key:${start.toLocalDate()}";if(p.getString("sent:$key","")==token)return
   val course=RadarData.courseName(c,row)
   val room=row.optString("room").ifBlank{"강의실 미지정"}
   // Show the lead the user chose. The alarm lands a few ms after start-lead, so
   // the measured time floored to 29 for a 30-minute lead. Only a clearly late
   // alarm (2+ minutes, e.g. in Doze) shows the real minutes left.
   val lead=p.getInt("lead",30).toLong()
   val actual=((Duration.between(now,start).seconds+30)/60).coerceAtLeast(1)
   val minutesLeft=if(lead-actual>=2)actual else lead
   val title="$course 수업 시작 ${minutesLeft}분 전"+(if(isCancelled)" (휴강으로 인식됨)" else "")
   val cancellation=if(isCancelled)TimetableCancellations.find(c,row,start.toLocalDate()) else null
   val noticeTitle=cancellation?.optString("noticeTitle").orEmpty().ifBlank{cancellation?.optString("source").orEmpty()}
   val body=if(isCancelled){
    val reason=if(noticeTitle.isNotBlank())"휴강 공지: $noticeTitle" else "직접 추가된 휴강"
    "${clock(row.getInt("start"))} 시작 · $room\n$reason"
   } else "${clock(row.getInt("start"))} 시작 · $room\n강의계획서 기준 · 휴강·보강은 직접 확인"
   if(notify(c,8200+(key.hashCode() and 0x3fffffff),title,body)){p.edit().putString("sent:$key",token).apply();RadarLockAccessibilityService.instance?.requestRefresh()}
  }
  data class Countdown(val id:String,val start:Instant,val course:String,val room:String)
  fun activeCountdown(c:Context,now:ZonedDateTime=ZonedDateTime.now(RadarData.schoolZone)):Countdown?{
   val p=c.getSharedPreferences("radar_timetable",0)
   if(!p.getBoolean("enabled",false))return null
   val until=ClassTimeLogic.parseUntil(p.getString("until",""))?:return null
   return entries(c).mapNotNull{row->
    val id=row.optString("id");val sent=p.getString("sent:$id","").orEmpty()
    if(!sent.startsWith("$id:"))return@mapNotNull null
    val start=ClassTimeLogic.countdownStart(row.optInt("weekday"),row.optInt("start",-1),p.getInt("lead",30),now,until,sent.removePrefix("$id:"),p.getInt("countdownAfter",0))?:return@mapNotNull null
    val isCancelled=TimetableCancellations.cancelled(c,row,start.toLocalDate())
    val name=RadarData.courseName(c,row)+(if(isCancelled)" (휴강으로 인식됨)" else "")
    Countdown(id,start.toInstant(),name,row.optString("room"))
   }.minByOrNull{it.start}
  }
  /** One-sentence brief for the daily summary: today, or tomorrow once today's classes are over. */
  fun brief(c:Context,now:ZonedDateTime=ZonedDateTime.now(RadarData.schoolZone)):String{
   val s=RadarData.read(c);val p=c.getSharedPreferences("radar_timetable",0)
   val minute=now.hour*60+now.minute
   fun lessons(day:java.time.LocalDate,after:Int):List<DailyBrief.Lesson>{
    val until=ClassTimeLogic.parseUntil(p.getString("until",""))?:day
    if(day.isAfter(until))return emptyList()
    return entries(c).filter{it.optInt("weekday")==day.dayOfWeek.value&&it.optInt("start")>after}.map{DailyBrief.Lesson(it.optInt("start"),RadarData.courseName(c,it),TimetableCancellations.cancelled(c,it,day))}
   }
   val today=now.toLocalDate();val left=lessons(today,minute)
   val tomorrow=left.none{!it.cancelled}&&now.hour>=15
   val day=if(tomorrow)today.plusDays(1) else today
   val tasks=RadarData.pending(s).mapNotNull{t->val due=RadarData.instant(t.optString("due"))?.atZone(RadarData.schoolZone)?:return@mapNotNull null
    if(due.isBefore(now))return@mapNotNull null
    val days=java.time.temporal.ChronoUnit.DAYS.between(day,due.toLocalDate()).toInt();if(days<0)return@mapNotNull null
    DailyBrief.Task(days,clock(due.hour*60+due.minute),RadarData.courseName(c,t),t.optString("title"))}
   val events=try{val a=org.json.JSONObject(c.getSharedPreferences("FlutterSharedPreferences",0).getString("flutter.widgetSnapshotJson",null)?:"{}").optJSONArray("events")?:org.json.JSONArray()
    (0 until a.length()).mapNotNull{i->val e=a.getJSONObject(i);val d=try{java.time.LocalDate.parse(e.optString("date"))}catch(_:Exception){null}?:return@mapNotNull null
     val n=java.time.temporal.ChronoUnit.DAYS.between(today,d).toInt();if(n<0)null else DailyBrief.Event(n,e.optString("time"),e.optString("course"),e.optString("title"))}
   }catch(_:Exception){emptyList()}
   return DailyBrief.sentence(tomorrow,if(tomorrow)lessons(day,-1) else left,tasks,events)
  }
  fun sendMidnight(c:Context,test:Boolean=false){
   val p=c.getSharedPreferences("radar_timetable",0);if(!test&&!p.getBoolean("midnight",false))return
   val s=RadarData.read(c);if(!s.connected&&!test)return
   val today=ZonedDateTime.now(RadarData.schoolZone).toLocalDate();if(!test&&p.getString("midnightSent","")==today.toString())return
   val until=ClassTimeLogic.parseUntil(p.getString("until",""))?:today.minusDays(1)
   val classes=if(today.isAfter(until))emptyList()else entries(c).filter{it.optInt("weekday")==today.dayOfWeek.value}.sortedBy{it.optInt("start")}
   val tasks=RadarData.pending(s).filter{RadarData.instant(it.optString("due"))?.atZone(RadarData.schoolZone)?.toLocalDate()==today}
   val lines=classes.map{val isCancelled=TimetableCancellations.cancelled(c,it,today);"${clock(it.getInt("start"))} ${RadarData.courseName(c,it)}${if(isCancelled)" (휴강으로 인식됨)" else ""} ${it.optString("room")}"}+tasks.map{"마감 ${RadarData.instant(it.optString("due"))?.atZone(RadarData.schoolZone)?.toLocalTime()} · ${RadarData.courseName(c,it)} ${it.optString("title")}"}
   val body="${today.monthValue}/${today.dayOfMonth} 수업 ${classes.size}개 · 미완료 마감 ${tasks.size}개\n"+lines.take(12).joinToString("\n")+"\n마지막 확인 ${RadarData.stamp(s)} (한국 시간)"
   notify(c,8100,"자정 · 오늘의 수업과 과제",body);if(!test)p.edit().putString("midnightSent",today.toString()).apply()
  }
 }
}

package kr.campusradar.campus_radar

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.time.Duration
import java.time.Instant

/**
 * Background collection can stop quietly (school session lost, battery limits),
 * and every other notification keeps working from the old data. When the last
 * successful collection is over a day old, say so once; a later success resets it.
 */
object StaleCollection {
 private const val ID = 710

 /** Whole days since [last], or null while it is within a day (or unknown). */
 fun staleDays(last: Instant?, now: Instant): Long? {
  if (last == null || last.isAfter(now)) return null
  val hours = Duration.between(last, now).toHours()
  return if (hours < 24) null else hours / 24
 }

 fun check(c: Context, now: Instant = Instant.now()) {
  val s = RadarData.read(c)
  if (!s.connected) return
  val p = c.getSharedPreferences("radar_stale", 0)
  val days = staleDays(NativeTimestamp.parse(s.last), now)
  if (days == null) {
   if (p.contains("alerted")) {
    p.edit().remove("alerted").apply()
    NotificationManagerCompat.from(c).cancel(ID)
   }
   return
  }
  if (p.getString("alerted", null) == s.last) return
  val manager = NotificationManagerCompat.from(c)
  if (!manager.areNotificationsEnabled()) return
  c.getSystemService(NotificationManager::class.java)
   .createNotificationChannel(NotificationChannel("collection_status", "수집 상태", NotificationManager.IMPORTANCE_DEFAULT))
  val body = "마지막 수집 ${RadarData.stamp(s)}(한국 시간). 그동안 받은 알림도 그 시각 기준이에요. 앱을 열어 학교 연결을 확인해 주세요."
  val n = NotificationCompat.Builder(c, "collection_status").setSmallIcon(R.drawable.ic_stat_radar)
   .setContentTitle("학교 자료가 ${days}일째 갱신되지 않았어요").setContentText(body)
   .setStyle(NotificationCompat.BigTextStyle().bigText(body))
   .setContentIntent(RadarData.launch(c, "_summary", ID)).setAutoCancel(true).build()
  try {
   manager.notify(ID, n)
   p.edit().putString("alerted", s.last).apply()
   RadarData.log(c, "수집 멈춤 알림 발송 요청", "${days}일째 갱신 없음")
  } catch (_: SecurityException) {}
 }
}

package kr.campusradar.campus_radar

/**
 * One sentence that says what the day needs, for the first line of the daily
 * summary notification. Pure (no Android types) so it is unit tested.
 *
 * Before 15:00 or while classes remain it talks about today; later, with no
 * class left, it looks at tomorrow so an evening summary is still useful.
 */
object DailyBrief {
    /** A class on the target day: start in minutes from midnight. */
    data class Lesson(val start: Int, val course: String, val cancelled: Boolean)

    /** An open task: days until due (0 = target day), clock like "23:59", titles. */
    data class Task(val daysLeft: Int, val time: String, val course: String, val title: String)

    /** A confirmed event from a notice (exam, make-up class): days from today, clock or "". */
    data class Event(val daysFromToday: Int, val time: String, val course: String, val title: String)

    private fun dayWord(n: Int) = when (n) { 0 -> "오늘"; 1 -> "내일"; 2 -> "모레"; else -> "${n}일 뒤" }

    private fun clock(n: Int) = "%02d:%02d".format(n / 60, n % 60)

    /**
     * [tomorrow] true when the sentence describes tomorrow. [lessons] are the
     * target day's classes still ahead (all of them for tomorrow). [tasks] are
     * open tasks with daysLeft relative to the target day, soonest first.
     */
    fun sentence(tomorrow: Boolean, lessons: List<Lesson>, tasks: List<Task>, events: List<Event> = emptyList()): String {
        val day = if (tomorrow) "내일" else "오늘"
        val held = lessons.filter { !it.cancelled }.sortedBy { it.start }
        val cancelled = lessons.filter { it.cancelled }.map { it.course }.distinct()
        val parts = mutableListOf<String>()
        parts += when {
            held.isEmpty() && cancelled.isEmpty() -> "$day 수업은 없어요"
            held.isEmpty() -> "$day 수업은 모두 휴강이에요"
            tomorrow -> "$day 수업 ${held.size}개, 첫 수업은 ${clock(held.first().start)} ${held.first().course}"
            else -> "$day 남은 수업 ${held.size}개, 다음은 ${clock(held.first().start)} ${held.first().course}"
        }
        if (held.isNotEmpty() && cancelled.isNotEmpty()) {
            parts += "${cancelled.joinToString("·")}은(는) 휴강"
        }
        events.minByOrNull { it.daysFromToday }?.let { e ->
            val at = if (e.time.isBlank()) "" else " ${e.time}"
            val more = if (events.size > 1) " 외 ${events.size - 1}개" else ""
            parts += "일정: ${dayWord(e.daysFromToday)}$at ${e.course} ${e.title}".replace("  ", " ").trimEnd() + more
        }
        val due = tasks.filter { it.daysLeft == 0 }
        val next = tasks.filter { it.daysLeft > 0 }.minByOrNull { it.daysLeft }
        parts += when {
            due.size == 1 -> "$day 마감 1개(${due[0].course} ${due[0].title}, ${due[0].time})"
            due.size > 1 -> "$day 마감 ${due.size}개(가장 이른 건 ${due[0].time} ${due[0].course})"
            next != null -> "$day 마감은 없고 가장 가까운 건 ${next.daysLeft}일 뒤 ${next.course} ${next.title}"
            else -> "남은 마감은 없어요"
        }
        return parts.joinToString(". ") + "."
    }
}

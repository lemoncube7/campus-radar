package kr.campusradar.campus_radar.ads

import android.content.Context
import android.view.View
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.StandardMessageCodec
import io.flutter.plugin.platform.PlatformView
import io.flutter.plugin.platform.PlatformViewFactory

/**
 * Small bottom banner, only compiled into the Galaxy Store build with ads on
 * (Gradle -P galaxyStore=true -P ads=true). MainActivity finds it by reflection,
 * so other builds carry no ad SDK. The request has no app data: no keywords,
 * no content URL, nothing about the school or the user's courses.
 */
object AdBannerFactory {
    @JvmStatic
    fun register(engine: FlutterEngine, context: Context) {
        MobileAds.initialize(context)
        engine.platformViewsController.registry.registerViewFactory(
            "campus_radar/ad_banner",
            object : PlatformViewFactory(StandardMessageCodec.INSTANCE) {
                override fun create(ctx: Context, id: Int, args: Any?): PlatformView {
                    val unit = (args as? Map<*, *>)?.get("unit") as? String
                        ?: "ca-app-pub-3940256099942544/6300978111" // Google test banner
                    val view = AdView(ctx).apply {
                        setAdSize(AdSize.BANNER)
                        adUnitId = unit
                        loadAd(AdRequest.Builder().build())
                    }
                    return object : PlatformView {
                        override fun getView(): View = view
                        override fun dispose() = view.destroy()
                    }
                }
            },
        )
    }
}

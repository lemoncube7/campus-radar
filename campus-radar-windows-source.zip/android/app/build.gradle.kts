import java.util.Properties

plugins {
    id("com.android.application")
    id("kotlin-android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "kr.campusradar.campus_radar"
    compileSdk = 36

    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    defaultConfig {
        // TODO: Specify your own unique Application ID (https://developer.android.com/studio/build/application-id.html).
        applicationId = "kr.campusradar.campus_radar"
        // You can update the following values to match your application needs.
        // For more information, see: https://flutter.dev/to/review-gradle-config.
        minSdk = 26
        targetSdk = 35
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    signingConfigs {
        create("prototype") {
            val props = Properties()
            file("../../../../work/signing.properties").inputStream().use { props.load(it) }
            storeFile = file(props.getProperty("storeFile"))
            storePassword = props.getProperty("storePassword")
            keyAlias = props.getProperty("keyAlias")
            keyPassword = props.getProperty("keyPassword")
        }
    }
    buildTypes {
        release {
            // TODO: Add your own signing config for the release build.
            // Signing with the debug keys for now, so `flutter run --release` works.
            signingConfig = signingConfigs.getByName("prototype")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    // Galaxy Store build: `flutter build apk --release -P galaxyStore=true
    // --dart-define=STORE=galaxy`. The store updates the app, so the in-app
    // APK installer and its REQUEST_INSTALL_PACKAGES permission are removed.
    if (project.hasProperty("galaxyStore")) {
        val ads = project.hasProperty("ads")
        // With ads (-P ads=true): the AdMob SDK, the banner view and the app ID
        // come in only here. Without an ID, Google's public test app ID is used.
        sourceSets.getByName("release").manifest.srcFile(
            if (ads) "src/galaxyStoreAds/AndroidManifest.xml" else "src/galaxyStore/AndroidManifest.xml"
        )
        if (ads) {
            sourceSets.getByName("release").java.srcDir("src/ads/kotlin")
            defaultConfig.manifestPlaceholders["admobAppId"] =
                (project.findProperty("admobAppId") as String?)
                    ?: "ca-app-pub-3940256099942544~3347511713"
        }
    }
}

dependencies {
    if (project.hasProperty("galaxyStore") && project.hasProperty("ads")) {
        "releaseImplementation"("com.google.android.gms:play-services-ads:23.6.0")
        // The ads SDK swaps in the empty listenablefuture stub; WorkManager code
        // in MainActivity still needs the real class.
        "releaseImplementation"("com.google.guava:guava:33.3.1-android")
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

flutter {
    source = "../.."
}
dependencies {
    implementation("com.google.android.gms:play-services-auth:22.0.0")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
    implementation("androidx.work:work-runtime:2.10.2")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")
}

-dontwarn com.google.android.gms.auth.api.signin.GoogleSignIn
-dontwarn com.google.android.gms.auth.api.signin.GoogleSignInClient

# Ad banner is looked up by reflection (Galaxy Store build with ads only).
-keep class kr.campusradar.campus_radar.ads.AdBannerFactory { *; }

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:campus_radar/core/demo_state.dart';
import 'package:campus_radar/home/feature_recommendation.dart';
import 'package:campus_radar/home/setup_checklist.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;

  late Directory tempDir;
  const secureChannel = MethodChannel(
    'plugins.it_nomads.com/flutter_secure_storage',
  );

  setUp(() async {
    tempDir = Directory.systemTemp.createTempSync('campus_checklist_test_');
    await databaseFactory.setDatabasesPath(tempDir.path);
    SharedPreferences.setMockInitialValues({});
    demoModeNotifier.value = false;

    final messenger =
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    messenger.setMockMethodCallHandler(secureChannel, (call) async {
      if (call.method == 'read') return null;
      if (call.method == 'readAll') return <String, String>{};
      return null;
    });
  });

  tearDown(() {
    demoModeNotifier.value = false;
    final messenger =
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    messenger.setMockMethodCallHandler(secureChannel, null);
    try {
      tempDir.deleteSync(recursive: true);
    } catch (_) {}
  });

  Future<void> settleAsync(WidgetTester tester) async {
    for (var i = 0; i < 10; i++) {
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 20)),
      );
      await tester.pump(const Duration(milliseconds: 50));
    }
  }

  test('setup steps reflect status and skip battery off Android', () {
    final steps = setupSteps(
      notificationsAllowed: true,
      powerWarnings: const ['배터리 최적화 예외가 아니에요.'],
      widgetSeen: false,
      hasTimetable: true,
      hasGeminiKey: false,
    );
    expect(
      {for (final s in steps) s.id: s.done},
      {
        'notify': true,
        'battery': false,
        'widget': false,
        'timetable': true,
        'gemini': false,
      },
    );
    final ios = setupSteps(
      notificationsAllowed: false,
      powerWarnings: const [],
      widgetSeen: true,
      hasTimetable: false,
      hasGeminiKey: true,
      android: false,
    );
    expect(ios.map((s) => s.id), isNot(contains('battery')));
  });

  testWidgets(
    'SetupChecklistCard: 체험 모드 활성 시 숨겨지고 비활성 시 표시됨',
    (tester) async {
      demoModeNotifier.value = true;

      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: SetupChecklistCard(),
          ),
        ),
      );
      await settleAsync(tester);

      // 체험 모드 중에는 카드 자체가 숨겨짐
      expect(find.textContaining('캠퍼스레이더 제대로 쓰기'), findsNothing);
      expect(find.byType(Card), findsNothing);

      // 체험 모드 해제 시 정상 표시
      demoModeNotifier.value = false;
      await settleAsync(tester);

      expect(find.textContaining('캠퍼스레이더 제대로 쓰기'), findsOneWidget);

      // 다시 체험 모드로 전환 시 즉시 숨김
      demoModeNotifier.value = true;
      await settleAsync(tester);

      expect(find.textContaining('캠퍼스레이더 제대로 쓰기'), findsNothing);
      expect(find.byType(Card), findsNothing);
    },
  );

  testWidgets(
    'FeatureRecommendation: 체험 모드 활성 시 숨겨지고 비활성 시 표시됨',
    (tester) async {
      demoModeNotifier.value = true;

      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: FeatureRecommendation(),
          ),
        ),
      );
      await settleAsync(tester);

      // 체험 모드 중에는 주간 기능 팁 카드가 숨겨짐
      expect(find.text('이 기능도 써보세요'), findsNothing);
      expect(find.byType(Card), findsNothing);

      // 체험 모드 해제 시 정상 표시
      demoModeNotifier.value = false;
      await settleAsync(tester);

      expect(find.text('이 기능도 써보세요'), findsOneWidget);

      // 다시 체험 모드로 전환 시 즉시 숨김
      demoModeNotifier.value = true;
      await settleAsync(tester);

      expect(find.text('이 기능도 써보세요'), findsNothing);
      expect(find.byType(Card), findsNothing);
    },
  );
}

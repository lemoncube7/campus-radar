import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/schedule/schedule_calendar.dart';
import 'package:campus_radar/schedule/schedule_repository.dart';
import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'package:campus_radar/schedule/timetable_grid.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/tasks/task_presentation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('weekMonday points to upcoming Monday on Sunday and same week Monday Mon–Sat', () {
    expect(weekMonday(DateTime(2026, 11, 15, 10)), DateTime(2026, 11, 16));
    expect(weekMonday(DateTime(2026, 11, 16, 10)), DateTime(2026, 11, 16));
    expect(weekMonday(DateTime(2026, 11, 21, 22)), DateTime(2026, 11, 16));
  });

  test('classesThisWeek excludes next Monday cancellation when checked on Sunday', () {
    const slot = ClassSlot(
      courseKey: 'k1',
      course: '자료구조',
      weekday: 1,
      start: 9 * 60,
      end: 10 * 60,
      room: 'N1',
    );
    final cancelMonday = ClassCancellation(
      '2026-11-16:${slot.id}',
      slot.id,
      '2026-11-16',
      '자료구조',
      '휴강 공지',
    );
    expect(classesThisWeek([slot], [cancelMonday], DateTime(2026, 11, 15)), isEmpty);
  });

  testWidgets('TimetableGrid marks upcoming Monday cancellation when viewed on Sunday', (tester) async {
    const slot = ClassSlot(
      courseKey: 'k1',
      course: '자료구조',
      weekday: 1,
      start: 9 * 60,
      end: 10 * 60,
      room: 'N1',
    );
    final cancelMonday = ClassCancellation(
      '2026-11-16:${slot.id}',
      slot.id,
      '2026-11-16',
      '자료구조',
      '휴강 공지',
    );
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SizedBox(
            width: 500,
            height: 700,
            child: SingleChildScrollView(
              child: TimetableGrid(
                entries: const [slot],
                cancellations: [cancelMonday],
                nowOverride: DateTime(2026, 11, 15, 14),
              ),
            ),
          ),
        ),
      ),
    );
    expect(find.text('휴강'), findsOneWidget);
  });

  test('cancellationForSlotOnDate finds cancellation by slotId or course', () {
    const slot = ClassSlot(
      courseKey: 'k1',
      course: '운영체제',
      weekday: 2,
      start: 10 * 60,
      end: 11 * 60,
      room: 'N2',
    );
    const byCourse = ClassCancellation(
      '2026-11-17:other',
      'other',
      '2026-11-17',
      '운영체제',
      '학회 참석 휴강',
      noticeTitle: '11/17 휴강',
    );
    final found = cancellationForSlotOnDate(slot, const [byCourse], DateTime(2026, 11, 17));
    expect(found, isNotNull);
    expect(found!.noticeTitle, '11/17 휴강');
  });

  testWidgets('ScheduleCalendar shows cancelled class with 휴강 badge instead of hiding it', (tester) async {
    const slot = ClassSlot(
      courseKey: 'k1',
      course: '운영체제',
      weekday: 2,
      start: 10 * 60,
      end: 11 * 60,
      room: 'N2',
    );
    final cancel = ClassCancellation(
      '2026-11-17:${slot.id}',
      slot.id,
      '2026-11-17',
      '운영체제',
      '교수 학회',
      noticeTitle: '교수 학회 휴강',
    );
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: ScheduleCalendar(
            initialSelected: DateTime(2026, 11, 17),
            snapshotLoader: () async => ScheduleSnapshot(
              const [],
              const [],
              const [slot],
              [cancel],
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.text('운영체제'), findsOneWidget);
    expect(find.text('휴강'), findsOneWidget);
  });

  test('remainingText and deadlineLabel show 추가 제출 중 during extended submission window', () {
    final now = DateTime.now().toUtc();
    final due = now.subtract(const Duration(days: 1));
    final item = CampusItem(
      key: 'LR:1',
      type: 'LR',
      title: '과제 1',
      course: '알고리즘',
      courseId: 'c1',
      classNo: '01',
      contentsId: '1',
      status: 'unsubmitted',
      body: '',
      due: due,
      additionalStartsAt: due,
      additionalDue: now.add(const Duration(days: 3)),
      context: const {},
    );
    expect(remainingText(item, now: now), '추가 제출 중');
    expect(deadlineLabel(item), '추가 제출 중');
  });
}

import 'package:campus_radar/core/school_time.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('school today follows Korea, not the device zone', () {
    // 2026-11-13 18:30 UTC is already the 14th in Korea.
    expect(schoolToday(DateTime.utc(2026, 11, 13, 18, 30)), DateTime(2026, 11, 14));
    expect(schoolToday(DateTime.utc(2026, 11, 13, 14, 59)), DateTime(2026, 11, 13));
  });
}

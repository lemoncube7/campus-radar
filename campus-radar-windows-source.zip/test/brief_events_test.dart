import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/platform/android_widget_snapshot.dart';
import 'package:flutter_test/flutter_test.dart';

Map<String, dynamic> row(
  String title,
  String date, {
  String status = 'confirmed',
  String category = 'exam',
  String? movedTo,
}) => {
  'candidate': ScheduleCandidate(
    title: title,
    date: date,
    time: '10:00',
    action: '',
    evidence: '',
    uncertainty: '',
    category: category,
  ),
  'state': {'status': status, 'date': ?movedTo},
  'notice': null,
};

void main() {
  test('brief events: confirmed non-task events in the next week, soonest first', () {
    // 2026-11-13 19:00 in Korea.
    final now = DateTime.utc(2026, 11, 13, 10);
    final out = briefEvents([
      row('기말고사', '2026-11-19'),
      row('중간고사', '2026-11-15'),
      row('지난 시험', '2026-11-12'),
      row('먼 시험', '2026-11-30'),
      row('후보', '2026-11-14', status: 'pending'),
      row('과제', '2026-11-14', category: 'task'),
      row('옮긴 보강', '2026-11-01', movedTo: '2026-11-14'),
    ], now);
    expect(out.map((e) => e['title']), ['옮긴 보강', '중간고사', '기말고사']);
    expect(out.first['date'], '2026-11-14');
  });
}

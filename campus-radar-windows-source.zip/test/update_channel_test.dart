import 'dart:convert';

import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/updates/updates.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

Map<String, dynamic> _manifest(String channel, int code, String name) => {
  'channel': channel,
  'versionCode': code,
  'versionName': name,
  'apkUrl': 'https://example.com/campus-radar-$channel.apk',
  'sha256': List.filled(64, 'a').join(),
};

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('effectiveUpdateChannel respects explicit saved channel over installed', () {
    expect(effectiveUpdateChannel('stable', 'development'), 'development');
    expect(effectiveUpdateChannel('stable', 'stable'), 'stable');
    expect(effectiveUpdateChannel('stable', null), 'stable');
    expect(effectiveUpdateChannel('development', 'stable'), 'stable');
    expect(effectiveUpdateChannel('development', 'development'), 'development');
    expect(effectiveUpdateChannel('development', null), 'development');
  });

  test('checkForUpdates fetches saved development channel and records fresh channels', () async {
    sqfliteFfiInit();
    SharedPreferences.setMockInitialValues({
      PrefKey.updateChannel: 'development',
    });
    final db = await databaseFactoryFfiNoIsolate.openDatabase(
      inMemoryDatabasePath,
    );
    await db.execute(
      'CREATE TABLE meta (id TEXT PRIMARY KEY,value TEXT NOT NULL)',
    );
    await db.execute(
      'CREATE TABLE notices (id TEXT PRIMARY KEY,payload TEXT NOT NULL)',
    );
    await db.execute(
      'CREATE TABLE logs (id INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT NOT NULL,kind TEXT NOT NULL,title TEXT NOT NULL,detail TEXT NOT NULL)',
    );
    final store = Store(db);
    try {
      final loaded = <String>[];
      await checkForUpdates(
        store,
        loader: (channel) async {
          loaded.add(channel);
          return _manifest(channel, appBuild + 5, '0.6.7-dev.9');
        },
        notifier: (_) async => true,
        noticesLoader: () async => null,
        noticeNotifier: (_) async => true,
      );
      expect(loaded, containsAll(['stable', 'development']));
      final p = await SharedPreferences.getInstance();
      expect(
        jsonDecode(p.getString('updateInfo:development')!)['versionName'],
        '0.6.7-dev.9',
      );
      expect(
        p.getStringList('updateFreshChannels'),
        containsAll(['stable', 'development']),
      );
    } finally {
      await store.db.close();
    }
  });

  test('failed channel check keeps fresh channel list without un-fetched channel', () async {
    sqfliteFfiInit();
    SharedPreferences.setMockInitialValues({
      PrefKey.updateChannel: 'development',
    });
    final db = await databaseFactoryFfiNoIsolate.openDatabase(
      inMemoryDatabasePath,
    );
    await db.execute(
      'CREATE TABLE meta (id TEXT PRIMARY KEY,value TEXT NOT NULL)',
    );
    await db.execute(
      'CREATE TABLE notices (id TEXT PRIMARY KEY,payload TEXT NOT NULL)',
    );
    await db.execute(
      'CREATE TABLE logs (id INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT NOT NULL,kind TEXT NOT NULL,title TEXT NOT NULL,detail TEXT NOT NULL)',
    );
    final store = Store(db);
    try {
      await checkForUpdates(
        store,
        loader: (channel) async {
          if (channel == 'development') {
            throw Exception('network error');
          }
          return _manifest(channel, appBuild, '0.6.6');
        },
        notifier: (_) async => true,
        noticesLoader: () async => null,
        noticeNotifier: (_) async => true,
      );
      final p = await SharedPreferences.getInstance();
      expect(p.getStringList('updateFreshChannels'), ['stable']);
      expect(p.getString(PrefKey.updateCheckError), isNotEmpty);
    } finally {
      await store.db.close();
    }
  });
}

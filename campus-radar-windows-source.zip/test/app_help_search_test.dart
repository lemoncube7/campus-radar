import 'package:campus_radar/settings/app_help_catalog.dart';
import 'package:campus_radar/settings/app_help_page.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('feature search finds Korean topics by English words', () {
    bool any(String q) => appHelpTopics.any((t) => helpTopicMatches(t, q));
    expect(any('widget'), isTrue);
    expect(any('calendar'), isTrue);
    expect(any('위젯'), isTrue);
    expect(any('dark'), isTrue);
    expect(any('다크'), isTrue);
    expect(any('숨김'), isTrue);
    expect(any('복구'), isTrue);
    expect(any('로그'), isTrue);
    expect(any('내보내기'), isTrue);
    expect(any('잠금'), isTrue);
    expect(any('알림'), isTrue);
    expect(any('zzzz'), isFalse);
  });
}

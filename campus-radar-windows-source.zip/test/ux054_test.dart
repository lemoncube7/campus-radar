import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/ai/audience_review_repository.dart';
import 'package:campus_radar/ai/audience_review_groups.dart';
import 'package:campus_radar/ai/ai_inbox_page.dart';
import 'package:campus_radar/ai/ai_inbox_repository.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/courses/course_colors.dart';
import 'package:campus_radar/ai/notice_ai_service.dart';
import 'package:campus_radar/notices/notice_pages.dart';
import 'package:campus_radar/navigation/app_router.dart';
import 'package:campus_radar/home/home_navigation.dart';
import 'package:campus_radar/main.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';
import 'package:campus_radar/schedule/timetable_grid.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'package:campus_radar/schedule/today_class_model.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  late CampusNotice notice;
  late List<ScheduleCandidate> candidates;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    homeNavigation.value = null;
    temp = await Directory.systemTemp.createTemp('ux054-');
    await databaseFactory.setDatabasesPath(temp.path);
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          (c) async => c.method == 'read' ? 'synthetic' : null,
        );
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('campus_radar/native'),
          (c) async =>
              c.method == 'timetableSettings' ? {'until': '2099-12-31'} : null,
        );
    notice = CampusNotice(
      id: 'n',
      title: '발표 안내',
      course: '가상 과목',
      context: {'course_id': 'c', 'class_no': '1'},
      body: '2029년 11월 1일 13:00 발표. 2029년 11월 8일 13:00 발표. 각 주차 발표자만 해당해요.',
      bodyFetched: true,
    );
    candidates = [
      for (final day in ['01', '08'])
        ScheduleCandidate(
          title: '$day 발표',
          date: '2029-11-$day',
          time: '13:00',
          action: 'add',
          evidence: notice.body,
          uncertainty: '해당 주차 발표자만 대상',
          category: 'presentation',
          condition: 'conditional',
        ),
    ];
    final store = await Store.open();
    try {
      await store.saveNotice(notice);
      await rememberCandidates(store, notice, candidates);
    } finally {
      await store.db.close();
    }
  });
  tearDown(() async {
    homeNavigation.value = null;
    for (final channel in [
      'plugins.it_nomads.com/flutter_secure_storage',
      'campus_radar/native',
    ]) {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(MethodChannel(channel), null);
    }
    await temp.delete(recursive: true);
  });
  Future<void> settle(WidgetTester t) async {
    for (var i = 0; i < 6; i++) {
      await t.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 70)),
      );
      await t.pump();
    }
    await t.pumpAndSettle();
  }

  Future<void> close(WidgetTester t) async {
    await t.pumpWidget(const SizedBox.shrink());
    await settle(t);
  }

  test(
    'Next class crosses date boundaries, respects cancellation and term end',
    () {
      const today = ClassSlot(
        courseKey: 'c:1',
        course: '예시',
        weekday: 3,
        start: 780,
        end: 840,
      );
      const tomorrow = ClassSlot(
        courseKey: 'd:1',
        course: '다음',
        weekday: 4,
        start: 600,
        end: 660,
      );
      final now = DateTime(2026, 10, 28, 12);
      expect(
        nextClassOccurrence([today, tomorrow], [], now)!.slot.course,
        '예시',
      );
      final cancelled = [
        ClassCancellation('x', today.id, '2026-10-28', '예시', '공지'),
      ];
      final occ = nextClassOccurrence([today, tomorrow], cancelled, now)!;
      expect(occ.day, DateTime(2026, 10, 28));
      expect(occ.isCancelled, isTrue);
      expect(
        nextClassOccurrence(
          [today, tomorrow],
          cancelled,
          now,
          until: DateTime(2026, 10, 28),
        )!.day,
        DateTime(2026, 10, 28),
      );
      expect(
        nextClassOccurrence(
          [today, tomorrow],
          [],
          DateTime(2026, 10, 28, 14),
        )!.slot.course,
        '다음',
      );
    },
  );
  test(
    'Audience selection changes only pending review state and undo preserves later edits',
    () async {
      final store = await Store.open();
      try {
        final keys = candidates.map((c) => candidateKey(notice, c)).toList();
        final receipt = await AudienceReviewRepository(
          store,
        ).apply(keys, {keys.first});
        final first =
            jsonDecode((await store.meta('aiState:${keys.first}'))!) as Map;
        final second =
            jsonDecode((await store.meta('aiState:${keys.last}'))!) as Map;
        expect(first['status'], 'review');
        expect(first['audienceConfirmed'], true);
        expect(second['status'], 'excluded');
        expect(first['calendarSent'], isNot(true));
        await AudienceReviewRepository(store).undo(receipt);
        expect(await store.meta('aiState:${keys.first}'), isNull);
        final again = await AudienceReviewRepository(
          store,
        ).apply(keys, {keys.first});
        final current =
            jsonDecode((await store.meta('aiState:${keys.first}'))!) as Map;
        await store.setMeta(
          'aiState:${keys.first}',
          jsonEncode({...current, 'status': 'confirmed'}),
        );
        await expectLater(
          AudienceReviewRepository(store).undo(again),
          throwsFormatException,
        );
        expect(
          jsonDecode((await store.meta('aiState:${keys.last}'))!)['status'],
          'excluded',
        );
      } finally {
        await store.db.close();
      }
    },
  );
  testWidgets(
    'Source and stored AI results share one scroll without a nested Scaffold',
    (t) async {
      t.view.physicalSize = const Size(380, 900);
      t.view.devicePixelRatio = 1;
      addTearDown(t.view.resetPhysicalSize);
      addTearDown(t.view.resetDevicePixelRatio);
      await t.pumpWidget(
        MaterialApp(
          onGenerateRoute: buildAppRoute,
          home: NoticeDetailPage(notice: notice),
        ),
      );
      await settle(t);
      expect(find.text('공지 내용'), findsOneWidget);
      await t.tap(find.text('공지에서 찾은 일정 2'));
      await settle(t);
      expect(find.byType(AiInboxPage), findsOneWidget);
      expect(find.byType(Scaffold), findsOneWidget);
      expect(find.text('01 발표'), findsWidgets);
      expect(t.takeException(), isNull);
      await close(t);
    },
  );
  testWidgets(
    'One audience answer removes irrelevant rows, retains selected review and offers undo',
    (t) async {
      await t.pumpWidget(
        const MaterialApp(home: AiInboxPage(showTools: false)),
      );
      await settle(t);
      final group = find.textContaining('해당 여부 한 번에 정리');
      await t.scrollUntilVisible(
        group,
        200,
        scrollable: find.byType(Scrollable).first,
      );
      await t.tap(group);
      await settle(t);
      expect(find.byType(CheckboxListTile), findsNWidgets(2));
      await t.tap(find.byType(CheckboxListTile).first);
      await t.pump();
      await t.tap(find.text('1개 해당 · 나머지 제외'));
      await settle(t);
      expect(find.byType(CheckboxListTile), findsNothing);
      await t.runAsync(() async {
        final store = await Store.open();
        try {
          final snapshot = await AiInboxRepository(store).read();
          expect(audienceReviewGroups(snapshot.candidates), isEmpty);
          expect(
            snapshot.candidates
                .where((r) => r['state']['status'] == 'review')
                .length,
            1,
          );
        } finally {
          await store.db.close();
        }
      });
      expect(find.text('실행 취소'), findsOneWidget);
      await t.tap(find.text('실행 취소'));
      await settle(t);
      expect(find.textContaining('해당 여부 한 번에 정리'), findsOneWidget);
      expect(t.takeException(), isNull);
      await close(t);
    },
  );
  testWidgets(
    'Review and timetable remain reachable as standalone tools from more',
    (t) async {
      t.view.physicalSize = const Size(600, 960);
      t.view.devicePixelRatio = 1;
      addTearDown(t.view.resetPhysicalSize);
      addTearDown(t.view.resetDevicePixelRatio);

      await t.pumpWidget(const RadarApp(home: Dashboard(autoSync: false)));
      await settle(t);
      await t.tap(find.widgetWithText(NavigationDestination, '할 일'));
      await settle(t);
      expect(find.byType(SegmentedButton<ScheduleView>), findsNothing);
      await t.tap(find.widgetWithText(NavigationDestination, '더보기'));
      await settle(t);
      await t.tap(find.text('검토함'));
      await settle(t);
      expect(find.byType(AiInboxPage), findsOneWidget);
      expect(find.byType(NavigationBar), findsNothing);
      Navigator.of(t.element(find.byType(AiInboxPage))).pop();
      await settle(t);
      expect(find.widgetWithText(NavigationDestination, '더보기'), findsOneWidget);
      expect(t.takeException(), isNull);
      await close(t);
    },
  );
  testWidgets(
    'TimetableGrid class detail sheet shows cancellation status and removes cancellation on tap',
    (t) async {
      final now = DateTime.now().toUtc().add(const Duration(hours: 9));
      final monday = DateTime(
        now.year,
        now.month,
        now.day,
      ).subtract(Duration(days: now.weekday - 1));
      final nextMonday = monday.add(const Duration(days: 7));
      final nextMondayStr =
          '${nextMonday.year.toString().padLeft(4, '0')}-${nextMonday.month.toString().padLeft(2, '0')}-${nextMonday.day.toString().padLeft(2, '0')}';

      const slot = ClassSlot(
        course: '데이터구조',
        courseKey: 'c2:01',
        weekday: 1,
        start: 10 * 60,
        end: 12 * 60,
        room: '공학관 202',
      );
      final cancel = ClassCancellation(
        'cancel-ds-1',
        slot.id,
        nextMondayStr,
        '데이터구조',
        '학회 참석 휴강',
      );
      await t.runAsync(() async {
        final store = await Store.open();
        try {
          await CancellationRepository(store).apply([cancel]);
        } finally {
          await store.db.close();
        }
      });

      var changedCalls = 0;
      await t.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: TimetableGrid(
              entries: const [slot],
              cancellations: [cancel],
              onChanged: () async {
                changedCalls++;
              },
            ),
          ),
        ),
      );
      await settle(t);

      await t.tap(find.text('데이터구조'));
      await settle(t);

      expect(
        find.text('${nextMonday.month}/${nextMonday.day} 휴강 반영됨'),
        findsOneWidget,
      );
      expect(find.text('휴강 해제'), findsOneWidget);
      expect(find.byTooltip('닫기'), findsOneWidget);

      await t.tap(find.text('휴강 해제'));
      await settle(t);

      expect(changedCalls, 1);
      await t.runAsync(() async {
        final store = await Store.open();
        try {
          final remaining =
              (await CancellationRepository(store).read()).entries;
          expect(remaining, isEmpty);
        } finally {
          await store.db.close();
        }
      });
      await t.pump(const Duration(seconds: 9));
      await close(t);
    },
  );
  test('All 12 course picker colors have distinct spoken accessibility names', () {
    expect(coursePickerColors.length, 12);
    final names = coursePickerColors.map(spokenColorName).toList();
    expect(names.toSet().length, 12);
    expect(names.any((n) => n == '선택'), isFalse);
  });
}

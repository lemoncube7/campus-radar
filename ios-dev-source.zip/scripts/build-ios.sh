#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
flutter pub get
flutter analyze
flutter test
ruby scripts/configure-ios-widgets.rb
# iPhone keeps its own 0.5.x numbering until it matches Android 0.6.0.
IOS_VERSION="${IOS_VERSION:-0.5.6}"
IOS_BUILD="${IOS_BUILD:-84}"
flutter build ios --release --no-codesign --dart-define=RELEASE_CHANNEL=stable \
  --build-name="$IOS_VERSION" --build-number="$IOS_BUILD" \
  --dart-define=APP_VERSION="$IOS_VERSION" --dart-define=APP_BUILD="$IOS_BUILD"
# Preserve requested App Group entitlements for AltStore to inspect and remap.
# These ad-hoc signatures are replaced by the user's AltStore signing identity.
codesign --force --sign - --entitlements ios/RadarWidgets/RadarWidgets.entitlements build/ios/iphoneos/Runner.app/PlugIns/RadarWidgets.appex
codesign --force --sign - --entitlements ios/Runner/Runner.entitlements build/ios/iphoneos/Runner.app
mkdir -p build/ios/altstore/Payload
cp -R build/ios/iphoneos/Runner.app build/ios/altstore/Payload/
cd build/ios/altstore
zip -qry campus-radar.ipa Payload
shasum -a 256 campus-radar.ipa > campus-radar.ipa.sha256
echo "Unsigned IPA ready for AltStore Classic: $PWD/campus-radar.ipa"


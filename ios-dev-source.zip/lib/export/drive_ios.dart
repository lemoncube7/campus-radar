import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/export/drive_uploader.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:path_provider/path_provider.dart';

/// iPhone implementation of the Android Drive channel (driveConnect,
/// driveAccounts, driveConfigure, driveDisconnect, driveEnqueue), so the
/// shared connection page and export preparation work unchanged.
///
/// Differences from Android, by platform necessity:
/// - Google Sign-In on iOS keeps one signed-in account; connecting another
///   replaces it.
/// - There is no 15-minute worker: uploads run after each collection and when
///   the user asks, while the app is running.
const googleIosClientId = String.fromEnvironment('GOOGLE_IOS_CLIENT_ID');
bool get driveIosAvailable => Platform.isIOS && googleIosClientId.isNotEmpty;

class DriveIos {
  DriveIos._();
  static final instance = DriveIos._();
  final _google = GoogleSignIn(
    clientId: googleIosClientId.isEmpty ? null : googleIosClientId,
    scopes: const [DriveApi.scope],
  );
  Future<void>? _running;
  bool _again = false;

  Future<File> _file(String name) async =>
      File('${(await getApplicationSupportDirectory()).path}/$name');

  Future<Map<String, dynamic>> _accounts() async {
    final f = await _file('drive-targets-v1.json');
    if (!await f.exists()) return {};
    try {
      return Map<String, dynamic>.from(jsonDecode(await f.readAsString()));
    } catch (_) {
      return {};
    }
  }

  Future<void> _save(Map<String, dynamic> accounts) async {
    final f = await _file('drive-targets-v1.json');
    final tmp = File('${f.path}.tmp');
    await tmp.writeAsString(jsonEncode(accounts), flush: true);
    await tmp.rename(f.path);
  }

  static String _uuid() {
    final r = Random.secure();
    return List.generate(
      16,
      (_) => r.nextInt(256),
    ).map((b) => b.toRadixString(16).padLeft(2, '0')).join();
  }

  Map<String, dynamic> _row(String id, Map r) => {
    'id': id,
    'binding': '${r['binding'] ?? ''}',
    'accountHash': '${r['accountHash'] ?? ''}',
    'email': '${r['email'] ?? ''}',
    'enabled': r['enabled'] == true,
    'lastSuccess': '${r['lastSuccess'] ?? ''}',
    'error': '${r['error'] ?? ''}',
    'folderUrl': '${r['folder'] ?? ''}'.isEmpty
        ? ''
        : 'https://drive.google.com/drive/folders/${r['folder']}',
    'options': r['options'] == null ? null : jsonEncode(r['options']),
  };

  Future<List<Map<String, dynamic>>> rows() async => [
    for (final e in (await _accounts()).entries)
      _row(e.key, Map.from(e.value as Map)),
  ];

  Future<Map<String, dynamic>?> connect() async {
    if (!driveIosAvailable) {
      throw const FormatException('iPhone Drive 연결이 이 빌드에서 아직 설정되지 않았어요.');
    }
    // One Google account at a time on iOS: start a fresh sign-in.
    await _google.signOut().catchError((_) => null);
    final user = await _google.signIn();
    if (user == null) return null;
    if (!await _google.requestScopes(const [DriveApi.scope])) {
      throw const FormatException('Drive 권한을 허용하지 않았어요.');
    }
    final accounts = await _accounts();
    // Replacing the account clears other rows (their tokens are gone).
    accounts.removeWhere((k, v) => (v as Map)['email'] != user.email);
    final id = user.id;
    final r = Map<String, dynamic>.from(
      accounts[id] as Map? ?? {'enabled': false, 'binding': _uuid()},
    )..['email'] = user.email;
    r['error'] = '';
    accounts[id] = r;
    await _save(accounts);
    return _row(id, r);
  }

  Future<void> configure(Map args) async {
    final accounts = await _accounts();
    final id = '${args['id']}';
    final r = Map<String, dynamic>.from(accounts[id] as Map);
    final hash = '${args['accountHash'] ?? ''}';
    final previous = '${r['accountHash'] ?? ''}';
    if (previous.isNotEmpty && previous != hash) {
      for (final k in [
        'folder',
        'files',
        'hashes',
        'courseFolder',
        'lastSuccess',
        'lastSnapshot',
      ]) {
        r.remove(k);
      }
    }
    r
      ..['enabled'] = args['enabled'] == true
      ..['accountHash'] = hash
      ..['options'] = Map<String, dynamic>.from(args['options'] as Map? ?? {})
      ..['binding'] = _uuid()
      ..['error'] = '';
    accounts[id] = r;
    await _save(accounts);
  }

  Future<void> disconnect(String id) async {
    final accounts = await _accounts()
      ..remove(id);
    await _save(accounts);
    if (accounts.isEmpty) await _google.signOut().catchError((_) => null);
  }

  /// Runs an upload now; a request during a run queues one more pass.
  Future<void> enqueue({bool manual = false}) {
    if (_running != null) {
      _again = true;
      return _running!;
    }
    final run = () async {
      do {
        _again = false;
        await _upload(manual: manual);
      } while (_again);
    }();
    _running = run.whenComplete(() => _running = null);
    return _running!;
  }

  Future<void> _log(String title, String detail) async {
    final s = await Store.open();
    try {
      await s.log('app', title, detail);
    } finally {
      await s.db.close();
    }
  }

  Future<void> _upload({required bool manual}) async {
    if (!driveIosAvailable) return;
    final snapFile = await _file('drive-export-v1.json');
    if (!await snapFile.exists()) {
      if (manual) await _log('Drive 전송 건너뜀', '보낼 자료가 아직 준비되지 않았어요.');
      return;
    }
    final snapshot = Map<String, dynamic>.from(
      jsonDecode(await snapFile.readAsString()) as Map,
    );
    final s = await Store.open();
    String? epoch;
    try {
      epoch = await s.meta(MetaKey.sessionEpoch);
    } finally {
      await s.db.close();
    }
    if (snapshot['epoch'] != epoch) return;
    final payloads = Map<String, dynamic>.from(
      snapshot['accounts'] as Map? ?? {},
    );
    final accounts = await _accounts();
    for (final id in accounts.keys.toList()) {
      final row = Map<String, dynamic>.from(accounts[id] as Map);
      final payload = payloads[id] as Map?;
      if (row['enabled'] != true || payload == null) continue;
      if (row['accountHash'] != snapshot['accountHash'] ||
          row['binding'] != payload['binding']) {
        continue;
      }
      final binding = row['binding'];
      Future<void> checkpoint() async {
        final live = await _accounts();
        if ((live[id] as Map?)?['binding'] != binding) {
          throw StateError('Drive settings changed during upload');
        }
        live[id] = row;
        await _save(live);
      }

      try {
        final user = _google.currentUser ?? await _google.signInSilently();
        if (user == null || user.email != row['email']) {
          throw const DriveHttpFailure(401);
        }
        final token = (await user.authentication).accessToken;
        if (token == null) throw const DriveHttpFailure(401);
        final result = await uploadDriveDocuments(
          api: DriveApi(token),
          state: row,
          documents: Map<String, String>.from(payload['documents'] as Map),
          checkpoint: checkpoint,
        );
        final changed = row['lastSnapshot'] != payload['revision'];
        if (result.complete) {
          row
            ..['lastSuccess'] = DateTime.now().toUtc().toIso8601String()
            ..['lastSnapshot'] = payload['revision']
            ..['error'] = '';
        } else {
          row['error'] = '일부 자료를 갱신했어요. 다음 전송에서 이어서 보내요.';
          _again = true;
        }
        await checkpoint();
        if (changed || !result.complete) {
          await _log(
            result.complete ? 'Drive 자동 내보내기 완료' : 'Drive 자동 내보내기 일부 완료',
            '${row['email']}: 문서 ${result.writes}개를 갱신했어요.',
          );
        }
      } on StateError {
        return; // settings changed; the new configuration prepares again
      } catch (e) {
        final code = e is DriveHttpFailure ? e.status : 0;
        row['error'] = switch (code) {
          401 => 'Google 계정에 다시 연결해 주세요.',
          403 => 'Drive 권한·API 설정 또는 사용량을 확인해 주세요.',
          429 || >= 500 => 'Drive가 잠시 응답하지 않아요. 다음 수집 때 다시 시도해요.',
          _ => '전송을 마치지 못했어요. 인터넷을 확인한 뒤 다시 전송해 주세요.',
        };
        try {
          await checkpoint();
        } catch (_) {}
        await _log('Drive 자동 내보내기 대기', '${row['email']}: ${row['error']}');
      }
    }
  }
}

/// Handles the Android Drive channel names on iPhone (see native_bridge).
Future<dynamic> driveIosMethod(String method, dynamic args) async {
  final d = DriveIos.instance;
  final a = args is Map ? args : const {};
  switch (method) {
    case 'driveAccounts':
      return d.rows();
    case 'driveConnect':
      return d.connect();
    case 'driveConfigure':
      return d.configure(a);
    case 'driveDisconnect':
      return d.disconnect('${a['id']}');
    case 'driveEnqueue':
      // Preparation awaits this call; the upload continues on its own.
      unawaited(d.enqueue(manual: a['manual'] == true));
      return null;
  }
  return null;
}

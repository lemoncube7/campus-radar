import 'package:campus_radar/export/drive_sync.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/courses/course_colors.dart';
import 'package:campus_radar/tasks/dashboard_model.dart';
import 'package:campus_radar/campus/power_status.dart';
import 'package:campus_radar/courses/materials_page.dart';
import 'package:campus_radar/campus/learning_resources.dart';
import 'package:campus_radar/session/session_lifetime.dart';
import 'package:campus_radar/core/foreground_entry.dart';
import 'package:campus_radar/core/startup_diagnostics.dart';
import 'package:campus_radar/core/adaptive_content.dart';
import 'package:campus_radar/session/session_lifetime_repository.dart';
import 'package:campus_radar/session/session_probe_policy.dart';
import 'package:campus_radar/campus/campus_session.dart';
import 'package:campus_radar/campus/collection_control.dart';
import 'package:campus_radar/home/feature_discovery.dart';
import 'package:campus_radar/tasks/task_display_preferences.dart';
import 'package:campus_radar/tasks/task_categories.dart';
import 'package:campus_radar/core/transient_message.dart';
import 'package:campus_radar/platform/ios_features.dart';
import 'package:campus_radar/home/home_navigation.dart';
import 'package:campus_radar/navigation/workspace_navigation.dart';
import 'package:campus_radar/home/home_connection_status.dart';
import 'package:campus_radar/session/session_lifetime_probe.dart';
import 'package:campus_radar/home/home_agenda_card.dart';
import 'package:campus_radar/tasks/dashboard_repository.dart';
import 'package:campus_radar/navigation/app_router.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/courses/courses_page.dart';
import 'package:campus_radar/ai/ai_chat_page.dart';
import 'package:campus_radar/ai/ai_daily_card.dart';
import 'package:campus_radar/settings/settings_page.dart';
import 'package:campus_radar/campus/account_service.dart';
import 'package:campus_radar/tasks/task_presentation.dart';
import 'package:campus_radar/session/background_status_page.dart';
import 'package:campus_radar/notices/notice_pages.dart';
import 'package:campus_radar/updates/update_page.dart';
import 'package:campus_radar/core/navigation_key.dart';
import 'package:campus_radar/navigation/app_navigation.dart';
import 'package:campus_radar/schedule/today_classes_card.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/notification_gateway.dart';

import 'package:campus_radar/courses/course_aliases.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/campus/portal_connect.dart';
import 'package:campus_radar/core/ui_refresh.dart';
import 'package:campus_radar/platform/desktop.dart';
import 'package:campus_radar/settings/radar_theme.dart';
import 'package:campus_radar/updates/updates.dart';
import 'package:campus_radar/ai/ai_automation.dart';
import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:workmanager/workmanager.dart';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/campus/services.dart';

Future<void> main(List<String> args) async {
  WidgetsFlutterBinding.ensureInitialized();
  if (Platform.isWindows) await initializeDesktop(args);
  await retireSessionExploration();
  await loadInstalledVersion();
  await loadRadarTheme();
  await loadTaskDisplayPreferences().catchError((_) {});
  runApp(const RadarApp());
}

class RadarApp extends StatelessWidget {
  final Widget? home;
  const RadarApp({super.key, this.home});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: Listenable.merge([
      radarThemeMode,
      radarAccent,
      radarSecondaryAccent,
    ]),
    builder: (context, _) => MaterialApp(
      onGenerateRoute: buildAppRoute,
      navigatorKey: navKey,
      debugShowCheckedModeBanner: false,
      title: '캠퍼스레이더',
      theme: radarTheme(Brightness.light),
      darkTheme: radarTheme(Brightness.dark),
      themeMode: radarThemeMode.value,
      home: home ?? const StartupGate(),
    ),
  );
}

Future<String?> initializeServices() async {
  startupStage = '수집 설정 복원';
  await retireSessionExploration();
  if (Platform.isIOS) {
    iosRefreshHandler = updateIosFeatures;
    iosMidnightTestHandler = testIosMidnight;
  }
  if (Platform.isAndroid || Platform.isIOS) {
    bridge.setMethodCallHandler((call) async {
      if (call.method == 'openTarget') {
        await openItem(call.arguments as String?);
      }
    });
  }
  startupStage = '저장된 과목 설정 읽기';
  await loadCourseAliases();
  await loadCourseColors();
  startupStage = '앱 버전 기록';
  await recordInstalledVersion();
  startupStage = '알림 초기화';
  await initNotifications(onTap: openItem).timeout(const Duration(seconds: 15));
  if (!Platform.isWindows) {
    startupStage = '백그라운드 작업 준비';
    await Workmanager()
        .initialize(backgroundDispatcher)
        .timeout(const Duration(seconds: 15));
  }
  startupStage = '수집 작업 예약';
  await registerSessionLifetimeProbe();
  if (await credentials.read(key: 'id').timeout(const Duration(seconds: 15)) !=
      null) {
    await registerBackground().timeout(const Duration(seconds: 15));
  }
  if (Platform.isAndroid) {
    try {
      final settings = await bridge.invokeNativeMap<String, dynamic>(
        NativeMethod.dailySettings,
      );
      await scheduleSummaryWarmup(
        settings?['hour'] ?? 18,
        settings?['minute'] ?? 0,
        settings?['enabled'] == true,
      );
    } catch (_) {
      // Native daily settings are restored again on the next start.
    }
  }
  startupStage = '실행 경로 확인';
  final launch = await notifications.getNotificationAppLaunchDetails().timeout(
    const Duration(seconds: 15),
  );
  if (Platform.isAndroid || Platform.isIOS) {
    final target = await bridge.invokeNative<String>(
      NativeMethod.takeLaunchTarget,
    );
    if (target != null) return target;
  }
  return (launch?.didNotificationLaunchApp ?? false)
      ? launch?.notificationResponse?.payload
      : null;
}

class StartupGate extends StatefulWidget {
  final Future<String?> Function()? initializer;
  const StartupGate({super.key, this.initializer});
  @override
  State<StartupGate> createState() => _StartupGateState();
}

class _StartupGateState extends State<StartupGate> {
  bool ready = false;
  bool starting = false;
  Map<String, String>? diagnostic;
  String? failure;
  @override
  void initState() {
    super.initState();
    start();
  }

  Future<void> start() async {
    if (starting) return;
    starting = true;
    setState(() {
      failure = null;
    });
    try {
      final target = await (widget.initializer ?? initializeServices)();
      if (!mounted) return;
      setState(() {
        ready = true;
      });
      if (target != null) {
        WidgetsBinding.instance.addPostFrameCallback((_) => openItem(target));
      }
    } catch (e) {
      diagnostic = startupDiagnostic(e, startupStage);
      unawaited(persistStartupDiagnostic(diagnostic!));
      if (!mounted) return;
      setState(() {
        failure = e is PlatformException
            ? '기기 기능을 준비하지 못했어요 (${e.code}).'
            : e is DatabaseException
            ? storageFailureAdvice(storageFailureCode(e))
            : '앱 초기화를 완료하지 못했어요. 다시 시도해 주세요.';
      });
    } finally {
      starting = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (ready) return const Dashboard();
    return Scaffold(
      appBar: AppBar(title: const Text('캠퍼스레이더')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.radar, size: 64),
              const SizedBox(height: 20),
              const Text(
                '캠퍼스레이더',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              if (failure == null) ...[
                const CircularProgressIndicator(),
                const SizedBox(height: 16),
                const Text('기기 설정을 준비하고 있어요.'),
              ] else ...[
                Text(failure!, textAlign: TextAlign.center),
                const SizedBox(height: 16),
                FilledButton(onPressed: start, child: const Text('다시 시도')),
                if (diagnostic != null)
                  TextButton.icon(
                    onPressed: () async {
                      await Clipboard.setData(
                        ClipboardData(text: jsonEncode(diagnostic)),
                      );
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('계정 정보가 없는 진단 내용을 복사했어요.'),
                            duration: Duration(seconds: 3),
                          ),
                        );
                      }
                    },
                    icon: const Icon(Icons.copy_outlined),
                    label: const Text('진단 정보 복사'),
                  ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class Dashboard extends StatefulWidget {
  final bool autoSync;
  const Dashboard({super.key, this.autoSync = true});
  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> with WidgetsBindingObserver {
  CampusItem? desktopSelected;
  Timer? clockRefresh;
  SessionLifetime? connectionObservation;
  Map<String, dynamic>? availableUpdate;
  // Battery/background warnings live in PowerStatus; the dashboard only
  // rebuilds when they change.
  final power = PowerStatus();
  void powerChanged() {
    if (mounted) setState(() {});
  }

  Future<void> openPowerSetting(String method) async {
    try {
      await bridge.invokeMethod(method);
    } catch (_) {
      if (mounted) {
        showTransientMessage(
          context,
          const SnackBar(content: Text('설정을 열지 못했어요. 휴대전화 설정에서 직접 확인해 주세요.')),
        );
      }
    }
  }

  int section = 0;
  int localRevision = 0;
  final taskSearch = TextEditingController();
  bool sessionTesting = false, automaticConnection = true;
  // List filter state (type, course, deadline, sort, query, toggles).
  final filter = TaskFilter();
  List<CampusItem> items = [];
  bool loggedIn = false, busy = false;

  /// New lists are on screen; only attachments/follow-up work remain.
  bool listsReady = false;
  bool accountChecked = false, reloading = false;
  String? storageError;
  List<CampusNotice> homeNotices = [];
  Set<String> excluded = {}, notTaskKeys = {};
  String? error, last;
  String syncPhase = '확인 준비';
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    homeNavigation.addListener(onHomeRequest);
    showWaitingAssignments.addListener(displayPreferenceChanged);
    power.addListener(powerChanged);
    loadTaskDisplayPreferences().catchError((_) {});
    if (homeNavigation.value != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) => onHomeRequest());
    }
    power.check();
    if (Platform.isIOS) setIosAiActive(true);
    if (Platform.isWindows) desktopChanged.addListener(desktopReload);
    clockRefresh = Timer.periodic(const Duration(minutes: 1), (_) {
      if (mounted) {
        reload();
        power.check();
      }
    });
    // The startup collection prepares the Drive export itself at its end;
    // the first reload must not start a competing one (device test build 75,
    // 13:17 '[앱 시작]' storage busy).
    startupSyncPending = widget.autoSync;
    reload().then((_) {
      startupSyncPending = false;
      if (widget.autoSync && mounted && loggedIn && !busy) {
        sync(source: '앱 시작', foregroundLogin: true);
      } else if (!busy && widget.autoSync && mounted) {
        unawaited(prepareDriveSnapshot().catchError(logDrivePrepareFailure));
      }
    });
  }

  bool get waitingActive => filter.waitingOnly && showWaitingAssignments.value;
  void displayPreferenceChanged() {
    if (mounted) setState(() {});
  }

  void onHomeRequest() {
    final request = homeNavigation.value;
    if (request == null || !mounted) return;
    homeNavigation.value = null;
    if (request.today) {
      setState(() => section = 0);
    } else if (request.view == ScheduleView.tasks) {
      showTasks();
    } else {
      unawaited(
        openWorkspaceTool(context, request.view).then((_) {
          if (mounted) reload();
        }),
      );
    }
  }

  void showTasks({String deadline = ''}) {
    taskSearch.clear();
    setState(() {
      section = 1;
      filter.deadline = deadline;
      filter.type = '';
      filter.course = '';
      filter.query = '';
      filter.waitingOnly = false;
      filter.completedOnly = false;
      filter.hiddenOnly = false;
      filter.showDone = false;
      filter.showExcluded = false;
    });
  }

  Widget connectionStatus() => HomeConnectionStatus(
    testing: sessionTesting,
    automatic: automaticConnection,
    busy: busy,
    last: last,
    error: error,
    refresh: reload,
    evidence: connectionObservation,
  );

  void selectRoot(int value) {
    final previous = section;
    setState(() => section = value == 3 ? 4 : value);
    if (previous == 2 || previous == 4) unawaited(reload());
  }

  void desktopReload() {
    if (mounted) reload();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final reopened = foregroundEntry.update(state);
    if (Platform.isIOS) setIosAiActive(state == AppLifecycleState.resumed);
    // Start the collection before reloading: sync() marks busy synchronously,
    // so reload() then skips its own Drive preparation instead of starting one
    // that the collection would collide with (device review 11/4 01:02).
    if (widget.autoSync && reopened && loggedIn) {
      sync(source: '앱 복귀', foregroundLogin: true);
    }
    if (state == AppLifecycleState.resumed) {
      power.check();
      unawaited(reload());
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    homeNavigation.removeListener(onHomeRequest);
    showWaitingAssignments.removeListener(displayPreferenceChanged);
    power
      ..removeListener(powerChanged)
      ..dispose();
    clockRefresh?.cancel();
    taskSearch.dispose();
    if (Platform.isWindows) desktopChanged.removeListener(desktopReload);
    super.dispose();
  }

  bool reloadAgain = false;
  bool startupSyncPending = false;
  Future<void> reload() async {
    // Optional export must not block UI; failures go to the activity log.
    // While a collection runs it prepares the export itself at the end;
    // preparing here too competed for the database and made both fail
    // (activity log 11/4 00:25: list save and Drive prepare, storage busy).
    if (!busy && !startupSyncPending) {
      unawaited(prepareDriveSnapshot().catchError(logDrivePrepareFailure));
    }
    if (!mounted) return;
    if (reloading) {
      // A change made while a reload is running (hide, undo, sync) must
      // still show up: run once more after the current one finishes.
      reloadAgain = true;
      return;
    }
    reloading = true;
    Store? store;
    try {
      // Authentication state must not depend on the optional local list query.
      final id = await credentials.read(key: 'id');
      final pw = await credentials.read(key: 'pw');
      if (!mounted) return;
      if (mounted) {
        setState(() {
          loggedIn = id != null && pw != null;
          if (!loggedIn) desktopSelected = null;
          accountChecked = true;
          storageError = null;
        });
      }
      if (Platform.isAndroid || Platform.isWindows) {
        final candidate = Platform.isWindows
            ? await cachedDesktopUpdate()
            : await cachedUpdate();
        if (mounted) setState(() => availableUpdate = candidate);
      }
      final testing = await sessionProbeActive();
      final automatic = await automaticSchoolConnectionPreference();
      if (!mounted) return;
      store = await Store.open();
      if (!mounted) return;
      final snapshot = await DashboardRepository(store).read();
      final nonTasks = await store.notTasks();
      SessionLifetime? observed;
      try {
        observed = await SessionLifetimeRepository(
          store,
        ).read(await store.meta(MetaKey.sessionEpoch) ?? '');
      } catch (_) {
        /* Optional local status must not fail the list. */
      }

      if (mounted) {
        setState(() {
          connectionObservation = observed;
          items = snapshot.items;
          // Keep the wide-layout preview in step with the list: show the
          // fresh copy, or nothing once the item (or account) is gone.
          desktopSelected = desktopSelected == null
              ? null
              : items.where((i) => i.key == desktopSelected!.key).firstOrNull;
          homeNotices = snapshot.notices;
          excluded = snapshot.excluded;
          notTaskKeys = nonTasks;
          last = snapshot.lastSuccess;
          error = snapshot.lastError;
          sessionTesting = testing;
          automaticConnection = automatic;
          localRevision++;
        });
      }
      // Reuse this connection for one-time local discovery adoption; a home
      // recommendation never starts another database connection or API request.
      try {
        final prefs = await SharedPreferences.getInstance();
        if (prefs.getBool(PrefKey.discoverySeeded053) != true) {
          final known = <DiscoverFeature>{};
          final timetable = await store.meta(MetaKey.timetableEntries);
          if (timetable != null && timetable != '[]') {
            known.add(DiscoverFeature.timetable);
          }
          if ((await store.meta('aiChat:all') ?? '[]') != '[]') {
            known.add(DiscoverFeature.chat);
          }
          if ((await store.meta(MetaKey.aiConsent) ?? '').isNotEmpty) {
            known.add(DiscoverFeature.ai);
          }
          if (await store.meta(MetaKey.overduePolicy) != null) {
            known.add(DiscoverFeature.tasks);
          }
          unawaited(FeatureDiscovery.adopt(known).catchError((_) {}));
        }
      } catch (_) {
        /* Discovery cannot fail account or list loading. */
      }
    } catch (_) {
      if (mounted) {
        setState(
          () => storageError = accountChecked
              ? '저장된 목록을 읽지 못했어요. 로그인 정보를 삭제하지 않았어요. 잠시 후 다시 확인해 주세요.'
              : '저장된 계정에 접근하지 못했어요. 로그인 정보 유실로 판단하지 않고 재확인을 기다려요.',
        );
      }
    } finally {
      await store?.db.close();
      if (mounted) {
        setState(() => reloading = false);
      } else {
        reloading = false;
      }
    }
    if (reloadAgain && mounted) {
      reloadAgain = false;
      await reload();
    }
  }

  final foregroundEntry = ForegroundEntry();
  Future<void> sync({
    String source = '수동 확인',
    bool automatic = false,
    bool foregroundLogin = false,
  }) async {
    if (automatic) {
      try {
        if (!await automaticSchoolConnectionEnabled()) return;
      } catch (_) {
        return;
      }
    }
    if (!mounted) return;
    if (busy) return;
    setState(() {
      busy = true;
      listsReady = false;
    });
    try {
      await synchronize(
        source: source,
        foregroundLogin: foregroundLogin,
        onPhase: (phase) {
          if (mounted) setState(() => syncPhase = phase);
        },
        onListsReady: () async {
          await reload();
          if (mounted) setState(() => listsReady = true);
        },
      );
    } catch (_) {
    } finally {
      await reload();
      if (mounted) {
        setState(() {
          busy = false;
          listsReady = false;
        });
      }
    }
  }

  Future<void> login() async {
    if (busy) return;
    String? currentAccount;
    try {
      if (loggedIn) currentAccount = await credentials.read(key: 'id');
    } catch (_) {
      if (mounted) {
        showTransientMessage(
          context,
          const SnackBar(content: Text('저장된 계정을 확인하지 못했어요. 기존 정보는 유지해요.')),
        );
      }
      return;
    }
    if (!mounted) return;
    Map<String, dynamic>? verifiedSchoolSession;
    String? verifiedAccount;
    final accepted = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      isDismissible: false,
      enableDrag: false,
      builder: (_) => PortalConnectSheet(
        initialId: currentAccount ?? '',
        lockAccount: currentAccount != null,
        connect: (id, pw) => verifyAndSavePortal(
          id: id,
          password: pw,
          authenticate: (id, pw) async {
            if (currentAccount != null && id != currentAccount) {
              throw CampusException('다른 계정은 로그아웃 후 연결해 주세요.');
            }
            final client = CampusClient();
            try {
              await client.login(id, pw);
              final terms = await client.api('/term/getYearTermList', null);
              if (terms is! Map || terms['list'] is! List) {
                throw CampusException('로그인 확인을 완료하지 못했어요. 학교 사이트 상태를 확인해 주세요.');
              }
              await client.fetchCourses();
              verifiedSchoolSession = client.exportSession();
              verifiedAccount = id;
            } finally {
              client.close();
            }
          },
          read: (key) => credentials.read(key: key),
          write: (key, value) async {
            if (value == null) {
              await credentials.delete(key: key);
            } else {
              await credentials.write(key: key, value: value);
            }
          },
        ),
      ),
    );
    if (accepted != true || !mounted) return;
    final sessionStore = await Store.open();
    try {
      await SessionScope.rotate(sessionStore, blocked: false);
    } finally {
      await sessionStore.db.close();
    }
    try {
      if (verifiedSchoolSession != null && verifiedAccount != null) {
        await rememberSchoolSession(verifiedSchoolSession!, verifiedAccount!);
      }
      await reload();
      await requestNotificationPermission();
      await registerBackground();
      await sync(foregroundLogin: false);
    } catch (_) {
      await reload();
      if (mounted) {
        setState(
          () => storageError =
              '로그인 정보는 저장했지만 알림·수집 준비를 완료하지 못했어요. 연결 상태와 권한을 확인해 주세요.',
        );
      }
    }
  }

  Future<void> logout() async {
    if (busy) return;
    final accepted = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('로그아웃할까요?'),
        content: const Text(
          '저장된 포털 계정과 AI 키, 수집 정보·로그를 삭제하고 캘린더 연결을 해제해요. 캘린더에 저장한 일정은 남아요.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('로그아웃'),
          ),
        ],
      ),
    );
    if (accepted != true) return;
    setState(() => busy = true);
    final failures = await performAccountLogout();
    if (mounted) setState(() => busy = false);
    if (mounted && failures.isNotEmpty) {
      showTransientMessage(
        context,
        SnackBar(
          content: Text('로그아웃 일부 정리 실패: ${failures.join(', ')}. 다시 로그아웃해 주세요.'),
        ),
      );
    }
    await reload();
  }

  Future<void> testNotification() async {
    await requestNotificationPermission();
    await notifications.show(
      notificationId('test'),
      '캠퍼스레이더 알림 테스트',
      items.isEmpty
          ? '알림이 정상적으로 표시돼요.'
          : '${items.first.course} · ${items.first.title}',
      noticeStyle,
      payload: items.firstOrNull?.key,
    );
    await logNotification('테스트 알림 발송 요청', '기기에 알림 표시를 요청했어요.');
  }

  final Set<String> visibilityBusy = {};
  Future<void> toggleTaskVisibility(CampusItem item) async {
    if (visibilityBusy.contains(item.key)) return;
    final before = excluded.contains(item.key);
    setState(() => visibilityBusy.add(item.key));
    try {
      final account = await credentials.read(key: 'id');
      await excludeItem(item, !before);
      if (before && notTaskKeys.contains(item.key)) {
        // A "할 일 아님" mark would keep the restored item hidden.
        await markNotTask(item, false);
      }
      await reload();
      if (mounted) {
        showTransientMessage(
          context,
          SnackBar(
            content: Text(before ? '목록에 복구했어요' : '목록에서 숨겼어요 · 이 항목 알림도 꺼져요'),
            action: SnackBarAction(
              label: '실행 취소',
              onPressed: () async {
                try {
                  if (await credentials.read(key: 'id') != account) return;
                  await excludeItem(item, before, undo: true);
                  await reload();
                } catch (_) {
                  if (mounted) {
                    showTransientMessage(
                      context,
                      const SnackBar(content: Text('복구하지 못했어요. 다시 시도해 주세요.')),
                    );
                  }
                }
              },
            ),
          ),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('목록을 변경하지 못했어요.')));
      }
    } finally {
      if (mounted) setState(() => visibilityBusy.remove(item.key));
    }
  }

  Widget itemTile(CampusItem item) => RadarTaskCard(
    item: item,
    compact: true,
    excluded: excluded.contains(item.key),
    onVisibilityToggle: visibilityBusy.contains(item.key)
        ? null
        : () => toggleTaskVisibility(item),
    onTap: () async {
      if (MediaQuery.sizeOf(context).width >= 1180 &&
          MediaQuery.sizeOf(context).height >= 500) {
        setState(() => desktopSelected = item);
        return;
      }
      await navigateTo(
        context,
        TaskDestination(item: item, excluded: excluded.contains(item.key)),
      );
      await reload();
    },
  );

  Widget metric(String number, String label, IconData icon) => Expanded(
    child: Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 8),
        child: Column(
          children: [
            Icon(icon, size: 22, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 8),
            Text(
              number,
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),
            Text(label, style: const TextStyle(fontSize: 12)),
          ],
        ),
      ),
    ),
  );

  String taskSection(CampusItem item) {
    if (item.isMaterial) return '자료실';
    if (item.due == null) return '마감 미확인';
    final now = DateTime.now().toUtc();
    if (!item.due!.isAfter(now)) return '마감 지남';
    // Korean calendar days: 오늘 / 내일 / 이번 주 / 다음 주 / 이후.
    final k = now.add(const Duration(hours: 9));
    final today = DateTime.utc(k.year, k.month, k.day);
    final d = item.due!.toUtc().add(const Duration(hours: 9));
    final days = DateTime.utc(d.year, d.month, d.day).difference(today).inDays;
    final weekEnd = 7 - today.weekday; // days left until Sunday
    if (days == 0) return '오늘 마감';
    if (days == 1) return '내일 마감';
    if (days <= weekEnd) return '이번 주 마감';
    if (days <= weekEnd + 7) return '다음 주 마감';
    return '이후 마감';
  }

  Widget taskDropdown(
    String label,
    String value,
    Map<String, String> values,
    ValueChanged<String> change,
  ) => DropdownButtonFormField<String>(
    key: ValueKey('$label:$value'),
    isExpanded: true,
    initialValue: values.containsKey(value) ? value : '',
    decoration: InputDecoration(
      labelText: label,
      border: const OutlineInputBorder(),
      isDense: true,
    ),
    items: values.entries
        .map(
          (e) => DropdownMenuItem(
            value: e.key,
            child: Text(e.value, overflow: TextOverflow.ellipsis),
          ),
        )
        .toList(),
    onChanged: (v) => setState(() => change(v ?? '')),
  );

  Future<void> openTaskFilters() async {
    var type = filter.type,
        course = filter.course,
        deadline = filter.deadline,
        sort = filter.sort;
    var done = filter.showDone, hidden = filter.showExcluded;
    final courses = items.map((e) => e.course).toSet().toList()..sort();
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheet) => StatefulBuilder(
        builder: (sheet, update) {
          Widget field(
            String label,
            String value,
            Map<String, String> values,
            ValueChanged<String> change,
          ) => Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: DropdownButtonFormField<String>(
              key: ValueKey('$label:$value'),
              initialValue: values.containsKey(value) ? value : '',
              isExpanded: true,
              decoration: InputDecoration(labelText: label),
              items: values.entries
                  .map(
                    (e) => DropdownMenuItem(
                      value: e.key,
                      child: Text(e.value, overflow: TextOverflow.ellipsis),
                    ),
                  )
                  .toList(),
              onChanged: (v) => update(() => change(v ?? '')),
            ),
          );
          final count = items
              .where(
                (i) =>
                    (!filter.hiddenOnly || !notTaskKeys.contains(i.key)) &&
                    categoryMatches(
                      i,
                      DateTime.now().toUtc(),
                      excluded,
                      waiting: waitingActive,
                      completed: filter.completedOnly,
                      hiddenOnly: filter.hiddenOnly,
                      showHidden: hidden,
                      showDone: done,
                    ) &&
                    taskTypeMatches(i, type) &&
                    (course.isEmpty || i.course == course) &&
                    (deadline.isEmpty ||
                        deadlineState(i.due).name == deadline ||
                        (deadline == 'today' &&
                            i.due != null &&
                            i.due!.isAfter(DateTime.now().toUtc()) &&
                            DateUtils.isSameDay(
                              DateTime.now().toUtc().add(
                                const Duration(hours: 9),
                              ),
                              i.due!.toUtc().add(const Duration(hours: 9)),
                            ))) &&
                    '${i.title} ${i.course} ${courseLabel(i.course)}'
                        .toLowerCase()
                        .contains(filter.query.toLowerCase()),
              )
              .length;
          return SafeArea(
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(
                24,
                0,
                24,
                24 + MediaQuery.viewInsetsOf(sheet).bottom,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          '목록 필터',
                          style: Theme.of(sheet).textTheme.titleLarge,
                        ),
                      ),
                      TextButton(
                        onPressed: () => update(() {
                          type = '';
                          course = '';
                          deadline = '';
                          sort = 'due';
                          done = false;
                          hidden = false;
                        }),
                        child: const Text('초기화'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  field('유형', type, {
                    '': '전체',
                    'LR': '과제',
                    'LV': '콘텐츠',
                  }, (v) => type = v),
                  field('과목', course, {
                    '': '모든 과목',
                    for (final c in courses) c: courseLabel(c),
                  }, (v) => course = v),
                  field('마감 상태', deadline, {
                    '': '전체',
                    'overdue': '마감 지남',
                    'withinDay': '24시간 이내',
                    'today': '오늘 마감',
                    'remaining': '아직 남음',
                    'unknown': '마감 미확인',
                  }, (v) => deadline = v),
                  field('정렬', sort, {
                    'due': '마감 빠른 순',
                    'course': '과목명 순',
                    'title': '제목 순',
                  }, (v) => sort = v),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('완료 포함'),
                    value: done,
                    onChanged: (v) => update(() => done = v),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('숨긴 항목 포함'),
                    value: hidden,
                    onChanged: (v) => update(() => hidden = v),
                  ),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: () {
                      setState(() {
                        filter.type = type;
                        filter.course = course;
                        filter.deadline = deadline;
                        filter.sort = sort;
                        filter.showDone = done;
                        filter.showExcluded = hidden;
                      });
                      Navigator.pop(sheet);
                    },
                    child: Text('결과 $count개 보기'),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  /// Undated rows share a due key; group them by section (materials vs.
  /// undated tasks) so each heading appears once, then order by title.
  int _byDueThenSection(CampusItem a, CampusItem b) {
    final due = (a.due ?? DateTime.utc(2100)).compareTo(
      b.due ?? DateTime.utc(2100),
    );
    if (due != 0) return due;
    final section = taskSection(a).compareTo(taskSection(b));
    return section != 0 ? section : a.title.compareTo(b.title);
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now().toUtc();
    final available = items
        .where((i) => i.availableAt(now) && !excluded.contains(i.key))
        .toList();
    final counts = DashboardCounts.of(items, excluded, now);
    final pending = counts.pending, urgent = counts.urgent;
    final today = counts.today;
    final visible = filter.apply(
      items,
      now: now,
      excluded: excluded,
      notTaskKeys: notTaskKeys,
      waiting: waitingActive,
    );
    visible.sort(
      (a, b) => filter.sort == 'course'
          ? a.course.compareTo(b.course)
          : filter.sort == 'title'
          ? a.title.compareTo(b.title)
          : _byDueThenSection(a, b),
    );
    // Same rule as the hidden filter: "할 일 아님" rows and keys of items no
    // longer collected are not shown there, so they are not counted either.
    final hiddenCount = items
        .where((i) => excluded.contains(i.key) && !notTaskKeys.contains(i.key))
        .length;
    final home = RefreshIndicator(
      onRefresh: loggedIn ? sync : reload,
      child: ListView(
        key: PageStorageKey('home-section-$section'),
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
        children: [
          if (busy && !listsReady) ...[
            // Normal collection stays small; failures surface in the status row.
            const LinearProgressIndicator(minHeight: 2),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Text(
                '$syncPhase 중…',
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ),
          ],
          if (storageError != null)
            Card(
              color: Theme.of(context).colorScheme.errorContainer,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text(storageError!),
                    TextButton(
                      onPressed: reloading ? null : reload,
                      child: const Text('저장 정보 다시 확인'),
                    ),
                  ],
                ),
              ),
            ),
          if (!accountChecked)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('저장된 계정 확인 중…'),
            ),
          if (accountChecked && !loggedIn)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.radar, size: 44),
                    const SizedBox(height: 16),
                    const Text(
                      '놓치기 전에, 한눈에',
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text('포털을 연결하면 과제와 콘텐츠를 확인할 수 있어요.'),
                    const SizedBox(height: 16),
                    FilledButton(
                      onPressed: busy ? null : login,
                      child: const Text('포털 연결'),
                    ),
                  ],
                ),
              ),
            ),
          if (loggedIn) ...[
            connectionStatus(),
            if (section == 0) ...[
              // Times on this screen are Korean time; rows no longer repeat it.
              Text(
                '${now.add(const Duration(hours: 9)).month}월 ${now.add(const Duration(hours: 9)).day}일 · 시간은 모두 한국 시간',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: 16),
              // The most time-critical thing leads: urgent deadlines when there
              // are any, otherwise the next class.
              if (urgent.isNotEmpty)
                Card(
                  color: Theme.of(context).colorScheme.errorContainer,
                  child: ListTile(
                    leading: const Icon(Icons.alarm),
                    title: Text('24시간 이내 ${urgent.length}개 마감'),
                    subtitle: Text('오늘 마감 $today개 · 전체 미완료 ${pending.length}개'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => showTasks(deadline: 'withinDay'),
                  ),
                ),
              if (Platform.isAndroid || Platform.isIOS)
                TodayClassesCard(
                  key: ValueKey('classes:$last'),
                  refreshToken: localRevision,
                  compact: true,
                  // Today/tomorrow deadlines join the hero's timeline.
                  deadlines: [
                    for (final i in pending)
                      if (i.due != null &&
                          i.due!.isAfter(now) &&
                          i.due!.difference(now).inHours < 48)
                        (
                          at: i.due!,
                          label: '${courseLabel(i.course)} · ${i.title}',
                          onTap: () =>
                              navigateTo(context, TaskDestination(item: i)),
                        ),
                  ],
                ),
            ],
            if (section == 0) ...[
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      '먼저 할 일',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                  ),

                  TextButton(onPressed: showTasks, child: const Text('전체 보기')),
                ],
              ),
              if (urgent.isEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text(
                    '24시간 이내 마감 없음 · 전체 미완료 ${pending.length}개',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
              if (!pending.any((i) => i.due == null || i.due!.isAfter(now)) &&
                  !busy)
                const Padding(
                  padding: EdgeInsets.all(24),
                  child: Text('앞으로 마감할 미완료 항목이 없어요. 지난 항목은 할 일에서 확인할 수 있어요.'),
                ),
              ...pending
                  .where((i) => i.due == null || i.due!.isAfter(now))
                  .take(3)
                  .map(itemTile),
              const SizedBox(height: 8),
              HomeAgendaCard(
                key: ValueKey('agenda:$last:$localRevision'),
                compact: true,
              ),
              if (homeNotices.any(
                (n) =>
                    !n.read &&
                    n.published != null &&
                    now.difference(n.published!).inHours <= 48,
              ))
                ListTile(
                  leading: const Icon(Icons.campaign_outlined),
                  title: const Text('최근 미확인 공지가 있어요'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const NoticesPage()),
                  ),
                ),
              const DailySummarySection(),
              if (availableUpdate != null)
                Card(
                  color: Theme.of(context).colorScheme.secondaryContainer,
                  child: ListTile(
                    leading: const Icon(Icons.system_update_outlined),
                    title: const Text('업데이트 가능'),
                    subtitle: Text(
                      '${availableUpdate!['versionName']} · ${channelLabel(availableUpdate!['channel'])}',
                    ),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => Platform.isWindows
                              ? const DesktopUpdatePage()
                              : const UpdatePage(),
                        ),
                      );
                      await reload();
                    },
                  ),
                ),
              if (power.warnings.isNotEmpty)
                Card(
                  color: Theme.of(context).colorScheme.errorContainer,
                  child: ListTile(
                    leading: const Icon(Icons.battery_alert_outlined),
                    title: const Text('앱 배터리 설정 확인'),
                    subtitle: Text(power.warnings.join('\n')),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const BackgroundStatusPage(),
                      ),
                    ),
                    trailing: IconButton(
                      onPressed: () => openPowerSetting('openAppSettings'),
                      icon: const Icon(Icons.settings_outlined),
                      tooltip: '앱 배터리 설정',
                    ),
                  ),
                ),
            ] else ...[
              const SizedBox(height: 20),
              TextField(
                controller: taskSearch,
                decoration: const InputDecoration(
                  hintText: '과제·콘텐츠·자료·과목 검색',
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(),
                ),
                onChanged: (v) => setState(() => filter.query = v),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          ChoiceChip(
                            label: Text(
                              '진행 중 ${available.where((i) => !i.done && !i.isMaterial).length}',
                            ),
                            selected:
                                !filter.completedOnly &&
                                !filter.hiddenOnly &&
                                !waitingActive,
                            onSelected: (_) => setState(() {
                              filter.completedOnly = false;
                              filter.waitingOnly = false;
                              filter.hiddenOnly = false;
                              filter.showDone = false;
                              filter.showExcluded = false;
                            }),
                          ),
                          const SizedBox(width: 8),
                          if (showWaitingAssignments.value) ...[
                            ChoiceChip(
                              label: Text(
                                '제출 대기 ${items.where((i) => waitingAssignment(i, now) && !excluded.contains(i.key)).length}',
                              ),
                              selected: waitingActive,
                              onSelected: (_) => setState(() {
                                filter.waitingOnly = true;
                                filter.completedOnly = false;
                                filter.hiddenOnly = false;
                                filter.showDone = false;
                                filter.showExcluded = false;
                                filter.deadline = '';
                              }),
                            ),
                            const SizedBox(width: 8),
                          ],
                          ChoiceChip(
                            label: const Text('제출 완료 과제'),
                            selected: filter.completedOnly,
                            onSelected: (_) => setState(() {
                              filter.completedOnly = true;
                              filter.waitingOnly = false;
                              filter.hiddenOnly = false;
                              filter.showDone = true;
                              filter.showExcluded = false;
                            }),
                          ),
                          const SizedBox(width: 8),
                          ChoiceChip(
                            label: Text('숨김 $hiddenCount'),
                            selected: filter.hiddenOnly,
                            onSelected: (_) => setState(() {
                              filter.hiddenOnly = true;
                              filter.waitingOnly = false;
                              filter.completedOnly = false;
                              filter.showExcluded = true;
                            }),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filledTonal(
                    tooltip: '필터',
                    onPressed: openTaskFilters,
                    icon: Badge(
                      isLabelVisible:
                          filter.course.isNotEmpty ||
                          filter.deadline.isNotEmpty ||
                          filter.sort != 'due' ||
                          filter.showDone ||
                          filter.showExcluded ||
                          filter.type.isNotEmpty,
                      label: const Text('•'),
                      child: const Icon(Icons.tune),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              // One scrolling row instead of two wrapped rows of chips.
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  spacing: 8,
                  children: [
                    ActionChip(
                      avatar: const Icon(Icons.folder_open_outlined, size: 18),
                      label: const Text('자료 모아보기'),
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const MaterialsPage(),
                        ),
                      ),
                    ),
                    for (final e in learningTypeChoices.entries)
                      FilterChip(
                        label: Text(e.value),
                        selected: filter.type == e.key,
                        onSelected: (_) => setState(() => filter.type = e.key),
                      ),
                    if (filter.course.isNotEmpty)
                      InputChip(
                        label: Text(courseLabel(filter.course)),
                        onDeleted: () => setState(() => filter.course = ''),
                      ),
                    if (filter.deadline.isNotEmpty)
                      InputChip(
                        label: Text(
                          {
                            'overdue': '마감 지남',
                            'withinDay': '24시간 이내',
                            'today': '오늘 마감',
                            'remaining': '아직 남음',
                            'unknown': '마감 미확인',
                          }[filter.deadline]!,
                        ),
                        onDeleted: () => setState(() => filter.deadline = ''),
                      ),
                  ],
                ),
              ),
              Text(
                '${visible.length}개 · ${waitingActive ? '제출 시작 전 공개 과제' : '공개·시작된 항목만 표시'}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 12),
              if (visible.isEmpty && !busy)
                const Padding(
                  padding: EdgeInsets.all(24),
                  child: Text('조건에 맞는 과제·콘텐츠가 없어요.'),
                ),
              for (var index = 0; index < visible.length; index++) ...[
                if (filter.sort == 'due' &&
                    (index == 0 ||
                        taskSection(visible[index]) !=
                            taskSection(visible[index - 1])))
                  SectionHeading(taskSection(visible[index])),
                itemTile(visible[index]),
              ],
            ],
          ],
        ],
      ),
    );
    final scheduleBody = home;
    if (MediaQuery.sizeOf(context).width >= 760 &&
        MediaQuery.sizeOf(context).height >= 500) {
      return Scaffold(
        body: Row(
          children: [
            NavigationRail(
              extended: MediaQuery.sizeOf(context).width >= 1180,
              selectedIndex: section == 4 ? 3 : section,
              onDestinationSelected: selectRoot,
              leading: const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Icon(Icons.radar, size: 32),
              ),
              destinations: const [
                NavigationRailDestination(
                  icon: Icon(Icons.today_outlined),
                  label: Text('오늘'),
                ),
                NavigationRailDestination(
                  icon: Icon(Icons.checklist),
                  label: Text('할 일'),
                ),
                NavigationRailDestination(
                  icon: Icon(Icons.school_outlined),
                  label: Text('과목'),
                ),

                NavigationRailDestination(
                  icon: Icon(Icons.settings_outlined),
                  label: Text('더보기'),
                ),
              ],
            ),
            const VerticalDivider(width: 1),
            Expanded(
              child: section == 2
                  ? const CoursesPage()
                  : section == 4
                  ? SettingsHub(
                      connected: loggedIn,
                      connect: login,
                      logout: busy ? () {} : logout,
                      test: testNotification,
                    )
                  : Scaffold(
                      appBar: AppBar(
                        title: Text(section == 0 ? '오늘' : '할 일'),
                        actions: [
                          if (Platform.isWindows)
                            IconButton(
                              tooltip: 'PC 실행 설정',
                              onPressed: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => const DesktopSettingsPage(),
                                ),
                              ),
                              icon: const Icon(Icons.desktop_windows_outlined),
                            ),
                          IconButton(
                            onPressed: busy
                                ? null
                                : () => sync(foregroundLogin: true),
                            icon: const Icon(Icons.sync),
                            tooltip: '지금 확인',
                          ),
                          IconButton(
                            onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => const AiChatPage(),
                              ),
                            ),
                            icon: const Icon(Icons.chat_bubble_outline),
                            tooltip: '질문하기',
                          ),
                        ],
                      ),
                      body: Row(
                        children: [
                          Expanded(
                            child: Align(
                              alignment: Alignment.topCenter,
                              child: ConstrainedBox(
                                constraints: const BoxConstraints(
                                  maxWidth: 1040,
                                ),
                                child: scheduleBody,
                              ),
                            ),
                          ),
                          if (MediaQuery.sizeOf(context).width >= 1180 &&
                              desktopSelected != null)
                            SizedBox(
                              width: 360,
                              child: DesktopTaskPreview(
                                item: desktopSelected!,
                                close: () =>
                                    setState(() => desktopSelected = null),
                                open: () async {
                                  await navigateTo(
                                    context,
                                    TaskDestination(
                                      item: desktopSelected!,
                                      excluded: excluded.contains(
                                        desktopSelected!.key,
                                      ),
                                    ),
                                  );
                                  await reload();
                                },
                              ),
                            ),
                        ],
                      ),
                    ),
            ),
          ],
        ),
      );
    }
    return Scaffold(
      appBar: section <= 1
          ? AppBar(
              title: Text(section == 0 ? '오늘' : '할 일'),
              actions: [
                IconButton(
                  onPressed: busy ? null : () => sync(foregroundLogin: true),
                  icon: const Icon(Icons.sync),
                  tooltip: '지금 확인',
                ),
                IconButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const AiChatPage()),
                  ),
                  icon: const Icon(Icons.chat_bubble_outline),
                  tooltip: '질문하기',
                ),
                IconButton(
                  onPressed: () => setState(() => section = 4),
                  icon: const Icon(Icons.more_horiz),
                  tooltip: '더보기',
                ),
              ],
            )
          : null,
      body: AdaptiveContent(
        child: section == 2
            ? const CoursesPage()
            : section == 4
            ? SettingsHub(
                connected: loggedIn,
                connect: login,
                logout: busy ? () {} : logout,
                test: testNotification,
              )
            : scheduleBody,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: section == 4 ? 3 : section,
        onDestinationSelected: selectRoot,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.today_outlined),
            selectedIcon: Icon(Icons.today),
            label: '오늘',
          ),
          NavigationDestination(
            icon: Icon(Icons.checklist_outlined),
            selectedIcon: Icon(Icons.checklist),
            label: '할 일',
          ),
          NavigationDestination(
            icon: Icon(Icons.school_outlined),
            selectedIcon: Icon(Icons.school),
            label: '과목',
          ),

          NavigationDestination(
            icon: Icon(Icons.more_horiz),
            selectedIcon: Icon(Icons.more_horiz),
            label: '더보기',
          ),
        ],
      ),
    );
  }
}

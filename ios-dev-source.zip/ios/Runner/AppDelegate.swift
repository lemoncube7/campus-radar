import Flutter
import UIKit
import QuickLook
import WidgetKit
import EventKit
import UserNotifications
import WebKit
import workmanager_apple
import flutter_local_notifications

@main
@objc class AppDelegate: FlutterAppDelegate {
  static var pendingTarget: String?
  override func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey: Any] = [:]) -> Bool {
    if url.scheme == "campusradar" {
      let target = url.host == "timetable" ? "_timetable" : "_tasks"
      AppDelegate.pendingTarget = target
      if let controller = window?.rootViewController as? FlutterViewController {
        FlutterMethodChannel(name: "campus_radar/native", binaryMessenger: controller.binaryMessenger)
          .invokeMethod("openTarget", arguments: target)
      }
      return true
    }
    return super.application(app, open: url, options: options)
  }
  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    GeneratedPluginRegistrant.register(with: self)
    UNUserNotificationCenter.current().delegate = self
    WorkmanagerPlugin.setPluginRegistrantCallback { registry in
      GeneratedPluginRegistrant.register(with: registry)
      registerRadarBridge(registry: registry, controller: nil)
    }
    WorkmanagerPlugin.registerPeriodicTask(
      withIdentifier: "kr.campusradar.campusradar.sync", frequency: NSNumber(value: 3600)
    )
    FlutterLocalNotificationsPlugin.setPluginRegistrantCallback { registry in
      GeneratedPluginRegistrant.register(with: registry)
      registerRadarBridge(registry: registry, controller: nil)
    }
    registerRadarBridge(registry: self, controller: window?.rootViewController as? FlutterViewController)

    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }
}

private func registerRadarBridge(registry: FlutterPluginRegistry, controller: FlutterViewController?) {
  guard !registry.hasPlugin("CampusRadarNative"), let registrar = registry.registrar(forPlugin: "CampusRadarNative") else { return }
  let channel = FlutterMethodChannel(name:"campus_radar/native", binaryMessenger:registrar.messenger())
      channel.setMethodCallHandler { [weak controller] call, result in
        switch call.method {
        case "openExternalUrl":
          guard let args=call.arguments as? [String:Any],let text=args["url"] as? String,
            ["https://aistudio.google.com/api-keys","https://aistudio.google.com/rate-limit"].contains(text),let url=URL(string:text) else { result(FlutterError(code:"invalid_url",message:"주소를 열 수 없어요.",details:nil));return }
          UIApplication.shared.open(url) { ok in result(ok ? nil:FlutterError(code:"open_failed",message:"브라우저를 열지 못했어요.",details:nil)) }
        case "openChatLink":
          guard let a=call.arguments as? [String:Any], let text=a["url"] as? String, let u=URL(string:text),u.scheme=="https",u.host != nil,u.user==nil,u.password==nil else {result(FlutterError(code:"invalid_url",message:"주소를 확인해 주세요.",details:nil));return}
          UIApplication.shared.open(u){ok in result(ok ? nil:FlutterError(code:"open_failed",message:"링크를 열지 못했어요.",details:nil))}
        case "calendarRenameCourse":
          do {try RadarCalendarIOS.renameCourse(call.arguments as? [String:Any] ?? [:]);result(nil)}catch{result(FlutterError(code:"calendar_error",message:error.localizedDescription,details:nil))}
        case "fetchLinkedPlan", "openLinkedPlan":
          guard let a=call.arguments as? [String:Any],let text=a["url"] as? String,let u=URL(string:text),SyllabusController.trusted(u),let c=controller else {result(FlutterError(code:"invalid_plan",message:"계획서 주소를 확인해 주세요.",details:nil));return}
          guard c.presentedViewController==nil else {result(FlutterError(code:"busy",message:"열린 창을 닫고 다시 시도해 주세요.",details:nil));return}
          let capture=call.method=="fetchLinkedPlan"
          let page=SyllabusController(url:u,course:a["course"] as? String ?? "",capture:capture,completion:capture ? result:nil)
          c.present(UINavigationController(rootViewController:page),animated:true)
          if !capture {result(nil)}
        case "takeLaunchTarget":
          let target = AppDelegate.pendingTarget; AppDelegate.pendingTarget = nil; result(target)
        case "timetableSettings":
          var settings = UserDefaults.standard.dictionary(forKey: "radarTimetableSettings") ?? [:]
          settings["exactAllowed"] = true; result(settings)
        case "setTimetableSettings":
          let settings = call.arguments as? [String: Any] ?? [:]
          UserDefaults.standard.set(settings, forKey: "radarTimetableSettings"); result(nil)
        case "widgetStatus":
          result(["available": RadarShared.snapshotURL != nil])
        case "publishWidgetSnapshot":
          guard let args = call.arguments as? [String: Any], let text = args["snapshot"] as? String,
                let data = text.data(using: .utf8), data.count < 100000 else {
            result(FlutterError(code: "invalid_snapshot", message: "위젯 표시 정보가 올바르지 않아요.", details: nil)); return
          }
          guard let url = RadarShared.snapshotURL else {
            result(["available": false]); return
          }
          do {
            try data.write(to: url, options: .atomic)
            try? FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: url.path)
            WidgetCenter.shared.reloadAllTimelines(); result(["available": true])
          } catch { result(FlutterError(code: "widget_write", message: "위젯 표시 정보를 저장하지 못했어요.", details: nil)) }
        case "openCampusFile":
          guard let args = call.arguments as? [String: Any], let path = args["path"] as? String,
                let controller = controller, controller.presentedViewController == nil else {
            result(FlutterError(code: "file_unavailable", message: "첨부파일 화면을 열 수 없어요.", details: nil)); return
          }
          let url = URL(fileURLWithPath: path).resolvingSymlinksInPath().standardizedFileURL
          let roots = [FileManager.default.temporaryDirectory, FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first!]
            .map { $0.appendingPathComponent("campus_media").resolvingSymlinksInPath().standardizedFileURL.path + "/" }
          guard roots.contains(where: { url.path.hasPrefix($0) }), FileManager.default.fileExists(atPath: url.path) else {
            result(FlutterError(code: "invalid_file", message: "앱 첨부 캐시의 파일만 열 수 있어요.", details: nil)); return
          }
          controller.present(RadarFilePreview(url: url), animated: true); result(nil)
        case "versionInfo":
          result(["name": Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "", "code": Int(Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "1") ?? 1])
        case "calendarPermission":
          RadarCalendarIOS.request(result)
        case "calendarSettings": result(RadarCalendarIOS.settings())
        case "calendarList": result(RadarCalendarIOS.calendars())
        case "calendarConfigure", "calendarWrite", "calendarSync":
          do {
            let args = call.arguments as? [String: Any] ?? [:]
            if call.method == "calendarConfigure" { try RadarCalendarIOS.configure(args); result(nil) }
            else if call.method == "calendarWrite" { result(try RadarCalendarIOS.write(args)) }
            else { try RadarCalendarIOS.sync(args); result(nil) }
          } catch { result(FlutterError(code: "calendar_error", message: error.localizedDescription, details: nil)) }
        case "calendarUnlink": RadarCalendarIOS.unlink(); result(nil)
        case "drainNativeLogs": result(RadarCalendarIOS.drainLogs())
        case "dailySettings": result(RadarCalendarIOS.dailySettings())
        case "setDailySettings":
          let a = call.arguments as? [String: Any] ?? [:]
          UserDefaults.standard.set(a, forKey: "radarDailySettings"); result(nil)
        case "openAppSettings":
          UIApplication.shared.open(URL(string:UIApplication.openSettingsURLString)!) { _ in result(nil) }
        case "backgroundStatus":
          result(["backgroundRefresh": UIApplication.shared.backgroundRefreshStatus == .available,
            "powerSave": ProcessInfo.processInfo.isLowPowerModeEnabled, "jobs": [], "events": []])
        case "versionCode":
          result(Int(Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "1"))
        case "clearWebSession":
          let data = WKWebsiteDataStore.default()
          data.removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: .distantPast) { result(nil) }
        case "openReleasePage":
          UIApplication.shared.open(URL(string: "https://github.com/lemoncube7/campus-radar/releases")!) { opened in
            result(opened ? nil : FlutterError(code: "open_failed", message: "배포 페이지를 열지 못했어요.", details: nil))
          }
        case "openAltStoreSource":
          guard let args = call.arguments as? [String: Any], let source = args["url"] as? String,
                let sourceURL = URL(string: source), sourceURL.scheme == "https" else {
            result(FlutterError(code: "invalid_source", message: "AltStore 소스 주소가 올바르지 않아요.", details: nil)); return
          }
          // SideStore (installed with iloader) first, then AltStore Classic. Both
          // read the same AltStore-format source and re-sign the same IPA.
          func storeURL(_ scheme: String) -> URL? {
            var components = URLComponents()
            components.scheme = scheme; components.host = "source"
            components.queryItems = [URLQueryItem(name: "url", value: source)]
            return components.url
          }
          let candidates = ["sidestore", "altstore-classic"].compactMap(storeURL)
          func open(_ index: Int) {
            guard index < candidates.count else {
              result(FlutterError(code: "altstore_missing", message: "SideStore 또는 AltStore Classic을 설치하고 다시 시도해 주세요.", details: nil)); return
            }
            UIApplication.shared.open(candidates[index]) { opened in
              if opened { result(nil) } else { open(index + 1) }
            }
          }
          open(0)
        case "openCampus":
          guard let args = call.arguments as? [String: Any], let controller = controller,
                let destination = args["url"] as? String, let url = URL(string: destination),
                url.scheme == "https", ["dcs-learning.cnu.ac.kr", "dcs-lcms.cnu.ac.kr"].contains(url.host ?? "") else {
            result(FlutterError(code: "invalid_url", message: "강의실 주소가 올바르지 않아요.", details: nil)); return
          }
          let page = CampusWebController(args: args, destination: url)
          controller.present(UINavigationController(rootViewController: page), animated: true)
          result(nil)
        case "exportDiagnostic", "shareAcademicExport":
          // iOS saves or sends a file through the share sheet (Files, Mail, chat apps).
          guard let controller = controller, let args = call.arguments as? [String: Any] else { result(false); return }
          var shared: URL?
          if call.method == "exportDiagnostic" {
            let text = args["text"] as? String ?? ""
            guard text.count <= 2_000_000 else { result(false); return }
            let file = FileManager.default.temporaryDirectory.appendingPathComponent("campus-radar-diagnostics-\(Int(Date().timeIntervalSince1970 * 1000)).txt")
            do { try text.write(to: file, atomically: true, encoding: .utf8); shared = file }
            catch { result(FlutterError(code: "export_failed", message: error.localizedDescription, details: nil)); return }
          } else if let path = args["path"] as? String {
            let file = URL(fileURLWithPath: path)
            if file.lastPathComponent == "campus-radar-academic.zip", FileManager.default.fileExists(atPath: path) { shared = file }
          }
          guard let item = shared else { result(false); return }
          let sheet = UIActivityViewController(activityItems: [item], applicationActivities: nil)
          sheet.popoverPresentationController?.sourceView = controller.view
          sheet.popoverPresentationController?.sourceRect = CGRect(x: controller.view.bounds.midX, y: controller.view.bounds.midY, width: 1, height: 1)
          controller.present(sheet, animated: true)
          result(true)
        default: result(FlutterMethodNotImplemented)
        }
      }
}

private enum RadarCalendarIOS {
  static let store = EKEventStore()
  static let prefs = UserDefaults.standard
  static var allowed: Bool {
    if #available(iOS 17.0, *) { return EKEventStore.authorizationStatus(for: .event) == .fullAccess }
    return EKEventStore.authorizationStatus(for: .event) == .authorized
  }
  static func request(_ result: @escaping FlutterResult) {
    let done: (Bool, Error?) -> Void = { ok, error in DispatchQueue.main.async {
      if let error = error { result(FlutterError(code:"calendar_permission", message:error.localizedDescription, details:nil)) }
      else { result(ok) }
    }}
    if #available(iOS 17.0, *) { store.requestFullAccessToEvents(completion: done) }
    else { store.requestAccess(to: .event, completion: done) }
  }
  static func error(_ message:String) -> NSError { NSError(domain:"CampusRadar",code:1,userInfo:[NSLocalizedDescriptionKey:message]) }
  static func settings() -> [String:Any] {
    ["calendarId":prefs.string(forKey:"radarCalendarID") ?? "", "auto":prefs.bool(forKey:"radarCalendarAuto"), "allowed":allowed]
  }
  static func calendars() -> [[String:Any]] {
    guard allowed else { return [] }
    return store.calendars(for:.event).filter{$0.allowsContentModifications}.map{["id":$0.calendarIdentifier,"name":$0.title,"account":$0.source.title]}
  }
  static func configure(_ args:[String:Any]) throws {
    let id=args["calendarId"] as? String ?? ""
    guard allowed, let calendar=store.calendar(withIdentifier:id), calendar.allowsContentModifications else { throw error("쓸 수 있는 캘린더를 선택해 주세요.") }
    let old=prefs.string(forKey:"radarCalendarID") ?? ""
    guard old.isEmpty || old==id || !prefs.dictionaryRepresentation().keys.contains(where:{$0.hasPrefix("radarEvent:")}) else { throw error("기존 연결을 해제한 뒤 캘린더를 변경해 주세요.") }
    prefs.set(id,forKey:"radarCalendarID");prefs.set(args["auto"] as? Bool ?? false,forKey:"radarCalendarAuto")
  }
  static func log(_ title:String,_ detail:String) {
    var logs=prefs.array(forKey:"radarNativeLogs") as? [[String:String]] ?? []
    logs.append(["kind":"calendar","title":title,"detail":detail]);prefs.set(Array(logs.suffix(100)),forKey:"radarNativeLogs")
  }
  static func drainLogs() -> [[String:String]] { let rows=prefs.array(forKey:"radarNativeLogs") as? [[String:String]] ?? [];prefs.removeObject(forKey:"radarNativeLogs");return rows }
  static func dailySettings() -> [String:Any] { prefs.dictionary(forKey:"radarDailySettings") ?? ["enabled":false,"hour":18,"minute":0] }
  static func write(_ args:[String:Any], automatic:Bool=false) throws -> String {
    guard allowed, let calendar=store.calendar(withIdentifier:prefs.string(forKey:"radarCalendarID") ?? ""),calendar.allowsContentModifications else { throw error("캘린더 권한과 저장할 캘린더를 확인해 주세요.") }
    guard let key=args["key"] as? String, let title=args["title"] as? String, !title.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty,
      let start=args["start"] as? NSNumber, let end=args["end"] as? NSNumber, end.doubleValue>start.doubleValue else { throw error("일정 제목과 시간을 확인해 주세요.") }
    let token="[CampusRadar:\(key)]"
    let linked=prefs.string(forKey:"radarEvent:\(key)")
    var event=linked.flatMap{store.event(withIdentifier:$0)}
    let owned=event?.calendar.calendarIdentifier==calendar.calendarIdentifier && (event?.notes ?? "").contains(token)
    if !owned {
      if automatic && linked != nil { return "" }
      event=EKEvent(eventStore:store)
    }
    guard let event=event else { throw error("캘린더 일정을 준비하지 못했어요.") }
    let description=String((args["description"] as? String ?? "").prefix(8000))
    let signatureData=try JSONSerialization.data(withJSONObject:args,options:[.sortedKeys])
    let signature=signatureData.base64EncodedString()
    if owned && prefs.string(forKey:"radarEventSig:\(key)")==signature { return event.eventIdentifier }
    // An event the user saved from the edit screen keeps their title/time;
    // automatic deadline sync must not overwrite it.
    if owned && automatic && prefs.bool(forKey:"radarEventManual:\(key)") { return event.eventIdentifier }
    event.calendar=calendar;event.title=title;event.startDate=Date(timeIntervalSince1970:start.doubleValue/1000);event.endDate=Date(timeIntervalSince1970:end.doubleValue/1000)
    event.isAllDay=args["allDay"] as? Bool ?? false;event.timeZone=TimeZone(identifier:event.isAllDay ? "UTC":"Asia/Seoul")
    event.notes=description+"\n"+token;event.availability = .free
    try store.save(event,span:.thisEvent,commit:true)
    prefs.set(event.eventIdentifier,forKey:"radarEvent:\(key)");prefs.set(signature,forKey:"radarEventSig:\(key)")
    prefs.set(!automatic || (owned && prefs.bool(forKey:"radarEventManual:\(key)")),forKey:"radarEventManual:\(key)")
    log(owned ? "캘린더 일정 갱신":"캘린더 일정 추가", title)
    return event.eventIdentifier
  }
  static func date(_ text:String?) -> Date? {
    guard let text=text else { return nil }
    let f=ISO8601DateFormatter();f.formatOptions=[.withInternetDateTime,.withFractionalSeconds]
    if let d=f.date(from:text) { return d };f.formatOptions=[.withInternetDateTime];return f.date(from:text)
  }
  static func renameCourse(_ args:[String:Any]) throws {
    var queue=prefs.array(forKey:"radarAliasQueue") as? [[String:String]] ?? []
    queue.append(["original":args["original"] as? String ?? "", "previous":args["previous"] as? String ?? "", "label":args["label"] as? String ?? ""])
    prefs.set(queue,forKey:"radarAliasQueue");try applyAliases()
  }
  static func applyAliases() throws {
    guard allowed,let calendarID=prefs.string(forKey:"radarCalendarID") else{return}
    let queue=prefs.array(forKey:"radarAliasQueue") as? [[String:String]] ?? []
    for rename in queue {
      let normalize:(String)->String = {$0.replacingOccurrences(of:"\\s+",with:"",options:.regularExpression)}
      for (name,rawID) in prefs.dictionaryRepresentation() where name.hasPrefix("radarEvent:") {
        let key=String(name.dropFirst("radarEvent:".count))
        guard let id=rawID as? String,let event=store.event(withIdentifier:id),event.calendar.calendarIdentifier==calendarID,(event.notes ?? "").contains("[CampusRadar:\(key)]"),let title=event.title,title.hasPrefix("["),let end=title.firstIndex(of:"]") else{continue}
        let inner=String(title[title.index(after:title.startIndex)..<end])
        let timeRange=inner.range(of:"\\s+\\d{2}:\\d{2}$",options:.regularExpression)
        let time=timeRange.map{String(inner[$0])} ?? ""
        let course=timeRange.map{String(inner[..<$0.lowerBound])} ?? inner
        if [rename["original"] ?? "",rename["previous"] ?? ""].contains(where:{normalize($0)==normalize(course)}) {
          event.title="[\(rename["label"] ?? course)\(time)]"+String(title[title.index(after:end)...])
          try store.save(event,span:.thisEvent,commit:true);prefs.removeObject(forKey:"radarEventSig:\(key)")
        }
      }
    }
    prefs.removeObject(forKey:"radarAliasQueue")
  }
  static func sync(_ args:[String:Any]) throws {
    try applyAliases()
    if let aliases=args["aliases"] as? [String:String] {prefs.set(aliases,forKey:"radarCourseAliases")}
    if let rows=args["items"] as? [[String:Any]] { prefs.set(try JSONSerialization.data(withJSONObject:rows),forKey:"radarCalendarItems") }
    guard allowed, !(prefs.string(forKey:"radarCalendarID") ?? "").isEmpty else { return }
    let rows=(prefs.data(forKey:"radarCalendarItems").flatMap{try? JSONSerialization.jsonObject(with:$0)}) as? [[String:Any]] ?? []
    var cal=Calendar(identifier:.gregorian);cal.timeZone=TimeZone(identifier:"Asia/Seoul")!
    let f=DateFormatter();f.locale=Locale(identifier:"en_US_POSIX");f.timeZone=cal.timeZone;f.dateFormat="HH:mm"
    for row in rows {
      guard let key=row["key"] as? String,let due=date(row["due"] as? String) else { continue }
      let linked=prefs.string(forKey:"radarEvent:\(key)") != nil
      if !linked && (!prefs.bool(forKey:"radarCalendarAuto") || row["status"] as? String != "pending" || due<=Date()) { continue }
      let midnight=cal.startOfDay(for:due),before=due.addingTimeInterval(-600)
      let start=due==midnight ? before:max(before,midnight)
      let original=row["course"] as? String ?? ""
      let aliases=prefs.dictionary(forKey:"radarCourseAliases") as? [String:String] ?? [:]
      let label=aliases[original] ?? aliases.first(where:{$0.key.filter{!$0.isWhitespace}==original.filter{!$0.isWhitespace}})?.value ?? original
      let title="[\(label) \(f.string(from:due))] \(row["title"] as? String ?? "")"+(row["status"] as? String == "done" ? " · 완료":"")
      _=try write(["key":key,"title":title,"start":start.timeIntervalSince1970*1000,"end":due.timeIntervalSince1970*1000,"allDay":false,"description":"마감 일정 · 한국 시간\n\(row["body"] as? String ?? "")\nhttps://dcs-learning.cnu.ac.kr/home"],automatic:true)
    }
  }
  static func unlink() { for key in prefs.dictionaryRepresentation().keys where key.hasPrefix("radarEvent:") || key.hasPrefix("radarEventSig:") || key.hasPrefix("radarEventManual:") || key.hasPrefix("radarCalendar") { prefs.removeObject(forKey:key) } }
}

// Cookies stay in the app's WebKit store. Portal credentials never enter JavaScript.
private final class CampusWebController: UIViewController, WKNavigationDelegate, WKUIDelegate {
  let args: [String: Any]
  let destination: URL
  var web: WKWebView!
  init(args: [String: Any], destination: URL) {
    self.args = args; self.destination = destination
    super.init(nibName: nil, bundle: nil)
  }
  required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }
  private func literal(_ value: Any) -> String {
    guard let data = try? JSONSerialization.data(withJSONObject: value, options: [.fragmentsAllowed]),
          let text = String(data: data, encoding: .utf8) else { return "null" }
    return text
  }
  override func viewDidLoad() {
    super.viewDidLoad()
    title = "사이버캠퍼스"
    navigationItem.leftBarButtonItem = UIBarButtonItem(title: "앱으로 돌아가기", style: .done, target: self, action: #selector(closePage))
    let config = WKWebViewConfiguration()
    let context = args["context"] as? String ?? literal(args["context"] ?? [:])
    let script = "if(location.origin==='https://dcs-learning.cnu.ac.kr'){sessionStorage.setItem('currentCourseData',\(literal(context)));}"
    config.userContentController.addUserScript(WKUserScript(source: script, injectionTime: .atDocumentStart, forMainFrameOnly: true))
    web = WKWebView(frame: .zero, configuration: config)
    web.navigationDelegate = self; web.uiDelegate = self
    web.translatesAutoresizingMaskIntoConstraints = false
    view.addSubview(web)
    NSLayoutConstraint.activate([web.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor), web.bottomAnchor.constraint(equalTo: view.bottomAnchor), web.leadingAnchor.constraint(equalTo: view.leadingAnchor), web.trailingAnchor.constraint(equalTo: view.trailingAnchor)])
    let group = DispatchGroup()
    for row in args["cookies"] as? [[String: String]] ?? [] {
      guard let origin = row["url"], let url = URL(string: origin), url.scheme == "https",
            ["dcs-learning.cnu.ac.kr", "dcs-lcms.cnu.ac.kr"].contains(url.host ?? ""),
            let header = row["cookie"] else { continue }
      for cookie in HTTPCookie.cookies(withResponseHeaderFields: ["Set-Cookie": header], for: url) {
        group.enter(); web.configuration.websiteDataStore.httpCookieStore.setCookie(cookie) { group.leave() }
      }
    }
    group.notify(queue: .main) { [weak self] in
      guard let self = self else { return }; self.web.load(URLRequest(url: self.destination))
    }
  }
  @objc private func closePage() { dismiss(animated: true) }
  func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
    guard let url = action.request.url, url.scheme == "https" else { decisionHandler(.cancel); return }
    if ["dcs-learning.cnu.ac.kr", "dcs-lcms.cnu.ac.kr"].contains(url.host ?? "") { decisionHandler(.allow) }
    else { decisionHandler(.cancel); if action.navigationType == .linkActivated { UIApplication.shared.open(url) } }
  }
  func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
    if action.targetFrame == nil { webView.load(action.request) }; return nil
  }
  func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
    guard webView.url?.host == "dcs-learning.cnu.ac.kr", webView.url?.path == "/std/course", let target = args["target"] as? String else { return }
    webView.evaluateJavaScript("(function(){var id=\(literal(target));var n=0;function jump(){var e=Array.from(document.querySelectorAll('[data-contentsid]')).find(e=>e.dataset.moduletype==='LV'&&(e.dataset.contentsid===id||e.dataset.weekseqno===id));if(e){var box=e.closest('.collapse');if(box)box.classList.add('show');e.scrollIntoView({block:'center'});if(window.courseAttend&&window.jQuery)courseAttend.detailContents(window.jQuery(e));}else if(n++<20)setTimeout(jump,500);}jump();})();", completionHandler: nil)
  }
}


private final class SyllabusController: UIViewController, WKNavigationDelegate, UIAdaptivePresentationControllerDelegate {
  let destination:URL;let course:String;let capture:Bool
  var completion:FlutterResult?;var web:WKWebView!;var timer:Timer?;var started=Date();var previous="";var stable=0
  static func trusted(_ url:URL)->Bool {url.scheme=="https" && ["cnuit.cnu.ac.kr","tlsn.cnu.ac.kr"].contains(url.host ?? "") && url.user==nil && url.password==nil}
  init(url:URL,course:String,capture:Bool,completion:FlutterResult?){self.destination=url;self.course=course;self.capture=capture;self.completion=completion;super.init(nibName:nil,bundle:nil)}
  required init?(coder:NSCoder){fatalError("unavailable")}
  override func viewDidLoad(){super.viewDidLoad();title=capture ? "계획서 가져오는 중":"강의계획서"
    navigationItem.leftBarButtonItem=UIBarButtonItem(title:"앱으로 돌아가기",style:.done,target:self,action:#selector(closePage))
    let config=WKWebViewConfiguration();config.websiteDataStore = .nonPersistent()
    web=WKWebView(frame:.zero,configuration:config);web.navigationDelegate=self;web.translatesAutoresizingMaskIntoConstraints=false;view.addSubview(web)
    NSLayoutConstraint.activate([web.topAnchor.constraint(equalTo:view.safeAreaLayoutGuide.topAnchor),web.bottomAnchor.constraint(equalTo:view.bottomAnchor),web.leadingAnchor.constraint(equalTo:view.leadingAnchor),web.trailingAnchor.constraint(equalTo:view.trailingAnchor)])
    web.load(URLRequest(url:destination));started=Date()
    if capture {timer=Timer.scheduledTimer(withTimeInterval:1,repeats:true){[weak self] _ in self?.poll()}}
  }
  override func viewDidAppear(_ animated:Bool){super.viewDidAppear(animated);navigationController?.presentationController?.delegate=self}
  func presentationControllerDidDismiss(_ presentationController:UIPresentationController){finish(nil)}
  @objc func closePage(){finish(nil);dismiss(animated:true)}
  func finish(_ value:Any?){timer?.invalidate();timer=nil;guard let cb=completion else{return};completion=nil;cb(value ?? FlutterError(code:"syllabus_cancelled",message:"계획서 가져오기가 취소되었거나 시간이 초과됐어요.",details:nil))}
  func poll(){if Date().timeIntervalSince(started)>60 {closePage();return}
    web.evaluateJavaScript(Self.extract){[weak self] value,error in
      guard let self=self,let raw=value as? String,let data=raw.data(using:.utf8),let obj=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any],let text=obj["text"] as? String else{return}
      let expected=self.course.filter{!$0.isWhitespace},normalized=text.filter{!$0.isWhitespace}
      let valid=(obj["fields"] as? Int ?? 0)>=8 && text.count>=400 && normalized.contains("교과목") && (expected.isEmpty || normalized.contains(expected))
      self.stable=valid && text==self.previous ? self.stable+1:0;self.previous=text
      if valid && self.stable>=2 {self.finish(["text":String(text.prefix(120000)),"sourceUrl":self.destination.absoluteString]);self.dismiss(animated:true)}
    }
  }
  func webView(_ webView:WKWebView,decidePolicyFor action:WKNavigationAction,decisionHandler:@escaping(WKNavigationActionPolicy)->Void){decisionHandler(action.request.url.map{Self.trusted($0)}==true ? .allow:.cancel)}
  deinit{timer?.invalidate()}
  static let extract = #"(function(){var lines=[],fields=0;function walk(n){if(n.nodeType===3){var t=n.textContent.trim();if(t)lines.push(t);return;}if(n.nodeType!==1)return;var tag=n.tagName;if(['SCRIPT','STYLE','NOSCRIPT'].indexOf(tag)>=0)return;var s=getComputedStyle(n);if(s.display==='none'||s.visibility==='hidden')return;if(n.getAttribute('role')==='textbox'&&!n.querySelector('input,textarea')){var rv=n.getAttribute('aria-valuetext')||n.innerText||'';if(rv.trim()){lines.push(rv.trim());fields++;}return;}if(tag==='INPUT'||tag==='TEXTAREA'){if(['password','hidden','checkbox','radio','button','submit'].indexOf(n.type)>=0)return;var v=n.value||'';if(v.trim()){lines.push(v.trim());fields++;}return;}for(var c=n.firstChild;c;c=c.nextSibling)walk(c);}walk(document.body);return JSON.stringify({text:lines.join('\n'),fields:fields});})();"#
}


private final class RadarFilePreview: QLPreviewController, QLPreviewControllerDataSource {
  let file: URL
  init(url: URL) { self.file = url; super.init(nibName: nil, bundle: nil); self.dataSource = self }
  required init?(coder: NSCoder) { fatalError("unavailable") }
  func numberOfPreviewItems(in controller: QLPreviewController) -> Int { 1 }
  func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem { file as NSURL }
}

import 'package:campus_radar/core/storage_keys.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Preserve 0.5.2's separate waiting category by default. This preference never
// changes availability, collection, daily summaries or notification eligibility.
final showWaitingAssignments = ValueNotifier<bool>(true);
Future<void> loadTaskDisplayPreferences() async {
  final prefs = await SharedPreferences.getInstance();
  showWaitingAssignments.value =
      prefs.getBool(PrefKey.showWaitingAssignments) ?? true;
}

Future<void> saveShowWaitingAssignments(bool value) async {
  final prefs = await SharedPreferences.getInstance();
  if (!await prefs.setBool(PrefKey.showWaitingAssignments, value)) {
    throw StateError('제출 대기 표시 설정을 저장하지 못했어요.');
  }
  showWaitingAssignments.value = value;
}

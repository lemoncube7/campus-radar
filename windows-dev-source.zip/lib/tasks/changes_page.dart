import 'package:campus_radar/tasks/task_presentation.dart';
import 'package:campus_radar/navigation/app_navigation.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'dart:convert';
import 'package:flutter/material.dart';

class ChangesPage extends StatefulWidget {
  final String? itemKey;
  const ChangesPage({super.key, this.itemKey});
  @override
  State<ChangesPage> createState() => _ChangesPageState();
}

class _ChangesPageState extends State<ChangesPage> {
  List<Map<String, dynamic>> changes = [];
  String? error;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final store = await Store.open();
    try {
      final rows = await store.db.query(
        'events',
        where: "id LIKE 'change:%'",
        orderBy: 'rowid DESC',
        limit: 200,
      );
      final list = rows
          .map(
            (r) =>
                Map<String, dynamic>.from(jsonDecode(r['payload'] as String)),
          )
          .where(
            (d) => widget.itemKey == null || d['item']['key'] == widget.itemKey,
          )
          .toList();
      if (mounted) setState(() => changes = list);
    } catch (_) {
      if (mounted) setState(() => error = '변경 이력을 불러오지 못했어요.');
    } finally {
      await store.db.close();
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('과제·콘텐츠 변경 이력')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('이 버전 이후 수집에서 발견한 마감·제목·설명 변경이에요. 제출 여부 변경은 알림 대상이 아니에요.'),
        if (error != null) Text(error!),
        if (changes.isEmpty)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Text('아직 발견한 변경 사항이 없어요.'),
          ),
        for (final d in changes)
          Card(
            child: ExpansionTile(
              title: Text(d['item']['title']),
              subtitle: Text(
                '${d['item']['course']} · ${formatDate(DateTime.parse(d['at']))}',
              ),
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: SelectableText(d['detail']),
                ),
                TextButton(
                  onPressed: () => openItem(d['item']['key']),
                  child: const Text('현재 항목 상세 보기'),
                ),
              ],
            ),
          ),
      ],
    ),
  );
}

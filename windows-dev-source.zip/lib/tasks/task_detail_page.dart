import 'package:campus_radar/core/app_storage.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:campus_radar/campus/campus_session.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/schedule/calendar_draft_page.dart';
import 'package:campus_radar/tasks/changes_page.dart';
import 'package:campus_radar/tasks/task_presentation.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/courses/media_widgets.dart';
import 'package:campus_radar/core/ui_refresh.dart';
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/campus/services.dart';

class DetailPage extends StatefulWidget {
  final CampusItem item;
  final bool excluded;
  const DetailPage({super.key, required this.item, this.excluded = false});
  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  bool busy = false, notTask = false, classificationReady = false;
  late bool excluded;
  @override
  void initState() {
    super.initState();
    excluded = widget.excluded;
    unawaited(loadClassification());
  }

  Future<void> loadClassification() async {
    Store? store;
    try {
      store = await Store.open();
      final value = (await store.notTasks()).contains(widget.item.key);
      if (mounted) {
        setState(() {
          notTask = value;
          classificationReady = true;
        });
      }
    } catch (_) {
      if (mounted) setState(() => classificationReady = false);
    } finally {
      await store?.db.close();
    }
  }

  Future<void> toggleNotTask() async {
    setState(() => busy = true);
    try {
      final reflected = await markNotTask(widget.item, !notTask);
      if (mounted) {
        setState(() => notTask = !notTask);
        if (!reflected) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('분류는 저장했어요. 알림·위젯은 다음 수집에서 다시 반영해요.')),
          );
        }
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('변경하지 못했어요. 다시 시도해 주세요.')));
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> toggleExcluded() async {
    if (!excluded) {
      final accepted = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('목록에서 숨길까요?'),
          content: const Text(
            '이 기기의 목록에서 숨기고 해당 항목의 알림을 취소해요. 숨김 목록에서 다시 복구할 수 있어요.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('취소'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('제외'),
            ),
          ],
        ),
      );
      if (accepted != true) return;
    }
    setState(() => busy = true);
    try {
      final restoring = excluded;
      await excludeItem(widget.item, !excluded);
      // "할 일 아님" also keeps the item hidden; restoring must clear it too.
      if (restoring && notTask) await markNotTask(widget.item, false);
      if (mounted) {
        setState(() {
          excluded = !excluded;
          if (restoring) notTask = false;
        });
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('변경하지 못했어요. 다시 시도해 주세요.')));
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> go() async {
    setState(() => busy = true);
    final client = CampusClient();
    try {
      final id = await credentials.read(key: 'id'),
          pw = await credentials.read(key: 'pw');
      if (id == null || pw == null) throw CampusException('포털을 다시 연결해 주세요.');
      await client.connectSchool(id, pw);
      final navigation = await client.navigation(widget.item);
      await bridge.invokeNative(NativeMethod.openCampus, navigation);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              e is CampusException ? e.message : '사이버캠퍼스를 열지 못했어요.',
            ),
          ),
        );
      }
    } finally {
      client.close();
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final i = widget.item;
    return Scaffold(
      appBar: AppBar(
        title: Text('${i.kindLabel} 상세'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) =>
                value == 'notTask' ? toggleNotTask() : toggleExcluded(),
            itemBuilder: (_) => [
              if (!widget.item.isMaterial)
                PopupMenuItem(
                  value: 'notTask',
                  enabled: classificationReady && !busy,
                  child: Text(notTask ? '할 일로 복구' : '할 일 아님'),
                ),
              PopupMenuItem(
                value: 'visibility',
                child: Text(excluded ? '목록에 복구' : '목록에서 숨기기'),
              ),
            ],
          ),
        ],
      ),
      bottomNavigationBar: PinnedAction(
        child: FilledButton.icon(
          onPressed: busy ? null : go,
          icon: const Icon(Icons.open_in_new),
          label: Text(busy ? '연결 중…' : '사이버캠퍼스 열기'),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          if (notTask)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('할 일 아님 · 미완료 개수와 알림에서 제외돼요. 원문은 계속 볼 수 있어요.'),
                    TextButton(
                      onPressed: busy ? null : toggleNotTask,
                      child: const Text('할 일로 복구'),
                    ),
                  ],
                ),
              ),
            ),
          Text(courseLabel(i.course)),
          const SizedBox(height: 4),
          Text(
            i.title,
            style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          // A real score keeps its place right under the title; an empty
          // placeholder card no longer takes that spot.
          if (i.type == 'LR' && i.evaluation != null)
            Card(
              color: Theme.of(context).colorScheme.primaryContainer,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
                side: BorderSide(
                  color: Theme.of(
                    context,
                  ).colorScheme.primary.withValues(alpha: 0.45),
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '내 평가 결과',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    ...[
                      Text(
                        '${i.evaluation!.score}${i.evaluation!.maximum.isEmpty ? '점' : ' / ${i.evaluation!.maximum}점'}',
                        style: Theme.of(context).textTheme.headlineMedium
                            ?.copyWith(
                              color: Theme.of(
                                context,
                              ).colorScheme.onPrimaryContainer,
                              fontWeight: FontWeight.w800,
                            ),
                      ),
                      if (i.evaluation!.feedback.isNotEmpty)
                        SelectableText(i.evaluation!.feedback),
                      const Text(
                        '학교에서 공개한 본인 결과 · 마지막 수집 기준',
                        style: TextStyle(fontSize: 12),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          // Deadline and state lead: the time, then state and remaining time.
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (!i.isMaterial)
                    Text(
                      i.due == null ? '마감 미확인' : '마감 ${formatDate(i.due!)}',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      Chip(label: Text(statusText(i))),
                      Chip(
                        label: Text(
                          remainingText(i),
                          style: TextStyle(color: deadlineColor(i, context)),
                        ),
                      ),
                      if (excluded) const Chip(label: Text('숨김 · 알림 꺼짐')),
                    ],
                  ),
                  if (i.startsAt != null) Text('시작 ${formatDate(i.startsAt!)}'),
                  if (i.type == 'LV') Text(i.attendanceLabel),
                  if (i.progress.isNotEmpty)
                    Text(
                      i.progress,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  if (i.additionalDue != null)
                    Text(
                      '추가 제출 ${i.additionalStartsAt == null ? '' : formatDate(i.additionalStartsAt!)} ~ ${formatDate(i.additionalDue!)}',
                    ),
                  if (i.originalDue != null && i.additionalDue != null)
                    Text('기본 마감 ${formatDate(i.originalDue!)}'),
                ],
              ),
            ),
          ),
          if (i.externalUrl.isNotEmpty)
            OutlinedButton.icon(
              onPressed: () => launchUrl(
                Uri.parse(i.externalUrl),
                mode: LaunchMode.externalApplication,
              ),
              icon: const Icon(Icons.open_in_new),
              label: const Text('외부 링크·온라인 수업 열기'),
            ),
          if (!i.isMaterial && (Platform.isAndroid || Platform.isIOS))
            TextButton.icon(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => CalendarDraftPage(
                    itemKey: i.key,
                    title: i.title,
                    deadlineCourse: i.course,
                    description:
                        '마감 일정 · 한국 시간\n${i.body}\nhttps://dcs-learning.cnu.ac.kr/home',
                    start: i.due,
                    deadline: true,
                  ),
                ),
              ),
              icon: const Icon(Icons.event_available),
              label: Text(Platform.isWindows ? '일정 파일 저장' : '캘린더에 전송'),
            ),

          TextButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ChangesPage(itemKey: i.key)),
            ),
            icon: const Icon(Icons.history),
            label: const Text('이 항목의 변경 이력'),
          ),
          const SizedBox(height: 20),
          CampusBodyView(
            body: i.body.isEmpty ? '상세 내용은 사이버캠퍼스에서 확인하세요.' : i.body,
            bodyHtml: i.bodyHtml,
            media: i.media,
          ),
          const SizedBox(height: 28),
          if (!i.isMaterial)
            const Text(
              '제출·완료 상태는 마지막 수집 기준이에요. 콘텐츠는 해당 강의의 학습 항목으로 연결해요.',
              style: TextStyle(fontSize: 12),
            ),
        ],
      ),
    );
  }
}

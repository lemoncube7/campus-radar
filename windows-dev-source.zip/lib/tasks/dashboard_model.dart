import 'package:flutter/material.dart' show DateUtils;
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/campus/learning_resources.dart';
import 'package:campus_radar/tasks/task_categories.dart';

/// Task-list filter state of the dashboard (was ten loose fields on the
/// dashboard state). Pure: no storage, widgets or platform access.
class TaskFilter {
  String type = '', course = '', deadline = '', sort = 'due', query = '';
  bool showDone = false,
      waitingOnly = false,
      completedOnly = false,
      showExcluded = false,
      hiddenOnly = false;

  /// Rows the task list shows. [waiting] is [waitingOnly] combined with the
  /// "show waiting assignments" display preference.
  List<CampusItem> apply(
    List<CampusItem> items, {
    required DateTime now,
    required Set<String> excluded,
    required Set<String> notTaskKeys,
    required bool waiting,
  }) => items
      .where(
        (i) =>
            (!hiddenOnly || !notTaskKeys.contains(i.key)) &&
            categoryMatches(
              i,
              now,
              excluded,
              waiting: waiting,
              completed: completedOnly,
              hiddenOnly: hiddenOnly,
              showHidden: showExcluded,
              showDone: showDone,
            ) &&
            taskTypeMatches(i, type) &&
            (course.isEmpty || i.course == course) &&
            (deadline.isEmpty ||
                (deadline == 'today' && dueTodayKst(i, now)) ||
                deadlineState(i.due, now: now).name == deadline) &&
            '${i.title} ${i.course} ${courseLabel(i.course)}'
                .toLowerCase()
                .contains(query.toLowerCase()),
      )
      .toList();
}

/// Still due later today, Korean calendar day.
bool dueTodayKst(CampusItem i, DateTime now) =>
    i.due != null &&
    i.due!.isAfter(now) &&
    DateUtils.isSameDay(
      now.add(const Duration(hours: 9)),
      i.due!.toUtc().add(const Duration(hours: 9)),
    );

/// Home-screen counts: open items ordered upcoming first, those due within
/// 24 hours, and how many fall due later today.
class DashboardCounts {
  final List<CampusItem> pending, urgent;
  final int today;
  const DashboardCounts._(this.pending, this.urgent, this.today);

  factory DashboardCounts.of(
    List<CampusItem> items,
    Set<String> excluded,
    DateTime now,
  ) {
    final pending =
        items
            .where(
              (i) =>
                  i.availableAt(now) && !excluded.contains(i.key) && i.openTask,
            )
            .toList()
          ..sort((a, b) {
            final aPast = a.due != null && !a.due!.isAfter(now);
            final bPast = b.due != null && !b.due!.isAfter(now);
            if (aPast != bPast) return aPast ? 1 : -1;
            return (a.due ?? DateTime.utc(2100)).compareTo(
              b.due ?? DateTime.utc(2100),
            );
          });
    return DashboardCounts._(
      pending,
      pending
          .where(
            (i) => deadlineState(i.due, now: now) == DeadlineState.withinDay,
          )
          .toList(),
      pending.where((i) => dueTodayKst(i, now)).length,
    );
  }
}

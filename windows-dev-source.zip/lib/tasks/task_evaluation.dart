import 'package:html/parser.dart' as html;

class TaskEvaluation {
  final String score, maximum, feedback;
  const TaskEvaluation({
    required this.score,
    this.maximum = '',
    this.feedback = '',
  });
  Map<String, dynamic> toJson() => {
    'score': score,
    'maximum': maximum,
    'feedback': feedback,
  };
  factory TaskEvaluation.fromJson(Map<String, dynamic> j) => TaskEvaluation(
    score: '${j['score']}',
    maximum: '${j['maximum'] ?? ''}',
    feedback: '${j['feedback'] ?? ''}',
  );
}

TaskEvaluation? releasedTaskEvaluation(
  dynamic raw,
  Map<String, dynamic> detail,
) {
  if (raw is List && raw.length == 1) raw = raw.single;
  if (raw is! Map ||
      raw['result_open_yn'] != 'Y' ||
      raw['mark_yn'] != 'Y' ||
      raw['report_scr'] == null ||
      num.tryParse('${raw['report_scr']}') == null) {
    return null;
  }
  return TaskEvaluation(
    score: '${raw['report_scr']}',
    maximum: '${detail['allot_scr'] ?? ''}',
    feedback:
        html.parse('${raw['report_apply_cmt'] ?? ''}').body?.text.trim() ?? '',
  );
}

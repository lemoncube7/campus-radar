import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/core/ui_formatters.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:campus_radar/ai/ai_automation.dart';
import 'package:campus_radar/ai/ai_state_repository.dart';

class AutomationControls extends StatefulWidget {
  const AutomationControls({super.key});
  @override
  State<AutomationControls> createState() => _AutomationControlsState();
}

class _AutomationControlsState extends State<AutomationControls> {
  bool auto = false, summary = false, busy = true;
  String scope = 'recent', message = '';
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    Store? s;
    try {
      s = await Store.open();
      final a = await s.meta(MetaKey.aiAuto) == 'yes',
          d = await s.meta(MetaKey.aiSummary) == 'yes',
          sc = await s.meta(MetaKey.aiScope) ?? 'recent';
      if (mounted) {
        setState(() {
          auto = a;
          summary = d;
          scope = sc;
          busy = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          busy = false;
          message = "설정을 읽지 못했습니다. 화면을 다시 열어 주세요.";
        });
      }
    } finally {
      await s?.db.close();
    }
  }

  Future<void> save() async {
    setState(() => busy = true);
    final s = await Store.open();
    try {
      if ((auto || summary) &&
          (await credentials.read(key: 'geminiApiKey') == null ||
              await s.meta(MetaKey.aiConsent) != aiConsentVersion)) {
        throw const AiFailure('먼저 위에서 개인 키와 공지 외부 전송 동의를 저장해 주세요.');
      }
      final oldScope = await s.meta(MetaKey.aiScope);
      if (auto && (await s.meta(MetaKey.aiAuto) != 'yes' || oldScope != scope)) {
        if (scope == 'new') {
          await s.setMeta(MetaKey.aiBaseline,
            jsonEncode((await s.notices()).map((n) => n.id).toList()),
          );
        }
        await AiStateRepository(s).resetQueueKeepingUserDecisions();
      }
      await s.setMeta(MetaKey.aiScope, scope);
      await s.setAiSetting(AiSetting.aiAuto, auto ? 'yes' : 'no');
      await s.setAiSetting(AiSetting.aiSummary, summary ? 'yes' : 'no');
      final p = await SharedPreferences.getInstance();
      await p.setBool(PrefKey.aiSummaryEnabled, summary);
      if (!summary) {
        await p.remove(PrefKey.aiSummaryText);
        await s.setMeta(MetaKey.aiSummaryText, '');
      }
      await enqueueNotices(s);
      await s.log(
        'ai',
        'AI 자동화 설정 저장',
        '공지 자동 분석 ${auto ? "켬" : "끔"} · 요약 ${summary ? "켬" : "끔"} · 범위 $scope',
      );
      if (auto || summary) {
        await scheduleSummaryWarmup(
          p.getInt(PrefKey.aiDailyHour) ?? 18,
          p.getInt(PrefKey.aiDailyMinute) ?? 0,
          p.getBool(PrefKey.aiDailyEnabled) ?? false,
        );
        await scheduleAiWork();
        unawaited(processAiWork());
      }
      if (mounted) {
        setState(
          () => message = '저장했어요. 검토함에서 진행 상황을 확인하세요. 실행 중 요청은 완료 후 중지돼요.',
        );
      }
    } catch (e) {
      if (mounted) setState(() => message = userError(e));
    } finally {
      await s.db.close();
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Divider(height: 40),
      const Text(
        '자동 분석과 요약',
        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
      ),
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('공지 자동 순차 분석'),
        subtitle: const Text(
          '선택 범위의 공지 본문을 가져와 Google에 전송해요. 분석 결과는 검토함에 모으며 캘린더에 자동 등록하지 않아요.',
        ),
        value: auto,
        onChanged: busy ? null : (v) => setState(() => auto = v),
      ),
      DropdownButtonFormField<String>(
        key: ValueKey(scope),
        initialValue: scope,
        decoration: const InputDecoration(labelText: '처음 분석할 공지 범위'),
        items: const [
          DropdownMenuItem(value: 'new', child: Text('설정 이후 신규 공지만')),
          DropdownMenuItem(value: 'recent', child: Text('최근 7일 (권장)')),
          DropdownMenuItem(value: 'all', child: Text('현재 수집된 학기 전체')),
        ],
        onChanged: busy ? null : (v) => setState(() => scope = v ?? 'recent'),
      ),
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('AI 하루 요약 사용'),
        subtitle: const Text(
          '미완료 과제·콘텐츠의 과목명·제목·마감·상태를 Google에 전송하는 데 동의해요. AI가 우선 항목을 고르고 실제 일정 값은 앱이 표시해요. 실패하면 기본 요약을 사용해요.',
        ),
        value: summary,
        onChanged: busy ? null : (v) => setState(() => summary = v),
      ),
      if (message.isNotEmpty) Text(message),
      FilledButton.tonal(
        onPressed: busy ? null : save,
        child: const Text('자동화 설정 저장·시작'),
      ),
    ],
  );
}

import 'package:campus_radar/core/storage_keys.dart';
import 'dart:convert';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/operation_token.dart';
import 'package:campus_radar/core/session_scope.dart';

class AudienceReviewReceipt {
  final String epoch;
  final Map<String, String?> before;
  final Map<String, String> after;
  const AudienceReviewReceipt(this.epoch, this.before, this.after);
}

class AudienceReviewRepository {
  final Store store;
  const AudienceReviewRepository(this.store);

  Future<AudienceReviewReceipt> apply(
    List<String> keys,
    Set<String> selected,
  ) async {
    if (keys.isEmpty ||
        keys.toSet().length != keys.length ||
        !selected.every(keys.contains)) {
      throw const FormatException('선택한 항목을 다시 확인해 주세요.');
    }
    final scope = await SessionScope.capture(store);
    final token = freshToken();
    final before = <String, String?>{}, after = <String, String>{};
    await store.db.transaction((txn) async {
      final epoch = await txn.query(
        'meta',
        where: 'id=?',
        whereArgs: ['sessionEpoch'],
      );
      if (epoch.single['value'] != scope.epoch) throw SessionChanged();
      for (final key in keys) {
        final id = MetaKey.aiState(key);
        final rows = await txn.query('meta', where: 'id=?', whereArgs: [id]);
        final raw = rows.isEmpty ? null : rows.single['value'] as String;
        final state = raw == null
            ? <String, dynamic>{}
            : Map<String, dynamic>.from(jsonDecode(raw) as Map);
        if ((state['status'] ?? 'review') != 'review') {
          throw const FormatException('이미 처리된 항목이 있어요. 목록을 새로 확인해 주세요.');
        }
        before[id] = raw;
        after[id] = jsonEncode({
          ...state,
          'status': selected.contains(key) ? 'review' : 'excluded',
          'audienceConfirmed': selected.contains(key),
          'reviewBatch': token,
          'resolution': selected.contains(key)
              ? 'audienceVerified'
              : 'notMyAudience',
        });
        await txn.rawInsert(
          'INSERT OR REPLACE INTO meta(id,value) VALUES(?,?)',
          [id, after[id]],
        );
      }
    });
    return AudienceReviewReceipt(scope.epoch, before, after);
  }

  Future<void> undo(AudienceReviewReceipt receipt) async {
    final scope = await SessionScope.capture(store);
    if (scope.epoch != receipt.epoch) throw SessionChanged();
    await store.db.transaction((txn) async {
      final epoch = await txn.query(
        'meta',
        where: 'id=?',
        whereArgs: ['sessionEpoch'],
      );
      if (epoch.single['value'] != receipt.epoch) throw SessionChanged();
      for (final entry in receipt.after.entries) {
        final rows = await txn.query(
          'meta',
          where: 'id=?',
          whereArgs: [entry.key],
        );
        if (rows.isEmpty || rows.single['value'] != entry.value) {
          throw const FormatException('이후 처리 상태가 바뀐 항목이 있어 실행 취소하지 않았어요.');
        }
      }
      for (final entry in receipt.before.entries) {
        if (entry.value == null) {
          await txn.delete('meta', where: 'id=?', whereArgs: [entry.key]);
        } else {
          await txn.rawInsert(
            'INSERT OR REPLACE INTO meta(id,value) VALUES(?,?)',
            [entry.key, entry.value],
          );
        }
      }
    });
  }
}

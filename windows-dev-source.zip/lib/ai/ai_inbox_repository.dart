import 'package:campus_radar/core/storage_keys.dart';
import 'dart:convert';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/ai/ai_state_repository.dart';

/// Read-only join of durable candidates, current notice caches and queue records.
/// Stale confirmed records remain visible; stale unreviewed records are omitted.
class AiInboxSnapshot {
  final List<Map<String, dynamic>> candidates, jobs;
  final bool enabled;
  final String recentQuestion;
  final String? blockedCode;
  final List<String> damagedRecords;
  const AiInboxSnapshot(
    this.candidates,
    this.jobs,
    this.enabled,
    this.recentQuestion,
    this.blockedCode, {
    this.damagedRecords = const [],
  });
}

class AiInboxRepository {
  final Store s;
  const AiInboxRepository(this.s);
  Future<AiInboxSnapshot> read() async {
    final damaged = <String>{};
    bool corrupt(Object e) =>
        e is FormatException ||
        e is TypeError ||
        e is AiFailure ||
        e is ArgumentError;
    final notices = await s.notices();
    final list = <Map<String, dynamic>>[], queue = <Map<String, dynamic>>[];
    final records = await s.db.query(
      'meta',
      where: 'id LIKE ?',
      whereArgs: ['aiCandidate:%'],
    );
    final seen = <String>{};
    // Same notice + same date/time/title is one schedule even if keyed apart.
    final seenSlots = <String>{};
    String slotOf(CampusNotice n, ScheduleCandidate c) => jsonEncode([
      n.id,
      c.title,
      c.date,
      c.time,
      c.endDate,
      c.endTime,
      c.action,
    ]);
    for (final r in records) {
      try {
        final record = Map<String, dynamic>.from(
          jsonDecode(r['value'] as String),
        );
        final n = CampusNotice.fromJson(
          Map<String, dynamic>.from(record['notice']),
        );
        final c = ScheduleCandidate.parse(
          Map<String, dynamic>.from(record['candidate']),
          '${n.title}\n${n.body}',
        );
        final k = record['key'] as String,
            st = (await AiStateRepository(s).schedule(k)).toJson();
        _validateState(st);
        final current = notices.where((x) => x.id == n.id).firstOrNull;
        final stale =
            current == null ||
            noticeFingerprint(current) != noticeFingerprint(n);
        if (stale && st['status'] != 'confirmed') continue;
        seen.add(k);
        seenSlots.add(slotOf(n, c));
        list.add({'notice': n, 'candidate': c, 'key': k, 'state': st});
      } catch (e) {
        if (!corrupt(e)) rethrow;
        damaged.add(r['id'] as String);
      }
    }
    for (final n in notices) {
      final raw = await s.meta('aiCache:${n.id}:${noticeFingerprint(n)}');
      if (raw != null) {
        List rows;
        try {
          rows = jsonDecode(raw) as List;
        } catch (e) {
          if (!corrupt(e)) rethrow;
          damaged.add(MetaKey.aiCache(n.id));
          rows = [];
        }
        for (final e in rows) {
          try {
            var c = ScheduleCandidate.parse(
              Map<String, dynamic>.from(e),
              '${n.title}\n${n.body}',
            );
            if (seenSlots.contains(slotOf(n, c))) continue;
            var k = candidateKey(n, c);
            if (seen.contains(k) && c.originKey.isEmpty) {
              // A sibling from the same sentence with another date.
              c = ScheduleCandidate.parse({
                ...c.toJson(),
                'originKey': distinctCandidateKey(n, c),
              }, '${n.title}\n${n.body}');
              k = candidateKey(n, c);
            }
            final state = (await AiStateRepository(s).schedule(k)).toJson();
            _validateState(state);
            if (seen.add(k)) {
              seenSlots.add(slotOf(n, c));
              list.add({'notice': n, 'candidate': c, 'key': k, 'state': state});
            }
          } catch (e) {
            if (!corrupt(e)) rethrow;
            damaged.add(MetaKey.aiCache(n.id));
          }
        }
      }
      final q = await s.meta(MetaKey.aiQueue(n.id));
      if (q != null) {
        try {
          final data = Map<String, dynamic>.from(jsonDecode(q));
          if (data['status'] is! String) {
            throw const FormatException('Missing job state');
          }
          queue.add({...data, 'id': n.id});
        } catch (e) {
          if (!corrupt(e)) rethrow;
          damaged.add(MetaKey.aiQueue(n.id));
        }
      }
    }
    final enabled = await s.meta(MetaKey.aiAuto) == 'yes';
    List chat;
    try {
      chat = jsonDecode(await s.meta('aiChat:all') ?? '[]') as List;
    } catch (e) {
      if (!corrupt(e)) rethrow;
      damaged.add('aiChat:all');
      chat = [];
    }
    final lastQuestion = chat
        .whereType<Map>()
        .where((m) => m['role'] == 'user' && m['text'] is String)
        .lastOrNull;
    final blocked = queue
        .where(
          (j) => j['status'] == 'failed' && j['errorCode'] == 'credentials',
        )
        .firstOrNull;
    for (final row in list) {
      final raw = await s.meta('aiApproval:${row['key']}');
      if (raw == null) continue;
      try {
        final review = jsonDecode(raw) as Map;
        final n = row['notice'] as CampusNotice;
        if (review['fingerprint'] == noticeFingerprint(n)) {
          row['approvalReview'] = review;
        }
      } catch (e) {
        if (!corrupt(e)) rethrow;
        damaged.add('aiApproval:${row['key']}');
      }
    }
    return AiInboxSnapshot(
      list,
      queue,
      enabled,
      lastQuestion?['text'] as String? ?? '',
      blocked?['errorCode'] as String?,
      damagedRecords: damaged.toList(),
    );
  }
}

void _validateState(Map<String, dynamic> state) {
  for (final key in [
    'title',
    'start',
    'end',
    'date',
    'courseLabel',
    'status',
    'approvalReason',
  ]) {
    if (state[key] != null && state[key] is! String) {
      throw const FormatException('Invalid stored schedule field');
    }
  }
  for (final key in ['allDay', 'calendarSent', 'audienceConfirmed']) {
    if (state[key] != null && state[key] is! bool) {
      throw const FormatException('Invalid stored schedule flag');
    }
  }
  for (final key in ['start', 'end']) {
    if (state[key] is String &&
        (state[key] as String).isNotEmpty &&
        DateTime.tryParse(state[key]) == null) {
      throw const FormatException('Invalid stored schedule date');
    }
  }
}

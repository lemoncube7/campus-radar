import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'dart:async';

class AiRunResult {
  final List<ScheduleCandidate> events;
  final Map<String, dynamic> response;
  const AiRunResult(this.events, this.response);
}

/// One corrective request at most; quota/permissions/network errors are not retried here.
Future<AiRunResult> analyzeAiWithRepair(
  CampusNotice notice,
  String key, {
  required AiTransport transport,
  Map<String, dynamic> timetable = const {},
  String supplemental = '',
  String repairHint = '',
  Future<void> Function(int attempt)? beforeRequest,
  Future<void> Function(
    int attempt,
    AiFailure error,
    Map<String, dynamic> response,
  )?
  onInvalid,
}) async {
  var hint = repairHint;
  for (var attempt = 1; attempt <= 2; attempt++) {
    await beforeRequest?.call(attempt);
    final response = await transport(
      key,
      aiRequest(
        notice,
        timetable: timetable,
        supplemental: supplemental,
        repairHint: hint,
      ),
    );
    try {
      var events = parseAiResponse(response, notice, timetable: timetable);
      final gaps = aiCoverageGaps(notice, events);
      if (gaps.isNotEmpty) {
        final failure = AiFailure(
          '원문에 있는 일부 날짜의 일정이 누락됐어요.',
          code: 'coverage',
          detail: '추가 확인할 원문 문단: ${gaps.join(', ')}. 제출·발표·휴강·보강 날짜를 모두 검토하세요.',
        );
        if (attempt == 1 || events.isEmpty) throw failure;
        await onInvalid?.call(attempt, failure, response);
        // Keep validated candidates usable; clearly surface remaining omissions.
        events = events
            .map(
              (e) => ScheduleCandidate.parse({
                ...e.toJson(),
                'uncertainty':
                    '${e.uncertainty}\n원문에 추가 일정이 있을 수 있어요. 문단 ${gaps.join(', ')}도 확인해 주세요.'
                        .trim(),
              }, '${notice.title}\n${notice.body}'),
            )
            .toList();
      }
      return AiRunResult(events, response);
    } on AiFailure catch (e) {
      await onInvalid?.call(attempt, e, response);
      if (attempt == 2 ||
          ![
            'evidence',
            'dateEvidence',
            'timeEvidence',
            'timetable',
            'date',
            'time',
            'category',
            'format',
            'coverage',
          ].contains(e.code)) {
        rethrow;
      }
      hint = '$repairHint\n${e.code}: ${e.message} ${e.detail}'.trim();
    }
  }
  throw const AiFailure('일정 검증을 완료하지 못했어요.');
}

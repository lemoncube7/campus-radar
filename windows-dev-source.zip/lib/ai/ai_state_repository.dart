import 'package:campus_radar/core/storage_keys.dart';
import 'dart:convert';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/ai/ai_state_models.dart';

/// Owns the legacy wire keys. Callers use typed state while stored JSON remains
/// compatible with released versions and preserves unknown fields.
class AiStateRepository {
  final Store store;
  const AiStateRepository(this.store);
  Future<AiJob> job(String noticeId) async =>
      AiJob.decode(await store.meta(MetaKey.aiQueue(noticeId)));
  Future<void> saveJob(String noticeId, AiJob job) =>
      store.setMeta(MetaKey.aiQueue(noticeId), jsonEncode(job.toJson()));
  Future<ConfirmedSchedule> schedule(String key) async =>
      ConfirmedSchedule.decode(await store.meta(MetaKey.aiState(key)));
  Future<void> saveSchedule(String key, ConfirmedSchedule state) =>
      store.setMeta(MetaKey.aiState(key), jsonEncode(state.toJson()));
  /// Clears queue rows so notices are re-evaluated, but keeps rows the user
  /// decided on (excluded from analysis, or handled manually).
  Future<void> resetQueueKeepingUserDecisions() async {
    final rows = await store.db.query(
      'meta',
      where: 'id LIKE ?',
      whereArgs: ['aiQueue:%'],
    );
    for (final r in rows) {
      AiJobStatus status;
      try {
        status = AiJob.decode(r['value'] as String?).status;
      } catch (_) {
        status = AiJobStatus.unknown;
      }
      if (status == AiJobStatus.excluded || status == AiJobStatus.manual) {
        continue;
      }
      await store.db.delete('meta', where: 'id = ?', whereArgs: [r['id']]);
    }
  }

  Future<bool> hasActiveJobs() async {
    final rows = await store.db.query(
      'meta',
      where: 'id LIKE ?',
      whereArgs: ['aiQueue:%'],
    );
    return rows.any((r) => AiJob.decode(r['value'] as String).isActive);
  }
}

import 'package:campus_radar/core/storage_keys.dart';
import 'package:sqflite/sqflite.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/operation_token.dart';
import 'package:campus_radar/ai/ai_protocol.dart';

Future<void> releaseAiRequest(Store store) async {
  final owner = store.aiRequestOwner;
  if (owner == null) return;
  await store.db.transaction((txn) async {
    final rows = await txn.query(
      'meta',
      where: 'id=?',
      whereArgs: ['aiNetworkOwner'],
    );
    if (rows.isNotEmpty && rows.single['value'] == owner) {
      await txn.delete('meta', where: 'id=?', whereArgs: ['aiNetworkOwner']);
      await txn.insert('meta', {
        'id': 'aiNetworkUntil',
        'value': '0',
      }, conflictAlgorithm: ConflictAlgorithm.replace);
    }
  });
  store.aiRequestOwner = null;
}

Future<void> claimAiRequest(Store store, {bool interactive = false}) async {
  await store.db.transaction((txn) async {
    Future<String?> value(String key) async {
      final r = await txn.query('meta', where: 'id=?', whereArgs: [key]);
      return r.isEmpty ? null : r.first['value'] as String;
    }

    final now = DateTime.now().toUtc();
    final lease = int.tryParse(await value('aiNetworkUntil') ?? '0') ?? 0;
    final pending = int.tryParse(await value('aiInteractiveUntil') ?? '0') ?? 0;
    if (!interactive && pending > now.millisecondsSinceEpoch) {
      throw const AiFailure('사용자 질문 대기 중', code: 'busy');
    }
    final last = DateTime.tryParse(await value('aiLastRequest') ?? '');
    if (lease > now.millisecondsSinceEpoch ||
        last != null && now.difference(last) < const Duration(seconds: 5)) {
      throw const AiFailure('다른 요청 완료 후 잠시 기다려 주세요.', code: 'busy');
    }
    Future<void> set(String key, String data) => txn
        .insert('meta', {
          'id': key,
          'value': data,
        }, conflictAlgorithm: ConflictAlgorithm.replace)
        .then((_) {});
    final owner = freshToken();
    await set('aiNetworkOwner', owner);
    store.aiRequestOwner = owner;
    await set('aiNetworkUntil', '${now.millisecondsSinceEpoch + 180000}');
    await set('aiLastRequest', now.toIso8601String());
    final counter =
        MetaKey.aiRequests(now.add(const Duration(hours: 9)).toIso8601String().substring(0, 10));
    await set(
      counter,
      '${(int.tryParse(await value(counter) ?? '0') ?? 0) + 1}',
    );
  });
}

/// Re-arms this store's own network lease for a follow-up request (the one
/// corrective attempt) without letting another claimant in between.
Future<void> renewAiRequest(Store store) async {
  final owner = store.aiRequestOwner;
  if (owner == null) return claimAiRequest(store);
  final renewed = await store.db.transaction((txn) async {
    final rows = await txn.query(
      'meta',
      where: 'id=?',
      whereArgs: ['aiNetworkOwner'],
    );
    if (rows.isEmpty || rows.single['value'] != owner) return false;
    final now = DateTime.now().toUtc();
    Future<void> set(String key, String data) => txn
        .insert('meta', {
          'id': key,
          'value': data,
        }, conflictAlgorithm: ConflictAlgorithm.replace)
        .then((_) {});
    await set('aiNetworkUntil', '${now.millisecondsSinceEpoch + 180000}');
    await set('aiLastRequest', now.toIso8601String());
    final counter =
        MetaKey.aiRequests(now.add(const Duration(hours: 9)).toIso8601String().substring(0, 10));
    final r = await txn.query('meta', where: 'id=?', whereArgs: [counter]);
    final count = r.isEmpty ? 0 : int.tryParse(r.first['value'] as String) ?? 0;
    await set(counter, '${count + 1}');
    return true;
  });
  if (!renewed) {
    store.aiRequestOwner = null;
    await claimAiRequest(store);
  }
}

/// Cross-isolate lock for analysing one notice, held for the whole analysis
/// (cache path and candidate writes included). The app and the background
/// worker run in different isolates, so an in-memory flag cannot do this.
Future<String> claimNoticeAnalysis(Store store, String noticeId) =>
    store.db.transaction((txn) async {
      final id = 'aiAnalyzing:$noticeId';
      final rows = await txn.query('meta', where: 'id=?', whereArgs: [id]);
      final now = DateTime.now().millisecondsSinceEpoch;
      if (rows.isNotEmpty) {
        final until =
            int.tryParse('${rows.single['value']}'.split('|').last) ?? 0;
        if (until > now) {
          throw const AiFailure(
            '이 공지를 이미 분석하고 있어요. 끝나면 다시 확인해 주세요.',
            code: 'busy',
          );
        }
      }
      final owner = freshToken();
      await txn.insert('meta', {
        'id': id,
        'value': '$owner|${now + 600000}',
      }, conflictAlgorithm: ConflictAlgorithm.replace);
      return owner;
    });

Future<void> releaseNoticeAnalysis(
  Store store,
  String noticeId,
  String owner,
) => store.db.transaction((txn) async {
  final id = 'aiAnalyzing:$noticeId';
  final rows = await txn.query('meta', where: 'id=?', whereArgs: [id]);
  if (rows.isNotEmpty && '${rows.single['value']}'.startsWith('$owner|')) {
    await txn.delete('meta', where: 'id=?', whereArgs: [id]);
  }
});

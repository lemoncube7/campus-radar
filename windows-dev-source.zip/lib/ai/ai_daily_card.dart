import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/school_time.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:campus_radar/ai/ai_automation.dart';

class DailySummarySection extends StatelessWidget {
  final Widget? child;
  const DailySummarySection({super.key, this.child});

  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: const Icon(Icons.auto_awesome_outlined),
      title: const Text('하루 요약 보기'),
      subtitle: const Text('오늘 현황과 AI 요약을 자세히 확인해요'),
      trailing: const Icon(Icons.chevron_right),
      onTap: () => child == null
          ? navigateTo(context, const SummaryDestination())
          : Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => Scaffold(
                  appBar: AppBar(title: const Text('하루 요약')),
                  body: child,
                ),
              ),
            ),
    ),
  );
}

class AiDailyCard extends StatefulWidget {
  const AiDailyCard({super.key});
  @override
  State<AiDailyCard> createState() => _AiDailyCardState();
}

class _AiDailyCardState extends State<AiDailyCard> {
  String? text;
  bool enabled = false, busy = false;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    Store? s;
    try {
      s = await Store.open();
      final on = await s.meta(MetaKey.aiSummary) == 'yes';
      final p = await SharedPreferences.getInstance();
      await p.reload();
      final last = await s.meta(MetaKey.lastSuccess);
      final now = DateTime.now().toUtc();
      final hour = p.getInt(PrefKey.aiSummaryHour) ?? -99;
      final valid =
          on &&
          p.getString(PrefKey.aiSummaryLast) == last &&
          p.getString(PrefKey.aiSummaryDay) == schoolDay(now) &&
          (p.getInt(PrefKey.aiSummaryExpires) ?? 0) > now.millisecondsSinceEpoch &&
          now.millisecondsSinceEpoch ~/ 3600000 - hour >= 0 &&
          now.millisecondsSinceEpoch ~/ 3600000 - hour <= 1;
      if (mounted) {
        setState(() {
          enabled = on;
          text = valid ? p.getString(PrefKey.aiSummaryText) : null;
        });
      }
    } catch (_) {
      if (mounted) setState(() => text = null);
    } finally {
      await s?.db.close();
    }
  }

  Future<void> generate() async {
    setState(() => busy = true);
    Store? s;
    try {
      s = await Store.open();
      await s.setMeta(MetaKey.aiSummaryFailHash, '');
      await prepareAiSummary(s);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('요약을 준비하지 못했어요. 잠시 후 다시 확인해 주세요.')),
        );
      }
    } finally {
      await s?.db.close();
      if (mounted) setState(() => busy = false);
    }
    await load();
  }

  @override
  Widget build(BuildContext context) => !enabled
      // Without AI, a single line is enough; no empty expandable card.
      ? Card(
          child: ListTile(
            leading: const Icon(Icons.auto_awesome),
            title: const Text('AI 요약'),
            subtitle: const Text('켜면 오늘 먼저 할 일을 정리해 줘요'),
            trailing: TextButton(
              onPressed: () => navigateTo(context, AiSettingsDestination()),
              child: const Text('AI 설정'),
            ),
          ),
        )
      : Card(
          child: ExpansionTile(
            key: const PageStorageKey<String>('ai-daily-summary-expansion'),
            // The card already has an outline; ExpansionTile's own top/bottom
            // borders drew doubled lines.
            shape: const Border(),
            collapsedShape: const Border(),
            leading: const Icon(Icons.auto_awesome),
            title: const Text('AI 요약'),
            subtitle: Text(
              text == null ? '아직 만든 요약이 없어요' : '수집된 목록에서 우선 확인할 일',
            ),
            childrenPadding: const EdgeInsets.all(16),
            expandedCrossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (text != null) SelectionArea(child: Text(text!)),
              if (enabled)
                TextButton(
                  onPressed: busy ? null : generate,
                  child: Text(busy ? '준비 중…' : '지금 요약 준비'),
                ),
              TextButton(
                onPressed: () => navigateTo(context, AiSettingsDestination()),
                child: const Text('AI 설정'),
              ),
            ],
          ),
        );
}

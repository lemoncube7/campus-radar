import 'package:campus_radar/core/demo_state.dart';
import 'package:campus_radar/core/developer_mode.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/campus/collection_control.dart';
import 'package:campus_radar/platform/drive_viewer.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';
import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/notification_gateway.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/school_time.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:crypto/crypto.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:tray_manager/tray_manager.dart';
import 'package:window_manager/window_manager.dart';
import 'package:launch_at_startup/launch_at_startup.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:campus_radar/campus/services.dart';
import 'package:campus_radar/updates/updates.dart';
import 'package:campus_radar/platform/desktop_web.dart';
import 'package:campus_radar/platform/desktop_update.dart';
export 'package:campus_radar/platform/desktop_update.dart';

final desktopRuntime = DesktopRuntime();
final desktopChanged = ValueNotifier<int>(0);

Future<void> initializeDesktop(List<String> args) async {
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  final support = await getApplicationSupportDirectory();
  await databaseFactory.setDatabasesPath(path.join(support.path, 'database'));
  desktopMethodHandler = desktopMethod;
  await windowManager.ensureInitialized();
  await windowManager.setPreventClose(true);
  await windowManager.setMinimumSize(const Size(740, 620));
  await windowManager.setTitle('캠퍼스레이더');
  launchAtStartup.setup(
    appName: 'CampusRadar',
    appPath: '"${Platform.resolvedExecutable}"',
    args: ['--tray'],
  );
  await desktopRuntime.initialize();
  await windowManager.waitUntilReadyToShow(
    const WindowOptions(size: Size(1180, 820), center: true),
    () async {
      if (args.contains('--tray')) {
        await windowManager.hide();
      } else {
        await windowManager.show();
        await windowManager.focus();
      }
    },
  );
}

class DesktopRuntime with WindowListener, TrayListener {
  Timer? timer;
  bool running = false, quitting = false;
  Future<void> initialize() async {
    windowManager.addListener(this);
    trayManager.addListener(this);
    await trayManager.setIcon(
      path.join(
        path.dirname(Platform.resolvedExecutable),
        'data',
        'flutter_assets',
        'assets',
        'radar.ico',
      ),
    );
    await trayManager.setToolTip('캠퍼스레이더 · 독립 실행');
    await menu();
    timer = Timer.periodic(const Duration(minutes: 1), (_) => tick());
  }

  Future<void> menu() async {
    await trayManager.setContextMenu(
      Menu(
        items: [
          MenuItem(key: 'open', label: '캠퍼스레이더 열기'),
          MenuItem(key: 'sync', label: '지금 수집'),
          if (isDeveloperMode) MenuItem(key: 'test', label: '알림 표시 테스트'),
          MenuItem.separator(),
          MenuItem(key: 'quit', label: '종료'),
        ],
      ),
    );
  }

  Future<void> show() async {
    await windowManager.show();
    await windowManager.restore();
    await windowManager.focus();
  }

  @override
  void onWindowClose() async {
    if (!quitting) await windowManager.hide();
  }

  @override
  void onTrayIconMouseDown() => show();
  @override
  void onTrayIconRightMouseDown() => trayManager.popUpContextMenu();
  @override
  void onTrayMenuItemClick(MenuItem menuItem) {
    switch (menuItem.key) {
      case 'open':
        show();
        break;
      case 'sync':
        tick(force: true);
        break;
      case 'test':
        desktopTestNotification();
        break;
      case 'quit':
        quit();
        break;
    }
  }

  Future<void> quit() async {
    quitting = true;
    timer?.cancel();
    await trayManager.destroy();
    await windowManager.setPreventClose(false);
    await windowManager.destroy();
  }

  Future<void> tick({bool force = false}) async {
    if (running || isDemoActive) return;
    running = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.reload();
      final viewer = await driveViewerConnected();
      if (!viewer && await credentials.read(key: 'id') == null) return;
      final s = await Store.open();
      DateTime? last;
      try {
        last = DateTime.tryParse(
          await s.meta(viewer ? driveViewerCheckedKey : MetaKey.lastSuccess) ??
              '',
        );
        await s.setMeta(
          MetaKey.desktopHeartbeat,
          DateTime.now().toUtc().toIso8601String(),
        );
        await reconcile(s);
        await desktopNoticeAlerts(s);
        await desktopDaily(s);
        await desktopTimetableAlerts(s, prefs);
      } finally {
        await s.db.close();
      }
      if (viewer) {
        // Drive reads are cheap and never touch the school: every 15 minutes.
        if (force ||
            last == null ||
            DateTime.now().toUtc().difference(last) >=
                const Duration(minutes: 15)) {
          try {
            await pullDriveSnapshot();
          } on DriveViewerException {
            // Saved for the status line.
          }
          await checkDesktopUpdate(silent: true);
        }
        desktopChanged.value++;
        return;
      }
      final minutes = prefs.getInt(PrefKey.desktopInterval) ?? 60;
      if (force ||
          ((prefs.getBool(PrefKey.desktopAuto) ?? true) &&
              await automaticSchoolConnectionEnabled() &&
              (last == null ||
                  DateTime.now().toUtc().difference(last) >=
                      Duration(minutes: minutes)))) {
        await synchronize(source: force ? 'PC 트레이 수동' : 'PC 트레이 자동');
        await checkDesktopUpdate(silent: true);
      }
      desktopChanged.value++;
    } catch (e) {
      await systemLog('PC 자동 확인 실패', diagnosticFailure(e));
    } finally {
      running = false;
    }
  }
}

Future<void> desktopTimetableAlerts(
  Store store,
  SharedPreferences prefs, {
  DateTime? clock,
}) async {
  if (!(prefs.getBool(PrefKey.desktopNotifications) ?? true)) return;
  final now = (clock ?? DateTime.now()).toUtc().add(const Duration(hours: 9));
  final day =
      '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
  final until = prefs.getString(PrefKey.desktopTimetableUntil);
  if (until != null && day.compareTo(until) > 0) return;
  final rows = decodeSlots(await store.meta(MetaKey.timetableEntries));
  // Skip classes with a saved cancellation (휴강) today, as mobile does.
  final cancelled = await readClassCancellations(store);
  final today =
      rows
          .where(
            (e) =>
                e.weekday == now.weekday &&
                !cancelled.any((c) => c.slotId == e.id && c.date == day),
          )
          .toList()
        ..sort((a, b) => a.start.compareTo(b.start));
  final minute = now.hour * 60 + now.minute;
  if (prefs.getBool(PrefKey.desktopTimetableEnabled) ?? false) {
    final lead = prefs.getInt(PrefKey.desktopTimetableLead) ?? 30;
    for (final row in today) {
      final key = 'desktopClassSent:$day:${row.id}';
      if (minute < row.start - lead ||
          minute >= row.start ||
          await store.meta(key) == 'yes') {
        continue;
      }
      await notifications.show(
        notificationId(key),
        '곧 수업이 시작돼요',
        '${courseLabel(row.course)} · ${slotTime(row.start)}${row.room.isEmpty ? '' : ' · ${row.room}'}',
        noticeStyle,
        payload: '_timetable',
      );
      await store.setMeta(key, 'yes');
      await store.log(
        'notification',
        'PC 수업 전 알림 요청',
        '${courseLabel(row.course)} · ${slotTime(row.start)}',
      );
    }
  }
  if ((prefs.getBool(PrefKey.desktopTimetableMidnight) ?? false) &&
      now.hour == 0 &&
      await store.meta(MetaKey.desktopTimetableMidnightSent) != day) {
    await notifications.show(
      notificationId('desktop-midnight'),
      '오늘 수업 ${today.length}개',
      today.isEmpty
          ? '저장한 시간표에 오늘 수업이 없어요.'
          : today
                .map((e) => '${slotTime(e.start)} ${courseLabel(e.course)}')
                .join(' · '),
      noticeStyle,
      payload: '_timetable',
    );
    await store.setMeta(MetaKey.desktopTimetableMidnightSent, day);
  }
}

Future<void> desktopNoticeAlerts(Store store) async {
  final notices = await store.notices();
  final previous = await store.meta(MetaKey.desktopNoticeIds);
  final old = previous == null
      ? null
      : (jsonDecode(previous) as List).cast<String>().toSet();
  final prefs = await SharedPreferences.getInstance();
  if (old != null && (prefs.getBool(PrefKey.desktopNotifications) ?? true)) {
    for (final notice in notices.where((n) => !old.contains(n.id))) {
      await notifications.show(
        notificationId('desktop-notice:${notice.id}'),
        '새 공지가 등록됐어요',
        '${courseLabel(notice.course)} · ${notice.title}',
        noticeStyle,
        payload: 'NOTICE:${notice.id}',
      );
      await store.log(
        'notification',
        '새 공지 알림 요청',
        '${courseLabel(notice.course)} · ${notice.title}',
      );
    }
  }
  await store.setMeta(
    MetaKey.desktopNoticeIds,
    jsonEncode(notices.map((n) => n.id).toList()),
  );
}

Future<void> desktopTestNotification() async {
  await notifications.show(
    notificationId('desktop-test'),
    '캠퍼스레이더 알림 테스트',
    'PC 알림이 표시돼요. 누르면 캠퍼스레이더를 열어요.',
    noticeStyle,
    payload: '_desktop',
  );
  await logNotification('PC 테스트 알림 발송 요청', 'Windows 알림에 표시를 요청했어요.');
}

Future<void> desktopDaily(Store s, {bool force = false}) async {
  final p = await SharedPreferences.getInstance();
  final now = DateTime.now();
  if (!force &&
      (!(p.getBool(PrefKey.desktopNotifications) ?? true) ||
          !(p.getBool(PrefKey.desktopDaily) ?? false))) {
    return;
  }
  final h = p.getInt(PrefKey.desktopDailyHour) ?? 18,
      m = p.getInt(PrefKey.desktopDailyMinute) ?? 0;
  final day = '${now.year}-${now.month}-${now.day}';
  if (!force &&
      (now.isBefore(DateTime(now.year, now.month, now.day, h, m)) ||
          await s.meta(MetaKey.desktopDailySent) == day)) {
    return;
  }
  final excluded = await s.excluded();
  final pending = (await s.items())
      .where(
        (i) => i.availableAt(now) && i.openTask && !excluded.contains(i.key),
      )
      .toList();
  final urgent = pending
      .where((i) => deadlineState(i.due) == DeadlineState.withinDay)
      .length;
  var body = '24시간 이내 $urgent개 · 미완료 ${pending.length}개\n마지막 수집 기준이에요.';
  final last = await s.meta(MetaKey.lastSuccess);
  if (p.getBool(PrefKey.aiSummaryEnabled) == true &&
      p.getString(PrefKey.aiSummaryLast) == last &&
      p.getString(PrefKey.aiSummaryDay) == schoolDay(now) &&
      (p.getInt(PrefKey.aiSummaryExpires) ?? 0) > now.millisecondsSinceEpoch) {
    final text = p.getString(PrefKey.aiSummaryText);
    if (text?.isNotEmpty == true) body += '\nAI 우선 확인\n$text';
  }
  await notifications.show(
    notificationId('desktop-daily'),
    '하루 요약',
    body,
    noticeStyle,
    payload: '_summary',
  );
  if (!force) await s.setMeta(MetaKey.desktopDailySent, day);
  await s.log(
    'notification',
    'PC 하루 요약 요청',
    '24시간 이내 $urgent개 · 미완료 ${pending.length}개',
  );
}

Future<dynamic> desktopMethod(String method, dynamic raw) async {
  final a = raw is Map ? Map<String, dynamic>.from(raw) : <String, dynamic>{};
  final p = await SharedPreferences.getInstance();
  switch (method) {
    case 'desktopQuit':
      await desktopRuntime.quit();
      return null;
    case 'versionInfo':
      return {'name': appVersion, 'code': appBuild};
    case 'versionCode':
      return appBuild;
    case 'timetableSettings':
      return {
        'enabled': p.getBool(PrefKey.desktopTimetableEnabled) ?? false,
        'midnight': p.getBool(PrefKey.desktopTimetableMidnight) ?? false,
        'lead': p.getInt(PrefKey.desktopTimetableLead) ?? 30,
        'until': p.getString(PrefKey.desktopTimetableUntil) ?? '',
        'exactAllowed': true,
      };
    case 'setTimetableSettings':
      final lead = a['lead'];
      final until = a['until'];
      if (![15, 30, 60].contains(lead) ||
          until is! String ||
          DateTime.tryParse(until) == null) {
        throw const FormatException('시간표 알림 설정을 확인해 주세요.');
      }
      await p.setBool(PrefKey.desktopTimetableEnabled, a['enabled'] == true);
      await p.setBool(PrefKey.desktopTimetableMidnight, a['midnight'] == true);
      await p.setInt(PrefKey.desktopTimetableLead, lead as int);
      await p.setString(PrefKey.desktopTimetableUntil, until);
      desktopChanged.value++;
      return null;
    case 'refreshWidget':
      desktopChanged.value++;
      return null;
    case 'dailySettings':
      return {
        'enabled': p.getBool(PrefKey.desktopDaily) ?? false,
        'hour': p.getInt(PrefKey.desktopDailyHour) ?? 18,
        'minute': p.getInt(PrefKey.desktopDailyMinute) ?? 0,
      };
    case 'setDailySettings':
      await p.setBool(PrefKey.desktopDaily, a['enabled'] == true);
      await p.setInt(PrefKey.desktopDailyHour, a['hour'] as int);
      await p.setInt(PrefKey.desktopDailyMinute, a['minute'] as int);
      return null;
    case 'testDailySummary':
      final s = await Store.open();
      try {
        await desktopDaily(s, force: true);
      } finally {
        await s.db.close();
      }
      return null;
    case 'openCampus':
      await openDesktopCampus(a);
      return null;
    case 'openCampusFile':
      final filePath = a['path'] as String?;
      if (filePath == null || filePath.isEmpty) {
        throw const FormatException('파일 경로를 확인해 주세요.');
      }
      final file = File(filePath);
      if (!await file.exists()) {
        throw const FormatException('파일을 찾지 못했어요.');
      }
      final uri = Uri.file(filePath);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri);
      } else {
        await Process.run('cmd', ['/c', 'start', '""', filePath], runInShell: true);
      }
      return null;
    case 'fetchLinkedPlan':
      return openDesktopPlan(a, capture: true);
    case 'openLinkedPlan':
      await openDesktopPlan(a, capture: false);
      return null;
    case 'openChatLink':
    case 'openExternalUrl':
    case 'openReleasePage':
      final uri = Uri.tryParse(
        a['url'] as String? ??
            'https://github.com/lemoncube7/campus-radar/releases',
      );
      if (uri == null ||
          uri.scheme != 'https' ||
          uri.host.isEmpty ||
          uri.userInfo.isNotEmpty) {
        throw const FormatException('HTTPS 주소를 확인해 주세요.');
      }
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        throw const FormatException('브라우저를 열지 못했어요.');
      }
      return null;
    case 'clearWebSession':
      await clearDesktopWeb();
      return null;
    case 'calendarPermission':
      return true;
    case 'calendarSettings':
      return {'allowed': true, 'calendarId': 'ics', 'auto': false};
    case 'calendarList':
      return [
        {'id': 'ics', 'name': '일정 파일 (.ics)', 'account': '이 PC에 저장'},
      ];
    case 'calendarConfigure':
    case 'calendarUnlink':
    case 'calendarSync':
      return null;
    case 'calendarWrite':
      return exportDesktopCalendar(a);
    case 'backgroundStatus':
      return {'backgroundRefresh': true, 'jobs': [], 'events': []};
  }
  throw PlatformException(
    code: 'windows_unsupported',
    message: '이 기능은 Windows에서 제공하지 않아요.',
  );
}

String icsEscape(String text) => text
    .replaceAll('\\', '\\\\')
    .replaceAll('\r', '')
    .replaceAll('\n', r'\n')
    .replaceAll(',', r'\,')
    .replaceAll(';', r'\;');
String foldDesktopCalendarLine(String line) {
  final result = StringBuffer();
  var length = 0;
  for (final rune in line.runes) {
    final char = String.fromCharCode(rune),
        size = utf8.encode(String.fromCharCode(rune)).length;
    if (length + size > 75) {
      result.write('\r\n ');
      length = 1;
    }
    result.write(char);
    length += size;
  }
  return result.toString();
}

String desktopCalendarText(Map<String, dynamic> a) {
  final start = a['start'] as int, end = a['end'] as int;
  if (end <= start || (a['title'] as String).trim().isEmpty) {
    throw const FormatException('일정 제목과 시간을 확인해 주세요.');
  }
  String stamp(int ms) =>
      '${DateTime.fromMillisecondsSinceEpoch(ms, isUtc: true).toIso8601String().replaceAll(RegExp(r'[-:]'), '').split('.').first}Z';
  String day(int ms) => stamp(ms).substring(0, 8);
  final allDay = a['allDay'] == true;
  final uid = sha256.convert(utf8.encode(a['key'] as String)).toString();
  return [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Campus Radar//Desktop//KO',
    'BEGIN:VEVENT',
    'UID:$uid@campusradar.local',
    'DTSTAMP:${stamp(DateTime.now().millisecondsSinceEpoch)}',
    'DTSTART${allDay ? ';VALUE=DATE' : ''}:${allDay ? day(start) : stamp(start)}',
    'DTEND${allDay ? ';VALUE=DATE' : ''}:${allDay ? day(end) : stamp(end)}',
    'SUMMARY:${icsEscape(a['title'] as String)}',
    'DESCRIPTION:${icsEscape(a['description'] as String? ?? '')}',
    'END:VEVENT',
    'END:VCALENDAR',
    '',
  ].map(foldDesktopCalendarLine).join('\r\n');
}

Future<Directory> desktopCalendarFolder() async {
  final d = Directory(
    path.join(
      (await getApplicationDocumentsDirectory()).path,
      'CampusRadar',
      '일정',
    ),
  );
  await d.create(recursive: true);
  return d;
}

Future<int> exportDesktopCalendar(Map<String, dynamic> a) async {
  final d = await desktopCalendarFolder();
  final key = sha256.convert(utf8.encode(a['key'] as String)).toString();
  await File(
    path.join(d.path, '$key.ics'),
  ).writeAsString(desktopCalendarText(a), flush: true);
  await systemLog('일정 파일 저장', a['title'] as String);
  return 1;
}

class DesktopCalendarPage extends StatelessWidget {
  const DesktopCalendarPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('일정 파일 내보내기')),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        const Text(
          'Windows에서는 확인한 AI 일정을 .ics 파일로 저장해요. 파일을 열어 사용 중인 캘린더에 추가할 수 있어요. 이미 가져온 외부 캘린더 일정은 자동으로 갱신되지 않아요.',
        ),
        const SizedBox(height: 20),
        FilledButton.icon(
          onPressed: () async {
            final d = await desktopCalendarFolder();
            await Process.start('explorer.exe', [d.path]);
          },
          icon: const Icon(Icons.folder_open),
          label: const Text('저장한 일정 폴더 열기'),
        ),
      ],
    ),
  );
}

class DesktopSettingsPage extends StatefulWidget {
  const DesktopSettingsPage({super.key});
  @override
  State<DesktopSettingsPage> createState() => _DesktopSettingsState();
}

class _DesktopSettingsState extends State<DesktopSettingsPage> {
  bool busy = true, auto = true, startup = false, alerts = true;
  int interval = 60;
  String? last, error;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      final start = await launchAtStartup.isEnabled();
      final s = await Store.open();
      String? stamp;
      try {
        stamp = await s.meta(MetaKey.desktopHeartbeat);
      } finally {
        await s.db.close();
      }
      if (mounted) {
        setState(() {
          auto = p.getBool(PrefKey.desktopAuto) ?? true;
          alerts = p.getBool(PrefKey.desktopNotifications) ?? true;
          interval = p.getInt(PrefKey.desktopInterval) ?? 60;
          startup = start;
          last = stamp;
          busy = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          busy = false;
          error = 'PC 실행 설정을 불러오지 못했어요.';
        });
      }
    }
  }

  Future<void> change(String key, dynamic value) async {
    final p = await SharedPreferences.getInstance();
    if (value is bool) await p.setBool(key, value);
    if (value is int) await p.setInt(key, value);
    await load();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('PC 실행 설정')),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        const Text(
          '이 PC에서 독립 실행',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        const Text(
          '창을 닫아도 트레이에서 계속 실행돼요. PC가 꺼지거나 절전 중이면 수집과 알림이 멈춰요. 휴대전화 앱과 계정·설정을 공유하지 않아요.',
        ),
        SwitchListTile(
          title: const Text('자동 수집'),
          value: auto,
          onChanged: busy ? null : (v) => change('desktopAuto', v),
        ),
        DropdownButtonFormField<int>(
          initialValue: interval,
          decoration: const InputDecoration(labelText: '수집 간격'),
          items: [
            15,
            30,
            60,
            120,
          ].map((v) => DropdownMenuItem(value: v, child: Text('$v분'))).toList(),
          onChanged: busy ? null : (v) => change('desktopInterval', v),
        ),
        SwitchListTile(
          title: const Text('Windows 로그인 시 자동 실행'),
          subtitle: const Text('트레이로 시작해요.'),
          value: startup,
          onChanged: busy
              ? null
              : (v) async {
                  try {
                    if (v) {
                      if (!await launchAtStartup.enable()) {
                        throw StateError('startup enable failed');
                      }
                    } else {
                      if (!await launchAtStartup.disable()) {
                        throw StateError('startup disable failed');
                      }
                    }
                    if (await launchAtStartup.isEnabled() != v) {
                      throw StateError('startup verification failed');
                    }
                    if (mounted) setState(() => error = null);
                    await load();
                  } catch (_) {
                    if (mounted) {
                      setState(() => error = '시작 프로그램 설정을 바꾸지 못했어요.');
                    }
                  }
                },
        ),
        SwitchListTile(
          title: const Text('PC 알림'),
          subtitle: const Text('휴대전화에서도 알림을 받는다면 필요에 따라 끌 수 있어요.'),
          value: alerts,
          onChanged: busy ? null : (v) => change('desktopNotifications', v),
        ),
        Text(
          last == null
              ? '아직 자동 확인 기록이 없어요.'
              : '마지막 자동 확인 ${koreanTime(DateTime.parse(last!))}',
        ),
        if (error != null) Text(error!),
        const SizedBox(height: 16),
        FilledButton(
          onPressed: busy
              ? null
              : () async {
                  await desktopRuntime.tick(force: true);
                  await load();
                },
          child: const Text('지금 수집'),
        ),
        if (isDeveloperMode)
          TextButton(
            onPressed: desktopTestNotification,
            child: const Text('Windows 알림 테스트'),
          ),
      ],
    ),
  );
}

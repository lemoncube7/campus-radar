import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/export/app_snapshot.dart';

/// Windows read-only mode: instead of logging into the school, the PC reads
/// the snapshot the phone uploads to the user's Google Drive.
///
/// Google "Desktop app" OAuth (system browser + PKCE + loopback redirect), the
/// same Cloud project as the phone, scope drive.file only. Files the phone
/// created are visible to this client (verified 2026-11-05).
const _clientId = String.fromEnvironment('GOOGLE_DESKTOP_CLIENT_ID');
// Installed-app secret: Google documents it as not confidential. Supplied at
// build time so it is not committed to the public repository.
const _clientSecret = String.fromEnvironment('GOOGLE_DESKTOP_CLIENT_SECRET');
const _scope = 'https://www.googleapis.com/auth/drive.file';
const _refreshKey = 'driveViewerRefresh';
const _startName = '캠퍼스레이더 시작.txt';
const driveViewerCheckedKey = 'driveViewerCheckedAt';
const driveViewerErrorKey = 'driveViewerError';
const driveViewerProfileKey = 'driveViewerProfile';

bool get driveViewerAvailable =>
    Platform.isWindows && _clientId.isNotEmpty && _clientSecret.isNotEmpty;

Future<bool> driveViewerConnected() async =>
    driveViewerAvailable && await credentials.read(key: _refreshKey) != null;

class DriveViewerException implements Exception {
  final String message;
  const DriveViewerException(this.message);
  @override
  String toString() => message;
}

/// Opens the browser for Google sign-in and stores the refresh token in the
/// Windows credential store. Returns after the first snapshot is applied.
Future<AppSnapshotInfo> connectDriveViewer() async {
  if (!driveViewerAvailable) {
    throw const DriveViewerException('이 빌드에는 Google 연결 정보가 없어요.');
  }
  final rnd = Random.secure();
  String rand(int n) => base64Url
      .encode(List.generate(n, (_) => rnd.nextInt(256)))
      .replaceAll('=', '');
  final verifier = rand(48), state = rand(16);
  final challenge = base64Url
      .encode(sha256.convert(ascii.encode(verifier)).bytes)
      .replaceAll('=', '');
  final server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
  final redirect = 'http://127.0.0.1:${server.port}';
  try {
    final url = Uri.https('accounts.google.com', '/o/oauth2/v2/auth', {
      'client_id': _clientId,
      'redirect_uri': redirect,
      'response_type': 'code',
      'scope': _scope,
      'code_challenge': challenge,
      'code_challenge_method': 'S256',
      'state': state,
      'access_type': 'offline',
      'prompt': 'consent select_account',
    });
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      throw const DriveViewerException('브라우저를 열지 못했어요.');
    }
    final req = await server.first.timeout(
      const Duration(minutes: 5),
      onTimeout: () =>
          throw const DriveViewerException('5분 안에 로그인이 끝나지 않았어요. 다시 시도해 주세요.'),
    );
    final q = req.uri.queryParameters;
    final ok = q['state'] == state && q['code'] != null;
    req.response
      ..headers.contentType = ContentType.html
      ..write(
        '<meta charset="utf-8"><title>캠퍼스레이더</title>'
        '<p style="font:16px sans-serif;margin:40px">'
        '${ok ? 'Google 연결을 마쳤어요. 이 창을 닫고 캠퍼스레이더로 돌아가세요.' : 'Google 연결이 취소됐어요.'}</p>',
      );
    await req.response.close();
    if (q['state'] != state) {
      throw const DriveViewerException('로그인 응답을 확인하지 못했어요. 다시 시도해 주세요.');
    }
    if (q['code'] == null) {
      throw const DriveViewerException('Google 연결이 취소됐어요.');
    }
    final token = await _token({
      'code': q['code']!,
      'code_verifier': verifier,
      'grant_type': 'authorization_code',
      'redirect_uri': redirect,
    });
    final refresh = token['refresh_token'];
    if (refresh is! String) {
      throw const DriveViewerException(
        'Google이 연결 유지 정보를 주지 않았어요. 다시 시도해 주세요.',
      );
    }
    await credentials.write(key: _refreshKey, value: refresh);
  } finally {
    await server.close(force: true);
  }
  final store = await Store.open();
  try {
    await store.setMeta(driveViewerProfileKey, '');
  } finally {
    await store.db.close();
  }
  return pullDriveSnapshot();
}

/// Forgets the Google connection and the mirrored school data on this PC.
Future<void> disconnectDriveViewer() async {
  final refresh = await credentials.read(key: _refreshKey);
  await credentials.delete(key: _refreshKey);
  if (refresh != null) {
    try {
      final http = HttpClient();
      final req = await http.postUrl(
        Uri.https('oauth2.googleapis.com', '/revoke', {'token': refresh}),
      );
      await (await req.close()).drain<void>();
      http.close();
    } catch (_) {
      // Revocation is best effort; the local token is already gone.
    }
  }
  final store = await Store.open();
  try {
    await store.db.transaction((txn) async {
      await txn.delete('items');
      await txn.delete('notices');
      await txn.delete(
        'meta',
        where: 'id IN (?,?,?,?)',
        whereArgs: [
          'lastSuccess',
          driveViewerCheckedKey,
          driveViewerErrorKey,
          driveViewerProfileKey,
        ],
      );
    });
  } finally {
    await store.db.close();
  }
}

/// Reads the newest finished upload and mirrors it locally. On any failure the
/// last good data stays and the reason is saved for the status line.
Future<AppSnapshotInfo> pullDriveSnapshot() async {
  final store = await Store.open();
  try {
    try {
      final info = await _pull(store);
      await store.setMeta(
        driveViewerCheckedKey,
        DateTime.now().toUtc().toIso8601String(),
      );
      await store.setMeta(driveViewerErrorKey, '');
      return info;
    } catch (e) {
      final message = e is DriveViewerException
          ? e.message
          : e is SocketException || e is HttpException
          ? '인터넷 연결을 확인해 주세요.'
          : '폰 자료를 읽지 못했어요. ($e)';
      await store.setMeta(driveViewerErrorKey, message);
      await store.log('sync', 'Drive 자료 확인 실패', message);
      throw DriveViewerException(message);
    }
  } finally {
    await store.db.close();
  }
}

Future<AppSnapshotInfo> _pull(Store store) async {
  final refresh = await credentials.read(key: _refreshKey);
  if (refresh == null) {
    throw const DriveViewerException('Google 계정을 연결해 주세요.');
  }
  final Map token;
  try {
    token = await _token({
      'refresh_token': refresh,
      'grant_type': 'refresh_token',
    });
  } on _TokenFailure catch (e) {
    if (e.code == 'invalid_grant') {
      throw const DriveViewerException('Google 연결이 만료됐어요. 다시 연결해 주세요.');
    }
    rethrow;
  }
  final api = _Drive('${token['access_token']}');
  try {
    final starts = await api.list("name = '$_startName' and trashed = false");
    if (starts.isEmpty) {
      throw const DriveViewerException(
        '폰이 올린 자료가 없어요. 폰에서 같은 Google 계정으로 Drive 자동 내보내기를 켜 주세요.',
      );
    }
    final wanted = await store.meta(driveViewerProfileKey) ?? '';
    final candidates = <({Map file, Map index})>[];
    for (final f in starts) {
      final text = await api.text('${f['id']}');
      if (!text.startsWith('CAMPUS_RADAR_START_V1\n')) continue;
      try {
        final index = jsonDecode(text.substring(text.indexOf('\n') + 1));
        if (index is Map) candidates.add((file: f, index: index));
      } on FormatException {
        continue;
      }
    }
    candidates.sort(
      (a, b) =>
          '${b.file['modifiedTime']}'.compareTo('${a.file['modifiedTime']}'),
    );
    final chosen =
        candidates.where((c) => c.index['profileId'] == wanted).firstOrNull ??
        candidates.firstOrNull;
    if (chosen == null) {
      throw const DriveViewerException('폰 자료의 시작 파일을 읽지 못했어요.');
    }
    final ref = chosen.index['appSnapshot'];
    if (ref is! Map || ref['sha256'] is! String) {
      throw const DriveViewerException(
        '폰 앱을 최신 버전으로 업데이트한 뒤 한 번 수집해 주세요. (PC용 자료 없음)',
      );
    }
    final parent = (chosen.file['parents'] as List?)?.firstOrNull;
    final name = '${ref['path'] ?? appSnapshotPath}'.replaceAll("'", r"\'");
    final files = await api.list(
      "name = '$name' and trashed = false${parent == null ? '' : " and '$parent' in parents"}",
    );
    if (files.isEmpty) {
      throw const DriveViewerException('PC용 자료 파일이 아직 없어요. 폰에서 다시 수집해 주세요.');
    }
    final text = await api.text('${files.first['id']}');
    if (appSnapshotDigest(text) != ref['sha256']) {
      // The phone is mid-upload: data and start file are from different runs.
      throw const DriveViewerException('폰이 자료를 올리는 중이에요. 잠시 후 다시 확인해요.');
    }
    final info = await applyAppSnapshot(store, text);
    await store.setMeta(driveViewerProfileKey, info.profileId);
    return info;
  } finally {
    api.close();
  }
}

class _Drive {
  final String token;
  final _http = HttpClient()..connectionTimeout = const Duration(seconds: 15);
  _Drive(this.token);
  void close() => _http.close(force: true);

  Future<String> text(String id) => _get(
    Uri.https('www.googleapis.com', '/drive/v3/files/$id', {'alt': 'media'}),
  );

  Future<List<Map>> list(String q) async {
    final out = <Map>[];
    String? page;
    do {
      final j =
          jsonDecode(
                await _get(
                  Uri.https('www.googleapis.com', '/drive/v3/files', {
                    'q': q,
                    'pageSize': '100',
                    'fields':
                        'nextPageToken,files(id,name,parents,modifiedTime)',
                    'pageToken': ?page,
                  }),
                ),
              )
              as Map;
      out.addAll((j['files'] as List).cast<Map>());
      page = j['nextPageToken'] as String?;
    } while (page != null && out.length < 500);
    return out;
  }

  Future<String> _get(Uri uri) async {
    final req = await _http.getUrl(uri).timeout(const Duration(seconds: 20));
    req.headers.set('Authorization', 'Bearer $token');
    final res = await req.close().timeout(const Duration(seconds: 30));
    final body = await utf8.decodeStream(res);
    if (res.statusCode == 200) return body;
    throw DriveViewerException(switch (res.statusCode) {
      401 => 'Google 연결을 다시 확인해 주세요.',
      403 => 'Drive 사용 권한이나 사용량 제한을 확인해 주세요.',
      404 => '폰 자료가 이동되거나 삭제됐어요.',
      429 || >= 500 => 'Drive가 잠시 응답하지 않아요. 잠시 후 다시 확인해요.',
      _ => 'Drive 응답 오류 (${res.statusCode})',
    });
  }
}

class _TokenFailure implements Exception {
  final String code;
  const _TokenFailure(this.code);
  @override
  String toString() => 'Google 인증 오류 ($code)';
}

Future<Map> _token(Map<String, String> form) async {
  final http = HttpClient()..connectionTimeout = const Duration(seconds: 15);
  try {
    final req = await http.postUrl(
      Uri.https('oauth2.googleapis.com', '/token'),
    );
    req.headers.contentType = ContentType(
      'application',
      'x-www-form-urlencoded',
    );
    req.write(
      Uri(
        queryParameters: {
          ...form,
          'client_id': _clientId,
          'client_secret': _clientSecret,
        },
      ).query,
    );
    final res = await req.close().timeout(const Duration(seconds: 30));
    final body = jsonDecode(await utf8.decodeStream(res)) as Map;
    if (res.statusCode != 200) throw _TokenFailure('${body['error']}');
    return body;
  } finally {
    http.close(force: true);
  }
}

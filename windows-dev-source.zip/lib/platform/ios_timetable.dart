import 'package:campus_radar/core/storage_keys.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/core/notification_gateway.dart';

class IosClassAlert {
  final String id, title, body, payload;
  final DateTime at;
  const IosClassAlert(this.id, this.title, this.body, this.at, this.payload);
}

/// Use dated occurrences, never recurring triggers: cancellations stay effective.
List<IosClassAlert> iosClassAlerts(
  List<ClassSlot> slots,
  List<ClassCancellation> cancelled,
  Map<String, dynamic> settings,
  List<CampusItem> items,
  Set<String> excluded,
  DateTime now,
) {
  final schoolNow = now.toUtc().add(const Duration(hours: 9));
  final until = DateTime.tryParse(settings['until'] as String? ?? '');
  final lead = (settings['lead'] as num? ?? 30).toInt().clamp(1, 120);
  final result = <IosClassAlert>[];
  for (var offset = 0; offset < 14; offset++) {
    final date = DateTime.utc(
      schoolNow.year,
      schoolNow.month,
      schoolNow.day + offset,
    );
    if (until != null &&
        date.isAfter(DateTime.utc(until.year, until.month, until.day))) {
      continue;
    }
    final today = classesOnDate(slots, cancelled, date)
      ..sort((a, b) => a.start.compareTo(b.start));
    if (settings['enabled'] == true) {
      for (final slot in today) {
        final at = date
            .add(Duration(minutes: slot.start - lead))
            .subtract(const Duration(hours: 9));
        if (!at.isAfter(now)) continue;
        result.add(
          IosClassAlert(
            '${date.toIso8601String()}:${slot.id}',
            '${courseLabel(slot.course)} 수업 $lead분 전',
            '${slotTime(slot.start)} 시작${slot.room.isEmpty ? '' : ' · ${slot.room}'}',
            at,
            '_timetable',
          ),
        );
      }
    }
    final midnight = date.subtract(const Duration(hours: 9));
    if (settings['midnight'] == true && midnight.isAfter(now)) {
      final tasks = items
          .where(
            (i) =>
                !i.done &&
                !excluded.contains(i.key) &&
                i.availableAt(midnight) &&
                i.due != null &&
                !i.due!.isBefore(midnight) &&
                i.due!.isBefore(midnight.add(const Duration(days: 1))),
          )
          .length;
      result.add(
        IosClassAlert(
          'midnight:${date.toIso8601String()}',
          '오늘의 수업·마감',
          '수업 ${today.length}개 · 오늘 마감 $tasks개\n마지막 수집·저장 시간표 기준이에요.',
          midnight,
          '_summary',
        ),
      );
    }
  }
  result.sort((a, b) => a.at.compareTo(b.at));
  return result.take(24).toList();
}

Future<void> refreshIosTimetable(
  List<ClassSlot> slots,
  List<ClassCancellation> cancelled,
  Map<String, dynamic> settings,
  List<CampusItem> items,
  Set<String> excluded,
  DateTime now,
) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  final old = prefs.getStringList(PrefKey.iosClassAlertIDs) ?? [];
  for (final id in old) {
    await notifications.cancel(int.parse(id));
  }
  final alerts = iosClassAlerts(
    slots,
    cancelled,
    settings,
    items,
    excluded,
    now,
  );
  final ids = <String>[];
  // Persist each intended ID before scheduling, so interrupted runs can clean up.
  for (final alert in alerts) {
    final id = notificationId('ios-class:${alert.id}');
    ids.add('$id');
    await prefs.setStringList(PrefKey.iosClassAlertIDs, ids);
    await notifications.zonedSchedule(
      id,
      alert.title,
      alert.body,
      tz.TZDateTime.from(alert.at, tz.local),
      noticeStyle,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      payload: alert.payload,
    );
  }
  await prefs.setStringList(PrefKey.iosClassAlertIDs, ids);
}

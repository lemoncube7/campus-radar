import 'package:campus_radar/core/storage_keys.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// A user-selected quiet window, evaluated in school (UTC+9) civil time.
class SessionProbePolicy {
  final bool enabled, scheduled;
  final List<int> days;
  final int startHour, endHour, initialMinutes;
  const SessionProbePolicy({
    this.enabled = false,
    this.scheduled = false,
    this.days = const [6, 7],
    this.startHour = 0,
    this.endHour = 24,
    this.initialMinutes = 60,
  });
  bool activeAt(DateTime utc) {
    if (!enabled) return false;
    if (!scheduled) return true;
    final now = utc.toUtc().add(const Duration(hours: 9));
    final minute = now.hour * 60 + now.minute;
    if (startHour < endHour) {
      return days.contains(now.weekday) &&
          minute >= startHour * 60 &&
          minute < endHour * 60;
    }
    // An overnight interval belongs to the weekday on which it starts.
    final previous = now.subtract(const Duration(days: 1)).weekday;
    return days.contains(now.weekday) && minute >= startHour * 60 ||
        days.contains(previous) && minute < endHour * 60;
  }

  factory SessionProbePolicy.fromPreferences(SharedPreferences p) {
    final days = (p.getStringList(PrefKey.sessionProbeDays) ?? ['6', '7'])
        .map(int.tryParse)
        .whereType<int>()
        .where((d) => d >= 1 && d <= 7)
        .toSet()
        .toList();
    final initial = p.getInt(PrefKey.sessionProbeInitialMinutes) ?? 60;
    return SessionProbePolicy(
      enabled: p.getBool(PrefKey.schoolLifetimeProbeEnabled) ?? false,
      scheduled: p.getString(PrefKey.sessionProbeMode) == 'scheduled',
      days: days.isEmpty ? [6, 7] : days,
      startHour: (p.getInt(PrefKey.sessionProbeStartHour) ?? 0).clamp(0, 23),
      endHour: (p.getInt(PrefKey.sessionProbeEndHour) ?? 24).clamp(1, 24),
      initialMinutes:
          const [15, 30, 60, 120, 240, 480, 720, 1440].contains(initial)
          ? initial
          : 60,
    );
  }
}

Future<SessionProbePolicy> readSessionProbePolicy() async {
  final p = await SharedPreferences.getInstance();
  await p.reload();
  return SessionProbePolicy.fromPreferences(p);
}

Future<bool> sessionProbeActive() async =>
    (await readSessionProbePolicy()).activeAt(DateTime.now());

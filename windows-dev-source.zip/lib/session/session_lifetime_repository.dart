import 'dart:convert';
import 'dart:async';
import 'package:sqflite/sqflite.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/session/session_lifetime.dart';
import 'package:campus_radar/core/session_scope.dart';

const sessionLifetimeKey = 'schoolSessionLifetime';

class SessionLifetimeRepository {
  final Store store;
  SessionLifetimeRepository(this.store);

  Future<SessionLifetime> read(String epoch) async {
    final raw = await store.meta(sessionLifetimeKey);
    if (raw == null) return SessionLifetime();
    final data = jsonDecode(raw) as Map<String, dynamic>;
    if (data['epoch'] != epoch) return SessionLifetime();
    return SessionLifetime.fromJson(
      Map<String, dynamic>.from(data['state'] as Map),
    );
  }

  /// Generation check and mutation are one SQLite transaction across isolates.
  Future<T> change<T>(String epoch, T Function(SessionLifetime) edit) async {
    for (var attempt = 0; ; attempt++) {
      try {
        return await _change(epoch, edit);
      } on DatabaseException catch (error) {
        final message = error.toString().toLowerCase();
        final code = (error.getResultCode() ?? 0) & 255;
        if (attempt >= 2 ||
            !(code == 5 ||
                code == 6 ||
                message.contains('database is locked') ||
                message.contains('sqlite_busy'))) {
          rethrow;
        }
        await Future<void>.delayed(Duration(milliseconds: 40 * (attempt + 1)));
      }
    }
  }

  Future<T> _change<T>(
    String epoch,
    T Function(SessionLifetime) edit,
  ) => store.db.transaction((txn) async {
    final generation = await txn.query(
      'meta',
      where: 'id=?',
      whereArgs: ['sessionEpoch'],
    );
    final blocked = await txn.query(
      'meta',
      where: 'id=?',
      whereArgs: ['sessionBlocked'],
    );
    if (generation.isEmpty ||
        generation.single['value'] != epoch ||
        blocked.isNotEmpty && blocked.single['value'] == 'yes') {
      throw SessionChanged();
    }
    final rows = await txn.query(
      'meta',
      where: 'id=?',
      whereArgs: [sessionLifetimeKey],
    );
    var state = SessionLifetime();
    if (rows.isNotEmpty) {
      final data =
          jsonDecode(rows.single['value'] as String) as Map<String, dynamic>;
      if (data['epoch'] == epoch) {
        state = SessionLifetime.fromJson(
          Map<String, dynamic>.from(data['state'] as Map),
        );
      }
    }
    final result = edit(state);
    await txn.rawInsert('INSERT OR REPLACE INTO meta(id,value) VALUES(?,?)', [
      sessionLifetimeKey,
      jsonEncode({'epoch': epoch, 'state': state.toJson()}),
    ]);
    return result;
  });
}

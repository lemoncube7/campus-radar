import 'dart:io';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/core/network_resilience.dart';
import 'package:campus_radar/core/operation_token.dart';
import 'package:campus_radar/session/session_lifetime.dart';
import 'package:campus_radar/session/session_lifetime_repository.dart';

class SchoolLifetimeObserver {
  final String epoch, session, group;
  final CampusClient client;
  SchoolLifetimeObserver._(this.client, this.epoch, this.session, this.group);

  Future<void> _edit(void Function(SessionLifetime) edit) async {
    Store? store;
    try {
      store = await Store.open();
      await SessionLifetimeRepository(store).change(epoch, (state) {
        if (state.session == session) edit(state);
      });
    } catch (_) {
      // Diagnostics cannot break collection or trigger a replacement login.
      client.diagnostic?.call('School lifetime observation unavailable');
    } finally {
      try {
        await store?.db.close();
      } catch (_) {
        /* Optional diagnostics. */
      }
    }
  }

  static Future<SchoolLifetimeObserver> attach(
    CampusClient client,
    String epoch,
    String session, {
    required bool fresh,
  }) async {
    final observer = SchoolLifetimeObserver._(
      client,
      epoch,
      session,
      freshToken(),
    );
    Store? store;
    try {
      store = await Store.open();
      await SessionLifetimeRepository(store).change(epoch, (state) {
        final now = DateTime.now().toUtc().millisecondsSinceEpoch;
        state.beginSession(session, now, freshlyLoggedIn: fresh);
        state.beginValidation(observer.group, now);
      });
    } catch (_) {
      client.diagnostic?.call('School lifetime observation unavailable');
    } finally {
      try {
        await store?.db.close();
      } catch (_) {
        /* Optional diagnostics. */
      }
    }
    client.trafficStarted = () async {
      final token = freshToken();
      await observer._edit(
        (state) => state.requestStarted(
          observer.group,
          token,
          DateTime.now().toUtc().millisecondsSinceEpoch,
        ),
      );
      return token;
    };
    client.trafficFinished = (token, failed) async {
      if (token == null) return;
      await observer._edit(
        (state) => state.requestFinished(
          observer.group,
          token,
          DateTime.now().toUtc().millisecondsSinceEpoch,
          failed: failed,
        ),
      );
    };
    return observer;
  }

  Future<void> validated() => _edit(
    (state) =>
        state.validated(group, DateTime.now().toUtc().millisecondsSinceEpoch),
  );

  Future<void> failed(Object error) => _edit(
    (state) => state.failedValidation(
      group,
      DateTime.now().toUtc().millisecondsSinceEpoch,
      authentication: error is CampusAuthenticationLost,
      network: isTransientNetworkFailure(error) || error is HandshakeException,
    ),
  );
}

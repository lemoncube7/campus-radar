import 'package:campus_radar/core/storage_keys.dart';
import 'dart:convert';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/courses/course_labels.dart';

String courseKey(Map<String, dynamic> course) =>
    '${course['course_id']}:${course['class_no']}';

/// A saved catalog, including an empty one, is authoritative. Item/notice
/// fallback is only for older installations that have never saved a catalog.
Future<List<Map<String, dynamic>>> readCourses(Store store) async {
  final courses = <String, Map<String, dynamic>>{};
  final raw = await store.meta(MetaKey.courses);
  if (raw != null) {
    for (final value in jsonDecode(raw) as List) {
      final row = Map<String, dynamic>.from(value);
      courses[courseKey(row)] = row;
    }
  } else {
    for (final item in await store.items()) {
      courses.putIfAbsent(
        courseKey(item.context),
        () => {...item.context, 'course_nm': item.course},
      );
    }
    for (final notice in await store.notices()) {
      courses.putIfAbsent(
        courseKey(notice.context),
        () => {...notice.context, 'course_nm': notice.course},
      );
    }
  }
  return courses.values.toList()..sort(
    (a, b) => courseLabel(
      '${a['course_nm']}',
    ).compareTo(courseLabel('${b['course_nm']}')),
  );
}

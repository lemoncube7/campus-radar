import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/campus/campus_rich_body.dart';
import 'package:campus_radar/campus/campus_session.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'dart:io';
import 'package:campus_radar/core/network_resilience.dart';
import 'package:flutter/material.dart';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/campus/campus_media.dart';
import 'package:campus_radar/campus/media_cache.dart';

class CampusBodyView extends StatefulWidget {
  final String body, bodyHtml;
  final List<CampusMedia> media;
  const CampusBodyView({
    super.key,
    required this.body,
    required this.bodyHtml,
    required this.media,
  });
  @override
  State<CampusBodyView> createState() => _CampusBodyViewState();
}

class _CampusBodyViewState extends State<CampusBodyView> {
  MediaCache? cache;
  final paths = <String, File>{}, statuses = <String, String>{};
  final busy = <String>{}, detectedImages = <String>{};
  String? account;
  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void didUpdateWidget(CampusBodyView old) {
    super.didUpdateWidget(old);
    if (old.bodyHtml != widget.bodyHtml || old.media != widget.media) load();
  }

  Future<void> load() async {
    if (widget.media.isEmpty) return;
    try {
      await loadMedia();
    } catch (_) {
      if (mounted) {
        setState(() {
          for (final m in widget.media) {
            statuses[m.identity] = '저장소를 열지 못했어요. 다시 시도해 주세요.';
          }
        });
      }
    }
  }

  Future<void> loadMedia() async {
    final id = await credentials.read(key: 'id');
    if (id == null) return;
    account = id;
    cache = await MediaCache.open(id);
    for (final m in widget.media) {
      final f = await cache!.local(m);
      if (f != null) {
        paths[m.identity] = f;
        statuses[m.identity] = '기기에 저장됨';
        if (mounted) setState(() {});
      } else {
        statuses[m.identity] = await cache!.status(m);
      }
      if (!m.image && (await cache!.mime(m)).startsWith('image/')) {
        detectedImages.add(m.identity);
      }
    }
    if (mounted) setState(() {});
    // Cache misses are fetched when this detail is opened, even between scheduled syncs.
    final pending = widget.media
        .where((m) => m.supported && !paths.containsKey(m.identity))
        .toList();
    if (pending.isEmpty) return;
    CampusClient? client;
    try {
      final pw = await credentials.read(key: 'pw');
      if (pw == null || !mounted) return;
      client = CampusClient();
      await client.connectSchool(id, pw);
      for (final m in pending) {
        if (!mounted || await credentials.read(key: 'id') != id) break;
        await fetch(m, client: client);
      }
    } catch (e) {
      await systemLog('첨부 자료 불러오기 실패', '자료 표시 또는 저장을 마치지 못했어요.', kind: 'app', error: e);
      if (mounted) {
        setState(() {
          for (final m in pending) {
            statuses[m.identity] =
                '${e is CampusException ? e.message : networkFailureMessage(e)} 눌러서 재시도';
          }
        });
      }
    } finally {
      client?.close();
    }
  }

  Future<File?> fetch(CampusMedia m, {CampusClient? client}) async {
    if (cache == null || busy.contains(m.identity)) return null;
    setState(() => busy.add(m.identity));
    CampusClient? owned;
    try {
      if (await credentials.read(key: 'id') != account) return null;
      if (client == null) {
        final pw = await credentials.read(key: 'pw');
        if (pw == null) throw CampusException('포털을 연결해 주세요.');
        owned = CampusClient();
        await owned.connectSchool(account!, pw);
        client = owned;
      }
      final f = await cache!.fetch(client, m);
      final imageMime = (await cache!.mime(m)).startsWith('image/');
      if (mounted) {
        setState(() {
          if (imageMime) detectedImages.add(m.identity);
          paths[m.identity] = f;
          statuses[m.identity] = '기기에 저장됨';
        });
      }
      return f;
    } catch (e) {
      await systemLog('첨부 자료 불러오기 실패', '자료 표시 또는 저장을 마치지 못했어요.', kind: 'app', error: e);
      if (mounted) {
        setState(
          () => statuses[m.identity] = e is CampusException
              ? e.message
              : '${networkFailureMessage(e)} 눌러서 재시도',
        );
      }
      return null;
    } finally {
      owned?.close();
      if (mounted) setState(() => busy.remove(m.identity));
    }
  }

  Future<void> open(CampusMedia m) async {
    var f = paths[m.identity];
    if (f != null && !await f.exists()) {
      paths.remove(m.identity);
      f = null;
    }
    f ??= await fetch(m);
    if (f == null || !mounted) return;
    if (m.image || detectedImages.contains(m.identity)) {
      final imageFile = f;
      await Navigator.push(
        context,
        MaterialPageRoute<void>(
          builder: (_) => Scaffold(
            appBar: AppBar(title: Text(m.name)),
            body: Center(
              child: InteractiveViewer(
                minScale: .5,
                maxScale: 6,
                child: Image.file(
                  imageFile,
                  errorBuilder: (_, e, st) => const Text('이미지를 표시하지 못했어요.'),
                ),
              ),
            ),
          ),
        ),
      );
    } else {
      try {
        // Cached files are named "<hash>-<name>"; hand viewer apps a copy
        // with the original name so they show the title, not a hash.
        var open = f;
        try {
          final dir = Directory('${cache!.root.parent.path}/open');
          if (await dir.exists()) await dir.delete(recursive: true);
          await dir.create(recursive: true);
          open = await f.copy('${dir.path}/${cache!.safeName(m.name)}');
        } catch (_) {
          open = f;
        }
        await bridge.invokeNative(NativeMethod.openCampusFile, {
          'path': open.path,
          'mime': await cache!.mime(m),
        });
      } catch (_) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('이 파일을 열 수 있는 앱이 없어요. PDF·한글·문서 뷰어를 확인해 주세요.'),
            ),
          );
        }
      }
    }
  }

  Widget image(CampusMedia m) {
    final file = paths[m.identity];
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (file != null)
            Semantics(
              label: m.name,
              button: true,
              child: InkWell(
                onTap: () => open(m),
                child: Image.file(
                  file,
                  cacheWidth: 1200,
                  errorBuilder: (_, e, st) => TextButton(
                    onPressed: () => open(m),
                    child: const Text('이미지 다시 열기'),
                  ),
                ),
              ),
            )
          else
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.image_outlined),
              title: Text(m.name),
              subtitle: Text(statuses[m.identity] ?? '불러오는 중'),
              trailing: busy.contains(m.identity)
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.refresh),
              onTap: () => open(m),
            ),
          if (file != null)
            const Text('눌러서 확대', style: TextStyle(fontSize: 12)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final images = widget.media
        .where((m) => m.image || detectedImages.contains(m.identity))
        .toList();
    final files = widget.media
        .where((m) => !m.image && !detectedImages.contains(m.identity))
        .toList();
    final pieces = widget.bodyHtml.isEmpty
        ? <BodyPiece>[]
        : campusBodyPieces(widget.bodyHtml);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (pieces.isEmpty)
          SelectableText(
            widget.body,
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(height: 1.7),
          ),
        if (pieces.isNotEmpty)
          CampusRichBody(
            source: widget.bodyHtml,
            imageAt: (index) => index < images.length
                ? image(images[index])
                : const Text('이미지는 원문에서 확인해 주세요.'),
          ),
        for (var index = 0; index < images.length; index++)
          if (!pieces.any((p) => p.imageIndex == index)) image(images[index]),
        if (files.isNotEmpty) ...[
          const SizedBox(height: 20),
          Text(
            '첨부파일 ${files.length}개',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          for (final m in files)
            Card(
              child: ListTile(
                leading: const Icon(Icons.attach_file),
                title: Text(m.name),
                subtitle: Text(
                  '${m.size == null ? '' : '${(m.size! / 1024 / 1024).toStringAsFixed(1)}MB · '}${statuses[m.identity] ?? '저장 대기'}',
                ),
                trailing: busy.contains(m.identity)
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.open_in_new),
                onTap: busy.contains(m.identity) ? null : () => open(m),
              ),
            ),
        ],
        if (widget.media.isNotEmpty)
          const Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text(
              '이미지·첨부는 기기에 임시 저장돼요. 파일당 50MB·캐시 300MB이며 오래된 파일은 다시 받아와요. 외부 서버 파일과 댓글은 원문에서 확인하세요. AI에는 이미지·파일을 전송하지 않아요.',
              style: TextStyle(fontSize: 12),
            ),
          ),
      ],
    );
  }
}

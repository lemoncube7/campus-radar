import 'package:flutter/material.dart';

import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/courses/course_catalog.dart';
import 'package:campus_radar/courses/course_colors.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/home/bouncy_tap.dart';
import 'package:campus_radar/schedule/timetable_model.dart';

/// Modern, visually rich card-based view for the 'Courses' (과목) tab.
/// Displays courses with distinctive palette accents, countdown badges for open tasks,
/// next scheduled classes, and tactile bouncy interactions.
class MobileCoursesView extends StatelessWidget {
  final List<Map<String, dynamic>> courses;
  final List<CampusItem> pendingTasks;
  final List<ClassSlot> slots;
  final bool isLoading;
  final bool isRefreshing;
  final VoidCallback onRefresh;
  final void Function(Map<String, dynamic> course) onCourseTap;
  final VoidCallback onTimetableTap;

  const MobileCoursesView({
    super.key,
    required this.courses,
    required this.pendingTasks,
    required this.slots,
    this.isLoading = false,
    this.isRefreshing = false,
    required this.onRefresh,
    required this.onCourseTap,
    required this.onTimetableTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    if (isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    final bottomInset = MediaQuery.paddingOf(context).bottom;

    return RefreshIndicator(
      onRefresh: () async => onRefresh(),
      child: ListView(
        padding: EdgeInsets.fromLTRB(16, 12, 16, 80 + bottomInset),
        children: [
          // 1. My Timetable Quick Hero Card
          BouncyTap(
            onTap: onTimetableTap,
            child: Card(
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
                side: BorderSide(
                  color: colorScheme.outlineVariant.withValues(alpha: 0.5),
                ),
              ),
              color: colorScheme.surfaceContainerLow,
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 18,
                  vertical: 14,
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: colorScheme.primary.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        Icons.calendar_month_rounded,
                        color: colorScheme.primary,
                        size: 22,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '나의 주간 시간표',
                            style: theme.textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.bold,
                              letterSpacing: -0.2,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '주간 수업 일정 · 시간표 확인',
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      size: 14,
                      color: colorScheme.onSurfaceVariant.withValues(
                        alpha: 0.7,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          const SizedBox(height: 16),

          // 2. Section Header: Course count
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 0, 4, 10),
            child: Row(
              children: [
                Text(
                  '수강 과목',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    letterSpacing: -0.3,
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: colorScheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    '${courses.length}개',
                    style: theme.textTheme.labelSmall?.copyWith(
                      color: colorScheme.onSurfaceVariant,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // 3. Courses List with Rich Cards
          if (courses.isEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Text(
                  '수집된 과목이 없어요.\n포털 연결 후 새로고침을 진행해 주세요.',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            )
          else
            ...courses.map((c) {
              final original = '${c['course_nm'] ?? ''}';
              final label = courseLabel(original);
              final cKey = courseKey(c);
              final accent = courseAccent(cKey);

              // Tasks belonging to this course
              final courseTasks = pendingTasks
                  .where((i) => courseKey(i.context) == cKey)
                  .toList();
              // The card's 마감 line is the nearest deadline still ahead;
              // the list's first row could be a miss from weeks ago.
              final now = DateTime.now().toUtc();
              final nextTask =
                  (courseTasks
                          .where((i) => i.due != null && i.due!.isAfter(now))
                          .toList()
                        ..sort((a, b) => a.due!.compareTo(b.due!)))
                      .firstOrNull;

              // Associated timetable slots
              final courseSlots = slots
                  .where(
                    (s) =>
                        s.courseKey == cKey ||
                        s.course == original ||
                        s.course == label,
                  )
                  .toList();
              final slotRoom =
                  courseSlots.isNotEmpty && courseSlots.first.room.isNotEmpty
                  ? courseSlots.first.room
                  : null;

              return Padding(
                padding: const EdgeInsets.only(bottom: 11),
                child: BouncyTap(
                  onTap: () => onCourseTap(c),
                  child: Container(
                    decoration: BoxDecoration(
                      color: colorScheme.surfaceContainerLowest,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                        color: colorScheme.outlineVariant.withValues(
                          alpha: 0.45,
                        ),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: colorScheme.shadow.withValues(alpha: 0.03),
                          blurRadius: 10,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: IntrinsicHeight(
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          // Left course accent stripe
                          Container(
                            width: 5.5,
                            decoration: BoxDecoration(
                              color: accent,
                              borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(18),
                                bottomLeft: Radius.circular(18),
                              ),
                            ),
                          ),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(
                                15,
                                14,
                                14,
                                14,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      // Course Pill
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 8.5,
                                          vertical: 3,
                                        ),
                                        decoration: BoxDecoration(
                                          color: accent.withValues(alpha: 0.14),
                                          borderRadius: BorderRadius.circular(
                                            8,
                                          ),
                                        ),
                                        child: Text(
                                          label,
                                          style: theme.textTheme.labelSmall
                                              ?.copyWith(
                                                color: accent,
                                                fontWeight: FontWeight.w700,
                                                letterSpacing: -0.2,
                                              ),
                                        ),
                                      ),
                                      if (slotRoom != null) ...[
                                        const SizedBox(width: 6),
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 7,
                                            vertical: 2.5,
                                          ),
                                          decoration: BoxDecoration(
                                            color: colorScheme
                                                .surfaceContainerHighest,
                                            borderRadius: BorderRadius.circular(
                                              6,
                                            ),
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Icon(
                                                Icons.place_outlined,
                                                size: 11,
                                                color: colorScheme
                                                    .onSurfaceVariant,
                                              ),
                                              const SizedBox(width: 2.5),
                                              Text(
                                                slotRoom,
                                                style: theme
                                                    .textTheme
                                                    .labelSmall
                                                    ?.copyWith(
                                                      fontSize: 10,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      color: colorScheme
                                                          .onSurfaceVariant,
                                                    ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                      const Spacer(),
                                      // Open task count badge
                                      if (courseTasks.isNotEmpty)
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 8.5,
                                            vertical: 3,
                                          ),
                                          decoration: BoxDecoration(
                                            color: colorScheme.errorContainer,
                                            borderRadius: BorderRadius.circular(
                                              9,
                                            ),
                                            border: Border.all(
                                              color: colorScheme.error
                                                  .withValues(alpha: 0.25),
                                            ),
                                          ),
                                          child: Text(
                                            '할 일 ${courseTasks.length}개',
                                            style: theme.textTheme.labelSmall
                                                ?.copyWith(
                                                  color: colorScheme
                                                      .onErrorContainer,
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 11,
                                                ),
                                          ),
                                        )
                                      else
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 8,
                                            vertical: 2.5,
                                          ),
                                          decoration: BoxDecoration(
                                            color: colorScheme
                                                .surfaceContainerHighest
                                                .withValues(alpha: 0.6),
                                            borderRadius: BorderRadius.circular(
                                              7,
                                            ),
                                          ),
                                          child: Text(
                                            '완료',
                                            style: theme.textTheme.labelSmall
                                                ?.copyWith(
                                                  color: colorScheme
                                                      .onSurfaceVariant,
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 11,
                                                ),
                                          ),
                                        ),
                                    ],
                                  ),
                                  const SizedBox(height: 9),

                                  // Full course title
                                  Text(
                                    original,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: theme.textTheme.titleMedium
                                        ?.copyWith(
                                          fontWeight: FontWeight.w800,
                                          fontSize: 16,
                                          letterSpacing: -0.4,
                                        ),
                                  ),
                                  const SizedBox(height: 6),

                                  // Nearest task deadline info (if any)
                                  if (nextTask != null)
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.schedule_rounded,
                                          size: 13,
                                          color: colorScheme.onSurfaceVariant,
                                        ),
                                        const SizedBox(width: 4.5),
                                        Expanded(
                                          child: Text(
                                            '다음 마감: ${nextTask.title}',
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: theme.textTheme.bodySmall
                                                ?.copyWith(
                                                  color: colorScheme
                                                      .onSurfaceVariant,
                                                  fontSize: 12,
                                                  letterSpacing: -0.2,
                                                ),
                                          ),
                                        ),
                                      ],
                                    ),
                                ],
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 14),
                            child: Icon(
                              Icons.arrow_forward_ios_rounded,
                              size: 13,
                              color: colorScheme.outlineVariant,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }
}

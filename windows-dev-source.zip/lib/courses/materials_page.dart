import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/campus/media_cache.dart';
import 'package:campus_radar/campus/campus_session.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/adaptive_content.dart';
import 'package:campus_radar/campus/material_catalog.dart';
import 'package:campus_radar/courses/media_widgets.dart';
import 'package:campus_radar/courses/course_labels.dart';

class MaterialsPage extends StatefulWidget {
  final String? course;
  final bool embedded, active;
  const MaterialsPage({
    super.key,
    this.course,
    this.embedded = false,
    this.active = true,
  });
  @override
  State<MaterialsPage> createState() => _MaterialsPageState();
}

class _MaterialsPageState extends State<MaterialsPage> {
  List<StudyMaterial> rows = [];
  final savedStates = <String, String>{};
  String query = '', kind = '';
  bool loading = true, started = false;
  String? error;
  @override
  void initState() {
    super.initState();
    if (widget.active) load();
  }

  @override
  void didUpdateWidget(MaterialsPage old) {
    super.didUpdateWidget(old);
    if (widget.active && !started) load();
  }

  Future<void> load() async {
    started = true;
    Store? s;
    try {
      s = await Store.open();
      final data = await studyMaterials(s);
      if (mounted) {
        setState(() {
          rows = data;
          loading = false;
          error = null;
        });
      }
      try {
        final viewer = await pcDriveMode();
        final account = viewer ? 'drive-viewer' : await credentials.read(key: 'id');
        if (account != null) {
          final cache = viewer ? await MediaCache.openViewer() : await MediaCache.open(account);
          for (final m in data.where((m) => m.media != null)) {
            savedStates[m.id] = await cache.status(m.media!);
          }
        }
      } catch (_) {
        for (final m in data.where((m) => m.media != null)) {
          savedStates[m.id] = '저장 상태 확인 불가';
        }
      }
      if (mounted) {
        setState(() {
          rows = data;
          error = null;
        });
      }
    } catch (_) {
      if (mounted) setState(() => error = '자료 목록을 읽지 못했어요.');
    } finally {
      await s?.db.close();
      if (mounted) setState(() => loading = false);
    }
  }

  Widget materialTile(StudyMaterial m) => ListTile(
    leading: Icon(
      m.externalUrl.isNotEmpty
          ? Icons.link
          : m.media == null
          ? Icons.article_outlined
          : Icons.attach_file,
    ),
    // The post title leads; "본문.txt"/"외부 링크" repeated on every row
    // and hid which lecture a file belonged to.
    title: Text(
      m.title.isEmpty ? m.name : m.title,
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
    ),
    subtitle: Text(
      [
        courseLabel(m.course),
        m.media != null
            ? m.name
            : m.externalUrl.isNotEmpty
            ? '외부 링크'
            : '본문',
        if (m.media != null) savedStates[m.id] ?? '저장 상태 확인 중',
      ].join(' · '),
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
    ),
    trailing: const Icon(Icons.chevron_right),
    onTap: () async {
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => Scaffold(
            appBar: AppBar(title: Text(m.name)),
            body: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                Text('${courseLabel(m.course)} · ${m.title}'),
                if (m.externalUrl.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 8, bottom: 8),
                    child: FilledButton.icon(
                      onPressed: () => launchUrl(
                        Uri.parse(m.externalUrl),
                        mode: LaunchMode.externalApplication,
                      ),
                      icon: const Icon(Icons.open_in_new),
                      label: const Text('외부 링크 열기'),
                    ),
                  ),
                if (m.media != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 8, bottom: 8),
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        if (m.media!.form.isNotEmpty) {
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('암호화 전송 자료예요. 기기 저장본 또는 Google Drive "캠퍼스레이더 첨부원본.zip"에서 확인해 주세요.'),
                              ),
                            );
                          }
                          return;
                        }
                        final u = Uri.tryParse(m.media!.url);
                        if (u != null) {
                          await launchUrl(u, mode: LaunchMode.externalApplication);
                        }
                      },
                      icon: Icon(m.media!.form.isNotEmpty ? Icons.lock_outline : Icons.open_in_browser),
                      label: Text(m.media!.form.isNotEmpty
                          ? '${m.media!.name} (암호화 원본 안내)'
                          : '${m.media!.name} 학교 원본 열기'),
                    ),
                  ),
                CampusBodyView(
                  body: m.body,
                  bodyHtml: '',
                  media: m.media == null ? const [] : [m.media!],
                ),
              ],
            ),
          ),
        ),
      );
      if (mounted) await load();
    },
  );
  @override
  Widget build(BuildContext context) {
    if (!widget.active) return const SizedBox.shrink();
    final list = rows
        .where(
          (m) =>
              (widget.course == null || m.course == widget.course) &&
              (kind.isEmpty || m.sourceType == kind) &&
              '${m.name} ${m.title} ${m.course} ${courseLabel(m.course)}'
                  .toLowerCase()
                  .contains(query.toLowerCase()),
        )
        .toList();
    final content = AdaptiveContent(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          if (widget.embedded)
            Row(
              children: [
                const Expanded(child: Text('공지·과제·콘텐츠·자료실 자료')),
                IconButton(
                  tooltip: '자료 목록 새로고침',
                  onPressed: load,
                  icon: const Icon(Icons.refresh),
                ),
              ],
            ),
          TextField(
            decoration: const InputDecoration(
              labelText: '파일·제목·과목 검색',
              prefixIcon: Icon(Icons.search),
            ),
            onChanged: (v) => setState(() => query = v),
          ),
          Wrap(
            spacing: 8,
            children: [
              for (final e in const {
                '': '전체',
                'LS': '자료실',
                'NT': '공지',
                'LV': '콘텐츠',
                'LR': '과제',
              }.entries)
                ChoiceChip(
                  label: Text(e.value),
                  selected: kind == e.key,
                  onSelected: (_) => setState(() => kind = e.key),
                ),
            ],
          ),
          if (loading) const LinearProgressIndicator(),
          if (error != null) Text(error!),
          Text('${list.length}개 · 본문·첨부·외부 링크'),
          for (final m in list) materialTile(m),
          if (!loading && list.isEmpty)
            const Text(
              '현재 조건에 해당하는 자료가 없어요. 본문·첨부가 아직 수집되지 않았다면 학교 수집 또는 해당 상세 화면에서 확인해 주세요.',
            ),
        ],
      ),
    );
    if (widget.embedded) return content;
    return Scaffold(
      appBar: AppBar(
        title: const Text('자료 모아보기'),
        actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))],
      ),
      body: content,
    );
  }
}

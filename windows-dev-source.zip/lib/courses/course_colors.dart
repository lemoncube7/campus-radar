import 'package:campus_radar/campus/campus_session.dart' show ensurePcEditable;
import 'package:campus_radar/core/storage_keys.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:flutter/material.dart';

const courseAccentColors = [
  Color(0xff4566b0),
  Color(0xff2a8d80),
  Color(0xffc36b43),
  Color(0xff8f62b5),
  Color(0xff3e84b8),
  Color(0xffb55880),
];
final courseColorOverrides = <String, int>{};
Future<void> loadCourseColors() async {
  final prefs = await SharedPreferences.getInstance();
  final raw = prefs.getString(PrefKey.courseColorOverrides);
  if (raw == null) {
    courseColorOverrides.clear();
    return;
  }
  try {
    final data = jsonDecode(raw) as Map;
    courseColorOverrides
      ..clear()
      ..addAll({
        for (final e in data.entries)
          if (e.value is int) '${e.key}': e.value as int,
      });
  } catch (_) {
    /* retain last good colors */
  }
}

Future<void> saveCourseColor(String key, Color? color) async {
  await ensurePcEditable();
  final next = Map<String, int>.from(courseColorOverrides);
  if (color == null) {
    next.remove(key);
  } else {
    next[key] = color.toARGB32();
  }
  final prefs = await SharedPreferences.getInstance();
  if (!await prefs.setString(PrefKey.courseColorOverrides, jsonEncode(next))) {
    throw StateError('색상을 저장하지 못했어요.');
  }
  courseColorOverrides
    ..clear()
    ..addAll(next);
}

Color courseAccent(String key) {
  if (courseColorOverrides.containsKey(key)) {
    return Color(courseColorOverrides[key]!);
  }
  var value = 0;
  for (final unit in key.codeUnits) {
    value = (31 * value + unit) & 0x7fffffff;
  }
  return courseAccentColors[value % courseAccentColors.length];
}

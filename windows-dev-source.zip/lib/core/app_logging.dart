import 'dart:async';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/startup_diagnostics.dart';

/// Short technical cause for an activity-log line. Keeps the user-facing
/// sentence, adds what actually failed. Exported logs redact accounts and keys.
String failureCause(Object e) {
  final String cause;
  if (e is PlatformException) {
    cause = '기기 기능 ${e.code}${e.message == null ? '' : ' · ${e.message}'}';
  } else if (e is SocketException) {
    cause = '네트워크 ${e.osError?.errorCode ?? '미확인'}';
  } else if (e is TimeoutException) {
    cause = '시간 초과';
  } else if (e is FormatException) {
    cause = '형식 · ${e.message}';
  } else if (e is FileSystemException) {
    cause = '파일 ${e.osError?.errorCode ?? '미확인'}';
  } else {
    final storage = storageFailureCode(e);
    cause = storage == 'unknown'
        ? '${e.runtimeType}'
        : '저장소 $storage (${e.runtimeType})';
  }
  // Drop query strings that could carry tokens; keep one short line.
  final line = cause.replaceAll(RegExp(r'\?\S*'), '').replaceAll('\n', ' ');
  return line.length > 160 ? '${line.substring(0, 160)}…' : line;
}

String withCause(String detail, Object e) => '$detail\n원인: ${failureCause(e)}';

Future<void> systemLog(
  String title,
  String detail, {
  String kind = 'system',
  Object? error,
}) async {
  Store? store;
  try {
    store = await Store.open();
    await store.log(kind, title, error == null ? detail : withCause(detail, error));
  } catch (_) {
    // The main operation remains available if local logging fails.
  } finally {
    await store?.db.close();
  }
}

import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/operation_token.dart';
import 'dart:async';

class SessionChanged implements Exception {
  @override
  String toString() => '계정 또는 전송 동의가 변경되어 이전 작업을 중단했어요.';
}

/// The generation survives logout cleanup, so logout -> same-account login is
/// also a different session. All isolates consult the same local database.
class SessionScope {
  final Store store;
  final String? account, apiKey;
  final String epoch;
  final Map<String, String> consents;
  SessionScope._(
    this.store,
    this.account,
    this.epoch,
    this.apiKey,
    this.consents,
  );

  static Future<SessionScope> capture(
    Store store, {
    Map<String, String> consents = const {},
    bool ai = false,
  }) async {
    final account = await credentials.read(key: 'id');
    final epoch = await store.db.transaction((txn) async {
      final rows = await txn.query(
        'meta',
        where: 'id=?',
        whereArgs: ['sessionEpoch'],
      );
      if (rows.isNotEmpty) return rows.single['value'] as String;
      final token = freshToken();
      await txn.insert('meta', {'id': 'sessionEpoch', 'value': token});
      return token;
    });
    final key = ai ? await credentials.read(key: 'geminiApiKey') : null;
    final scope = SessionScope._(store, account, epoch, key, Map.of(consents));
    await scope.verify();
    return scope;
  }

  Future<void> verify() async {
    if (await store.meta(MetaKey.sessionEpoch) != epoch ||
        await store.meta(MetaKey.sessionBlocked) == 'yes' ||
        await credentials.read(key: 'id') != account ||
        apiKey != null &&
            await credentials.read(key: 'geminiApiKey') != apiKey) {
      throw SessionChanged();
    }
    for (final entry in consents.entries) {
      if (await store.meta(entry.key) != entry.value) throw SessionChanged();
    }
  }

  Timer watch(void Function() cancel) {
    var checking = false;
    return Timer.periodic(const Duration(seconds: 1), (timer) async {
      if (checking) return;
      checking = true;
      try {
        await verify();
      } catch (_) {
        timer.cancel();
        cancel();
      } finally {
        checking = false;
      }
    });
  }

  static Future<void> rotate(Store store, {required bool blocked}) =>
      store.db.transaction((txn) async {
        await txn.rawInsert(
          'INSERT OR REPLACE INTO meta(id,value) VALUES(?,?)',
          ['sessionEpoch', freshToken()],
        );
        await txn.rawInsert(
          'INSERT OR REPLACE INTO meta(id,value) VALUES(?,?)',
          ['sessionBlocked', blocked ? 'yes' : 'no'],
        );
      });
}

/// A lightweight marker of the session a screen loaded its data under, for
/// actions taken later (undo, decisions) on a store opened afresh.
class SessionMark {
  final String? epoch, account;
  const SessionMark._(this.epoch, this.account);
  static Future<SessionMark> capture(Store store) async => SessionMark._(
    await store.meta(MetaKey.sessionEpoch),
    await credentials.read(key: 'id'),
  );
  Future<void> verify(Store store) async {
    if (await store.meta(MetaKey.sessionEpoch) != epoch ||
        await store.meta(MetaKey.sessionBlocked) == 'yes' ||
        await credentials.read(key: 'id') != account) {
      throw SessionChanged();
    }
  }
}

/// Cleanup steps are independent: a failed widget/cache operation must never
/// prevent the credential deletion step from being attempted.
Future<List<String>> completeLogout(
  List<(String, Future<void> Function())> steps,
) async {
  final failed = <String>[];
  for (final step in steps) {
    try {
      await step.$2();
    } catch (_) {
      failed.add(step.$1);
    }
  }
  return failed;
}

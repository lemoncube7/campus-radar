import 'package:campus_radar/updates/updates.dart';

String redactDiagnostic(String value) => value
    .replaceAll(RegExp(r'AIza[0-9A-Za-z_-]{20,}'), '[키 제거됨]')
    .replaceAll(
      RegExp(r'(?:https?://)[^\s]+', caseSensitive: false),
      '[주소 제거됨]',
    )
    .replaceAll(
      RegExp(r'(?:bearer\s+)[^\s]+', caseSensitive: false),
      '[인증 제거됨]',
    )
    .replaceAllMapped(
      RegExp(
        r'''([a-z_]*(?:password|passwd|pwd|cookie|authorization|token|sessionid|session|api[_ -]?key)|pw)["']?\s*[:=]\s*[^\n]+''',
        caseSensitive: false,
      ),
      (m) => '${m[1]}=[제거됨]',
    );

String diagnosticReport(
  List<Map<String, Object?>> rows, {
  required String platform,
  required DateTime generatedAt,
  bool includeDetails = false,
}) {
  final out = StringBuffer(
    '캠퍼스레이더 진단 로그\n앱: $installedAppVersion ($installedAppBuild)\n기기: $platform\n생성: ${generatedAt.toUtc().toIso8601String()} (UTC)\n기록 시각은 저장된 원래 값입니다.\n건수: ${rows.length}\n상세 내용: ${includeDetails ? "포함 (전송 전 검토 필요)" : "제외"}\n\n',
  );
  for (final row in rows) {
    if (out.length > 1700000) {
      out.writeln('\n파일 크기 제한으로 이후 기록을 생략했어요. 필터로 범위를 좁혀 주세요.');
      break;
    }
    out.writeln(
      redactDiagnostic(
        '[${row['at'] ?? row['created_at'] ?? row['time'] ?? ""}] ${row['kind']} · ${row['title']}',
      ),
    );
    if (includeDetails) {
      out.writeln(
        redactDiagnostic(
          '${row['detail'] ?? ""}'.substring(
            0,
            '${row['detail'] ?? ""}'.length.clamp(0, 20000),
          ),
        ),
      );
    }
  }
  return out.toString();
}

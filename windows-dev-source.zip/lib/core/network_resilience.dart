import 'dart:async';
import 'dart:io';

class ActiveRequests {
  static final _clients = <HttpClient>{};
  static void add(HttpClient client) => _clients.add(client);
  static void remove(HttpClient client) => _clients.remove(client);
  static void cancelAll() {
    for (final client in _clients.toList()) {
      client.close(force: true);
    }
    _clients.clear();
  }
}

Future<T> requestDeadline<T>(
  Future<T> Function() run,
  void Function() cancel, {
  required Duration limit,
}) async {
  if (limit <= Duration.zero) throw TimeoutException('요청 전체 시간이 초과됐어요.');
  return run().timeout(
    limit,
    onTimeout: () {
      cancel();
      throw TimeoutException('요청 전체 시간이 초과됐어요.');
    },
  );
}

abstract interface class HttpStatusError {
  int get status;
}

class NetworkHttpException implements Exception, HttpStatusError {
  @override
  final int status;
  NetworkHttpException(this.status);
  @override
  String toString() => 'HTTP $status';
}

bool isTransientNetworkFailure(Object error) =>
    error is SocketException ||
    error is TimeoutException ||
    error is HttpException ||
    (error is HttpStatusError &&
        const {408, 502, 503, 504}.contains(error.status));

/// Only use for reads with no external side effects. Never wrap AI generation,
/// credential submission, calendar insertion or notification delivery.
Future<T> retryNetworkRead<T>(
  Future<T> Function() read, {
  void Function()? onRetry,
  Duration delay = const Duration(milliseconds: 700),
}) async {
  try {
    return await read();
  } catch (error) {
    if (!isTransientNetworkFailure(error)) rethrow;
    onRetry?.call();
    await Future<void>.delayed(delay);
    return read();
  }
}

String networkFailureMessage(Object error) {
  if (error is TimeoutException) return '서버 응답 시간이 초과됐어요. 잠시 후 다시 시도해 주세요.';
  if (error is SocketException) {
    return '인터넷 연결을 확인해 주세요. 연결이 복구되면 다시 시도할 수 있어요.';
  }
  if (error is HandshakeException) {
    return '보안 연결을 확인하지 못했어요. 기기의 날짜·시간과 네트워크를 확인해 주세요.';
  }
  if (error is HttpStatusError) {
    if (error.status == 401 || error.status == 403) {
      return '서버가 접근을 거절했어요 (${error.status}). 로그인 상태 또는 접근 권한을 확인해 주세요.';
    }
    if (error.status == 429) {
      return '요청이 많아 서버가 잠시 제한했어요. 잠시 기다린 뒤 다시 시도해 주세요.';
    }
    return '서버 응답 오류 (${error.status}). 잠시 후 다시 시도해 주세요.';
  }
  if (error is HttpException) return '통신이 도중에 끊겼습니다. 다시 시도해 주세요.';
  return '네트워크 요청을 완료하지 못했어요.';
}

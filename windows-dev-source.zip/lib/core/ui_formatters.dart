import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:flutter/services.dart';

String dateText(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
String userError(Object e) => e is AiFailure
    ? e.message
    : e is PlatformException
    ? e.message ?? '기기 작업을 완료하지 못했어요.'
    : '처리하지 못했어요. 다시 시도해 주세요.';

/// Per-stage timings. Labels are fixed operations or API paths without queries.
class SyncTiming {
  final _samples = <String, ({int count, int micros, int maxMicros})>{};

  Future<T> measure<T>(String label, Future<T> Function() operation) async {
    final clock = Stopwatch()..start();
    try {
      return await operation();
    } finally {
      final elapsed = clock.elapsedMicroseconds;
      final previous = _samples[label];
      final max = previous?.maxMicros ?? 0;
      _samples[label] = (
        count: (previous?.count ?? 0) + 1,
        micros: (previous?.micros ?? 0) + elapsed,
        maxMicros: elapsed > max ? elapsed : max,
      );
    }
  }

  List<String> describe(int totalMs) {
    final ordered = _samples.entries.toList()
      ..sort((a, b) => b.value.micros.compareTo(a.value.micros));
    final measured = ordered.fold<int>(0, (sum, e) => sum + e.value.micros);
    String ms(num micros) => (micros / 1000).toStringAsFixed(1);
    return [
      '전체: $totalMs ms',
      for (final entry in ordered)
        '${entry.key}: ${entry.value.count}회 · 합계 ${ms(entry.value.micros)} ms · 최대 ${ms(entry.value.maxMicros)} ms',
      '나머지(목록 조회·파싱·검사 등): ${ms((totalMs * 1000 - measured).clamp(0, totalMs * 1000))} ms',
    ];
  }
}


import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

String startupStage = '초기화';

String storageFailureCode(Object error) {
  final text = error.toString().toLowerCase();
  if (RegExp(
    r'sqlite_busy|sqlite_locked|database is locked|database table is locked',
  ).hasMatch(text)) {
    return 'busy';
  }
  if (RegExp(
    r'sqlite_full|database or disk is full|no space left',
  ).hasMatch(text)) {
    return 'full';
  }
  if (RegExp(
    r'sqlite_corrupt|sqlite_notadb|malformed|not a database',
  ).hasMatch(text)) {
    return 'corrupt';
  }
  if (RegExp(
    r'downgrade|database version|no such table|no such column',
  ).hasMatch(text)) {
    return 'schema';
  }
  if (RegExp(r'read.?only|sqlite_cantopen|unable to open').hasMatch(text)) {
    return 'access';
  }
  return 'unknown';
}

String storageFailureAdvice(String code) => switch (code) {
  'busy' => '다른 작업이 저장소를 사용하고 있어요. 잠시 후 다시 시도해 주세요.',
  'full' => '기기의 저장 공간이 부족해요. 여유 공간을 확보한 뒤 다시 시도해 주세요.',
  'corrupt' => '저장소 파일을 읽지 못했어요. 데이터를 유지한 채 진단 정보를 전달해 주세요.',
  'schema' => '저장소 버전을 준비하지 못했어요. 앱 버전과 진단 정보를 전달해 주세요.',
  'access' => '저장소에 접근하지 못했어요. 기기 저장 공간과 진단 정보를 확인해 주세요.',
  _ => '기기 저장소를 준비하지 못했어요. 데이터를 지우지 않고 다시 시도해 주세요.',
};

Future<T> retryDatabaseOpen<T>(
  Future<T> Function() open, {
  Future<void> Function(Duration)? delay,
}) async {
  for (var attempt = 0; ; attempt++) {
    try {
      return await open();
    } catch (error) {
      if (error is! DatabaseException ||
          storageFailureCode(error) != 'busy' ||
          attempt >= 2) {
        rethrow;
      }
      await (delay ?? Future<void>.delayed)(
        Duration(milliseconds: 250 * (attempt + 1)),
      );
    }
  }
}

/// No SQL, account, key, cookie, path, source text, or raw exception is stored.
Map<String, String> startupDiagnostic(Object error, String stage) => {
  'at': DateTime.now().toUtc().toIso8601String(),
  'stage': stage,
  'kind': error.runtimeType.toString(),
  'storageCode': error is DatabaseException
      ? storageFailureCode(error)
      : 'not_database',
};

Future<void> persistStartupDiagnostic(Map<String, String> value) async {
  try {
    final dir = await getApplicationSupportDirectory();
    await dir.create(recursive: true);
    await File(
      '${dir.path}/startup-diagnostic.json',
    ).writeAsString(jsonEncode(value), flush: true);
  } catch (_) {
    /* A diagnostic failure must not hide the original failure. */
  }
}

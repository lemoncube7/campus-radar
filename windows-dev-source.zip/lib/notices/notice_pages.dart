import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/ai/ai_inbox_page.dart';
import 'package:campus_radar/ai/ai_inbox_repository.dart';
import 'package:campus_radar/ai/notice_ai_service.dart';
import 'package:campus_radar/ai/ai_recovery_page.dart';
import 'package:campus_radar/core/ui_formatters.dart';
import 'package:campus_radar/campus/campus_session.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/campus/services.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/tasks/task_presentation.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/core/network_resilience.dart';
import 'package:campus_radar/courses/media_widgets.dart';
import 'package:campus_radar/core/ui_refresh.dart';
import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:campus_radar/campus/campus.dart';

class NoticesPage extends StatefulWidget {
  const NoticesPage({super.key});
  @override
  State<NoticesPage> createState() => _NoticesPageState();
}

class _NoticesPageState extends State<NoticesPage> {
  List<CampusNotice> notices = [];
  Map<String, String> aiStates = {};
  String query = '', course = '', error = '';
  bool loading = true, collecting = false;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final store = await Store.open();
    try {
      final data = await store.notices();
      final failure = await store.meta(MetaKey.noticeError);
      final statuses = <String, String>{};
      for (final n in data) {
        // One damaged queue row must not keep the whole list from loading.
        Map q;
        try {
          final raw = jsonDecode(
            await store.meta(MetaKey.aiQueue(n.id)) ?? '{}',
          );
          q = raw is Map ? raw : const {};
        } catch (_) {
          q = const {};
        }
        statuses[n.id] =
            {
              'pending': 'AI 대기',
              'running': 'AI 분석 중',
              'done': 'AI 후보 있음',
              'empty': '일정 없음',
              'failed': 'AI 실패',
            }[q['status']] ??
            '미분석';
      }
      if (mounted) {
        setState(() {
          notices = data;
          aiStates = statuses;
          error = failure ?? '';
          loading = false;
          if (!data.any((n) => n.course == course)) course = '';
        });
      }
    } finally {
      await store.db.close();
    }
  }

  Future<void> collect() async {
    if (collecting) return;
    setState(() => collecting = true);
    try {
      await synchronize(source: '공지 목록에서 확인');
      await load();
    } catch (_) {
      if (mounted) {
        setState(() => error = '학교에서 새 공지를 확인하지 못했어요. 저장된 목록은 유지해요.');
      }
    } finally {
      if (mounted) setState(() => collecting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final courses = notices.map((n) => n.course).toSet().toList()..sort();
    final visible = notices
        .where(
          (n) =>
              (course.isEmpty || n.course == course) &&
              '${courseLabel(n.course)} ${n.title}'.toLowerCase().contains(
                query.toLowerCase(),
              ),
        )
        .toList();
    return Scaffold(
      appBar: AppBar(
        title: const Text('공지 모아보기'),
        actions: [
          IconButton(
            onPressed: collecting ? null : collect,
            icon: const Icon(Icons.refresh),
            tooltip: '학교에서 새 공지 확인',
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                TextField(
                  decoration: const InputDecoration(
                    labelText: '공지·과목 검색',
                    prefixIcon: Icon(Icons.search),
                  ),
                  onChanged: (v) => setState(() => query = v),
                ),
                DropdownButton<String>(
                  isExpanded: true,
                  value: course,
                  items: [
                    const DropdownMenuItem(value: '', child: Text('모든 과목')),
                    ...courses.map(
                      (c) => DropdownMenuItem(
                        value: c,
                        child: Text(
                          courseLabel(c),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ),
                  ],
                  onChanged: (v) => setState(() => course = v ?? ''),
                ),
                if (error.isNotEmpty)
                  Text(
                    error,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.error,
                    ),
                  ),
              ],
            ),
          ),
          if (loading) const LinearProgressIndicator(),
          if (aiStates.values.where((s) => s == 'AI 실패').length
              case final failed when failed > 0)
            // One banner instead of an "AI 실패" tag on every card.
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Material(
                color: Theme.of(context).colorScheme.errorContainer,
                borderRadius: BorderRadius.circular(12),
                child: ListTile(
                  dense: true,
                  leading: const Icon(Icons.error_outline),
                  title: Text('AI 분석 $failed건 실패'),
                  trailing: const Text('원인 보기'),
                  onTap: () async {
                    await navigateTo(
                      context,
                      const AiInboxDestination(records: true),
                    );
                    await load();
                  },
                ),
              ),
            ),
          Expanded(
            child: RefreshIndicator(
              onRefresh: load,
              child: ListView.builder(
                physics: const AlwaysScrollableScrollPhysics(),
                itemCount: visible.isEmpty ? 1 : visible.length,
                itemBuilder: (context, index) {
                  if (visible.isEmpty) {
                    return const Padding(
                      padding: EdgeInsets.all(24),
                      child: Text('표시할 공지가 없어요. 학교에서 새 공지를 확인해 주세요.'),
                    );
                  }
                  final n = visible[index];
                  final day = n.published == null
                      ? '게시일 미확인'
                      : formatDate(n.published!).split(' ').first;
                  final previous = index == 0
                      ? ''
                      : visible[index - 1].published == null
                      ? '게시일 미확인'
                      : formatDate(
                          visible[index - 1].published!,
                        ).split(' ').first;
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      if (day != previous)
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: SectionHeading(day),
                        ),
                      Card(
                        margin: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 4,
                        ),
                        child: ListTile(
                          minLeadingWidth: 12,
                          leading: Icon(
                            n.read ? Icons.circle_outlined : Icons.circle,
                            size: 10,
                            color: n.read
                                ? Theme.of(context).colorScheme.outline
                                : Theme.of(context).colorScheme.primary,
                            semanticLabel: n.read ? '읽음' : '안 읽음',
                          ),
                          title: Text(
                            n.title,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          // The day is already the section heading.
                          subtitle: Text(
                            '${courseLabel(n.course)} · ${n.published == null ? '시각 미확인' : formatDate(n.published!).split(' ')[1]}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          // Only actionable states; failures are in the banner,
                          // "미분석"/"일정 없음" on every row was noise.
                          trailing: switch (aiStates[n.id]) {
                            'AI 후보 있음' || 'AI 분석 중' => Text(
                              aiStates[n.id]!,
                              style: Theme.of(context).textTheme.labelSmall,
                            ),
                            _ => null,
                          },
                          onTap: () async {
                            await navigateTo(
                              context,
                              NoticeDestination(notice: n),
                            );
                            await load();
                          },
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class NoticeDetailPage extends StatefulWidget {
  final CampusNotice notice;
  const NoticeDetailPage({super.key, required this.notice});
  @override
  State<NoticeDetailPage> createState() => _NoticeDetailPageState();
}

class _NoticeDetailPageState extends State<NoticeDetailPage> {
  late CampusNotice notice = widget.notice;
  bool loading = true, opening = false;
  String? error;
  bool resultsVisible = false, analyzing = false;
  int resultCount = 0, needsReview = 0, analysisRevision = 0;
  Map<String, dynamic>? analysisJob;
  String? analysisError;
  @override
  void initState() {
    super.initState();
    loadBody();
    loadAnalysisStatus();
  }

  Future<void> loadAnalysisStatus() async {
    if (!mounted) return;
    Store? store;
    try {
      store = await Store.open();
      if (!mounted) return;
      final snapshot = await AiInboxRepository(store).read();
      final results = snapshot.candidates
          .where((r) => (r['notice'] as CampusNotice).id == notice.id)
          .toList();
      if (mounted) {
        setState(() {
          resultCount = results.length;
          needsReview = results
              .where(
                (r) => ((r['state'] as Map)['status'] ?? 'review') == 'review',
              )
              .length;
          analysisJob = snapshot.jobs
              .where((j) => j['id'] == notice.id)
              .firstOrNull;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() => analysisError = '저장된 분석 상태를 확인하지 못했어요. 원문은 계속 볼 수 있어요.');
      }
    } finally {
      await store?.db.close();
    }
  }

  Future<void> analyzeNotice() async {
    if (analyzing) return;
    setState(() {
      analyzing = true;
      analysisError = null;
    });
    try {
      if (!notice.bodyFetched) await loadBody();
      if (!notice.bodyFetched || error != null) return;
      await NoticeAi.analyze(notice);
      await loadAnalysisStatus();
      if (mounted) {
        setState(() {
          resultsVisible = true;
          analysisRevision++;
        });
      }
    } catch (failure) {
      if (mounted) setState(() => analysisError = userError(failure));
    } finally {
      if (mounted) setState(() => analyzing = false);
    }
  }

  Widget resultsView() => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      Text(
        needsReview > 0
            ? '검토함 $needsReview개 · 전체 $resultCount개'
            : resultCount > 0
            ? '처리 결과 $resultCount개'
            : '아직 찾은 결과가 없어요.',
        style: Theme.of(context).textTheme.titleMedium,
      ),
      const SizedBox(height: 8),
      const Text(
        '저장된 결과는 바로 확인할 수 있어요. 새로 분석할 때는 이 공지 본문을 Gemini에 전송하며 기존 자동 승인 설정을 따라요.',
      ),
      Wrap(
        spacing: 8,
        children: [
          FilledButton.tonalIcon(
            onPressed: analyzing || loading ? null : analyzeNotice,
            icon: const Icon(Icons.auto_awesome),
            label: Text(
              analyzing
                  ? '공지 확인 중…'
                  : resultCount > 0
                  ? '다시 분석'
                  : '공지에서 일정 찾기',
            ),
          ),
          TextButton(
            onPressed: () => navigateTo(context, AiSettingsDestination()),
            child: const Text('AI 설정'),
          ),
        ],
      ),
      if (analysisError != null) Text(analysisError!),
      if (analysisJob?['status'] == 'failed')
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.info_outline),
          title: const Text('분석에 도움이 필요해요'),
          subtitle: Text(
            '${analysisJob?['error'] ?? '실패 원인과 해결 방법을 확인해 주세요.'}',
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () async {
            await Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    AiRecoveryPage(notice: notice, job: analysisJob!),
              ),
            );
            await loadAnalysisStatus();
            if (mounted) setState(() => analysisRevision++);
          },
        ),
      AiInboxPage(
        key: ValueKey('notice-results:$analysisRevision'),
        embedded: true,
        inline: true,
        noticeId: notice.id,
        initialFilter: 'all',
        showTools: false,
      ),
    ],
  );

  Future<CampusClient> client() async {
    final id = await credentials.read(key: 'id'),
        pw = await credentials.read(key: 'pw');
    if (id == null || pw == null) throw CampusException('포털을 먼저 연결해 주세요.');
    final c = CampusClient();
    try {
      await c.connectSchool(id, pw);
      return c;
    } catch (_) {
      c.close();
      rethrow;
    }
  }

  Future<void> loadBody({bool force = false}) async {
    if (notice.bodyFetched && !force) {
      setState(() => loading = false);
      return;
    }
    setState(() {
      loading = true;
      error = null;
    });
    CampusClient? c;
    Store? sourceStore;
    SessionScope? scope;
    Timer? watch;
    String? account;
    try {
      sourceStore = await Store.open();
      account = await credentials.read(key: 'id');
      scope = await SessionScope.capture(sourceStore);
      c = await client();
      watch = scope.watch(() => c?.close());
      final data = await c.fetchNoticeBody(notice);
      if (await credentials.read(key: 'id') != account) {
        throw CampusException('계정이 변경되어 공지 저장을 중지했어요.');
      }
      final store = await Store.open();
      try {
        await scope.verify();
        await store.saveNotice(data);
        await store.log(
          'received',
          '공지 본문 수집',
          '${data.course} · ${data.title}',
        );
      } finally {
        await store.db.close();
      }
      if (mounted) setState(() => notice = data);
    } catch (e) {
      if (mounted) {
        setState(
          () => error = e is CampusException
              ? e.message
              : '${networkFailureMessage(e)} 저장된 본문은 유지해요.',
        );
      }
    } finally {
      watch?.cancel();
      c?.close();
      await sourceStore?.db.close();
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> openCampus() async {
    setState(() => opening = true);
    CampusClient? c;
    try {
      c = await client();
      await bridge.invokeNative(
        NativeMethod.openCampus,
        await c.navigation(notice.item),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              e is CampusException ? e.message : '사이버캠퍼스를 열지 못했어요.',
            ),
          ),
        );
      }
    } finally {
      c?.close();
      if (mounted) setState(() => opening = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('공지 상세'),
      actions: [
        IconButton(
          tooltip: '본문·첨부 새로고침',
          onPressed: loading ? null : () => loadBody(force: true),
          icon: const Icon(Icons.refresh),
        ),
      ],
    ),
    bottomNavigationBar: PinnedAction(
      child: FilledButton.icon(
        onPressed: opening ? null : openCampus,
        icon: const Icon(Icons.open_in_new),
        label: Text(opening ? '연결 중…' : '사이버캠퍼스 열기'),
      ),
    ),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Text(courseLabel(notice.course)),
        const SizedBox(height: 8),
        Text(
          notice.title,
          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        if (notice.published != null) Text(formatDate(notice.published!)),
        const SizedBox(height: 16),
        SegmentedButton<bool>(
          showSelectedIcon: false,
          segments: [
            const ButtonSegment(value: false, label: Text('공지 내용')),
            ButtonSegment(value: true, label: Text('찾은 결과 $resultCount')),
          ],
          selected: {resultsVisible},
          onSelectionChanged: (value) {
            setState(() => resultsVisible = value.single);
            loadAnalysisStatus();
          },
        ),
        const SizedBox(height: 20),
        if (resultsVisible)
          resultsView()
        else ...[
          if (loading) const LinearProgressIndicator(),
          if (error != null) ...[
            Text(error!),
            TextButton(
              onPressed: () => loadBody(force: true),
              child: const Text('본문 다시 불러오기'),
            ),
          ],
          if (!notice.bodyFetched && notice.body.isNotEmpty)
            const Text('저장된 본문이에요. 최신 내용을 확인하고 있어요.'),
          CampusBodyView(
            body: notice.body.isEmpty && notice.media.isEmpty
                ? (loading ? '본문을 불러오는 중이에요.' : '본문이 없어요.')
                : notice.body,
            bodyHtml: notice.bodyHtml,
            media: notice.media,
          ),
          const SizedBox(height: 24),
          if (Platform.isAndroid || Platform.isIOS)
            FilledButton.tonalIcon(
              onPressed: loading || opening
                  ? null
                  : () async {
                      if (!notice.bodyFetched) await loadBody();
                      if (!context.mounted ||
                          error != null ||
                          !notice.bodyFetched) {
                        return;
                      }
                      setState(() => resultsVisible = true);
                      await loadAnalysisStatus();
                    },
              icon: const Icon(Icons.auto_awesome),
              label: const Text('공지에서 찾은 일정'),
            ),
          const SizedBox(height: 12),
          const Text(
            '댓글과 외부 학습 도구의 자료는 사이버캠퍼스에서 확인하세요.',
            style: TextStyle(fontSize: 12),
          ),
        ],
      ],
    ),
  );
}

import 'package:campus_radar/core/demo_mode.dart';
import 'package:campus_radar/export/drive_sync.dart';
import 'package:campus_radar/platform/drive_viewer.dart';
import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/campus/deadline_reminders.dart';
import 'package:campus_radar/campus/campus_session.dart';
import 'package:campus_radar/session/session_lifetime_probe.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/core/background_contract.dart';
import 'package:campus_radar/campus/collection_control.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/notification_gateway.dart';
import 'package:campus_radar/courses/course_aliases.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/updates/updates.dart';
import 'package:campus_radar/core/network_resilience.dart';
import 'package:campus_radar/platform/ios_features.dart';
import 'package:campus_radar/core/sync_timing.dart';
import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:workmanager/workmanager.dart';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/campus/media_cache.dart';
import 'package:campus_radar/campus/campus_media.dart';
import 'package:campus_radar/ai/ai_automation.dart';

Future<void> collectCampusMedia(
  Store store,
  CampusClient client,
  String account, {
  SyncTiming? timing,
}) async {
  final scope = await SessionScope.capture(store);
  final cache = await MediaCache.open(account);
  final clock = Stopwatch()..start();
  var bytes = 0, saved = 0, failed = 0;
  Future<bool> sameAccount() async {
    Future<String?> read() => credentials.read(key: 'id');
    return await (timing?.measure('계정 확인', read) ?? read()) == account;
  }

  Future<void> collect(List<CampusMedia> media) async {
    for (final m in media) {
      if (clock.elapsed.inSeconds >= 60 || bytes >= 100 * 1024 * 1024) break;
      if (!m.supported) continue;
      Future<File?> cached() => cache.local(m);
      if (await (timing?.measure('파일 캐시 확인', cached) ?? cached()) != null) {
        continue;
      }
      if ((m.size ?? 0) > 50 * 1024 * 1024) continue;
      // Check the account only before an actual download: cached files need
      // no network, and the secure-storage read cost ~33 ms per item
      // (build 79: 103 checks, 3.4 s, no downloads).
      if (!await sameAccount()) return;
      try {
        final f = await cache.fetch(client, m, timing: timing);
        bytes += await f.length();
        saved++;
      } catch (_) {
        failed++;
      }
    }
  }

  for (final item in await store.items()) {
    if (item.availableAt(DateTime.now())) {
      await collect(item.media);
    }
  }
  // Oldest checked first: a bounded batch eventually covers all notices, not just the newest.
  final notices = await store.notices();
  final checked = <String, String>{};
  for (final n in notices) {
    Future<String?> stamp() => store.meta(MetaKey.mediaChecked(n.id));
    checked[n.id] =
        await (timing?.measure('공지 확인 시각 조회', stamp) ?? stamp()) ?? '';
  }
  notices.sort((a, b) => checked[a.id]!.compareTo(checked[b.id]!));
  var fetched = 0;
  for (var n in notices) {
    if (clock.elapsed.inSeconds >= 60 || fetched >= 12) break;
    final stamp = DateTime.tryParse(checked[n.id]!);
    if (noticeBodyDue(n, stamp, DateTime.now().toUtc())) {
      // Only a body request needs the account check (34 reads, 1.5 s, when
      // no body was due); downloads in collect() check on their own.
      if (!await sameAccount()) return;
      fetched++;
      try {
        n =
            await (timing?.measure(
                  '공지 본문 요청',
                  () => client.fetchNoticeBody(n),
                ) ??
                client.fetchNoticeBody(n));
        Future<void> saveNotice() async {
          await scope.verify();
          await store.saveNotice(n);
          await store.setMeta(
            MetaKey.mediaChecked(n.id),
            DateTime.now().toUtc().toIso8601String(),
          );
        }

        await (timing?.measure('공지 본문 저장·세션 확인', saveNotice) ?? saveNotice());
      } catch (_) {
        failed++;
        await store.setMeta(
          MetaKey.mediaChecked(n.id),
          DateTime.now().toUtc().toIso8601String(),
        );
        continue;
      }
    }
    await collect(n.media);
  }
  await store.log(
    'received',
    '이미지·첨부파일 수집',
    '새 저장 $saved개 · 실패 $failed개 · 공지 본문 확인 $fetched개 · ${(bytes / 1024 / 1024).toStringAsFixed(1)}MB\n파일당 50MB, 회차당 약 100MB·60초, 계정별 캐시 300MB. 남은 항목은 다음 수집 또는 상세 화면에서 이어받아요.',
  );
}

Future<void> reconcile(Store store) async {
  if (isDemoActive) return;
  final items = await store.items();
  final excluded = await store.excluded();
  final prefs = await SharedPreferences.getInstance();
  // The background isolate may have scheduled reminders since this isolate
  // last read preferences; a stale list would leave them uncancelled.
  await prefs.reload();
  final old = prefs.getStringList(PrefKey.scheduled) ?? [];
  final desired = <String>[];
  var iosFutureCount = 0;
  final android = notifications
      .resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin
      >();
  final desktop = Platform.isWindows && android == null;
  final permitted = desktop
      ? (prefs.getBool(PrefKey.desktopNotifications) ?? true)
      : Platform.isIOS
      ? (await notifications
                    .resolvePlatformSpecificImplementation<
                      IOSFlutterLocalNotificationsPlugin
                    >()
                    ?.checkPermissions())
                ?.isEnabled ??
            false
      : await android?.areNotificationsEnabled() ?? false;
  final now = DateTime.now().toUtc();
  final permissionState = permitted ? 'yes' : 'no';
  if (await store.meta(MetaKey.notificationPermission) != permissionState) {
    await store.log(
      'notification',
      permitted ? '알림 권한 허용' : '알림 권한 꺼짐',
      permitted ? '알림 발송·예약을 진행해요.' : '권한을 허용하기 전에는 알림을 표시하지 못해요.',
    );
    await store.setMeta(MetaKey.notificationPermission, permissionState);
  }
  final reminderLeads = await deadlineLeads(store);
  for (final item in items) {
    if ((item.attendanceRequired == false &&
            await store.meta(MetaKey.notifyNonAttendance) == 'no') ||
        !item.availableAt(now) ||
        excluded.contains(item.key) ||
        !item.openTask ||
        item.due == null ||
        !item.due!.isAfter(now)) {
      continue;
    }
    final elapsedLead = latestElapsedLead(reminderLeads, item.due!, now);
    for (final minutes in reminderLeads) {
      final token = deadlineToken(item.key, item.due!, minutes);
      final at = item.due!.subtract(Duration(minutes: minutes));
      // A passed trigger is still valid until the task is completed or expires.
      // Cancelling here also removes an already displayed Android notification.
      if (Platform.isIOS && at.isAfter(now)) {
        if (iosFutureCount >= 32) continue;
        iosFutureCount++;
      }
      desired.add(token);
      if (at.isAfter(now)) {
        if (desktop) continue;
        // iOS retains at most 64 pending notifications; reserve 24 class/midnight and seven daily notifications; keep the nearest 32.
        if (permitted) {
          final wasScheduled = await store.meta(token) == 'scheduled';
          await notifications.zonedSchedule(
            notificationId(token),
            '${item.kindLabel} 마감 ${leadLabel(minutes)}',
            '${courseLabel(item.course)} · ${item.title}',
            tz.TZDateTime.from(at, tz.UTC),
            noticeStyle,
            androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
            payload: item.key,
          );
          await store.setMeta(token, 'scheduled');
          if (!wasScheduled) {
            await store.log(
              'notification',
              '마감 알림 예약',
              '${courseLabel(item.course)} · ${item.title}\n예정: ${koreanTime(at)}',
            );
          }
        }
      } else if (minutes == elapsedLead &&
          permitted &&
          await store.meta(token) != 'sent' &&
          (await store.meta(token) != 'scheduled' || !old.contains(token))) {
        // Older versions discarded passed reservations from `scheduled` and
        // cancelled them. Recover those once; retained reservations must not
        // cause another notification on every collection.
        await notifications.show(
          notificationId(token),
          minutes == 1440
              ? '마감까지 하루 이내예요'
              : '${item.kindLabel} 마감 ${leadLabel(minutes)} 알림',
          '${courseLabel(item.course)} · ${item.title}',
          noticeStyle,
          payload: item.key,
        );
        await store.setMeta(token, 'sent');
        await store.log(
          'notification',
          '마감 임박 알림 발송 요청',
          '${courseLabel(item.course)} · ${item.title}',
        );
      }
    }
  }
  for (final token in old.where((t) => !desired.contains(t))) {
    await notifications.cancel(notificationId(token));
    await store.log(
      'notification',
      '마감 알림 예약 취소',
      '완료·마감 변경·제외 등의 이유로 기존 예약을 취소했어요.',
    );
  }
  await prefs.setStringList(PrefKey.scheduled, desired);
  if (permitted) {
    for (final event in await store.db.query('events', where: 'delivered=0')) {
      final data =
          jsonDecode(event['payload'] as String) as Map<String, dynamic>;
      if (data['kind'] == 'notice') {
        final notice = CampusNotice.fromJson(
          Map<String, dynamic>.from(data['notice']),
        );
        if ((await store.notices()).any((n) => n.id == notice.id)) {
          await notifications.show(
            notificationId(event['id'] as String),
            '새 공지가 등록됐어요',
            '${courseLabel(notice.course)} · ${notice.title}',
            noticeStyle,
            payload: 'NOTICE:${notice.id}',
          );
          await store.log(
            'notification',
            '새 공지 알림 발송 요청',
            '${courseLabel(notice.course)} · ${notice.title}',
          );
        }
        await store.db.update(
          'events',
          {'delivered': 1},
          where: 'id=?',
          whereArgs: [event['id']],
        );
        continue;
      }
      final changed = data['kind'] == 'change';
      final original = CampusItem.fromJson(
        Map<String, dynamic>.from(changed ? data['item'] : data),
      );
      final item = items.where((i) => i.key == original.key).firstOrNull;
      if (item == null ||
          !item.availableAt(now) ||
          excluded.contains(item.key)) {
        await store.db.update(
          'events',
          {'delivered': 1},
          where: 'id=?',
          whereArgs: [event['id']],
        );
        continue;
      }
      await notifications.show(
        notificationId(event['id'] as String),
        changed
            ? '${item.kindLabel} 정보가 변경됐어요'
            : item.isMaterial
            ? '새 자료가 등록됐어요'
            : '새 ${item.kindLabel}${const {'LD', 'LE'}.contains(item.type) ? '이' : '가'} 등록됐어요',
        changed
            ? '${courseLabel(item.course)} · ${item.title}\n${(data['detail'] as String).split('\n').first}'
            : '${courseLabel(item.course)} · ${item.title}',
        noticeStyle,
        payload: item.key,
      );
      await store.log(
        'notification',
        changed
            ? '변경 알림 발송 요청'
            : '새 ${item.isMaterial ? '자료' : item.kindLabel} 알림 발송 요청',
        changed
            ? '${courseLabel(item.course)} · ${item.title}\n${data['detail']}'
            : '${courseLabel(item.course)} · ${item.title}',
      );
      await store.db.update(
        'events',
        {'delivered': 1},
        where: 'id=?',
        whereArgs: [event['id']],
      );
    }
  }
  if (Platform.isIOS) await refreshIosFeatures(store);
  if (Platform.isAndroid) {
    try {
      await bridge.invokeNative(NativeMethod.refreshWidget);
    } on MissingPluginException {
      /* Worker completion refreshes native widgets. */
    }
  }
}

Future<void> excludeItem(
  CampusItem item,
  bool exclude, {
  bool undo = false,
}) async {
  await ensurePcEditable();
  final store = await Store.open();
  try {
    await store.setTaskExcluded(item.key, exclude, undo: undo);
    await store.log(
      'received',
      exclude ? '목록에서 숨기기' : '목록에 복구',
      '${courseLabel(item.course)} · ${item.title}',
    );
    if (exclude) {
      await notifications.cancel(notificationId('new:${item.key}'));
      if (item.due != null) {
        await notifications.cancel(
          notificationId('due:${item.key}:${item.due!.toIso8601String()}'),
        );
        await store.setMeta(
          'due:${item.key}:${item.due!.toIso8601String()}',
          '',
        );
      }
    }
    await reconcile(store);
  } finally {
    await store.db.close();
  }
}

Future<bool> markNotTask(CampusItem item, bool value) async {
  await ensurePcEditable();
  final store = await Store.open();
  try {
    await store.setMeta(MetaKey.notTask(item.key), value ? 'yes' : 'no');
    await store.log(
      'received',
      value ? '할 일 아님으로 변경' : '할 일로 복구',
      '${courseLabel(item.course)} · ${item.title}',
    );
    try {
      if (value) {
        await notifications.cancel(notificationId('new:${item.key}'));
        if (item.due != null) {
          final token = 'due:${item.key}:${item.due!.toIso8601String()}';
          await notifications.cancel(notificationId(token));
          await store.setMeta(token, '');
        }
      }
      await reconcile(store);
      return true;
    } catch (e) {
      await store.log(
        'notification',
        '분류 저장 완료 · 표시 반영 대기',
        withCause('분류는 저장했어요. 다음 수집에서 알림·위젯을 다시 반영해요.', e),
      );
      return false;
    }
  } finally {
    await store.db.close();
  }
}

enum SyncOutcome { completed, busy, noCredentials, accountChanged }

String diagnosticFailure(Object e) {
  if (e is HttpStatusError) return networkFailureMessage(e);
  if (e is CampusException) return e.message;
  if (e is PlatformException) return '기기 기능 오류 (${e.code})';
  if (e is SocketException) {
    return '네트워크 연결 오류 (${e.osError?.errorCode ?? '미확인'})';
  }
  if (e is HandshakeException) return 'HTTPS 연결을 확인하지 못했어요.';
  if (e is TimeoutException) return '요청 시간이 초과됐어요.';
  if (e is FormatException) return '응답 데이터 형식이 예상과 달라요.';
  return '처리 오류 (${e.runtimeType})';
}

/// A task whose detail failed to load keeps its previous record, marked
/// 'unknown' (still treated as open), instead of losing its detail.
List<CampusItem> keepDetailOnTaskWarnings(
  List<CampusItem> items,
  Map<String, CampusItem> old,
  Set<String> warnings,
) => items.map((i) {
  if (!warnings.contains(i.key) || old[i.key] == null) return i;
  return CampusItem.fromJson({...old[i.key]!.toJson(), 'status': 'unknown'});
}).toList();

/// When a course's material list or a material's detail failed to load,
/// keep the materials and attachments saved before, so nothing looks
/// removed or new on the next successful sync.
List<CampusItem> keepMaterialsOnResourceWarnings(
  List<CampusItem> items,
  Map<String, CampusItem> old,
  Set<String> warnings,
) {
  final result = [...items];
  final present = items.map((i) => i.key).toSet();
  for (final before in old.values) {
    if (before.isMaterial &&
        !present.contains(before.key) &&
        warnings.contains('LSCOURSE:${before.courseId}:${before.classNo}')) {
      result.add(before);
    }
  }
  return result.map((i) {
    final before = old[i.key];
    if (!warnings.contains(i.key) || before == null) return i;
    return CampusItem.fromJson({
      ...i.toJson(),
      'media': before.media.map((m) => m.toJson()).toList(),
      if (i.body.isEmpty) 'body': before.body,
      if (i.bodyHtml.isEmpty) 'bodyHtml': before.bodyHtml,
    });
  }).toList();
}

/// One activity-log entry per collection instead of one per item: a run
/// logged ~145 rows (101 items + 34 notices), so the 2,000-row log only kept
/// about 14 collections.
Future<void> logReceivedItems(Store store, List<CampusItem> items) async {
  if (items.isEmpty) return;
  String line(CampusItem item) =>
      '${item.kindLabel} · ${courseLabel(item.course)} · ${item.title} · ${item.done
          ? '완료'
          : item.status == 'pending'
          ? '미완료'
          : '확인 불가'} · 마감 ${item.due == null ? '미확인' : koreanTime(item.due!)}';
  final counts = <String, int>{};
  for (final item in items) {
    counts[item.kindLabel] = (counts[item.kindLabel] ?? 0) + 1;
  }
  await store.log(
    'received',
    '과제·콘텐츠 ${items.length}개 수집',
    [
      counts.entries.map((e) => '${e.key} ${e.value}').join(' · '),
      ...items.map(line),
    ].join('\n'),
  );
}

Future<SyncOutcome> synchronize({
  String source = '앱에서 확인',
  bool foregroundLogin = false,
  void Function(String)? onPhase,

  /// Lists, notices and alerts are saved; attachments and follow-up work
  /// continue. The app shows the new lists here instead of at the very end.
  Future<void> Function()? onListsReady,
}) async {
  // Demo builds (--dart-define=DEMO=true) carry synthetic data only; the
  // Android background worker must not try the school with demo credentials.
  if (demoMode) return SyncOutcome.completed;
  if (Platform.isWindows && await driveViewerConnected()) {
    // Read-only PC: refresh means re-reading the phone's Drive upload. The
    // school is never contacted from here.
    onPhase?.call('폰 자료 확인');
    try {
      await pullDriveSnapshot();
    } on DriveViewerException {
      // Saved as the status line; the last good data stays.
    }
    await onListsReady?.call();
    return SyncOutcome.completed;
  }
  final elapsed = Stopwatch()..start();
  final stages = <String>[];
  final details = <String, SyncTiming>{
    for (final label in ['과제·콘텐츠 수집', '이미지·첨부파일 수집']) label: SyncTiming(),
  };
  final stageMs = <String, int>{};
  var stageName = '저장소 열기·수집 잠금';
  var stageStart = 0;
  void markStage(String next) {
    final now = elapsed.elapsedMilliseconds;
    stageMs[stageName] = now - stageStart;
    stages.add('$stageName: ${now - stageStart} ms');
    stageName = next;
    stageStart = now;
  }

  final store = await Store.open();
  final locked = await store.acquire();
  if (!locked) {
    await store.log(
      'sync',
      '[$source] 수집 대기',
      '다른 수집이 진행 중이에요. 백그라운드 작업이면 재시도해요.',
    );
    await store.db.close();
    return SyncOutcome.busy;
  }
  var route = '연결 준비';
  var networkRetries = 0;
  var sessionMode = '학교 연결을 확인했어요.';
  late final CampusClient client;
  try {
    client = CampusClient(
      diagnostic: (line) {
        if (line.startsWith('API ')) route = line.substring(4);
        if (line.startsWith('Retry ')) networkRetries++;
        if (line == 'School session reused') {
          sessionMode = '기존 학교 세션을 재사용했어요. 재로그인하지 않았어요.';
        }
        if (line == 'School session newly connected') {
          sessionMode = '새 학교 세션으로 연결했어요.';
        }
      },
    );
  } catch (_) {
    try {
      await store.releaseLease();
    } finally {
      await store.db.close();
    }
    rethrow;
  }
  var phase = '계정 읽기';
  markStage(phase);
  SessionScope? scope;
  Timer? sessionWatch;
  final budget = Timer(const Duration(minutes: 7), client.close);
  try {
    scope = await SessionScope.capture(store);
    sessionWatch = scope.watch(client.close);
    await loadCourseAliases();
    final id = await credentials.read(key: 'id');
    final pw = await credentials.read(key: 'pw');
    if (id == null || pw == null) {
      await store.log('sync', '[$source] 수집 건너뜀', '저장된 계정이 없어요.');
      return SyncOutcome.noCredentials;
    }
    await store.log(
      'sync',
      '[$source] 수집 시작',
      foregroundLogin
          ? '사용자가 앱을 열어 재연결 대기·세션 탐색을 건너뛰고 새로 로그인해요.'
          : '저장된 학교 세션을 먼저 확인하고 과제·콘텐츠·공지를 수집해요.',
    );
    phase = '학교 세션 연결';
    markStage(phase);
    onPhase?.call(phase);
    await client.connectSchool(id, pw, reconnectNow: foregroundLogin);
    await store.log('sync', '[$source] 학교 연결 확인', '$sessionMode 과제·콘텐츠를 수집해요.');
    phase = '과제·콘텐츠 수집';
    markStage(phase);
    onPhase?.call(phase);
    client.apiTiming = details[phase];
    // Automatic collections reuse unchanged material/content attachment
    // lists for up to 6 hours (one request per row otherwise); a manual
    // collection always refetches everything.
    var items = await client.fetchItems(
      previous: {for (final i in await store.items()) i.key: i},
      reuseDetailsFor: source == '수동 확인'
          ? Duration.zero
          : const Duration(hours: 6),
      onCourses: (courses) async {
        if (await credentials.read(key: 'id') != id) {
          throw CampusException('계정이 변경되어 과목 저장을 중지했어요.');
        }
        await scope!.verify();
        await store.setMeta(MetaKey.courses, jsonEncode(courses));
      },
    );
    if (await credentials.read(key: 'id') != id) {
      return SyncOutcome.accountChanged;
    }
    if (client.taskWarnings.isNotEmpty) {
      items = keepDetailOnTaskWarnings(items, {
        for (final i in await store.items()) i.key: i,
      }, client.taskWarnings.keys.toSet());
      for (final entry in client.taskWarnings.entries) {
        await store.log(
          'sync',
          '과제 상세 일부 확인 불가',
          '${entry.key} · ${entry.value}\n다른 항목 수집을 계속해요. 해당 과제는 제출 상태 미확인으로 표시하며 기존 상세가 있으면 유지해요.',
        );
      }
    }
    if (client.resourceWarnings.isNotEmpty) {
      items = keepMaterialsOnResourceWarnings(items, {
        for (final i in await store.items()) i.key: i,
      }, client.resourceWarnings);
      await store.log(
        'sync',
        '일부 자료 목록 확인 대기',
        '${client.resourceWarnings.length}개 자료 상세·첨부 조회 실패. 기존 첨부 목록은 유지해요.',
      );
    }
    await store.setMeta(
      MetaKey.taskDetailWarnings,
      '${client.taskWarnings.length}',
    );
    client.apiTiming = null;
    phase = '목록 저장';
    markStage(phase);
    onPhase?.call(phase);
    await scope.verify();
    await store.replace(items);
    if (client.taskWarnings.isNotEmpty) {
      await store.setMeta(
        MetaKey.lastError,
        '일부 과제 ${client.taskWarnings.length}개의 상세·제출 상태를 확인하지 못했어요. 다른 항목은 수집했고 활동 로그에 응답 형식을 남겼어요.',
      );
    }
    // Re-check before each write group so a logout that lands mid-sync is not
    // followed by the previous account's data being written back.
    await scope.verify();
    await store.setMeta(MetaKey.courses, jsonEncode(client.courseList));
    await scope.verify();
    await logReceivedItems(store, items);
    try {
      markStage('공지 수집·저장');
      onPhase?.call('공지 수집');
      final notices = await client.fetchNotices();
      if (await credentials.read(key: 'id') != id) {
        return SyncOutcome.accountChanged;
      }
      await scope.verify();
      await store.replaceNotices(notices);
      await store.setMeta(MetaKey.noticeError, '');
      await scope.verify();
      if (notices.isNotEmpty) {
        await store.log(
          'received',
          '공지 ${notices.length}개 수집',
          notices
              .map((n) => '${courseLabel(n.course)} · ${n.title}')
              .join('\n'),
        );
      }
      await store.log(
        'sync',
        '[$source] 목록 수집 완료',
        '과제 ${items.where((i) => i.type == 'LR').length}개 · 콘텐츠 ${items.where((i) => i.type == 'LV').length}개 · 자료실 ${items.where((i) => i.type == 'LS').length}개 · 기타 ${items.where((i) => i.isOther).length}개 · 공지 ${notices.length}개',
      );
    } catch (e) {
      final message = '${diagnosticFailure(e)} 마지막 공지 목록을 유지해요.';
      await store.setMeta(MetaKey.noticeError, message);
      await store.log('sync', '공지 수집 실패', '$message\n과제·콘텐츠 결과는 저장했어요.');
    }
    await scope.verify();
    phase = '알림 처리';
    markStage(phase);
    onPhase?.call(phase);
    await reconcile(store);
    await scope.verify();
    try {
      await store.pruneStaleMeta(DateTime.now());
    } catch (_) {
      // Housekeeping only; never fail a sync over it.
    }
    try {
      await onListsReady?.call();
    } catch (_) {
      // Showing lists early is cosmetic; the final reload still runs.
    }
    if (Platform.isAndroid || Platform.isIOS) {
      markStage('이미지·첨부파일 수집');
      onPhase?.call('이미지·첨부파일 수집');
      try {
        await collectCampusMedia(
          store,
          client,
          id,
          timing: details['이미지·첨부파일 수집'],
        );
      } catch (e) {
        await store.log(
          'sync',
          '이미지·첨부 수집 대기',
          withCause('과제·공지 목록과 알림은 저장했어요. 상세 화면에서 다시 시도할 수 있어요.', e),
        );
      }
    }
    await store.log(
      'sync',
      '[$source] 처리 완료',
      '수집 결과 저장과 알림 처리를 마쳤습니다. 통신 재시도 $networkRetries회.',
    );
    // Follow-up work used to run under the previous "attachments" label.
    phase = '마무리(AI·내보내기)';
    onPhase?.call(phase);
    markStage('AI 후속 처리');
    try {
      await aiAfterSync(store);
    } catch (e) {
      await store.log(
        'ai',
        'AI 작업 예약 대기',
        withCause('다음 수집 또는 검토함에서 다시 시도해요.', e),
      );
    }
    markStage('Drive 자료 준비');
    try {
      await prepareDriveSnapshot();
    } catch (e) {
      await logDrivePrepareFailure(e);
    }
    return SyncOutcome.completed;
  } catch (e) {
    await store.log(
      'sync',
      '[$source] 수집 또는 알림 처리 실패',
      '$phase 단계: ${diagnosticFailure(e)}\n실패 종류: ${e.runtimeType}\n마지막 요청: $route · 통신 재시도 $networkRetries회',
    );
    await store.setMeta(MetaKey.lastError, '$phase: ${diagnosticFailure(e)}');
    rethrow;
  } finally {
    if (Platform.isAndroid) {
      markStage('업데이트 확인');
      try {
        // The manifest download took up to 5 s per collection (build 80);
        // automatic collections check at most every 3 hours.
        final prefs = await SharedPreferences.getInstance();
        final last = DateTime.tryParse(
          prefs.getString(PrefKey.updateCheckedAt) ?? '',
        );
        if (source == '수동 확인' ||
            last == null ||
            DateTime.now().toUtc().difference(last) >
                const Duration(hours: 3)) {
          await checkForUpdates(store);
        }
      } catch (_) {
        /* Update checks never fail collection. */
      }
    }
    budget.cancel();
    sessionWatch?.cancel();
    client.close();
    markStage('수집 잠금 해제');
    try {
      await store.releaseLease();
    } finally {
      markStage('');
      try {
        // One entry: stage totals followed by each measured stage's detail.
        final lines = ['전체: $stageStart ms', ...stages];
        for (final entry in details.entries) {
          final duration = stageMs[entry.key];
          if (duration == null) continue;
          lines
            ..add('')
            ..add('[${entry.key}]')
            ..addAll(entry.value.describe(duration));
        }
        await store.log('sync', '[$source] 수집 소요 시간', lines.join('\n'));
      } catch (_) {
        // Timing diagnostics must not change the collection result.
      } finally {
        await store.db.close();
      }
    }
  }
}

Future<void> logNotification(String title, String detail) async {
  final store = await Store.open();
  try {
    await store.log('notification', title, detail);
  } finally {
    await store.db.close();
  }
}

@pragma('vm:entry-point')
void backgroundDispatcher() {
  Workmanager().executeTask(backgroundTaskCallback);
}

@pragma('vm:entry-point')
Future<bool> backgroundTaskCallback(
  String task,
  Map<String, dynamic>? data,
) async {
  if (await initDemoState()) return true;
    await retireSessionExploration();
    if (task == sessionLifetimeTask) {
      // Reconcile normal collection at quiet-window boundaries, even after restart.
      await registerBackground(configureSessionProbe: false);
      await runSessionLifetimeProbe();
      return true;
    }
    if (task != aiWorkTask && !await automaticSchoolConnectionEnabled()) {
      return true;
    }
    if (Platform.isIOS) setIosAiActive(false);
    if (task == aiWorkTask) {
      await processAiWork();
      if (data?['summaryWarmup'] == true) {
        final p = await SharedPreferences.getInstance();
        await p.reload();
        await scheduleSummaryWarmup(
          p.getInt(PrefKey.aiDailyHour) ?? 18,
          p.getInt(PrefKey.aiDailyMinute) ?? 0,
          p.getBool(PrefKey.aiDailyEnabled) ?? false,
        );
      }
      return true;
    }
    Store? trace;
    try {
      trace = await Store.open();
      await trace.setMeta(
        MetaKey.workerStarted,
        DateTime.now().toUtc().toIso8601String(),
      );
      await trace.log('sync', '백그라운드 작업 진입', '운영체제가 자동 수집 코드를 실행했어요.');
      await initNotifications().timeout(const Duration(seconds: 20));
      // Reaching synchronize means notifications initialised; its own
      // "수집 시작" entry follows, so no separate breadcrumb here.
      final outcome = await synchronize(
        source: data?['source'] == 'trial' ? '백그라운드 시험' : '백그라운드 자동',
      );
      if (outcome == SyncOutcome.busy) {
        await trace.log('sync', '백그라운드 재시도 요청', '다른 수집과 겹쳐 운영체제에 재시도를 요청했어요.');
        return false;
      }
      if (outcome == SyncOutcome.completed) {
        await trace.setMeta(
          MetaKey.workerSource,
          data?['source'] == 'trial' ? '시험' : '정기 자동',
        );
        await trace.setMeta(
          MetaKey.workerSuccess,
          DateTime.now().toUtc().toIso8601String(),
        );
      }
      return true;
    } catch (e) {
      final retry = e is! CampusLoginRejected && e is! CampusReconnectDeferred;
      if (trace != null) {
        await trace.log(
          'sync',
          '백그라운드 작업 실패',
          e is CampusReconnectDeferred
              ? '재연결 대기 설정에 따라 이번 자동 로그인을 건너뛰었어요. 다음 정기 수집에서 다시 확인해요.'
              : !retry
              ? '학교 로그인이 거절됐어요. 앱에서 계정을 확인해 주세요. 즉시 자동 재시도하지 않아요.'
              : e is PlatformException
              ? '기기 기능 오류: ${e.code}. 운영체제에 재시도를 요청해요.'
              : '실패 종류: ${e.runtimeType}. 운영체제에 재시도를 요청해요.',
        );
      }
      return !retry;
    } finally {
      await trace?.db.close();
    }
}

Future<void> registerBackground({
  bool updateInterval = false,
  bool configureSessionProbe = true,
}) async {
  if (isDemoActive || Platform.isWindows) return;
  if (configureSessionProbe) await registerSessionLifetimeProbe();
  if (!await automaticSchoolConnectionEnabled()) {
    await Workmanager().cancelByUniqueName(periodicTask);
    await Workmanager().cancelByUniqueName('campus-radar-probe');
    return;
  }
  final minutes = await schoolCollectionMinutes();
  await Workmanager().registerPeriodicTask(
    periodicTask,
    periodicTask,
    frequency: Duration(minutes: minutes),
    existingWorkPolicy: updateInterval
        ? ExistingPeriodicWorkPolicy.update
        : ExistingPeriodicWorkPolicy.keep,
    constraints: Constraints(networkType: NetworkType.connected),
  );
  final store = await Store.open();
  try {
    await store.log(
      'sync',
      '자동 수집 예약 확인',
      '$minutes분 주기 작업을 ${updateInterval ? '변경' : '유지'}해요. 실제 실행 시각은 운영체제와 네트워크 조건에 따라 지연될 수 있어요.',
    );
  } finally {
    await store.db.close();
  }
}

Future<void> setAutomaticSchoolConnection(bool enabled) async {
  // Persist the guard first: a stale/retried OS job must not start a new login.
  await saveAutomaticSchoolConnection(enabled);
  await registerBackground();
}

Future<void> setExclusiveSessionLifetimeTest(bool enabled) async {
  // The persisted mask is consulted by startup, resume, AI source fetching and
  // workers before scheduling changes, including after process recreation.
  Object? failure;
  try {
    await setSessionLifetimeProbe(enabled);
  } catch (error) {
    failure = error;
  }
  // Attempt regular-job restoration/cancellation even if the probe scheduler
  // failed. The persisted flag remains the source of truth for stale workers.
  try {
    await registerBackground(configureSessionProbe: false);
  } catch (error) {
    failure ??= error;
  }
  if (failure != null) throw failure;
}

Future<void> scheduleBackgroundTrial() async {
  if (isDemoActive) return;
  await Workmanager().registerOneOffTask(
    'campus-radar-probe',
    periodicTask,
    initialDelay: const Duration(seconds: 30),
    existingWorkPolicy: ExistingWorkPolicy.replace,
    constraints: Constraints(networkType: NetworkType.connected),
    inputData: {'source': 'trial'},
  );
  final store = await Store.open();
  try {
    await store.log(
      'sync',
      '백그라운드 시험 예약',
      '30초 이후 실행 가능한 시험을 예약했어요. 홈 화면으로 나가 기다려 주세요. 운영체제에 따라 지연될 수 있어요.',
    );
  } finally {
    await store.db.close();
  }
}

/// Diagnostics must never prevent startup or the operation being diagnosed.
List<String> batteryWarnings(Map<Object?, Object?> status) {
  final warnings = <String>[];
  if (status['batteryExempt'] == false) {
    warnings.add('배터리 최적화 예외가 아니에요. 앱 배터리를 제한 없음으로 설정해 주세요.');
  }
  if (status['backgroundRestricted'] == true) {
    warnings.add('앱의 백그라운드 실행이 제한되어 있어요.');
  }
  if ([
    'batteryExempt',
    'backgroundRestricted',
  ].any((key) => status[key] is! bool)) {
    warnings.add('일부 배터리 설정 상태를 확인하지 못했어요. 설정에서 직접 확인해 주세요.');
  }
  return warnings;
}

Future<void> recordInstalledVersion() async {
  if (isDemoActive) return;
  if (!Platform.isAndroid && !Platform.isIOS && !Platform.isWindows) return;
  Store? store;
  try {
    final info = await bridge.invokeNativeMap<String, dynamic>(
      NativeMethod.versionInfo,
    );
    if (info == null) {
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    final current = "${info['name']} (${info['code']})";
    final previous = prefs.getString(PrefKey.observedInstalledVersion);
    store = await Store.open();
    if (previous == current &&
        await store.meta(MetaKey.installedVersionLogged) == current) {
      return;
    }
    await store.log(
      'system',
      previous == null
          ? '설치 버전 최초 기록'
          : previous == current
          ? '업데이트 후 저장소 확인'
          : '앱 버전 변경 확인',
      previous == null
          ? '현재 $current · 이전 버전 기록 없음'
          : previous == current
          ? '현재 $current · 저장소 읽기 및 버전 기록 저장 확인'
          : '$previous → $current · 변경된 버전으로 실행됨',
    );
    if (previous != null && previous != current) {
      final oldCode = int.tryParse(
        RegExp(r'\((\d+)\)$').firstMatch(previous)?.group(1) ?? '',
      );
      if (oldCode != null &&
          info['code'] is num &&
          oldCode < (info['code'] as num).toInt()) {
        await prefs.setInt(PrefKey.updateHistoryPreviousBuild, oldCode);
      }
    }
    await store.setMeta(MetaKey.installedVersionLogged, current);
    await prefs.setString(PrefKey.observedInstalledVersion, current);
  } catch (_) {
  } finally {
    await store?.db.close();
  }
}

/// Notice bodies are re-read every 6 hours while a notice is new (edits and
/// attachments usually follow soon after posting) and every 3 days once it is
/// older than a week. Build 79 re-read 12 bodies (3.8 s) per collection.
bool noticeBodyDue(CampusNotice n, DateTime? checkedAt, DateTime now) {
  if (!n.bodyFetched || n.bodyHtml.isEmpty || checkedAt == null) return true;
  final recent =
      n.published == null ||
      now.difference(n.published!) <= const Duration(days: 7);
  return now.difference(checkedAt) >
      (recent ? const Duration(hours: 6) : const Duration(days: 3));
}

import 'dart:convert';
import 'dart:io';
import 'package:archive/archive.dart';
import 'package:html/parser.dart' as html;
import 'package:campus_radar/campus/campus_media.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';

String? directAcademicUrl(CampusMedia m) {
  final u = Uri.tryParse(m.url);
  return m.form.isEmpty &&
          u != null &&
          allowedMediaUri(u) &&
          !u.hasQuery &&
          !u.hasFragment
      ? u.toString()
      : null;
}

String attachmentAccessLabel(String code) => switch (code) {
  'directVerified' => '세션 없는 직접 다운로드 확인',
  'loginRequired' => '로그인 필요 응답',
  'postRequired' => '앱의 파일 요청 필요 · 단순 링크 아님',
  'unavailable' => '현재 파일 접근 실패',
  _ => '아직 확인하지 않음',
};

class AttachmentText {
  final String text, note;
  final bool partial;
  const AttachmentText(this.text, this.note, {this.partial = false});
}

/// Local cached bytes only; no network and no school login.
Future<AttachmentText> extractAttachmentText(File file, String name) async {
  if (await file.length() > 10 * 1024 * 1024) {
    return const AttachmentText('', '텍스트 추출은 파일당 10MB까지 지원');
  }
  final ext = name.split('.').last.toLowerCase();
  if (ext == 'pdf') {
    if (!Platform.isAndroid) {
      return const AttachmentText('', '이 기기에서는 PDF 텍스트 추출 미지원');
    }
    final j = await bridge
        .invokeNativeMap<String, dynamic>(NativeMethod.extractAcademicText, {
          'path': file.path,
        })
        .timeout(const Duration(seconds: 25));
    return AttachmentText(
      '${j?['text'] ?? ''}',
      '${j?['note'] ?? 'PDF 텍스트 추출'}',
      partial: j?['partial'] == true,
    );
  }
  return extractAttachmentBytes(await file.readAsBytes(), ext);
}

AttachmentText extractAttachmentBytes(List<int> bytes, String ext) {
  const limit = 200000;
  if (bytes.length > 10 * 1024 * 1024) {
    return const AttachmentText('', '파일 크기 제한 초과');
  }
  String text;
  try {
    if ({'txt', 'md', 'csv', 'json'}.contains(ext)) {
      text = utf8.decode(bytes).replaceFirst('\ufeff', '');
    } else if ({'hwpx', 'pptx', 'docx'}.contains(ext)) {
      final archive = ZipDecoder().decodeBytes(bytes);
      if (archive.length > 2000) {
        return const AttachmentText('', '문서 내부 파일 수 제한 초과');
      }
      final entries =
          archive.files
              .where(
                (e) =>
                    e.isFile &&
                    (ext == 'hwpx' &&
                            RegExp(
                              r'^Contents/section\d+\.xml$',
                            ).hasMatch(e.name) ||
                        ext == 'pptx' &&
                            RegExp(
                              r'^ppt/slides/slide\d+\.xml$',
                            ).hasMatch(e.name) ||
                        ext == 'docx' && e.name == 'word/document.xml'),
              )
              .toList()
            ..sort((a, b) {
              int n(String s) =>
                  int.tryParse(RegExp(r'\d+').firstMatch(s)?.group(0) ?? '0') ??
                  0;
              return n(a.name).compareTo(n(b.name));
            });
      if (entries.isEmpty) return const AttachmentText('', '읽을 수 있는 문서 본문 없음');
      if (entries.isEmpty) return const AttachmentText('', '읽을 수 있는 문서 본문 없음');
      var total = 0;
      final out = StringBuffer();
      for (final f in entries) {
        total += f.size;
        if (total > 4 * 1024 * 1024 || f.size > 1024 * 1024) {
          return AttachmentText(
            out.toString(),
            '문서 구조 크기 제한으로 일부만 추출',
            partial: true,
          );
        }
        final output = _LimitedXmlOutput();
        f.writeContent(output);
        final xml = utf8.decode(output.getBytes());
        final doc = html.parse(xml);
        final parts = doc
            .querySelectorAll('*')
            .where((e) => (e.localName ?? '').split(':').last == 't')
            .map((e) => e.text);
        out.writeln('--- ${f.name} ---');
        out.writeln(parts.join('\n'));
        if (out.length > limit) {
          return AttachmentText(
            out.toString().substring(0, limit),
            '최대 20만 자까지 추출 · 표/그림/배치 제외',
            partial: true,
          );
        }
      }
      text = out.toString();
    } else {
      return const AttachmentText('', '이 형식은 원본으로 확인 필요 · 텍스트 변환 미지원');
    }
  } catch (_) {
    return const AttachmentText('', '텍스트를 추출하지 못함 · 인코딩/문서 형식 확인 필요');
  }
  if (text.trim().isEmpty) {
    return const AttachmentText('', '읽을 수 있는 텍스트 없음 · 스캔/그림 원본 확인 필요');
  }
  return AttachmentText(
    text.length > limit ? text.substring(0, limit) : text,
    '텍스트만 추출 · 표/그림/배치 제외',
    partial: text.length > limit,
  );
}

Future<Map<String, dynamic>> probeAnonymousAttachment(CampusMedia media) async {
  final at = DateTime.now().toUtc().toIso8601String();
  Map<String, dynamic> result(String status, {int? http, String? mime}) => {
    'status': status,
    'checkedAt': at,
    if (http != null) 'http': http,
    if (mime != null) 'mime': mime,
    'scope': 'device-network-only; LLM reader not verified',
  };
  if (media.form.isNotEmpty) return result('postRequired');
  final address = directAcademicUrl(media);
  if (address == null) return result('unknown');
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
  try {
    final request = await client
        .getUrl(Uri.parse(address))
        .timeout(const Duration(seconds: 8));
    request.followRedirects = false;
    request.headers.set('Range', 'bytes=0-255');
    // This client has no CookieJar. Never add account cookies, auth or Referer.
    final response = await request.close().timeout(const Duration(seconds: 8));
    final mime = response.headers.contentType?.mimeType;
    if ([301, 302, 303, 307, 308, 401, 403].contains(response.statusCode)) {
      final location = Uri.tryParse(response.headers.value('location') ?? '');
      await response.drain<void>();
      return result(
        [401, 403].contains(response.statusCode) ||
                location?.path.toLowerCase().contains('login') == true
            ? 'loginRequired'
            : 'unknown',
        http: response.statusCode,
        mime: mime,
      );
    }
    if (![200, 206].contains(response.statusCode)) {
      await response.drain<void>();
      return result('unavailable', http: response.statusCode, mime: mime);
    }
    final bytes = <int>[];
    await for (final chunk in response.timeout(const Duration(seconds: 8))) {
      bytes.addAll(chunk.take(256 - bytes.length));
      if (bytes.length >= 256) break;
    }
    final known = isAttachmentBytes(bytes, media.name, mime);
    return result(
      known ? 'directVerified' : 'unknown',
      http: response.statusCode,
      mime: mime,
    );
  } catch (_) {
    return result('unknown');
  } finally {
    client.close(force: true);
  }
}

bool isAttachmentBytes(List<int> bytes, String name, String? mime) {
  if (bytes.isEmpty || mime == 'text/html' || mime == 'application/json') {
    return false;
  }
  final hex = bytes
      .take(8)
      .map((b) => b.toRadixString(16).padLeft(2, '0'))
      .join();
  final ext = name.split('.').last.toLowerCase();
  return switch (ext) {
    'pdf' => hex.startsWith('25504446'),
    'hwpx' || 'pptx' || 'docx' || 'xlsx' || 'zip' => hex.startsWith('504b0304'),
    'hwp' => hex.startsWith('d0cf11e0a1b11ae1'),
    'png' => hex.startsWith('89504e47'),
    'jpg' || 'jpeg' => hex.startsWith('ffd8ff'),
    'txt' || 'md' || 'csv' => mime?.startsWith('text/') == true,
    _ => false,
  };
}

class _LimitedXmlOutput extends OutputMemoryStream {
  void check(int count) {
    if (length + count > 1024 * 1024) {
      throw const FormatException('XML output limit');
    }
  }

  @override
  void writeByte(int value) {
    check(1);
    super.writeByte(value);
  }

  @override
  void writeBytes(List<int> bytes, {int? length}) {
    check(length ?? bytes.length);
    super.writeBytes(bytes, length: length);
  }

  @override
  void writeStream(InputStream stream) {
    check(stream.length);
    super.writeStream(stream);
  }
}

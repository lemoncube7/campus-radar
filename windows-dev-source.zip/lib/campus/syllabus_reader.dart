import 'package:flutter/material.dart';
import 'package:campus_radar/campus/syllabus_loader.dart';

class SyllabusReader extends StatelessWidget {
  final String course, text;
  final dynamic tables;
  const SyllabusReader({
    super.key,
    required this.course,
    required this.text,
    this.tables,
  });
  @override
  Widget build(BuildContext context) {
    final structured = parseSyllabusTables(tables);
    return Scaffold(
      appBar: AppBar(title: Text('$course 강의계획서')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          if (structured.isEmpty) ...[
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  '텍스트 저장본이에요. 원본의 표 구조를 보려면 과목 화면에서 다시 불러오거나 원문 보기를 사용해 주세요.',
                ),
              ),
            ),
            SelectableText(
              text.replaceAll(r'\n', '\n'),
              style: Theme.of(
                context,
              ).textTheme.bodyLarge?.copyWith(height: 1.7),
            ),
          ] else ...[
            const Text('원본의 행·열 배치를 읽기용으로 정리했어요. 병합 셀·글꼴 등은 원문과 다를 수 있어요.'),
            const SizedBox(height: 16),
            for (var i = 0; i < structured.length; i++) ...[
              Text(
                '구역 ${i + 1}',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 8),
              LayoutBuilder(
                builder: (context, constraints) {
                  final rows = structured[i];
                  final count = rows.fold<int>(
                    0,
                    (n, r) => n > r.length ? n : r.length,
                  );
                  final width = count <= 2
                      ? constraints.maxWidth
                      : (count * 150.0).clamp(constraints.maxWidth, 3000.0);
                  return SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: SizedBox(
                      width: width,
                      child: Table(
                        border: TableBorder.all(
                          color: Theme.of(context).colorScheme.outlineVariant,
                        ),
                        defaultVerticalAlignment:
                            TableCellVerticalAlignment.top,
                        children: [
                          for (final row in rows)
                            TableRow(
                              children: [
                                for (var c = 0; c < count; c++)
                                  Container(
                                    color: c == 0
                                        ? Theme.of(
                                            context,
                                          ).colorScheme.surfaceContainerHighest
                                        : null,
                                    padding: const EdgeInsets.all(10),
                                    child: Text(
                                      c < row.length ? row[c] : '',
                                      style: TextStyle(
                                        height: 1.5,
                                        fontWeight: c == 0
                                            ? FontWeight.w600
                                            : FontWeight.normal,
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                        ],
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 24),
            ],
            ExpansionTile(
              title: const Text('표 밖의 내용·전체 텍스트'),
              children: [
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: SelectableText(
                    text,
                    style: const TextStyle(height: 1.7),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

import 'dart:convert';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';

typedef LinkedPlanReader =
    Future<Map<String, dynamic>?> Function(String url, String course);

bool isAllowedSyllabusUrl(String value) {
  final uri = Uri.tryParse(value);
  return uri != null &&
      uri.scheme == 'https' &&
      {'cnuit.cnu.ac.kr', 'tlsn.cnu.ac.kr'}.contains(uri.host) &&
      uri.userInfo.isEmpty;
}

/// Shared native fetch policy for the course page and timetable builder.
/// Account/session verification and persistence remain with each operation.
Future<String> loadLinkedSyllabus(
  String url,
  String course, {
  LinkedPlanReader? reader,
  void Function(List<List<List<String>>>)? onTables,
}) async {
  if (!isAllowedSyllabusUrl(url)) {
    throw CampusException('계획서 바로가기 주소를 확인하지 못했어요.');
  }
  final fetched =
      await (reader != null
              ? reader(url, course)
              : bridge.invokeNativeMap<String, dynamic>(
                  NativeMethod.fetchLinkedPlan,
                  {'url': url, 'course': course},
                ))
          .timeout(const Duration(seconds: 75));
  final text = fetched?['text'] as String?;
  if (text == null || text.trim().isEmpty) {
    throw CampusException('실제 계획서 본문을 가져오지 못했어요.');
  }
  onTables?.call(parseSyllabusTables(fetched?['structure']));
  return text;
}

List<List<List<String>>> parseSyllabusTables(dynamic raw) {
  try {
    final decoded = raw is String ? jsonDecode(raw) : raw;
    if (decoded is! List || decoded.length > 50) return [];
    var total = 0;
    final tables = <List<List<String>>>[];
    for (final table in decoded) {
      if (table is! List || table.length > 100) return [];
      final rows = <List<String>>[];
      for (final row in table) {
        if (row is! List ||
            row.length > 20 ||
            row.any((c) => c is! String || c.length > 6000)) {
          return [];
        }
        final cells = row.cast<String>();
        total += cells.fold<int>(0, (n, c) => n + c.length);
        if (total > 120000) return [];
        if (cells.any((c) => c.trim().isNotEmpty)) rows.add(cells);
      }
      if (rows.isNotEmpty) tables.add(rows);
    }
    return tables;
  } catch (_) {
    return [];
  }
}

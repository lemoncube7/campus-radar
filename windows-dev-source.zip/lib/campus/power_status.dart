import 'package:campus_radar/core/storage_keys.dart';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/campus/services.dart';

/// Android battery-optimisation / background-restriction warnings shown on
/// the home screen. Moved out of the dashboard state; behaviour unchanged.
class PowerStatus extends ChangeNotifier {
  List<String> warnings = [];
  bool _checking = false;

  Future<void> check() async {
    if (!Platform.isAndroid || _checking) return;
    _checking = true;
    try {
      final status = await bridge
          .invokeNativeMap<String, dynamic>(NativeMethod.batteryStatus)
          .timeout(const Duration(seconds: 5));
      warnings = batteryWarnings(status ?? {});
      notifyListeners();
      final fingerprint = jsonEncode({
        'batteryExempt': status?['batteryExempt'],
        'backgroundRestricted': status?['backgroundRestricted'],
      });
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getString(PrefKey.batteryStatusFingerprint) != fingerprint) {
        await systemLog(
          '배터리 설정 상태 변경',
          warnings.isEmpty ? '배터리 최적화 예외 · 백그라운드 제한 없음' : warnings.join('\n'),
        );
        await prefs.setString(PrefKey.batteryStatusFingerprint, fingerprint);
      }
    } catch (_) {
      warnings = ['배터리 설정을 확인하지 못했어요. 다시 확인해 주세요.'];
      notifyListeners();
    } finally {
      _checking = false;
    }
  }
}

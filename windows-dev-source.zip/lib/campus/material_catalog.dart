import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_media.dart';
import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:campus_radar/campus/learning_resources.dart';

String cloudId(String value) => sha256.convert(utf8.encode(value)).toString();

class StudyMaterial {
  final String id, sourceId, sourceType, title, course, body, externalUrl;
  final CampusMedia? media;
  const StudyMaterial({
    required this.id,
    required this.sourceId,
    required this.sourceType,
    required this.title,
    required this.course,
    this.body = '',
    this.externalUrl = '',
    this.media,
  });
  String get name =>
      media?.name ?? (externalUrl.isNotEmpty ? '외부 링크' : '본문.txt');
  Map<String, dynamic> toCloudJson() => {
    'id': id,
    'sourceId': sourceId,
    'sourceType': sourceType,
    'alias': courseLabel(course),
    'title': title.length > 600 ? title.substring(0, 600) : title,
    'course': course.length > 160 ? course.substring(0, 160) : course,
    'name': name.length > 300 ? name.substring(0, 300) : name,
    'size': media?.size,
    if (externalUrl.isNotEmpty)
      'externalUrl': safeExternalLink(externalUrl, cloud: true),
  };
}

Future<List<StudyMaterial>> studyMaterials(Store store, {DateTime? now}) async {
  final rows = <StudyMaterial>[];
  final hidden = await store.excluded(includeNotTasks: false);
  final at = now ?? DateTime.now();
  void add(
    String key,
    String type,
    String title,
    String course,
    String body,
    List<CampusMedia> media,
    String link,
  ) {
    final source = cloudId(key);
    if (body.trim().isNotEmpty) {
      rows.add(
        StudyMaterial(
          id: cloudId('$key:body'),
          sourceId: source,
          sourceType: type,
          title: title,
          course: course,
          body: body,
        ),
      );
    }
    for (final m in media) {
      rows.add(
        StudyMaterial(
          id: cloudId('$key:${m.identity}'),
          sourceId: source,
          sourceType: type,
          title: title,
          course: course,
          media: m,
        ),
      );
    }
    if (link.isNotEmpty) {
      rows.add(
        StudyMaterial(
          id: cloudId('$key:link'),
          sourceId: source,
          sourceType: type,
          title: title,
          course: course,
          externalUrl: link,
        ),
      );
    }
  }

  for (final i in await store.items()) {
    if (!const {'LR', 'LV', 'LS'}.contains(i.type) ||
        !i.availableAt(at) ||
        hidden.contains(i.key)) {
      continue;
    }
    add(i.key, i.type, i.title, i.course, i.body, i.media, i.externalUrl);
  }
  for (final n in await store.notices()) {
    add('NT:${n.id}', 'NT', n.title, n.course, n.body, n.media, '');
  }
  final seen = <String>{};
  return rows.where((r) => seen.add(r.id)).toList();
}

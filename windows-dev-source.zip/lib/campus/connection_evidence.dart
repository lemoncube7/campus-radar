import 'package:campus_radar/session/session_lifetime.dart';

enum ConnectionEvidence { recent, stale, lost, unknown }

ConnectionEvidence connectionEvidence(SessionLifetime? value, DateTime now) {
  if (value == null || value.session.isEmpty) return ConnectionEvidence.unknown;
  if (value.lost) return ConnectionEvidence.lost;
  final at = value.lastValidatedAt;
  if (at == null || at > now.toUtc().millisecondsSinceEpoch) {
    return ConnectionEvidence.unknown;
  }
  return now.toUtc().millisecondsSinceEpoch - at <= 15 * 60000
      ? ConnectionEvidence.recent
      : ConnectionEvidence.stale;
}

import 'package:campus_radar/core/storage_keys.dart';
import 'dart:convert';
import 'package:campus_radar/core/app_storage.dart';

List<int> parseDeadlineLeads(String? raw) {
  if (raw == null) return [1440];
  try {
    final list = jsonDecode(raw) as List;
    final sorted =
        list
            .whereType<int>()
            .where((m) => m >= 1 && m <= 43200)
            .toSet()
            .toList()
          ..sort((a, b) => b.compareTo(a));
    return sorted.take(6).toList();
  } catch (_) {
    return [1440];
  }
}

Future<List<int>> deadlineLeads(Store s) async =>
    parseDeadlineLeads(await s.meta(MetaKey.deadlineLeadMinutes));
String leadLabel(int m) => m % 1440 == 0
    ? '${m ~/ 1440}일 전'
    : m % 60 == 0
    ? '${m ~/ 60}시간 전'
    : '$m분 전';
String deadlineToken(String key, DateTime due, int minutes) =>
    'due:$key:${due.toIso8601String()}${minutes == 1440 ? '' : ':m$minutes'}';
int? latestElapsedLead(List<int> leads, DateTime due, DateTime now) => leads
    .where((m) => !due.subtract(Duration(minutes: m)).isAfter(now))
    .fold<int?>(null, (a, b) => a == null || b < a ? b : a);

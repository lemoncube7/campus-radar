import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'dart:convert';
import 'package:campus_radar/core/network_resilience.dart';
import 'package:campus_radar/core/sync_timing.dart';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:path_provider/path_provider.dart';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/campus/campus_media.dart';

/// Re-downloadable private cache, isolated by account. No public storage permission.
class MediaCache {
  final Directory root;
  final String? account, epoch;
  MediaCache(this.root, {this.account, this.epoch});
  static Future<MediaCache> open(String account) async {
    final base = await getTemporaryDirectory();
    final key = sha256.convert(utf8.encode(account)).toString();
    final root = Directory('${base.path}/campus_media/$key');
    await root.create(recursive: true);
    final store = await Store.open();
    try {
      final scope = await SessionScope.capture(store);
      if (scope.account != account) throw SessionChanged();
      return MediaCache(root, account: account, epoch: scope.epoch);
    } finally {
      await store.db.close();
    }
  }

  String key(CampusMedia m) =>
      sha256.convert(utf8.encode(m.identity)).toString();
  String safeName(String s) {
    var name = s.replaceAll(RegExp(r'[<>:"/\\|?*\x00-\x1f]'), '_').trim();
    // File systems cap names at 255 bytes (64-char key + '-' included);
    // Korean takes 3 bytes per letter. Keep the extension and cut whole
    // characters from the end of the stem.
    final dot = name.lastIndexOf('.');
    final ext = dot > 0 && name.length - dot <= 10 ? name.substring(dot) : '';
    var stem = name.substring(0, name.length - ext.length);
    while (stem.isNotEmpty && utf8.encode('$stem$ext').length > 150) {
      stem = String.fromCharCodes(stem.runes.toList()..removeLast());
    }
    name = '$stem$ext'.trim();
    if (name.isEmpty || name == '.' || name == '..' || name == ext) {
      name = 'attachment$ext';
    }
    return name;
  }

  File data(CampusMedia m) =>
      File('${root.path}/${key(m)}-${safeName(m.name)}');
  File record(CampusMedia m) => File('${root.path}/${key(m)}.json');
  Future<File?> local(CampusMedia m) async {
    final f = data(m);
    return await f.exists() && await record(m).exists() ? f : null;
  }

  Future<String> status(CampusMedia m) async {
    if (await local(m) != null) return '기기에 저장됨';
    try {
      return (jsonDecode(await record(m).readAsString()) as Map)['error'] ??
          '저장 대기';
    } catch (_) {
      return m.supported ? '저장 대기' : '외부 파일 · 원문에서 확인';
    }
  }

  Future<String> mime(CampusMedia m) async {
    try {
      return (jsonDecode(await record(m).readAsString()) as Map)['mime'] ??
          'application/octet-stream';
    } catch (_) {
      return 'application/octet-stream';
    }
  }

  Future<void> verifySession() async {
    if (epoch == null) return;
    final store = await Store.open();
    try {
      final scope = await SessionScope.capture(store);
      if (scope.epoch != epoch || scope.account != account) {
        throw SessionChanged();
      }
    } finally {
      await store.db.close();
    }
  }

  Future<File> fetch(CampusClient client, CampusMedia m, {SyncTiming? timing}) async {
    await verifySession();
    final existing = await local(m);
    if (existing != null) return existing;
    if (!m.supported) throw CampusException('외부 이미지·파일은 원문에서 확인해 주세요.');
    if ((m.size ?? 0) > 50 * 1024 * 1024) {
      throw CampusException('파일당 50MB 저장 제한을 초과했어요.');
    }
    final partialRoot = Directory('${root.path}/partial');
    await partialRoot.create(recursive: true);
    final partial = File(
      '${partialRoot.path}/${key(m)}.${DateTime.now().microsecondsSinceEpoch}.part',
    );
    try {
      final result = await (timing?.measure('파일 다운로드', () => client.downloadMedia(m)) ?? client.downloadMedia(m));
      Future<void> save() async {
        await verifySession();
        await trim(result.bytes.length);
        await partial.writeAsBytes(result.bytes, flush: true);
        await partial.rename(data(m).path);
        await record(m).writeAsString(jsonEncode({'mime': result.mime}));
      }
      await (timing?.measure('파일 저장·캐시 정리', save) ?? save());
      return data(m);
    } catch (e) {
      if (await partial.exists()) await partial.delete();
      if (e is SessionChanged) rethrow;
      if (await local(m) == null) {
        await record(m).writeAsString(
          jsonEncode({
            'error': e is CampusException
                ? e.message
                : '${networkFailureMessage(e)} 눌러서 재시도',
          }),
        );
      }
      rethrow;
    }
  }

  Future<void> trim(int incoming) async {
    final files = await root
        .list()
        .where(
          (f) =>
              f is File &&
              !RegExp(
                r'^[a-f0-9]{64}\.json$',
              ).hasMatch(f.uri.pathSegments.last),
        )
        .cast<File>()
        .toList();
    final stats = <File, FileStat>{};
    var total = incoming;
    for (final f in files) {
      final st = await f.stat();
      stats[f] = st;
      total += st.size;
    }
    files.sort((a, b) => stats[a]!.modified.compareTo(stats[b]!.modified));
    for (final f in files) {
      if (total <= 300 * 1024 * 1024) break;
      total -= stats[f]!.size;
      await f.delete();
      final name = f.uri.pathSegments.last;
      if (name.length > 64) {
        final metadata = File('${root.path}/${name.substring(0, 64)}.json');
        if (await metadata.exists()) await metadata.delete();
      }
    }
  }
}

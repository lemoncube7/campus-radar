import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:html/dom.dart' as dom;
import 'package:html/parser.dart' as html;
import 'package:campus_radar/campus/campus_media.dart';

/// Native, read-only rendering. No CSS engine, WebView, scripts or URL execution.
class CampusRichBody extends StatelessWidget {
  final String source;
  final Widget Function(int) imageAt;
  const CampusRichBody({
    super.key,
    required this.source,
    required this.imageAt,
  });
  @override
  Widget build(BuildContext context) {
    final renderer = _Renderer(context, imageAt);
    final nodes = html
        .parseFragment(
          normalizeCampusHtml(
            source.length > 300000 ? source.substring(0, 300000) : source,
          ),
        )
        .nodes;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: renderer.blocks(nodes, 0),
    );
  }
}

class _Renderer {
  final BuildContext context;
  final Widget Function(int) imageAt;
  int images = 0, visited = 0;
  _Renderer(this.context, this.imageAt);
  static const hidden = {
    'script',
    'style',
    'iframe',
    'object',
    'embed',
    'form',
    'input',
    'button',
    'video',
    'audio',
    'svg',
  };
  static const block = {
    'p',
    'div',
    'section',
    'article',
    'blockquote',
    'pre',
    'ul',
    'ol',
    'li',
    'table',
    'hr',
    'h1',
    'h2',
    'h3',
    'h4',
    'h5',
    'h6',
    'figure',
  };
  TextStyle get base =>
      Theme.of(context).textTheme.bodyLarge!.copyWith(height: 1.6);
  String tag(dom.Node n) => n is dom.Element ? n.localName ?? '' : '';
  List<Widget> blocks(List<dom.Node> nodes, int depth) {
    if (depth > 20 || visited > 3000) {
      return [const Text('긴 본문은 사이버캠퍼스 원문에서 확인해 주세요.')];
    }
    final result = <Widget>[];
    var inline = <dom.Node>[];
    void flush() {
      if (inline.isEmpty) return;
      final spans = inline.map((n) => span(n, base, depth + 1)).toList();
      if (spans.any((s) => s.toPlainText().trim().isNotEmpty)) {
        result.add(paragraph(spans));
      }
      inline = [];
    }

    for (final node in nodes) {
      if (++visited > 3000) break;
      final name = tag(node);
      if (hidden.contains(name)) continue;
      if (name == 'img') {
        flush();
        final e = node as dom.Element;
        if ((e.attributes['src'] ??
                e.attributes['data-src'] ??
                e.attributes['data-cms-no'] ??
                '')
            .isNotEmpty) {
          result.add(imageAt(images++));
        }
        continue;
      }
      if (block.contains(name)) {
        flush();
        result.addAll(element(node as dom.Element, depth + 1));
      } else if (node is dom.Element && node.querySelector('img') != null) {
        // An image wrapped in a link/span must still take its slot, or every
        // later image would shift to the wrong place.
        flush();
        result.addAll(blocks(node.nodes, depth + 1));
      } else {
        inline.add(node);
      }
    }
    flush();
    return result;
  }

  Widget paragraph(List<InlineSpan> spans, {TextStyle? style}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: SelectableText.rich(TextSpan(style: style ?? base, children: spans)),
  );
  TextSpan span(dom.Node node, TextStyle style, int depth) {
    if (depth > 20 || ++visited > 3000) return const TextSpan(text: '');
    if (node is dom.Text) return TextSpan(text: node.text, style: style);
    if (node is! dom.Element || hidden.contains(tag(node))) {
      return const TextSpan(text: '');
    }
    final name = tag(node);
    if (name == 'br') return const TextSpan(text: '\n');
    var effective = style;
    final css = (node.attributes['style'] ?? '').toLowerCase();
    if ({'b', 'strong', 'th'}.contains(name) ||
        RegExp(r'font-weight\s*:\s*(bold|[6-9]00)').hasMatch(css)) {
      effective = effective.copyWith(fontWeight: FontWeight.w700);
    }
    if ({'i', 'em'}.contains(name) || css.contains('font-style: italic')) {
      effective = effective.copyWith(fontStyle: FontStyle.italic);
    }
    if (name == 'u' || css.contains('underline')) {
      effective = effective.copyWith(decoration: TextDecoration.underline);
    }
    if (name == 'code') {
      effective = effective.copyWith(
        fontFamily: 'monospace',
        backgroundColor: Theme.of(context).colorScheme.surfaceContainerHighest,
      );
    }
    return TextSpan(
      style: effective,
      children: node.nodes.map((n) => span(n, effective, depth + 1)).toList(),
    );
  }

  List<Widget> element(dom.Element e, int depth) {
    if (depth > 20) return [];
    final name = tag(e);
    if (RegExp(r'^h[1-6]$').hasMatch(name)) {
      final heading = base.copyWith(
        fontSize: math.max(17, 25 - int.parse(name[1]) * 1.5),
        fontWeight: FontWeight.bold,
      );
      return [
        paragraph(
          e.nodes.map((n) => span(n, heading, depth + 1)).toList(),
          style: heading,
        ),
      ];
    }
    if (name == 'p' &&
        !e.children.any((c) => block.contains(tag(c))) &&
        e.querySelector('img') == null) {
      return [
        paragraph([span(e, base, depth + 1)]),
      ];
    }
    if (name == 'hr') return [const Divider(height: 24)];
    if (name == 'ul' || name == 'ol') {
      final result = <Widget>[];
      var index = 0;
      for (final li in e.children.where((c) => tag(c) == 'li').take(100)) {
        index++;
        result.add(
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 5, right: 10),
                child: Text(name == 'ol' ? '$index.' : '•', style: base),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: blocks(li.nodes, depth + 1),
                ),
              ),
            ],
          ),
        );
      }
      return result;
    }
    if (name == 'table') {
      final rows = e
          .querySelectorAll('tr')
          .where((r) => r.parent?.localName != 'table' || r.parent == e)
          .take(100)
          .toList();
      if (rows.isEmpty) return blocks(e.nodes, depth + 1);
      final cells = rows
          .map(
            (r) => r.children
                .where((c) => {'td', 'th'}.contains(tag(c)))
                .take(12)
                .toList(),
          )
          .toList();
      final columns = cells.fold<int>(0, (n, row) => math.max(n, row.length));
      if (columns == 0) return [];
      return [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: LayoutBuilder(
            builder: (c, limits) => SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SizedBox(
                width: math.max(limits.maxWidth, columns * 135.0),
                child: Table(
                  border: TableBorder.all(
                    color: Theme.of(context).dividerColor,
                  ),
                  defaultVerticalAlignment: TableCellVerticalAlignment.top,
                  children: [
                    for (final row in cells)
                      TableRow(
                        children: [
                          for (var col = 0; col < columns; col++)
                            Padding(
                              padding: const EdgeInsets.all(10),
                              child: col >= row.length
                                  ? const SizedBox.shrink()
                                  : Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.stretch,
                                      children: blocks(
                                        row[col].nodes,
                                        depth + 1,
                                      ),
                                    ),
                            ),
                        ],
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ];
    }
    if (name == 'pre') {
      return [
        Container(
          margin: const EdgeInsets.symmetric(vertical: 8),
          padding: const EdgeInsets.all(12),
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          child: SelectableText(
            e.text,
            style: base.copyWith(fontFamily: 'monospace'),
          ),
        ),
      ];
    }
    return blocks(e.nodes, depth + 1);
  }
}

import 'package:flutter/material.dart';

import 'package:campus_radar/tasks/task_presentation.dart' show formatDate;

/// Status line for the read-only Windows mode. School collection time (the
/// phone) and Drive check time (this PC) are shown separately: refreshing here
/// re-reads Drive but cannot make the phone collect.
class DriveViewerStatus extends StatelessWidget {
  final String? collected, checked, error;
  final bool busy;
  final Future<void> Function() refresh;
  const DriveViewerStatus({
    super.key,
    required this.collected,
    required this.checked,
    required this.error,
    required this.busy,
    required this.refresh,
  });

  @override
  Widget build(BuildContext context) {
    final problem = error?.isNotEmpty == true;
    final school = DateTime.tryParse(collected ?? '');
    final drive = DateTime.tryParse(checked ?? '');
    final small = Theme.of(context).textTheme.bodySmall;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: problem
              ? Theme.of(context).colorScheme.surfaceContainerHigh
              : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Padding(
          padding: EdgeInsets.all(problem ? 12 : 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(
                    Icons.add_to_drive_outlined,
                    size: 16,
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      '폰 자료 보기 · 폰 수집 ${school == null ? '-' : formatDate(school)}'
                      ' · Drive 확인 ${drive == null ? '-' : formatDate(drive)}',
                      style: small,
                    ),
                  ),
                  Tooltip(
                    message: 'Drive를 다시 읽어요. 폰의 학교 수집을 시작하지는 않아요.',
                    child: TextButton(
                      onPressed: busy ? null : refresh,
                      child: const Text('지금 확인'),
                    ),
                  ),
                ],
              ),
              if (problem) Text(error!, style: small),
            ],
          ),
        ),
      ),
    );
  }
}

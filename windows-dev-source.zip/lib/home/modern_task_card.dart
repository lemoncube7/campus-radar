import 'package:flutter/material.dart';

import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/courses/course_colors.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/tasks/task_presentation.dart';

/// Modern card widget for mobile task display with clear visual hierarchy,
/// course accent color bar, deadline status badges, and smooth gestures.
class ModernTaskCard extends StatelessWidget {
  final CampusItem item;
  final bool excluded;
  final VoidCallback onTap;
  final VoidCallback? onVisibilityToggle;

  const ModernTaskCard({
    super.key,
    required this.item,
    this.excluded = false,
    required this.onTap,
    this.onVisibilityToggle,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final accent = deadlineColor(item, context);
    final courseColor = courseAccent('${item.courseId}:${item.classNo}');
    final badge = dueBadge(item);
    final isUrgent =
        deadlineState(item.due) == DeadlineState.withinDay ||
        deadlineState(item.due) == DeadlineState.overdue;

    final card = Container(
      margin: const EdgeInsets.symmetric(vertical: 4.5),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerLowest,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isUrgent
              ? colorScheme.error.withValues(alpha: 0.45)
              : colorScheme.outlineVariant.withValues(alpha: 0.45),
          width: isUrgent ? 1.2 : 1.0,
        ),
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.03),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
              // 1. Left colored accent bar for course identification
              Container(
                width: 5,
                color: courseColor,
              ),

              // 2. Main content area
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(14, 12, 12, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Header: Course pill + Type label + Due Badge
                      Row(
                        children: [
                          // Course Tag Pill
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: courseColor.withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              courseLabel(item.course),
                              style: theme.textTheme.labelSmall?.copyWith(
                                color: courseColor,
                                fontWeight: FontWeight.bold,
                                letterSpacing: -0.2,
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            item.kindLabel,
                            style: theme.textTheme.labelSmall?.copyWith(
                              color: colorScheme.onSurfaceVariant,
                            ),
                          ),
                          if (item.type == 'LV' &&
                              item.attendanceRequired != null) ...[
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 6,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                color: colorScheme.surfaceContainerHighest,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                item.attendanceRequired! ? '출석' : '자율',
                                style: theme.textTheme.labelSmall?.copyWith(
                                  fontSize: 10,
                                  color: colorScheme.onSurfaceVariant,
                                ),
                              ),
                            ),
                          ],
                          if (item.evaluation != null) ...[
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 6.5,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xff2e7d32).withValues(alpha: 0.12),
                                borderRadius: BorderRadius.circular(5),
                                border: Border.all(
                                  color: const Color(0xff2e7d32).withValues(alpha: 0.3),
                                ),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(
                                    Icons.grade_rounded,
                                    size: 11,
                                    color: Color(0xff2e7d32),
                                  ),
                                  const SizedBox(width: 3),
                                  Text(
                                    item.evaluation!.maximum.isNotEmpty
                                        ? '${item.evaluation!.score}/${item.evaluation!.maximum}점'
                                        : '${item.evaluation!.score}점',
                                    style: const TextStyle(
                                      color: Color(0xff2e7d32),
                                      fontSize: 10.5,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                          const Spacer(),
                          // Due badge
                          if (badge != null)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 3,
                              ),
                              decoration: BoxDecoration(
                                color: isUrgent
                                    ? colorScheme.errorContainer
                                    : colorScheme.secondaryContainer,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  if (isUrgent) ...[
                                    Icon(
                                      Icons.timer_outlined,
                                      size: 12,
                                      color: colorScheme.onErrorContainer,
                                    ),
                                    const SizedBox(width: 3),
                                  ],
                                  Text(
                                    badge,
                                    style: theme.textTheme.labelSmall?.copyWith(
                                      color: isUrgent
                                          ? colorScheme.onErrorContainer
                                          : colorScheme.onSecondaryContainer,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 8),

                      // Title
                      Text(
                        item.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                          fontSize: 14.5,
                          height: 1.25,
                          letterSpacing: -0.2,
                          decoration: excluded
                              ? TextDecoration.lineThrough
                              : TextDecoration.none,
                          color: excluded
                              ? colorScheme.outline
                              : colorScheme.onSurface,
                        ),
                      ),
                      const SizedBox(height: 8),

                      if (item.evaluation != null && item.evaluation!.feedback.isNotEmpty) ...[
                        Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4.5),
                          decoration: BoxDecoration(
                            color: colorScheme.surfaceContainerHighest.withValues(alpha: 0.45),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.chat_bubble_outline_rounded,
                                size: 12,
                                color: colorScheme.onSurfaceVariant,
                              ),
                              const SizedBox(width: 5),
                              Expanded(
                                child: Text(
                                  '피드백: ${item.evaluation!.feedback}',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: theme.textTheme.bodySmall?.copyWith(
                                    color: colorScheme.onSurfaceVariant,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],

                      // Footer: Status and Due Date Info
                      Row(
                        children: [
                          Icon(
                            item.done
                                ? Icons.check_circle_rounded
                                : Icons.schedule_rounded,
                            size: 14,
                            color: accent,
                          ),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(
                              [
                                excluded ? '숨김' : statusText(item),
                                if (!item.isMaterial)
                                  item.due == null
                                      ? '마감 미확인'
                                      : formatDateShort(item.due!),
                                if (item.progress.isNotEmpty) item.progress,
                              ].join(' · '),
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: colorScheme.onSurfaceVariant,
                                fontSize: 12,
                              ),
                            ),
                          ),
                          if (onVisibilityToggle != null)
                            InkWell(
                              onTap: onVisibilityToggle,
                              borderRadius: BorderRadius.circular(12),
                              child: Padding(
                                padding: const EdgeInsets.all(4),
                                child: Icon(
                                  excluded
                                      ? Icons.visibility_outlined
                                      : Icons.visibility_off_outlined,
                                  size: 16,
                                  color: colorScheme.outline,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    ),
    );

    if (onVisibilityToggle == null) return card;

    return Dismissible(
      key: ValueKey('modern-card-${item.key}'),
      direction: DismissDirection.endToStart,
      confirmDismiss: (_) async {
        onVisibilityToggle?.call();
        return false;
      },
      background: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(
          color: excluded
              ? colorScheme.primaryContainer
              : colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(16),
        ),
        alignment: Alignment.centerRight,
        child: Icon(
          excluded ? Icons.visibility_rounded : Icons.visibility_off_rounded,
          color: excluded
              ? colorScheme.onPrimaryContainer
              : colorScheme.onSurfaceVariant,
        ),
      ),
      child: card,
    );
  }
}

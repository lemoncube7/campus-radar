import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:flutter/material.dart';

class WidgetTextPage extends StatefulWidget {
  const WidgetTextPage({super.key});
  @override
  State<WidgetTextPage> createState() => _WidgetTextState();
}

class _WidgetTextState extends State<WidgetTextPage> {
  final values = <String, int>{'tasks': 100, 'timetable': 100, 'lock': 100};
  bool busy = true;
  String? error;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final data = await bridge.invokeNativeMap<String, dynamic>(
        NativeMethod.widgetTextSettings,
      );
      if (!mounted) return;
      setState(() {
        for (final key in values.keys) {
          values[key] = ((data?[key] as num?)?.toInt() ?? 100).clamp(80, 150);
        }
        busy = false;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          busy = false;
          error = '설정을 읽지 못했어요. 다시 열어 주세요.';
        });
      }
    }
  }

  Future<void> save() async {
    setState(() {
      busy = true;
      error = null;
    });
    try {
      await bridge.invokeNative(NativeMethod.widgetTextConfigure, values);
    } catch (_) {
      if (mounted) setState(() => error = '저장하지 못했어요. 다시 시도해 주세요.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('위젯 글씨 크기')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text(
          '종류별로 80~150%까지 조절할 수 있어요. 손을 떼면 저장하고 적용해요. 기기의 기본 글자 크기 설정도 함께 반영돼요(시간표 이미지는 선택 비율 적용).',
        ),
        for (final entry in const {
          'tasks': '과제·콘텐츠 위젯',
          'timetable': '시간표 위젯',
          'lock': '잠금화면 카드',
        }.entries)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${entry.value} · ${values[entry.key]}%'),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    child: Text(
                      '컴프2 · 실습 과제\n오늘 23:59 마감',
                      style: TextStyle(fontSize: 14 * values[entry.key]! / 100),
                    ),
                  ),
                  Slider(
                    key: ValueKey(entry.key),
                    value: values[entry.key]!.toDouble(),
                    min: 80,
                    max: 150,
                    divisions: 7,
                    label: '${values[entry.key]}%',
                    onChanged: busy
                        ? null
                        : (v) => setState(() => values[entry.key] = v.round()),
                    onChangeEnd: busy ? null : (_) => save(),
                  ),
                ],
              ),
            ),
          ),
        const Text('글씨를 크게 하면 표시되는 글자 수가 줄어들 수 있어요. 홈 화면 위젯은 크기도 함께 늘려 주세요.'),
        if (error != null)
          Text(
            error!,
            style: TextStyle(color: Theme.of(context).colorScheme.error),
          ),
        TextButton(
          onPressed: busy
              ? null
              : () {
                  setState(() => values.updateAll((_, _) => 100));
                  save();
                },
          child: const Text('기본 크기로 복원'),
        ),
      ],
    ),
  );
}

import 'package:campus_radar/settings/deadline_settings_page.dart';
import 'package:flutter/material.dart';
import 'package:campus_radar/home/daily_summary_page.dart';
import 'package:campus_radar/schedule/timetable_page.dart';
import 'package:campus_radar/settings/permissions_page.dart';
import 'package:campus_radar/ai/ai_settings_page.dart';

class NotificationSettingsPage extends StatelessWidget {
  const NotificationSettingsPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('알림 설정')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('새 과제·공지와 마감 알림은 수집 상태와 기기 알림 권한을 따라요.'),
        ListTile(
          title: const Text('마감 알림 시점'),
          subtitle: const Text('여러 시점 선택 · 기본 하루 전'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const DeadlineSettingsPage()),
          ),
        ),
        ListTile(
          title: const Text('알림·백그라운드 권한'),
          subtitle: const Text('알림 허용 · 배터리 제한 · 정확한 알림'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const PermissionsPage()),
          ),
        ),
        ListTile(
          title: const Text('수업 전·자정 알림'),
          subtitle: const Text('수업 15·30·60분 전 · 자정의 오늘 수업과 과제'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const TimetablePage(initialMode: 2),
            ),
          ),
        ),
        ListTile(
          title: const Text('하루 요약 알림'),
          subtitle: const Text('원하는 시각에 오늘의 과제 현황 받기'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const DailySummaryPage(settings: true),
            ),
          ),
        ),
        ListTile(
          title: const Text('요약에 AI 사용'),
          subtitle: const Text('알림 시각과 별개로 요약 문장 생성을 설정해요.'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AiSettingsPage()),
          ),
        ),
      ],
    ),
  );
}

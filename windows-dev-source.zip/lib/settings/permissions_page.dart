import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/core/notification_gateway.dart';

class PermissionsPage extends StatefulWidget {
  const PermissionsPage({super.key});
  @override
  State<PermissionsPage> createState() => _PermissionsState();
}

class _PermissionsState extends State<PermissionsPage>
    with WidgetsBindingObserver {
  Map<String, dynamic>? status;
  bool? allowed, exact;
  Map<String, dynamic>? lock;
  String? error;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) load();
  }

  Future<void> load() async {
    try {
      final s = await bridge.invokeNativeMap<String, dynamic>(
        NativeMethod.backgroundStatus,
      );
      if (s == null) throw StateError('권한 응답 없음');
      final a = Platform.isAndroid
          ? await notifications
                .resolvePlatformSpecificImplementation<
                  AndroidFlutterLocalNotificationsPlugin
                >()
                ?.areNotificationsEnabled()
          : null;
      final timetable = Platform.isAndroid
          ? await bridge.invokeNativeMap<String, dynamic>(
              NativeMethod.timetableSettings,
            )
          : null;
      final lockState = Platform.isAndroid
          ? await bridge.invokeNativeMap<String, dynamic>(
              NativeMethod.lockSettings,
            )
          : null;
      if (mounted) {
        setState(() {
          exact = timetable?['exactAllowed'] as bool?;
          lock = lockState;
          status = s;
          allowed = a;
          error = null;
        });
      }
    } catch (_) {
      if (mounted) setState(() => error = '권한 상태를 확인하지 못했어요. 다시 확인해 주세요.');
    }
  }

  Widget row(String title, bool? ok, VoidCallback action, {String? detail}) =>
      Card(
        child: ListTile(
          leading: Icon(
            ok == true ? Icons.check_circle_outline : Icons.info_outline,
            color: ok == true ? Theme.of(context).colorScheme.primary : null,
          ),
          title: Text(title),
          subtitle: Text(
            detail ??
                (ok == null
                    ? '확인 전'
                    : ok
                    ? '허용됨'
                    : '설정 필요'),
          ),
          trailing: TextButton(onPressed: action, child: const Text('설정 열기')),
        ),
      );
  Future<void> open(NativeMethod method) async {
    try {
      await bridge.invokeNative(method);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('기기 설정을 열지 못했어요.')));
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('알림·백그라운드 권한'),
      actions: [
        IconButton(
          onPressed: load,
          tooltip: '권한 다시 확인',
          icon: const Icon(Icons.refresh),
        ),
      ],
    ),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('문제가 있는 항목만 기기 설정에서 변경해 주세요. 돌아오면 상태를 다시 확인해요.'),
        const SizedBox(height: 16),
        if (error != null)
          Text(
            error!,
            style: TextStyle(color: Theme.of(context).colorScheme.error),
          ),
        if (status == null && error == null) const LinearProgressIndicator(),
        row('알림 허용', allowed, () => open(NativeMethod.openAppSettings)),
        if (Platform.isAndroid) ...[
          row(
            '배터리 제한 없음',
            status == null
                ? null
                : status!['batteryExempt'] == true &&
                      status!['backgroundRestricted'] != true,
            () => open(NativeMethod.openAppSettings),
          ),
          row(
            '정확한 수업 알림',
            exact,
            () => open(NativeMethod.openExactAlarmSettings),
          ),
          if (lock?['enabled'] == true)
            row(
              '잠금화면 접근성',
              lock?['allowed'] as bool?,
              () => open(NativeMethod.lockPermission),
              detail: lock?['connected'] == true ? '서비스 연결됨' : '서비스 연결 확인 필요',
            ),
        ],
        const SizedBox(height: 16),
        const Text(
          '권한이 허용되어도 운영체제의 실행 조건에 따라 수집이나 알림이 늦어질 수 있어요.',
          style: TextStyle(fontSize: 12),
        ),
      ],
    ),
  );
}

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';

class SystemWidgetPage extends StatefulWidget {
  const SystemWidgetPage({super.key});
  @override
  State<SystemWidgetPage> createState() => _State();
}

class _State extends State<SystemWidgetPage> {
  bool details = false;
  String? message;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final j = await bridge.invokeNativeMap<String, dynamic>(
        NativeMethod.compactWidgetSettings,
      );
      if (mounted) setState(() => details = j?['details'] == true);
    } catch (_) {
      // Keep the default (details hidden) when settings are unreadable.
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('시스템 잠금화면 위젯')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text(
          '접근성 카드와 다른 표준 위젯',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const Text(
          '“캠퍼스레이더 수업·마감 (잠금화면용)”은 위젯을 지원하는 잠금화면에 사용자가 배치하는 방식이에요. 접근성 서비스나 화면 위 표시 권한이 필요하지 않아요. 다음 수업 시각과 24시간 내 마감 개수를 표시해요.',
        ),
        const ListTile(
          leading: Icon(Icons.phone_android),
          title: Text('Galaxy · Good Lock → LockStar'),
          subtitle: Text(
            'Galaxy Store에서 두 앱을 최신으로 업데이트한 뒤, LockStar 편집 화면에서 LockStar 버튼 → 앱 위젯 → 캠퍼스레이더을 찾아 배치하세요. One UI·기기·지역·LockStar 버전에 따라 기능이나 메뉴가 다를 수 있어요.',
          ),
        ),
        const Text(
          '기본 잠금화면의 시계 아래 미니 위젯 목록과 LockStar의 위젯 추가 기능은 달라요. 목록에 없다면 앱이 강제로 추가할 수는 없어요. 다른 Android 기기는 해당 잠금화면의 위젯 선택 기능이 필요해요. AOD 표시·갱신 주기는 기기 정책에 따라 달라져요.',
        ),
        const ListTile(
          title: Text('요약형 / 과제 목록형'),
          subtitle: Text(
            '수업·마감은 큰 숫자와 다음 수업을, 과제 현황은 과제 제목·과목·마감을 보여줘요. 둘 다 LockStar의 앱 위젯에서 선택할 수 있어요. 작은 크기에서는 표시 개수를 줄이고, 긴 제목은 두 줄로 표시해요.',
          ),
        ),
        OutlinedButton(
          onPressed: () => launchUrl(
            Uri.parse(
              'https://www.samsung.com/uk/mobile-phone-buying-guide/what-are-widgets/',
            ),
            mode: LaunchMode.externalApplication,
          ),
          child: const Text('삼성 공식 위젯 안내'),
        ),
        SwitchListTile(
          title: const Text('수업명·강의실 표시'),
          subtitle: const Text(
            '켜면 잠긴 화면에도 수업명과 강의실이 표시돼요. 작은 위젯에서는 한 줄에 표시해요.',
          ),
          value: details,
          onChanged: !Platform.isAndroid
              ? null
              : (v) async {
                  try {
                    await bridge.invokeNative(
                      NativeMethod.compactWidgetConfigure,
                      {'details': v},
                    );
                    if (mounted) setState(() => details = v);
                  } catch (_) {
                    if (mounted) {
                      setState(() => message = '설정을 저장하지 못했어요. 다시 시도해 주세요.');
                    }
                  }
                },
        ),
        FilledButton.icon(
          onPressed: !Platform.isAndroid
              ? null
              : () async {
                  try {
                    final ok = await bridge.invokeNative<bool>(
                      NativeMethod.pinCompactWidget,
                    );
                    if (mounted) {
                      setState(
                        () => message = ok == true
                            ? '홈 화면 추가 창을 열었어요. 잠금화면 배치는 LockStar에서 별도로 해 주세요.'
                            : '홈 화면의 위젯 목록에서 수업·마감을 찾아 주세요.',
                      );
                    }
                  } catch (_) {
                    if (mounted) {
                      setState(() => message = '기기의 위젯 목록에서 직접 추가해 주세요.');
                    }
                  }
                },
          icon: const Icon(Icons.widgets_outlined),
          label: const Text('홈 화면에서 먼저 확인'),
        ),
        const Text(
          '수업 부분을 누르면 잠금 해제 후 시간표로 이동해요. 시간표 수업 → 과목 보기로 연결돼요. 기존 접근성 카드는 직접 끄기 전까지 유지되므로 중복 표시 여부를 확인해 주세요.',
        ),
        if (message != null) Text(message!),
      ],
    ),
  );
}

import 'package:campus_radar/core/storage_keys.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/deadline_reminders.dart';
import 'package:campus_radar/campus/services.dart';

class DeadlineSettingsPage extends StatefulWidget {
  const DeadlineSettingsPage({super.key});
  @override
  State<DeadlineSettingsPage> createState() => _DeadlineSettingsPageState();
}

class _DeadlineSettingsPageState extends State<DeadlineSettingsPage> {
  final custom = TextEditingController();
  Set<int> selected = {1440};
  bool loading = true, busy = false;
  String? message;
  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void dispose() {
    custom.dispose();
    super.dispose();
  }

  Future<void> load() async {
    Store? s;
    try {
      s = await Store.open();
      final v = await deadlineLeads(s);
      if (mounted) setState(() => selected = v.toSet());
    } catch (_) {
      message = '설정을 읽지 못했어요.';
    } finally {
      await s?.db.close();
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> save() async {
    setState(() => busy = true);
    Store? s;
    try {
      s = await Store.open();
      await s.setMeta(MetaKey.deadlineLeadMinutes,
        jsonEncode(selected.toList()..sort()),
      );
      await s.log(
        'notification',
        '마감 알림 시점 변경',
        selected.map(leadLabel).join(' · '),
      );
      await reconcile(s);
      if (mounted) Navigator.pop(context);
    } catch (_) {
      if (mounted) {
        setState(() => message = '설정 저장 또는 알림 반영을 완료하지 못했어요. 다시 확인해 주세요.');
      }
    } finally {
      await s?.db.close();
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final choices = {4320, 1440, 360, 60, 30, ...selected}.toList()
      ..sort((a, b) => b.compareTo(a));
    return Scaffold(
      appBar: AppBar(title: const Text('마감 알림 시점')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            '여러 시점을 선택할 수 있어요. 기본은 하루 전이에요. 모두 해제하면 마감 알림을 꺼요. 새 항목 알림은 유지해요.',
          ),
          if (loading) const LinearProgressIndicator(),
          for (final m in choices)
            CheckboxListTile(
              title: Text(leadLabel(m)),
              value: selected.contains(m),
              onChanged: loading || busy
                  ? null
                  : (v) => setState(() {
                      if (v == true && selected.length < 6) {
                        selected.add(m);
                      } else if (v != true) {
                        selected.remove(m);
                      } else {
                        message = '최대 6개까지 선택할 수 있어요.';
                      }
                    }),
            ),
          TextField(
            controller: custom,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: '직접 추가 · 마감 몇 분 전?',
              helperText: '1~43,200분 (최대 30일)',
            ),
          ),
          TextButton(
            onPressed: busy
                ? null
                : () {
                    final m = int.tryParse(custom.text);
                    setState(() {
                      if (m == null ||
                          m < 1 ||
                          m > 43200 ||
                          selected.length >= 6) {
                        message = '유효한 분 단위를 입력해 주세요. 최대 6개까지 가능해요.';
                      } else {
                        selected.add(m);
                        custom.clear();
                        message = null;
                      }
                    });
                  },
            child: const Text('알림 시점 추가'),
          ),
          const Text(
            '절전·네트워크·수집 상태에 따라 늦어질 수 있어요. 여러 알림 시점이 이미 지났다면 가장 가까운 한 시점만 알려요.',
          ),
          if (message != null) Text(message!),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: loading || busy ? null : save,
            child: Text(busy ? '반영 중…' : '저장'),
          ),
        ],
      ),
    );
  }
}

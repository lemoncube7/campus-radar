/// App-owned instructions, separate from untrusted academic reference data.
class AppHelpTopic {
  final String id, title, description;
  final List<String> steps;
  const AppHelpTopic(this.id, this.title, this.description, this.steps);
  String get link => 'campus-radar://help/$id';
}

const appHelpTopics = [
  AppHelpTopic(
    'ai-calendar',
    'AI 공지 일정을 캘린더에 표시하기',
    '개인 Gemini 키 연결부터 일정 확인과 캘린더 전송까지 안내해요.',
    [
      'AI 설정에서 개인 Gemini 키를 저장하고 공지 전송 범위에 동의하세요. 자동 분석은 원하는 경우 켜세요.',
      '캘린더 설정에서 권한과 저장할 캘린더를 선택하세요. 확인한 AI 일정도 보내려면 해당 옵션을 켜세요.',
      '검토함에서 날짜·시간과 근거를 검토한 뒤 추가하세요. 명확한 일정의 자동 승인은 AI 설정에서 별도로 선택할 수 있어요.',
      '캘린더에서 결과를 확인하세요. 이미 확정한 일정은 개별 일정의 전송 동작이 필요할 수 있어요.',
    ],
  ),
  AppHelpTopic('ai', '공지에서 일정 찾기', '제목과 본문에서 시험·마감·휴강 일정을 찾고 검토해요.', [
    'AI 설정에서 개인 Gemini 키와 전송 동의를 확인하세요.',
    '공지 상세의 찾은 결과에서 분석하거나, 자동 분석 설정을 켜세요. 이미지·첨부파일 내용은 텍스트 분석에 포함되지 않을 수 있어요.',
    '검토함에서 불확실한 날짜·대상·변경 여부를 검토하세요.',
  ]),
  AppHelpTopic('timetable', '시간표와 휴강 관리', '강의계획서로 시간표를 만들고 수업 알림을 설정해요.', [
    '시간표 만들기로 강의계획서를 읽고 누락·잘못된 수업 시간을 직접 확인하세요.',
    '시간표에서 수업 알림을 설정하세요. AI 휴강 후보는 근거와 적용 날짜를 확인한 후 반영하세요.',
  ]),
  AppHelpTopic('notifications', '알림 설정', '새 과제·마감·하루 요약 알림을 조절해요.', [
    '알림 설정에서 필요한 알림 종류와 시각을 선택하세요.',
    '알림·백그라운드 권한에서 알림 허용과 배터리 제한을 확인하세요. 최근 수집 성공은 학교 연결·수집에서 확인할 수 있어요. 수집 간격과 Android 실행 조건에 따라 감지가 늦어질 수 있어요.',
  ]),
  AppHelpTopic('widgets', '위젯 설정', '홈 화면과 잠금화면에서 과제·수업을 확인해요.', [
    '위젯 설정에서 홈 화면·잠금화면 표시와 크기·위치 등을 조절하세요. 지원 범위는 기기에 따라 달라요.',
  ]),
  AppHelpTopic('collection', '학교 연결과 수집', '최근 수집 상태·간격·세션 재연결 정책을 확인해요.', [
    '학교 연결·수집에서 자동 수집과 간격·세션 종료 후 대기를 확인하세요. 인증이 끊기면 기본 2시간 기다린 뒤 다음 수집에서 다시 연결해요. 다른 기기에서 시험 중이라면 자동 연결을 꺼 주세요.',
    '활동 로그에서 실패 원인과 최근 성공 시각을 확인하세요.',
  ]),
  AppHelpTopic('appearance', '화면과 테마', '색상과 라이트·다크를 선택해요.', [
    '화면 설정에서 테마와 강조 색상을 선택하세요.',
  ]),
  AppHelpTopic('tasks', '할 일 표시 정리', '제출 대기와 마감 지난 항목을 정리해요.', [
    '할 일 표시 설정에서 제출 대기 표시·마감 지난 항목·출석 미반영 콘텐츠 표시 방식을 선택하세요.',
  ]),
];

AppHelpTopic? appHelpTopic(String id) {
  for (final topic in appHelpTopics) {
    if (topic.id == id) return topic;
  }
  return null;
}

/// Accept only known app-owned help routes. No arbitrary setting mutations.
AppHelpTopic? appHelpLink(String? value) {
  final uri = Uri.tryParse(value ?? '');
  if (uri == null ||
      uri.scheme != 'campus-radar' ||
      uri.host != 'help' ||
      uri.userInfo.isNotEmpty ||
      uri.hasPort ||
      uri.hasQuery ||
      uri.hasFragment ||
      uri.pathSegments.length != 1) {
    return null;
  }
  return appHelpTopic(uri.pathSegments.single);
}

String get appHelpKnowledge =>
    '''
캠퍼스레이더의 현재 화면은 오늘 / 할 일 / 과목 / 더보기다.
앱 기능과 사용 경로는 다음 앱 소유 자료를 기준으로 설명하라.
기능 설명에는 수집 정보 공유가 필요하지 않다. 실제 사용자 설정·권한·키 연결 여부는 알 수 없다.
설정을 바꿨다거나 일정 전송을 완료했다고 주장하지 마라. 사용자가 실행할 수 있는 안내 링크를 제시하라.
내부 링크는 아래 목록의 Markdown 링크만 사용하라. 파라미터·실행 명령·새 경로를 만들지 마라.
${appHelpTopics.map((t) => '[${t.title}](${t.link})\n${t.description}\n${t.steps.asMap().entries.map((e) => '${e.key + 1}. ${e.value}').join('\n')}').join('\n\n')}
''';

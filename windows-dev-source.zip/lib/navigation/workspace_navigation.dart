import 'package:flutter/material.dart';
import 'package:campus_radar/home/home_navigation.dart';
import 'package:campus_radar/ai/ai_inbox_page.dart';
import 'package:campus_radar/schedule/timetable_page.dart';
import 'package:campus_radar/schedule/schedule_calendar.dart';

Future<void> openWorkspaceTool(BuildContext context, ScheduleView view) async {
  final Widget page = switch (view) {
    ScheduleView.review => const AiInboxPage(
      showTools: false,
      compactReview: true,
    ),
    ScheduleView.timetable => const TimetablePage(),
    ScheduleView.calendar => Scaffold(
      appBar: AppBar(title: const Text('캘린더')),
      body: const ScheduleCalendar(),
    ),
    ScheduleView.tasks => throw ArgumentError('할 일은 기본 화면에서 열어요.'),
  };
  await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
}

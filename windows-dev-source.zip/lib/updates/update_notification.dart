import 'dart:io';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/notification_gateway.dart';

const updateNotificationTarget = '_updates';
const updateNotificationStyle = NotificationDetails(
  android: AndroidNotificationDetails(
    'app_updates',
    '앱 업데이트',
    channelDescription: '새 정식·개발 버전 안내',
    importance: Importance.defaultImportance,
    priority: Priority.defaultPriority,
  ),
);

/// Returns false when permission is absent so a later check can try again.
Future<bool> showUpdateNotification(Map<String, dynamic> update) async {
  if (!Platform.isAndroid) return false;
  final android = notifications
      .resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin
      >();
  if (await android?.areNotificationsEnabled() != true) return false;
  final label = update['channel'] == 'development' ? '개발 버전' : '정식 릴리스';
  await notifications.show(
    notificationId(updateNotificationTarget),
    '캠퍼스레이더 업데이트 가능',
    '${update['versionName']} · $label — 눌러서 변경 내용과 설치 방법을 확인하세요.',
    updateNotificationStyle,
    payload: updateNotificationTarget,
  );
  return true;
}

typedef UpdateNotifier = Future<bool> Function(Map<String, dynamic> update);

Future<void> notifyNewUpdate(
  Store store,
  Map<String, dynamic> update, {
  UpdateNotifier notifier = showUpdateNotification,
}) async {
  final key = 'updateNotified:${update['channel']}:${update['versionCode']}';
  if (await store.meta(key) != null) return;
  try {
    if (!await notifier(update)) return;
    // Record only a successful display request; denied permission and platform
    // failures must not permanently consume this version's notification.
    await store.setMeta(key, DateTime.now().toUtc().toIso8601String());
    await store.log(
      'notification',
      '업데이트 알림 발송 요청',
      '${update['versionName']} · ${update['channel']} · 앱 업데이트 화면으로 연결해요.',
    );
  } catch (e) {
    await store.log(
      'notification',
      '업데이트 알림 요청 실패',
      withCause('다음 업데이트 확인 때 다시 시도해요.', e),
    );
  }
}

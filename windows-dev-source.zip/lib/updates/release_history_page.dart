import 'package:campus_radar/core/storage_keys.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:campus_radar/updates/release_history.dart';
import 'package:campus_radar/updates/updates.dart';

class ReleaseHistoryPage extends StatefulWidget {
  final int? fromBuild, throughBuild;
  final ReleaseHistoryRepository? repository;
  const ReleaseHistoryPage({
    super.key,
    this.fromBuild,
    this.throughBuild,
    this.repository,
  });
  @override
  State<ReleaseHistoryPage> createState() => _HistoryState();
}

class _HistoryState extends State<ReleaseHistoryPage> {
  late final repository = widget.repository ?? ReleaseHistoryRepository();
  List<ReleaseEntry> entries = [];
  String channel = 'stable';
  int? after, through;
  bool busy = true, recent = true;
  String? message;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      final c = await updateChannel();
      final rows = await repository.read();
      if (!mounted) return;
      setState(() {
        entries = rows;
        channel = c == 'development' ? 'development' : 'stable';
        after = widget.fromBuild ?? p.getInt(PrefKey.updateHistoryPreviousBuild);
        through = widget.throughBuild ?? installedAppBuild;
        recent = after != null && after! < through!;
        busy = false;
      });
      unawaited(refresh());
    } catch (_) {
      if (mounted) {
        setState(() {
          busy = false;
          message = '내역을 읽지 못했어요. 새로고침해 주세요.';
        });
      }
    }
  }

  Future<void> refresh() async {
    setState(() {
      busy = true;
      message = null;
    });
    try {
      final rows = await repository.refresh();
      if (mounted) {
        setState(() {
          entries = rows;
          message = '최신 내역을 확인했어요.';
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() => message = '최신 내역에 연결하지 못했어요. 앱에 저장된 내역을 표시해요.');
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final rows = selectReleaseHistory(
      entries,
      channel: channel,
      after: recent ? after : null,
      through: recent ? through : null,
    );
    return Scaffold(
      appBar: AppBar(
        title: const Text('업데이트 내역'),
        actions: [
          IconButton(
            tooltip: '내역 새로고침',
            onPressed: busy ? null : refresh,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('버전별로 달라진 점을 확인하세요. 개발 버전에는 정식·개발 버전 내역이 함께 표시돼요.'),
          const SizedBox(height: 16),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'stable', label: Text('정식 버전')),
              ButtonSegment(value: 'development', label: Text('개발 모드')),
            ],
            selected: {channel},
            onSelectionChanged: (s) => setState(() => channel = s.single),
          ),
          const SizedBox(height: 12),
          if (after != null && through != null && after! < through!)
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('이번 업데이트에 포함된 내역만'),
              subtitle: Text('빌드 $after 이후 ~ $through · 건너뛴 버전도 함께 표시'),
              value: recent,
              onChanged: (v) => setState(() => recent = v),
            ),
          if (busy) const LinearProgressIndicator(),
          if (message != null)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Text(message!),
            ),
          if (!busy && rows.isEmpty)
            const Padding(
              padding: EdgeInsets.all(20),
              child: Text('선택한 범위에 기록된 업데이트가 없어요. 전체 내역이나 다른 모드를 확인하세요.'),
            ),
          for (final row in rows)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${row.version} (${row.build}) · ${channelLabel(row.channel)}',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    Text(
                      DateTime.parse(row.date)
                          .toUtc()
                          .add(const Duration(hours: 9))
                          .toIso8601String()
                          .substring(0, 10),
                      style: Theme.of(context).textTheme.labelMedium,
                    ),
                    const SizedBox(height: 10),
                    for (final change in row.changes)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Text('• $change'),
                      ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

import 'package:campus_radar/core/storage_keys.dart';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:campus_radar/updates/update_download.dart';

class ReleaseEntry {
  final String version, channel, date;
  final int build;
  final List<String> changes;
  const ReleaseEntry(
    this.version,
    this.build,
    this.channel,
    this.date,
    this.changes,
  );
  factory ReleaseEntry.parse(Map<String, dynamic> row) {
    final version = row['versionName'], build = row['versionCode'];
    final channel = row['channel'], date = row['publishedAt'];
    final changes = row['changes'];
    if (version is! String ||
        version.isEmpty ||
        version.length > 80 ||
        build is! int ||
        build < 1 ||
        !['stable', 'development'].contains(channel) ||
        date is! String ||
        !RegExp(r'^\d{4}-\d{2}-\d{2}T').hasMatch(date) ||
        DateTime.tryParse(date) == null ||
        changes is! List ||
        changes.isEmpty ||
        changes.length > 30 ||
        changes.any((v) => v is! String || v.isEmpty || v.length > 12000)) {
      throw const FormatException('업데이트 내역 형식을 확인하지 못했어요.');
    }
    return ReleaseEntry(
      version,
      build,
      channel as String,
      date,
      changes.cast<String>(),
    );
  }
}

List<ReleaseEntry> parseReleaseHistory(String raw) {
  if (raw.length > 500000) throw const FormatException('내역 크기 초과');
  final data = jsonDecode(raw);
  if (data is! Map ||
      data['schemaVersion'] != 1 ||
      data['releases'] is! List ||
      (data['releases'] as List).length > 500) {
    throw const FormatException('업데이트 내역 형식 오류');
  }
  final seen = <String>{};
  return (data['releases'] as List).map((r) {
    final entry = ReleaseEntry.parse(Map<String, dynamic>.from(r as Map));
    if (!seen.add('${entry.channel}:${entry.build}')) {
      throw const FormatException('중복된 업데이트 내역');
    }
    return entry;
  }).toList();
}

List<ReleaseEntry> selectReleaseHistory(
  List<ReleaseEntry> entries, {
  required String channel,
  int? after,
  int? through,
}) {
  final rows = entries
      .where(
        (e) =>
            (channel == 'development' || e.channel == 'stable') &&
            (after == null || e.build > after) &&
            (through == null || e.build <= through),
      )
      .toList();
  rows.sort(
    (a, b) =>
        after == null ? b.build.compareTo(a.build) : a.build.compareTo(b.build),
  );
  return rows;
}

typedef HistoryLoader = Future<String> Function();

class ReleaseHistoryRepository {
  final HistoryLoader bundled, remote;
  ReleaseHistoryRepository({HistoryLoader? bundled, HistoryLoader? remote})
    : bundled =
          bundled ??
          (() => rootBundle.loadString('assets/update-history.json')),
      remote =
          remote ??
          (() async => utf8.decode(
            await downloadUpdateFile(
              Uri.parse(
                'https://raw.githubusercontent.com/lemoncube7/campus-radar/main/updates/history.json?check=${DateTime.now().millisecondsSinceEpoch}',
              ),
              limit: 500000,
              deadline: DateTime.now().add(const Duration(seconds: 20)),
            ),
          ));
  Future<List<ReleaseEntry>> read() async {
    final prefs = await SharedPreferences.getInstance();
    final base = parseReleaseHistory(await bundled());
    final merged = {for (final e in base) '${e.channel}:${e.build}': e};
    final cached = prefs.getString(PrefKey.releaseHistoryV1);
    if (cached != null) {
      try {
        for (final e in parseReleaseHistory(cached)) {
          merged['${e.channel}:${e.build}'] = e;
        }
      } catch (_) {
        /* keep bundled fallback */
      }
    }
    return merged.values.toList();
  }

  Future<List<ReleaseEntry>> refresh() async {
    final raw = await remote();
    parseReleaseHistory(raw);
    final prefs = await SharedPreferences.getInstance();
    if (!await prefs.setString(PrefKey.releaseHistoryV1, raw)) {
      throw StateError('내역 저장 실패');
    }
    return read();
  }
}

import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';

import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/courses/course_catalog.dart' show courseKey;
import 'package:campus_radar/schedule/cancellation_repository.dart';

/// Machine-readable copy of the phone's academic state, uploaded next to the
/// human-readable Drive documents. The Windows viewer mirrors it into its own
/// local store instead of logging into the school itself.
///
/// Allow-list only: no school credentials, cookies, download form fields,
/// HTML, Google tokens, AI keys or chats, activity logs or friend timetables.
const appSnapshotPath = '캠퍼스레이더 앱 데이터.json';
const appSnapshotSchema = 1;

/// Single-value meta keys copied as-is.
const _metaKeys = [
  MetaKey.lastSuccess,
  MetaKey.noticeError,
  MetaKey.taskDetailWarnings,
  MetaKey.overduePolicy,
  MetaKey.courses,
  MetaKey.timetableEntries,
  MetaKey.timetableSavedAt,
  MetaKey.academicLinkChecks,
  CancellationRepository.key,
];

/// Per-entity meta families copied as-is (`family:id`).
const _metaFamilies = [
  'excluded:',
  'notTask:',
  'overdueRestored:',
  'coursePlan:',
  'discovered:',
  'mediaChecked:',
  // Schedules found in notices (review box, timeline). Shown read-only.
  'aiCandidate:',
  'aiApproval:',
  'aiState:',
];
const _aiFamilies = {'aiCandidate:', 'aiApproval:', 'aiState:'};

/// Display preferences the PC should show the same way (course nicknames and
/// colors).
const _prefKeys = [PrefKey.courseAliases, PrefKey.courseColorOverrides];

String appSnapshotDigest(String text) =>
    sha256.convert(utf8.encode(text)).toString();

Map<String, dynamic> _context(Map<String, dynamic> c) => {
  for (final k in const ['course_id', 'class_no', 'course_nm'])
    if (c[k] != null) k: c[k],
};

Map<String, dynamic> _item(CampusItem i) {
  final j = i.toJson()
    ..remove('evaluation') // grades and feedback stay on the phone
    ..['context'] = _context(i.context);
  final body = j['body'] as String? ?? '';
  if (body.length > 20000) j['body'] = body.substring(0, 20000);
  if ('${j['bodyHtml']}'.length > 120000) j['bodyHtml'] = '';
  return j;
}

Map<String, dynamic> _notice(CampusNotice n) {
  final j = n.toJson()..['context'] = _context(n.context);
  if ('${j['bodyHtml']}'.length > 120000) j['bodyHtml'] = '';
  final body = j['body'] as String? ?? '';
  if (body.length > 24000) j['body'] = body.substring(0, 24000);
  return j;
}

/// Same scope switches as the Drive documents. [selectedCourses] holds course
/// names (`course_nm`); null means every course.
Future<Map<String, dynamic>> buildAppSnapshot(
  Store store, {
  required String profileId,
  Set<String>? selectedCourses,
  bool tasks = true,
  bool notices = true,
  bool materials = true,
  bool timetable = true,
  bool plans = true,
}) async {
  final prefs = await SharedPreferences.getInstance();
  bool chosen(String course) =>
      selectedCourses == null || selectedCourses.contains(course);
  final meta = <String, String>{};
  for (final k in _metaKeys) {
    if (!timetable &&
        (k == MetaKey.timetableEntries ||
            k == MetaKey.timetableSavedAt ||
            k == CancellationRepository.key)) {
      continue;
    }
    final v = await store.meta(k);
    if (v != null) meta[k] = v;
  }
  if (meta[MetaKey.courses] != null) {
    // Catalog rows carry more school fields than the viewer needs.
    meta[MetaKey.courses] = jsonEncode([
      for (final c in jsonDecode(meta[MetaKey.courses]!) as List)
        if (c is Map && chosen('${c['course_nm']}'))
          _context(Map<String, dynamic>.from(c)),
    ]);
  }
  final items = (await store.items()).where((i) {
    if (!chosen(i.course)) return false;
    if (i.type == 'LS') return materials;
    return tasks;
  }).toList();
  final keys = items.map((i) => i.key).toSet();
  final planKeys = <String>{
    if (plans && meta[MetaKey.courses] != null)
      for (final c in jsonDecode(meta[MetaKey.courses]!) as List)
        if (c is Map)
          MetaKey.coursePlan(courseKey(Map<String, dynamic>.from(c))),
  };
  for (final r in await store.db.query('meta')) {
    final id = r['id'] as String;
    final family = _metaFamilies.where(id.startsWith).firstOrNull;
    if (family == null) continue;
    final ok = family == 'coursePlan:'
        ? planKeys.contains(id)
        : _aiFamilies.contains(family)
        // AI rows are keyed by notice/schedule, not by course: only sent when
        // every course is exported, so a course filter cannot leak through.
        ? notices && selectedCourses == null
        : keys.contains(id.substring(family.length));
    if (ok) meta[id] = r['value'] as String;
  }
  return {
    'format': 'campus-radar-app',
    'schema': appSnapshotSchema,
    'profileId': profileId,
    'collectedAt': meta[MetaKey.lastSuccess],
    'timezone': 'Asia/Seoul',
    'items': items.map(_item).toList(),
    'notices': notices
        ? (await store.notices())
              .where((n) => chosen(n.course))
              .map(_notice)
              .toList()
        : const [],
    'meta': meta,
    'prefs': {
      for (final k in _prefKeys)
        if (prefs.getString(k) != null) k: prefs.getString(k),
    },
  };
}

/// Validates [text] and mirrors it into [store] in one transaction. Throws
/// [FormatException] and leaves the store untouched when anything is off.
Future<AppSnapshotInfo> applyAppSnapshot(Store store, String text) async {
  final j = jsonDecode(text);
  if (j is! Map || j['format'] != 'campus-radar-app' || j['schema'] is! int) {
    throw const FormatException('앱 데이터 형식이 아니에요.');
  }
  if (j['schema'] as int > appSnapshotSchema) {
    throw const FormatException('폰 앱이 더 새 형식으로 내보냈어요. PC 앱을 업데이트해 주세요.');
  }
  final items = [
    for (final m in j['items'] as List)
      CampusItem.fromJson(Map<String, dynamic>.from(m as Map)),
  ];
  final notices = [
    for (final m in j['notices'] as List)
      CampusNotice.fromJson(Map<String, dynamic>.from(m as Map)),
  ];
  final meta = Map<String, String>.from(j['meta'] as Map);
  if (meta[MetaKey.lastSuccess] == null) {
    throw const FormatException('수집 기록이 없는 자료예요.');
  }
  await store.db.transaction((txn) async {
    await txn.delete('items');
    await txn.delete('notices');
    for (final k in _metaKeys) {
      await txn.delete('meta', where: 'id=?', whereArgs: [k]);
    }
    for (final f in _metaFamilies) {
      await txn.delete('meta', where: 'id LIKE ?', whereArgs: ['$f%']);
    }
    final batch = txn.batch();
    for (final i in items) {
      batch.insert('items', {
        'id': i.key,
        'payload': jsonEncode(i.toJson()),
      }, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    for (final n in notices) {
      batch.insert('notices', {
        'id': n.id,
        'payload': jsonEncode(n.toJson()),
      }, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    for (final e in meta.entries) {
      final allowed =
          _metaKeys.contains(e.key) || _metaFamilies.any(e.key.startsWith);
      if (!allowed) continue;
      batch.insert('meta', {
        'id': e.key,
        'value': e.value,
      }, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await batch.commit(noResult: true);
  });
  final prefs = await SharedPreferences.getInstance();
  final shared = j['prefs'];
  for (final k in _prefKeys) {
    final v = shared is Map ? shared[k] : null;
    if (v is String) {
      await prefs.setString(k, v);
    } else {
      await prefs.remove(k);
    }
  }
  return AppSnapshotInfo(
    profileId: '${j['profileId']}',
    collectedAt: DateTime.tryParse(meta[MetaKey.lastSuccess]!),
    items: items.length,
    notices: notices.length,
  );
}

class AppSnapshotInfo {
  final String profileId;
  final DateTime? collectedAt;
  final int items, notices;
  const AppSnapshotInfo({
    required this.profileId,
    required this.collectedAt,
    required this.items,
    required this.notices,
  });
}

import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/campus/academic_attachment.dart';
import 'dart:convert';
import 'package:archive/archive.dart';
import 'package:crypto/crypto.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/courses/course_catalog.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';
import 'package:campus_radar/campus/material_catalog.dart';

class AcademicExport {
  final Map<String, String> documents;
  final String profileId;
  final Map<String, List<int>> originals;
  const AcademicExport(
    this.documents,
    this.profileId, [
    this.originals = const {},
  ]);
  List<int> zip() {
    final archive = Archive();
    for (final e in documents.entries) {
      final bytes = utf8.encode(e.value);
      archive.addFile(ArchiveFile(e.key, bytes.length, bytes));
    }
    for (final e in originals.entries) {
      archive.addFile(ArchiveFile(e.key, e.value.length, e.value));
    }
    return ZipEncoder().encode(archive);
  }
}

/// A readable, bounded snapshot. No generic model/context serialization.
AcademicExport packAcademicDocuments({
  required String profileId,
  required DateTime at,
  required DateTime? collectedAt,
  required Map<String, String> documents,
  List<String> warnings = const [],
  bool fixture = false,
  Map<String, List<int>> originals = const {},
}) {
  if (!RegExp(r'^[a-f0-9]{32}$').hasMatch(profileId)) {
    throw const FormatException('내보내기 프로필이 올바르지 않아요.');
  }
  if (documents.length > 250) throw const FormatException('문서 수가 너무 많습니다.');
  var total = 0;
  for (final e in documents.entries) {
    if (!RegExp(r'^(?:과목/)?[^/\\\x00-\x1f]+\.(txt|md)$').hasMatch(e.key) ||
        e.key.contains('..') ||
        e.key == '캠퍼스레이더 시작.txt') {
      throw const FormatException('문서 경로가 올바르지 않아요.');
    }
    final n = utf8.encode(e.value).length;
    total += n;
    if (n > 1048576 || total > 8388608) {
      throw const FormatException(
        '내보낼 자료가 크기 제한(문서 1MB·전체 8MB)을 넘었어요. 일부만 저장하지 않았어요.',
      );
    }
  }
  var binaryBytes = 0;
  if (originals.length > 5) {
    throw const FormatException('원본은 한 번에 최대 5개까지 포함할 수 있어요.');
  }
  for (final e in originals.entries) {
    if (!RegExp(r'^원본/[a-f0-9]{16}\.[a-z0-9]{1,8}$').hasMatch(e.key) ||
        e.value.length > 10 * 1024 * 1024) {
      throw const FormatException('원본 파일 경로/크기 제한을 확인해 주세요.');
    }
    binaryBytes += e.value.length;
  }
  if (binaryBytes > 20 * 1024 * 1024) {
    throw const FormatException('원본 합계는 최대 20MB이에요.');
  }
  final index = {
    'formatVersion': 1,
    'profileId': profileId,
    'fixture': fixture,
    'exportedAt': at.toUtc().toIso8601String(),
    'collectedAt': collectedAt?.toUtc().toIso8601String(),
    'timezone': 'Asia/Seoul',
    'warnings': warnings,
    // Rules travel with the data so an AI that reads this file through a
    // storage connector answers correctly without an installed skill.
    'readingRules': academicReadingRules,
    'documents': [
      for (final e in documents.entries)
        {
          // Extracted attachments have opaque paths; their first line names
          // the course and material.
          'title': e.key.startsWith('과목/첨부_')
              ? e.value.split('\n').first
              : e.key.replaceAll('.txt', ''),
          'path': e.key,
        },
    ],
    'attachments': originals.isEmpty
        ? '첨부 원본 미포함 · 자료 인덱스/선택한 추출 텍스트 확인'
        : '사용자가 선택한 원본 ${originals.length}개 포함',
    'originalFiles': originals.keys.toList(),
    'refresh': '수동 스냅샷 · 새 내보내기 전까지 갱신되지 않음',
  };
  return AcademicExport(
    {
      '캠퍼스레이더 시작.txt':
          'CAMPUS_RADAR_START_V1\n${const JsonEncoder.withIndent('  ').convert(index)}',
      ...documents,
    },
    profileId,
    originals,
  );
}

Future<AcademicExport> buildAcademicExport(
  Store store,
  String profileId, {
  DateTime? now,
  bool includeLinks = true,
  bool markdown = false,
  Set<String>? selectedCourses,
  bool exportTasks = true,
  bool exportNotices = true,
  bool exportMaterials = true,
  bool exportTimetable = true,
  bool exportPlans = true,
  Map<String, Map<String, dynamic>> linkChecks = const {},
  Map<String, AttachmentText> attachmentTexts = const {},
  Map<String, List<int>> originals = const {},
  List<String> attachmentWarnings = const [],
}) async {
  final at = (now ?? DateTime.now()).toUtc();
  final collected = DateTime.tryParse(
    await store.meta(MetaKey.lastSuccess) ?? '',
  );
  if (collected == null) throw const FormatException('먼저 학교 자료를 한 번 수집해 주세요.');
  final hidden = await store.excluded(), nonTasks = await store.notTasks();
  bool chosen(String name) =>
      selectedCourses == null || selectedCourses.contains(name);
  final items = exportTasks
      ? (await store.items()).where((i) => chosen(i.course)).toList()
      : <CampusItem>[];
  final notices = exportNotices
      ? (await store.notices()).where((n) => chosen(n.course)).toList()
      : <CampusNotice>[];
  if (items.length > 2000 || notices.length > 500) {
    throw const FormatException('자료 건수 제한을 초과했어요.');
  }
  String date(DateTime? d) => d == null ? '미확인' : koreanTime(d);
  final overview = StringBuffer(
    '학업 현황 · 저장된 자료 기준\n수집: ${date(collected)}\n내보냄: ${date(at)}\n숨김/할 일 아님/시작 전 상태를 반드시 구별하세요.\n\n',
  );
  for (final i in items) {
    overview.writeln(
      '${i.course} | ${i.title}\n종류: ${i.type} · 상태: ${i.status} · 공개: ${i.published}\n시작: ${date(i.startsAt)} · 마감: ${date(i.due)} · 추가 제출 마감: ${date(i.additionalDue)}\n숨김: ${hidden.contains(i.key)} · 할 일 아님: ${nonTasks.contains(i.key)} · 출석 반영: ${i.attendanceRequired ?? '미확인'}\n',
    );
  }
  final slots = decodeSlots(await store.meta(MetaKey.timetableEntries))
      .where(
        (e) =>
            exportTimetable &&
            chosen(e.course) &&
            !e.courseKey.startsWith('personal:'),
      )
      .toList();
  final cancellationRead = await CancellationRepository(store).read();
  final schedule = StringBuffer(
    '내 주간 시간표 · Asia/Seoul\n개인 반복 일정과 친구 시간표는 제외했어요.\n\n',
  );
  for (final s in slots) {
    schedule.writeln(
      '${s.course} | ${weekNames[s.weekday - 1]} ${slotTime(s.start)}–${slotTime(s.end)} | ${s.room}',
    );
  }
  schedule.writeln('\n저장된 날짜별 휴강 (아래 날짜만 제외, 보강 추측 금지)');
  for (final c in cancellationRead.entries) {
    final slot = slots.where((s) => s.id == c.slotId).firstOrNull;
    if (slot != null) {
      schedule.writeln(
        '${c.date} | ${slot.course} | ${slotTime(slot.start)}–${slotTime(slot.end)}',
      );
    }
  }
  final courseDocs = <String, StringBuffer>{};
  StringBuffer doc(String course) => courseDocs.putIfAbsent(
    course,
    () => StringBuffer(
      '$course\n약칭: ${courseLabel(course)}\n수집: ${date(collected)}\n첨부 원본은 포함되지 않았어요.\n\n',
    ),
  );
  for (final n in notices) {
    doc(n.course).writeln(
      '## 공지: ${n.title}\n게시: ${date(n.published)} · 본문 수집: ${n.bodyFetched}\n${n.body}\n',
    );
  }
  for (final m in (await studyMaterials(
    store,
    now: at,
  )).where((m) => exportMaterials && chosen(m.course))) {
    final d = doc(m.course);
    if (m.sourceType == 'NT' && m.body.isNotEmpty) continue;
    if (m.body.isNotEmpty) {
      d.writeln('## ${m.sourceType} 자료: ${m.title}\n${m.body}\n');
    } else if (m.media != null) {
      d.writeln('첨부 목록: ${m.title} → ${m.name} (원본 미포함)');
    } else {
      d.writeln('외부 링크 항목: ${m.title} (이 내보내기에는 주소 미포함)');
    }
  }
  for (final c in (await readCourses(
    store,
  )).where((c) => exportPlans && chosen('${c['course_nm']}'))) {
    final raw = await store.meta(MetaKey.coursePlan(courseKey(c)));
    if (raw == null) continue;
    final plan = jsonDecode(raw) as Map;
    if (plan['linkedText'] is String) {
      doc('${c['course_nm']}').writeln(
        '## 저장된 강의계획서\n계획서 수집: ${plan['fetchedAt'] ?? '미확인'}\n${plan['linkedText']}\n',
      );
    }
  }
  final materials = (await studyMaterials(
    store,
    now: at,
  )).where((m) => exportMaterials && chosen(m.course)).toList();
  final fileIndex = StringBuffer(
    '첨부 자료 인덱스\n학교 직접 링크도 현재 AI 도구에서 읽히지 않을 수 있어요. 상태는 기기 네트워크의 관측 결과이며 LLM 읽기 성공을 뜻하지 않아요.\n',
  );
  final extracted = <String, String>{};
  for (final m in materials.where((m) => m.media != null)) {
    final media = m.media!;
    final check = linkChecks[m.id];
    final status =
        check?['status'] as String? ??
        (media.form.isNotEmpty ? 'postRequired' : 'unknown');
    fileIndex.writeln(
      '\n## ${m.course} · ${m.title}\n첨부: ${m.name} · ${media.size ?? '크기 미확인'}바이트\n접근: ${attachmentAccessLabel(status)} · 검사 시각: ${check?['checkedAt'] ?? '없음'}',
    );
    final url = includeLinks ? directAcademicUrl(media) : null;
    if (url != null) fileIndex.writeln('학교 원본 주소(비공개 보관): $url');
    final text = attachmentTexts[m.id];
    if (text != null) {
      fileIndex.writeln('텍스트 추출: ${text.note} · 일부 추출: ${text.partial}');
      if (text.text.trim().isNotEmpty) {
        final path = '과목/첨부_${m.id.substring(0, 16)}.txt';
        extracted[path] =
            '${m.course} · ${m.title}\n첨부: ${m.name}\n추출 방식: ${text.note} · 일부 추출: ${text.partial}\n${text.text}';
        fileIndex.writeln(
          '추출 문서: ${markdown ? path.replaceAll('.txt', '.md') : path}',
        );
      }
    }
    final original = originals.keys
        .where((p) => p.startsWith('원본/${m.id.substring(0, 16)}.'))
        .firstOrNull;
    if (original != null) fileIndex.writeln('선택 원본 경로: $original');
  }
  String outputPath(String p) => markdown ? p.replaceAll('.txt', '.md') : p;
  return packAcademicDocuments(
    profileId: profileId,
    at: at,
    collectedAt: collected,
    warnings: [
      if ((await store.meta(MetaKey.noticeError) ?? '').isNotEmpty)
        '최근 공지 수집에 실패했어요.',
      if (cancellationRead.invalidRows > 0 || cancellationRead.recovered)
        '일부 휴강 기록을 복구하거나 제외했어요.',
      ...attachmentWarnings,
      '실시간 연결이 아니에요. 새로 내보내고 저장소 파일을 교체해야 갱신돼요.',
    ],
    originals: originals,
    documents: {
      outputPath('첨부 자료 인덱스.txt'): fileIndex.toString(),
      for (final e in extracted.entries) outputPath(e.key): e.value,
      outputPath('학업 현황.txt'): overview.toString(),
      if (exportTimetable) outputPath('시간표.txt'): schedule.toString(),
      for (final e in courseDocs.entries)
        outputPath('과목/${_courseFilename(e.key)}.txt'): e.value.toString(),
    },
  );
}

String _courseFilename(String name) {
  final safe = name.replaceAll(RegExp(r'[^가-힣A-Za-z0-9 _-]'), '_');
  return '${safe.substring(0, safe.length.clamp(0, 60))}_${sha256.convert(utf8.encode(name)).toString().substring(0, 12)}';
}

const academicReadingRules = [
  '이 자료는 캠퍼스레이더가 학교 사이트에서 수집한 기록이에요. 답할 때 수집 시각(collectedAt)을 함께 알려 주세요. 하루 넘게 지났으면 앱에서 새로 수집하라고 안내해 주세요.',
  '남은 할 일·마감을 답할 때는 학업 현황에서 숨김: true, 할 일 아님: true, 공개: false, 상태: done/available 항목을 빼요. 사용자가 직접 물을 때만 따로 알려 주세요.',
  '종류 LR은 과제, LV는 콘텐츠(출석 반영 표시 확인), LE는 시험, LS는 자료실 자료예요. 상태 unknown은 제출 여부를 확인하지 못한 항목이라 미제출로 단정하지 마세요.',
  '모든 시각은 한국 시간(Asia/Seoul)이에요. 수업은 시간표.txt 기준이며, 아래에 적힌 휴강 날짜 외의 휴강·보강은 추측하지 마세요.',
  '과목별 공지·자료는 과목/ 폴더 문서에서 확인하고, 학교 원문과 다를 수 있으니 중요한 제출은 사이버캠퍼스에서 다시 확인하라고 안내해 주세요.',
];

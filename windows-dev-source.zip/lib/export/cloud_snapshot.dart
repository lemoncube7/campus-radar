import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/campus/material_catalog.dart' show studyMaterials;
import 'package:campus_radar/campus/learning_resources.dart';
import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:campus_radar/ai/ai_timetable.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/courses/course_labels.dart';

const radarCloudOrigin =
    'https://campus-radar-connect.lemoncube07.chatgpt.site';
String cloudId(String id) => sha256.convert(utf8.encode(id)).toString();
String _clip(String text, int n) =>
    text.length <= n ? text : text.substring(0, n);

/// Allow-list only. Never serialize model context, HTML, media or credentials.
Future<Map<String, dynamic>> buildCloudSnapshot(
  Store store, {
  DateTime? now,
}) async {
  final at = (now ?? DateTime.now()).toUtc();
  final collected = DateTime.tryParse(await store.meta(MetaKey.lastSuccess) ?? '');
  if (collected == null) throw StateError('NO_COLLECTION');
  final items = await store.items(), notices = await store.notices();
  // Fail closed instead of silently claiming that a truncated task list is complete.
  if (items.length > 2000 || notices.length > 300) {
    throw StateError('SNAPSHOT_LIMIT');
  }
  final excluded = await store.excluded();
  final timetable = await aiTimetableContext(store, now: at);
  return {
    'schemaVersion': await store.meta(MetaKey.cloudMaterialsConsent) == 'yes' ? 2 : 1,
    if (await store.meta(MetaKey.cloudMaterialsConsent) == 'yes')
      'materials': (await studyMaterials(
        store,
        now: at,
      )).map((m) => m.toCloudJson()).toList(),
    'capturedAt': at.toIso8601String(),
    'collectedAt': collected.toUtc().toIso8601String(),
    'timezone': 'Asia/Seoul',
    'noticeCollectionFailed':
        (await store.meta(MetaKey.noticeError) ?? '').isNotEmpty,
    'taskDetailWarningCount':
        int.tryParse(await store.meta(MetaKey.taskDetailWarnings) ?? '') ?? 0,
    'items': items
        .where(
          (i) =>
              const {'LR', 'LV', 'LS', 'LD', 'LT', 'LQ', 'LE'}.contains(i.type),
        )
        .map(
          (i) => {
            'id': cloudId(i.key),
            'type': i.type,
            'title': _clip(i.title, 600),
            'course': _clip(i.course, 160),
            'alias': _clip(courseLabel(i.course), 160),
            'status': ['pending', 'done'].contains(i.status)
                ? i.status
                : 'unknown',
            'startsAt': i.startsAt?.toUtc().toIso8601String(),
            'originalDue': i.originalDue?.toUtc().toIso8601String(),
            'additionalStartsAt': i.additionalStartsAt
                ?.toUtc()
                .toIso8601String(),
            'additionalDue': i.additionalDue?.toUtc().toIso8601String(),
            'progress': i.progress,
            'externalUrl': safeExternalLink(i.externalUrl, cloud: true),
            'due': i.due?.toUtc().toIso8601String(),
            'published': i.published,
            'attendanceRequired': i.attendanceRequired,
            'hidden': excluded.contains(i.key),
          },
        )
        .toList(),
    'notices': notices
        .map(
          (n) => {
            'id': cloudId(n.id),
            'title': _clip(n.title, 600),
            'course': _clip(n.course, 160),
            'alias': _clip(courseLabel(n.course), 160),
            'body': _clip(n.body, 24000),
            'bodyLoaded': n.bodyFetched,
            'bodyTruncated': n.body.length > 24000,
            'publishedAt': n.published?.toUtc().toIso8601String(),
          },
        )
        .toList(),
    'timetable': {
      'savedAt': DateTime.tryParse(
        '${timetable['savedAt'] ?? ''}',
      )?.toUtc().toIso8601String(),
      'generatedAt': at.toIso8601String(),
      'coverageThrough': at
          .add(const Duration(hours: 9, days: 14))
          .toIso8601String()
          .substring(0, 10),
      'limitations': timetable['limits'],
      'upcoming': (timetable['upcoming'] as List)
          .map(
            (dynamic r) => {
              'course': _clip(r['course'] as String, 160),
              'date': r['date'],
              'start': r['start'],
              'end': r['end'],
              'room': _clip(r['room'] as String, 200),
            },
          )
          .toList(),
    },
  };
}

class CloudConnection {
  final String deviceId, deviceToken, gateToken, expiresAt;
  CloudConnection(
    this.deviceId,
    this.deviceToken,
    this.gateToken,
    this.expiresAt,
  );
  factory CloudConnection.parse(String text) {
    final j = jsonDecode(text) as Map<String, dynamic>;
    if (j['version'] != 1 ||
        j['server'] != radarCloudOrigin ||
        !RegExp(r'^[a-f0-9-]{36}$').hasMatch('${j['deviceId']}') ||
        !RegExp(r'^[a-f0-9]{64}$').hasMatch('${j['deviceToken']}') ||
        j['gateToken'] is! String ||
        (j['gateToken'] as String).length < 16 ||
        (j['gateToken'] as String).contains(RegExp(r'[\r\n]')) ||
        DateTime.tryParse('${j['expiresAt']}') == null) {
      throw const FormatException('연결 정보 형식이 올바르지 않아요.');
    }
    return CloudConnection(
      j['deviceId'],
      j['deviceToken'],
      j['gateToken'],
      j['expiresAt'],
    );
  }
}

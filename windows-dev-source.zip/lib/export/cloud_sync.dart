import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/export/cloud_materials.dart';
import 'package:campus_radar/core/sync_timing.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/export/cloud_snapshot.dart';
import 'package:campus_radar/core/session_scope.dart';

Future<bool> sendCloud(Store store, {bool disconnect = false, SyncTiming? timing}) async {
  if (!disconnect && await store.meta(MetaKey.cloudEnabled) != 'yes') return false;
  final raw = await credentials.read(key: 'cloudConnection');
  if (raw == null ||
      await credentials.read(key: 'cloudLocalAccount') !=
          await credentials.read(key: 'id')) {
    return false;
  }
  final connection = CloudConnection.parse(raw);
  final scope = await SessionScope.capture(
    store,
    consents: disconnect ? const {} : const {'cloudEnabled': 'yes'},
  );
  final payload = disconnect
      ? <String, dynamic>{}
      : await (timing?.measure('스냅샷 구성', () => buildCloudSnapshot(store)) ?? buildCloudSnapshot(store));
  final bytes = utf8.encode(jsonEncode(payload));
  if (bytes.length > 2000000) throw StateError('SNAPSHOT_LIMIT');
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
  final watcher = scope.watch(() => client.close(force: true));
  try {
    Future<void> request() async {
      await scope.verify();
      final req = await client.postUrl(
        Uri.parse(
          '$radarCloudOrigin/api/${disconnect ? 'device-disconnect' : 'snapshot'}',
        ),
      );
      req.followRedirects = false;
      req.headers.set(
        'OAI-Sites-Authorization',
        'Bearer ${connection.gateToken}',
      );
      req.headers.set(
        HttpHeaders.authorizationHeader,
        'Bearer ${connection.deviceToken}',
      );
      req.headers.set('X-Radar-Device', connection.deviceId);
      req.headers.contentType = ContentType.json;
      req.add(bytes);
      final response = await req.close();
      // Do not retain or log server response bodies (they may contain identifiers).
      await response.drain<void>();
      if (response.statusCode != 200) {
        throw HttpException('CLOUD_HTTP_${response.statusCode}');
      }
      await scope.verify();
    }

    Future<void> sendSnapshot() => request().timeout(const Duration(seconds: 20));
    await (timing?.measure('스냅샷 HTTP 전송', sendSnapshot) ?? sendSnapshot());
    if (!disconnect) {
      await store.setMeta(MetaKey.cloudLastUploaded,
        DateTime.now().toUtc().toIso8601String(),
      );
    }
    if (!disconnect) {
      await uploadCloudMaterials(store, connection, timing: timing);
    }
    return true;
  } finally {
    watcher.cancel();
    client.close(force: true);
  }
}

Future<void> cloudAfterSync(Store store, {SyncTiming? timing}) async {
  try {
    if (await sendCloud(store, timing: timing)) {
      await store.setMeta(MetaKey.cloudError, '');
      await store.log(
        'sync',
        '플러그인 자료 동기화 완료',
        '과제·공지·시간표를 비공개 조회 서버에 전송했어요.',
      );
    }
  } catch (e) {
    await store.setMeta(MetaKey.cloudError,
      '동기화하지 못했어요. 네트워크·기기 연결 만료를 확인해 주세요. 다음 수집 후 다시 시도해요.',
    );
    await store.log(
      'sync',
      '플러그인 동기화 대기',
      withCause('학교 수집 결과는 유지했어요. 다음 수집 또는 연결 설정에서 다시 시도할 수 있어요.', e),
    );
  }
}

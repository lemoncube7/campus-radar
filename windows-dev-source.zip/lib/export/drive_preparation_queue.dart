/// Serialize preparations within one isolate. A manual request always gets a
/// fresh preparation after an automatic attempt, including a failed one.
class DrivePreparationQueue {
  Future<void>? _active;
  Future<void> run({
    required bool manual,
    required Future<void> Function() prepare,
  }) async {
    while (_active != null) {
      final pending = _active!;
      try {
        await pending;
      } catch (error, stack) {
        // The original caller owns its failure log; a manual retry must proceed.
        if (!manual) Error.throwWithStackTrace(error, stack);
      }
      if (!manual) return;
    }
    final work = Future<void>.sync(prepare);
    _active = work;
    try {
      await work;
    } finally {
      if (identical(_active, work)) _active = null;
    }
  }
}

import 'package:campus_radar/core/storage_keys.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:campus_radar/core/adaptive_content.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/export/cloud_snapshot.dart';
import 'package:campus_radar/export/cloud_sync.dart';

class CloudSettingsPage extends StatefulWidget {
  const CloudSettingsPage({super.key});
  @override
  State<CloudSettingsPage> createState() => _CloudSettingsPageState();
}

class _CloudSettingsPageState extends State<CloudSettingsPage> {
  final input = TextEditingController();
  bool enabled = false, busy = false;
  String status = '불러오는 중';
  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void dispose() {
    input.dispose();
    super.dispose();
  }

  Future<void> load() async {
    final s = await Store.open();
    try {
      final on = await s.meta(MetaKey.cloudEnabled) == 'yes';
      final last = await s.meta(MetaKey.cloudLastUploaded);
      final error = await s.meta(MetaKey.cloudError) ?? '';
      final materials = await s.meta(MetaKey.cloudMaterialsStatus) ?? '';
      if (mounted) {
        setState(() {
          enabled = on;
          status =
              (error.isNotEmpty ? error : '마지막 전송: ${last ?? '아직 없음'}') +
              (materials.isEmpty ? '' : '\n$materials');
        });
      }
    } finally {
      await s.db.close();
    }
  }

  Future<void> action(Future<void> Function(Store) run) async {
    setState(() => busy = true);
    Store? s;
    try {
      s = await Store.open();
      await run(s);
      await load();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('연결 정보·네트워크·기기 만료 상태를 확인해 주세요.'),
            duration: Duration(seconds: 4),
          ),
        );
      }
    } finally {
      await s?.db.close();
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> connect(Store s) async {
    final raw = input.text.trim();
    final config = CloudConnection.parse(raw);
    if (!DateTime.parse(config.expiresAt).isAfter(DateTime.now())) {
      throw StateError('EXPIRED');
    }
    final account = await credentials.read(key: 'id');
    if (account == null) throw StateError('NO_ACCOUNT');
    if (!mounted) return;
    final yes = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('학사 정보를 서버에 저장할까요?'),
        content: const Text(
          '과제·콘텐츠의 제목·과목·상태·기한, 공지 제목·본문, 저장 시간표에서 만든 향후 수업을 개인용 조회 서버에 저장합니다. 연결하면 지금 전송하고 이후 수집 성공 시 갱신합니다.\n\n첨부자료·자료 본문·외부 링크도 전송합니다. 파일당 최대 20MB, 회차당 최대 6개·약 40MB입니다. 학교 ID/PW·쿠키·Gemini 키·활동 로그는 보내지 않습니다. 공지 본문에 포함된 개인정보는 전송될 수 있습니다.\n\n개인 시험용 연결입니다. 연결 정보는 타인에게 공유하지 마세요.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(c, true),
            child: const Text('동의하고 연결'),
          ),
        ],
      ),
    );
    if (yes != true) return;
    if (account != await credentials.read(key: 'id')) {
      throw StateError('ACCOUNT_CHANGED');
    }
    await credentials.write(key: 'cloudConnection', value: raw);
    await credentials.write(key: 'cloudLocalAccount', value: account);
    await s.setMeta(MetaKey.cloudEnabled, 'yes');
    await s.setMeta(MetaKey.cloudMaterialsConsent, 'yes');
    input.clear();
    await cloudAfterSync(s);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('플러그인 연결')),
    body: AdaptiveContent(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            '내 과제·공지·시간표를 GPT에서 조회',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          const Text(
            '선택 기능 · 개인용 시험 연결\n앱이 수집한 마지막 정보를 전송해요. GPT의 조회 때문에 학교에 새로 로그인하지 않아요.',
          ),
          const SizedBox(height: 20),
          OutlinedButton.icon(
            onPressed: () => launchUrl(
              Uri.parse(radarCloudOrigin),
              mode: LaunchMode.externalApplication,
            ),
            icon: const Icon(Icons.open_in_new),
            label: const Text('연결 사이트 열기'),
          ),
          TextField(
            controller: input,
            obscureText: true,
            enableSuggestions: false,
            autocorrect: false,
            decoration: const InputDecoration(labelText: '사이트에서 발급한 개인 연결 정보'),
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: busy ? null : () => action(connect),
            child: const Text('안내 확인하고 연결'),
          ),
          const SizedBox(height: 20),
          Text(enabled ? '자동 동기화 켜짐' : '자동 동기화 꺼짐'),
          Text(status),
          TextButton.icon(
            icon: const Icon(Icons.folder_open_outlined),
            label: const Text('첨부자료·본문 연결 범위 확인'),
            onPressed: busy
                ? null
                : () => action((s) async {
                    final accepted = await showDialog<bool>(
                      context: context,
                      builder: (c) => AlertDialog(
                        title: const Text('자료도 플러그인에 연결할까요?'),
                        content: const Text(
                          '공지·과제·자료실·콘텐츠의 본문과 기기에 저장된 첨부파일, 외부 링크를 비공개 서버에 전송해요. 자료에 포함된 개인정보도 전송될 수 있어요. 지원 문서는 서버에서 텍스트를 추출하며 GPT 도구로 읽을 수 있어요. 파일당 20MB, 회차당 최대 6개·약 40MB이에요. 학교 로그인 정보는 보내지 않아요.',
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(c, false),
                            child: const Text('취소'),
                          ),
                          FilledButton(
                            onPressed: () => Navigator.pop(c, true),
                            child: const Text('동의하고 자료 연결'),
                          ),
                        ],
                      ),
                    );
                    if (accepted == true) {
                      await s.setMeta(MetaKey.cloudMaterialsConsent, 'yes');
                      await cloudAfterSync(s);
                    }
                  }),
          ),

          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: busy || !enabled
                ? null
                : () => action((s) => cloudAfterSync(s)),
            child: const Text('저장된 정보 지금 전송'),
          ),
          TextButton(
            onPressed: busy || !enabled
                ? null
                : () => action((s) => s.setMeta(MetaKey.cloudEnabled, 'no')),
            child: const Text('전송 중지 (서버 자료 유지)'),
          ),
          TextButton(
            onPressed: busy
                ? null
                : () => action((s) async {
                    await s.setMeta(MetaKey.cloudEnabled, 'no');
                    if (!await sendCloud(s, disconnect: true)) {
                      throw StateError('NOT_CONNECTED');
                    }
                    await credentials.delete(key: 'cloudConnection');
                    await credentials.delete(key: 'cloudLocalAccount');
                    await s.setMeta(MetaKey.cloudLastUploaded, '');
                    await s.setMeta(MetaKey.cloudError, '');
                  }),
            child: const Text('연결 해제·서버 자료 삭제'),
          ),
          const Text(
            '자료 삭제에 실패하면 연결 사이트에서 기기를 해제해 주세요. 앱 로그아웃이나 전송 중지만으로 서버 자료가 삭제되지는 않아요.',
          ),
          if (busy) const LinearProgressIndicator(),
        ],
      ),
    ),
  );
}

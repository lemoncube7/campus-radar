import 'package:campus_radar/core/storage_keys.dart';
import 'dart:convert';
import 'package:campus_radar/core/sync_timing.dart';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/export/cloud_snapshot.dart';
import 'package:campus_radar/campus/material_catalog.dart';
import 'package:campus_radar/campus/media_cache.dart';
import 'package:campus_radar/core/session_scope.dart';

Future<void> uploadCloudMaterials(
  Store store,
  CloudConnection config, {
  SyncTiming? timing,
}) async {
  if (await store.meta(MetaKey.cloudMaterialsConsent) != 'yes') return;
  final scope = await SessionScope.capture(
    store,
    consents: const {'cloudEnabled': 'yes', 'cloudMaterialsConsent': 'yes'},
  );
  if (scope.account == null) return;
  final cache = await MediaCache.open(scope.account!);
  var sent = 0, total = 0, waiting = 0;
  final materials =
      await (timing?.measure('첨부 목록 구성', () => studyMaterials(store)) ??
          studyMaterials(store));
  for (final m in materials) {
    if (m.externalUrl.isNotEmpty) continue;
    if (sent >= 6 || total >= 40 * 1024 * 1024) {
      waiting++;
      continue;
    }
    // Unchanged files skip reading and hashing: the stored signature
    // (path, size, modified time) still matches what was last sent
    // (build 79: 163 hashes, 2.8 s, nothing to upload).
    final key = 'cloudBlob:${config.deviceId}:${m.id}';
    final sigKey = 'cloudBlobSig:${config.deviceId}:${m.id}';
    File? file;
    String? fileSig;
    if (m.media != null) {
      Future<File?> cached() => cache.local(m.media!);
      file = await (timing?.measure('첨부 캐시 확인', cached) ?? cached());
      if (file != null) {
        final stat = await file.stat();
        fileSig =
            '${file.path}|${stat.size}|${stat.modified.toUtc().toIso8601String()}';
        final known = await store.meta(sigKey);
        if (known != null &&
            known.startsWith('$fileSig|') &&
            await store.meta(key) == known.substring(fileSig.length + 1)) {
          continue;
        }
      }
    }
    List<int> bytes;
    String mime;
    if (m.media == null) {
      bytes = utf8.encode(m.body);
      mime = 'text/plain';
    } else {
      final f = file;
      if (f == null || await f.length() > 20 * 1024 * 1024) {
        waiting++;
        continue;
      }
      bytes =
          await (timing?.measure('첨부 파일 읽기', f.readAsBytes) ?? f.readAsBytes());
      mime = await cache.mime(m.media!);
    }
    if (bytes.length > 20 * 1024 * 1024) {
      waiting++;
      continue;
    }
    Future<String> digest() async => sha256.convert(bytes).toString();
    final hash = await (timing?.measure('첨부 해시 계산', digest) ?? digest());
    Future<String?> priorHash() => store.meta(key);
    if (await (timing?.measure('기존 전송 해시 조회', priorHash) ?? priorHash()) ==
        hash) {
      if (fileSig != null) await store.setMeta(sigKey, '$fileSig|$hash');
      continue;
    }
    // The session check guards the upload only; it read secure storage and
    // metadata for every attachment before (build 79: 168 checks, 10.3 s).
    await (timing?.measure('첨부별 세션 확인', scope.verify) ?? scope.verify());
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    final watcher = scope.watch(() => client.close(force: true));
    try {
      Future<void> upload() => (() async {
        final req = await client.postUrl(
          Uri.parse('$radarCloudOrigin/api/materials'),
        );
        req.followRedirects = false;
        req.headers.set(
          'OAI-Sites-Authorization',
          'Bearer ${config.gateToken}',
        );
        req.headers.set(
          HttpHeaders.authorizationHeader,
          'Bearer ${config.deviceToken}',
        );
        req.headers.set('X-Radar-Device', config.deviceId);
        req.headers.set('X-Radar-Material', m.id);
        req.headers.set('X-Radar-Content-Hash', hash);
        req.headers.contentType = ContentType.parse(mime);
        req.add(bytes);
        final response = await req.close();
        await response.drain<void>();
        if (response.statusCode != 200) {
          throw HttpException('MATERIAL_HTTP_${response.statusCode}');
        }
      })().timeout(const Duration(seconds: 35));
      await (timing?.measure('첨부 HTTP 전송', upload) ?? upload());
      await scope.verify();
      await store.setMeta(key, hash);
      if (fileSig != null) await store.setMeta(sigKey, '$fileSig|$hash');
      sent++;
      total += bytes.length;
    } catch (_) {
      waiting++;
    } finally {
      watcher.cancel();
      client.close(force: true);
    }
  }
  await store.setMeta(
    MetaKey.cloudMaterialsStatus,
    '이번 전송 $sent개 · 대기 $waiting개 (기기 저장 파일부터, 회차당 최대 6개·약 40MB)',
  );
}

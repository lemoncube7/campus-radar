import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/courses/course_catalog.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/courses/course_colors.dart';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:campus_radar/schedule/timetable_model.dart';

class TimetableGrid extends StatelessWidget {
  final List<ClassSlot> entries;
  final bool readOnly;
  const TimetableGrid({
    super.key,
    required this.entries,
    this.readOnly = false,
  });
  @override
  Widget build(BuildContext context) {
    final days = math.max(
      5,
      entries.fold<int>(1, (a, e) => math.max(a, e.weekday)),
    );
    final first = entries.fold<int>(9, (a, e) => math.min(a, e.start ~/ 60));
    final last = entries.fold<int>(
      18,
      (a, e) => math.max(a, (e.end + 59) ~/ 60),
    );
    const hour = 58.0, left = 34.0, header = 32.0;
    final now = DateTime.now().toUtc().add(const Duration(hours: 9));
    final minute = now.hour * 60 + now.minute;
    final lanes = timetableLanes(entries);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final column = math.max(1.0, (constraints.maxWidth - left) / days);
          final compact = column < 85;
          return SizedBox(
            width: left + days * column,
            height: header + (last - first) * hour,
            child: Stack(
              children: [
                if (now.weekday <= days)
                  Positioned(
                    left: left + (now.weekday - 1) * column,
                    top: 0,
                    width: column,
                    height: header + (last - first) * hour,
                    child: ColoredBox(
                      color: Theme.of(
                        context,
                      ).colorScheme.primary.withValues(alpha: 0.05),
                    ),
                  ),
                for (var day = 1; day <= days; day++)
                  Positioned(
                    left: left + (day - 1) * column,
                    top: 0,
                    width: column,
                    child: Center(
                      child: Text(
                        weekNames[day - 1],
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                for (var h = first; h <= last; h++) ...[
                  Positioned(
                    left: 0,
                    top: header + (h - first) * hour - 7,
                    child: Text(
                      '${h.toString().padLeft(2, '0')}:00',
                      style: Theme.of(context).textTheme.labelSmall,
                    ),
                  ),
                  Positioned(
                    left: left,
                    right: 0,
                    top: header + (h - first) * hour,
                    child: Divider(
                      height: 1,
                      color: Theme.of(context).dividerColor,
                    ),
                  ),
                ],
                for (final e in entries) ...[
                  Builder(
                    builder: (context) {
                      final position = lanes[e.id]!;
                      final width = column / position.count;
                      final color = courseAccent(e.courseKey);
                      return Positioned(
                        left:
                            left +
                            (e.weekday - 1) * column +
                            position.lane * width +
                            1,
                        top: header + (e.start - first * 60) / 60 * hour + 1,
                        width: width - 2,
                        height: math.max(12, (e.end - e.start) / 60 * hour - 2),
                        child: GestureDetector(
                          onTap: () => showClass(context, e),
                          child: Tooltip(
                            message:
                                '${courseLabel(e.course)}\n${slotTime(e.start)}–${slotTime(e.end)} ${e.room}',
                            child: Container(
                              padding: EdgeInsets.all(compact ? 3 : 5),
                              decoration: BoxDecoration(
                                // Stronger fill and a solid left edge so
                                // neighbouring courses are told apart.
                                color: color.withValues(alpha: 0.32),
                                borderRadius: BorderRadius.circular(7),
                                border: Border(
                                  left: BorderSide(color: color, width: 3),
                                ),
                              ),
                              child: ClipRect(
                                child: Text(
                                  compact
                                      ? courseLabel(e.course)
                                      : '${courseLabel(e.course)}\n${slotTime(e.start)}–${slotTime(e.end)}\n${e.room}',
                                  style: Theme.of(context).textTheme.labelSmall
                                      ?.copyWith(
                                        fontWeight: FontWeight.w600,
                                        fontSize: compact ? 11 : null,
                                      ),
                                  maxLines: compact ? 4 : null,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ],
                if (now.weekday <= days &&
                    minute >= first * 60 &&
                    minute <= last * 60)
                  Positioned(
                    left: left + (now.weekday - 1) * column,
                    top: header + (minute - first * 60) / 60 * hour,
                    width: column,
                    child: const Divider(
                      color: Colors.red,
                      height: 1,
                      thickness: 2,
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }

  Future<void> showClass(BuildContext context, ClassSlot e) async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheet) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                courseLabel(e.course),
                style: Theme.of(sheet).textTheme.titleLarge,
              ),
              const SizedBox(height: 12),
              Text(
                '${weekNames[e.weekday - 1]} ${slotTime(e.start)}–${slotTime(e.end)}',
              ),
              Text(e.room.isEmpty ? '강의실 미확인' : e.room),
              const SizedBox(height: 12),
              Text(
                '${readOnly
                    ? '주간 시간표 사본'
                    : e.courseKey.startsWith('personal:')
                    ? '개인 반복 일정'
                    : '강의계획서 기준'} · ${e.source}',
              ),
              const SizedBox(height: 20),
              if (!readOnly && !e.courseKey.startsWith('personal:'))
                FilledButton(
                  onPressed: () async {
                    final store = await Store.open();
                    Map<String, dynamic>? course;
                    try {
                      course = (await readCourses(
                        store,
                      )).where((c) => courseKey(c) == e.courseKey).firstOrNull;
                    } finally {
                      await store.db.close();
                    }
                    if (!sheet.mounted) return;
                    if (course == null) {
                      ScaffoldMessenger.of(sheet).showSnackBar(
                        const SnackBar(
                          content: Text('과목 정보를 찾지 못했어요. 새로고침 후 확인해 주세요.'),
                        ),
                      );
                      return;
                    }
                    Navigator.pop(sheet);
                    if (context.mounted) {
                      navigateTo(context, CourseDestination(course: course));
                    }
                  },
                  child: const Text('과목 보기'),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

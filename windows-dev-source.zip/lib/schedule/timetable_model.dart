import 'dart:convert';

class ClassSlot {
  final String courseKey, course, source, room;
  final int weekday, start, end;
  const ClassSlot({
    required this.courseKey,
    required this.course,
    required this.weekday,
    required this.start,
    required this.end,
    this.room = '',
    this.source = '',
  });
  String get id => '$courseKey:$weekday:$start';
  Map<String, dynamic> toJson() => {
    'id': id,
    'courseKey': courseKey,
    'course': course,
    'weekday': weekday,
    'start': start,
    'end': end,
    'room': room,
    'source': source,
  };
  factory ClassSlot.fromJson(Map<String, dynamic> j) => ClassSlot(
    courseKey: j['courseKey'],
    course: j['course'],
    weekday: j['weekday'],
    start: j['start'],
    end: j['end'],
    room: j['room'] ?? '',
    source: j['source'] ?? '',
  );
}

String slotTime(int minutes) =>
    '${(minutes ~/ 60).toString().padLeft(2, '0')}:${(minutes % 60).toString().padLeft(2, '0')}';
const weekNames = ['월', '화', '수', '목', '금', '토', '일'];

/// Only explicit weekday + clock ranges are accepted. Period numbers are ambiguous.
List<ClassSlot> parsePlanSlots(String text, String key, String course) {
  text = text.replaceAll(r'\n', '\n');
  final heading = RegExp(
    r'강의\s*시간표(?:\s*\([^)]*\))?|강의\s*시간(?:\s*\([^)]*\))?|수업\s*시간표',
  ).firstMatch(text);
  if (heading != null) {
    text = text.substring(heading.end);
    // Look for the next section only after the first clock time: a table
    // header such as "요일/시간/강의실/담당교수" sits before the times.
    final firstTime = RegExp(r'\d{1,2}:\d{2}').firstMatch(text)?.start ?? 0;
    final stop = RegExp(
      r'수업\s*운영\s*방식|수업\s*방식|강의\s*목표|교과목\s*개요|교재|교수',
    ).firstMatch(text.substring(firstTime));
    final cut = stop == null ? null : firstTime + stop.start;
    text = text.substring(
      0,
      cut ?? (text.length < 800 ? text.length : 800),
    );
  }
  final result = <String, ClassSlot>{};
  final pattern = RegExp(
    r'(?<![가-힣0-9])([월화수목금토일](?:\s*[,·/]\s*[월화수목금토일])*)\s*(?:요일)?\s*[:：]?\s*(\d{1,2}):(\d{2})\s*[~∼～–—\-]\s*(\d{1,2}):(\d{2})(?:\s*\(([^)\n]{1,80})\))?',
  );
  for (final m in pattern.allMatches(text)) {
    final h1 = int.parse(m[2]!),
        n1 = int.parse(m[3]!),
        h2 = int.parse(m[4]!),
        n2 = int.parse(m[5]!);
    if (h1 > 23 || h2 > 23 || n1 > 59 || n2 > 59) continue;
    final start = h1 * 60 + n1, end = h2 * 60 + n2;
    if (end <= start) continue;
    for (final day in RegExp('[월화수목금토일]').allMatches(m[1]!)) {
      final slot = ClassSlot(
        courseKey: key,
        course: course,
        weekday: weekNames.indexOf(day[0]!) + 1,
        start: start,
        end: end,
        // Control characters (tabs from table cells) break share codes.
        room: (m[6] ?? '').replaceAll(RegExp(r'[\x00-\x1f]+'), ' ').trim(),
        source: m[0]!,
      );
      result[slot.id] = slot;
    }
  }
  return result.values.toList()..sort(
    (a, b) => a.weekday != b.weekday
        ? a.weekday.compareTo(b.weekday)
        : a.start.compareTo(b.start),
  );
}

List<ClassSlot> decodeSlots(String? raw) => raw == null
    ? []
    : (jsonDecode(raw) as List)
          .map((j) => ClassSlot.fromJson(Map<String, dynamic>.from(j)))
          .toList();

/// A shared-width connected overlap group prevents chained overlaps from covering classes.
Map<String, ({int lane, int count})> timetableLanes(List<ClassSlot> entries) {
  final result = <String, ({int lane, int count})>{};
  for (var day = 1; day <= 7; day++) {
    final rows = entries.where((e) => e.weekday == day).toList()
      ..sort((a, b) {
        final c = a.start.compareTo(b.start);
        return c == 0 ? a.id.compareTo(b.id) : c;
      });
    var index = 0;
    while (index < rows.length) {
      final group = <ClassSlot>[rows[index++]];
      var end = group.first.end;
      while (index < rows.length && rows[index].start < end) {
        final row = rows[index++];
        group.add(row);
        if (row.end > end) end = row.end;
      }
      final ends = <int>[];
      final lanes = <String, int>{};
      for (final row in group) {
        var lane = ends.indexWhere((end) => end <= row.start);
        if (lane < 0) {
          lane = ends.length;
          ends.add(row.end);
        } else {
          ends[lane] = row.end;
        }
        lanes[row.id] = lane;
      }
      for (final row in group) {
        result[row.id] = (lane: lanes[row.id]!, count: ends.length);
      }
    }
  }
  return result;
}

List<ClassSlot> replaceCourseSlots(
  List<ClassSlot> previous,
  String courseKey,
  List<ClassSlot> replacement,
) =>
    [...previous.where((row) => row.courseKey != courseKey), ...replacement]
      ..sort((a, b) {
        final day = a.weekday.compareTo(b.weekday);
        return day == 0 ? a.start.compareTo(b.start) : day;
      });

List<ClassSlot> retainCurrentTimetable(
  List<ClassSlot> entries,
  Set<String> currentCourseKeys,
) => entries
    .where(
      (e) =>
          currentCourseKeys.contains(e.courseKey) ||
          e.courseKey.startsWith('personal:'),
    )
    .toList();

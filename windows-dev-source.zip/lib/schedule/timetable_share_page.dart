import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/schedule/timetable_share_repository.dart';
import 'package:campus_radar/core/startup_diagnostics.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/timetable_grid.dart';
import 'package:campus_radar/schedule/timetable_share.dart';

class TimetableSharePage extends StatefulWidget {
  final Future<TimetableShareSnapshot> Function()? readSnapshot;
  const TimetableSharePage({super.key, this.readSnapshot});
  @override
  State<TimetableSharePage> createState() => _ShareState();
}

class _ShareState extends State<TimetableSharePage> {
  final input = TextEditingController(), name = TextEditingController();
  List<ClassSlot> own = [];
  List<Map<String, dynamic>> friends = [];
  String id = '', code = '', error = '';
  String? epoch;
  bool rooms = false, personal = false, loading = true, saving = false;
  SharedTimetable? preview;
  String? readError;
  bool reading = false;
  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void dispose() {
    input.dispose();
    name.dispose();
    super.dispose();
  }

  Future<void> load() async {
    if (reading) return;
    reading = true;
    if (mounted) {
      setState(() {
        loading = true;
        readError = null;
      });
    }
    try {
      final snapshot =
          await (widget.readSnapshot ?? readTimetableShareSnapshot)();
      if (mounted) {
        setState(() {
          epoch = snapshot.epoch;
          own = snapshot.own;
          id = snapshot.id;
          friends = snapshot.friends;
          code = '';
          preview = null;
          error = '';
          loading = false;
        });
      }
    } catch (error) {
      if (error is! SessionChanged) {
        await systemLog('시간표 공유 화면 읽기 실패', '공유 정보를 읽지 못했어요.', kind: 'app', error: error);
      }
      if (mounted) {
        setState(() {
          loading = false;
          readError = error is SessionChanged
              ? '계정 상태가 바뀌었어요. 현재 계정의 시간표를 다시 불러와 주세요.'
              : '시간표를 불러오지 못했어요. 저장된 자료는 지우지 않았어요.\n${storageFailureAdvice(storageFailureCode(error))}';
        });
      }
    } finally {
      reading = false;
    }
  }

  Future<void> persist(List<Map<String, dynamic>> rows) async {
    final s = await Store.open();
    try {
      final scope = await SessionScope.capture(s);
      if (scope.epoch != epoch || await s.meta(MetaKey.timetableShareId) != id) {
        throw SessionChanged();
      }
      await s.setMeta(MetaKey.friendTimetables, jsonEncode(rows));
    } finally {
      await s.db.close();
    }
    if (mounted) setState(() => friends = rows);
  }

  void make() {
    try {
      setState(() {
        code = encodeTimetable(own, id: id, rooms: rooms, personal: personal);
        error = '';
      });
    } on FormatException catch (e) {
      setState(() => error = e.message);
    }
  }

  void inspect() {
    try {
      final result = decodeTimetable(input.text);
      setState(() {
        preview = result;
        error = '';
      });
    } on FormatException catch (e) {
      setState(() {
        preview = null;
        error = e.message;
      });
    }
  }

  Future<void> saveFriend() async {
    final value = preview;
    if (value == null || saving) return;
    if (value.id == id) {
      setState(() => error = '내 시간표 코드예요. 친구의 코드를 붙여 넣어 주세요.');
      return;
    }
    final label = name.text.trim();
    if (label.isEmpty || label.length > 40) {
      setState(() => error = '친구 이름을 1~40자로 입력해 주세요.');
      return;
    }
    final previous = friends.where((e) => e['id'] == value.id).firstOrNull;
    if (previous == null && friends.length >= 30) {
      setState(() => error = '친구 시간표는 최대 30개까지 보관할 수 있어요.');
      return;
    }
    if (previous != null) {
      final old = decodeTimetable(previous['code']);
      if (!mounted) return;
      final accept = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('친구 시간표 바꾸기'),
          content: Text(
            '${previous['name']}의 사본을 새 코드로 바꿔요.${value.generatedAt.isBefore(old.generatedAt) ? '\n주의: 지금 코드가 기존 사본보다 오래되었습니다.' : ''}',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('취소'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(c, true),
              child: const Text('바꾸기'),
            ),
          ],
        ),
      );
      if (accept != true) return;
    }
    setState(() => saving = true);
    try {
      await persist([
        ...friends.where((e) => e['id'] != value.id),
        {
          'id': value.id,
          'name': label,
          'code': input.text.trim(),
          'receivedAt': DateTime.now().toUtc().toIso8601String(),
        },
      ]);
      if (mounted) {
        setState(() {
          preview = null;
          input.clear();
          name.clear();
        });
      }
    } catch (e) {
      await systemLog('친구 시간표 저장 실패', '기존 시간표는 유지돼요.', kind: 'app', error: e);
      if (mounted) setState(() => error = '저장하지 못했어요. 기존 시간표는 유지돼요.');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> openFriend(Map<String, dynamic> row) async {
    try {
      final data = decodeTimetable(row['code']);
      await Navigator.push(
        context,
        MaterialPageRoute<void>(
          builder: (_) => _FriendPage(row: row, data: data, own: own),
        ),
      );
    } on FormatException catch (e) {
      await systemLog('공유 시간표 읽기 실패', '공유 코드 형식을 확인해 주세요.', kind: 'app', error: e);
      if (mounted) setState(() => error = e.message);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('시간표 공유·친구 시간표'),
      actions: [
        IconButton(
          tooltip: '시간표 다시 읽기',
          onPressed: loading ? null : load,
          icon: const Icon(Icons.refresh),
        ),
      ],
    ),
    body: loading
        ? const Center(child: CircularProgressIndicator())
        : readError != null
        ? Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.sync_problem, size: 40),
                  const SizedBox(height: 16),
                  Text(readError!, textAlign: TextAlign.center),
                  const SizedBox(height: 16),
                  FilledButton.icon(
                    onPressed: load,
                    icon: const Icon(Icons.refresh),
                    label: const Text('다시 불러오기'),
                  ),
                ],
              ),
            ),
          )
        : ListView(
            padding: const EdgeInsets.all(20),
            children: [
              const Text(
                '문자열 하나로 공유',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const Text(
                '서버 없이 주간 시간표 사본을 주고받아요. 이후 휴강·시간 변경은 자동 반영되지 않아요. 코드는 암호화되지 않으니 받을 사람을 확인하세요.',
              ),
              SwitchListTile(
                title: const Text('강의실 포함'),
                value: rooms,
                onChanged: (v) => setState(() {
                  rooms = v;
                  code = '';
                }),
              ),
              SwitchListTile(
                title: const Text('개인 일정의 바쁜 시간 포함'),
                subtitle: const Text('제목·장소·메모는 제외하고 “일정 있음”으로 표시'),
                value: personal,
                onChanged: (v) => setState(() {
                  personal = v;
                  code = '';
                }),
              ),
              FilledButton.icon(
                onPressed: own.isEmpty || id.isEmpty ? null : make,
                icon: const Icon(Icons.link),
                label: Text(
                  '공유 코드 만들기 · ${own.where((e) => personal || !e.courseKey.startsWith('personal:')).length}개',
                ),
              ),
              if (code.isNotEmpty) ...[
                const SizedBox(height: 12),
                Text('생성된 코드 · ${code.length}자'),
                SizedBox(
                  height: 110,
                  child: SingleChildScrollView(child: SelectableText(code)),
                ),
                OutlinedButton.icon(
                  onPressed: () async {
                    await Clipboard.setData(ClipboardData(text: code));
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('시간표 코드를 복사했어요.')),
                      );
                    }
                  },
                  icon: const Icon(Icons.copy),
                  label: const Text('코드 복사'),
                ),
              ],
              const Divider(height: 36),
              const Text(
                '친구 코드 가져오기',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              TextField(
                controller: input,
                minLines: 2,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: 'CRTT1.으로 시작하는 전체 코드',
                ),
                onChanged: (_) => setState(() => preview = null),
              ),
              OutlinedButton(onPressed: inspect, child: const Text('시간표 미리보기')),
              if (preview != null) ...[
                Text(
                  '생성 시각: ${preview!.generatedAt.toLocal()} · 수업 ${preview!.slots.length}개',
                ),
                TimetableGrid(entries: preview!.slots, readOnly: true),
                TextField(
                  controller: name,
                  maxLength: 40,
                  decoration: const InputDecoration(
                    labelText: '이 기기에서 부를 친구 이름',
                  ),
                ),
                FilledButton(
                  onPressed: saving ? null : saveFriend,
                  child: const Text('친구 시간표로 저장'),
                ),
              ],
              if (error.isNotEmpty)
                Text(
                  error,
                  style: TextStyle(color: Theme.of(context).colorScheme.error),
                ),
              const Divider(height: 36),
              const Text(
                '저장한 친구 시간표',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              if (friends.isEmpty)
                const Text(
                  '받은 코드를 저장하면 여기서 볼 수 있어요. 내 알림·캘린더·AI 자료에는 섞이지 않아요.',
                ),
              for (final row in friends)
                ListTile(
                  title: Text('${row['name']}'),
                  subtitle: const Text('읽기 전용 사본 · 눌러서 비교'),
                  onTap: () => openFriend(row),
                  trailing: IconButton(
                    tooltip: '친구 시간표 삭제',
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () async {
                      final yes = await showDialog<bool>(
                        context: context,
                        builder: (c) => AlertDialog(
                          title: Text('${row['name']} 시간표를 지울까요?'),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(c),
                              child: const Text('취소'),
                            ),
                            FilledButton(
                              onPressed: () => Navigator.pop(c, true),
                              child: const Text('삭제'),
                            ),
                          ],
                        ),
                      );
                      if (yes == true) {
                        try {
                          await persist(
                            friends.where((e) => e['id'] != row['id']).toList(),
                          );
                        } catch (e) {
                          if (mounted) setState(() => error = '삭제하지 못했어요.');
                          await systemLog('친구 시간표 삭제 실패', '목록은 그대로예요.', kind: 'app', error: e);
                        }
                      }
                    },
                  ),
                ),
            ],
          ),
  );
}

class _FriendPage extends StatefulWidget {
  final Map<String, dynamic> row;
  final SharedTimetable data;
  final List<ClassSlot> own;
  const _FriendPage({required this.row, required this.data, required this.own});
  @override
  State<_FriendPage> createState() => _FriendState();
}

class _FriendState extends State<_FriendPage> {
  bool compare = false;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('${widget.row['name']} 시간표')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(
          '사본 생성: ${widget.data.generatedAt.toLocal()}\n받은 시각: ${widget.row['receivedAt']}\n주간 반복 기준 · 이후 휴강/변경 자동 반영 없음',
        ),
        SwitchListTile(
          title: const Text('내 시간표와 겹쳐 보기'),
          value: compare,
          onChanged: (v) => setState(() => compare = v),
        ),
        TimetableGrid(
          readOnly: true,
          entries: [
            for (final e in widget.data.slots)
              ClassSlot(
                courseKey: e.courseKey,
                course: '${widget.row['name']} · ${e.course}',
                weekday: e.weekday,
                start: e.start,
                end: e.end,
                room: e.room,
              ),
            if (compare) ...widget.own,
          ],
        ),
      ],
    ),
  );
}

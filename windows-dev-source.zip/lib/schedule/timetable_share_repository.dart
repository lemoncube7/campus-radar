import 'dart:convert';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/core/startup_diagnostics.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/timetable_share.dart';

class TimetableShareSnapshot {
  final List<ClassSlot> own;
  final List<Map<String, dynamic>> friends;
  final String id, epoch;
  const TimetableShareSnapshot({
    required this.own,
    required this.friends,
    required this.id,
    required this.epoch,
  });
}

/// Retry only transient SQLite busy/locked failures. Never reset stored data.
Future<TimetableShareSnapshot>
readTimetableShareSnapshot() => retryDatabaseOpen(() async {
  Store? store;
  var stage = '저장소 열기';
  try {
    store = await Store.open();
    stage = '계정 확인';
    final scope = await SessionScope.capture(store);
    stage = '시간표·친구 읽기';
    final value = await store.db.transaction((txn) async {
      final rows = await txn.query(
        'meta',
        where: 'id IN (?,?,?)',
        whereArgs: ['timetableEntries', 'timetableShareId', 'friendTimetables'],
      );
      final meta = {
        for (final r in rows) r['id'] as String: r['value'] as String,
      };
      final id = meta['timetableShareId'] ?? newShareId();
      if (!meta.containsKey('timetableShareId')) {
        await txn.insert('meta', {'id': 'timetableShareId', 'value': id});
      }
      final friends = (jsonDecode(meta['friendTimetables'] ?? '[]') as List)
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
      return TimetableShareSnapshot(
        own: decodeSlots(meta['timetableEntries']),
        friends: friends,
        id: id,
        epoch: scope.epoch,
      );
    });
    stage = '계정 재확인';
    await scope.verify();
    return value;
  } catch (error) {
    // Stage/type/storage classification only: no raw SQL, code, account or token.
    await persistStartupDiagnostic(startupDiagnostic(error, '시간표 공유 · $stage'));
    rethrow;
  } finally {
    try {
      await store?.db.close();
    } catch (_) {
      /* keep the original read result */
    }
  }
});

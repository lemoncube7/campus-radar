import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'package:flutter/material.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/schedule/schedule_repository.dart';
import 'package:campus_radar/schedule/timetable_grid.dart';
import 'package:campus_radar/schedule/timetable_model.dart';

class ScheduleCalendar extends StatefulWidget {
  const ScheduleCalendar({super.key});
  @override
  State<ScheduleCalendar> createState() => _ScheduleCalendarState();
}

class _ScheduleCalendarState extends State<ScheduleCalendar> {
  DateTime selected = DateTime.now();
  ScheduleSnapshot? data;
  String? error;
  DateTime? until;
  bool restored = false;
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!restored) {
      final saved = PageStorage.maybeOf(
        context,
      )?.readState(context, identifier: 'scheduleDate');
      if (saved is DateTime) selected = saved;
      restored = true;
    }
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    Store? store;
    try {
      store = await Store.open();
      final result = await ScheduleRepository(store).read();
      if (mounted) setState(() => data = result);
      DateTime? end;
      try {
        final settings = await bridge
            .invokeNativeMap<String, dynamic>(NativeMethod.timetableSettings)
            .timeout(const Duration(seconds: 2));
        end = DateTime.tryParse(settings?['until'] as String? ?? '');
      } catch (_) {
        // Without native settings, classes show with no end date.
      }
      if (mounted) {
        setState(() {
          data = result;
          until = end;
          error = null;
        });
      }
    } catch (_) {
      if (mounted) setState(() => error = '저장된 일정을 읽지 못했어요. 다시 확인해 주세요.');
    } finally {
      await store?.db.close();
    }
  }

  @override
  Widget build(BuildContext context) {
    final day =
        '${selected.year}-${selected.month.toString().padLeft(2, '0')}-${selected.day.toString().padLeft(2, '0')}';
    final tasks =
        data?.tasks
            .where((i) => i.due != null && koreanDate(i.due!) == day)
            .toList() ??
        [];
    final events = confirmedOnDay(data?.events ?? [], day);
    final classes =
        (until != null &&
            selected.isAfter(
              DateTime(until!.year, until!.month, until!.day, 23, 59),
            ))
        ? <ClassSlot>[]
        : classesOnDate(
            data?.classes ?? [],
            data?.cancellations ?? [],
            selected,
          );
    return RefreshIndicator(
      onRefresh: load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            '과제 마감·공지에서 추가한 일정·수업',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          CalendarDatePicker(
            initialDate: selected,
            firstDate: DateTime(2020),
            lastDate: DateTime(2100),
            onDateChanged: (d) {
              PageStorage.maybeOf(
                context,
              )?.writeState(context, d, identifier: 'scheduleDate');
              setState(() => selected = d);
            },
          ),
          Text(
            '${selected.month}월 ${selected.day}일',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          if (error != null) ...[
            Text(error!),
            TextButton(onPressed: load, child: const Text('다시 확인')),
          ],
          if (data == null && error == null) const LinearProgressIndicator(),
          if (data != null &&
              tasks.isEmpty &&
              events.isEmpty &&
              classes.isEmpty)
            const Padding(
              padding: EdgeInsets.all(24),
              child: Text('저장된 일정이 없어요.'),
            ),
          for (final item in tasks)
            Card(
              child: ListTile(
                leading: const Icon(Icons.checklist),
                title: Text(item.title),
                subtitle: Text(
                  '${courseLabel(item.course)} · ${koreanDate(item.due!)} 마감',
                ),
                onTap: () async {
                  await navigateTo(context, TaskDestination(item: item));
                  await load();
                },
              ),
            ),
          for (final row in events)
            Builder(
              builder: (context) {
                final st = row['state'] as Map;
                final n = row['notice'] as CampusNotice;
                final c = row['candidate'] as ScheduleCandidate;
                return Card(
                  child: ListTile(
                    leading: const Icon(Icons.event_available),
                    title: Text(
                      courseEventTitle(
                        st['title'] as String? ?? c.title,
                        n.course,
                        oldLabel: st['courseLabel'] as String?,
                      ),
                    ),
                    subtitle: Text(
                      '${st['allDay'] == true ? '종일' : (DateTime.tryParse(st['start'] as String? ?? '')?.toUtc().add(const Duration(hours: 9)).toIso8601String().substring(11, 16) ?? c.time)} · ${st['approvalMode'] == 'automatic' ? '자동 추가' : '추가한 일정'} · ${st['calendarSent'] == true ? '캘린더 전송됨' : '앱 일정함'}',
                    ),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () async {
                      await navigateTo(
                        context,
                        AiInboxDestination(
                          initialFilter: 'all',
                          candidateId: row['key'] as String,
                        ),
                      );
                      await load();
                    },
                  ),
                );
              },
            ),
          for (final c in classes)
            Card(
              child: ListTile(
                leading: const Icon(Icons.school_outlined),
                title: Text(courseLabel(c.course)),
                subtitle: Text(
                  '${slotTime(c.start)}–${slotTime(c.end)} · ${c.room.isEmpty ? '강의실 미확인' : c.room}',
                ),
                onTap: () => TimetableGrid(
                  entries: data?.classes ?? [],
                ).showClass(context, c),
              ),
            ),
          if (classes.isNotEmpty)
            const Text('수업은 저장된 강의계획서의 반복 시간 기준이에요. 휴강·보강은 과목 공지를 확인하세요.'),
        ],
      ),
    );
  }
}

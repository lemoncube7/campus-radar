import 'package:flutter/material.dart';
import 'package:campus_radar/home/home_navigation.dart';
import 'package:campus_radar/schedule/schedule_calendar.dart';
import 'package:campus_radar/schedule/timetable_page.dart';
import 'package:campus_radar/ai/ai_inbox_page.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';

class ScheduleWorkspace extends StatelessWidget {
  final Widget tasks;
  final ScheduleView view;
  final ValueChanged<ScheduleView> onChanged;
  const ScheduleWorkspace({
    super.key,
    required this.tasks,
    required this.view,
    required this.onChanged,
  });
  @override
  Widget build(BuildContext context) => Column(
    children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: SegmentedButton<ScheduleView>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(value: ScheduleView.tasks, label: Text('할 일')),
              ButtonSegment(value: ScheduleView.calendar, label: Text('캘린더')),
              ButtonSegment(value: ScheduleView.timetable, label: Text('시간표')),
              ButtonSegment(value: ScheduleView.review, label: Text('확인 필요')),
            ],
            selected: {view},
            onSelectionChanged: (v) => onChanged(v.single),
          ),
        ),
      ),
      if (view == ScheduleView.calendar || view == ScheduleView.review)
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              TextButton(
                onPressed: () => navigateTo(
                  context,
                  AiInboxDestination(initialFilter: 'confirmed'),
                ),
                child: const Text('추가한 공지 일정'),
              ),
              const Spacer(),
              IconButton(
                tooltip: '일정 자동 승인 설정',
                onPressed: () => navigateTo(context, AiSettingsDestination()),
                icon: const Icon(Icons.tune),
              ),
            ],
          ),
        ),
      Expanded(
        child: switch (view) {
          ScheduleView.tasks => tasks,
          ScheduleView.calendar => const ScheduleCalendar(),
          ScheduleView.timetable => const TimetablePage(),
          ScheduleView.review => const AiInboxPage(
            embedded: true,
            showTools: false,
          ),
        },
      ),
    ],
  );
}

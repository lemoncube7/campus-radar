import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';
import 'dart:async';
import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'package:campus_radar/schedule/timetable_grid.dart';
import 'package:campus_radar/schedule/today_class_model.dart';
import 'package:campus_radar/schedule/timetable_cancellations_page.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:flutter/material.dart';
import 'package:campus_radar/schedule/timetable_model.dart';

/// A deadline shown in the home hero's today/tomorrow timeline.
typedef TimelineDeadline = ({DateTime at, String label, VoidCallback? onTap});

class TodayClassesCard extends StatefulWidget {
  final int refreshToken;
  final bool compact;

  /// Home hero only: open deadlines in UTC, merged with classes by time.
  final List<TimelineDeadline> deadlines;
  const TodayClassesCard({
    super.key,
    this.refreshToken = 0,
    this.compact = false,
    this.deadlines = const [],
  });
  @override
  State<TodayClassesCard> createState() => _TodayClassesState();
}

class _TodayClassesState extends State<TodayClassesCard> {
  List<ClassSlot> entries = [];
  List<ClassCancellation> cancellations = [];
  bool loaded = false;
  bool reading = false;
  String? error;
  DateTime? until;
  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void didUpdateWidget(covariant TodayClassesCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.refreshToken != widget.refreshToken) unawaited(load());
  }

  Future<void> load() async {
    if (reading || !mounted) return;
    reading = true;
    Store? store;
    try {
      store = await Store.open();
      if (!mounted) return;
      final slots = decodeSlots(await store.meta(MetaKey.timetableEntries));
      final cancelled = await readClassCancellations(store);
      Map<String, dynamic>? settings;
      try {
        settings = await bridge.invokeNativeMap<String, dynamic>(
          NativeMethod.timetableSettings,
        );
      } catch (_) {
        // Fall back to default timetable settings.
      }
      if (mounted) {
        setState(() {
          entries = slots;
          cancellations = cancelled;
          until = DateTime.tryParse('${settings?['until'] ?? ''}');
          loaded = true;
          error = null;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          loaded = true;
          error = '저장된 수업 정보를 확인하지 못했어요.';
        });
      }
    } finally {
      await store?.db.close();
      reading = false;
    }
  }

  Future<void> open() async {
    await navigateTo(context, TimetableDestination());
    await load();
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now().toUtc().add(const Duration(hours: 9));
    final civilNow = DateTime(
      now.year,
      now.month,
      now.day,
      now.hour,
      now.minute,
      now.second,
    );
    final next = nextClassOccurrence(entries, cancellations, now, until: until);
    final cancelledToday = cancellations
        .where((c) => c.date == classDate(now))
        .length;
    final started = next != null && !civilNow.isBefore(next.start);
    final minutes = next?.start.difference(civilNow).inMinutes;
    final days = next?.day
        .difference(DateTime(now.year, now.month, now.day))
        .inDays;
    final when = started
        ? '수업 중'
        : days == 0
        ? (minutes! < 60
              ? '$minutes분 후 시작'
              : '${minutes ~/ 60}시간${minutes % 60 == 0 ? "" : " ${minutes % 60}분"} 후 시작')
        : days == 1
        ? '내일'
        : days == null
        ? ''
        : '${next!.day.month}/${next.day.day}';
    if (widget.compact) {
      final colors = Theme.of(context).colorScheme;
      final today = DateTime(now.year, now.month, now.day);
      // Today/tomorrow timeline: remaining classes and deadlines by time.
      final rows =
          <({DateTime at, String time, String label, VoidCallback? onTap})>[];
      for (var offset = 0; offset < 2; offset++) {
        final day = DateTime(today.year, today.month, today.day + offset);
        for (final slot in classesOnDate(entries, cancellations, day)) {
          final at = DateTime(
            day.year,
            day.month,
            day.day,
            slot.start ~/ 60,
            slot.start % 60,
          );
          final end = DateTime(
            day.year,
            day.month,
            day.day,
            slot.end ~/ 60,
            slot.end % 60,
          );
          if (!end.isAfter(civilNow)) continue;
          if (next != null && slot.id == next.slot.id && day == next.day) {
            continue;
          }
          rows.add((
            at: at,
            time: '${offset == 1 ? '내일 ' : ''}${slotTime(slot.start)}',
            label:
                '${courseLabel(slot.course)}${slot.room.isEmpty ? '' : ' · ${slot.room}'}',
            onTap: open,
          ));
        }
      }
      for (final d in widget.deadlines) {
        final k = d.at.toUtc().add(const Duration(hours: 9));
        final at = DateTime(k.year, k.month, k.day, k.hour, k.minute);
        if (!at.isAfter(civilNow) ||
            !at.isBefore(DateTime(today.year, today.month, today.day + 2))) {
          continue;
        }
        rows.add((
          at: at,
          time:
              '${at.day != today.day ? '내일 ' : ''}${k.hour.toString().padLeft(2, '0')}:${k.minute.toString().padLeft(2, '0')}',
          label: '마감 · ${d.label}',
          onTap: d.onTap,
        ));
      }
      rows.sort((a, b) => a.at.compareTo(b.at));
      return Card(
        color: colors.primaryContainer.withValues(alpha: .55),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            InkWell(
              onTap: open,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
                child: !loaded
                    ? const Text('시간표 확인 중…')
                    : error != null
                    ? Text(error!)
                    : next == null
                    ? Text(
                        entries.isEmpty
                            ? '시간표를 만들면 다음 수업을 알려드려요.'
                            : '예정된 다음 수업이 없어요.',
                      )
                    : Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                started
                                    ? Icons.school_outlined
                                    : Icons.schedule,
                                size: 18,
                                color: colors.primary,
                              ),
                              const SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  started ? '지금 수업' : '다음 수업',
                                  style: Theme.of(context).textTheme.labelLarge,
                                ),
                              ),
                              Text(
                                when,
                                style: Theme.of(context).textTheme.titleMedium
                                    ?.copyWith(
                                      color: colors.primary,
                                      fontWeight: FontWeight.w700,
                                    ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Text(
                            courseLabel(next.slot.course),
                            style: Theme.of(context).textTheme.headlineSmall
                                ?.copyWith(fontWeight: FontWeight.w700),
                          ),
                          Text(
                            '${slotTime(next.slot.start)}–${slotTime(next.slot.end)} · ${next.slot.room.isEmpty ? "강의실 미확인" : next.slot.room}${cancelledToday > 0 ? " · 오늘 휴강 $cancelledToday건" : ""}',
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        ],
                      ),
              ),
            ),
            if (rows.isNotEmpty) ...[
              const Divider(height: 1),
              for (final r in rows.take(5))
                InkWell(
                  onTap: r.onTap,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 8,
                    ),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 84,
                          child: Text(
                            r.time,
                            style: Theme.of(context).textTheme.labelLarge
                                ?.copyWith(
                                  fontFeatures: const [
                                    FontFeature.tabularFigures(),
                                  ],
                                ),
                          ),
                        ),
                        Expanded(
                          child: Text(
                            r.label,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: r.label.startsWith('마감')
                                ? TextStyle(color: colors.error)
                                : null,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              const SizedBox(height: 4),
            ],
          ],
        ),
      );
    }
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Icon(
                  started ? Icons.school_outlined : Icons.schedule,
                  size: 20,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    started ? '지금 수업' : '다음 수업',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                TextButton(onPressed: open, child: const Text('시간표')),
              ],
            ),
            if (!loaded)
              const LinearProgressIndicator()
            else if (error != null)
              Text(error!)
            else if (next == null)
              Text(
                entries.isEmpty
                    ? '시간표를 만들면 다음 수업을 알려드려요.'
                    : '저장된 시간표에 예정된 다음 수업이 없어요.',
              )
            else
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(
                  courseLabel(next.slot.course),
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                subtitle: Text(
                  '${weekNames[next.slot.weekday - 1]} ${slotTime(next.slot.start)}–${slotTime(next.slot.end)}\n${next.slot.room.isEmpty ? '강의실 미확인' : next.slot.room}',
                ),
                trailing: Text(
                  when,
                  style: Theme.of(context).textTheme.labelLarge?.copyWith(
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
                onTap: () => TimetableGrid(
                  entries: entries,
                ).showClass(context, next.slot),
              ),
            if (cancelledToday > 0)
              TextButton.icon(
                onPressed: () async {
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const TimetableCancellationsPage(),
                    ),
                  );
                  await load();
                },
                icon: const Icon(Icons.event_busy, size: 18),
                label: Text('오늘 휴강 처리 $cancelledToday건 · 근거 확인'),
              ),
            Text('저장한 시간표 기준', style: Theme.of(context).textTheme.labelSmall),
          ],
        ),
      ),
    );
  }
}

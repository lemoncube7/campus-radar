/// A committed timetable remains saved even when a platform effect fails.
class TimetableSaveOutcome {
  final List<String> warnings;
  const TimetableSaveOutcome(this.warnings);
}

Future<TimetableSaveOutcome> saveTimetableWithEffects({
  required Future<void> Function() persist,
  required Map<String, Future<void> Function()> effects,
  required Future<void> Function(String stage, Object error) report,
}) async {
  await persist(); // Failure here must propagate; no effect may run before commit.
  final warnings = <String>[];
  for (final entry in effects.entries) {
    try {
      await entry.value();
    } catch (error) {
      warnings.add(entry.key);
      try {
        await report(entry.key, error);
      } catch (_) {
        // Reporting failure cannot turn a successful commit into a failed save.
      }
    }
  }
  return TimetableSaveOutcome(List.unmodifiable(warnings));
}

import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:campus_radar/schedule/timetable_model.dart';

String newShareId() {
  final random = Random.secure();
  return List.generate(
    16,
    (_) => random.nextInt(256).toRadixString(16).padLeft(2, '0'),
  ).join();
}

class SharedTimetable {
  final String id;
  final DateTime generatedAt;
  final List<ClassSlot> slots;
  const SharedTimetable(this.id, this.generatedAt, this.slots);
}

/// No course IDs, source notes, account identifiers or date exceptions leave the app.
String encodeTimetable(
  List<ClassSlot> entries, {
  required String id,
  DateTime? now,
  bool rooms = false,
  bool personal = false,
}) {
  final rows = entries
      .where((e) => personal || !e.courseKey.startsWith('personal:'))
      .map(
        (e) => {
          'title': e.courseKey.startsWith('personal:') ? '일정 있음' : e.course,
          'weekday': e.weekday,
          'start': e.start,
          'end': e.end,
          if (rooms && !e.courseKey.startsWith('personal:')) 'room': e.room,
        },
      )
      .toList();
  final data = utf8.encode(
    jsonEncode({
      'v': 1,
      'id': id,
      'at': (now ?? DateTime.now()).toUtc().toIso8601String(),
      'timezone': 'Asia/Seoul',
      'slots': rows,
    }),
  );
  if (data.length > 131072) throw const FormatException('시간표가 너무 커요.');
  final packed = zlib.encode(data);
  final code =
      'CRTT1.${base64Url.encode(packed).replaceAll('=', '')}.${sha256.convert(packed).toString().substring(0, 16)}';
  decodeTimetable(
    code,
  ); // The same validation applies to outgoing and incoming data.
  return code;
}

class _LimitedSink extends ByteConversionSinkBase {
  final List<int> bytes = [];
  @override
  void add(List<int> chunk) {
    if (bytes.length + chunk.length > 131072) {
      throw const FormatException('시간표 압축 해제 크기 제한을 초과했어요.');
    }
    bytes.addAll(chunk);
  }

  @override
  void close() {}
}

SharedTimetable decodeTimetable(String raw) {
  try {
    final code = raw.trim();
    if (code.length > 32768) throw const FormatException('시간표 코드가 너무 길어요.');
    final parts = code.split('.');
    if (parts.length != 3 ||
        parts[0] != 'CRTT1' ||
        !RegExp(r'^[A-Za-z0-9_-]+$').hasMatch(parts[1])) {
      throw const FormatException('캠퍼스레이더 시간표 코드가 아니에요.');
    }
    final packed = base64Url.decode(base64Url.normalize(parts[1]));
    if (packed.length > 24576 ||
        sha256.convert(packed).toString().substring(0, 16) != parts[2]) {
      throw const FormatException('시간표 코드가 손상되었어요. 전체 코드를 다시 복사해 주세요.');
    }
    final out = _LimitedSink();
    final decoder = ZLibDecoder().startChunkedConversion(out);
    decoder.add(packed);
    decoder.close();
    final j = jsonDecode(utf8.decode(out.bytes)) as Map<String, dynamic>;
    if (j['v'] != 1 ||
        j['timezone'] != 'Asia/Seoul' ||
        j['id'] is! String ||
        !RegExp(r'^[a-f0-9]{32}$').hasMatch(j['id'])) {
      throw const FormatException('지원하지 않는 시간표 형식이에요.');
    }
    final at = DateTime.parse(j['at'] as String).toUtc();
    final rows = j['slots'] as List;
    if (rows.length > 200) {
      throw const FormatException('시간표는 최대 200개 일정까지 가능해요.');
    }
    final slots = <ClassSlot>[];
    for (final (index, value) in rows.indexed) {
      final r = value as Map<String, dynamic>;
      final title = r['title'] as String, room = (r['room'] ?? '') as String;
      final day = r['weekday'] as int,
          start = r['start'] as int,
          end = r['end'] as int;
      if (title.trim().isEmpty ||
          title.length > 120 ||
          room.length > 160 ||
          RegExp(r'[\x00-\x1f]').hasMatch(title + room) ||
          day < 1 ||
          day > 7 ||
          start < 0 ||
          start >= 1440 ||
          end <= start ||
          end > 1440) {
        throw const FormatException('시간표에 올바르지 않은 수업 정보가 있어요.');
      }
      slots.add(
        ClassSlot(
          courseKey: 'friend:${j['id']}:$index',
          course: title,
          weekday: day,
          start: start,
          end: end,
          room: room,
          source: '공유받은 주간 시간표 사본',
        ),
      );
    }
    return SharedTimetable(j['id'], at, slots);
  } on FormatException {
    rethrow;
  } catch (_) {
    throw const FormatException('시간표 코드를 읽지 못했어요. 전체 코드를 확인해 주세요.');
  }
}

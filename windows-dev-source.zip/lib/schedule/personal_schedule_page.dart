import 'package:flutter/material.dart';
import 'package:campus_radar/schedule/timetable_model.dart';

class PersonalSchedulePage extends StatefulWidget {
  final ClassSlot? item;
  const PersonalSchedulePage({super.key, this.item});
  @override
  State<PersonalSchedulePage> createState() => _PersonalSchedulePageState();
}

class _PersonalSchedulePageState extends State<PersonalSchedulePage> {
  late final TextEditingController name, room, note;
  late int day;
  late TimeOfDay start, end;
  String? error;
  @override
  void initState() {
    super.initState();
    final i = widget.item;
    name = TextEditingController(text: i?.course ?? '');
    room = TextEditingController(text: i?.room ?? '');
    note = TextEditingController(text: i?.source ?? '');
    day = i?.weekday ?? 1;
    start = TimeOfDay(
      hour: (i?.start ?? 540) ~/ 60,
      minute: (i?.start ?? 540) % 60,
    );
    end = TimeOfDay(hour: (i?.end ?? 600) ~/ 60, minute: (i?.end ?? 600) % 60);
  }

  @override
  void dispose() {
    name.dispose();
    room.dispose();
    note.dispose();
    super.dispose();
  }

  Future<void> time(bool first) async {
    final value = await showTimePicker(
      context: context,
      initialTime: first ? start : end,
    );
    if (value != null) {
      setState(() {
        if (first) {
          start = value;
        } else {
          end = value;
        }
      });
    }
  }

  void save() {
    final a = start.hour * 60 + start.minute, b = end.hour * 60 + end.minute;
    if (name.text.trim().isEmpty || b <= a) {
      setState(() => error = '이름과 같은 날의 시작·종료 시각을 확인해 주세요.');
      return;
    }
    Navigator.pop(
      context,
      ClassSlot(
        courseKey:
            widget.item?.courseKey ??
            'personal:${DateTime.now().microsecondsSinceEpoch}',
        course: name.text.trim(),
        weekday: day,
        start: a,
        end: b,
        room: room.text.trim(),
        source: note.text.trim(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(widget.item == null ? '개인 반복 일정 추가' : '개인 반복 일정 수정'),
    ),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('매주 같은 요일·시각에 시간표에 표시해요. 학교 강의계획서에서 시간표를 다시 만들어도 유지돼요.'),
        TextField(
          controller: name,
          maxLength: 80,
          decoration: const InputDecoration(labelText: '일정 이름 · 동아리, 스터디 등'),
        ),
        DropdownButtonFormField<int>(
          initialValue: day,
          items: [
            for (var n = 1; n <= 7; n++)
              DropdownMenuItem(value: n, child: Text('${weekNames[n - 1]}요일')),
          ],
          onChanged: (v) => setState(() => day = v!),
          decoration: const InputDecoration(labelText: '매주 반복 요일'),
        ),
        ListTile(
          title: const Text('시작'),
          trailing: Text(start.format(context)),
          onTap: () => time(true),
        ),
        ListTile(
          title: const Text('종료'),
          trailing: Text(end.format(context)),
          onTap: () => time(false),
        ),
        TextField(
          controller: room,
          maxLength: 120,
          decoration: const InputDecoration(labelText: '장소 (선택)'),
        ),
        TextField(
          controller: note,
          maxLength: 500,
          maxLines: 3,
          decoration: const InputDecoration(labelText: '메모 (선택)'),
        ),
        if (error != null) Text(error!),
        FilledButton(onPressed: save, child: const Text('저장')),
        if (widget.item != null)
          TextButton(
            onPressed: () => Navigator.pop(context, 'delete'),
            child: const Text('개인 일정 삭제'),
          ),
      ],
    ),
  );
}

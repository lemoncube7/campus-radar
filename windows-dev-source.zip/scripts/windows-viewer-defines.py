"""Print --dart-define flags for the Drive viewer from a Desktop OAuth JSON.

Usage: python scripts/windows-viewer-defines.py PATH/TO/client.json
The installed-app secret is not confidential (Google), but it is kept out of
the repository and supplied at build time.
"""
import json
import sys

c = json.load(open(sys.argv[1], encoding="utf-8"))["installed"]
print(f"--dart-define=GOOGLE_DESKTOP_CLIENT_ID={c['client_id']} "
      f"--dart-define=GOOGLE_DESKTOP_CLIENT_SECRET={c['client_secret']}")

// ignore_for_file: avoid_print
import 'dart:io';
import 'package:campus_radar/campus/campus.dart';
Future<void> main()async{final l=await File('../../login.txt').readAsLines();final c=CampusClient();try{await c.login(l[0].trim(),l[1]);final t=await c.api('/term/getYearTermList',null);final term=(t['list'] as List).firstWhere((x)=>x['current_term_yn']=='Y');final courses=await c.api('/course/getStdMyCourseList',{'term_year':term['term_year'],'term_cd':term['term_cd'],'is_current':'Y'});print('courses=${(courses['course_list'] as List).length}');
for(final course in courses['course_list']){final w=await c.api('/week/getStdWeekList',{'course_id':course['course_id'],'class_no':course['class_no'],'is_current':'N'});final counts=<String,int>{};void visit(dynamic n){if(n is List){for(final x in n){visit(x);}}else if(n is Map){if(n['module_type']!=null){final k='${n['module_type']} open=${n['learning_open_yn']} display=${n['display_yn']}';counts[k]=(counts[k]??0)+1;}for(final v in n.values){if(v is List||v is Map)visit(v);}}}visit(w);print('weekCount=${(w['week_list'] as List).length} types=$counts');}
}finally{c.close();}}


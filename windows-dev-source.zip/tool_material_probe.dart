import 'dart:convert';
import 'dart:io';
import 'package:campus_radar/campus/campus.dart';
import 'package:html/parser.dart' as html;
Future<void> main()async{
 final lines=File('../../login.txt').readAsLinesSync();final c=CampusClient();
 final dir=Directory('../../outputs/tests/materials/private')..createSync(recursive:true);
 try{
  await c.login(lines[0].trim(),lines[1].trim());
  final courses=await c.fetchCourses();final types=<String,int>{};final samples=<String,Map<String,dynamic>>{};
  for(final course in courses){
   await c.api('/course/addSessionCourseInfo',course);
   for(final endpoint in ['/week/getStdWeekList','/week/getStdEtcList']){
    final data=await c.api(endpoint,{...course,'is_current':'N'});
    void visit(dynamic n){if(n is List){for(final x in n){visit(x);}}else if(n is Map){if(n['module_type']!=null){final t='${n['module_type']}';types[t]=(types[t]??0)+1;samples.putIfAbsent(t,()=>{...course,...Map<String,dynamic>.from(n)});}for(final v in n.values){if(v is Map||v is List)visit(v);}}}
    visit(data);
   }
  }
  File('${dir.path}/samples.json').writeAsStringSync(jsonEncode(samples));
  File('${dir.path}/session.json').writeAsStringSync(jsonEncode(c.exportSession()));
  print(jsonEncode({'types':types,'fields':samples.map((k,v)=>MapEntry(k,v.keys.toList()))}));
  final archive=samples['LS'];
  if(archive!=null){await c.api('/course/addSessionCourseInfo',archive);
   final page=await c.request(Uri.parse('${CampusClient.learning}/std/archiveView'));File('${dir.path}/archive.html').writeAsStringSync(page);
   for(final tag in html.parse(page).querySelectorAll('script[src]')){final src=tag.attributes['src']!;if(src.contains('archiveView')){File('${dir.path}/archiveView.js').writeAsStringSync(await c.request(Uri.parse(CampusClient.learning).resolve(src)));print('Archive JS saved');}}
  }
 }catch(e){print('Probe failed: ${e.runtimeType}');exitCode=1;}finally{c.close();}
}

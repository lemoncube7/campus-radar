import 'dart:async';
import 'dart:io';

import 'package:campus_radar/core/app_logging.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('failureCause names what failed in one short line', () {
    expect(
      failureCause(PlatformException(code: 'google_authorization', message: '연결 실패')),
      '기기 기능 google_authorization · 연결 실패',
    );
    expect(failureCause(TimeoutException('x')), '시간 초과');
    expect(failureCause(const FormatException('학교 계정을 먼저 연결해 주세요.')),
        '형식 · 학교 계정을 먼저 연결해 주세요.');
    expect(
      failureCause(const SocketException('x', osError: OSError('', 7))),
      '네트워크 7',
    );
    expect(failureCause(Exception('database is locked')),
        startsWith('저장소 busy'));
    expect(failureCause(StateError('x')), 'StateError');
  });

  test('failureCause drops query strings and caps length', () {
    final cause = failureCause(
      FormatException('https://example.com/a?token=secret ${'x' * 300}'),
    );
    expect(cause, isNot(contains('secret')));
    expect(cause.length, lessThanOrEqualTo(161));
  });

  test('withCause keeps the user sentence first', () {
    expect(
      withCause('다음에 다시 시도해요.', TimeoutException('x')),
      '다음에 다시 시도해요.\n원인: 시간 초과',
    );
  });
}

import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/settings/app_help_catalog.dart';
import 'package:campus_radar/settings/app_help_page.dart';
import 'package:campus_radar/ai/chat.dart';

void main() {
  test(
    'Chat gets app instructions without academic data and only known help links resolve',
    () {
      final request = chatRequest([], '캘린더 설정은?', '공유 안 함');
      final text = request['systemInstruction']['parts'][0]['text'] as String;
      expect(text, contains('campus-radar://help/ai-calendar'));
      expect(text, contains('더보기'));
      expect(text, contains('실제 사용자 설정·권한·키 연결 여부는 알 수 없다'));
      for (final link in [
        'campus-radar://help/unknown',
        'https://help/ai-calendar',
        'campus-radar://help/ai-calendar?auto=true',
        'campus-radar://user@help/ai-calendar',
        'campus-radar://help/ai-calendar#enable',
        'campus-radar://help/ai-calendar/extra',
      ]) {
        expect(appHelpLink(link), isNull);
      }
      expect(appHelpLink('campus-radar://help/ai-calendar')?.id, 'ai-calendar');
    },
  );

  testWidgets(
    'Search finds setup guide and progresses without mutating settings',
    (t) async {
      HelpTool? opened;
      await t.pumpWidget(
        MaterialApp(
          home: const AppHelpPage(),
          onGenerateRoute: (settings) {
            final target = settings.arguments;
            if (target is! HelpToolDestination || settings.name != target.path) {
              return null;
            }
            opened = target.tool;
            return MaterialPageRoute<void>(
              builder: (context) => Scaffold(
                appBar: AppBar(title: const Text('설정 화면')),
                body: const Text('설정 경로 확인'),
              ),
            );
          },
        ),
      );
      await t.enterText(find.byType(TextField), '캘린더');
      await t.pump();
      expect(find.text('시간표와 휴강 관리'), findsNothing);
      await t.tap(find.text('AI 공지 일정을 캘린더에 표시하기'));
      await t.pumpAndSettle();
      expect(find.text('1 / 4'), findsOneWidget);
      expect(find.text('AI 설정 열기'), findsOneWidget);
      await t.tap(find.text('다음 단계'));
      await t.pumpAndSettle();
      expect(find.text('2 / 4'), findsOneWidget);
      expect(find.text('캘린더 설정 열기'), findsOneWidget);
      await t.tap(find.text('캘린더 설정 열기'));
      await t.pumpAndSettle();
      expect(opened, HelpTool.calendarSettings);
      await t.pageBack();
      await t.pumpAndSettle();
      expect(find.text('2 / 4'), findsOneWidget);
      await t.tap(find.text('이전 단계'));
      await t.pumpAndSettle();
      expect(find.text('1 / 4'), findsOneWidget);
      expect(t.takeException(), isNull);
    },
  );
}

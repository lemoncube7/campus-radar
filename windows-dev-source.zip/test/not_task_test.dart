import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/material_catalog.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Store store;
  late Directory dir;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    dir = await Directory.systemTemp.createTemp('radar-not-task-');
    await databaseFactory.setDatabasesPath(dir.path);
    store = await Store.open();
  });
  tearDown(() async {
    await store.db.close();
    await dir.delete(recursive: true);
  });
  CampusItem item(String id) => CampusItem(
    key: id,
    type: 'LR',
    title: '점수 확인',
    course: '과목',
    courseId: 'c',
    classNo: '1',
    contentsId: id,
    status: 'pending',
    body: '확인 정보',
    context: {},
  );
  test(
    'not-task survives recollection and excludes actionable views without hiding source materials',
    () async {
      await store.replace([item('a'), item('b')]);
      await store.setMeta('notTask:a', 'yes');
      await store.replace([item('a'), item('b')]);
      expect(await store.notTasks(), {'a'});
      expect(await store.excluded(), contains('a'));
      expect(
        await store.excluded(includeNotTasks: false),
        isNot(contains('a')),
      );
      expect(
        (await studyMaterials(store)).where((m) => m.title == '점수 확인').length,
        2,
      );
      final excluded = await store.excluded();
      expect(
        (await store.items())
            .where((i) => !excluded.contains(i.key))
            .map((i) => i.key),
        ['b'],
      );
    },
  );
  test(
    'restore keeps independent hidden choice and invalidates stale AI summary',
    () async {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('aiSummaryText', 'old summary');
      await store.setMeta('notTask:a', 'yes');
      expect(prefs.getString('aiSummaryText'), isNull);
      expect(await store.meta('aiSummaryRevision'), isNotNull);
      await store.setMeta('excluded:a', 'yes');
      await store.setMeta('notTask:a', 'no');
      expect(await store.notTasks(), isEmpty);
      expect(await store.excluded(), contains('a'));
    },
  );
}

import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:campus_radar/campus/campus_media.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/export/app_snapshot.dart';
import 'package:campus_radar/export/drive_sync.dart';
import 'package:campus_radar/tasks/task_evaluation.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory dir;
  late Store store;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    dir = await Directory.systemTemp.createTemp('radar-app-snapshot-');
    await databaseFactory.setDatabasesPath(dir.path);
    store = await Store.open();
  });
  tearDown(() async {
    await store.db.close();
    await dir.delete(recursive: true);
  });

  CampusItem item(String key, String course, {String type = 'LR'}) =>
      CampusItem(
        key: key,
        type: type,
        title: '제목 $key',
        course: course,
        courseId: 'c-$course',
        classNo: '1',
        contentsId: key,
        status: 'pending',
        body: '본문',
        bodyHtml: '<b>PRIVATE_HTML</b>',
        media: const [
          CampusMedia(
            name: 'a.pdf',
            url: 'https://x/a',
            form: {'k': 'PRIVATE_FORM'},
          ),
        ],
        evaluation: const TaskEvaluation(score: 'PRIVATE_GRADE'),
        due: DateTime.utc(2026, 11, 9, 14, 59),
        context: {
          'course_id': 'c-$course',
          'class_no': '1',
          'cookie': 'PRIVATE_COOKIE',
        },
      );

  Future<void> seed() async {
    await store.setMeta('lastSuccess', '2026-11-05T08:00:00Z');
    await store.setMeta('pw', 'PRIVATE_PW');
    await store.setMeta('aiCache:x', 'PRIVATE_AI');
    await store.setMeta(
      'courses',
      jsonEncode([
        {
          'course_id': 'c-A',
          'class_no': '1',
          'course_nm': 'A',
          'student_id': 'PRIVATE_ID',
        },
        {'course_id': 'c-B', 'class_no': '1', 'course_nm': 'B'},
      ]),
    );
    await store.setMeta('timetableEntries', '[]');
    await store.setMeta('excluded:a1', 'yes');
    await store.setMeta('excluded:b1', 'yes');
    for (final i in [
      item('a1', 'A'),
      item('b1', 'B'),
      item('a2', 'A', type: 'LS'),
    ]) {
      await store.db.insert('items', {
        'id': i.key,
        'payload': jsonEncode(i.toJson()),
      });
    }
    await store.saveNotice(
      CampusNotice(
        id: 'n1',
        title: '공지',
        course: 'A',
        context: {'course_id': 'c-A'},
        body: '공지 본문',
      ),
    );
  }

  test('snapshot keeps an allow-list and drops private fields', () async {
    await seed();
    final text = jsonEncode(await buildAppSnapshot(store, profileId: 'p1'));
    for (final secret in [
      'PRIVATE_HTML',
      'PRIVATE_FORM',
      'PRIVATE_GRADE',
      'PRIVATE_COOKIE',
      'PRIVATE_ID',
      'PRIVATE_PW',
      'PRIVATE_AI',
    ]) {
      expect(text, isNot(contains(secret)), reason: secret);
    }
    final j = jsonDecode(text) as Map;
    expect((j['items'] as List).length, 3);
    expect(
      (j['meta'] as Map).keys,
      containsAll(['lastSuccess', 'courses', 'excluded:a1']),
    );
  });

  test('snapshot follows course and type selection', () async {
    await seed();
    final j = await buildAppSnapshot(
      store,
      profileId: 'p1',
      selectedCourses: {'A'},
      materials: false,
      timetable: false,
    );
    expect([for (final i in j['items'] as List) i['key']], ['a1']);
    final meta = j['meta'] as Map;
    expect(meta.containsKey('excluded:b1'), false);
    expect(meta.containsKey('timetableEntries'), false);
    expect(jsonDecode(meta['courses'] as String), [
      {'course_id': 'c-A', 'class_no': '1', 'course_nm': 'A'},
    ]);
  });

  test('apply mirrors the snapshot and replaces old rows atomically', () async {
    await seed();
    final text = jsonEncode(
      await buildAppSnapshot(store, profileId: 'p1', selectedCourses: {'B'}),
    );
    await store.setMeta('excluded:stale', 'yes');
    final info = await applyAppSnapshot(store, text);
    expect(info.items, 1);
    expect((await store.items()).map((i) => i.key), ['b1']);
    expect(await store.notices(), isEmpty);
    expect(await store.meta('excluded:b1'), 'yes');
    expect(await store.meta('excluded:stale'), isNull);
    expect(await store.meta('pw'), 'PRIVATE_PW'); // local-only keys untouched
  });

  test('invalid or newer snapshots leave the store unchanged', () async {
    await seed();
    await expectLater(
      applyAppSnapshot(store, '{"format":"x"}'),
      throwsFormatException,
    );
    await expectLater(
      applyAppSnapshot(
        store,
        '{"format":"campus-radar-app","schema":99,"items":[],"notices":[],"meta":{}}',
      ),
      throwsFormatException,
    );
    expect((await store.items()).length, 3);
  });

  test('start index records the snapshot digest', () async {
    const start = 'CAMPUS_RADAR_START_V1\n{"formatVersion":1}';
    final docs = automaticDriveDocuments({
      '캠퍼스레이더 시작.txt': start,
    }, appSnapshot: '{"a":1}');
    expect(docs[appSnapshotPath], '{"a":1}');
    final index =
        jsonDecode(docs['캠퍼스레이더 시작.txt']!.split('\n').skip(1).join('\n'))
            as Map;
    expect(index['appSnapshot']['sha256'], appSnapshotDigest('{"a":1}'));
  });
}

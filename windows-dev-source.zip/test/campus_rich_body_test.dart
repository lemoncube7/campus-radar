import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/campus/campus_media.dart';
import 'package:campus_radar/campus/campus_rich_body.dart';

void main() {
  test(
    'encoded HTML is normalized but escaped code within markup remains text',
    () {
      expect(
        normalizeCampusHtml(
          '&lt;p&gt;&lt;strong&gt;시험 안내&lt;/strong&gt;&lt;/p&gt;',
        ),
        '<p><strong>시험 안내</strong></p>',
      );
      expect(
        normalizeCampusHtml('<pre>&lt;div&gt;코드&lt;/div&gt;</pre>'),
        '<pre>&lt;div&gt;코드&lt;/div&gt;</pre>',
      );
      expect(
        campusBodyPieces(
          '&lt;p&gt;앞&lt;br&gt;뒤&lt;/p&gt;&lt;script&gt;BAD&lt;/script&gt;',
        ).map((p) => p.text).join(),
        '앞\n뒤',
      );
    },
  );
  testWidgets(
    'encoded paragraphs bold lists and tables render without active contents',
    (t) async {
      await t.pumpWidget(
        MaterialApp(
          theme: ThemeData.dark(),
          home: Scaffold(
            body: SingleChildScrollView(
              child: CampusRichBody(
                source:
                    '&lt;p&gt;안내 &lt;strong&gt;중요&lt;/strong&gt;&lt;/p&gt;&lt;ul&gt;&lt;li&gt;준비물&lt;/li&gt;&lt;/ul&gt;&lt;table&gt;&lt;tr&gt;&lt;th&gt;일시&lt;/th&gt;&lt;td&gt;내일&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;script&gt;BAD&lt;/script&gt;',
                imageAt: (_) => const SizedBox(),
              ),
            ),
          ),
        ),
      );
      expect(find.byType(Table), findsOneWidget);
      expect(find.text('•'), findsOneWidget);
      final texts = t
          .widgetList<SelectableText>(find.byType(SelectableText))
          .map((w) => w.textSpan?.toPlainText() ?? w.data ?? '')
          .join();
      expect(texts, contains('중요'));
      expect(texts, isNot(contains('<p')));
      expect(texts, isNot(contains('BAD')));
      final spans = t
          .widgetList<SelectableText>(find.byType(SelectableText))
          .where((w) => w.textSpan?.toPlainText().contains('중요') == true)
          .single
          .textSpan!;
      bool bold(InlineSpan s) =>
          s is TextSpan &&
          ((s.text == '중요' && s.style?.fontWeight == FontWeight.w700) ||
              (s.children ?? []).any(bold));
      expect(bold(spans), true);
      expect(t.takeException(), isNull);
    },
  );
  testWidgets('narrow tables scroll and images retain order', (t) async {
    t.view.physicalSize = const Size(320, 700);
    t.view.devicePixelRatio = 1;
    addTearDown(t.view.resetPhysicalSize);
    addTearDown(t.view.resetDevicePixelRatio);
    await t.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SingleChildScrollView(
            child: CampusRichBody(
              source:
                  '<p>앞</p><img src="/file/a.png"><table><tr><td>가</td><td>나</td><td>다</td></tr></table>',
              imageAt: (i) => Text('image$i'),
            ),
          ),
        ),
      ),
    );
    expect(find.text('image0'), findsOneWidget);
    expect(t.takeException(), isNull);
  });
}

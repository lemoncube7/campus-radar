import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/tasks/task_presentation.dart';
import 'package:flutter_test/flutter_test.dart';

CampusItem item({
  DateTime? due,
  String status = 'pending',
  String type = 'LR',
}) => CampusItem(
  key: 'k',
  type: type,
  title: 't',
  course: 'c',
  courseId: 'c',
  classNo: '1',
  contentsId: 'x',
  status: status,
  body: '',
  due: due,
  context: {},
);

void main() {
  // 2026-11-04 23:30 KST
  final now = DateTime.utc(2026, 11, 4, 14, 30);

  test('dueBadge counts hours within a day and KST calendar days beyond', () {
    expect(
      dueBadge(item(due: now.add(const Duration(minutes: 20))), now: now),
      '20분 남음',
    );
    expect(
      dueBadge(item(due: now.add(const Duration(hours: 5))), now: now),
      '5시간 남음',
    );
    // 11/6 00:30 KST is two calendar days away although only ~25h remain.
    expect(
      dueBadge(item(due: DateTime.utc(2026, 11, 5, 15, 30)), now: now),
      'D-2',
    );
    // 11/5 23:59 KST: 24.5h left, next calendar day.
    expect(
      dueBadge(item(due: DateTime.utc(2026, 11, 5, 14, 59)), now: now),
      'D-1',
    );
    expect(
      dueBadge(item(due: now.subtract(const Duration(minutes: 1))), now: now),
      '마감 지남',
    );
    expect(dueBadge(item(), now: now), '마감 미확인');
    expect(
      dueBadge(
        item(due: now, status: 'done'),
        now: now,
      ),
      '완료',
    );
  });

  test('formatDateShort shows Korean time with weekday and no suffix', () {
    expect(formatDateShort(DateTime.utc(2026, 11, 9, 14, 59)), '11/9(월) 23:59');
    expect(formatDateShort(DateTime.utc(2026, 11, 8, 15, 0)), '11/9(월) 00:00');
  });
}

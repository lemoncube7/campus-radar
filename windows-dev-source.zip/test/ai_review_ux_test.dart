import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/ai/ai_inbox_page.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'package:campus_radar/ai/ai_state_repository.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  late String cancelKey;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    temp = await Directory.systemTemp.createTemp('review-ux-');
    await databaseFactory.setDatabasesPath(temp.path);
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          (c) async => c.method == 'read' ? 'synthetic' : null,
        );
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('campus_radar/native'),
          (c) async => null,
        );
    final s = await Store.open();
    try {
      await s.setMeta(
        'timetableEntries',
        jsonEncode([
          const ClassSlot(
            courseKey: 'c:1',
            course: '예시 수업',
            weekday: 3,
            start: 780,
            end: 1020,
          ).toJson(),
        ]),
      );
      for (final kind in ['exam', 'audience', 'cancel']) {
        final body = kind == 'cancel'
            ? '11월 4일 수업 휴강입니다.'
            : '11월 4일 13:00에 진행합니다.';
        final n = CampusNotice(
          id: kind,
          title: '안내 $kind',
          course: '예시 수업',
          body: body,
          bodyFetched: true,
          context: {'course_id': 'c', 'class_no': '1'},
        );
        final c = ScheduleCandidate(
          title: kind == 'exam'
              ? '중간고사'
              : kind == 'audience'
              ? '조건부 발표'
              : '수업 휴강',
          date: '2026-11-04',
          time: kind == 'cancel' ? '' : '13:00',
          action: kind == 'cancel' ? 'cancel' : 'add',
          evidence: body,
          uncertainty: '',
          category: kind == 'cancel' ? 'class' : 'exam',
          condition: kind == 'audience' ? 'conditional' : 'required',
        );
        final key = candidateKey(n, c);
        if (kind == 'cancel') cancelKey = key;
        await s.saveNotice(n);
        await s.setMeta(
          'aiCandidate:$kind',
          jsonEncode({
            'notice': n.toJson(),
            'candidate': c.toJson(),
            'key': key,
          }),
        );
      }
    } finally {
      await s.db.close();
    }
  });
  tearDown(() async {
    for (final name in [
      'plugins.it_nomads.com/flutter_secure_storage',
      'campus_radar/native',
    ]) {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(MethodChannel(name), null);
    }
    await temp.delete(recursive: true);
  });
  Future<void> settle(WidgetTester t) async {
    for (var i = 0; i < 5; i++) {
      await t.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 80)),
      );
      await t.pump();
    }
    await t.pumpAndSettle();
  }

  testWidgets(
    'Review categories narrow the decision and cancellation applies once with undo',
    (t) async {
      await t.pumpWidget(const MaterialApp(home: AiInboxPage()));
      await settle(t);
      final filter = find.widgetWithText(ChoiceChip, '휴강·취소');
      await t.ensureVisible(filter);
      await t.tap(filter);
      await t.pumpAndSettle();
      expect(find.textContaining('조건부 발표'), findsNothing);
      final apply = find.text('시간표에 휴강 반영');
      await t.scrollUntilVisible(apply, 250, scrollable: find.byType(Scrollable).first);
      await t.tap(apply);
      await settle(t);
      expect(find.text('적용될 수업'), findsOneWidget);
      expect(find.text('2026-11-04 · 예시 수업'), findsOneWidget);
      expect(find.byType(CheckboxListTile), findsNothing);
      await t.tap(find.text('선택한 날짜·수업에 휴강 적용'));
      await settle(t);
      await t.runAsync(() async {
        final s = await Store.open();
        try {
          expect(
            decodeCancellations(await s.meta('timetableCancellations')).length,
            1,
          );
          expect(
            (await AiStateRepository(
              s,
            ).schedule(cancelKey)).toJson()['resolution'],
            'classCancellationApplied',
          );
        } finally {
          await s.db.close();
        }
      });
      expect(find.text('실행 취소'), findsOneWidget);
      await t.tap(find.text('실행 취소'));
      await settle(t);
      await t.runAsync(() async {
        final s = await Store.open();
        try {
          expect(
            decodeCancellations(await s.meta('timetableCancellations')),
            isEmpty,
          );
          expect(
            (await AiStateRepository(s).schedule(cancelKey)).toJson()['status'],
            'review',
          );
        } finally {
          await s.db.close();
        }
      });
      expect(t.takeException(), isNull);
      await t.pumpWidget(const SizedBox.shrink());
      await settle(t);
    },
  );
}

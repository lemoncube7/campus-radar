import 'dart:convert';

import 'package:campus_radar/export/academic_export.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('start file carries reading rules and readable attachment titles', () {
    final export = packAcademicDocuments(
      profileId: 'a' * 32,
      at: DateTime.utc(2026, 11, 4, 4),
      collectedAt: DateTime.utc(2026, 11, 4, 3),
      documents: {
        '학업 현황.txt': '학업 현황',
        '과목/첨부_0123456789abcdef.txt': '선형대수 · 4장 강의자료\n첨부: ch4.pdf\n본문',
      },
    );
    final start = export.documents['캠퍼스레이더 시작.txt']!;
    final index = jsonDecode(start.substring(start.indexOf('\n') + 1)) as Map;
    expect(index['readingRules'], academicReadingRules);
    expect(
      (index['readingRules'] as List).join(),
      allOf(contains('숨김: true'), contains('수집 시각'), contains('추측하지')),
    );
    final titles = {
      for (final d in index['documents'] as List) d['path']: d['title'],
    };
    expect(titles['과목/첨부_0123456789abcdef.txt'], '선형대수 · 4장 강의자료');
    expect(titles['학업 현황.txt'], '학업 현황');
  });
}

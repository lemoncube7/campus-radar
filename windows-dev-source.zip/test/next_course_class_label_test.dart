import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/today_class_model.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const slots = [
    ClassSlot(
      courseKey: 'a',
      course: 'A',
      weekday: 4,
      start: 540,
      end: 630,
      room: '교404A',
    ),
    ClassSlot(courseKey: 'a', course: 'A', weekday: 1, start: 780, end: 870),
    ClassSlot(courseKey: 'b', course: 'B', weekday: 4, start: 600, end: 690),
  ];
  // 2026-11-05 is a Thursday (weekday 4).
  test('today, tomorrow and weekday labels with room', () {
    expect(
      nextCourseClassLabel(slots, const [], 'a', DateTime(2026, 11, 5, 8)),
      '오늘 09:00 · 교404A',
    );
    expect(
      nextCourseClassLabel(slots, const [], 'a', DateTime(2026, 11, 5, 11)),
      '월 13:00',
    );
    expect(
      nextCourseClassLabel(slots, const [], 'b', DateTime(2026, 11, 4, 20)),
      '내일 10:00',
    );
    expect(
      nextCourseClassLabel(slots, const [], 'c', DateTime(2026, 11, 5)),
      isNull,
    );
  });
}

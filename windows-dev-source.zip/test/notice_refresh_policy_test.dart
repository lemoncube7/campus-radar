import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/services.dart';
import 'package:flutter_test/flutter_test.dart';

CampusNotice notice(DateTime? published, {bool fetched = true}) => CampusNotice(
  id: 'n',
  title: 't',
  course: 'c',
  context: const {},
  published: published,
  bodyFetched: fetched,
  bodyHtml: fetched ? '<p>본문</p>' : '',
);

void main() {
  final now = DateTime.utc(2026, 11, 4, 6);
  test('new notices refresh every 6 hours', () {
    final n = notice(now.subtract(const Duration(days: 2)));
    expect(
      noticeBodyDue(n, now.subtract(const Duration(hours: 5)), now),
      isFalse,
    );
    expect(
      noticeBodyDue(n, now.subtract(const Duration(hours: 7)), now),
      isTrue,
    );
  });
  test('notices older than a week refresh every 3 days', () {
    final n = notice(now.subtract(const Duration(days: 30)));
    expect(
      noticeBodyDue(n, now.subtract(const Duration(hours: 7)), now),
      isFalse,
    );
    expect(
      noticeBodyDue(n, now.subtract(const Duration(days: 4)), now),
      isTrue,
    );
  });
  test('missing bodies and unknown dates always refresh', () {
    expect(noticeBodyDue(notice(now, fetched: false), now, now), isTrue);
    expect(noticeBodyDue(notice(now), null, now), isTrue);
    expect(
      noticeBodyDue(notice(null), now.subtract(const Duration(hours: 7)), now),
      isTrue,
    );
  });
}

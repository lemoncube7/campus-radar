import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/learning_resources.dart';

void main(){
  final course={'course_id':'c','class_no':'1','course_nm':'과목'};
  test('archive and other modules keep separate kinds and never assume participation',(){
    for(final pair in {'LS':'boarditem_no','LD':'discuss_no','LT':'team_project_no','LQ':'exam_no','LE':'exam_no'}.entries){
      final i=parseAdditionalLearning({'module_type':pair.key,pair.value:'x','weekseq_nm':'제목'},course,{});
      expect(i,isNotNull);expect(i!.type,pair.key);expect(i.status,pair.key=='LS'?'available':'unknown');expect(taskTypeMatches(i,'OTHER'),pair.key!='LS');
    }
  });
  test('week-based exam has actual published interval and no invented completion',(){
    final i=parseAdditionalLearning({'module_type':'LE','contents_id':'e','weekseq_nm':'시험','weekseq_str_dt':'2026-11-02','weekseq_str_dt_hour':'10','weekseq_str_dt_min':'00','weekseq_end_dt':'2026-11-02','weekseq_end_dt_hour':'12','weekseq_end_dt_min':'00'},course,{});
    expect(i!.startsAt,DateTime.utc(2026,11,2,1));expect(i.due,DateTime.utc(2026,11,2,3));expect(i.status,'unknown');
  });
  test('new fields survive old and new persisted payloads',(){
    final i=CampusItem(key:'x',type:'LR',title:'과제',course:'과목',courseId:'c',classNo:'1',contentsId:'x',status:'pending',context:{},originalDue:DateTime.utc(2026,10,30),additionalDue:DateTime.utc(2026,11,2),due:DateTime.utc(2026,11,2));
    final restored=CampusItem.fromJson(i.toJson());expect(restored.originalDue,i.originalDue);expect(restored.additionalDue,i.additionalDue);
    final old=Map<String,dynamic>.from(i.toJson())..remove('additionalDue')..remove('externalUrl')..remove('progress');expect(CampusItem.fromJson(old).additionalDue,isNull);
  });
  test('school content duration in minutes and learned seconds rendered compactly',(){
    expect(contentProgress({'study_time':50,'lv_complete_rst':'1500','complete_yn':'N'}),'학습 25/50분');
    expect(contentProgress({'study_time':50,'lv_complete_rst':'3000','complete_yn':'Y'}),'학습 50/50분');
    expect(contentProgress({}),'');
  });
  test('external links cannot contain script schemes or export viewer auth queries',(){
    expect(safeExternalLink('javascript:alert(1)'),'');
    expect(safeExternalLink('https://user:pw@example.com/video'),'');
    expect(safeExternalLink('https://example.com/watch?v=abc&token=SECRET',cloud:true),isNot(contains('SECRET')));
    expect(safeExternalLink('https://example.com/watch?v=abc&token=SECRET',cloud:true),contains('v=abc'));
  });
}

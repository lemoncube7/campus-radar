import 'package:campus_radar/export/drive_sync.dart';
import 'package:flutter_test/flutter_test.dart';

Map target({String binding = 'b1', Map options = const {'courses': []}}) => {
  'enabled': true,
  'accountHash': 'h',
  'binding': binding,
  'options': options,
};

void main() {
  String inputs(Map targets, {String last = '2026-11-04T06:00:00Z'}) =>
      drivePreparationInputs(lastSuccess: last, accountHash: 'h', targets: targets);

  test('upload progress written by the worker does not trigger a rebuild', () {
    final before = inputs({'g1': target()});
    final afterUpload = inputs({
      'g1': {
        ...target(),
        'lastSuccess': '2026-11-04T06:17:24Z',
        'files': {'캠퍼스레이더 시작.txt': 'fileId'},
        'hashes': {'캠퍼스레이더 시작.txt': 'abc'},
        'error': '',
        'email': 'a@example.com',
      },
    });
    expect(afterUpload, before);
  });

  test('a new collection or a settings change does', () {
    final base = inputs({'g1': target()});
    expect(inputs({'g1': target()}, last: '2026-11-04T07:00:00Z'), isNot(base));
    expect(inputs({'g1': target(binding: 'b2')}), isNot(base));
    expect(inputs({'g1': target(options: {'courses': ['x']})}), isNot(base));
    expect(inputs({'g1': target(), 'g2': target()}), isNot(base));
  });
}

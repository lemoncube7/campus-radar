import 'dart:async';
import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/export/drive_preparation_queue.dart';
import 'package:campus_radar/export/drive_sync.dart';

void main() {
  test(
    'automatic manifest removes only manual refresh warning and preserves source',
    () {
      const stale = '실시간 연결이 아니에요. 새로 내보내고 저장소 파일을 교체해야 갱신돼요.';
      final source = {
        '캠퍼스레이더 시작.txt':
            'CAMPUS_RADAR_START_V1\n${jsonEncode({
              'warnings': [stale, '첨부 일부 누락'],
              'collectedAt': 'source-time',
              'exportedAt': 'export-time',
              'refresh': 'manual',
            })}',
        '과목/test.txt': 'body',
      };
      final result = automaticDriveDocuments(source);
      final index =
          jsonDecode(result['캠퍼스레이더 시작.txt']!.split('\n').skip(1).join('\n'))
              as Map;
      expect(index['warnings'], isNot(contains(stale)));
      expect(index['warnings'], contains('첨부 일부 누락'));
      expect(index['collectedAt'], 'source-time');
      expect(index['refresh'], contains('자동'));
      expect(source['캠퍼스레이더 시작.txt'], contains(stale));
      expect(result['과목/test.txt'], 'body');
    },
  );
  test('background triggers coalesce while preparation is active', () async {
    final q = DrivePreparationQueue(), gate = Completer<void>();
    var calls = 0;
    final first = q.run(
      manual: false,
      prepare: () async {
        calls++;
        await gate.future;
      },
    );
    final second = q.run(
      manual: false,
      prepare: () async {
        calls++;
      },
    );
    gate.complete();
    await Future.wait([first, second]);
    expect(calls, 1);
  });
  test('manual request retries after failed automatic preparation', () async {
    final q = DrivePreparationQueue(), gate = Completer<void>();
    var manualRuns = 0;
    final first = q.run(manual: false, prepare: () => gate.future);
    final failure = expectLater(first, throwsStateError);
    final manual = q.run(
      manual: true,
      prepare: () async {
        manualRuns++;
      },
    );
    gate.completeError(StateError('synthetic failure'));
    await failure;
    await manual;
    expect(manualRuns, 1);
  });
  test('two manual waiters never start concurrent preparations', () async {
    final q = DrivePreparationQueue(), gate = Completer<void>();
    var active = 0, peak = 0, calls = 0;
    Future<void> prepare() async {
      active++;
      calls++;
      if (active > peak) peak = active;
      await Future<void>.delayed(Duration.zero);
      active--;
    }

    final first = q.run(manual: false, prepare: () => gate.future);
    final a = q.run(manual: true, prepare: prepare),
        b = q.run(manual: true, prepare: prepare);
    gate.complete();
    await Future.wait([first, a, b]);
    expect(calls, 2);
    expect(peak, 1);
  });
}

import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/courses/course_page.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory dir;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    dir = await Directory.systemTemp.createTemp('radar-material-tab-');
    await databaseFactory.setDatabasesPath(dir.path);
    final store = await Store.open();
    for (final course in ['과목A', '과목B']) {
      final item = CampusItem(
        key: course,
        type: 'LS',
        title: '$course 자료제목',
        course: course,
        courseId: course,
        classNo: '1',
        contentsId: 'x',
        status: 'available',
        body: '자료 본문',
        context: {'course_id': course, 'class_no': '1'},
      );
      await store.db.insert('items', {
        'id': item.key,
        'payload': jsonEncode(item.toJson()),
      });
    }
    await store.db.close();
  });
  testWidgets(
    'course exposes materials as a top-level tab scoped to that course',
    (tester) async {
      SharedPreferences.setMockInitialValues({});
      await tester.pumpWidget(
        const MaterialApp(
          home: CoursePage(
            course: {'course_id': '과목A', 'class_no': '1', 'course_nm': '과목A'},
          ),
        ),
      );
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 400)),
      );
      for (var n = 0; n < 15; n++) {
        await tester.pump(const Duration(milliseconds: 100));
        await tester.runAsync(
          () => Future<void>.delayed(const Duration(milliseconds: 100)),
        );
      }
      expect(find.widgetWithText(Tab, '자료'), findsOneWidget);
      await tester.tap(find.widgetWithText(Tab, '자료'));
      await tester.pump();
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 400)),
      );
      for (var n = 0; n < 15; n++) {
        await tester.pump(const Duration(milliseconds: 100));
        await tester.runAsync(
          () => Future<void>.delayed(const Duration(milliseconds: 100)),
        );
      }
      expect(find.text('공지·과제·콘텐츠·자료실 자료'), findsOneWidget);
      expect(find.text('1개 · 본문·첨부·외부 링크'), findsOneWidget);
      expect(find.text('과목A 자료제목'), findsOneWidget);
      expect(find.text('과목B 자료제목'), findsNothing);
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox.shrink());
      await tester.runAsync(() => dir.delete(recursive: true));
    },
  );
}

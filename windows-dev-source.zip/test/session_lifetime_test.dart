import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/session/session_lifetime.dart';

const minute = 60000;
SessionLifetime baseline() {
  final state = SessionLifetime()
    ..beginSession('synthetic', 0, freshlyLoggedIn: true);
  validate(state, 'initial', 0);
  return state;
}

void validate(SessionLifetime state, String group, int at) {
  state.beginValidation(group, at);
  state.requestStarted(group, group, at);
  state.requestFinished(group, group, at + 10);
  state.validated(group, at + 10);
}

void main() {
  test(
    'Test baseline and recovery preparation reserve the same daily budget without immediate repeats',
    () {
      final state = SessionLifetime();
      expect(state.reserveProbe(0, prepareSession: true), true);
      expect(state.reserveProbe(1, prepareSession: true), false);
      expect(state.reserveProbe(15 * minute, prepareSession: true), true);
      expect(state.probes.length, 2);
    },
  );
  test(
    'Experimental bracket bisects after loss and resets on contradictory short loss',
    () {
      final state = baseline();
      validate(state, '60', 60 * minute + 10);
      state.beginValidation('120', 180 * minute + 20);
      state.failedValidation(
        '120',
        180 * minute + 30,
        authentication: true,
        network: false,
      );
      expect(state.targetMinutes, 90);
      state.beginSession('second', 200 * minute, freshlyLoggedIn: true);
      validate(state, 'baseline', 200 * minute);
      validate(state, '90', 290 * minute + 10);
      expect(state.targetMinutes, 105);
      expect(state.searchCeilingMs, 120 * minute);
      state.beginValidation('contradiction', 305 * minute + 20);
      state.failedValidation(
        'contradiction',
        305 * minute + 30,
        authentication: true,
        network: false,
      );
      expect(state.targetMinutes, 15);
      expect(state.searchCeilingMs, isNull);
      expect(state.maxIdleMs, 90 * minute);
    },
  );

  test(
    'Malformed optional history is rejected before the UI reads timestamps',
    () {
      final raw = baseline().toJson();
      raw['history'] = [
        {'at': 'broken', 'kind': 'validated'},
      ];
      expect(() => SessionLifetime.fromJson(raw), throwsFormatException);
    },
  );
  test(
    'Adaptive probes expand from actual successful idle gaps, bounded at twenty-four hours',
    () {
      final state = baseline();
      var now = 10;
      for (final expected in [30, 60, 120, 240, 480, 720, 1440, 1440]) {
        now += state.targetMinutes * minute;
        validate(state, '$now', now);
        now += 10;
        expect(state.targetMinutes, expected);
      }
      expect(state.maxIdleMs, 1440 * minute);
      expect(state.maxAgeMs, greaterThan(state.maxIdleMs));
    },
  );

  test(
    'Normal app traffic restarts idle clock rather than counting scheduled delay',
    () {
      final state = baseline();
      state.requestStarted('notice', 'notice', 10 * minute);
      state.requestFinished('notice', 'notice', 10 * minute + 10);
      validate(state, 'probe', 15 * minute + 10);
      expect(state.maxIdleMs, 5 * minute);
      expect(state.targetMinutes, 15);
      expect(state.nextProbeAt(15 * minute + 20), 30 * minute + 20);
    },
  );

  test(
    'Concurrent traffic and a recovered transport failure exclude idle samples',
    () {
      final state = baseline();
      state.beginValidation('probe', 30 * minute);
      state.requestStarted('probe', 'a', 30 * minute);
      state.requestStarted('other', 'b', 30 * minute + 1);
      state.requestFinished('other', 'b', 30 * minute + 2);
      state.requestFinished('probe', 'a', 30 * minute + 3);
      state.validated('probe', 30 * minute + 4);
      expect(state.maxIdleMs, 0);
      state.beginValidation('retry', 60 * minute);
      state.requestStarted('retry', 'c', 60 * minute);
      state.requestFinished('retry', 'c', 60 * minute + 1, failed: true);
      state.requestStarted('retry', 'd', 60 * minute + 2);
      state.requestFinished('retry', 'd', 60 * minute + 3);
      state.validated('retry', 60 * minute + 4);
      expect(state.maxIdleMs, 0);
    },
  );

  test(
    'Authentication loss pauses probes and never becomes a timeout upper bound',
    () {
      final state = baseline();
      validate(state, 'ok', 30 * minute + 10);
      state.beginValidation('lost', 150 * minute + 20);
      state.failedValidation(
        'lost',
        150 * minute + 30,
        authentication: true,
        network: false,
      );
      expect(state.maxIdleMs, 30 * minute);
      expect(state.targetMinutes, 75);
      expect(state.nextProbeAt(1000 * minute), isNull);
      expect(state.history.last['isTimeoutUpperBound'], false);
      expect(state.history.last['cause'], 'unknown');
      state.failedValidation(
        'lost',
        150 * minute + 40,
        authentication: true,
        network: false,
      );
      expect(state.losses, 1);
      state.beginSession('new', 200 * minute, freshlyLoggedIn: true);
      validate(state, 'new-baseline', 200 * minute);
      expect(state.lost, false);
      expect(state.nextProbeAt(200 * minute + 10), isNotNull);
    },
  );

  test(
    'Network errors keep lower bounds and back off instead of marking expiry',
    () {
      final state = baseline();
      validate(state, 'ok', 30 * minute + 10);
      for (var i = 0; i < 5; i++) {
        state.beginValidation('net', (60 + i * 130) * minute);
        state.failedValidation(
          'net',
          (60 + i * 130) * minute + 10,
          authentication: false,
          network: true,
        );
      }
      expect(state.maxIdleMs, 30 * minute);
      expect(state.lost, false);
      expect(state.networkErrors, 5);
      expect(state.history.last['retryMinutes'], 120);
    },
  );

  test(
    'Process death / stale in-flight request and backwards clock cannot inflate idle',
    () {
      var state = baseline();
      state.requestStarted('killed', 'unfinished', 10 * minute);
      state = SessionLifetime.fromJson(
        jsonDecode(jsonEncode(state.toJson())) as Map<String, dynamic>,
      );
      validate(state, 'restart', 100 * minute);
      expect(state.maxIdleMs, 0);
      expect(
        state.history.any((e) => e['kind'] == 'observationInterrupted'),
        true,
      );
      validate(state, 'clock-back', 90 * minute);
      expect(state.maxIdleMs, 0);
    },
  );

  test('Rolling day budget reserves atomically and releases at 24 hours', () {
    final state = baseline();
    var now = 15 * minute + 10;
    final first = now;
    for (var i = 0; i < 8; i++) {
      now = state.nextProbeAt(now)!;
      expect(state.reserveProbe(now), true);
      expect(state.reserveProbe(now), false);
      // Reserved workers may stop before they make a school request. Those
      // reservations still consume the daily budget.
      now += 10;
    }
    expect(state.probes.length, 8);
    expect(state.reserveProbe(now), false);
    final due = state.nextProbeAt(now)!;
    expect(due, greaterThanOrEqualTo(first + 1440 * minute));
    expect(state.reserveProbe(due), true);
    expect(state.probes.length, lessThanOrEqualTo(8));
  });

  test(
    'Restored pre-existing session does not fabricate a birth time; history stays bounded',
    () {
      final state = SessionLifetime()
        ..beginSession('adopted', 100 * minute, freshlyLoggedIn: false);
      validate(state, 'first', 100 * minute);
      validate(state, 'second', 130 * minute + 10);
      expect(state.bornAt, isNull);
      expect(state.maxAgeMs, 0);
      expect(state.maxIdleMs, 30 * minute);
      for (var i = 0; i < 80; i++) {
        validate(state, '$i', (140 + i) * minute);
      }
      expect(state.history.length, 60);
      expect(
        SessionLifetime.fromJson(
          jsonDecode(jsonEncode(state.toJson())) as Map<String, dynamic>,
        ).toJson(),
        state.toJson(),
      );
    },
  );
}

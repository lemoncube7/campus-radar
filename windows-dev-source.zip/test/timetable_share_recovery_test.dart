import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/schedule/timetable_share_page.dart';
import 'package:campus_radar/schedule/timetable_share_repository.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/core/session_scope.dart';

const snapshot = TimetableShareSnapshot(
  own: [
    ClassSlot(
      courseKey: 'fixture',
      course: '시험 수업',
      weekday: 1,
      start: 540,
      end: 600,
    ),
  ],
  friends: [],
  id: '00112233445566778899aabbccddeeff',
  epoch: 'fixture',
);
void main() {
  testWidgets(
    'initial read failure has retry and never claims empty timetable',
    (t) async {
      var calls = 0;
      await t.pumpWidget(
        MaterialApp(
          home: TimetableSharePage(
            readSnapshot: () async {
              calls++;
              if (calls == 1) throw StateError('fixture');
              return snapshot;
            },
          ),
        ),
      );
      await t.pumpAndSettle();
      expect(find.text('다시 불러오기'), findsOneWidget);
      expect(find.textContaining('공유 코드 만들기'), findsNothing);
      expect(find.textContaining('받은 코드를 저장하면'), findsNothing);
      await t.tap(find.text('다시 불러오기'));
      await t.pumpAndSettle();
      expect(find.text('공유 코드 만들기 · 1개'), findsOneWidget);
      expect(calls, 2);
    },
  );
  testWidgets(
    'account change on refresh hides old data and allows a fresh read',
    (t) async {
      var calls = 0;
      await t.pumpWidget(
        MaterialApp(
          home: TimetableSharePage(
            readSnapshot: () async {
              calls++;
              if (calls == 2) throw SessionChanged();
              return snapshot;
            },
          ),
        ),
      );
      await t.pumpAndSettle();
      expect(find.text('공유 코드 만들기 · 1개'), findsOneWidget);
      await t.tap(find.byTooltip('시간표 다시 읽기'));
      await t.pumpAndSettle();
      expect(find.textContaining('계정 상태가 바뀌었어요'), findsOneWidget);
      expect(find.textContaining('공유 코드 만들기'), findsNothing);
      await t.tap(find.text('다시 불러오기'));
      await t.pumpAndSettle();
      expect(find.text('공유 코드 만들기 · 1개'), findsOneWidget);
      expect(calls, 3);
    },
  );
}

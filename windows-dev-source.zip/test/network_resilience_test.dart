import 'dart:async';
import 'dart:io';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/core/network_resilience.dart';
import 'package:flutter_test/flutter_test.dart';

class InterruptedClient extends CampusClient {
  var requests = 0;
  @override
  Future<String> request(
    Uri url, {
    Map<String, String>? form,
    int redirects = 0,
  }) async {
    if (++requests == 1) throw const SocketException('private server data');
    return '{"header":{"code":200},"body":{"ok":true}}';
  }
}

void main() {
  for (final error in [
    const SocketException('private'),
    TimeoutException('private'),
    NetworkHttpException(503),
  ]) {
    test('Read retries once for ${error.runtimeType}', () async {
      var calls = 0, retries = 0;
      final result = await retryNetworkRead(
        () async {
          if (++calls == 1) throw error;
          return 'ok';
        },
        delay: Duration.zero,
        onRetry: () => retries++,
      );
      expect(result, 'ok');
      expect(calls, 2);
      expect(retries, 1);
    });
  }
  for (final error in [
    NetworkHttpException(401),
    NetworkHttpException(429),
    const HandshakeException('private'),
    const FormatException('private'),
  ]) {
    test('Permanent or restricted response is not retried: $error', () async {
      var calls = 0;
      await expectLater(
        retryNetworkRead(() async {
          calls++;
          throw error;
        }, delay: Duration.zero),
        throwsA(same(error)),
      );
      expect(calls, 1);
      expect(networkFailureMessage(error), isNot(contains('private')));
    });
  }
  test('A second transient failure stops after exactly two attempts', () async {
    var calls = 0;
    await expectLater(
      retryNetworkRead(() async {
        calls++;
        throw const SocketException('offline');
      }, delay: Duration.zero),
      throwsA(isA<SocketException>()),
    );
    expect(calls, 2);
  });
  test(
    'Allowlisted school read API recovers from a dropped connection',
    () async {
      final client = InterruptedClient();
      addTearDown(client.close);
      expect((await client.api('/term/getYearTermList', null))['ok'], true);
      expect(client.requests, 2);
    },
  );
  test('Unrecognized POST API is never automatically retried', () async {
    final client = InterruptedClient();
    client.transportKey = '0123456789abcdef';
    addTearDown(client.close);
    await expectLater(
      client.api('/task/submit', {}),
      throwsA(isA<SocketException>()),
    );
    expect(client.requests, 1);
  });
}

import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/schedule/timetable_model.dart';

void main() {
  test('Plan class field excludes office hours and later instructions', () {
    expect(
      parsePlanSlots(
        '교수면담 월 13:00~14:00\n강의시간표(강의실)\n화15:00~18:00(공5412), 수19:00~22:00(공5412)\n수업운영방식 상담 목 11:00~12:00',
        'x',
        '예시',
      ).map((s) => s.weekday),
      [2, 3],
    );
  });
  test(
    'Plan clock ranges extract weekdays, rooms and repeated sessions without duplicates',
    () {
      final s = parsePlanSlots(
        '강의시간 월 09:00~10:30(공학관 101), 목 10:30~12:00\n월 09:00~10:30(공학관 101)',
        'c:1',
        '예시',
      );
      expect(s.length, 2);
      expect(s.first.weekday, 1);
      expect(s.first.start, 540);
      expect(s.first.room, '공학관 101');
      expect(s.last.weekday, 4);
    },
  );
  test(
    'Multiple weekdays, newline fields and escaped newlines are supported',
    () {
      expect(
        parsePlanSlots(r'월,수\n13:00–14:15', 'x', '예시').map((s) => s.weekday),
        [1, 3],
      );
    },
  );
  test(
    'Invalid clock, periods, date and narrative tomorrow never create a schedule',
    () {
      for (final x in [
        '화 25:00~26:00',
        '월 10:30~09:00',
        '수 3,4교시',
        '17일 10:00~11:00',
        '내일 10:00~11:00',
      ]) {
        expect(parsePlanSlots(x, 'x', '예시'), isEmpty, reason: x);
      }
    },
  );
  test('Saved slots retain stable IDs and source after reopen', () {
    final a = parsePlanSlots('화 09:00~10:00', 'x', '예시').single;
    expect(ClassSlot.fromJson(a.toJson()).toJson(), a.toJson());
  });
}

import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/export/drive_sync.dart';
import 'package:campus_radar/updates/updates.dart';

void main() {
  test(
    'stable install ignores a development preference retained by upgrade',
    () {
      expect(effectiveUpdateChannel('stable', 'development'), 'stable');
      expect(effectiveUpdateChannel('stable', null), 'stable');
      expect(effectiveUpdateChannel('development', 'stable'), 'stable');
      expect(effectiveUpdateChannel('development', null), 'development');
    },
  );
  test('Drive targets reject disabled or another school account', () {
    final hash = driveAccountHash('school-a');
    final row = {
      'enabled': true,
      'accountHash': hash,
      'binding': 'generation-a',
    };
    expect(driveTargetMatches(row, hash), isTrue);
    expect(driveTargetMatches(row, driveAccountHash('school-b')), isFalse);
    expect(driveTargetMatches({...row, 'enabled': false}, hash), isFalse);
    expect(driveTargetMatches({...row, 'binding': ''}, hash), isFalse);
  });
  test(
    'Drive revision ignores export clock but retains source collection age',
    () {
      Map<String, String> documents(
        String exported,
        String collected,
        String text,
      ) => {
        '캠퍼스레이더 시작.txt':
            'CAMPUS_RADAR_START_V1\n${jsonEncode({'exportedAt': exported, 'collectedAt': collected})}',
        '학업 현황.txt': '내보냄: $exported\n$text',
      };
      final a = driveDocumentRevision(
        documents('one', 'source-one', 'original'),
      );
      expect(
        driveDocumentRevision(documents('two', 'source-one', 'original')),
        a,
      );
      expect(
        driveDocumentRevision(documents('two', 'source-two', 'original')),
        isNot(a),
      );
      expect(
        driveDocumentRevision(documents('two', 'source-one', 'changed')),
        isNot(a),
      );
    },
  );
}

import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/schedule/timetable_save.dart';

void main() {
  test(
    'platform failure after commit preserves saved data and later effects run',
    () async {
      var saved = false, scheduled = false;
      final failures = <String>[];
      final result = await saveTimetableWithEffects(
        persist: () async {
          saved = true;
        },
        effects: {
          'widget': () async {
            throw StateError('fixture');
          },
          'alarm': () async {
            scheduled = true;
          },
        },
        report: (stage, error) async {
          failures.add(stage);
        },
      );
      expect(saved, isTrue);
      expect(scheduled, isTrue);
      expect(result.warnings, ['widget']);
      expect(failures, ['widget']);
    },
  );
  test('database failure propagates before any effects', () async {
    var ran = false;
    await expectLater(
      saveTimetableWithEffects(
        persist: () async {
          throw StateError('storage');
        },
        effects: {
          'alarm': () async {
            ran = true;
          },
        },
        report: (s, e) async {},
      ),
      throwsStateError,
    );
    expect(ran, isFalse);
  });
  test('failed diagnostic log cannot disguise successful commit', () async {
    final result = await saveTimetableWithEffects(
      persist: () async {},
      effects: {
        'alarm': () async {
          throw StateError('native');
        },
      },
      report: (s, e) async {
        throw StateError('log');
      },
    );
    expect(result.warnings, ['alarm']);
  });
  test('normal save has no warning and preserves effect ordering', () async {
    final order = <String>[];
    final result = await saveTimetableWithEffects(
      persist: () async {
        order.add('commit');
      },
      effects: {
        'widget': () async {
          order.add('widget');
        },
        'alarm': () async {
          order.add('alarm');
        },
      },
      report: (s, e) async {},
    );
    expect(order, ['commit', 'widget', 'alarm']);
    expect(result.warnings, isEmpty);
  });
}

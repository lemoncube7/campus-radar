import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/campus/services.dart';

void main() {
  test('unrestricted status has no warning', () {
    expect(
      batteryWarnings({
        'powerSave': false,
        'batteryExempt': true,
        'backgroundRestricted': false,
      }),
      isEmpty,
    );
  });
  test('global power saver is ignored when app is unrestricted', () {
    final warnings = batteryWarnings({
      'powerSave': true,
      'batteryExempt': true,
      'backgroundRestricted': false,
    });
    expect(warnings, isEmpty);
  });
  test('optimization and background restriction warn separately', () {
    expect(
      batteryWarnings({
        'powerSave': false,
        'batteryExempt': false,
        'backgroundRestricted': true,
      }),
      hasLength(2),
    );
  });
  test('unknown settings never treated as healthy', () {
    expect(batteryWarnings({}).single, contains('확인하지 못했어요'));
  });
}

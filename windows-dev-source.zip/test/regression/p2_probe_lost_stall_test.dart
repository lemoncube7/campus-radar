// P2-01 repro: after an authentication loss and the configured reconnect wait,
// the exclusive probe worker never prepares the next round (stuck forever).
import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/session/session_lifetime.dart';
import 'package:campus_radar/session/session_lifetime_probe.dart';
import 'package:campus_radar/session/session_lifetime_repository.dart';

class NoNetwork extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) =>
      throw const SocketException('offline (repro)');
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  const secure = MethodChannel('plugins.it_nomads.com/flutter_secure_storage');
  setUp(() async {
    temp = await Directory.systemTemp.createTemp('p2-lost-');
    await databaseFactory.setDatabasesPath(temp.path);
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          secure,
          (c) async => c.method == 'read' ? 'synthetic' : null,
        );
    // Real HttpClient object; no stored school session, so no request is sent.
  });
  tearDown(() async {
    HttpOverrides.global = null;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(secure, null);
    await temp.delete(recursive: true);
  });

  test('after reconnect wait elapses, probe prepares the next round', () async {
    // Manual (always-active) exclusive test: ordinary auto sync is masked.
    SharedPreferences.setMockInitialValues({
      'schoolLifetimeProbeEnabled': true,
      'sessionProbePolicyVersion': 2,
      'sessionProbeMode': 'manual',
      'schoolReconnectMinutes': 120,
    });
    final now = DateTime.now().toUtc();
    final store = await Store.open();
    try {
      await store.setMeta('sessionEpoch', 'e1');
      await store.setMeta('schoolSessionLostEpoch', 'e1');
      // Lost a full day ago: the 120-minute reconnect wait has long elapsed.
      await store.setMeta(
        'schoolSessionLostAt',
        now.subtract(const Duration(days: 1)).toIso8601String(),
      );
      final state = SessionLifetime()
        ..session = 'S'
        ..successes = 3
        ..losses = 1
        ..lost = true
        ..lastValidatedAt = now.millisecondsSinceEpoch - 2 * 86400000
        ..lastTrafficAt = now.millisecondsSinceEpoch - 86400000;
      await store.setMeta(
        sessionLifetimeKey,
        jsonEncode({'epoch': 'e1', 'state': state.toJson()}),
      );
    } finally {
      await store.db.close();
    }

    await runSessionLifetimeProbe();

    final check = await Store.open();
    try {
      final after = await SessionLifetimeRepository(check).read('e1');
      // Card promises: "설정한 재로그인 대기 후 다음 회차를 준비해요".
      // A prepare attempt reserves a probe slot in the daily budget.
      expect(after.probes, hasLength(1),
          reason: 'worker should reserve/prepare once the wait has elapsed');
    } finally {
      await check.db.close();
    }
  });
}

// ignore_for_file: depend_on_referenced_packages
// P1-02 repro: reconcile() reads the 'scheduled' list from the isolate-local
// SharedPreferences cache without reload(). A reminder persisted by another
// isolate (workmanager worker) is invisible, so it is never cancelled.
import 'dart:io';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/services.dart';
import 'package:campus_radar/core/notification_gateway.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shared_preferences_platform_interface/shared_preferences_platform_interface.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  late Directory temp;
  late Store store;
  final calls = <MethodCall>[];
  const channel = MethodChannel('dexterous.com/flutter/local_notifications');
  setUp(() async {
    temp = await Directory.systemTemp.createTemp('p1-stale-prefs-');
    await databaseFactory.setDatabasesPath(temp.path);
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (c) async {
      calls.add(c);
      return c.method == 'initialize' || c.method == 'areNotificationsEnabled'
          ? true
          : null;
    });
    SharedPreferences.setMockInitialValues({});
    FlutterLocalNotificationsPlatform.instance =
        AndroidFlutterLocalNotificationsPlugin();
    await initNotifications();
    store = await Store.open();
  });
  tearDown(() async {
    await store.db.close();
    await temp.delete(recursive: true);
  });

  test('reminder scheduled by worker isolate is cancelled after task is done', () async {
    CampusItem task(String status) => CampusItem(
          key: 'synthetic', type: 'LR', title: 'T', course: 'C', courseId: 'c',
          classNo: '1', contentsId: 'x', status: status, context: {},
          due: DateTime.utc(2100, 1, 1));
    final pending = task('pending');
    final token = 'due:${pending.key}:${pending.due!.toIso8601String()}';
    // UI isolate has already loaded its prefs cache (scheduled = none).
    expect((await SharedPreferences.getInstance()).getStringList('scheduled'), isNull);
    // Worker isolate scheduled the reminder and persisted it to disk.
    await store.replace([pending]);
    await store.setMeta(token, 'scheduled');
    await SharedPreferencesStorePlatform.instance
        .setValue('StringList', 'flutter.scheduled', [token]);
    // User submits the task; UI-isolate collection reconciles.
    await store.replace([task('done')]);
    calls.clear();
    await reconcile(store);
    expect(calls.where((c) => c.method == 'cancel').length, 1,
        reason: 'stale reminder for the completed task must be cancelled');
  });
}

// ignore_for_file: unused_local_variable
// P6-03 repro: quick-confirm undo has no session check; after logout wiped meta
// it resurrects the previous account's AI decision record.
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/ai/ai_inbox_page.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/core/session_scope.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  late String cancelKey;
  late String examKey;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    temp = await Directory.systemTemp.createTemp('review-ux-');
    await databaseFactory.setDatabasesPath(temp.path);
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          (c) async => c.method == 'read' ? 'synthetic' : null,
        );
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('campus_radar/native'),
          (c) async => null,
        );
    final s = await Store.open();
    try {
      await s.setMeta(
        'timetableEntries',
        jsonEncode([
          const ClassSlot(
            courseKey: 'c:1',
            course: '예시 수업',
            weekday: 3,
            start: 780,
            end: 1020,
          ).toJson(),
        ]),
      );
      for (final kind in ['exam', 'audience', 'cancel']) {
        final body = kind == 'cancel'
            ? '11월 4일 수업 휴강입니다.'
            : '11월 4일 13:00에 진행합니다.';
        final n = CampusNotice(
          id: kind,
          title: '안내 $kind',
          course: '예시 수업',
          body: body,
          bodyFetched: true,
          context: {'course_id': 'c', 'class_no': '1'},
        );
        final c = ScheduleCandidate(
          title: kind == 'exam'
              ? '중간고사'
              : kind == 'audience'
              ? '조건부 발표'
              : '수업 휴강',
          date: '2026-11-04',
          time: kind == 'cancel' ? '' : '13:00',
          action: kind == 'cancel' ? 'cancel' : 'add',
          evidence: body,
          uncertainty: '',
          category: kind == 'cancel' ? 'class' : 'exam',
          condition: kind == 'audience' ? 'conditional' : 'required',
        );
        final key = candidateKey(n, c);
        if (kind == 'cancel') cancelKey = key;
        if (kind == 'exam') examKey = key;
        await s.saveNotice(n);
        await s.setMeta(
          'aiCandidate:$kind',
          jsonEncode({
            'notice': n.toJson(),
            'candidate': c.toJson(),
            'key': key,
          }),
        );
      }
    } finally {
      await s.db.close();
    }
  });
  tearDown(() async {
    for (final name in [
      'plugins.it_nomads.com/flutter_secure_storage',
      'campus_radar/native',
    ]) {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(MethodChannel(name), null);
    }
    await temp.delete(recursive: true);
  });
  Future<void> settle(WidgetTester t) async {
    for (var i = 0; i < 5; i++) {
      await t.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 80)),
      );
      await t.pump();
    }
    await t.pumpAndSettle();
  }
  testWidgets('undo after logout does not write into the wiped store', (t) async {
    await t.runAsync(() async {
      final s = await Store.open();
      try { await s.setMeta('aiCalendarDefault', 'no'); } finally { await s.db.close(); }
    });
    await t.pumpWidget(const MaterialApp(home: AiInboxPage()));
    await settle(t);
    await t.tap(find.widgetWithText(ChoiceChip, '바로 추가'));
    await t.pumpAndSettle();
    await t.tap(find.text('일정에 추가').first);
    await settle(t);
    expect(find.text('실행 취소'), findsOneWidget);
    await t.runAsync(() async { // performAccountLogout's DB steps
      final s = await Store.open();
      try {
        await SessionScope.rotate(s, blocked: true);
        await s.db.delete('meta', where: 'id NOT IN (?,?)', whereArgs: ['sessionEpoch', 'sessionBlocked']);
      } finally { await s.db.close(); }
    });
    await t.tap(find.text('실행 취소'));
    await settle(t);
    await t.runAsync(() async {
      final s = await Store.open();
      try { expect(await s.meta('aiState:$examKey'), isNull); } finally { await s.db.close(); }
    });
    await t.pumpWidget(const SizedBox.shrink());
    await settle(t);
  });
}

import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'package:campus_radar/schedule/timetable_share.dart';

void main() {
  test('P7-1 table header containing 담당교수 before the times must not drop all slots', () {
    // Syllabus table extracted one cell per line (SyllabusFetchActivity joins text nodes with \n).
    const text = '강의시간표\n요일\n시간\n강의실\n담당교수\n월\n09:00~10:15\n공학관 101\n홍길동';
    expect(parsePlanSlots(text, 'c:1', '예시').map((s) => s.weekday), [1]);
  });

  test('P7-2 cancellation range cap is "1년 이내" (<= 366 calendar days)', () {
    final slot = ClassSlot(courseKey: 'c:1', course: 'x', weekday: 5, start: 540, end: 600);
    // 2026-01-02 .. 2027-01-01 inclusive is 365 days; 2026-01-02 .. 2027-01-08 is 372 days.
    expect(
      () => planCancellations([slot], {slot.id}, DateTime(2026, 1, 1), DateTime(2027, 1, 2)),
      throwsFormatException,
      reason: '367 calendar days (two of the same weekday-date pair: Jan 1/2 2026 and Jan 1/2 2027)',
    );
  });

  test('P7-3 a room with a tab from the syllabus makes room-sharing impossible', () {
    final slots = parsePlanSlots('화 09:00~10:00(공학관\t301)', 'c:1', '예시');
    expect(slots.single.room, '공학관 301'); // tab normalised at parse time
    expect(
      () => encodeTimetable(slots, id: '0123456789abcdef0123456789abcdef', rooms: true),
      returnsNormally,
    );
  });
}

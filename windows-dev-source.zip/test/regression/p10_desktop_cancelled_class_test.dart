// P10 repro: Windows "class starting soon" alert ignores saved cancellations (휴강).
import 'dart:convert';
import 'dart:io';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';
import 'package:campus_radar/platform/desktop.dart';
import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

class Alerts extends FlutterLocalNotificationsPlatform
    implements FlutterLocalNotificationsWindows {
  @override
  dynamic noSuchMethod(Invocation i) => super.noSuchMethod(i);
  final shown = <int>[];
  @override
  Future<void> show(int id, String? title, String? body,
      {String? payload, WindowsNotificationDetails? details}) async => shown.add(id);
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  test('cancelled class on that date gets no pre-class alert', () async {
    debugDefaultTargetPlatformOverride = TargetPlatform.windows;
    SharedPreferences.setMockInitialValues({});
    final alerts = Alerts();
    FlutterLocalNotificationsPlatform.instance = alerts;
    final temp = await Directory.systemTemp.createTemp('p10-desk-');
    await databaseFactory.setDatabasesPath(temp.path);
    final store = await Store.open();
    try {
      final p = await SharedPreferences.getInstance();
      await p.setBool('desktopTimetableEnabled', true);
      await p.setInt('desktopTimetableLead', 30);
      await p.setString('desktopTimetableUntil', '2026-12-31');
      const slot = ClassSlot(courseKey: 'c', course: 'Synthetic', weekday: 3, start: 600, end: 660);
      await store.setMeta('timetableEntries', jsonEncode([slot.toJson()]));
      await CancellationRepository(store).change((l) =>
          [...l, ClassCancellation('x1', slot.id, '2026-10-21', 'Synthetic', 'manual')]);
      expect((await CancellationRepository(store).read()).entries.single.date, '2026-10-21');
      // 2026-10-21 09:31 KST (Wed), class at 10:00 KST, cancelled that date.
      await desktopTimetableAlerts(store, p, clock: DateTime.utc(2026, 10, 21, 0, 31));
      expect(alerts.shown, isEmpty);
    } finally {
      await store.db.close();
      await temp.delete(recursive: true);
      debugDefaultTargetPlatformOverride = null;
    }
  });
}

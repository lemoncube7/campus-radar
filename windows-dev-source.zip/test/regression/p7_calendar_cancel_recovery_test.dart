import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';
import 'package:campus_radar/schedule/schedule_repository.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  late Store store;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    temp = await Directory.systemTemp.createTemp('p7-cal-');
    await databaseFactory.setDatabasesPath(temp.path);
    store = await Store.open();
  });
  tearDown(() async {
    await store.db.close();
    await temp.delete(recursive: true);
  });
  const slot = ClassSlot(courseKey: 'c:1', course: '예시', weekday: 3, start: 780, end: 1020);
  test('P7-4 calendar honours the same recovered cancellations as today card/notifications', () async {
    await store.setMeta('timetableEntries', jsonEncode([slot.toJson()]));
    final repo = CancellationRepository(store);
    await repo.apply([ClassCancellation('2026-10-28:${slot.id}', slot.id, '2026-10-28', '예시', '공지')]);
    await store.setMeta(CancellationRepository.key, '{'); // root damaged, lastGood intact
    expect((await repo.read()).entries.length, 1); // today card / iOS alerts path
    final snap = await ScheduleRepository(store).read(); // calendar path
    expect(classesOnDate(snap.classes, snap.cancellations, DateTime(2026, 10, 28)), isEmpty);
  });
}

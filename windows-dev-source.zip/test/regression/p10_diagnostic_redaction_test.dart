// P10 repro: redactDiagnostic misses common secret encodings.
import 'package:campus_radar/core/diagnostic_export.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('form field usr_pwd=<secret> is redacted', () {
    expect(redactDiagnostic('POST /ilos/lo/login.acl usr_id=x&usr_pwd=S3CRETpw'),
        isNot(contains('S3CRETpw')));
  });
  test('JSON "password": "<secret>" is redacted', () {
    expect(redactDiagnostic('body {"user":"a","password":"S3CRETpw"}'),
        isNot(contains('S3CRETpw')));
  });
  test('JSESSIONID=<value> outside a URL is redacted', () {
    expect(redactDiagnostic('cookie jar: JSESSIONID=ABCDEF0123456789SESSION'),
        isNot(contains('ABCDEF0123456789SESSION')));
  });
  test('scheme-less URL query access_token is redacted', () {
    expect(redactDiagnostic('redirect //dcs-learning.cnu.ac.kr/a?access_token=TKN123456'),
        isNot(contains('TKN123456')));
  });
}

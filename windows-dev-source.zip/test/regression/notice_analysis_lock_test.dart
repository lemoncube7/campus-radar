// P4-07: the app and the background worker run in different isolates, so the
// per-notice analysis lock must live in the shared database.
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/ai/ai_request_budget.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;

  test('a second claimant on the same notice is refused until release', () async {
    SharedPreferences.setMockInitialValues({});
    final temp = await Directory.systemTemp.createTemp('notice-lock-');
    await databaseFactory.setDatabasesPath(temp.path);
    final a = await Store.open();
    try {
      final owner = await claimNoticeAnalysis(a, 'n1');
      // Another isolate would see the same row.
      await expectLater(
        claimNoticeAnalysis(a, 'n1'),
        throwsA(isA<AiFailure>().having((e) => e.code, 'code', 'busy')),
      );
      // A different notice is unaffected.
      final other = await claimNoticeAnalysis(a, 'n2');
      await releaseNoticeAnalysis(a, 'n2', other);
      // Only the owner can release.
      await releaseNoticeAnalysis(a, 'n1', 'someone-else');
      await expectLater(claimNoticeAnalysis(a, 'n1'), throwsA(isA<AiFailure>()));
      await releaseNoticeAnalysis(a, 'n1', owner);
      final again = await claimNoticeAnalysis(a, 'n1');
      expect(again, isNot(owner));
    } finally {
      await a.db.close();
      await temp.delete(recursive: true);
    }
  });
}

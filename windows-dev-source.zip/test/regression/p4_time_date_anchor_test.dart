import 'dart:convert';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/ai/ai_approval_policy.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:flutter_test/flutter_test.dart';

CampusNotice notice(String body) => CampusNotice(
  id: 'p4',
  title: '일정 안내',
  course: '예시 과목',
  context: const {},
  body: body,
  bodyFetched: true,
  published: DateTime.parse('2026-10-12T19:32:00+09:00'),
);
Map<String, dynamic> ev(String date, String time, {List<String>? ids, String? evidence, String category = 'task'}) => {
  'title': '예시 일정', 'date': date, 'time': time,
  if (ids != null) 'sourceIds': ids,
  if (evidence != null) 'evidence': evidence,
  'action': 'add', 'category': category, 'uncertainty': '',
  'endDate': '', 'endTime': '', 'condition': 'unspecified',
};
Map<String, dynamic> resp(List events) => {
  'candidates': [
    {'finishReason': 'STOP', 'content': {'parts': [{'text': jsonEncode({'events': events})}]}},
  ],
};
List<ScheduleCandidate> parse(CampusNotice n, Map<String, dynamic> e) => parseAiResponse(resp([e]), n);
final now = DateTime.parse('2026-11-03T12:00:00+09:00');
bool rejected(CampusNotice n, Map<String, dynamic> e) {
  try {
    return !eligibleForAutoApproval(n, parse(n, e).single, now);
  } on AiFailure {
    return true;
  }
}

void main() {
  // P4-01: 자정 deadline maps to 00:00 of the SAME day (24h early); 23:59 / next-day 00:00 rejected.
  test('P4-01a 자정까지 deadline accepts 23:59 of that day', () {
    final n = notice('과제는 11월 20일 자정까지 제출하세요.');
    expect(() => parse(n, ev('2026-11-20', '23:59', ids: ['P1'])), returnsNormally);
  });
  test('P4-01b 자정 is not accepted as 00:00 at the START of the stated day', () {
    final n = notice('과제는 11월 20일 자정까지 제출하세요.');
    expect(rejected(n, ev('2026-11-20', '00:00', ids: ['P1'])), isTrue);
  });
  test('P4-01c 24:00까지 accepts 23:59', () {
    final n = notice('과제는 11월 20일 24:00까지 제출하세요.');
    expect(() => parse(n, ev('2026-11-20', '23:59', ids: ['P1'])), returnsNormally);
  });
  // P4-02: 저녁/밤 period words ignored -> correct PM time rejected, AM time accepted.
  test('P4-02 저녁 7시 accepts 19:00 and not 07:00', () {
    final n = notice('11월 20일 저녁 7시 발표가 있습니다.');
    expect(() => parse(n, ev('2026-11-20', '19:00', ids: ['P1'], category: 'presentation')), returnsNormally);
  });
  test('P4-02b 저녁 7시 is not auto-approvable as 07:00', () {
    final n = notice('11월 20일 저녁 7시 발표가 있습니다.');
    expect(rejected(n, ev('2026-11-20', '07:00', ids: ['P1'], category: 'presentation')), isTrue);
  });
  // P4-03: "3시 반" (half past) not understood.
  test('P4-02c 밤 9시 and 새벽 2시 map to 21:00 and 02:00', () {
    expect(evidenceClocks('밤 9시'), contains('21:00'));
    expect(evidenceClocks('새벽 2시'), contains('02:00'));
  });
  test('P4-03 오후 3시 반 accepts 15:30', () {
    final n = notice('11월 20일 오후 3시 반 시험');
    expect(() => parse(n, ev('2026-11-20', '15:30', ids: ['P1'], category: 'exam')), returnsNormally);
  });
  // P4-04: duration "2시간" read as clock 02:00 and auto-approvable.
  test('P4-04 duration 2시간 is not a 02:00 clock anchor', () {
    final n = notice('11월 20일 기말 시험 (2시간)');
    expect(rejected(n, ev('2026-11-20', '02:00', ids: ['P1'], category: 'exam')), isTrue);
  });
  // P4-05: omitting sourceIds bypasses date/time anchor validation entirely.
  test('P4-05 event without sourceIds must still have date grounded', () {
    final n = notice('과제를 제출하세요.\n마감은 11월 20일입니다.');
    expect(() => parse(n, ev('2026-12-25', '09:00', evidence: '과제를 제출하세요.')),
        throwsA(isA<AiFailure>()));
  });
  // P4-06: year never checked against the notice's publish year.
  test('P4-06 yearless 11월 20일 cannot auto-approve as 2031-11-20', () {
    final n = notice('11월 20일 10:00 기말 시험');
    expect(rejected(n, ev('2031-11-20', '10:00', ids: ['P1'], category: 'exam')), isTrue);
  });
}

// P5 repro: re-enabling auto analysis (or changing scope) wipes every
// aiQueue row, so a notice the user explicitly excluded from AI analysis is
// re-queued as pending and will be sent to Gemini. Read-only on lib/.
import 'dart:convert';
import 'dart:io';
import 'package:campus_radar/ai/ai_recovery.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/ai/automation_settings_card.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

const channel = MethodChannel('plugins.it_nomads.com/flutter_secure_storage');

void main() {
  late Directory temp;
  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });
  tearDown(() async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, null);
  });

  testWidgets('excluded notice stays excluded after auto analysis is re-enabled', (
    tester,
  ) async {
    var keyReads = 0;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (c) async {
          // Key visible only to the settings guard; background worker then
          // sees no key and exits without any network attempt.
          if (c.method == 'read' && c.arguments['key'] == 'geminiApiKey') {
            return keyReads++ == 0 ? 'synthetic-test-key-000000' : null;
          }
          return null;
        });
    final n = CampusNotice(
      id: 'x', title: '개인 사정 공지', course: '가상 수업', context: {},
      published: DateTime.now().toUtc(), body: '본문', bodyFetched: true,
    );
    await tester.runAsync(() async {
      temp = await Directory.systemTemp.createTemp('p5-excl-');
      await databaseFactory.setDatabasesPath(temp.path);
      SharedPreferences.setMockInitialValues({});
      final s = await Store.open();
      await s.setMeta('aiConsent', '1');
      await s.setMeta('aiAuto', 'no'); // user turned auto off earlier
      await s.setMeta('aiScope', 'recent');
      await s.saveNotice(n);
      await excludeNoticeAnalysis(s, n); // user: "분석 제외"
      await s.db.close();
    });
    await tester.pumpWidget(const MaterialApp(
      home: Scaffold(body: SingleChildScrollView(child: AutomationControls())),
    ));
    await tester.runAsync(() => Future<void>.delayed(const Duration(seconds: 1)));
    await tester.pump();
    await tester.tap(find.byType(Switch).first); // turn auto analysis back on
    await tester.pump();
    await tester.runAsync(() async {
      await tester.tap(find.text('자동화 설정 저장·시작'));
      await Future<void>.delayed(const Duration(seconds: 3));
    });
    late String? status;
    await tester.runAsync(() async {
      final s = await Store.open();
      status = jsonDecode((await s.meta('aiQueue:x')) ?? '{}')['status'];
      await s.db.close();
      await Future<void>.delayed(const Duration(seconds: 6)); // drain worker timer
    });
    expect(status, 'excluded', reason: 'user exclusion must survive re-enable');
  });
}

import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/timetable_cancellations_page.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  testWidgets('P7-5 two sections with the same course name show the multi-section guidance', (tester) async {
    final dir = await tester.runAsync(() => Directory.systemTemp.createTemp('p7-sec-'));
    SharedPreferences.setMockInitialValues({});
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger.setMockMethodCallHandler(
        const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
        (call) async => call.method == 'read' ? 'synthetic' : null);
    await tester.runAsync(() async {
      await databaseFactory.setDatabasesPath(dir!.path);
      final s = await Store.open();
      await s.setMeta('timetableEntries', jsonEncode([
        const ClassSlot(courseKey: 'A:1', course: '자료구조', weekday: 1, start: 540, end: 615).toJson(),
        const ClassSlot(courseKey: 'A:2', course: '자료구조', weekday: 2, start: 540, end: 615).toJson(),
      ]));
      await s.db.close();
    });
    final notice = CampusNotice(id: 'n', title: '휴강 안내', course: '자료구조', body: '', context: {});
    await tester.pumpWidget(MaterialApp(home: CancellationEditor(notice: notice)));
    for (var i = 0; i < 20; i++) {
      await tester.runAsync(() => Future.delayed(const Duration(milliseconds: 50)));
      await tester.pump();
    }
    // ignore: avoid_print
    print('generic shown: ${find.textContaining("시간표를 읽지 못했어요").evaluate().length}');
    expect(find.textContaining('같은 이름의 분반이 여러 개예요'), findsOneWidget);
  });
}

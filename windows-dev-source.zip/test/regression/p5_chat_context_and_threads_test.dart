// P5 repros: chat context truncation keeps oldest items; corrupt thread JSON
// permanently breaks saving chat answers. Read-only on lib/.
import 'dart:convert';
import 'dart:io';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/ai/chat.dart';
import 'package:campus_radar/ai/chat_threads.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

CampusItem item(String key, DateTime due) => CampusItem(
  key: key,
  type: 'assignment',
  title: 'task $key',
  course: '가상 수업',
  courseId: 'c1',
  classNo: '1',
  contentsId: key,
  status: 'pending',
  due: due,
  context: {'course_id': 'c1', 'class_no': '1'},
);

void main() {
  late Directory temp;
  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });
  setUp(() async {
    temp = await Directory.systemTemp.createTemp('p5-chat-');
    await databaseFactory.setDatabasesPath(temp.path);
    SharedPreferences.setMockInitialValues({});
  });
  tearDown(() async => temp.delete(recursive: true));

  test('chat context keeps upcoming deadlines when >60 items exist', () async {
    final s = await Store.open();
    final now = DateTime.now().toUtc();
    // 65 past items (earlier in semester) + 3 upcoming deadlines this week.
    for (var i = 0; i < 65; i++) {
      final it = item('past$i', now.subtract(Duration(days: 70 - i)));
      await s.db.insert('items', {'id': it.key, 'payload': jsonEncode(it.toJson())});
    }
    for (var i = 0; i < 3; i++) {
      final it = item('soon$i', now.add(Duration(days: i + 1)));
      await s.db.insert('items', {'id': it.key, 'payload': jsonEncode(it.toJson())});
    }
    final data = jsonDecode(await chatContext(s));
    final titles = (data['items'] as List).map((e) => e['title']).toList();
    await s.db.close();
    expect(titles, contains('task soon0'),
        reason: '"이번 주 마감은?" needs upcoming items in the 60-item context');
  });

  test('corrupt saved thread JSON does not block saving a new answer', () async {
    final s = await Store.open();
    await s.setMeta('aiChat:all:threads', '[{"id":"x","title":"t","messages":[{"role":"user","text":null}]}]');
    Object? error;
    try {
      await saveChatThread(s, 'aiChat:all', ChatThread('new', 'q', [
        {'role': 'user', 'text': 'q'},
        {'role': 'model', 'text': 'a'},
      ]));
    } catch (e) {
      error = e;
    }
    await s.db.close();
    expect(error, isNull, reason: 'answer persistence should survive a bad legacy row');
  });
}

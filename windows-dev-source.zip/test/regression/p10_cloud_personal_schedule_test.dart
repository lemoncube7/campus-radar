// P10 repro: cloud snapshot uploads personal recurring schedules as "upcoming classes".
import 'dart:convert';
import 'dart:io';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/export/cloud_snapshot.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory dir;
  late Store store;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    dir = await Directory.systemTemp.createTemp('p10-cloud-');
    await databaseFactory.setDatabasesPath(dir.path);
    store = await Store.open();
  });
  tearDown(() async {
    await store.db.close();
    await dir.delete(recursive: true);
  });
  test('personal: schedule slots are not sent to the cloud server', () async {
    await store.setMeta('lastSuccess', '2026-10-30T00:00:00Z');
    await store.setMeta('timetableEntries', jsonEncode([
      const ClassSlot(courseKey: 'c1:1', course: '컴프2', weekday: 1, start: 600, end: 660).toJson(),
      const ClassSlot(courseKey: 'personal:1', course: 'PRIVATE_CLINIC_VISIT',
          weekday: 2, start: 900, end: 960, room: 'PRIVATE_PLACE').toJson(),
    ]));
    final payload = await buildCloudSnapshot(store, now: DateTime.utc(2026, 10, 30, 1));
    final upcoming = jsonEncode((payload['timetable'] as Map)['upcoming']);
    expect(upcoming, contains('컴프2'));
    expect(upcoming, isNot(contains('PRIVATE_CLINIC_VISIT')));
  });
}

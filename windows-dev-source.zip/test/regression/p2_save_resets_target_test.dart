// P2-02 repro: pressing "탐색 설정 저장" mid-experiment overwrites the learned
// idle target with the "첫 무요청 목표" (initial target) dropdown value.
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/session/session_exploration_page.dart';
import 'package:campus_radar/session/session_lifetime.dart';
import 'package:campus_radar/session/session_lifetime_repository.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  setUp(() async {
    SharedPreferences.setMockInitialValues({
      'schoolLifetimeProbeEnabled': true,
      'sessionProbePolicyVersion': 2,
      'sessionProbeMode': 'scheduled',
      'sessionProbeDays': ['6', '7'],
      'sessionProbeInitialMinutes': 60,
    });
    temp = await Directory.systemTemp.createTemp('p2-target-');
    await databaseFactory.setDatabasesPath(temp.path);
    final store = await Store.open();
    try {
      await store.setMeta('sessionEpoch', 'e1');
      // Experiment already climbed 60 -> 120 -> 240 -> 480 through successes.
      final state = SessionLifetime()
        ..session = 'S'
        ..successes = 5
        ..maxIdleMs = 240 * 60000
        ..searchFloorMs = 240 * 60000
        ..targetMinutes = 480;
      await store.setMeta(sessionLifetimeKey,
          jsonEncode({'epoch': 'e1', 'state': state.toJson()}));
    } finally {
      await store.db.close();
    }
  });
  tearDown(() async => temp.delete(recursive: true));

  Future<void> settle(WidgetTester t) async {
    for (var i = 0; i < 10; i++) {
      await t.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 30)));
      await t.pump();
    }
  }

  testWidgets('saving schedule edits keeps the learned target', (t) async {
    t.view.physicalSize = const Size(800, 3000);
    t.view.devicePixelRatio = 1;
    addTearDown(t.view.resetPhysicalSize);
    addTearDown(t.view.resetDevicePixelRatio);
    await t.pumpWidget(const MaterialApp(home: SessionExplorationPage()));
    await settle(t);
    // User only adds Friday to the schedule, then saves.
    await t.tap(find.text('금'));
    await t.pump();
    await t.tap(find.text('탐색 설정 저장'));
    await settle(t);
    final state = await t.runAsync(() async {
      final store = await Store.open();
      try {
        return await SessionLifetimeRepository(store).read('e1');
      } finally {
        await store.db.close();
      }
    });
    expect(state!.targetMinutes, 480);
  });
}

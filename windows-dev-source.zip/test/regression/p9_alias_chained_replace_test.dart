import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/courses/course_labels.dart';

// P9-3: displayCourseText re-scans already-substituted alias values, so an
// alias that contains another course's name gets rewritten a second time.
void main() {
  test('alias output is not re-substituted by a shorter course key', () {
    courseAliases = {'자료구조': '자구', '고급자료구조': '자료구조2'};
    expect(displayCourseText('고급자료구조 과제 마감'), '자료구조2 과제 마감');
  });
}

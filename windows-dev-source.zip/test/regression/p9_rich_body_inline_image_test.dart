import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/campus/campus_media.dart';
import 'package:campus_radar/campus/campus_rich_body.dart';

// P9-1: an <img> wrapped in an inline element (<a>, <span>) is counted by
// extractCampusMedia/campusBodyPieces but never rendered by CampusRichBody, so
// later images shift onto the wrong slot and the last image is never shown.
void main() {
  testWidgets('every body image index is requested by the renderer', (t) async {
    const body =
        '<p><a href="/x"><img src="/a.png"></a></p><p><img src="/b.png"></p>';
    final media = extractCampusMedia(body, null, notice: true);
    final pieceIdx = campusBodyPieces(body)
        .where((p) => p.imageIndex != null)
        .map((p) => p.imageIndex)
        .toList();
    final requested = <int>[];
    await t.pumpWidget(MaterialApp(
      home: Scaffold(
        body: CampusRichBody(
          source: body,
          imageAt: (i) {
            requested.add(i);
            return const SizedBox();
          },
        ),
      ),
    ));
    expect(media.where((m) => m.image).length, 2);
    expect(pieceIdx, [0, 1]);
    // Expected [0, 1]; the <a>-wrapped image is dropped and b.png is drawn
    // using media[0] (a.png). media[1] is never shown (pieces claims it).
    expect(requested, [0, 1]);
  });
}

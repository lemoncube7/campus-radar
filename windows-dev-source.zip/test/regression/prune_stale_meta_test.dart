// P3-4: per-day and per-deadline bookkeeping keys are pruned once past.
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;

  test('old day and deadline keys go, current ones and other keys stay', () async {
    SharedPreferences.setMockInitialValues({});
    final temp = await Directory.systemTemp.createTemp('prune-meta-');
    await databaseFactory.setDatabasesPath(temp.path);
    final s = await Store.open();
    try {
      await s.setMeta('desktopClassSent:2026-10-01:slot1', 'yes');
      await s.setMeta('desktopClassSent:2026-11-03:slot1', 'yes');
      await s.setMeta('due:LR:1:2026-10-01T14:59:00.000Z', 'sent');
      await s.setMeta('due:LR:2:2026-11-20T14:59:00.000Z', 'scheduled');
      await s.setMeta('excluded:LR:3', 'yes');
      await s.pruneStaleMeta(DateTime.utc(2026, 11, 3, 3));
      expect(await s.meta('desktopClassSent:2026-10-01:slot1'), isNull);
      expect(await s.meta('desktopClassSent:2026-11-03:slot1'), 'yes');
      expect(await s.meta('due:LR:1:2026-10-01T14:59:00.000Z'), isNull);
      expect(await s.meta('due:LR:2:2026-11-20T14:59:00.000Z'), 'scheduled');
      expect(await s.meta('excluded:LR:3'), 'yes');
    } finally {
      await s.db.close();
      await temp.delete(recursive: true);
    }
  });
}

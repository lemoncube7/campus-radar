// P8 repro: home/list count contracts on the Dashboard (read-only QA).
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:campus_radar/core/notification_gateway.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/tasks/task_detail_page.dart';

CampusItem item(String key, String type, String status, {DateTime? due}) =>
    CampusItem(
      key: key,
      type: type,
      title: 'T-$key',
      course: '가상 과목',
      courseId: 'c',
      classNo: '1',
      contentsId: key,
      status: status,
      due: due,
      context: const {},
    );

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    temp = await Directory.systemTemp.createTemp('p8d-');
    await databaseFactory.setDatabasesPath(temp.path);
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('dexterous.com/flutter/local_notifications'),
          (c) async => c.method == 'initialize' || c.method == 'areNotificationsEnabled' ? true : null,
        );
    FlutterLocalNotificationsPlatform.instance = AndroidFlutterLocalNotificationsPlugin();
    await initNotifications();
  });
  tearDown(() => temp.delete(recursive: true));

  testWidgets('"목록에 복구" on a not-task item actually restores it', (t) async {
    final due = DateTime.now().toUtc().add(const Duration(days: 3));
    final it = item('LR:c:1:a', 'LR', 'pending', due: due);
    await t.runAsync(() async {
      final s = await Store.open();
      try {
        await s.replace([it]);
        await s.setMeta('notTask:${it.key}', 'yes');
      } finally {
        await s.db.close();
      }
    });
    // Dashboard passes excluded.contains(key); store.excluded() includes notTask keys.
    await t.pumpWidget(MaterialApp(home: DetailPage(item: it, excluded: true)));
    for (var i = 0; i < 5; i++) {
      await t.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 60)));
      await t.pump();
    }
    await t.tap(find.byType(PopupMenuButton<String>));
    await t.pumpAndSettle();
    await t.tap(find.text('목록에 복구'));
    for (var i = 0; i < 8; i++) {
      await t.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 60)));
      await t.pump();
    }
    await t.pumpAndSettle();
    final stillHidden = await t.runAsync(() async {
      final s = await Store.open();
      try {
        return (await s.excluded()).contains(it.key);
      } finally {
        await s.db.close();
      }
    });
    final pageSaysRestored = find.text('목록에서 제외됨 · 알림 꺼짐').evaluate().isEmpty;
    debugPrint('DIAG restored=$pageSaysRestored hidden=$stillHidden err=${find.textContaining('하지 못').evaluate().length}');
    expect(pageSaysRestored && stillHidden!, isFalse,
        reason: 'page restored=$pageSaysRestored, store still hidden=$stillHidden, '
            'error snackbar=${find.text('변경하지 못했습니다. 다시 시도해 주세요.').evaluate().isNotEmpty}');
  });
}

// P3 repro: logout deletes credentials first; if the data-wipe step then fails
// (DB busy), previous-account data stays and, with credentials gone, the
// logout entry point (shown only when `loggedIn`) disappears, so the advised
// "다시 로그아웃해 주세요" retry is impossible.
import 'dart:io';
import 'package:campus_radar/campus/account_service.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  test('partial logout leaves old data with no way to retry', () async {
    final temp = await Directory.systemTemp.createTemp('p3-logout-');
    await databaseFactory.setDatabasesPath(temp.path);
    SharedPreferences.setMockInitialValues({});
    final vault = <String, String>{'id': 'synthetic-a', 'pw': '***'};
    final m = TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    m.setMockMethodCallHandler(
      const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
      (c) async {
        final a = (c.arguments as Map?) ?? {};
        switch (c.method) {
          case 'read':
            return vault[a['key']];
          case 'deleteAll':
            vault.clear();
            return null;
        }
        return null;
      },
    );
    m.setMockMethodCallHandler(
      const MethodChannel('plugins.flutter.io/path_provider'),
      (c) async => temp.path,
    );
    final seed = await Store.open();
    await seed.replace([
      CampusItem(
        key: 'LR:prev-account',
        type: 'LR',
        title: 'Previous account task',
        course: 'Previous course',
        courseId: 'c',
        classNo: '1',
        contentsId: 'x',
        status: 'pending',
        due: DateTime.now().toUtc().add(const Duration(days: 2)),
        context: const {},
      ),
    ]);
    await seed.db.close();
    // Another isolate (e.g. background collection) holds a write lock.
    final locker = await databaseFactoryFfi.openDatabase(
      '${temp.path}/campus.db',
    );
    await locker.execute('BEGIN EXCLUSIVE');
    final failures = await performAccountLogout();
    await locker.execute('COMMIT');
    await locker.close();
    final after = await Store.open();
    final items = await after.items();
    await after.db.close();
    final loggedIn =
        await credentials.read(key: 'id') != null &&
        await credentials.read(key: 'pw') != null;
    // ignore: avoid_print
    print('failures=$failures items=${items.length} loggedIn=$loggedIn');
    expect(failures, contains('수집 정보 삭제'));
    // Correct: either the data is gone, or the account is still "logged in"
    // so the logout button (settings_page.dart:170 `if (connected)`) remains.
    expect(
      items.isEmpty || loggedIn,
      isTrue,
      reason: 'old account data retained while logout entry is hidden',
    );
  }, timeout: const Timeout(Duration(minutes: 2)));
}

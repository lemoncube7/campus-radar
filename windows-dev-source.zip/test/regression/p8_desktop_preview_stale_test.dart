// ignore_for_file: unused_element
// P8 repro: home/list count contracts on the Dashboard (read-only QA).
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/home/home_navigation.dart';
import 'package:campus_radar/main.dart';
import 'package:campus_radar/tasks/task_presentation.dart';

CampusItem item(String key, String type, String status, {DateTime? due}) =>
    CampusItem(
      key: key,
      type: type,
      title: 'T-$key',
      course: '가상 과목',
      courseId: 'c',
      classNo: '1',
      contentsId: key,
      status: status,
      due: due,
      context: const {},
    );

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    homeNavigation.value = null;
    temp = await Directory.systemTemp.createTemp('p8-');
    await databaseFactory.setDatabasesPath(temp.path);
    final m = TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    m.setMockMethodCallHandler(
      const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
      (c) async => c.method == 'read' ? 'synthetic' : null,
    );
    m.setMockMethodCallHandler(
      const MethodChannel('campus_radar/native'),
      (c) async => null,
    );
  });
  tearDown(() async {
    final m = TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    for (final ch in [
      'plugins.it_nomads.com/flutter_secure_storage',
      'campus_radar/native',
    ]) {
      m.setMockMethodCallHandler(MethodChannel(ch), null);
    }
    await temp.delete(recursive: true);
  });
  Future<void> settle(WidgetTester t) async {
    for (var i = 0; i < 8; i++) {
      await t.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 70)));
      await t.pump();
    }
  }

  Future<void> seed(List<CampusItem> items, Map<String, String> meta) async {
    final s = await Store.open();
    try {
      await s.replace(items);
      for (final e in meta.entries) {
        await s.setMeta(e.key, e.value);
      }
    } finally {
      await s.db.close();
    }
  }

  Future<void> pumpDash(WidgetTester t) async {
    t.view.physicalSize = const Size(600, 1400);
    t.view.devicePixelRatio = 1;
    addTearDown(t.view.resetPhysicalSize);
    addTearDown(t.view.resetDevicePixelRatio);
    await t.pumpWidget(const RadarApp(home: Dashboard(autoSync: false)));
    await settle(t);
  }

  Future<void> close(WidgetTester t) async {
    await t.pumpWidget(const SizedBox.shrink());
    await settle(t);
  }

  testWidgets('desktop preview is cleared when the account is gone', (t) async {
    final later = DateTime.now().toUtc().add(const Duration(days: 3));
    await t.runAsync(() => seed([item('LR:c:1:a', 'LR', 'pending', due: later)], {}));
    t.view.physicalSize = const Size(1400, 1000);
    t.view.devicePixelRatio = 1;
    addTearDown(t.view.resetPhysicalSize);
    addTearDown(t.view.resetDevicePixelRatio);
    await t.pumpWidget(const RadarApp(home: Dashboard(autoSync: false)));
    await settle(t);
    await t.tap(find.text('T-LR:c:1:a').first);
    await settle(t);
    expect(find.byType(DesktopTaskPreview), findsOneWidget);
    // Simulate the post-logout state: credentials and collected items wiped.
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          (c) async => null,
        );
    await t.runAsync(() async {
      final s = await Store.open();
      try {
        await s.db.delete('items');
      } finally {
        await s.db.close();
      }
    });
    t.binding.handleAppLifecycleStateChanged(AppLifecycleState.inactive);
    t.binding.handleAppLifecycleStateChanged(AppLifecycleState.resumed);
    await settle(t);
    expect(find.text('포털 연결'), findsWidgets); // logged-out home is shown
    expect(find.text('T-LR:c:1:a'), findsNothing,
        reason: 'previous account item still rendered in DesktopTaskPreview');
    await t.pumpWidget(const SizedBox.shrink());
    await settle(t);
  });
}

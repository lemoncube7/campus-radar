// P6-02 repro: two grounded candidates from one enumerated sentence (same
// title + evidence, different dates) share candidateKey, so the inbox shows one.
import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/ai/ai_inbox_repository.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/campus/campus_models.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  test('each enumerated date stays a separate reviewable candidate', () async {
    SharedPreferences.setMockInitialValues({});
    final temp = await Directory.systemTemp.createTemp('p6-key-');
    await databaseFactory.setDatabasesPath(temp.path);
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          (c) async => null,
        );
    const quote = '2026년 11월 4일(수), 11일(수) 퀴즈';
    final n = CampusNotice(
      id: 'n1',
      title: '퀴즈 안내',
      course: '예시 수업',
      body: '$quote를 진행합니다.',
      bodyFetched: true,
      context: {'course_id': 'c', 'class_no': '1'},
    );
    Map<String, dynamic> cand(String date) => {
      'title': '퀴즈', 'date': date, 'time': '', 'action': 'add',
      'evidence': quote, 'sourceQuotes': [quote], 'uncertainty': '',
      'category': 'exam', 'condition': 'required',
    };
    final rows = [cand('2026-11-04'), cand('2026-11-11')];
    final parsed = [
      for (final r in rows) ScheduleCandidate.parse(r, '${n.title}\n${n.body}'),
    ];
    final s = await Store.open();
    try {
      await s.saveNotice(n);
      await s.setMeta('aiCache:${n.id}:${noticeFingerprint(n)}', jsonEncode(rows));
      final keys = parsed.map((c) => candidateKey(n, c)).toSet();
      final inbox = await AiInboxRepository(s).read();
      expect(
        inbox.candidates.map((r) => (r['candidate'] as ScheduleCandidate).date),
        unorderedEquals(['2026-11-04', '2026-11-11']),
        reason: 'distinct keys=${keys.length}',
      );
    } finally {
      await s.db.close();
      await temp.delete(recursive: true);
    }
  });
}

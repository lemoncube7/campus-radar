import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/campus/campus_media.dart';
import 'package:campus_radar/campus/media_cache.dart';

// P9-2: safeName caps at 100 *characters*, but data(m) prefixes a 64-char hash.
// Korean names are 3 UTF-8 bytes/char, so the basename exceeds the 255-byte
// NAME_MAX of ext4/f2fs/APFS -> rename/write fails with ENAMETOOLONG on device.
void main() {
  test('cache data file basename fits in 255 bytes', () {
    final cache = MediaCache(Directory.systemTemp);
    final m = CampusMedia(
      name: '${'가' * 90}.pdf',
      url: 'https://dcs-lcms.cnu.ac.kr/api/v1/file/downloadSingleFile',
      form: const {'file_no': '1'},
    );
    final base = cache.data(m).path.split('/').last;
    expect(utf8.encode(base).length, lessThanOrEqualTo(255));
  });
}

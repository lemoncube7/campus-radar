// The partial-failure merges extracted from synchronize().
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/services.dart';

CampusItem item(String key, String type, {String status = 'pending'}) =>
    CampusItem.fromJson({
      'key': key,
      'type': type,
      'title': key,
      'course': '예시',
      'courseId': 'c',
      'classNo': '1',
      'contentsId': key,
      'status': status,
      'context': {'course_id': 'c', 'class_no': '1'},
    });

void main() {
  test('a task whose detail failed keeps its old record as unknown', () {
    final merged = keepDetailOnTaskWarnings(
      [item('LR:1', 'LR', status: 'pending')],
      {'LR:1': item('LR:1', 'LR', status: 'done')},
      {'LR:1'},
    );
    expect(merged.single.status, 'unknown');
  });

  test('materials of a course whose list failed are kept', () {
    final old = item('LS:9', 'LS');
    final merged = keepMaterialsOnResourceWarnings(
      [item('LR:1', 'LR')],
      {'LS:9': old},
      {'LSCOURSE:${old.courseId}:${old.classNo}'},
    );
    expect(merged.map((i) => i.key), containsAll(['LR:1', 'LS:9']));
  });
}

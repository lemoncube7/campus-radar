// P1-01 repro: a rejected school login records no hold, so every later
// automatic collection submits the (wrong) password again.
import 'dart:io';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/campus/campus_session.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

class RejectingCampus extends CampusClient {
  int logins = 0;
  @override
  Future<void> login(String id, String password) async {
    logins++;
    throw CampusLoginRejected('synthetic rejection');
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  final secure = <String, String>{};
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    secure..clear()..addAll({'id': 'synthetic', 'pw': '***'});
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          (call) async {
            final a = Map<String, dynamic>.from(call.arguments as Map);
            if (call.method == 'read') return secure[a['key']];
            if (call.method == 'write') secure[a['key'] as String] = a['value'] as String;
            if (call.method == 'delete') secure.remove(a['key']);
            return null;
          },
        );
    temp = await Directory.systemTemp.createTemp('p1-reject-');
    await databaseFactory.setDatabasesPath(temp.path);
  });
  tearDown(() async => temp.delete(recursive: true));

  test('second automatic connect after a rejected login is held, not retried', () async {
    final first = RejectingCampus();
    addTearDown(first.close);
    await expectLater(first.connectSchool('synthetic', '***'),
        throwsA(isA<CampusLoginRejected>()));
    final store = await Store.open();
    final lostAt = await store.meta('schoolSessionLostAt');
    await store.db.close();
    // Next periodic (non-foreground) collection, minutes later.
    final second = RejectingCampus();
    addTearDown(second.close);
    await expectLater(second.connectSchool('synthetic', '***'),
        throwsA(isA<CampusReconnectDeferred>()),
        reason: 'lostAt after rejection = "$lostAt"');
    expect(second.logins, 0);
  });
}

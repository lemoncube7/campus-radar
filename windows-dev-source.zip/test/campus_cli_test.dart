import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

import '../bin/campus_cli.dart';
import 'collection_request_budget_test.dart' show SemesterClient;

/// Records the fake semester into a cassette, then checks that replaying it
/// through the CLI client gives the same items and request counts.
class RecordingFake extends SemesterClient {
  final Directory dir;
  RecordingFake(this.dir);
  @override
  Future<dynamic> api(
    String route,
    Map<String, dynamic>? payload, {
    String host = 'https://dcs-learning.cnu.ac.kr',
  }) async {
    final response = route == '/board/std/notice/list'
        ? {
            'list': payload!['offset'] == 0
                ? [
                    for (var i = 0; i < 3; i++)
                      {
                        'boarditem_no': 'n$i',
                        'boarditem_title': '공지 $i',
                        'course_nm': '수업0',
                        'insert_dt': '2026-11-01 09:00',
                      },
                  ]
                : [],
          }
        : await super.api(route, payload, host: host);
    await File(
      '${dir.path}/${cassetteKey(route, payload, host)}.json',
    ).writeAsString(
      jsonEncode({'route': route, 'payload': payload, 'response': response}),
    );
    return response;
  }
}

void main() {
  test('replayed cassette reproduces a recorded collection', () async {
    // FAKE_CASSETTE=dir keeps the recording, e.g. for tool/pipeline_test.dart.
    final keep = Platform.environment['FAKE_CASSETTE'];
    final dir = keep != null
        ? (Directory(keep)..createSync(recursive: true))
        : await Directory.systemTemp.createTemp('cassette');
    if (keep == null) addTearDown(() => dir.delete(recursive: true));
    final fake = RecordingFake(dir);
    addTearDown(fake.close);
    final recorded = await fake.fetchItems();
    await fake.fetchNotices();

    final replay = CliClient(replay: dir, strict: true);
    addTearDown(replay.close);
    final items = await replay.fetchItems();
    expect(
      items.map((i) => i.key).toList(),
      recorded.map((i) => i.key).toList(),
    );
    expect(replay.calls['/archive/detail'], fake.calls['/archive/detail']);
    expect(replay.missing, isEmpty);

    final again = CliClient(replay: dir);
    addTearDown(again.close);
    await again.fetchItems(
      previous: {for (final i in items) i.key: i},
      reuseDetailsFor: const Duration(hours: 6),
    );
    expect(again.calls['/archive/detail'], isNull);
  });
}

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/main.dart';
import 'package:campus_radar/settings/settings_page.dart';
import 'package:campus_radar/settings/radar_theme.dart';
import 'package:campus_radar/ai/ai_chat_page.dart';
import 'package:campus_radar/schedule/timetable_page.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  setUp(() async {
    temp = await Directory.systemTemp.createTemp('radar-tablet-');
    await databaseFactory.setDatabasesPath(temp.path);
    SharedPreferences.setMockInitialValues({});
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          (_) async => null,
        );
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('campus_radar/native'),
          (c) async => c.method == 'timetableSettings'
              ? {'until': '2099-12-31', 'exactAllowed': true}
              : null,
        );
  });
  tearDown(() async {
    await temp.delete(recursive: true);
  });
  test(
    'concurrent cold database opens preserve schema and all writes',
    () async {
      final stores = await Future.wait(List.generate(16, (_) => Store.open()));
      try {
        await Future.wait([
          for (var i = 0; i < stores.length; i++)
            stores[i].setMeta('probe:$i', '$i'),
        ]);
        for (var i = 0; i < stores.length; i++) {
          expect(await stores.first.meta('probe:$i'), '$i');
        }
      } finally {
        for (final s in stores) {
          await s.db.close();
        }
      }
    },
  );
  test('version one database migrates and preserves records', () async {
    final db = await openDatabase(
      '${temp.path}/campus.db',
      version: 1,
      onCreate: (db, _) async {
        await db.execute(
          'CREATE TABLE items (id TEXT PRIMARY KEY, payload TEXT NOT NULL)',
        );
        await db.execute(
          'CREATE TABLE meta (id TEXT PRIMARY KEY, value TEXT NOT NULL)',
        );
        await db.execute(
          'CREATE TABLE events (id TEXT PRIMARY KEY, payload TEXT NOT NULL, delivered INTEGER NOT NULL DEFAULT 0)',
        );
        await db.insert('meta', {'id': 'existing', 'value': 'preserve'});
      },
    );
    await db.close();
    final s = await Store.open();
    try {
      expect(await s.meta('existing'), 'preserve');
      await s.log('test', 'migration', '');
      expect(await s.logs('all'), hasLength(1));
    } finally {
      await s.db.close();
    }
  });
  for (final size in [
    const Size(800, 1280),
    const Size(1280, 800),
    const Size(600, 960),
  ]) {
    testWidgets('tablet major screens ${size.width}x${size.height}', (t) async {
      t.view.physicalSize = size;
      t.view.devicePixelRatio = 1;
      addTearDown(t.view.resetPhysicalSize);
      addTearDown(t.view.resetDevicePixelRatio);
      final pages = <Widget>[
        const Dashboard(autoSync: false),
        SettingsHub(
          connected: true,
          connect: () {},
          logout: () {},
          test: () {},
        ),
        const AppearancePage(),
        const AiChatPage(),
        const TimetablePage(),
      ];
      for (final page in pages) {
        await t.pumpWidget(
          MaterialApp(
            home: MediaQuery(
              data: MediaQueryData(
                size: size,
                textScaler: const TextScaler.linear(1.5),
              ),
              child: page,
            ),
          ),
        );
        for (var i = 0; i < 12; i++) {
          await t.runAsync(
            () => Future<void>.delayed(const Duration(milliseconds: 25)),
          );
          await t.pump(const Duration(milliseconds: 100));
        }
        expect(
          t.takeException(),
          isNull,
          reason: '${page.runtimeType} at $size',
        );
        await t.pumpWidget(const SizedBox.shrink());
        await t.pump();
      }
    });
  }
  testWidgets(
    'tablet rail adapts to split screen while retaining selected section',
    (t) async {
      t.view.physicalSize = const Size(1280, 800);
      t.view.devicePixelRatio = 1;
      addTearDown(t.view.resetPhysicalSize);
      addTearDown(t.view.resetDevicePixelRatio);
      await t.pumpWidget(const MaterialApp(home: Dashboard(autoSync: false)));
      for (var i = 0; i < 10; i++) {
        await t.runAsync(
          () => Future<void>.delayed(const Duration(milliseconds: 20)),
        );
        await t.pump();
      }
      expect(find.byType(NavigationRail), findsOneWidget);
      await t.tap(
        find.descendant(
          of: find.byType(NavigationRail),
          matching: find.text('할 일'),
        ),
      );
      await t.pumpAndSettle();
      expect(
        t.widget<NavigationRail>(find.byType(NavigationRail)).selectedIndex,
        1,
      );
      t.view.physicalSize = const Size(600, 960);
      await t.pumpAndSettle();
      expect(find.byType(NavigationRail), findsNothing);
      expect(
        t.widget<NavigationBar>(find.byType(NavigationBar)).selectedIndex,
        1,
      );
      t.view.physicalSize = const Size(1280, 800);
      await t.pumpAndSettle();
      expect(
        t.widget<NavigationRail>(find.byType(NavigationRail)).selectedIndex,
        1,
      );
      expect(t.takeException(), isNull);
      await t.pumpWidget(const SizedBox.shrink());
      await t.pump();
    },
  );
}

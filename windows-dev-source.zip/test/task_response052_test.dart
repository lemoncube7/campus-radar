import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/tasks/task_response.dart';
import 'package:campus_radar/tasks/task_categories.dart';

class VariantClient extends CampusClient {
  @override
  Future<List<Map<String, dynamic>>> fetchCourses() async => [
    {
      'course_id': 'c',
      'class_no': '1',
      'course_nm': '테스트',
      'term_year': '2026',
      'term_cd': '2',
    },
  ];
  @override
  Future<dynamic> api(
    String route,
    Map<String, dynamic>? payload, {
    String host = CampusClient.learning,
  }) async {
    if (route == '/week/getStdWeekList') {
      return {
        'week_list': [
          for (var i = 1; i <= 3; i++)
            {'module_type': 'LR', 'report_no': '$i', 'report_nm': '과제 $i'},
        ],
      };
    }
    if (route == '/week/getStdEtcList') return {'etc_list': []};
    if (route == '/task/detail') {
      return payload?['report_no'] == '3'
          ? []
          : {
              'report_nm': '과제 ${payload?['report_no']}',
              'report_content': '본문',
            };
    }
    if (route == '/task/stdDetail') {
      return payload?['report_no'] == '1' ? [] : true;
    }
    return {};
  }
}

void main() {
  test(
    'empty no-submission responses are pending; ambiguous responses never become done',
    () {
      for (final value in [null, [], {}]) {
        expect(submissionStatus(value), 'pending');
      }
      expect(
        submissionStatus([
          {'report_apply_no': 1, 'apply_yn': 'Y'},
        ]),
        'done',
      );
      expect(
        submissionStatus({
          'report_apply_no': 1,
          'temp_yn': 'Y',
          'apply_yn': 'Y',
        }),
        'pending',
      );
      for (final value in [
        true,
        '',
        {'other': 'private body'},
        {'report_apply_no': 1},
      ]) {
        expect(submissionStatus(value), 'unknown');
      }
      expect(responseShape({'name': 'private body'}), 'Map(name)');
    },
  );
  test('one unusual task detail does not discard other tasks', () async {
    final client = VariantClient();
    try {
      final items = await client.fetchItems();
      expect(items.length, 3);
      expect(items.firstWhere((i) => i.contentsId == '1').status, 'pending');
      expect(items.where((i) => i.status == 'unknown').length, 2);
      expect(client.taskWarnings.length, 2);
    } finally {
      client.close();
    }
  });
  test(
    'waiting category separates future reports from actionable items and unpublished content',
    () {
      final now = DateTime.utc(2026, 10, 27);
      CampusItem item({
        String type = 'LR',
        bool published = true,
        String status = 'pending',
        DateTime? start,
      }) => CampusItem(
        key: 'x',
        type: type,
        title: '과제',
        course: '과목',
        courseId: 'c',
        classNo: '1',
        contentsId: '1',
        status: status,
        startsAt: start ?? now.add(const Duration(days: 1)),
        published: published,
        context: {},
      );
      final future = item();
      expect(categoryMatches(future, now, {}), false);
      expect(categoryMatches(future, now, {}, waiting: true), true);
      expect(
        categoryMatches(future, now.add(const Duration(days: 1)), {}),
        true,
      );
      expect(
        categoryMatches(
          future,
          now.add(const Duration(days: 1)),
          {},
          waiting: true,
        ),
        false,
      );
      expect(
        categoryMatches(item(published: false), now, {}, waiting: true),
        false,
      );
      expect(categoryMatches(item(type: 'LV'), now, {}, waiting: true), false);
      expect(
        categoryMatches(item(status: 'done'), now, {}, waiting: true),
        false,
      );
      expect(categoryMatches(future, now, {'x'}, waiting: true), false);
      expect(categoryMatches(future, now, {'x'}, hiddenOnly: true), true);
    },
  );
}

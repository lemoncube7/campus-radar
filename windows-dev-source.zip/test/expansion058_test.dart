import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:campus_radar/tasks/task_evaluation.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/campus_media.dart';
import 'package:campus_radar/campus/deadline_reminders.dart';
import 'package:campus_radar/courses/course_colors.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/personal_schedule_page.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() => SharedPreferences.setMockInitialValues({}));
  tearDown(() => courseColorOverrides.clear());
  test(
    'published personal result is displayed even without a submitted report; unpublished grades never enter model',
    () {
      final source = {
        'mark_yn': 'Y',
        'result_open_yn': 'Y',
        'report_scr': '0',
        'apply_yn': 'N',
        'report_apply_cmt': '<p>검토 완료</p>',
      };
      final result = releasedTaskEvaluation(source, {'allot_scr': 55});
      expect(result!.score, '0');
      expect(result.feedback, '검토 완료');
      expect(
        releasedTaskEvaluation({...source, 'result_open_yn': 'N'}, {}),
        isNull,
      );
      expect(releasedTaskEvaluation({...source, 'mark_yn': 'N'}, {}), isNull);
      expect(
        releasedTaskEvaluation({...source, 'report_scr': null}, {}),
        isNull,
      );
      expect(
        releasedTaskEvaluation({...source, 'report_scr': 'invalid'}, {}),
        isNull,
      );
      final item = CampusItem(
        key: 'a',
        type: 'LR',
        title: '점수',
        course: '과목',
        courseId: 'c',
        classNo: '1',
        contentsId: 'a',
        status: 'pending',
        context: {},
        evaluation: result,
      );
      expect(CampusItem.fromJson(item.toJson()).evaluation!.score, '0');
      final old = item.toJson()..remove('evaluation');
      expect(CampusItem.fromJson(old).evaluation, isNull);
    },
  );
  test(
    'image files and old cached attachments are identified without changing identity',
    () {
      final image = CampusMedia.fromJson({
        'name': '안내.PNG',
        'url': 'https://dcs-learning.cnu.ac.kr/file/a',
        'image': false,
      });
      expect(image.image, true);
      final files = extractCampusMedia('', [
        {'file_name': '첨부.jpg', 'save_name': '/a', 'file_size': 50},
      ], notice: true);
      expect(files.single.image, true);
      final restored = CampusMedia.fromJson(image.toJson());
      expect(restored.identity, image.identity);
    },
  );
  test(
    'multiple reminders normalize input, preserve legacy reservation, and select only nearest missed trigger',
    () {
      expect(parseDeadlineLeads(null), [1440]);
      expect(parseDeadlineLeads('[]'), isEmpty);
      expect(parseDeadlineLeads('[60,1440,60,-1,999999,"30"]'), [1440, 60]);
      expect(
        parseDeadlineLeads(jsonEncode(List.generate(12, (i) => i + 1))).length,
        6,
      );
      final due = DateTime.utc(2026, 11, 2, 12);
      expect(deadlineToken('x', due, 1440), 'due:x:${due.toIso8601String()}');
      expect(deadlineToken('x', due, 60), endsWith(':m60'));
      expect(
        latestElapsedLead(
          [4320, 1440, 60],
          due,
          due.subtract(const Duration(minutes: 30)),
        ),
        60,
      );
      expect(
        latestElapsedLead(
          [1440, 60],
          due,
          due.subtract(const Duration(days: 2)),
        ),
        isNull,
      );
    },
  );
  test(
    'course color choices persist independently and reset restores automatic color',
    () async {
      final original = courseAccent('a');
      await saveCourseColor('a', const Color(0xff123456));
      await saveCourseColor('b', const Color(0xffabcdef));
      courseColorOverrides.clear();
      await loadCourseColors();
      expect(courseAccent('a'), const Color(0xff123456));
      expect(courseAccent('b'), const Color(0xffabcdef));
      await saveCourseColor('a', null);
      expect(courseAccent('a'), original);
    },
  );
  test(
    'school rebuild preserves personal recurring events and drops obsolete school courses',
    () {
      ClassSlot slot(String key) => ClassSlot(
        courseKey: key,
        course: key,
        weekday: 1,
        start: 540,
        end: 600,
      );
      expect(
        retainCurrentTimetable(
          [slot('old'), slot('current'), slot('personal:1')],
          {'current'},
        ).map((e) => e.courseKey),
        ['current', 'personal:1'],
      );
    },
  );
  testWidgets(
    'personal recurring schedule validates and returns a weekly item',
    (t) async {
      ClassSlot? saved;
      await t.pumpWidget(
        MaterialApp(
          home: Builder(
            builder: (context) => Scaffold(
              body: TextButton(
                onPressed: () async {
                  saved = await Navigator.push<ClassSlot>(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const PersonalSchedulePage(),
                    ),
                  );
                },
                child: const Text('추가'),
              ),
            ),
          ),
        ),
      );
      await t.tap(find.text('추가'));
      await t.pumpAndSettle();
      await t.enterText(find.byType(TextField).first, '스터디');
      await t.scrollUntilVisible(
        find.text('저장'),
        200,
        scrollable: find.byType(Scrollable).first,
      );
      await t.tap(find.text('저장'));
      await t.pumpAndSettle();
      expect(saved, isNotNull);
      expect(saved!.courseKey, startsWith('personal:'));
      expect(saved!.course, '스터디');
      expect(saved!.end, greaterThan(saved!.start));
    },
  );
}

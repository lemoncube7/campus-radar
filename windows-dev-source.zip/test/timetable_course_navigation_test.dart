import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/navigation/app_navigation.dart';
import 'package:campus_radar/core/navigation_key.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/schedule/timetable_page.dart';
import 'package:campus_radar/schedule/timetable_model.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory dir;
  setUp(() async {
    dir = await Directory.systemTemp.createTemp('timetable-course-');
    await databaseFactory.setDatabasesPath(dir.path);
    SharedPreferences.setMockInitialValues({});
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('campus_radar/native'),
          (c) async => c.method == 'timetableSettings'
              ? <String, dynamic>{'exactAllowed': true}
              : null,
        );
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('window_manager'),
          (c) async => false,
        );
    final s = await Store.open();
    await s.setMeta(
      'courses',
      jsonEncode([
        {'course_id': 'fixture', 'class_no': '1', 'course_nm': '연결 시험 과목'},
      ]),
    );
    await s.setMeta(
      'timetableEntries',
      jsonEncode([
        const ClassSlot(
          courseKey: 'fixture:1',
          course: '연결 시험 과목',
          weekday: 1,
          start: 600,
          end: 660,
        ).toJson(),
      ]),
    );
    await s.db.close();
  });
  tearDown(() async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('campus_radar/native'),
          null,
        );
    await dir.delete(recursive: true);
  });
  Future<void> settle(WidgetTester t) async {
    for (var i = 0; i < 5; i++) {
      await t.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 60)),
      );
      await t.pump();
    }
    await t.pumpAndSettle();
  }

  testWidgets(
    'widget target opens timetable and explicit course chip routes exact saved course',
    (t) async {
      CourseDestination? opened;
      await t.pumpWidget(
        MaterialApp(
          navigatorKey: navKey,
          home: const Scaffold(body: Text('home')),
          onGenerateRoute: (settings) {
            final args = settings.arguments;
            if (args is TimetableDestination) {
              return MaterialPageRoute<void>(
                builder: (_) => const TimetablePage(),
              );
            }
            if (args is CourseDestination) {
              opened = args;
              return MaterialPageRoute<void>(
                builder: (_) => const Scaffold(body: Text('과목 도착')),
              );
            }
            return null;
          },
        ),
      );
      await t.runAsync(() => openItem('_timetable'));
      await settle(t);
      expect(find.byType(TimetablePage), findsOneWidget);
      await t.scrollUntilVisible(
        find.text('시간표 과목 바로가기'),
        300,
        scrollable: find.byType(Scrollable).first,
      );
      await t.tap(find.text('시간표 과목 바로가기'));
      await t.pumpAndSettle();
      final chip = find.byType(ActionChip);
      await t.scrollUntilVisible(
        chip,
        150,
        scrollable: find.byType(Scrollable).first,
      );
      await t.tap(chip);
      await settle(t);
      expect(find.text('과목 도착'), findsOneWidget);
      expect(opened?.course['course_id'], 'fixture');
      expect(opened?.course['class_no'], '1');
      expect(t.takeException(), isNull);
      await t.pumpWidget(const SizedBox.shrink());
    },
  );
}

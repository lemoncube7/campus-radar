import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/updates/updates.dart';

void main() {
  test('release without qualifier defaults to stable', () {
    expect(releaseChannelForVersion('0.5.10'), 'stable');
  });
  test('development and release candidates default to development', () {
    for (final v in ['0.5.10-dev.9', '0.5.10-rc.1', '0.6.0-beta.1']) {
      expect(releaseChannelForVersion(v), 'development');
    }
  });
  test('explicit valid build channel remains authoritative', () {
    expect(
      releaseChannelForVersion('0.5.10-dev.9', configured: 'stable'),
      'stable',
    );
    expect(
      releaseChannelForVersion('0.5.10', configured: 'development'),
      'development',
    );
  });
  test('unknown channel cannot silently label a dev build stable', () {
    expect(
      releaseChannelForVersion('0.5.10-dev.9', configured: 'typo'),
      'development',
    );
  });
}

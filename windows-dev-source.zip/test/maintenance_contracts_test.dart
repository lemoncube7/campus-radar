import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/ai/ai_state_repository.dart';
import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/ai/ai_state_models.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/campus/syllabus_loader.dart';
import 'package:campus_radar/campus/campus.dart';
import 'architecture_boundaries_test.dart' show libFiles, localImports;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test(
    'State repository keeps legacy keys; settings retain cancellation and summary invalidation',
    () async {
      sqfliteFfiInit();
      SharedPreferences.setMockInitialValues({'aiSummaryText': 'old'});
      final db = await databaseFactoryFfiNoIsolate.openDatabase(
        inMemoryDatabasePath,
      );
      await db.execute(
        'CREATE TABLE meta (id TEXT PRIMARY KEY, value TEXT NOT NULL)',
      );
      final store = Store(db), repo = AiStateRepository(Store(db));
      try {
        await repo.saveJob(
          'notice',
          AiJob.fromJson({'status': 'failed', 'attempts': 2, 'future': 42}),
        );
        expect(await repo.hasActiveJobs(), isFalse);
        await repo.saveJob(
          'notice',
          (await repo.job('notice')).withStatus(AiJobStatus.pending),
        );
        expect(await repo.hasActiveJobs(), isTrue);
        expect(jsonDecode((await store.meta('aiQueue:notice'))!)['future'], 42);
        await repo.saveSchedule(
          'key',
          ConfirmedSchedule.fromJson({
            'status': 'confirmed',
            'calendarId': '4',
          }),
        );
        expect((await repo.schedule('key')).isConfirmed, isTrue);
        await store.setAiSetting(AiSetting.aiAuto, 'yes');
        final epoch = await store.meta('sessionEpoch');
        await store.setAiSetting(AiSetting.aiAuto, 'yes');
        expect(await store.meta('sessionEpoch'), epoch);
        await store.setAiSetting(AiSetting.aiAuto, 'no');
        expect(await store.meta('sessionEpoch'), isNot(epoch));
        await store.setTaskExcluded('task', true);
        expect(await store.meta('excluded:task'), 'yes');
        expect(await store.meta('aiSummaryRevision'), isNotNull);
        expect(
          (await SharedPreferences.getInstance()).getString('aiSummaryText'),
          isNull,
        );
      } finally {
        await db.close();
      }
    },
  );
  test('Every module has an acyclic dependency path', () {
    final graph = localImports();
    final complete = <String>{}, active = <String>{};
    void visit(String file) {
      expect(
        active,
        isNot(contains(file)),
        reason: 'Dependency cycle at $file: $active',
      );
      if (complete.contains(file)) return;
      active.add(file);
      for (final dependency in graph[file] ?? <String>{}) {
        visit(dependency);
      }
      active.remove(file);
      complete.add(file);
    }

    for (final file in graph.keys) {
      visit(file);
    }
  });
  test('AI validation and generation cannot reach IO, storage or widgets', () {
    final graph = localImports();
    final seen = <String>{};
    void visit(String file) {
      if (!seen.add(file)) return;
      final source = libFiles()[file]!.readAsStringSync();
      for (final forbidden in [
        'dart:io',
        'package:http',
        'package:flutter/',
        'app_storage.dart',
        'native_bridge.dart',
      ]) {
        // Local files are imported as package:campus_radar/<folder>/<name>.
        expect(
          RegExp(
            "^import '(package:campus_radar/[a-z_]+/)?${RegExp.escape(forbidden)}",
            multiLine: true,
          ).hasMatch(source),
          isFalse,
          reason: '$file imports $forbidden',
        );
      }
      for (final dep in graph[file] ?? <String>{}) {
        visit(dep);
      }
    }

    visit('ai_protocol.dart');
    visit('ai_generation.dart');
  });
  test('Legacy job JSON retains unknown fields and missing defaults', () {
    final raw = {
      'status': 'failed',
      'attempts': 3,
      'errorCode': 'grounding',
      'future': {'v': 1},
    };
    final job = AiJob.decode(jsonEncode(raw));
    expect(job.status, AiJobStatus.failed);
    expect(job.toJson(), raw);
    expect(
      job.withStatus(AiJobStatus.pending, fields: {'errorCode': ''}).toJson(),
      {...raw, 'status': 'pending', 'errorCode': ''},
    );
    final missing = AiJob.decode(null);
    expect(missing.attempts, 0);
    expect(missing.toJson(), isEmpty);
    final future = AiJob.fromJson({'status': 'future_state'});
    expect(future.status, AiJobStatus.unknown);
    expect(future.toJson()['status'], 'future_state');
    expect(() => job.withStatus(AiJobStatus.unknown), throwsArgumentError);
  });
  test('Manual decisions and calendar metadata survive typed adapters', () {
    for (final decision in [
      ScheduleDecision.confirmed,
      ScheduleDecision.hold,
      ScheduleDecision.excluded,
    ]) {
      final raw = {
        'status': decision.name,
        'calendarSent': true,
        'calendarId': '12',
        'extra': 'keep',
      };
      final state = ConfirmedSchedule.decode(jsonEncode(raw));
      expect(state.isExplicitDecision, isTrue);
      expect(state.toJson(), raw);
      expect(state.withDecision(ScheduleDecision.review).toJson(), {
        ...raw,
        'status': 'review',
      });
    }
    expect(ConfirmedSchedule.decode(null).toJson(), isEmpty);
    expect(ConfirmedSchedule.decode(null).decision, ScheduleDecision.review);
  });
  test(
    'Typed native methods preserve the wire name, payload and return value',
    () async {
      final calls = <String>[];
      desktopMethodHandler = (method, args) async {
        calls.add(method);
        expect(args, {'probe': 1});
        return {'ok': true};
      };
      try {
        expect(
          await bridge.invokeNativeMap<String, dynamic>(
            NativeMethod.versionInfo,
            {'probe': 1},
          ),
          {'ok': true},
        );
        expect(calls, ['versionInfo']);
      } finally {
        desktopMethodHandler = null;
      }
    },
    skip: !Platform.isWindows,
  );
  test(
    'Shared syllabus loader enforces hosts before transport and rejects empty text',
    () async {
      var calls = 0;
      Future<Map<String, dynamic>?> reader(String url, String course) async {
        calls++;
        return {'text': '수업 월 10:00'};
      }

      for (final url in [
        'http://cnuit.cnu.ac.kr/a',
        'https://evil.test/a',
        'https://user@cnuit.cnu.ac.kr/a',
      ]) {
        await expectLater(
          loadLinkedSyllabus(url, '가상과목', reader: reader),
          throwsA(isA<CampusException>()),
        );
      }
      expect(calls, 0);
      expect(
        await loadLinkedSyllabus(
          'https://cnuit.cnu.ac.kr/a',
          '가상과목',
          reader: reader,
        ),
        '수업 월 10:00',
      );
      await expectLater(
        loadLinkedSyllabus(
          'https://tlsn.cnu.ac.kr/a',
          '가상과목',
          reader: (_, __) async => {'text': ' '},
        ),
        throwsA(isA<CampusException>()),
      );
    },
  );
}

import 'package:campus_radar/navigation/app_router.dart';
import 'package:campus_radar/schedule/calendar_draft_page.dart';
import 'package:campus_radar/notices/notice_analysis_page.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const channel = MethodChannel('campus_radar/native');
  final calls = <MethodCall>[];
  setUp(() {
    calls.clear();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (c) async {
          calls.add(c);
          if (c.method == 'calendarPermission') return true;
          if (c.method == 'calendarWrite') return 42;
          return null;
        });
  });
  tearDown(
    () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, null),
  );
  testWidgets(
    'calendar export waits for confirmation and preserves KST instant',
    (tester) async {
      final due = DateTime.parse('2026-10-20T15:00:00+09:00');
      await tester.pumpWidget(
        MaterialApp(
          onGenerateRoute: buildAppRoute,
          home: CalendarDraftPage(
            itemKey: 'test',
            title: '마감',
            description: '예시',
            start: due,
          ),
        ),
      );
      await tester.pumpAndSettle();
      expect(calls, isEmpty);
      expect(find.textContaining('15:00'), findsOneWidget);
      await tester.ensureVisible(
        find.text(Platform.isWindows ? '일정 파일 저장' : '캘린더에 저장'),
      );
      await tester.tap(find.text(Platform.isWindows ? '일정 파일 저장' : '캘린더에 저장'));
      await tester.pumpAndSettle();
      final write = calls.singleWhere((c) => c.method == 'calendarWrite');
      expect(write.arguments['start'], due.millisecondsSinceEpoch);
      expect(write.arguments['allDay'], false);
      expect(write.arguments['key'], 'test');
    },
  );
  testWidgets('unknown AI date cannot export before user selects a date', (
    tester,
  ) async {
    await tester.pumpWidget(
      const MaterialApp(
        onGenerateRoute: buildAppRoute,
        home: CalendarDraftPage(
          itemKey: 'ai',
          title: '날짜 미확인',
          description: '원문',
          allDay: true,
        ),
      ),
    );
    await tester.pumpAndSettle();
    await tester.ensureVisible(
      find.text(Platform.isWindows ? '일정 파일 저장' : '캘린더에 저장'),
    );
    await tester.tap(find.text(Platform.isWindows ? '일정 파일 저장' : '캘린더에 저장'));
    await tester.pumpAndSettle();
    expect(calls, isEmpty);
    expect(find.text('제목과 날짜를 확인해 주세요.'), findsOneWidget);
  });
  testWidgets(
    'AI edit/calendar path keeps a 23:59 deadline on its original day',
    (tester) async {
      final due = DateTime.parse('2026-10-20T23:59:00+09:00');
      await tester.pumpWidget(
        MaterialApp(
          onGenerateRoute: buildAppRoute,
          home: CalendarDraftPage(
            itemKey: 'example-deadline',
            title: '선택 초안 제출',
            description: '예시 근거',
            start: due,
            deadline: true,
          ),
        ),
      );
      await tester.pumpAndSettle();
      final save = find.text(Platform.isWindows ? '일정 파일 저장' : '캘린더에 저장');
      await tester.ensureVisible(save);
      await tester.tap(save);
      await tester.pumpAndSettle();
      final w = calls.singleWhere((c) => c.method == 'calendarWrite').arguments;
      expect(
        w['start'],
        due.subtract(const Duration(minutes: 10)).millisecondsSinceEpoch,
      );
      expect(w['end'], due.millisecondsSinceEpoch);
    },
  );
  testWidgets('date-only events use UTC midnight calendar all-day semantics', (
    tester,
  ) async {
    await tester.pumpWidget(
      MaterialApp(
        onGenerateRoute: buildAppRoute,
        home: CalendarDraftPage(
          itemKey: 'date',
          title: '시험일',
          description: '원문',
          start: DateTime.utc(2026, 10, 20),
          allDay: true,
        ),
      ),
    );
    await tester.pumpAndSettle();
    await tester.ensureVisible(
      find.text(Platform.isWindows ? '일정 파일 저장' : '캘린더에 저장'),
    );
    await tester.tap(find.text(Platform.isWindows ? '일정 파일 저장' : '캘린더에 저장'));
    await tester.pumpAndSettle();
    final args = calls
        .singleWhere((c) => c.method == 'calendarWrite')
        .arguments;
    expect(args['start'], DateTime.utc(2026, 10, 20).millisecondsSinceEpoch);
    expect(args['end'] - args['start'], 86400000);
    expect(args['allDay'], true);
  });
  testWidgets('opening AI page never sends a request automatically', (
    tester,
  ) async {
    final n = CampusNotice(
      id: 'n',
      title: '예시 공지',
      course: '수업',
      context: {},
      body: '내일 안내합니다.',
      bodyFetched: true,
    );
    await tester.pumpWidget(
      MaterialApp(
        onGenerateRoute: buildAppRoute,
        home: NoticeAnalysisPage(notice: n),
      ),
    );
    await tester.pumpAndSettle();
    expect(calls, isEmpty);
    expect(find.text('일정 찾기·저장 결과 확인'), findsOneWidget);
    expect(find.text('공지 원문'), findsOneWidget);
    await tester.pumpWidget(const SizedBox.shrink());
  });
}

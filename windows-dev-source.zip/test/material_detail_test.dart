import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/tasks/task_detail_page.dart';

void main() {
  testWidgets(
    'archive detail has source text without missing-deadline warnings',
    (tester) async {
      final item = CampusItem(
        key: 'archive',
        type: 'LS',
        title: '수업 자료',
        course: '과목',
        courseId: 'c',
        classNo: '1',
        contentsId: 'x',
        status: 'available',
        body: '강의자료 본문',
        context: {},
      );
      await tester.pumpWidget(MaterialApp(home: DetailPage(item: item)));
      expect(find.text('자료실 상세'), findsOneWidget);
      expect(find.text('마감 미확인'), findsNothing);
      expect(find.text('캘린더에 전송'), findsNothing);
      await tester.scrollUntilVisible(
        find.text('강의자료 본문'),
        200,
        scrollable: find.byType(Scrollable).first,
      );
      expect(find.text('강의자료 본문'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );
}

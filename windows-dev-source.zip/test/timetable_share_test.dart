import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/schedule/timetable_share.dart';
import 'package:campus_radar/schedule/timetable_model.dart';

const id = '0123456789abcdef0123456789abcdef';
const school = ClassSlot(
  courseKey: 'SECRET_COURSE',
  course: '선형대수',
  weekday: 1,
  start: 600,
  end: 675,
  room: '공학관 101',
  source: 'PRIVATE_NOTE',
);
const personal = ClassSlot(
  courseKey: 'personal:secret',
  course: 'PRIVATE_TITLE',
  weekday: 2,
  start: 720,
  end: 780,
  room: 'PRIVATE_ROOM',
  source: 'PRIVATE_NOTE',
);
String wrap(Map<String, dynamic> j) {
  final bytes = zlib.encode(utf8.encode(jsonEncode(j)));
  return 'CRTT1.${base64Url.encode(bytes).replaceAll('=', '')}.${sha256.convert(bytes).toString().substring(0, 16)}';
}

void main() {
  test('roundtrip strips IDs notes rooms and personal defaults', () {
    final code = encodeTimetable(
      [school, personal],
      id: id,
      now: DateTime.utc(2026, 11, 1),
    );
    final got = decodeTimetable(code);
    expect(got.id, id);
    expect(got.slots, hasLength(1));
    expect(got.slots.single.course, '선형대수');
    expect(got.slots.single.room, '');
    expect(got.slots.single.courseKey, startsWith('friend:'));
    final body = utf8.decode(
      zlib.decode(base64Url.decode(base64Url.normalize(code.split('.')[1]))),
    );
    for (final value in [
      'SECRET_COURSE',
      'PRIVATE_NOTE',
      'PRIVATE_TITLE',
      'PRIVATE_ROOM',
    ]) {
      expect(body, isNot(contains(value)));
    }
  });
  test('optional busy slots never disclose personal titles or rooms', () {
    final got = decodeTimetable(
      encodeTimetable([school, personal], id: id, rooms: true, personal: true),
    );
    expect(got.slots.first.room, '공학관 101');
    expect(got.slots.last.course, '일정 있음');
    expect(got.slots.last.room, '');
  });
  test('broken checksum unsupported version and invalid ranges fail', () {
    final code = encodeTimetable([school], id: id);
    expect(
      () => decodeTimetable('${code.substring(0, code.length - 1)}x'),
      throwsFormatException,
    );
    final j = {
      'v': 2,
      'id': id,
      'at': '2026-11-01T00:00:00Z',
      'timezone': 'Asia/Seoul',
      'slots': [],
    };
    expect(() => decodeTimetable(wrap(j)), throwsFormatException);
    j['v'] = 1;
    j['slots'] = [
      {'title': 'x', 'weekday': 1, 'start': 600, 'end': 599},
    ];
    expect(() => decodeTimetable(wrap(j)), throwsFormatException);
    j['slots'] = [
      {'title': 'x', 'weekday': 8, 'start': 600, 'end': 700},
    ];
    expect(() => decodeTimetable(wrap(j)), throwsFormatException);
  });
  test('oversized input and compressed bomb are rejected during inflate', () {
    expect(() => decodeTimetable('x' * 32769), throwsFormatException);
    final packed = zlib.encode(List.filled(5000000, 65));
    final bomb =
        'CRTT1.${base64Url.encode(packed).replaceAll('=', '')}.${sha256.convert(packed).toString().substring(0, 16)}';
    expect(() => decodeTimetable(bomb), throwsFormatException);
  });
  test('max slots and control characters rejected', () {
    expect(
      () => encodeTimetable(List.filled(201, school), id: id),
      throwsFormatException,
    );
    expect(
      () => encodeTimetable([
        const ClassSlot(
          courseKey: 'x',
          course: 'x\ny',
          weekday: 1,
          start: 1,
          end: 2,
        ),
      ], id: id),
      throwsFormatException,
    );
  });
}

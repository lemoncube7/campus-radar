import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/main.dart';
import 'package:campus_radar/campus/collection_control.dart';
import 'package:campus_radar/session/session_lifetime_probe.dart';
import 'package:campus_radar/campus/services.dart';
import 'package:workmanager/workmanager.dart';

class TestCollectionScheduler extends WorkmanagerPlatform {
  @override
  Future<void> cancelByUniqueName(String uniqueName) async {}
  @override
  Future<void> registerPeriodicTask(
    String uniqueName,
    String taskName, {
    Duration? frequency,
    Duration? flexInterval,
    Map<String, dynamic>? inputData,
    Duration? initialDelay,
    Constraints? constraints,
    ExistingPeriodicWorkPolicy? existingWorkPolicy,
    BackoffPolicy? backoffPolicy,
    Duration? backoffPolicyDelay,
    String? tag,
  }) async {}
}

class CountHttpClients extends HttpOverrides {
  int created = 0;
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    created++;
    throw StateError('No network is expected in this test');
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  setUp(() async {
    WorkmanagerPlatform.instance = TestCollectionScheduler();
    SharedPreferences.setMockInitialValues({});
    temp = await Directory.systemTemp.createTemp('collection-control-');
    await databaseFactory.setDatabasesPath(temp.path);
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          (c) async => c.method == 'read' ? 'synthetic' : null,
        );
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('campus_radar/native'),
          (c) async => null,
        );
  });
  tearDown(() async {
    HttpOverrides.global = null;
    for (final name in [
      'plugins.it_nomads.com/flutter_secure_storage',
      'campus_radar/native',
    ]) {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(MethodChannel(name), null);
    }
    await temp.delete(recursive: true);
  });

  test(
    'Inactive test does not create a school client even with ordinary collection enabled',
    () async {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('schoolLifetimeProbeEnabled', false);
      await saveAutomaticSchoolConnection(true);
      final counter = CountHttpClients();
      HttpOverrides.global = counter;
      await runSessionLifetimeProbe();
      expect(counter.created, 0);
    },
  );
  test(
    'Exclusive test masks automatic collection and restores both original on and off preferences',
    () async {
      for (final original in [true, false]) {
        await saveAutomaticSchoolConnection(original);
        await setExclusiveSessionLifetimeTest(true);
        expect(await automaticSchoolConnectionEnabled(), false);
        expect(await automaticSchoolConnectionPreference(), original);
        await setExclusiveSessionLifetimeTest(false);
        expect(await automaticSchoolConnectionEnabled(), original);
      }
    },
  );
  test(
    'Automatic connection preference defaults on and persists an explicit pause',
    () async {
      expect(await automaticSchoolConnectionEnabled(), true);
      await saveAutomaticSchoolConnection(false);
      expect(await automaticSchoolConnectionEnabled(), false);
      await saveAutomaticSchoolConnection(true);
      expect(await automaticSchoolConnectionEnabled(), true);
    },
  );
  testWidgets(
    'Opening the app intentionally connects even during exclusive session exploration',
    (t) async {
      await saveAutomaticSchoolConnection(true);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('schoolLifetimeProbeEnabled', true);
      final network = CountHttpClients();
      HttpOverrides.global = network;
      await t.pumpWidget(const RadarApp(home: Dashboard()));
      for (var i = 0; i < 8; i++) {
        await t.runAsync(
          () => Future<void>.delayed(const Duration(milliseconds: 80)),
        );
        await t.pump();
      }
      await t.pumpAndSettle();
      t.binding.handleAppLifecycleStateChanged(AppLifecycleState.paused);
      t.binding.handleAppLifecycleStateChanged(AppLifecycleState.resumed);
      for (var i = 0; i < 4; i++) {
        await t.runAsync(
          () => Future<void>.delayed(const Duration(milliseconds: 80)),
        );
        await t.pump();
      }
      expect(network.created, greaterThan(0));
      expect(t.takeException(), isNull);
      await t.pumpWidget(const SizedBox.shrink());
      await t.pumpAndSettle();
      await t.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 100)),
      );
    },
  );
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/export/drive_connection_page.dart';

void main() {
  const channel = MethodChannel('campus_radar/native');
  TestWidgetsFlutterBinding.ensureInitialized();
  tearDown(
    () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, null),
  );
  testWidgets(
    'separate account statuses are visible and disabled account cannot request upload',
    (tester) async {
      final calls = <String>[];
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(channel, (call) async {
            calls.add(call.method);
            if (call.method == 'driveAccounts') {
              return [
                {
                  'id': 'one',
                  'email': 'first@example.invalid',
                  'enabled': false,
                },
                {
                  'id': 'two',
                  'email': 'second@example.invalid',
                  'enabled': true,
                  'error': 'Google 계정에 다시 연결해 주세요.',
                },
              ];
            }
            return null;
          });
      await tester.pumpWidget(const MaterialApp(home: DriveConnectionPage()));
      await tester.pumpAndSettle();
      expect(find.text('first@example.invalid'), findsOneWidget);
      expect(find.text('second@example.invalid'), findsOneWidget);
      expect(find.text('자동 전송 꺼짐'), findsOneWidget);
      expect(find.text('자동 전송 켜짐'), findsOneWidget);
      final upload = find.widgetWithText(TextButton, '지금 전송 요청');
      expect(tester.widget<TextButton>(upload.at(0)).onPressed, isNull);
      expect(tester.widget<TextButton>(upload.at(1)).onPressed, isNotNull);
      expect(calls, everyElement('driveAccounts'));
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets('native error gives a recovery message without crashing', (
    tester,
  ) async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          channel,
          (call) async => throw PlatformException(code: 'unavailable'),
        );
    await tester.pumpWidget(const MaterialApp(home: DriveConnectionPage()));
    await tester.pumpAndSettle();
    expect(find.text('Drive 연결 상태를 읽지 못했어요. 다시 확인해 주세요.'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
  testWidgets('authorization failure survives refreshing the account list', (
    tester,
  ) async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (call) async {
          if (call.method == 'driveConnect') {
            throw PlatformException(
              code: 'cancelled',
              message: 'Google 연결을 취소했어요.',
            );
          }
          return [];
        });
    await tester.pumpWidget(const MaterialApp(home: DriveConnectionPage()));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Google 계정 연결'));
    await tester.pumpAndSettle();
    expect(find.text('Google 연결을 취소했어요.'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}

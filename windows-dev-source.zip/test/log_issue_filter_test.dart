import 'package:campus_radar/settings/history_page.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('normal summaries with zero failures are not issues', () {
    expect(logLooksLikeIssue('이미지·첨부파일 수집 새 저장 0개 · 실패 0개 · 공지 본문 확인 12개'), isFalse);
    expect(logLooksLikeIssue('통신 재시도 0회 · 오류 0건'), isFalse);
  });
  test('real failures still match', () {
    expect(logLooksLikeIssue('새 저장 2개 · 실패 1개'), isTrue);
    expect(logLooksLikeIssue('Drive 내보내기 준비 실패'), isTrue);
    expect(logLooksLikeIssue('권한 거절'), isTrue);
  });
}

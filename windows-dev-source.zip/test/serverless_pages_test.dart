import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/timetable_share.dart';
import 'package:campus_radar/schedule/timetable_share_page.dart';
import 'package:campus_radar/export/academic_export_page.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory dir;
  setUp(() async {
    dir = await Directory.systemTemp.createTemp('serverless-ui-');
    await databaseFactory.setDatabasesPath(dir.path);
    SharedPreferences.setMockInitialValues({});
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          (c) async => c.method == 'read' ? 'fixture' : null,
        );
    final s = await Store.open();
    await s.setMeta('lastSuccess', '2026-11-01T00:00:00Z');
    await s.setMeta('courses', '[]');
    await s.setMeta(
      'timetableEntries',
      jsonEncode([
        const ClassSlot(
          courseKey: 'mine:1',
          course: '내 수업',
          weekday: 1,
          start: 600,
          end: 660,
        ).toJson(),
      ]),
    );
    await s.db.close();
  });
  tearDown(() async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          null,
        );
    await dir.delete(recursive: true);
  });
  Future<void> settle(WidgetTester t) async {
    for (var i = 0; i < 5; i++) {
      await t.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 60)),
      );
      await t.pump();
    }
    await t.pumpAndSettle();
  }

  testWidgets('friend import is previewed and stays separate from own slots', (
    t,
  ) async {
    await t.pumpWidget(const MaterialApp(home: TimetableSharePage()));
    await settle(t);
    final code = encodeTimetable([
      const ClassSlot(
        courseKey: 'foreign:1',
        course: '친구 수업',
        weekday: 2,
        start: 700,
        end: 760,
      ),
    ], id: 'abcdef0123456789abcdef0123456789');
    await t.enterText(find.byType(TextField).first, code);
    await t.ensureVisible(find.text('시간표 미리보기'));
    await t.tap(find.text('시간표 미리보기'));
    await settle(t);
    expect(find.textContaining('친구 수업'), findsWidgets);
    final nickname = find.widgetWithText(TextField, '이 기기에서 부를 친구 이름');
    await t.scrollUntilVisible(
      nickname,
      250,
      scrollable: find.byType(Scrollable).first,
    );
    await t.enterText(nickname, '친구');
    await t.scrollUntilVisible(
      find.text('친구 시간표로 저장'),
      200,
      scrollable: find.byType(Scrollable).first,
    );
    await t.tap(find.text('친구 시간표로 저장'));
    await settle(t);
    await t.runAsync(() async {
      final s = await Store.open();
      try {
        expect(
          decodeSlots(await s.meta('timetableEntries')).single.course,
          '내 수업',
        );
        expect(
          jsonDecode((await s.meta('friendTimetables'))!).single['name'],
          '친구',
        );
      } finally {
        await s.db.close();
      }
    });
    await t.scrollUntilVisible(
      find.text('친구'),
      250,
      scrollable: find.byType(Scrollable).first,
    );
    await t.tap(find.text('친구'));
    await settle(t);
    await t.tap(find.text('내 시간표와 겹쳐 보기'));
    await settle(t);
    expect(t.takeException(), isNull);
  });
  testWidgets('export requires consent and offers document preview', (t) async {
    await t.pumpWidget(const MaterialApp(home: AcademicExportPage()));
    await settle(t);
    final button = find.text('자료 만들고 미리보기');
    await t.scrollUntilVisible(
      button,
      250,
      scrollable: find.byType(Scrollable).first,
    );
    expect(
      t
          .widget<FilledButton>(
            find
                .ancestor(
                  of: button,
                  matching: find.byWidgetPredicate((w) => w is FilledButton),
                )
                .first,
          )
          .onPressed,
      isNull,
    );
    await t.scrollUntilVisible(
      find.byType(CheckboxListTile),
      -200,
      scrollable: find.byType(Scrollable).first,
    );
    await t.tap(find.byType(CheckboxListTile));
    await t.pumpAndSettle();
    await t.scrollUntilVisible(
      button,
      250,
      scrollable: find.byType(Scrollable).first,
    );
    await t.tap(button);
    await settle(t);
    await t.scrollUntilVisible(
      find.text('시간표.txt'),
      250,
      scrollable: find.byType(Scrollable).first,
    );
    await t.ensureVisible(find.text('시간표.txt'));
    await t.pumpAndSettle();
    await t.tap(find.text('시간표.txt'));
    await settle(t);
    expect(find.textContaining('내 수업'), findsOneWidget);
    expect(t.takeException(), isNull);
  });
}

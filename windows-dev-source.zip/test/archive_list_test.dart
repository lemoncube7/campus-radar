import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/campus/learning_resources.dart';

class ArchiveClient extends CampusClient {
  final List<dynamic> pages;
  final offsets = <int>[];
  ArchiveClient(this.pages);
  @override
  Future<dynamic> api(
    String route,
    Map<String, dynamic>? payload, {
    String host = CampusClient.learning,
  }) async {
    expect(route, '/archive/list');
    offsets.add(payload!['offset'] as int);
    return pages.removeAt(0);
  }
}

void main() {
  test(
    'archive board paginates beyond weekly curriculum and deduplicates IDs',
    () async {
      final c = ArchiveClient([
        {
          'tot_cnt': 101,
          'list': [
            for (var n = 0; n < 100; n++) {'boarditem_no': n},
          ],
        },
        {
          'tot_cnt': 101,
          'list': [
            {'boarditem_no': 100},
          ],
        },
      ]);
      try {
        expect(
          (await c.fetchArchiveRows({
            'course_id': 'c',
            'class_no': '1',
          })).length,
          101,
        );
        expect(c.offsets, [0, 100]);
      } finally {
        c.close();
      }
    },
  );
  test(
    'partial archive response is failure instead of silently replacing full list',
    () async {
      final c = ArchiveClient([
        {
          'tot_cnt': 5,
          'list': [
            {'boarditem_no': 1},
          ],
        },
      ]);
      try {
        await expectLater(
          c.fetchArchiveRows({}),
          throwsA(isA<CampusException>()),
        );
      } finally {
        c.close();
      }
    },
  );
  test(
    'hidden deleted and not-yet-open archive rows cannot become visible',
    () {
      for (final field in ['hide_yn', 'delete_yn', 'complete_delete_yn']) {
        final i = parseAdditionalLearning(
          {'module_type': 'LS', 'boarditem_no': 1, field: 'Y'},
          {'course_id': 'c', 'class_no': '1'},
          {},
        );
        expect(i!.published, false);
      }
      final i = parseAdditionalLearning(
        {'module_type': 'LS', 'boarditem_no': 1, 'status': 'B'},
        {'course_id': 'c', 'class_no': '1'},
        {},
      );
      expect(i!.published, false);
    },
  );
}

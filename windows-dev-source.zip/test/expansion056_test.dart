import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/session/session_probe_policy.dart';
import 'package:campus_radar/campus/collection_control.dart';
import 'package:campus_radar/session/session_lifetime_probe.dart';
import 'package:campus_radar/session/session_lifetime.dart';
import 'package:campus_radar/session/session_exploration_page.dart';
import 'package:campus_radar/campus/connection_evidence.dart';
import 'package:campus_radar/schedule/timetable_grid.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/core/app_storage.dart';

class NoRequests extends HttpOverrides {
  int requests = 0;
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    requests++;
    throw StateError('no network during settings');
  }
}

ClassSlot slot(String key, int day) => ClassSlot(
  courseKey: key,
  course: '컴퓨터프로그래밍2',
  weekday: day,
  start: 540,
  end: 630,
  room: '공415',
);
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    temp = await Directory.systemTemp.createTemp('expand056-');
    await databaseFactory.setDatabasesPath(temp.path);
    final s = await Store.open();
    await s.db.close();
  });
  tearDown(() async {
    HttpOverrides.global = null;
    courseAliases = {};
    await temp.delete(recursive: true);
  });
  test('weekend quiet windows have exact Korean-time boundaries', () {
    const p = SessionProbePolicy(enabled: true, scheduled: true);
    expect(p.activeAt(DateTime.parse('2026-10-30T14:59:59Z')), false);
    expect(p.activeAt(DateTime.parse('2026-10-30T15:00:00Z')), true);
    expect(p.activeAt(DateTime.parse('2026-11-01T14:59:59Z')), true);
    expect(p.activeAt(DateTime.parse('2026-11-01T15:00:00Z')), false);
    expect(const SessionProbePolicy().activeAt(DateTime.now()), false);
  });
  test('overnight quiet window belongs to its start weekday', () {
    const p = SessionProbePolicy(
      enabled: true,
      scheduled: true,
      days: [5],
      startHour: 22,
      endHour: 8,
    );
    expect(p.activeAt(DateTime.parse('2026-10-30T12:59:00Z')), false);
    expect(p.activeAt(DateTime.parse('2026-10-30T13:00:00Z')), true);
    expect(p.activeAt(DateTime.parse('2026-10-30T22:59:00Z')), true);
    expect(p.activeAt(DateTime.parse('2026-10-30T23:00:00Z')), false);
  });
  test(
    'scheduled exploration masks collection only inside its quiet window',
    () async {
      final day = DateTime.now().toUtc().add(const Duration(hours: 9)).weekday;
      SharedPreferences.setMockInitialValues({
        'schoolLifetimeProbeEnabled': true,
        'sessionProbeMode': 'scheduled',
        'sessionProbeDays': ['$day'],
        'automaticSchoolConnection': true,
      });
      expect(await automaticSchoolConnectionEnabled(), false);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList('sessionProbeDays', ['${day % 7 + 1}']);
      expect(await automaticSchoolConnectionEnabled(), true);
      await prefs.setBool('automaticSchoolConnection', false);
      expect(await automaticSchoolConnectionEnabled(), false);
    },
  );
  test(
    'new exploration settings survive startup and worker migration',
    () async {
      SharedPreferences.setMockInitialValues({
        'schoolLifetimeProbeEnabled': true,
      });
      await retireSessionExploration();
      expect(await sessionLifetimeProbeEnabled(), false);
      await setSessionLifetimeProbe(true);
      await retireSessionExploration();
      await retireSessionExploration();
      expect(await sessionLifetimeProbeEnabled(), true);
      await setSessionLifetimeProbe(false);
      expect(await automaticSchoolConnectionEnabled(), true);
    },
  );
  test('online marker never treats old evidence or future clocks as live', () {
    final now = DateTime.utc(2026, 10, 29, 3);
    final state = SessionLifetime()
      ..session = 'synthetic'
      ..lastValidatedAt = now.millisecondsSinceEpoch;
    expect(connectionEvidence(state, now), ConnectionEvidence.recent);
    expect(
      connectionEvidence(state, now.add(const Duration(minutes: 16))),
      ConnectionEvidence.stale,
    );
    expect(
      connectionEvidence(state, now.subtract(const Duration(seconds: 1))),
      ConnectionEvidence.unknown,
    );
    state.lost = true;
    expect(connectionEvidence(state, now), ConnectionEvidence.lost);
    expect(connectionEvidence(null, now), ConnectionEvidence.unknown);
  });
  test('home widget descriptors support 3x3 and smaller resize bounds', () {
    for (final name in ['radar_widget_info.xml', 'timetable_widget_info.xml']) {
      final xml = File('android/app/src/main/res/xml/$name').readAsStringSync();
      expect(xml, contains('targetCellWidth="3"'));
      expect(xml, contains('targetCellHeight="3"'));
      expect(xml, contains('minResizeWidth="100dp"'));
      expect(xml, contains('resizeMode="horizontal|vertical"'));
    }
  });
  Future<void> ready(WidgetTester t, Widget widget) async {
    await t.pumpWidget(widget);
    await t.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 350)),
    );
    await t.pumpAndSettle();
  }

  testWidgets(
    'whole week fits 320px without a horizontal scroll, details stay accessible',
    (t) async {
      t.view.physicalSize = const Size(320, 900);
      t.view.devicePixelRatio = 1;
      addTearDown(t.view.resetPhysicalSize);
      addTearDown(t.view.resetDevicePixelRatio);
      courseAliases = {'컴퓨터프로그래밍2': '컴프2'};
      await ready(
        t,
        MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(
              child: TimetableGrid(
                entries: [slot('a', 1), slot('b', 5), slot('c', 7)],
              ),
            ),
          ),
        ),
      );
      expect(
        find.byWidgetPredicate(
          (w) =>
              w is SingleChildScrollView &&
              w.scrollDirection == Axis.horizontal,
        ),
        findsNothing,
      );
      expect(t.getRect(find.text('일')).right, lessThanOrEqualTo(320));
      await t.tap(find.text('컴프2').first);
      await t.pumpAndSettle();
      expect(find.textContaining('09:00'), findsWidgets);
      expect(t.takeException(), isNull);
    },
  );
  testWidgets(
    'session settings open without any school request and preserve normal setting',
    (t) async {
      final http = NoRequests();
      HttpOverrides.global = http;
      await ready(t, const MaterialApp(home: SessionExplorationPage()));
      expect(find.text('탐색 꺼짐'), findsOneWidget);
      await t.tap(find.text('요일·시간 예약'));
      await t.pumpAndSettle();
      expect(find.text('토'), findsOneWidget);
      expect(find.text('일'), findsOneWidget);
      expect(await automaticSchoolConnectionEnabled(), true);
      expect(http.requests, 0);
      await t.pumpWidget(const SizedBox.shrink());
    },
  );
  testWidgets(
    'saved quiet-window controls show persisted values after loading',
    (t) async {
      SharedPreferences.setMockInitialValues({
        'sessionProbeMode': 'scheduled',
        'sessionProbeInitialMinutes': 240,
        'sessionProbeStartHour': 22,
        'sessionProbeEndHour': 8,
        'sessionProbeDays': ['5'],
      });
      await ready(t, const MaterialApp(home: SessionExplorationPage()));
      expect(find.text('4시간'), findsWidgets);
      expect(find.text('22:00'), findsWidgets);
      expect(find.text('8:00'), findsWidgets);
      await t.pumpWidget(const SizedBox.shrink());
    },
  );
  testWidgets(
    'stop always restores collection even if the draft has no selected days',
    (t) async {
      SharedPreferences.setMockInitialValues({
        'schoolLifetimeProbeEnabled': true,
        'sessionProbePolicyVersion': 2,
        'sessionProbeMode': 'scheduled',
        'sessionProbeDays': ['6', '7'],
      });
      await ready(t, const MaterialApp(home: SessionExplorationPage()));
      await t.tap(find.text('토'));
      await t.tap(find.text('일'));
      await t.pumpAndSettle();
      await t.scrollUntilVisible(find.text('탐색 종료·평소 수집 복원'), 150);
      await t.pumpAndSettle();
      await t.ensureVisible(find.text('탐색 종료·평소 수집 복원'));
      await t.pumpAndSettle();
      await t.tap(find.text('탐색 종료·평소 수집 복원'));
      await t.pump();
      await t.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 350)),
      );
      await t.pumpAndSettle();
      expect(await sessionLifetimeProbeEnabled(), false);
      expect(await automaticSchoolConnectionEnabled(), true);
      await t.pumpWidget(const SizedBox.shrink());
    },
  );
  testWidgets(
    'capture whole-week overview with course aliases',
    (t) async {
      t.view.physicalSize = const Size(390, 820);
      t.view.devicePixelRatio = 1;
      addTearDown(t.view.resetPhysicalSize);
      addTearDown(t.view.resetDevicePixelRatio);
      await t.runAsync(() async {
        for (final e in {
          'Malgun': 'C:/Windows/Fonts/malgun.ttf',
          'MaterialIcons':
              '../../work/tools/flutter/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf',
        }.entries) {
          final f = FontLoader(e.key);
          f.addFont(
            Future.value(
              ByteData.sublistView(await File(e.value).readAsBytes()),
            ),
          );
          await f.load();
        }
      });
      courseAliases = {'컴퓨터프로그래밍2': '컴프2'};
      final key = GlobalKey();
      await ready(
        t,
        MaterialApp(
          theme: ThemeData(
            fontFamily: 'Malgun',
            brightness: Brightness.dark,
            colorSchemeSeed: Colors.teal,
          ),
          home: RepaintBoundary(
            key: key,
            child: Scaffold(
              appBar: AppBar(title: const Text('이번 주 시간표')),
              body: SingleChildScrollView(
                child: TimetableGrid(
                  entries: [slot('a', 1), slot('b', 3), slot('c', 5)],
                ),
              ),
            ),
          ),
        ),
      );
      expect(t.takeException(), isNull);
      // Keep GPU readback isolated from the parallel regression suite.
      if (!const bool.fromEnvironment('CAPTURE_DESIGN')) return;
      await t.runAsync(() async {
        final img =
            await (key.currentContext!.findRenderObject()
                    as RenderRepaintBoundary)
                .toImage();
        final bytes = await img.toByteData(format: ui.ImageByteFormat.png);
        final dir = Directory('../../outputs/tests/expansion056')
          ..createSync(recursive: true);
        File(
          '${dir.path}/weekly-overview.png',
        ).writeAsBytesSync(bytes!.buffer.asUint8List());
        img.dispose();
      });
    },
    skip: !const bool.fromEnvironment('CAPTURE_DESIGN'),
  );
}

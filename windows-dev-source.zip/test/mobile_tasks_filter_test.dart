import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/tasks/mobile_tasks_view.dart';

CampusItem item(
  String key,
  String course,
  Duration due, {
  String type = 'LR',
}) => CampusItem(
  key: key,
  type: type,
  title: '과제 $key',
  course: course,
  courseId: course,
  classNo: '1',
  contentsId: key,
  status: 'pending',
  due: DateTime.now().toUtc().add(due),
  context: const {},
);

void main() {
  testWidgets('filter sheet narrows by course and deadline, then resets', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(400, 900);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: MobileTasksView(
            items: [
              item('a', '알고리즘', const Duration(hours: -2)),
              item('b', '알고리즘', const Duration(days: 3)),
              item('c', '물리학', const Duration(hours: -1)),
            ],
            excludedKeys: const {},
            visibilityBusy: const {},
            isBusy: false,
            onRefresh: () {},
            onTaskTap: (_) {},
            onTaskVisibilityToggle: (_) {},
          ),
        ),
      ),
    );
    expect(find.text('과제 a'), findsOneWidget);
    expect(find.text('과제 c'), findsOneWidget);

    await tester.tap(find.text('필터'));
    await tester.pumpAndSettle();
    await tester.tap(find.widgetWithText(ChoiceChip, '알고리즘'));
    await tester.tap(find.widgetWithText(ChoiceChip, '마감 지남'));
    await tester.tap(find.text('적용'));
    await tester.pumpAndSettle();

    expect(find.text('과제 a'), findsOneWidget);
    expect(find.text('과제 b'), findsNothing);
    expect(find.text('과제 c'), findsNothing);
    expect(find.text('필터 •'), findsOneWidget);

    await tester.tap(find.text('필터 •'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('초기화'));
    await tester.tap(find.text('적용'));
    await tester.pumpAndSettle();
    expect(find.text('과제 c'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('전체 counts open to-dos only and lists past deadlines last', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(400, 1600);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: MobileTasksView(
            items: [
              item('old', '알고리즘', const Duration(days: -40)),
              item('soon', '알고리즘', const Duration(days: 2)),
              item('file', '알고리즘', const Duration(days: 1), type: 'LS'),
            ],
            excludedKeys: const {},
            visibilityBusy: const {},
            isBusy: false,
            onRefresh: () {},
            onTaskTap: (_) {},
            onTaskVisibilityToggle: (_) {},
          ),
        ),
      ),
    );
    expect(find.text('과제 file'), findsNothing); // material, not a to-do
    final soon = tester.getTopLeft(find.text('과제 soon')).dy;
    final old = tester.getTopLeft(find.text('과제 old')).dy;
    expect(soon, lessThan(old));
  });
}

import 'package:campus_radar/tasks/task_evaluation.dart';
import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/export/cloud_snapshot.dart';
import 'package:campus_radar/export/cloud_sync.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory dir;
  late Store store;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    dir = await Directory.systemTemp.createTemp('radar-cloud-');
    await databaseFactory.setDatabasesPath(dir.path);
    store = await Store.open();
  });
  tearDown(() async {
    await store.db.close();
    await dir.delete(recursive: true);
  });
  test('default off makes no credential or HTTP access', () async {
    expect(await sendCloud(store), false);
  });
  test('snapshot requires a successful saved collection', () async {
    await expectLater(buildCloudSnapshot(store), throwsStateError);
  });
  test(
    'allowlist removes source account IDs context html media and local secrets',
    () async {
      await store.setMeta('lastSuccess', '2026-10-30T00:00:00Z');
      await store.setMeta('pw', 'DO_NOT_UPLOAD');
      await store.setMeta('courses', '[{"student_id":"DO_NOT_UPLOAD"}]');
      final i = CampusItem(
        key: 'PRIVATE_TASK_ID',
        evaluation: const TaskEvaluation(
          score: 'PRIVATE_GRADE',
          feedback: 'PRIVATE_FEEDBACK',
        ),
        type: 'LR',
        title: '과제',
        course: '컴프2',
        courseId: 'PRIVATE_COURSE',
        classNo: '1',
        contentsId: 'PRIVATE_CONTENT',
        status: 'unknown',
        body: 'PRIVATE_BODY',
        bodyHtml: '<img src="PRIVATE_URL">',
        context: {'cookie': 'DO_NOT_UPLOAD'},
      );
      await store.db.insert('items', {
        'id': i.key,
        'payload': jsonEncode(i.toJson()),
      });
      await store.saveNotice(
        CampusNotice(
          id: 'PRIVATE_NOTICE',
          title: '11월 2일 휴강',
          course: '논비사',
          context: {'cookie': 'DO_NOT_UPLOAD'},
          body: '수업 없음',
          bodyFetched: true,
        ),
      );
      final payload = await buildCloudSnapshot(
        store,
        now: DateTime.utc(2026, 10, 30, 1),
      );
      final text = jsonEncode(payload);
      for (final secret in [
        'DO_NOT_UPLOAD',
        'PRIVATE_TASK_ID',
        'PRIVATE_GRADE',
        'PRIVATE_FEEDBACK',
        'PRIVATE_COURSE',
        'PRIVATE_CONTENT',
        'PRIVATE_BODY',
        'PRIVATE_URL',
        'PRIVATE_NOTICE',
      ]) {
        expect(text, isNot(contains(secret)));
      }
      expect((payload['items'] as List).single['status'], 'unknown');
      expect((payload['notices'] as List).single['title'], '11월 2일 휴강');
      expect(
        (payload['items'] as List).single['id'],
        cloudId('PRIVATE_TASK_ID'),
      );
    },
  );
  test(
    'materials require renewed consent and never export raw bodies in metadata',
    () async {
      await store.setMeta('lastSuccess', '2026-10-30T00:00:00Z');
      final item = CampusItem(
        key: 'PRIVATE_ARCHIVE_ID',
        courseId: 'PRIVATE_COURSE_ID',
        classNo: '1',
        contentsId: 'PRIVATE_CONTENTS_ID',
        status: 'available',
        type: 'LS',
        title: '자료실',
        course: '컴프2',
        body: 'PRIVATE_DOCUMENT_BODY',
        context: {'cookie': 'PRIVATE_COOKIE'},
      );
      await store.db.insert('items', {
        'id': item.key,
        'payload': jsonEncode(item.toJson()),
      });
      final before = await buildCloudSnapshot(store);
      expect(before['schemaVersion'], 1);
      expect(before.containsKey('materials'), false);
      await store.setMeta('cloudMaterialsConsent', 'yes');
      final after = await buildCloudSnapshot(store);
      expect(after['schemaVersion'], 2);
      final material = (after['materials'] as List).single;
      expect(material['sourceType'], 'LS');
      expect(material['name'], '본문.txt');
      for (final secret in [
        'PRIVATE_DOCUMENT_BODY',
        'PRIVATE_COOKIE',
        'PRIVATE_ARCHIVE_ID',
      ]) {
        expect(jsonEncode(after), isNot(contains(secret)));
      }
    },
  );
  test(
    'only trusted origin accepted; credentials cannot redirect to attacker',
    () {
      final valid = {
        'version': 1,
        'server': radarCloudOrigin,
        'deviceId': '00000000-0000-0000-0000-000000000001',
        'deviceToken': List.filled(64, 'a').join(),
        'gateToken': List.filled(24, 'b').join(),
        'expiresAt': '2026-11-30T00:00:00Z',
      };
      expect(
        CloudConnection.parse(jsonEncode(valid)).deviceId,
        valid['deviceId'],
      );
      expect(
        () => CloudConnection.parse(
          jsonEncode({...valid, 'server': 'https://attacker.invalid'}),
        ),
        throwsFormatException,
      );
      expect(
        () => CloudConnection.parse(
          jsonEncode({...valid, 'gateToken': 'bad\r\nheader'}),
        ),
        throwsFormatException,
      );
    },
  );
}

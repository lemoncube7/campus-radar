import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/schedule/timetable_page.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory dir;
  setUp(() async {
    dir = await Directory.systemTemp.createTemp('timetable-save-ui-');
    await databaseFactory.setDatabasesPath(dir.path);
    SharedPreferences.setMockInitialValues({});
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(const MethodChannel('campus_radar/native'), (
          c,
        ) async {
          if (c.method == 'timetableSettings') {
            return <String, dynamic>{
              'exactAllowed': true,
              'enabled': true,
              'midnight': false,
              'lead': 30,
              'countdownAfter': 0,
              'until': '2026-12-31',
            };
          }
          if (c.method == 'setTimetableSettings') {
            throw PlatformException(code: 'fixture_alarm_failure');
          }
          return null;
        });
    final s = await Store.open();
    await s.setMeta('courses', '[]');
    await s.setMeta('timetableEntries', '[]');
    await s.db.close();
  });
  tearDown(() async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('campus_radar/native'),
          null,
        );
    await dir.delete(recursive: true);
  });
  Future<void> settle(WidgetTester t) async {
    for (var i = 0; i < 8; i++) {
      await t.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 60)),
      );
      await t.pump();
    }
    await t.pumpAndSettle();
  }

  testWidgets(
    'personal schedule remains visible and saved when native alarm update fails',
    (t) async {
      t.view.physicalSize = const Size(1200, 2400);
      t.view.devicePixelRatio = 1;
      addTearDown(t.view.resetPhysicalSize);
      addTearDown(t.view.resetDevicePixelRatio);
      await t.pumpWidget(const MaterialApp(home: TimetablePage()));
      await settle(t);
      await t.tap(find.text('개인 반복 일정 추가'));
      await t.pumpAndSettle();
      await t.enterText(find.byType(TextField).first, 'DEVICE_SAVE_FIXTURE');
      await t.ensureVisible(find.text('저장'));
      await t.tap(find.text('저장'));
      await settle(t);
      expect(find.textContaining('일정은 저장했어요.'), findsOneWidget);
      expect(find.textContaining('알림 설정 적용'), findsOneWidget);
      expect(find.text('개인 일정 저장을 완료하지 못했어요.'), findsNothing);
      expect(find.textContaining('DEVICE_SAVE_FIXTURE'), findsWidgets);
      await t.runAsync(() async {
        final s = await Store.open();
        try {
          final rows =
              jsonDecode(await s.meta('timetableEntries') ?? '[]') as List;
          expect(rows.single['course'], 'DEVICE_SAVE_FIXTURE');
          final logs = await s.db.query(
            'logs',
            where: 'title=?',
            whereArgs: ['시간표 저장 후 반영 실패'],
          );
          expect(logs, isNotEmpty);
          expect(
            logs.last['detail'].toString(),
            contains('fixture_alarm_failure'),
          );
        } finally {
          await s.db.close();
        }
      });
      await t.pumpWidget(const SizedBox.shrink());
    },
  );
}

import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/export/drive_sync.dart';

void main() {
  test('lease describes owner role and remaining bounded wait', () {
    final now = DateTime.utc(2026, 11, 3);
    expect(
      driveLeaseMessage({
        'label': '자동 전송 자료 준비',
        'until': now.millisecondsSinceEpoch + 75000,
      }, now: now),
      contains('자동 전송 자료 준비'),
    );
    expect(
      driveLeaseMessage({
        'until': now.millisecondsSinceEpoch + 75000,
      }, now: now),
      contains('75초'),
    );
    expect(
      driveLeaseMessage({'until': now.millisecondsSinceEpoch - 1}, now: now),
      contains('0초'),
    );
  });
}

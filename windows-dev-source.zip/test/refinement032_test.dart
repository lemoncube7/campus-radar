import 'package:campus_radar/navigation/app_router.dart';
import 'package:campus_radar/courses/course_page.dart';
import 'package:campus_radar/ai/ai_chat_page.dart';
import 'package:campus_radar/settings/lock_screen_settings_page.dart';
import 'package:campus_radar/schedule/calendar_draft_page.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/courses/course_aliases.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'dart:convert';
import 'dart:io';
import 'package:campus_radar/ai/ai_automation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_markdown_plus/flutter_markdown_plus.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  late Directory dir;
  late Store store;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    courseAliases = {};
    dir = await Directory.systemTemp.createTemp('radar032-');
    await databaseFactory.setDatabasesPath(dir.path);
    store = await Store.open();
  });
  tearDown(() async {
    await store.db.close();
    await dir.delete(recursive: true);
    courseAliases = {};
  });
  test(
    'Alias normalizes school whitespace, keeps original records, and formats calendar',
    () async {
      await setCourseAlias('컴퓨터프로그래밍 2', '컴프2');
      expect(courseLabel('컴퓨터프로그래밍2'), '컴프2');
      expect(
        calendarDeadlineTitle(
          '컴퓨터프로그래밍 2',
          '연습',
          DateTime.parse('2026-10-20T23:59:00+09:00'),
        ),
        '[컴프2 23:59] 연습',
      );
      expect(displayCourseText('**컴퓨터프로그래밍 2** 과제'), '**컴프2** 과제');
    },
  );
  test(
    'Existing confirmed AI title updates without changing dates or personal title',
    () async {
      final n = CampusNotice(
        id: 'n',
        title: '공지',
        course: '컴퓨터프로그래밍 2',
        body: '10월 20일 제출',
        context: {},
      );
      await store.setMeta(
        'aiCandidate:AI:x',
        jsonEncode({'key': 'AI:x', 'notice': n.toJson(), 'candidate': {}}),
      );
      await store.setMeta(
        'aiState:AI:x',
        jsonEncode({
          'title': '[컴퓨터프로그래밍 2] 연습',
          'status': 'confirmed',
          'start': '2026-10-20T14:59:00.000Z',
          'calendarSent': true,
        }),
      );
      await setCourseAlias(n.course, '컴프2');
      var state = jsonDecode((await store.meta('aiState:AI:x'))!);
      expect(state['title'], '[컴프2] 연습');
      expect(state['start'], '2026-10-20T14:59:00.000Z');
      expect(state['calendarSent'], true);
      await setCourseAlias(n.course, '프로그2');
      state = jsonDecode((await store.meta('aiState:AI:x'))!);
      expect(state['title'], '[프로그2] 연습');
      expect(courseEventTitle('내가 정한 제목', n.course), '내가 정한 제목');
    },
  );
  test(
    'Daily AI rendering uses alias without changing task identity',
    () async {
      await setCourseAlias('원래 과목', '약자');
      final i = CampusItem(
        key: 'x',
        type: 'LR',
        title: '과제',
        course: '원래 과목',
        courseId: 'c',
        classNo: '1',
        contentsId: 'x',
        status: 'pending',
        due: DateTime.now().toUtc().add(const Duration(hours: 2)),
        context: {},
      );
      final rendered = renderAiSummary(
        {
          'focusKeys': ['x'],
          'advice': 'start_soon',
        },
        [i],
        DateTime.now().toUtc(),
      );
      expect(rendered, contains('약자'));
      expect(i.toJson()['course'], '원래 과목');
    },
  );
  testWidgets('Chat renders markdown and never loads remote markdown images', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(780, 1688);
    tester.view.devicePixelRatio = 2;
    await tester.runAsync(
      () => store.setMeta(
        'aiChat:all',
        jsonEncode([
          {'role': 'user', 'text': '예시'},
          {
            'role': 'model',
            'text':
                '## 제목\n\n**굵은 글씨**와 목록\n\n- 첫째\n- 둘째\n\n```java\nint[] a = {1, 2};\n```\n\n| 과목 | 기한 |\n|---|---|\n| 컴프2 | 내일 |\n\n![외부 이미지](https://example.invalid/tracking.png)',
          },
        ]),
      ),
    );
    await tester.pumpWidget(
      const MaterialApp(onGenerateRoute: buildAppRoute, home: AiChatPage()),
    );
    await tester.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 250)),
    );
    await tester.pumpAndSettle();
    await tester.tap(find.text('이전 대화'));
    await tester.pump();
    await tester.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 250)),
    );
    await tester.pumpAndSettle();
    await tester.tap(find.text('이전 버전의 대화'));
    await tester.pumpAndSettle();
    expect(find.byType(MarkdownBody), findsOneWidget);
    expect(find.byType(Image), findsNothing);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox.shrink());
    tester.view.resetPhysicalSize();
    tester.view.resetDevicePixelRatio();
  });
  testWidgets(
    'AI calendar editor resolves a previously saved full course name',
    (tester) async {
      courseAliases = {'컴퓨터프로그래밍2': '컴프2'};
      await tester.pumpWidget(
        MaterialApp(
          onGenerateRoute: buildAppRoute,
          home: CalendarDraftPage(
            itemKey: 'AI:example',
            title: '[컴퓨터프로그래밍2] 중간고사',
            courseName: '컴퓨터프로그래밍2',
            description: '가상 공지',
            start: DateTime.utc(2026, 10, 20),
          ),
        ),
      );
      await tester.pumpAndSettle();
      expect(find.widgetWithText(TextField, '[컴프2] 중간고사'), findsOneWidget);
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox.shrink());
    },
  );
  testWidgets(
    'Plan section shows linked plan cache rather than obsolete LMS blank fields',
    (tester) async {
      await tester.runAsync(
        () => store.setMeta(
          'coursePlan:c:1',
          jsonEncode({
            'fetchedAt': '2026-10-16T00:00:00Z',
            'linkedText': '실제 계획서\n평가 방법 50%\n주차별 강의계획',
            'linkedUrl': 'https://cnuit.cnu.ac.kr/checkMenu.jsp?test=synthetic',
            'data': {
              'plan_info': {'lect_goal': '오래된 빈 LMS 필드'},
            },
          }),
        ),
      );
      await tester.pumpWidget(
        const MaterialApp(
          onGenerateRoute: buildAppRoute,
          home: CoursePage(
            course: {'course_id': 'c', 'class_no': '1', 'course_nm': '예시 과목'},
          ),
        ),
      );
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 250)),
      );
      await tester.pumpAndSettle();
      await tester.tap(find.text('수업 정보'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('강의계획서 전체 읽기'));
      await tester.pumpAndSettle();
      expect(find.textContaining('평가 방법 50%'), findsOneWidget);
      expect(find.text('오래된 빈 LMS 필드'), findsNothing);
      await tester.pumpWidget(const SizedBox.shrink());
    },
  );
  test(
    'Accessibility manifest cannot read window content or perform gestures',
    () {
      final root = Directory.current.path;
      final config = File(
        '$root/android/app/src/main/res/xml/radar_accessibility.xml',
      ).readAsStringSync();
      expect(config, contains('canRetrieveWindowContent="false"'));
      expect(config, contains('canPerformGestures="false"'));
      expect(config, contains('typeWindowStateChanged'));
      expect(config, isNot(contains('typeViewTextChanged')));
    },
  );
  testWidgets(
    'Compact card resizing persists dimensions without changing privacy',
    (tester) async {
      tester.view.physicalSize = const Size(800, 2400);
      tester.view.devicePixelRatio = 1;
      var config = <String, dynamic>{
        'enabled': true,
        'allowed': true,
        'details': false,
        'mode': 'compact',
        'position': 'right',
        'width': 270,
        'height': 380,
        'x': 90,
        'y': 40,
      };
      Map<dynamic, dynamic>? saved;
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(bridge, (call) async {
            if (call.method == 'lockConfigure') {
              saved = call.arguments as Map;
              config = {...config, ...Map<String, dynamic>.from(saved!)};
              return null;
            }
            return config;
          });
      await tester.pumpWidget(
        const MaterialApp(
          onGenerateRoute: buildAppRoute,
          home: LockScreenSettingsPage(),
        ),
      );
      await tester.pumpAndSettle();
      expect(find.byType(Slider), findsNWidgets(5));
      await tester.drag(find.byType(Slider).at(1), const Offset(-120, 0));
      await tester.pumpAndSettle();
      expect(saved, isNotNull);
      expect(saved!['width'], lessThan(270));
      expect(saved!['height'], 380);
      expect(saved!['x'], 90);
      expect(saved!['y'], 40);
      expect(saved!['details'], false);
      expect(saved!['enabled'], true);
      await tester.pumpWidget(const SizedBox.shrink());
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(bridge, null);
    },
  );
}

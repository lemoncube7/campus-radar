import 'package:campus_radar/tasks/task_presentation.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/campus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

class NoticeClient extends CampusClient {
  final bool duplicate;
  final List<int> offsets = [];
  NoticeClient({this.duplicate = false});
  @override
  Future<dynamic> api(
    String route,
    Map<String, dynamic>? payload, {
    String host = CampusClient.learning,
  }) async {
    if (route == '/term/getYearTermList') {
      return {
        'list': [
          {'current_term_yn': 'Y', 'term_year': '2026', 'term_cd': '2'},
        ],
      };
    }
    if (route == '/board/std/notice/list') {
      final offset = payload!['offset'] as int;
      offsets.add(offset);
      return {
        'tot_cnt': 125,
        'list': List.generate(
          offset == 0 ? 100 : 25,
          (i) => {
            'boarditem_no': '${duplicate ? i : offset + i}',
            'boarditem_title': '<b>공지</b> $i',
            'course_nm': '수업',
            'course_id': 'course',
            'class_no': '1',
            'insert_dt': '2026-10-15 08:30:00',
            'read_yn': i.isEven ? 'Y' : 'N',
          },
        ),
      };
    }
    if (route == '/course/addSessionCourseInfo') {
      return {
        'data': {'course_id': 'course'},
      };
    }
    if (route == '/board/notice/info') {
      return {'boarditem_content': '<p>제출 <b>안내</b></p>'};
    }
    throw StateError('Unexpected route');
  }
}

void main() {
  test('Deadline boundaries include exactly 24 hours and separate overdue', () {
    final now = DateTime.utc(2026, 10, 15);
    expect(deadlineState(null, now: now), DeadlineState.unknown);
    expect(deadlineState(now, now: now), DeadlineState.overdue);
    expect(
      deadlineState(now.subtract(const Duration(seconds: 1)), now: now),
      DeadlineState.overdue,
    );
    expect(
      deadlineState(now.add(const Duration(hours: 24)), now: now),
      DeadlineState.withinDay,
    );
    expect(
      deadlineState(now.add(const Duration(hours: 24, seconds: 1)), now: now),
      DeadlineState.remaining,
    );
  });
  test('Completed assignments use completion color even after deadline', () {
    final item = CampusItem(
      key: 'x',
      type: 'LR',
      title: '과제',
      course: '수업',
      courseId: 'c',
      classNo: '1',
      contentsId: 'x',
      status: 'done',
      due: DateTime.utc(2000),
      context: {},
    );
    expect(deadlineLabel(item), '완료');
    expect(deadlineColor(item), Colors.green.shade800);
  });
  test(
    'Notice collection includes later pages and preserves school read state',
    () async {
      final c = NoticeClient();
      try {
        final list = await c.fetchNotices();
        expect(list, hasLength(125));
        expect(c.offsets, [0, 100]);
        final first = list.singleWhere((n) => n.id == '0');
        expect(first.title, '공지 0');
        expect(first.read, isTrue);
        expect(list.singleWhere((n) => n.id == '1').read, isFalse);
        expect(first.published, DateTime.utc(2026, 10, 14, 23, 30));
        final body = await c.fetchNoticeBody(first);
        expect(body.body, '제출 안내');
        expect(body.bodyFetched, isTrue);
        expect(CampusNotice.fromJson(body.toJson()).body, body.body);
      } finally {
        c.close();
      }
    },
  );
  test(
    'Repeated notice pages fail instead of storing a truncated collection',
    () async {
      final c = NoticeClient(duplicate: true);
      try {
        await expectLater(c.fetchNotices(), throwsA(isA<CampusException>()));
      } finally {
        c.close();
      }
    },
  );
}

import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/main.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/ai/notice_ai_service.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/schedule/schedule_repository.dart';
import 'package:campus_radar/notices/notice_analysis_page.dart';
import 'package:campus_radar/home/home_navigation.dart';
import 'package:campus_radar/navigation/app_navigation.dart';
import 'package:campus_radar/core/native_bridge.dart';

const candidate = ScheduleCandidate(
  title: '검증 시험',
  date: '2030-11-01',
  time: '13:00',
  action: 'add',
  evidence: '2030년 11월 1일 13:00 시험',
  uncertainty: '',
  category: 'exam',
);
CampusNotice source() => CampusNotice(
  id: 'source',
  title: '시험 안내',
  course: '가상과목',
  context: {},
  body: candidate.evidence,
  bodyFetched: true,
);
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  setUp(() async {
    homeNavigation.value = null;
    temp = await Directory.systemTemp.createTemp('ux050-');
    await databaseFactory.setDatabasesPath(temp.path);
    SharedPreferences.setMockInitialValues({});
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          (c) async => c.method == 'read' ? 'synthetic' : null,
        );
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          bridge,
          (c) async =>
              c.method == 'timetableSettings' ? {'until': '2099-12-31'} : null,
        );
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('window_manager'),
          (c) async => false,
        );
    final s = await Store.open();
    await s.saveNotice(source());
    await rememberCandidates(s, source(), [candidate]);
    await s.setMeta(
      'aiState:${candidateKey(source(), candidate)}',
      jsonEncode({
        'status': 'confirmed',
        'date': '2030-11-01',
        'start': '2030-11-01T04:00:00Z',
        'allDay': false,
        'title': '직접 수정한 시험',
        'approvalMode': 'automatic',
        'calendarSent': false,
      }),
    );
    await s.db.close();
  });
  tearDown(() async {
    homeNavigation.value = null;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(const MethodChannel('window_manager'), null);
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(bridge, null);
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          null,
        );
    await temp.delete(recursive: true);
  });
  Future<void> ready(WidgetTester t, Widget widget) async {
    addTearDown(() async {
      await t.pumpWidget(const SizedBox.shrink());
      for (var i = 0; i < 5; i++) {
        await t.pump();
        await t.runAsync(
          () => Future<void>.delayed(const Duration(milliseconds: 100)),
        );
      }
    });
    await t.pumpWidget(RadarApp(home: widget));
    await t.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 350)),
    );
    await t.pumpAndSettle();
  }

  Future<void> close(WidgetTester t) async {
    await t.pumpWidget(const SizedBox.shrink());
    await t.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 150)),
    );
    await t.pump();
  }

  test(
    'Calendar keeps inclusive periods and exclusive all-day endpoints distinct',
    () {
      final row = {
        'notice': source(),
        'candidate': candidate,
        'state': {
          'status': 'confirmed',
          'date': '2030-11-01',
          'end': '2030-11-03T00:00:00Z',
          'allDay': true,
        },
      };
      expect(confirmedOnDay([row], '2030-11-02'), hasLength(1));
      expect(confirmedOnDay([row], '2030-11-03'), isEmpty);
      expect(
        confirmedOnDay([
          {
            ...row,
            'state': {'status': 'review', 'date': '2030-11-01'},
          },
        ], '2030-11-01'),
        isEmpty,
      );
    },
  );
  testWidgets(
    'Four root destinations keep task view default and expose calendar and review',
    (t) async {
      t.view.physicalSize = const Size(600, 960);
      t.view.devicePixelRatio = 1;
      addTearDown(t.view.resetPhysicalSize);
      addTearDown(t.view.resetDevicePixelRatio);

      await ready(t, const Dashboard(autoSync: false));
      expect(
        t.widget<NavigationBar>(find.byType(NavigationBar)).destinations,
        hasLength(4),
      );
      expect(find.widgetWithText(NavigationDestination, 'AI'), findsNothing);
      await t.tap(find.widgetWithText(NavigationDestination, '할 일'));
      await t.pumpAndSettle();
      expect(find.text('과제·콘텐츠·자료·과목 검색'), findsOneWidget);
      expect(find.byType(SegmentedButton<ScheduleView>), findsNothing);
      await t.tap(find.widgetWithText(NavigationDestination, '더보기'));
      await t.pumpAndSettle();
      expect(find.text('캘린더'), findsOneWidget);
      expect(find.text('시간표'), findsOneWidget);
      expect(find.text('검토함'), findsOneWidget);
      expect(t.takeException(), isNull);
      await close(t);
    },
  );
  testWidgets(
    'Source view reads the same approved title and never asks to approve it again',
    (t) async {
      await ready(t, NoticeAnalysisPage(notice: source()));
      expect(find.text('직접 수정한 시험'), findsOneWidget);
      expect(find.text('일정에 추가'), findsNothing);
      expect(find.text('Gemini 검토 · 자동 승인'), findsOneWidget);
      expect(find.text('앱에 추가됨 · 캘린더 미전송'), findsOneWidget);
      await close(t);
    },
  );
  testWidgets(
    'Widget background returns to task list; expired target gives feedback',
    (t) async {
      await ready(t, const Dashboard(autoSync: false));
      await t.runAsync(() => openItem('_tasks'));
      await t.pumpAndSettle();
      expect(find.text('과제·콘텐츠·자료·과목 검색'), findsOneWidget);
      openTaskList(message: '현재 목록에서 이 항목을 찾지 못했어요. 목록을 새로 확인해 주세요.');
      await t.pump();
      expect(homeNavigation.value, isNull);
      expect(
        find.text('현재 목록에서 이 항목을 찾지 못했어요. 목록을 새로 확인해 주세요.'),
        findsOneWidget,
      );
      await close(t);
    },
  );
  testWidgets(
    'Schedule controls remain reachable at narrow width with enlarged text',
    (t) async {
      t.view.physicalSize = const Size(380, 800);
      t.view.devicePixelRatio = 1;
      addTearDown(t.view.resetPhysicalSize);
      addTearDown(t.view.resetDevicePixelRatio);
      await ready(
        t,
        MediaQuery(
          data: const MediaQueryData(
            size: Size(380, 800),
            textScaler: TextScaler.linear(1.4),
          ),
          child: const Dashboard(autoSync: false),
        ),
      );
      await t.tap(find.widgetWithText(NavigationDestination, '할 일'));
      await t.pumpAndSettle();
      expect(t.takeException(), isNull);
      await close(t);
    },
  );
}

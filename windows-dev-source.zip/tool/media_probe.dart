// ignore_for_file: avoid_print, avoid_relative_lib_imports
import 'dart:io';
import 'dart:convert';
import '../lib/campus.dart';
Future<void> main() async {
 final lines=File('../../login.txt').readAsLinesSync().where((s)=>s.trim().isNotEmpty).toList();
 final c=CampusClient();final results=<Map<String,dynamic>>[];
 try {
 await c.login(lines[0].replaceFirst(RegExp(r'^\s*(id|아이디)\s*[:=]\s*',caseSensitive:false),''),lines[1].replaceFirst(RegExp(r'^\s*(pw|password|비밀번호)\s*[:=]\s*',caseSensitive:false),''));
 final notices=await c.fetchNotices();var imageCount=0,fileCount=0;
 for(final n in notices.take(80)) {
  final full=await c.fetchNoticeBody(n);
  for(final m in full.media) {
   if(!m.supported || (m.image ? imageCount>=2 : fileCount>=2))continue;
   try {final d=await c.downloadMedia(m);results.add({'kind':m.image?'image':'file','transport':m.form.isEmpty?'LMS':'CMS','mime':d.mime,'bytes':d.bytes.length});
    if(m.image){imageCount++;}else{fileCount++;}
   }catch(e){results.add({'kind':m.image?'image':'file','error':'$e'});}
  }
  if(imageCount>=2 && fileCount>=2)break;
 }
 final items=await c.fetchItems();var assignmentFiles=0;
 for(final i in items.where((i)=>i.type=='LR' && i.availableAt(DateTime.now()))) {
  for(final m in i.media.take(2)) {
   if(assignmentFiles>=2 || !m.supported)continue;
   try {final d=await c.downloadMedia(m);results.add({'kind':'assignment attachment','transport':m.form.isEmpty?'LMS':'CMS','mime':d.mime,'bytes':d.bytes.length});assignmentFiles++;}catch(e){results.add({'kind':'assignment attachment','error':'$e'});}
  }
 }
 final out=File('../../outputs/tests/media049-live.json');await out.writeAsString(const JsonEncoder.withIndent('  ').convert(results));print(await out.readAsString());
 }finally{c.close();}
}

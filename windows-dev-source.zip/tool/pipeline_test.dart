// PC pipeline: cassette → collection (manual, then automatic reuse) → local
// store → Drive/academic export documents, with timings and request counts.
//
// It needs Flutter's test runner because the store uses sqflite:
//   CASSETTE=cassettes/today flutter test tool/pipeline_test.dart
// Optional: DELAY_MS=300 (per school call), OUT=out/pipeline (write documents).
// Lives in tool/ so a normal `flutter test` does not run it.
import 'dart:convert';
import 'dart:io';

import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/core/sync_timing.dart';
import 'package:campus_radar/export/academic_export.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import '../bin/campus_cli.dart';

void main() {
  final env = Platform.environment;
  final cassette = env['CASSETTE'];
  test('pipeline', () async {
    if (cassette == null || !Directory(cassette).existsSync()) {
      markTestSkipped('Set CASSETTE to a recorded cassette directory.');
      return;
    }
    final delay = Duration(
      milliseconds: int.tryParse(env['DELAY_MS'] ?? '') ?? 0,
    );
    TestWidgetsFlutterBinding.ensureInitialized();
    // ignore: invalid_use_of_visible_for_testing_member
    SharedPreferences.setMockInitialValues({});
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfiNoIsolate;
    final dir = await Directory.systemTemp.createTemp('radar-pipeline-');
    await databaseFactory.setDatabasesPath(dir.path);
    final store = await Store.open();
    final report = <String>[];
    try {
      Future<CliClient> run(String label, {bool reuse = false}) async {
        final client = CliClient(replay: Directory(cassette), delay: delay)
          ..apiTiming = SyncTiming();
        final clock = Stopwatch()..start();
        final previous = {for (final i in await store.items()) i.key: i};
        final items = await client.fetchItems(
          previous: reuse ? previous : const {},
          reuseDetailsFor: reuse ? const Duration(hours: 6) : Duration.zero,
        );
        final notices = await client.fetchNotices();
        await store.replace(items);
        await store.replaceNotices(notices);
        await store.setMeta(MetaKey.courses, jsonEncode(client.courseList));
        await store.setMeta(
          MetaKey.lastSuccess,
          DateTime.now().toUtc().toIso8601String(),
        );
        final requests = client.calls.values.fold<int>(0, (a, b) => a + b);
        report
          ..add(
            '[$label] 항목 ${items.length} · 공지 ${notices.length} · 요청 $requests회',
          )
          ..addAll(
            client.apiTiming!
                .describe(clock.elapsedMilliseconds)
                .map((l) => '  $l'),
          );
        if (client.missing.isNotEmpty) {
          report.add(
            '  카세트에 없는 요청 ${client.missing.length}회: ${client.missing.toSet().join(', ')}',
          );
        }
        client.close();
        return client;
      }

      final manual = await run('수동 수집');
      final auto = await run('자동 수집(재사용 6시간)', reuse: true);
      int count(CliClient c) => c.calls.values.fold<int>(0, (a, b) => a + b);
      report.add('재사용으로 줄어든 요청: ${count(manual) - count(auto)}회');

      final clock = Stopwatch()..start();
      final export = await buildAcademicExport(
        store,
        '0123456789abcdef0123456789abcdef',
      );
      final bytes = export.documents.values.fold<int>(
        0,
        (a, d) => a + utf8.encode(d).length,
      );
      report.add(
        '[내보내기] 문서 ${export.documents.length}개 · ${(bytes / 1024).toStringAsFixed(1)} KB · ${clock.elapsedMilliseconds} ms',
      );
      final out = env['OUT'];
      if (out != null) {
        for (final e in export.documents.entries) {
          final f = File('$out/${e.key}')..parent.createSync(recursive: true);
          await f.writeAsString(e.value);
        }
        report.add('문서 저장: $out');
      }
      // ignore: avoid_print
      print(report.join('\n'));
    } finally {
      await store.db.close();
      await dir.delete(recursive: true);
    }
  }, timeout: const Timeout(Duration(minutes: 10)));
}

// Feasibility probe: can a Windows "Desktop app" OAuth client in the same
// Cloud project read the Drive files the phone created, with drive.file only?
//
//   dart run tool/drive_probe.dart [--client FILE] [--token FILE] [--logout]
//
// Prints metadata only (names, sizes, times, format header fields). Never
// prints tokens, auth codes, or document bodies.
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:crypto/crypto.dart';

const scope = 'https://www.googleapis.com/auth/drive.file';
const startName = '캠퍼스레이더 시작.txt';

Future<void> main(List<String> args) async {
  String opt(String name, String fallback) {
    final i = args.indexOf(name);
    return i >= 0 && i + 1 < args.length ? args[i + 1] : fallback;
  }

  final clientFile = File(opt('--client', '../../work/windows-oauth-client.json'));
  final tokenFile = File(opt('--token', '../../work/drive-probe-token.json'));
  if (args.contains('--logout')) {
    if (await tokenFile.exists()) await tokenFile.delete();
    print('Saved probe token removed.');
    return;
  }
  if (!await clientFile.exists()) {
    stderr.writeln('Missing ${clientFile.path} (Desktop app OAuth client JSON).');
    exit(2);
  }
  final cfg = jsonDecode(await clientFile.readAsString()) as Map;
  final c = (cfg['installed'] ?? cfg) as Map;
  final clientId = '${c['client_id']}', secret = '${c['client_secret']}';

  var access = await _refresh(tokenFile, clientId, secret);
  if (access == null) {
    access = await _login(tokenFile, clientId, secret);
    print('Login: OK (new consent)');
  } else {
    print('Login: OK (saved refresh token)');
  }

  final api = _Drive(access);
  final grant = await api.get('https://www.googleapis.com/oauth2/v3/tokeninfo?access_token=$access');
  print('Granted scope: ${grant['scope']}');

  final starts = await api.list("name = '$startName' and trashed = false");
  print('\nStart files visible with drive.file: ${starts.length}');
  if (starts.isEmpty) {
    final any = await api.list('trashed = false');
    print('Any files visible at all: ${any.length}');
    print('=> Phone-created files are NOT visible to this client.');
    return;
  }
  for (final f in starts) {
    final parent = (f['parents'] as List?)?.first;
    final folder = parent == null ? null : await api.meta(parent);
    print('- folder "${folder?['name']}" (${parent ?? '-'}) modified ${f['modifiedTime']} size ${f['size']}');
    final text = await api.text(f['id']);
    final firstLine = text.split('\n').first;
    print('  header: $firstLine');
    try {
      final index = jsonDecode(text.substring(firstLine.length + 1)) as Map;
      for (final k in ['formatVersion', 'exportedAt', 'collectedAt', 'timezone']) {
        print('  $k: ${index[k]}');
      }
      final ref = index['appSnapshot'];
      print('  appSnapshot ref: ${ref is Map ? '${ref['path']} schema ${ref['schema']}' : 'none'}');
      if (ref is Map && parent != null) {
        final hits = await api.list("name = '${ref['path']}' and '$parent' in parents and trashed = false");
        if (hits.isEmpty) {
          print('  appSnapshot file: missing');
        } else {
          final body = await api.text(hits.first['id']);
          final ok = sha256.convert(utf8.encode(body)).toString() == ref['sha256'];
          print('  appSnapshot file: ${utf8.encode(body).length} bytes, sha256 ${ok ? 'MATCH' : 'MISMATCH'}');
          final out = args.indexOf('--save');
          if (out >= 0) {
            await File(args[out + 1]).writeAsString(body);
            print('  saved locally for the apply test (not printed)');
          }
        }
      }
      final docs = index['documents'];
      print('  documents in index: ${docs is List ? docs.length : docs is Map ? docs.length : '?'}');
    } catch (e) {
      print('  index: not parsed ($e)');
    }
    if (parent != null) {
      final children = await api.list("'$parent' in parents and trashed = false");
      print('  children visible: ${children.length}');
      final body = children.firstWhere(
        (x) => x['mimeType'] == 'text/plain' && x['name'] != startName,
        orElse: () => {},
      );
      if (body.isNotEmpty) {
        final t = await api.text(body['id']);
        print('  sample body "${body['name']}": readable, ${utf8.encode(t).length} bytes');
      }
      final sub = children.where((x) => x['mimeType'] == 'application/vnd.google-apps.folder');
      for (final s in sub) {
        final n = await api.list("'${s['id']}' in parents and trashed = false");
        print('  subfolder "${s['name']}": ${n.length} files visible');
      }
    }
  }
}

class _Drive {
  final String token;
  _Drive(this.token);
  final _http = HttpClient();

  Future<Map> get(String url) async => jsonDecode(await _raw(url)) as Map;
  Future<String> text(String id) =>
      _raw('https://www.googleapis.com/drive/v3/files/$id?alt=media');
  Future<Map?> meta(String id) async {
    try {
      return await get('https://www.googleapis.com/drive/v3/files/$id?fields=id,name,mimeType');
    } on HttpException catch (e) {
      print('  (folder metadata not accessible: ${e.message})');
      return null;
    }
  }

  Future<List<Map>> list(String q) async {
    final out = <Map>[];
    String? page;
    do {
      final u = Uri.https('www.googleapis.com', '/drive/v3/files', {
        'q': q,
        'pageSize': '200',
        'fields': 'nextPageToken,files(id,name,mimeType,parents,modifiedTime,size)',
        'pageToken': ?page,
      });
      final j = await get(u.toString());
      out.addAll((j['files'] as List).cast<Map>());
      page = j['nextPageToken'] as String?;
    } while (page != null);
    return out;
  }

  Future<String> _raw(String url) async {
    final req = await _http.getUrl(Uri.parse(url));
    req.headers.set('Authorization', 'Bearer $token');
    final res = await req.close();
    final body = await utf8.decodeStream(res);
    if (res.statusCode != 200) {
      String reason = '';
      try {
        reason = '${(jsonDecode(body)['error'] as Map)['message']}';
      } catch (_) {}
      throw HttpException('HTTP ${res.statusCode} $reason');
    }
    return body;
  }
}

Future<String?> _refresh(File tokenFile, String id, String secret) async {
  if (!await tokenFile.exists()) return null;
  final refresh = (jsonDecode(await tokenFile.readAsString()) as Map)['refresh_token'];
  final j = await _post({
    'client_id': id,
    'client_secret': secret,
    'refresh_token': '$refresh',
    'grant_type': 'refresh_token',
  });
  return j['access_token'] as String?;
}

Future<String> _login(File tokenFile, String id, String secret) async {
  final rnd = Random.secure();
  String rand(int n) =>
      base64Url.encode(List.generate(n, (_) => rnd.nextInt(256))).replaceAll('=', '');
  final verifier = rand(48), state = rand(16);
  final challenge =
      base64Url.encode(sha256.convert(ascii.encode(verifier)).bytes).replaceAll('=', '');
  final server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
  final redirect = 'http://127.0.0.1:${server.port}';
  final url = Uri.https('accounts.google.com', '/o/oauth2/v2/auth', {
    'client_id': id,
    'redirect_uri': redirect,
    'response_type': 'code',
    'scope': scope,
    'code_challenge': challenge,
    'code_challenge_method': 'S256',
    'state': state,
    'access_type': 'offline',
    'prompt': 'consent',
  });
  print('Opening browser for Google sign-in...');
  await Process.run('rundll32', ['url.dll,FileProtocolHandler', url.toString()]);
  final req = await server.first.timeout(const Duration(minutes: 5));
  final q = req.uri.queryParameters;
  req.response
    ..headers.contentType = ContentType.html
    ..write('<meta charset="utf-8"><p>Campus Radar probe: 로그인 완료. 이 창을 닫아도 돼요.</p>');
  await req.response.close();
  await server.close();
  if (q['state'] != state) throw StateError('state mismatch');
  if (q['code'] == null) throw StateError('no code: ${q['error']}');
  final j = await _post({
    'client_id': id,
    'client_secret': secret,
    'code': q['code']!,
    'code_verifier': verifier,
    'grant_type': 'authorization_code',
    'redirect_uri': redirect,
  });
  if (j['refresh_token'] != null) {
    await tokenFile.writeAsString(jsonEncode({'refresh_token': j['refresh_token']}));
  }
  return j['access_token'] as String;
}

Future<Map> _post(Map<String, String> form) async {
  final http = HttpClient();
  final req = await http.postUrl(Uri.parse('https://oauth2.googleapis.com/token'));
  req.headers.contentType = ContentType('application', 'x-www-form-urlencoded');
  req.write(Uri(queryParameters: form).query);
  final res = await req.close();
  final body = jsonDecode(await utf8.decodeStream(res)) as Map;
  if (res.statusCode != 200) {
    throw HttpException('token HTTP ${res.statusCode} ${body['error']}');
  }
  return body;
}

package kr.campusradar.campus_radar
import android.app.Activity
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.*
import org.json.JSONObject
import org.json.JSONTokener
/** One non-interactive renderer behind Flutter; never launches another Activity. */
class SyllabusCapture(private val activity:Activity,private val url:String,private val course:String,private val complete:(Map<String,String>?,String?)->Unit){
 private val handler=Handler(Looper.getMainLooper())
 private var web:WebView?=null
 private var done=false
 private var previous=""
 private var stable=0
 private var retried=false
 private fun trusted(value:String):Boolean{val u=Uri.parse(value);return u.scheme=="https"&&u.host in setOf("cnuit.cnu.ac.kr","tlsn.cnu.ac.kr")&&u.userInfo==null}
 fun start(){
  if(!trusted(url)){finish(null,"허용되지 않은 강의계획서 주소예요.");return}
  val root=activity.findViewById<ViewGroup>(android.R.id.content)
  val view=WebView(activity);web=view
  view.alpha=0f;view.isFocusable=false;view.isFocusableInTouchMode=false;view.importantForAccessibility=android.view.View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
  root.addView(view,0,ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT))
  view.settings.javaScriptEnabled=true;view.settings.domStorageEnabled=true;view.settings.allowFileAccess=false;view.settings.allowContentAccess=false;view.settings.mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW
  view.webViewClient=object:WebViewClient(){
   override fun shouldOverrideUrlLoading(v:WebView,r:WebResourceRequest)=!trusted(r.url.toString())
   override fun shouldInterceptRequest(v:WebView,r:WebResourceRequest):WebResourceResponse?=if(trusted(r.url.toString()))null else WebResourceResponse("text/plain","UTF-8",java.io.ByteArrayInputStream(byteArrayOf()))
   override fun onPageFinished(v:WebView,value:String){if(trusted(value)){handler.removeCallbacks(poll);handler.postDelayed(poll,800)}}
   override fun onReceivedError(v:WebView,r:WebResourceRequest,e:WebResourceError){if(r.isForMainFrame)retry("계획서 연결 실패 (${e.errorCode})")}
   override fun onReceivedHttpError(v:WebView,r:WebResourceRequest,e:WebResourceResponse){if(r.isForMainFrame){if(e.statusCode>=500||e.statusCode==408||e.statusCode==429)retry("계획서 서버 응답 오류 (${e.statusCode})")else finish(null,"계획서 접근 실패 (${e.statusCode})")}}
  }
  handler.postDelayed({finish(null,"계획서 본문을 제한 시간 내 확인하지 못했어요. 원문 열기로 확인해 주세요.")},60000)
  view.loadUrl(url)
 }
 private fun retry(message:String){if(done)return;if(retried){finish(null,message);return};retried=true;previous="";stable=0;handler.removeCallbacks(poll);handler.postDelayed({if(!done)web?.reload()},1000)}
 private val poll=object:Runnable{override fun run(){if(done)return;web?.evaluateJavascript(SyllabusFetchActivity.EXTRACT){raw->if(!done)try{
  val d=JSONTokener(raw).nextValue();val v=if(d is String)JSONObject(d)else JSONObject()
  val text=v.optString("text").take(120000);val normalized=text.replace(Regex("\\s+"),"");val expected=course.replace(Regex("\\s+"),"")
  val valid=v.optInt("fields")>=8&&text.length>=400&&normalized.contains("교과목")&&(expected.isEmpty()||normalized.contains(expected))
  stable=if(valid&&previous==text)stable+1 else 0;previous=text
  if(valid&&stable>=2)finish(mapOf("text" to text,"structure" to (v.optJSONArray("tables")?.toString()?:"[]"),"sourceUrl" to url),null)else handler.postDelayed(this,800)
 }catch(_:Exception){handler.postDelayed(this,800)}}}}
 fun cancel(){finish(null,"계획서 가져오기를 취소했어요.")}
 private fun finish(value:Map<String,String>?,error:String?){if(done)return;done=true;handler.removeCallbacksAndMessages(null);val view=web;web=null;view?.stopLoading();(view?.parent as? ViewGroup)?.removeView(view);view?.destroy();complete(value,error)}
}

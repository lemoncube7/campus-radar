package kr.campusradar.campus_radar

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.work.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

object DriveSyncStore {
 private fun p(c:Context)=c.getSharedPreferences("radar_drive",0)
 @Synchronized fun accounts(c:Context):JSONObject=JSONObject(p(c).getString("accounts","{}")?:"{}")
 @Synchronized private fun save(c:Context,a:JSONObject){check(p(c).edit().putString("accounts",a.toString()).commit());val file=android.util.AtomicFile(File(c.filesDir,"drive-targets-v1.json"));val out=file.startWrite();try{out.write(a.toString().toByteArray(Charsets.UTF_8));file.finishWrite(out)}catch(e:Exception){file.failWrite(out);throw e}}
 @Synchronized fun add(c:Context,id:String,email:String){val a=accounts(c);val r=a.optJSONObject(id)?:JSONObject().put("enabled",false).put("binding",java.util.UUID.randomUUID().toString());r.put("email",email).put("error","");a.put(id,r);save(c,a)}
 @Synchronized fun configure(c:Context,id:String,enabled:Boolean,accountHash:String,options:Map<String,Any?>){
  val a=accounts(c);val r=a.getJSONObject(id)
  val previous=r.optString("accountHash")
  if(previous.isNotEmpty()&&previous!=accountHash){r.remove("folder");r.remove("files");r.remove("hashes");r.remove("courseFolder");r.remove("lastSuccess");r.remove("lastSnapshot")}
  r.put("enabled",enabled).put("accountHash",accountHash).put("options",JSONObject(options)).put("binding",java.util.UUID.randomUUID().toString()).put("error","")
  a.put(id,r);save(c,a);schedule(c)
 }
 @Synchronized fun remove(c:Context,id:String){val a=accounts(c);a.remove(id);save(c,a);schedule(c)}
 @Synchronized fun state(c:Context,id:String,update:JSONObject){val a=accounts(c);if(a.has(id)&&a.getJSONObject(id).optString("binding")==update.optString("binding")){a.put(id,update);save(c,a)}}
 fun rows(c:Context):List<Map<String,Any?>>{val a=accounts(c);return a.keys().asSequence().map{id->val r=a.getJSONObject(id);mapOf("id" to id,"binding" to r.optString("binding"),"accountHash" to r.optString("accountHash"),"email" to r.optString("email"),"enabled" to r.optBoolean("enabled"),"lastSuccess" to r.optString("lastSuccess"),"error" to r.optString("error"),"folderUrl" to r.optString("folder").let{if(it.isBlank())"" else "https://drive.google.com/drive/folders/$it"},"options" to r.optJSONObject("options")?.toString())}.toList()}
 fun schedule(c:Context){
  val active=rows(c).any{it["enabled"]==true};val wm=WorkManager.getInstance(c)
  if(!active){wm.cancelUniqueWork("radar-drive-periodic");return}
  val constraints=Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
  wm.enqueueUniquePeriodicWork("radar-drive-periodic",ExistingPeriodicWorkPolicy.KEEP,PeriodicWorkRequestBuilder<DriveSyncWorker>(15,TimeUnit.MINUTES).setConstraints(constraints).setBackoffCriteria(BackoffPolicy.EXPONENTIAL,1,TimeUnit.MINUTES).build())
 }
 /** Logs why a run did nothing, once per distinct reason, so periodic runs don't flood the log. */
 @Synchronized fun note(c:Context,title:String,detail:String){
  val key="$title|$detail";if(p(c).getString("lastNote","")==key)return
  p(c).edit().putString("lastNote",key).apply();RadarData.log(c,title,detail,"app")
 }
 fun clearNote(c:Context)=p(c).edit().remove("lastNote").apply()
 // A manual request replaces a run waiting in retry backoff instead of being ignored.
 fun enqueue(c:Context,manual:Boolean=false){
  if(rows(c).none{it["enabled"]==true}){if(manual)RadarData.log(c,"Drive 전송 요청 무시","자동 전송이 켜진 Google 계정이 없어요.","app");return}
  WorkManager.getInstance(c).enqueueUniqueWork("radar-drive-now",if(manual)ExistingWorkPolicy.APPEND_OR_REPLACE else ExistingWorkPolicy.KEEP,OneTimeWorkRequestBuilder<DriveSyncWorker>().setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).setBackoffCriteria(BackoffPolicy.EXPONENTIAL,1,TimeUnit.MINUTES).build())
 }
 fun epoch(c:Context):String?=try{
  SQLiteDatabase.openDatabase(c.getDatabasePath("campus.db").path,null,SQLiteDatabase.OPEN_READONLY).use{db->
   val blocked=db.rawQuery("SELECT value FROM meta WHERE id='sessionBlocked'",null).use{it.moveToFirst()&&it.getString(0)=="yes"}
   if(blocked)null else db.rawQuery("SELECT value FROM meta WHERE id='sessionEpoch'",null).use{if(it.moveToFirst())it.getString(0)else null}
  }
 }catch(_:Exception){null}
}

class DriveSyncWorker(c:Context,p:WorkerParameters):Worker(c,p){
 override fun doWork():Result=synchronized(lock){
  val c=applicationContext
  val file=File(c.filesDir,"drive-export-v1.json")
  if(!file.isFile){DriveSyncStore.note(c,"Drive 전송 건너뜀","보낼 자료가 아직 준비되지 않았어요. 앱을 열거나 학교 자료를 수집하면 준비돼요.");return@synchronized Result.success()}
  var retry=false
  val deadline=android.os.SystemClock.elapsedRealtime()+7*60*1000
  val snapshot=try{if(file.length()>32L*1024*1024)throw IllegalStateException("snapshot over 32MB");JSONObject(file.readText())}catch(e:Exception){RadarData.logError(c,"Drive 전송 실패","준비된 전송 자료를 읽지 못했어요. 앱에서 다시 전송해 주세요.",e);return@synchronized Result.failure()}
  val epoch=snapshot.optString("epoch");if(epoch.isBlank()||DriveSyncStore.epoch(c)!=epoch){DriveSyncStore.note(c,"Drive 전송 건너뜀","학교 연결이 바뀌었거나 멈춘 상태라 이전에 준비한 자료는 보내지 않아요. 학교 연결 후 다시 준비돼요.");return@synchronized Result.success()}
  val payloads=snapshot.optJSONObject("accounts")?:return@synchronized Result.success()
  val all=DriveSyncStore.accounts(c)
  // Newly connected accounts (no completed upload yet) go first so they are not starved.
  val order=all.keys().asSequence().toList().sortedBy{all.optJSONObject(it)?.optString("lastSuccess").isNullOrEmpty().not()}
  for(id in order){
   if(isStopped)return@synchronized Result.success()
   if(android.os.SystemClock.elapsedRealtime()>=deadline){retry=true;break}
   var row=all.getJSONObject(id)
   if(!row.optBoolean("enabled")||!payloads.has(id))continue
   val payload=payloads.getJSONObject(id)
   if(row.optString("accountHash")!=snapshot.optString("accountHash")||row.optString("binding")!=payload.optString("binding")){DriveSyncStore.note(c,"Drive 전송 건너뜀","${row.optString("email")}: 설정이 바뀐 뒤 자료가 아직 다시 준비되지 않았어요. 앱을 열면 새 설정으로 준비해요.");continue}
   val binding=row.getString("binding")
   fun checkActive(){check(!isStopped);val live=DriveSyncStore.accounts(c).optJSONObject(id);check(live!=null&&live.optBoolean("enabled")&&live.optString("binding")==binding&&DriveSyncStore.epoch(c)==epoch)}
   try{
    checkActive()
    val token=DriveAuthorization.token(c,row.getString("email"));checkActive();val api=DriveApi(token){DriveAuthorization.clear(c,token)}
    fun checkpoint(){checkActive();DriveSyncStore.state(c,id,row)}
    var folder=row.optString("folder")
    if(folder.isBlank()||!api.exists(folder)){
     checkActive();folder=api.id()
     row.put("folder",folder);row.remove("courseFolder");row.remove("files");row.remove("hashes")
     checkpoint();api.createFolder(folder,"캠퍼스레이더")
    }
    var course=row.optString("courseFolder")
    if(course.isBlank()||!api.exists(course)){
     checkActive();course=api.id();row.put("courseFolder",course)
     val oldFiles=row.optJSONObject("files")
     val oldHashes=row.optJSONObject("hashes")
     oldFiles?.keys()?.asSequence()?.filter{it.startsWith("과목/")}?.toList()?.forEach{
      oldFiles.remove(it);oldHashes?.remove(it)
     }
     checkpoint();api.createFolder(course,"과목",folder)
    }
    val files=row.optJSONObject("files")?:JSONObject();row.put("files",files)
    val hashes=row.optJSONObject("hashes")?:JSONObject();row.put("hashes",hashes)
    val docs=payload.getJSONObject("documents")
    val names=docs.keys().asSequence().filter{it!="캠퍼스레이더 시작.txt"}.toList()+listOf("캠퍼스레이더 시작.txt")
    // Only app-owned tracked files removed by the user's new scope are trashed.
    for(old in files.keys().asSequence().toList())if(!docs.has(old)){
     checkActive();try{api.trash(files.getString(old))}catch(e:DriveHttpFailure){if(e.status!=404)throw e};files.remove(old);hashes.remove(old);checkpoint()
    }
    var writes=0
    var complete=true
    for(name in names){
     checkActive()
     if(android.os.SystemClock.elapsedRealtime()>=deadline){complete=false;retry=true;break}
     val text=docs.getString(name);val hash=DriveApi.digest(text)
     var fid=files.optString(name)
     val present=fid.isNotBlank()&&api.exists(fid)
     if(present&&hashes.optString(name)==hash)continue
     if(writes>=25){complete=false;retry=true;break}
     if(!present){
      checkActive();fid=api.id();files.put(name,fid);hashes.remove(name);checkpoint()
      val parent=if(name.startsWith("과목/"))course else folder
      if(name.endsWith(".zip"))api.createFile(fid,name.substringAfterLast('/'),"application/zip",parent)
      else api.createText(fid,name.substringAfterLast('/'),parent)
     }
     checkActive()
     if(name.endsWith(".zip")){
      val bytes=android.util.Base64.decode(text,android.util.Base64.DEFAULT)
      api.writeBytes(fid,bytes,"application/zip")
     }else{
      api.write(fid,text)
     }
     hashes.put(name,hash);checkpoint();writes++
    }
    if(complete){val changed=row.optString("lastSnapshot")!=payload.optString("revision");row.put("lastSuccess",java.time.Instant.now().toString()).put("lastSnapshot",payload.optString("revision")).put("error","");checkpoint();DriveSyncStore.clearNote(c);if(changed)RadarData.log(c,"Drive 자동 내보내기 완료","${row.optString("email")}: 문서 ${writes}개를 갱신했어요.","app")}
    else{row.put("error","일부 자료를 갱신했어요. 다음 작업에서 이어서 전송해요.");checkpoint();RadarData.log(c,"Drive 자동 내보내기 일부 완료","${row.optString("email")}: 문서 ${writes}개를 갱신했어요. 남은 문서는 다음 작업에서 보내요.","app")}
   }catch(e:Exception){
    if(isStopped){DriveSyncStore.note(c,"Drive 전송 중단","이전 전송 작업이 취소되어 추가 요청을 멈췄어요.");return@synchronized Result.success()}
    // Disconnect, account switch and option changes invalidate old work.
    val live=DriveSyncStore.accounts(c).optJSONObject(id)
    if(live!=null&&live.optString("binding")==binding&&DriveSyncStore.epoch(c)==epoch){
     val code=if(e is DriveHttpFailure)e.status else 0
     val msg=when{
      e is DriveNeedsAuthorization||code==401->"Google 계정에 다시 연결해 주세요."
      code==403->"Drive 권한·API 설정 또는 사용량을 확인해 주세요."
      code==404->"Drive 폴더나 문서가 전송 중 사라졌어요. 다음 전송에서 다시 확인해요."
      code==429||code>=500->"Drive가 잠시 응답하지 않아요. 자동으로 다시 시도해요."
      else->"전송을 마치지 못했어요. 인터넷을 확인한 뒤 다시 전송해 주세요."
     }
     live.put("error",msg);DriveSyncStore.state(c,id,live)
     if(code==0&&e !is DriveNeedsAuthorization||code==429||code>=500||(code==401||code==404)&&runAttemptCount==0)retry=true
     RadarData.logError(c,"Drive 자동 내보내기 대기","${row.optString("email")}: $msg",e)
    }
   }
  }
  if(retry)Result.retry()else Result.success()
 }
 companion object{private val lock=Any()}
}

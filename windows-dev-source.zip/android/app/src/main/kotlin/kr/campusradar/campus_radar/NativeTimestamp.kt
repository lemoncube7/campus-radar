package kr.campusradar.campus_radar
import java.time.*
/** Legacy Flutter local timestamps had no offset; new writes use UTC. */
object NativeTimestamp {
 fun parse(value:String?, localZone:ZoneId=ZoneId.systemDefault()):Instant? {
  if(value.isNullOrBlank() || value=="null")return null
  return try {OffsetDateTime.parse(value).toInstant()} catch(_:Exception){
   try {LocalDateTime.parse(value).atZone(localZone).toInstant()}catch(_:Exception){null}
  }
 }
}

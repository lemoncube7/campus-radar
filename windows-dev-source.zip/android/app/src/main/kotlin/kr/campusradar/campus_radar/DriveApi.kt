package kr.campusradar.campus_radar

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

class DriveHttpFailure(val status:Int):Exception("Drive HTTP $status")
internal fun driveResourceExists(lookup:()->Boolean):Boolean=try{lookup()}catch(e:DriveHttpFailure){if(e.status==404)false else throw e}
/** Fixed HTTPS Google endpoints, bounded responses, no logged tokens/content. */
class DriveApi(private val token:String,private val unauthorized:()->Unit={}){
 companion object{
  const val scope="https://www.googleapis.com/auth/drive.file"
  fun digest(value:String)=MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8)).joinToString(""){"%02x".format(it)}
 }
 fun json(method:String,url:String,body:JSONObject?=null)=JSONObject(request(method,url,body?.toString()?.toByteArray(Charsets.UTF_8),"application/json; charset=UTF-8").ifBlank{"{}"})
 private fun request(method:String,url:String,body:ByteArray?,mime:String):String{
  require(url.startsWith("https://www.googleapis.com/drive/v3/")||url.startsWith("https://www.googleapis.com/upload/drive/v3/"))
  val c=URL(url).openConnection()as HttpURLConnection
  try{
   c.instanceFollowRedirects=false;c.connectTimeout=15000;c.readTimeout=25000;c.requestMethod=method;c.setRequestProperty("Authorization","Bearer $token")
   if(body!=null){c.doOutput=true;c.setRequestProperty("Content-Type",mime);c.setFixedLengthStreamingMode(body.size);c.outputStream.use{it.write(body)}}
   val status=c.responseCode
   if(status==401)unauthorized()
   if(status !in 200..299)throw DriveHttpFailure(status)
   return c.inputStream.use{input->val out=java.io.ByteArrayOutputStream();val buf=ByteArray(8192);while(true){val n=input.read(buf);if(n<0)break;require(out.size()+n<=1048576);out.write(buf,0,n)};out.toString("UTF-8")}
  }finally{c.disconnect()}
 }
 fun id():String=json("GET","https://www.googleapis.com/drive/v3/files/generateIds?count=1&space=drive&type=files").getJSONArray("ids").getString(0)
 fun createFolder(id:String,name:String,parent:String?=null){
  val m=JSONObject().put("id",id).put("name",name).put("mimeType","application/vnd.google-apps.folder")
  if(parent!=null)m.put("parents",org.json.JSONArray().put(parent))
  create(id,m)
 }
 fun createText(id:String,name:String,parent:String){
  create(id,JSONObject().put("id",id).put("name",name).put("mimeType","text/plain").put("parents",org.json.JSONArray().put(parent)))
 }
 fun write(id:String,text:String){request("PATCH","https://www.googleapis.com/upload/drive/v3/files/$id?uploadType=media",text.toByteArray(Charsets.UTF_8),"text/plain; charset=UTF-8")}
 fun trash(id:String){json("PATCH","https://www.googleapis.com/drive/v3/files/$id",JSONObject().put("trashed",true))}

 private fun create(id:String,metadata:JSONObject){
  try{json("POST","https://www.googleapis.com/drive/v3/files?fields=id",metadata)}
  catch(e:DriveHttpFailure){if(e.status!=409||!exists(id))throw e}
 }
 fun exists(id:String)=driveResourceExists{
  !json("GET","https://www.googleapis.com/drive/v3/files/$id?fields=id,trashed").getBoolean("trashed")
 }
}

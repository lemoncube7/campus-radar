package kr.campusradar.campus_radar

/** Pure layout policy, in dp, independent of a launcher's cell dimensions. */
object WidgetSizing {
 data class Tasks(val rows:Int,val padding:Int,val title:Boolean,val stamp:Boolean,val factor:Float)
 fun tasks(width:Int,height:Int,fontScale:Float=1f,showNext:Boolean=false):Tasks {
  val factor=if(height<110).85f else if(width<160).9f else 1f
  val scale=fontScale.coerceIn(.7f,1.6f)*factor
  val compact=width<210||height<180
  val title=!compact&&height>=220
  val stamp=height>=180
  val padding=if(compact)8 else 12
  val fixed=padding*2+28+(if(stamp)18 else 0)+(if(showNext)18 else 0)
  val rowHeight=(if(height<140)38 else 64)*scale
  val rows=((height-fixed)/rowHeight).toInt().coerceIn(1,4)
  return Tasks(rows,padding,title,stamp,factor)
 }
}

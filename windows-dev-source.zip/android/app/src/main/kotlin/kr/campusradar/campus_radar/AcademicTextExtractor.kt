package kr.campusradar.campus_radar
import android.content.Context
import android.graphics.pdf.PdfRenderer
import android.os.Build
import android.os.ParcelFileDescriptor
import java.io.File
object AcademicTextExtractor {
 fun extract(c:Context,path:String):Map<String,Any>{
  val file=File(path).canonicalFile
  val root=File(c.cacheDir,"campus_media").canonicalFile
  require(file.path.startsWith(root.path+File.separator)&&file.isFile&&file.length()<=10*1024*1024)
  if(Build.VERSION.SDK_INT<35)return mapOf("text" to "","note" to "PDF 텍스트 추출은 Android 15 이상에서 지원","partial" to false)
  val out=StringBuilder();var pages=0;var partial=false;var contentCharacters=0
  val deadline=System.nanoTime()+15_000_000_000L
  ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY).use{fd->PdfRenderer(fd).use{renderer->
   pages=renderer.pageCount
   for(i in 0 until minOf(pages,80)){
    if(System.nanoTime()>deadline||out.length>=200000){partial=true;break}
    out.append("\n--- ").append(i+1).append("쪽 ---\n")
    renderer.openPage(i).use{page->for(block in page.textContents){val text=block.text;contentCharacters+=text.length;if(out.length+text.length>200000){out.append(text.take((200000-out.length).coerceAtLeast(0)));partial=true;break};out.append(text).append('\n')}}
   }
   if(pages>80)partial=true
  }}
  val text=if(contentCharacters==0)"" else out.toString();return mapOf("text" to text,"note" to if(contentCharacters==0)"읽을 수 있는 텍스트 없음 · 스캔/그림 원본 확인 필요" else "PDF 텍스트만 추출 · 전체 ${pages}쪽 · 그림/배치 제외","partial" to partial)
 }
}

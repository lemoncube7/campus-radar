package kr.campusradar.campus_radar

/** Window metadata only. System UI controls do not dismiss the user's card. */
object LockWindowPolicy {
    fun suppress(packageName: String?, className: String?, ownPackage: String, hideOtherWindows: Boolean = true): Boolean {
        if (packageName.isNullOrEmpty() || packageName == ownPackage) return false
        val name = className.orEmpty().lowercase()
        if (packageName == "com.android.systemui") {
            // SystemUI also owns authentication. Hide only positively identified
            // keyguard/bouncer screens; a generic dialog may be the volume panel.
            return listOf("bouncer", "keyguardpassword", "keyguardpin", "keyguardpattern",
                "credential", "biometric").any { name.contains(it) }
        }
        if (packageName.contains("camera", ignoreCase = true)) return true
        // Incoming calls and ringing alarms must never sit under the card.
        val p = packageName.lowercase()
        if (listOf("incallui", "dialer", "telecom", "deskclock", "clockpackage", "alarm")
                .any { p.contains(it) }) return true
        return hideOtherWindows // Other overlay widgets are not authentication screens.
    }
}

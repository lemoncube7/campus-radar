package kr.campusradar.campus_radar

import java.util.concurrent.Executors

/**
 * Widget refreshes read the app database. On the broadcast (main) thread a
 * read waiting on a collection's write lock exceeded the 10 s receiver limit
 * right after an update install (ANR on APPWIDGET_UPDATE, 11/5). Updates run
 * here instead, one at a time. A broadcast's goAsync() keeps the same limit,
 * so it is not used; RemoteViews updates are allowed from any thread.
 */
object WidgetWork {
 private val worker=Executors.newSingleThreadExecutor{r->Thread(r,"radar-widget").apply{isDaemon=true}}
 fun run(block:()->Unit){worker.execute{try{block()}catch(_:Throwable){}}}
}

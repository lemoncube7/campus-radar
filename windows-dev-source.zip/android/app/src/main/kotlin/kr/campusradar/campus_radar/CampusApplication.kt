package kr.campusradar.campus_radar

import android.app.Application
import android.content.Context
import dev.fluttercommunity.workmanager.TaskDebugInfo
import dev.fluttercommunity.workmanager.TaskResult
import dev.fluttercommunity.workmanager.WorkmanagerDebug
import dev.fluttercommunity.workmanager.pigeon.TaskStatus
import org.json.JSONArray
import org.json.JSONObject

class CampusApplication : Application() {
 override fun onCreate() {
  super.onCreate()
  // A new process has no surviving Dart preparation; do not retain its old lease.
  val database=getDatabasePath("campus.db")
  if(database.exists())try{
   android.database.sqlite.SQLiteDatabase.openDatabase(database.path,null,android.database.sqlite.SQLiteDatabase.OPEN_READWRITE).use{db->
    db.execSQL("DELETE FROM meta WHERE id='drivePrepareLease'")
    // Same for the collection lease: a process killed mid-collection (app
    // update, force stop) left it for up to 10 minutes, so every new start
    // only logged "수집 대기" (device tests 11/4, builds 80/81).
    db.execSQL("DELETE FROM meta WHERE id IN ('lease','leaseOwner')")
   }
  }catch(e:Exception){RadarData.logError(this,"Drive 준비 잠금 복구 대기","이전 작업 잠금을 정리하지 못했어요.",e)}
  WorkmanagerDebug.setCurrent(object : WorkmanagerDebug() {
   override fun onTaskStatusUpdate(context: Context, taskInfo: TaskDebugInfo, status: TaskStatus, result: TaskResult?) {
    record(context, status.name, result?.duration)
    if(status == TaskStatus.COMPLETED) { RadarWidget.updateAll(context); try{DriveSyncStore.enqueue(context)}catch(_:Exception){}; Thread { RadarCalendar.sync(context) }.start() }
   }
   override fun onExceptionEncountered(context: Context, taskInfo: TaskDebugInfo?, exception: Throwable) {
    record(context, "NATIVE_ERROR:" + exception.javaClass.simpleName, null)
   }
  })
 }
 companion object {
  @Synchronized private fun record(context: Context, state: String, duration: Long?) {
   val prefs = context.getSharedPreferences("campus_background", Context.MODE_PRIVATE)
   val events = JSONArray(prefs.getString("events", "[]"))
   events.put(JSONObject().put("at", System.currentTimeMillis()).put("state", state).put("durationMs", duration))
   while (events.length() > 100) events.remove(0)
   prefs.edit().putString("events", events.toString()).apply()
  }
 }
}

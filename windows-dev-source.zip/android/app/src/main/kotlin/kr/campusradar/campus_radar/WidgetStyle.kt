package kr.campusradar.campus_radar
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.widget.RemoteViews
object WidgetStyle {
 data class Palette(val dark:Boolean,val surface:Int,val text:Int,val muted:Int,val line:Int,val primary:Int,val secondary:Int,val danger:Int)
 fun read(c:Context):Palette {
  val mode=c.getSharedPreferences("FlutterSharedPreferences",0).getString("flutter.radarTheme","system")
  val dark=mode=="dark"||(mode!="light"&&(c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES)
  val a=NativeAccentPalette.read(c)
  return if(dark)Palette(true,Color.rgb(22,32,36),Color.rgb(237,245,246),Color.rgb(167,187,192),Color.rgb(49,66,71),NativeAccentPalette.onDark(a.primary),NativeAccentPalette.onDark(a.secondary),Color.rgb(255,179,171))
  else Palette(false,Color.rgb(247,251,251),Color.rgb(23,43,47),Color.rgb(83,109,115),Color.rgb(219,231,233),a.primary,a.secondary,Color.rgb(170,48,40))
 }
 fun background(v:RemoteViews,root:Int,p:Palette){v.setInt(root,"setBackgroundResource",if(p.dark)R.drawable.widget_surface_dark else R.drawable.widget_surface_light)}
 fun blend(color:Int,surface:Int,weight:Float):Int=Color.rgb((Color.red(color)*weight+Color.red(surface)*(1-weight)).toInt(),(Color.green(color)*weight+Color.green(surface)*(1-weight)).toInt(),(Color.blue(color)*weight+Color.blue(surface)*(1-weight)).toInt())
}

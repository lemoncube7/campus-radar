package kr.campusradar.campus_radar

import android.accounts.Account
import android.app.Activity
import android.content.Context
import android.content.Intent
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import com.google.android.gms.tasks.Tasks
import io.flutter.plugin.common.MethodChannel
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Tokens stay in Google Play services and memory, never in Dart or logs. */
class DriveAuthorization(private val activity:Activity) {
 private var pending:MethodChannel.Result?=null
 private var expected:String?=null
 fun connect(email:String?,result:MethodChannel.Result){
  if(pending!=null){result.error("busy","다른 Google 연결을 마쳐 주세요.",null);return}
  pending=result;expected=email
  val builder=AuthorizationRequest.builder().setRequestedScopes(listOf(Scope(DriveApi.scope)))
  if(email!=null)builder.setAccount(Account(email,"com.google"))
  else builder.setPrompt(AuthorizationRequest.Prompt.SELECT_ACCOUNT)
  Identity.getAuthorizationClient(activity).authorize(builder.build())
   .addOnSuccessListener{a->
    if(a.hasResolution())try{activity.startIntentSenderForResult(a.pendingIntent!!.intentSender,809,null,0,0,0)}catch(e:Exception){fail("동의 화면 열기",e)}
    else finish(a)
   }.addOnFailureListener{fail("권한 요청",it)}
 }
 fun onResult(code:Int,resultCode:Int,data:Intent?):Boolean{
  if(code!=809)return false
  if(resultCode!=Activity.RESULT_OK){val r=pending;pending=null;RadarData.log(activity,"Google 연결 취소","동의 화면에서 돌아왔어요(결과 코드 $resultCode).","app");r?.error("cancelled","Google 연결을 취소했어요.",null);return true}
  try{finish(Identity.getAuthorizationClient(activity).getAuthorizationResultFromIntent(data))}catch(e:Exception){fail("동의 결과 읽기",e)}
  return true
 }
 /** Logs the failing step and cause; the user sees one stable message. */
 private fun fail(step:String,e:Throwable?){
  if(e==null)RadarData.log(activity,"Google 연결 실패","$step 단계에서 멈췄어요.","app")
  else RadarData.logError(activity,"Google 연결 실패","$step 단계에서 멈췄어요.",e)
  val r=pending;pending=null;r?.error("google_authorization","Google 연결을 마치지 못했어요. 인터넷·Google 계정과 앱의 OAuth 등록을 확인해 주세요.",null)
 }
 private fun finish(a:AuthorizationResult){
  val token=a.accessToken
  if(token.isNullOrBlank()){fail("접근 토큰 받기",null);return}
  Thread{
   try{
    val api=DriveApi(token)
    val user=api.json("GET","https://www.googleapis.com/drive/v3/about?fields=user(emailAddress,permissionId)").getJSONObject("user")
    val email=user.getString("emailAddress");val id=user.getString("permissionId")
    require(expected==null||expected==email){"selected account differs from the one being reconnected"}
    DriveSyncStore.add(activity,id,email)
    val row=DriveSyncStore.rows(activity).first{it["id"]==id}
    RadarData.log(activity,"Google 계정 연결","$email 계정의 Drive 권한을 받았어요.","app")
    activity.runOnUiThread{val r=pending;pending=null;r?.success(row)}
   }catch(e:Exception){activity.runOnUiThread{fail("Drive 계정 확인",e)}}
  }.start()
 }
 companion object {
  fun clear(c:Context,token:String){Tasks.await(Identity.getAuthorizationClient(c).clearToken(com.google.android.gms.auth.api.identity.ClearTokenRequest.builder().setToken(token).build()),10,TimeUnit.SECONDS)}
  fun token(c:Context,email:String):String{
   val r=Tasks.await(Identity.getAuthorizationClient(c).authorize(AuthorizationRequest.builder().setAccount(Account(email,"com.google")).setRequestedScopes(listOf(Scope(DriveApi.scope))).build()),30,TimeUnit.SECONDS)
   if(r.hasResolution()||r.accessToken.isNullOrBlank())throw DriveNeedsAuthorization()
   return r.accessToken!!
  }
 }
}
class DriveNeedsAuthorization:Exception()

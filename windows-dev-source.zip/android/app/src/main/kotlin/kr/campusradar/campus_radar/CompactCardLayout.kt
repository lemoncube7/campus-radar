package kr.campusradar.campus_radar
/** Keep content clear of launcher/keyguard corner masks at every size. */
object CompactCardLayout {
 fun padding(width:Int)=if(width<160)16 else 20
 /** With details hidden the clock is the only content, so a roomy card gives it more weight. */
 fun clockSize(width:Int,height:Int,details:Boolean=true)=if(width<180||height<150)22f else if(!details&&width>=200&&height>=200)40f else 32f
 fun showTasks(height:Int)=height>=320
 fun showHeading(height:Int)=height>=140
 fun showDeadline(height:Int)=height>=110
 fun showCourse(height:Int)=height>=110
 fun showRoom(height:Int)=height>=200
}

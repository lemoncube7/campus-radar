package kr.campusradar.campus_radar
import org.junit.Assert.*
import org.junit.Test
class CompactCardLayoutTest {
 @Test fun tinyHostsKeepOnlyPrimaryValue(){assertFalse(CompactCardLayout.showHeading(80));assertFalse(CompactCardLayout.showDeadline(80));assertFalse(CompactCardLayout.showCourse(90));assertTrue(CompactCardLayout.showCourse(160));assertFalse(CompactCardLayout.showRoom(180));assertTrue(CompactCardLayout.showRoom(220))}
 @Test fun smallHostRetainsCornerPadding(){assertEquals(16,CompactCardLayout.padding(140));assertEquals(20,CompactCardLayout.padding(200))}
 @Test fun smallHostReducesClockBeforeCrowding(){assertEquals(22f,CompactCardLayout.clockSize(150,160));assertEquals(22f,CompactCardLayout.clockSize(250,140));assertEquals(32f,CompactCardLayout.clockSize(250,200))}
 @Test fun clockGrowsOnlyWhenItIsTheOnlyContent(){assertEquals(40f,CompactCardLayout.clockSize(272,206,false));assertEquals(32f,CompactCardLayout.clockSize(272,206,true));assertEquals(40f,CompactCardLayout.clockSize(235,218,false));assertEquals(32f,CompactCardLayout.clockSize(190,218,false));assertEquals(22f,CompactCardLayout.clockSize(150,160,false))}
 @Test fun shortWidgetDoesNotShowLowerPriorityTaskRows(){assertFalse(CompactCardLayout.showTasks(160));assertTrue(CompactCardLayout.showTasks(330))}
}

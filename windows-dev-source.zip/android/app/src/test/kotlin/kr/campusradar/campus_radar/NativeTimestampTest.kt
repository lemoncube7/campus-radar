package kr.campusradar.campus_radar
import org.junit.Assert.*
import org.junit.Test
import java.time.*
class NativeTimestampTest {
 @Test fun utcAndOffsetReferToSameInstant(){
  assertEquals(Instant.parse("2026-11-02T08:05:00Z"),NativeTimestamp.parse("2026-11-02T17:05:00+09:00"))
  assertEquals(Instant.parse("2026-11-02T08:05:00Z"),NativeTimestamp.parse("2026-11-02T08:05:00Z"))
 }
 @Test fun legacyLocalSuccessTimestampIsReadable(){assertEquals(Instant.parse("2026-11-02T08:05:00Z"),NativeTimestamp.parse("2026-11-02T17:05:00",ZoneId.of("Asia/Seoul")))}
 @Test fun malformedAndAbsentValuesRemainUnknown(){for(v in listOf(null,"","null","not-a-date"))assertNull(NativeTimestamp.parse(v))}
}

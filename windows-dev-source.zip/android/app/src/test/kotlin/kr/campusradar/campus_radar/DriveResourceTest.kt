package kr.campusradar.campus_radar
import org.junit.Assert.*
import org.junit.Test
class DriveResourceTest {
 @Test fun existingResourceIsReused(){assertTrue(driveResourceExists{true})}
 @Test fun trashedResourceIsUnavailable(){assertFalse(driveResourceExists{false})}
 @Test fun onlyMissingResourceCanBeCreated(){assertFalse(driveResourceExists{throw DriveHttpFailure(404)})}
 @Test fun permissionFailureCannotTriggerDuplicateCreation(){val e=assertThrows(DriveHttpFailure::class.java){driveResourceExists{throw DriveHttpFailure(403)}};assertEquals(403,e.status)}
 @Test fun networkFailureCannotTriggerDuplicateCreation(){assertThrows(java.io.IOException::class.java){driveResourceExists{throw java.io.IOException()}}}
}

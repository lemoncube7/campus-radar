# Claude 작업 기록 (2026-11-03)

Codex가 이어서 작업할 때 참고할 변경 기록이에요. 기준점은 `78b2355`(0.5.10-dev.9+71 원본 그대로)이고, 그 뒤 커밋은 모두 Claude가 만들었어요. 커밋마다 메시지에 이유를 적어 두었으니, 자세한 내용은 `git log 78b2355..HEAD`로 확인하세요.

## 먼저 알아둘 것 (작업 방식이 바뀐 부분)

1. **git으로 관리해요.** `outputs/campus-radar/`가 git 저장소가 됐어요. `core.autocrlf=false`예요. 파일마다 CRLF/LF가 섞여 있으니 **원래 줄바꿈을 유지**해 주세요. 줄바꿈이 바뀌면 diff가 파일 전체로 커져요.
2. **`lib/`가 기능별 폴더로 나뉘었어요.** `main.dart`만 `lib/`에 있어요. 나머지는 `core/ campus/ session/ courses/ tasks/ notices/ ai/ schedule/ home/ settings/ navigation/ export/ updates/ platform/` 안에 있어요. 파일 이름은 그대로예요. 어디로 갔는지는 `ARCHITECTURE.md` 맨 위의 "Folder layout"을 보거나 `git log --follow -- lib/<폴더>/<파일>`로 확인하세요.
3. **import는 `package:campus_radar/<폴더>/<파일>.dart` 형식**이에요. 새 파일도 이 형식으로 써 주세요.
4. **저장소 키는 상수로 써요.** `lib/core/storage_keys.dart`의 `MetaKey`(Store.meta)와 `PrefKey`(SharedPreferences)를 쓰세요. 엔터티별 키는 `MetaKey.aiQueue(id)` 같은 함수예요. 키 값(문자열)은 바꾸지 않았으니 기존 데이터와 네이티브 위젯은 그대로 호환돼요.
5. **문구 규칙:** 화면 문구는 해요체예요. 용어집은 아래와 같아요.
   - 하루 요약 (데일리/오늘/매일 요약 아님)
   - 마감 (기한 아님)
   - 숨기기·숨김 (목록에서 빼기, "제외" 아님)
   - 검토함 (AI 일정 검토), 앱 일정 (앱에 저장한 일정)
   - 자동 승인 (자동 정리 아님)
   - 정식/개발 버전 (모드·채널·릴리스 아님)
   - 동기화는 캘린더·클라우드에만 쓰고, 학교 수집은 새로고침·수집이라고 해요.
   - AI 프롬프트(모델에게 보내는 지시문)는 바꾸지 않았어요.
6. **회귀 테스트:** 버그마다 회귀 테스트를 `test/regression/`에 넣었어요. 전체 테스트는 441개가 통과하고 `flutter analyze` 경고는 0개예요.
7. **⚠️ 네이티브 코드는 빌드 확인을 못 했어요.** Android(Kotlin)·iOS(Swift)는 이 환경에 빌드 도구가 없어서 컴파일하지 못했어요. 다음 빌드 때 꼭 확인해 주세요. 대상 파일은 아래와 같아요.
   - `MainActivity.kt`, `RadarCalendar.kt`, `RadarWidget.kt`, `TimetableReceiver.kt`, `LockWindowPolicy.kt`(+테스트)
   - `AppDelegate.swift`, `RadarWidgets.swift`

## 동작이 바뀐 것 (버그 수정)

조사 보고서는 `outputs/research/bug-hunt-2026-11-03/`에 있어요.

| 영역 | 변경 |
|---|---|
| 개인정보 | 자동 분석을 다시 켜거나 범위를 바꿔도 **분석 제외한 공지는 대기열에 다시 들어가지 않아요** (`AiStateRepository.resetQueueKeepingUserDecisions`). |
| 개인정보 | `aiTimetableContext`가 `personal:` 슬롯을 빼요. 개인 일정이 클라우드·AI 채팅으로 나가지 않아요. |
| 개인정보 | 키를 둔 채 전송 동의를 해제하면 공지·채팅 동의가 철회되고 자동화가 꺼져요. 진단 로그 가림 처리에 `usr_pwd`, JSON `password`, `JSESSIONID`를 추가했어요. |
| AI 날짜 | `evidenceClocks()`를 새로 만들었어요. 자정까지/24:00은 23:59, 저녁·밤·새벽·아침·낮, "3시 반"을 읽고, "2시간" 같은 기간은 시각으로 보지 않아요. |
| AI 날짜 | sourceIds가 없는 근거도 날짜·시각을 검증해요. 연도가 없는 날짜는 게시일 기준 -60일~+300일 안이어야 해요. |
| AI 날짜 | 한 문장에 날짜가 여러 개면 각 후보에 서로 다른 키를 줘요(`distinctCandidateKey`). 수동 추가 후보도 각자 고유 키를 받아요. |
| 동시성 | 공지 분석에 DB 잠금(`claimNoticeAnalysis`, 메타 키 `aiAnalyzing:<id>`)을 걸어 앱 화면과 백그라운드가 동시에 분석하지 않아요. 2차 보정 요청은 잠금을 놓지 않고 갱신해요(`renewAiRequest`). |
| 알림 | `reconcile()`가 SharedPreferences를 `reload()`한 뒤 읽어요. 백그라운드가 예약한 알림도 이제 취소돼요. |
| 알림·개수 | `CampusItem.openTask`를 새로 만들었어요. 상태가 unknown인 퀴즈·시험·토론·팀플과 상세를 못 읽은 과제도 "할 일"로 봐요. 홈 화면, 하루 요약, 위젯(Android 포함), 마감 알림에 모두 적용했어요. |
| 수집 | 학교 로그인이 거절되면 `schoolLoginRejectedEpoch`를 기록하고, 사용자가 포털을 다시 연결하거나 앱을 직접 열 때까지 자동 재로그인을 멈춰요. |
| 계정 | 로그아웃 순서를 바꿨어요. 수집 데이터를 먼저 지우고, 그다음 알림을 취소하고, 로그인 정보는 마지막에 지워요. 데이터 삭제가 실패하면 로그인 정보를 지우지 않아요. 동기화는 쓰기 단계마다 세션을 다시 확인해요. 검토함 결정·실행 취소와 일정 저장은 로그아웃 후에 동작하지 않아요(`SessionMark`). |
| 세션 탐색 | 인증이 끊긴 뒤 영원히 멈춰 있던 문제를 고쳤어요. 탐색 중에 저장해도 학습한 목표값을 유지하고, 끌 때 저장소 오류가 나도 꺼져요. |
| 표시 | 링크 안 이미지가 제자리에 보여요. 첨부 파일명은 150바이트 이하로 자르고, 외부 앱으로 열 때는 원래 이름으로 복사해서 넘겨요(`campus_media/open/`). |
| 표시 | 강의계획서 파싱은 첫 시각이 나온 뒤에만 다음 섹션 단어를 찾아요. 강의실 이름의 제어문자는 공백으로 바꾸고, 휴강 기간은 1년까지만 허용해요. 캘린더는 백업 휴강 데이터를 읽고, 같은 이름 분반 안내도 보여줘요. |
| 표시 | 숨김 개수가 숨김 목록과 일치해요. 마감 없는 항목도 섹션별로 묶어 정렬해요. "할 일 아님" 항목도 복구할 수 있고, 숨기기를 실행 취소해도 자동 숨김 대상에서 빠지지 않아요. |
| 기타 | 채팅 자료는 진행 중·다가오는 항목을 먼저 넣어요. 깨진 대화 기록은 건너뛰고, 과목 약자는 한 번에 치환해요. 공지 목록은 깨진 대기열 행이 있어도 열려요. Windows 업데이터는 리다이렉트마다 HTTPS를 확인하고 전체 시간 제한 10분을 둬요. 지난 날짜·마감용 메타 키는 7일 뒤 정리해요(`Store.pruneStaleMeta`). |
| 네이티브 | `openCampus`가 null 값 때문에 크래시하지 않아요. 사용자가 편집한 캘린더 일정은 자동 동기화가 덮어쓰지 않아요(`manual:<key>` / `radarEventManual:<key>`). 잠금화면 카드는 전화·알람 화면에서 숨겨지고, 늦게 도착한 심야 수업 알람도 버리지 않아요. iOS 위젯은 수집 전이면 "기록 없음"을 보여줘요. |

**의도된 동작으로 보고 그대로 둔 것:**
- 네트워크 오류 뒤 AI 분석을 자동으로 재시도하지 않는 것(기존 테스트에 명시된 설계)
- 하루 요약 알림이 기기 시간대를 따르는 것
- 세션 탐색에서 시작 시각과 종료 시각이 같으면 하루 종일로 보는 것

## 화면·구조 변경

- **하루 요약 화면:** 마감이 0개일 때 "다음 마감"을 보여줘요. AI가 꺼져 있으면 "AI 요약"을 한 줄짜리 카드로 보여주고, 겹치던 테두리를 없앴어요.
- **설정 화면:** "ChatGPT 연결" 묶음을 새로 만들었어요(ChatGPT 내보내기, 서버 플러그인). 세션 탐색은 "기록·지원" 맨 아래의 개발자 옵션으로 옮겼어요.
- **대시보드:** `main.dart`의 목록 필터 10개는 `tasks/dashboard_model.dart`의 `TaskFilter`로 옮겼고, 홈 개수 계산은 `DashboardCounts`로 분리했어요. 배터리 경고는 `campus/power_status.dart`(`PowerStatus`)로 옮겼어요.
- **동기화 함수:** `synchronize()`에서 `keepDetailOnTaskWarnings`, `keepMaterialsOnResourceWarnings`, `logReceivedItems`를 분리했어요.
- **빈 catch 정리:** 빈 `catch (_) {}`는 로그를 남기거나, 무시해도 되는 이유를 주석으로 적어 두었어요.

## 커밋되지 않은 파일

`NEXT-UPDATE.md`, `SUBMISSION-2026-11-05.md`, `docs/`는 Claude가 작업하는 동안 따로 바뀐 파일이라 건드리지 않았고 커밋하지도 않았어요.

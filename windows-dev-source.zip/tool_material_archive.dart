import 'dart:io';import 'dart:convert';import 'package:campus_radar/campus.dart';
Future<void> main()async{final c=CampusClient();try{c.restoreSession(jsonDecode(File('../../outputs/tests/materials/private/session.json').readAsStringSync()));final s=await c.request(Uri.parse('${CampusClient.learning}/js/page/std/learningElements/archive/view-d10bebdcf5c158996866a2a889df52fc.js'));File('../../outputs/tests/materials/private/archiveView.js').writeAsStringSync(s);print('Archive script saved');}finally{c.close();}}


# Campus Radar source boundaries

## Folder layout (since 2026-11-03)

`lib/main.dart` is the entry point; every other file lives in a feature folder
and is imported as `package:campus_radar/<folder>/<file>.dart`. File names are
unique across folders, and the rules below still refer to files by name.

- `core/`: storage (`app_storage`, `storage_keys`), credentials, logging, native
  bridge/contract, notifications, session scope, network/time helpers, small UI
  helpers. Must not depend on feature folders' screens or `services.dart`.
- `campus/`: school HTTP client, models, media cache, syllabus loading, sync
  orchestration (`services.dart`), logout policy (`account_service.dart`).
- `session/`: school session lifetime observation and the exploration test.
- `courses/`, `tasks/`, `notices/`, `home/`, `settings/`: feature screens and
  their repositories/models (`tasks/dashboard_model.dart` holds the list filter
  and home counts).
- `ai/`: AI protocol, generation, transport, queue/automation, chat, review
  inbox.
- `schedule/`: timetable, cancellations, schedule calendar, calendar drafts.
- `navigation/`, `export/` (ChatGPT export/cloud), `updates/`,
  `platform/` (Windows/iOS specific).

Storage key names live in `core/storage_keys.dart` (`MetaKey`, `PrefKey`). Use
the constants for new keys; values are wire names and must not change without
a migration (native widgets read some SharedPreferences keys).

## Current ownership

- `main.dart`: app startup and dashboard composition. Other feature modules must not import this entry point.
- `app_storage.dart`: SQLite store; persisted schema and existing invalidation behavior are retained.
- `app_credentials.dart`, `native_bridge.dart`, `notification_gateway.dart`: platform infrastructure entry points.
- `campus_models.dart`: task/notice models and availability/deadline rules; import this instead of the HTTP client when only using models.
- `campus.dart`: school HTTP/API client and transport errors.
- `session_scope.dart`: session generation and cancellation guards; must not depend on the sync coordinator or feature pages.
- `services.dart`: collection/background/notification orchestration. Import it only for those operations.
- `account_service.dart`: logout cleanup policy without widget/dialog dependencies.
- `update_download.dart`: bounded update file download without widget state.
- `course_catalog.dart`, `course_labels.dart`, `course_aliases.dart`: catalog authority, display labels, persistence/linked title updates respectively.
- `task_presentation.dart`, `ui_refresh.dart`: render inputs without storage/network/feature-page dependencies.
- `today_classes_card.dart`: feature card that intentionally reads timetable data and opens the timetable page.
- `navigation_key.dart`: shared Navigator key without concrete page imports.

## Constraints

Run `flutter test` and `flutter analyze`. `test/architecture_boundaries_test.dart` prevents foundation-to-screen/coordinator references and imports of main from features. Preserve the database schema, secure-storage options, platform channel and payload names during structural refactoring.

## Follow-up structure

- `ai_protocol.dart`, `ai_timetable_rules.dart`: pure AI schema, grounding and time rules; no IO, storage or widgets.
- `ai_generation.dart`: injected transport and one corrective attempt; no persistence or HTTP client.
- `ai_transport.dart`, `notice_ai_service.dart`: guarded HTTP and notice/cache orchestration respectively.
- `ai_state_models.dart`, `ai_state_repository.dart`: typed legacy JSON adapters and durable queue/decision keys. Unknown fields and missing defaults survive round trips.
- `ai_inbox_repository.dart`: read-only inbox joins, stale confirmed record retention and cache deduplication.
- Feature pages have separate files. Cross-feature navigation uses `navigation_contract.dart`; `app_router.dart` constructs the concrete destination.
- `native_contract.dart`: wire method names. Keep strings and payloads compatible with Kotlin/Swift/desktop handlers.
- `syllabus_loader.dart`: shared trusted-host, timeout and body validation policy; caller retains account/session and persistence guards.
- New AI settings use `Store.setAiSetting`; task exclusion uses `Store.setTaskExcluded`. The legacy `setMeta` path retains policy side effects for compatibility.

`maintenance_contracts_test.dart` prevents cycles across all local Dart files and IO dependencies from pure AI layers, and verifies storage/wire compatibility. Current graph has no cycles.

Some dashboard/workflow state and UI JSON maps remain; native source formatting/large handlers are unchanged. These are recorded in `../research/architecture-next/report.md` rather than treated as completed migrations.

## Automatic schedule approval

- `ai_approval_policy.dart` is pure: eligibility, review prompt and strict response parsing.
- `ai_auto_approval.dart` owns optional second review, saved-candidate processing, decision preservation and calendar forwarding.
- `ai_request_budget.dart` owns the shared request lease and daily accounting for extraction and approval. Import directly for new callers; notice service re-export remains for compatibility.
- Automatic approval defaults off and requires the existing notice-transfer consent plus an explicit setting. Changing this setting rotates the session epoch.
- Approved schedules reuse `confirmAiCandidate` and `calendarWindow`; do not create another calendar time-window implementation.
- `dashboard_repository.dart` reads the dashboard snapshot without owning authentication or collection.

`ai_auto_approval_test.dart` uses synthetic notices and injected transports. Do not turn these tests into live-provider requests.

## 0.5.0 information architecture

- Root sections are Today / Schedule / Courses / Settings. Existing task filter state remains in Dashboard.
- `schedule_workspace.dart` composes the existing task view, month calendar, timetable and shared review view.
- `schedule_repository.dart` joins tasks, confirmed notice schedules and class slots without changing persisted data.
- `ai_inbox_page.dart` is the common schedule status/action renderer. Source analysis scopes it by noticeId; other entries may scope by candidateId. Never introduce a second confirmation renderer that ignores stored decisions.
- `home_navigation.dart` carries root requests without importing main; notification/widget navigation uses the same root task destination.
- `notification_settings_page.dart` and `widget_settings_page.dart` group existing settings; policy values remain compatible.
- `CalendarSettingsPage` owns the AI calendar destination preference, while approval enablement stays in AI settings.

## Android Drive automatic export (0.5.11-dev.1)

- `lib/export/drive_connection_page.dart`: opt-in, per-Google-account configuration and recovery UI. Existing cloud server settings stay ChatGPT-only.
- `lib/export/drive_sync.dart`: account-scoped bounded snapshot preparation, stable revision, separate preparation lease, optional local attachment extraction. Collection and root reload trigger preparation; no credentials are exported.
- `DriveAuthorization.kt`: Google Play services authorization. Access tokens stay native and transient; SDK holds the authorization grant.
- `DriveSyncWorker.kt`: independent account state, private ordinary Drive folders, file-ID/hash checkpointing, live account/epoch/binding checks, periodic/network-constrained retries.
- `DriveApi.kt`: fixed HTTPS Google endpoints, no redirects or response-body logging.
- Native account configuration is mirrored to `drive-targets-v1.json`; Dart atomically prepares `drive-export-v1.json`. This bridge works when Flutter background workers have no Activity method channel.
- Keep `sessionEpoch`, account hash and connection binding checks on every outbound path. Do not replace them with a UI-only consent flag. Disconnect stops future work and leaves existing Drive files; scope reduction trashes only tracked app-owned files. A request already accepted by Google cannot be recalled.
- Google registration and automated tests do not prove account consent, background upload, or each AI's Drive retrieval. See `docs/UPDATE-0.5.11-dev.1.md`.

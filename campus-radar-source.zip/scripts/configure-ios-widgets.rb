require 'xcodeproj'
require 'fileutils'
root = File.expand_path('../ios', __dir__)
path = File.join(root, 'Runner.xcodeproj')
project = Xcodeproj::Project.open(path)
runner = project.targets.find { |t| t.name == 'Runner' }
extension = project.targets.find { |t| t.name == 'RadarWidgets' } || project.new_target(:app_extension, 'RadarWidgets', :ios, '16.0')
group = project.main_group.find_subpath('RadarWidgets', true)
group.set_source_tree('<group>'); group.set_path('RadarWidgets')
widget = group.files.find { |f| f.path == 'RadarWidgets.swift' } || group.new_file('RadarWidgets.swift')
shared = project.main_group.files.find { |f| f.path == 'RadarShared.swift' } || project.main_group.new_file('RadarShared.swift')
extension.source_build_phase.add_file_reference(widget, true)
extension.source_build_phase.add_file_reference(shared, true)
runner.source_build_phase.add_file_reference(shared, true)
ent = {'com.apple.security.application-groups' => ['group.kr.campusradar.campusradar']}
Xcodeproj::Plist.write_to_path(ent, File.join(root, 'Runner', 'Runner.entitlements'))
Xcodeproj::Plist.write_to_path(ent, File.join(root, 'RadarWidgets', 'RadarWidgets.entitlements'))
widget_info = {
  'CFBundleDisplayName'=>'Campus Radar Widgets', 'CFBundleIdentifier'=>'$(PRODUCT_BUNDLE_IDENTIFIER)',
  'CFBundleExecutable'=>'$(EXECUTABLE_NAME)', 'CFBundleName'=>'$(PRODUCT_NAME)', 'CFBundlePackageType'=>'XPC!',
  'CFBundleShortVersionString'=>'$(MARKETING_VERSION)', 'CFBundleVersion'=>'$(CURRENT_PROJECT_VERSION)',
  'NSExtension'=>{'NSExtensionPointIdentifier'=>'com.apple.widgetkit-extension'}
}
Xcodeproj::Plist.write_to_path(widget_info, File.join(root, 'RadarWidgets', 'Info.plist'))
runner.build_configurations.each { |c| c.build_settings['CODE_SIGN_ENTITLEMENTS'] = 'Runner/Runner.entitlements' }
extension.build_configurations.each do |c|
  c.build_settings.merge!({'INFOPLIST_FILE'=>'RadarWidgets/Info.plist', 'PRODUCT_BUNDLE_IDENTIFIER'=>'kr.campusradar.campusradar.RadarWidgets',
    'SWIFT_VERSION'=>'5.0', 'IPHONEOS_DEPLOYMENT_TARGET'=>'16.0', 'TARGETED_DEVICE_FAMILY'=>'1,2',
    'SKIP_INSTALL'=>'YES', 'APPLICATION_EXTENSION_API_ONLY'=>'YES', 'CODE_SIGN_ENTITLEMENTS'=>'RadarWidgets/RadarWidgets.entitlements',
    'MARKETING_VERSION'=>'0.5.2', 'CURRENT_PROJECT_VERSION'=>'38', 'GENERATE_INFOPLIST_FILE'=>'NO'})
end
runner.add_dependency(extension) unless runner.dependencies.any? { |d| d.target == extension }
embed = runner.copy_files_build_phases.find { |p| p.name == 'Embed App Extensions' } || runner.new_copy_files_build_phase('Embed App Extensions')
embed.dst_subfolder_spec = '13'
embed.add_file_reference(extension.product_reference, true)
# Embed before Flutter's thin-binary script to avoid dependency cycles.
runner.build_phases.delete(embed)
runner.build_phases.insert(0, embed)
project.save

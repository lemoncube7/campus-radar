#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
flutter pub get
flutter analyze
flutter test
flutter build ios --release --no-codesign
mkdir -p build/ios/altstore/Payload
cp -R build/ios/iphoneos/Runner.app build/ios/altstore/Payload/
cd build/ios/altstore
zip -qry campus-radar.ipa Payload
shasum -a 256 campus-radar.ipa > campus-radar.ipa.sha256
echo "Unsigned IPA ready for AltStore Classic: $PWD/campus-radar.ipa"

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
flutter pub get
# Analyze the app only: the repo root keeps old tool_*.dart probes that do not compile.
flutter analyze --no-fatal-infos lib test
flutter test
export IOS_VERSION="${IOS_VERSION:-0.6.6}"
export IOS_BUILD="${IOS_BUILD:-92}"
ruby scripts/configure-ios-widgets.rb
# Drive on iPhone needs the iOS OAuth client (Google Cloud console). Without
# it the build still works and the Drive menu stays hidden.
GOOGLE_IOS_CLIENT_ID="${GOOGLE_IOS_CLIENT_ID:-1080133684655-s1cfphi5bqrtm451u0phntn4dg2q2ueh.apps.googleusercontent.com}"
if [ -n "$GOOGLE_IOS_CLIENT_ID" ]; then
  SCHEME="com.googleusercontent.apps.${GOOGLE_IOS_CLIENT_ID%%.apps.googleusercontent.com}"
  # Keep the app's own campusradar:// scheme; add Google's redirect scheme.
  if ! /usr/libexec/PlistBuddy -c "Print :CFBundleURLTypes" ios/Runner/Info.plist | grep -q "$SCHEME"; then
    /usr/libexec/PlistBuddy -c "Add :CFBundleURLTypes:0:CFBundleURLSchemes: string $SCHEME" ios/Runner/Info.plist
  fi
  /usr/libexec/PlistBuddy -c "Delete :GIDClientID" ios/Runner/Info.plist 2>/dev/null || true
  /usr/libexec/PlistBuddy -c "Add :GIDClientID string $GOOGLE_IOS_CLIENT_ID" ios/Runner/Info.plist
fi
flutter build ios --release --no-codesign --dart-define=RELEASE_CHANNEL=stable \
  --build-name="$IOS_VERSION" --build-number="$IOS_BUILD" \
  --dart-define=APP_VERSION="$IOS_VERSION" --dart-define=APP_BUILD="$IOS_BUILD" \
  --dart-define=GOOGLE_IOS_CLIENT_ID="$GOOGLE_IOS_CLIENT_ID"
# Preserve requested App Group entitlements for AltStore to inspect and remap.
# These ad-hoc signatures are replaced by the user's AltStore signing identity.
codesign --force --sign - --entitlements ios/RadarWidgets/RadarWidgets.entitlements build/ios/iphoneos/Runner.app/PlugIns/RadarWidgets.appex
codesign --force --sign - --entitlements ios/Runner/Runner.entitlements build/ios/iphoneos/Runner.app
mkdir -p build/ios/altstore/Payload
cp -R build/ios/iphoneos/Runner.app build/ios/altstore/Payload/
cd build/ios/altstore
zip -qry campus-radar.ipa Payload
shasum -a 256 campus-radar.ipa > campus-radar.ipa.sha256
echo "Unsigned IPA ready for AltStore Classic: $PWD/campus-radar.ipa"


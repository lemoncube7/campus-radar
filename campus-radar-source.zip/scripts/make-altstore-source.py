"""Generate release metadata from the actual unsigned IPA, never guessed size/hash."""
import datetime
import hashlib
import json
import pathlib
import plistlib
import sys
import zipfile

ipa = pathlib.Path(sys.argv[1])
destination = pathlib.Path(sys.argv[2])
asset_base = sys.argv[3].rstrip('/')
with zipfile.ZipFile(ipa) as archive:
    info = plistlib.loads(archive.read('Payload/Runner.app/Info.plist'))
assert info['CFBundleIdentifier'] == 'kr.campusradar.campusradar'
version = {
    'version': info['CFBundleShortVersionString'],
    'buildVersion': info['CFBundleVersion'],
    'date': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'downloadURL': asset_base + '/campus-radar.ipa',
    'size': ipa.stat().st_size,
    'minOSVersion': info.get('MinimumOSVersion', '14.0'),
    'localizedDescription': 'iPhone 초기 프로토타입. 실제 기기 검증 전 테스트 배포입니다.',
}
source = {
    'name': '캠퍼스레이더 테스트',
    'identifier': 'kr.campusradar.source',
    'subtitle': '충남대 과제·콘텐츠 알림',
    'website': 'https://github.com/lemoncube7/campus-radar',
    'apps': [{
        'name': '캠퍼스레이더',
        'bundleIdentifier': info['CFBundleIdentifier'],
        'developerName': 'Campus Radar',
        'localizedDescription': '계정은 기기 Keychain에 저장합니다. 기기에서 사이버캠퍼스로 직접 로그인해 수집합니다. iOS 백그라운드 확인은 실행 시각이 보장되지 않습니다. 앱에서 목록 제외·복구와 마감 알림을 제공합니다.',
        'iconURL': asset_base + '/icon.png',
        'tintColor': '3448AE',
        'versions': [version],
        'appPermissions': {'entitlements': [], 'privacy': {}},
    }],
    'news': [],
}
destination.write_text(json.dumps(source, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
destination.with_name('ios-latest.json').write_text(json.dumps({
    'versionCode': int(info['CFBundleVersion']),
    'versionName': info['CFBundleShortVersionString'],
    'ipaUrl': version['downloadURL'],
    'sha256': hashlib.sha256(ipa.read_bytes()).hexdigest(),
    'sourceUrl': asset_base + '/altstore-source.json',
}, indent=2) + '\n', encoding='utf-8')

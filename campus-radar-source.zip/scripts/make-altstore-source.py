"""Generate release metadata from the actual unsigned IPA, never guessed size/hash."""
import datetime
import hashlib
import json
import os
import pathlib
import plistlib
import sys
import zipfile
import struct


def signed_entitlements(data):
    """Read the actual ad-hoc signature retained for AltStore re-signing."""
    if data[:4] == b'\xca\xfe\xba\xbe':
        count = struct.unpack_from('>I', data, 4)[0]
        values = set()
        for n in range(count):
            offset, length = struct.unpack_from('>II', data, 8 + n * 20 + 8)
            values.update(signed_entitlements(data[offset:offset + length]))
        return values
    if data[:4] != b'\xcf\xfa\xed\xfe':
        raise ValueError('Expected a signed arm64 Mach-O executable')
    count = struct.unpack_from('<I', data, 16)[0]
    position = 32
    for _ in range(count):
        command, size = struct.unpack_from('<II', data, position)
        if command == 0x1d:
            offset, length = struct.unpack_from('<II', data, position + 8)
            signature = data[offset:offset + length]
            _, _, entries = struct.unpack_from('>III', signature)
            for n in range(entries):
                kind, location = struct.unpack_from('>II', signature, 12 + n * 8)
                if kind == 5:
                    _, length = struct.unpack_from('>II', signature, location)
                    return set(plistlib.loads(signature[location + 8:location + length]))
            return set()
        position += size
    raise ValueError('Missing ad-hoc code signature')

ipa = pathlib.Path(sys.argv[1])
destination = pathlib.Path(sys.argv[2])
asset_base = sys.argv[3].rstrip('/')
with zipfile.ZipFile(ipa) as archive:
    info = plistlib.loads(archive.read('Payload/Runner.app/Info.plist'))
    entitlements = set()
    for name in archive.namelist():
        if name == 'Payload/Runner.app/Info.plist' or name.endswith('.appex/Info.plist'):
            bundle = plistlib.loads(archive.read(name))
            executable = name.removesuffix('Info.plist') + bundle['CFBundleExecutable']
            entitlements.update(signed_entitlements(archive.read(executable)))
    entitlements -= {'application-identifier', 'com.apple.developer.team-identifier'}
assert info['CFBundleIdentifier'] == 'kr.campusradar.campusradar'
version = {
    'version': info['CFBundleShortVersionString'],
    'buildVersion': info['CFBundleVersion'],
    'date': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'downloadURL': asset_base + '/campus-radar.ipa',
    'size': ipa.stat().st_size,
    'minOSVersion': info.get('MinimumOSVersion', '14.0'),
    # Release notes come from the workflow (IOS_RELEASE_NOTES) so a new build
    # never ships an older version's text.
    'localizedDescription': os.environ.get('IOS_RELEASE_NOTES', '').strip()
    or f"{info['CFBundleShortVersionString']} ({info['CFBundleVersion']}) 테스트 빌드. 실제 iPhone 설치·알림·위젯·재서명은 체크리스트로 확인해 주세요.",
}
# The same AltStore-format source is read by SideStore (installed with iloader)
# and AltStore Classic; both re-sign the unsigned IPA with the user's Apple ID.
source = {
    'name': '캠퍼스레이더 테스트',
    'identifier': 'kr.campusradar.source',
    'subtitle': '충남대 과제·콘텐츠 알림',
    'description': '캠퍼스레이더 iPhone 소규모 테스트 배포용 소스예요. SideStore 또는 AltStore Classic에 추가해 설치·업데이트해요.',
    'website': 'https://github.com/lemoncube7/campus-radar',
    'apps': [{
        'name': '캠퍼스레이더',
        'bundleIdentifier': info['CFBundleIdentifier'],
        'developerName': 'Campus Radar',
        'localizedDescription': '계정은 기기 Keychain에 저장합니다. 기기에서 사이버캠퍼스로 직접 로그인해 수집합니다. iOS 백그라운드 확인은 실행 시각이 보장되지 않습니다. 새 화면·공지·활동 로그·마감 알림·캘린더 전송을 제공합니다. 선택한 경우 공지와 과제 정보를 개인 키로 Google Gemini에 전송합니다. AI 대기열은 앱 사용 중 진행합니다.',
        'iconURL': asset_base + '/icon.png',
        'tintColor': '197E7B',
        'versions': [version],
        'appPermissions': {'entitlements': sorted(entitlements), 'privacy': {k:v for k,v in info.items() if k.endswith('UsageDescription')}},
    }],
    'news': [],
}
destination.write_text(json.dumps(source, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
destination.with_name('ios-latest.json').write_text(json.dumps({
    'versionCode': int(info['CFBundleVersion']),
    'versionName': info['CFBundleShortVersionString'],
    'ipaUrl': version['downloadURL'],
    'sha256': hashlib.sha256(ipa.read_bytes()).hexdigest(),
    'sourceUrl': asset_base + '/altstore-source.json',
}, indent=2) + '\n', encoding='utf-8')

"""Package the complete Windows runtime, not only its EXE."""
from pathlib import Path
import os,json,re,hashlib,zipfile,shutil,urllib.parse,urllib.request

root=Path(__file__).resolve().parent.parent
release=root/'build/windows/x64/runner/Release'
assert (release/'campus_radar.exe').is_file()
config=json.loads((root/'.dart_tool/package_config.json').read_text())
sql=next(p for p in config['packages'] if p['name']=='sqflite_common_ffi')
uri=sql['rootUri']
package=Path(urllib.request.url2pathname(urllib.parse.urlparse(uri).path)) if uri.startswith('file:') else (root/'.dart_tool'/uri).resolve()
# sqflite_common_ffi < 2.4 shipped sqlite3.dll; newer sqlite3 (3.x) builds it as
# a native asset into build/native_assets/windows. Use whichever exists.
for src in (package/'lib/src/windows/sqlite3.dll',root/'build/native_assets/windows/sqlite3.dll'):
 if src.is_file():
  shutil.copy2(src,release/'sqlite3.dll');break
assert (release/'sqlite3.dll').is_file(), 'sqlite3.dll missing from portable package'
vc=Path(os.environ.get('VCToolsRedistDir',r'C:/Program Files/Microsoft Visual Studio/2022/Enterprise/VC/Redist/MSVC'))
candidates=list(vc.rglob('x64/Microsoft.VC*.CRT/vcruntime140.dll'))
if candidates:
 for f in candidates[-1].parent.glob('*.dll'):shutil.copy2(f,release/f.name)
assert (release/'vcruntime140.dll').is_file(), 'VC runtime missing from portable package'
assert (release/'msvcp140.dll').is_file(), 'C++ runtime missing from portable package'
text=(root/'pubspec.yaml').read_text(encoding='utf-8')
m=re.search(r'^version:\s*([0-9.]+)\+(\d+)',text,re.M);assert m
version,build=m.group(1),int(m.group(2))
metadata={'versionName':version,'versionCode':build,'platform':'windows','architecture':'x64'}
(release/'windows-version.json').write_text(json.dumps(metadata,indent=2)+'\n')
shutil.copy2(root/'WINDOWS-README.md',release/'README-WINDOWS.txt')
out=root/'build/windows/dist';out.mkdir(parents=True,exist_ok=True)
target=out/'campus-radar-windows.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(release.rglob('*')):
  if f.is_file():z.write(f,f.relative_to(release).as_posix())
manifest={**metadata,'zipUrl':f'https://github.com/lemoncube7/campus-radar/releases/download/windows-v{version}/campus-radar-windows.zip','sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'bytes':target.stat().st_size}
(out/'windows.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Windows package ready:',version,build,target.stat().st_size,manifest['sha256'])

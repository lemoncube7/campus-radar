// ignore_for_file: avoid_print
import 'dart:io';
import 'package:campus_radar/campus.dart';
Future<void> main() async {
 final lines=await File('../../login.txt').readAsLines();
 final id=lines[0].replaceFirst(RegExp(r'^\s*(id|아이디)\s*[:=]\s*',caseSensitive:false),'').trim();
 final pw=lines[1].replaceFirst(RegExp(r'^\s*(pw|password|비밀번호)\s*[:=]\s*',caseSensitive:false),'');
 final client=CampusClient();
 try{await client.login(id,pw);final list=await client.fetchItems();
 print('Login: success');
 for(final type in ['LR','LV']){final items=list.where((i)=>i.type==type).toList();print('$type total=${items.length} done=${items.where((i)=>i.done).length} pending=${items.where((i)=>i.status=="pending").length} unknown=${items.where((i)=>i.status=="unknown").length} due=${items.where((i)=>i.due!=null).length}');}
 }catch(e){print(e is CampusException?e.message:'Live test failed (${e.runtimeType})');exitCode=1;}finally{client.close();}
}



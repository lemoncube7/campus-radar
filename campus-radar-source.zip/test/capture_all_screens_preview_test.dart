import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/courses/mobile_courses_view.dart';
import 'package:campus_radar/tasks/mobile_tasks_view.dart';

void main() {
  final hasMalgun = File('C:/Windows/Fonts/malgun.ttf').existsSync();

  group(
    'Capture mobile tasks and courses preview group',
    skip: !hasMalgun ? 'Windows font (C:/Windows/Fonts/malgun.ttf) not found' : null,
    () {
      testWidgets('Capture mobile tasks and courses preview', (tester) async {
        if (!hasMalgun) return;
        // 1. Load fonts
    final font = FontLoader('KoreanPreview')
      ..addFont(
        Future.value(
          ByteData.sublistView(File('C:/Windows/Fonts/malgun.ttf').readAsBytesSync()),
        ),
      );
    await font.load();

    final icons = FontLoader('MaterialIcons')
      ..addFont(
        Future.value(
          ByteData.sublistView(
            File(
              '../../work/tools/flutter/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf',
            ).readAsBytesSync(),
          ),
        ),
      );
    await icons.load();

    await tester.binding.setSurfaceSize(const Size(390, 844));

    final now = DateTime.utc(2026, 11, 5, 8, 30);
    final items = [
      CampusItem(
        key: 't1',
        title: '중간 캡스톤 프로젝트 기획서 제출',
        course: '어드벤처디자인',
        courseId: 'c1',
        classNo: '1',
        contentsId: 'cnt1',
        type: 'LR',
        status: 'pending',
        due: now.add(const Duration(hours: 3)),
        context: {'course_id': 'c1', 'class_no': '1'},
      ),
      CampusItem(
        key: 't2',
        title: '9주차 객체지향 프로그래밍 실습 강의',
        course: '컴퓨터프로그래밍 2',
        courseId: 'c2',
        classNo: '1',
        contentsId: 'cnt2',
        type: 'LV',
        status: 'pending',
        attendanceRequired: true,
        progress: '70% 수강',
        due: now.add(const Duration(hours: 6)),
        context: {'course_id': 'c2', 'class_no': '1'},
      ),
      CampusItem(
        key: 't3',
        title: 'B-Tree 구현 및 성능 분석 과제',
        course: '자료구조',
        courseId: 'c3',
        classNo: '1',
        contentsId: 'cnt3',
        type: 'LR',
        status: 'pending',
        due: now.add(const Duration(days: 3)),
        context: {'course_id': 'c3', 'class_no': '1'},
      ),
      CampusItem(
        key: 't4',
        title: '운영체제 프로세스 동기화 실습',
        course: '운영체제',
        courseId: 'c4',
        classNo: '1',
        contentsId: 'cnt4',
        type: 'LR',
        status: 'done',
        due: now.subtract(const Duration(days: 1)),
        context: {'course_id': 'c4', 'class_no': '1'},
      ),
    ];

    final courses = [
      {'course_nm': '어드벤처디자인', 'course_id': 'c1', 'class_no': '1'},
      {'course_nm': '컴퓨터프로그래밍 2', 'course_id': 'c2', 'class_no': '1'},
      {'course_nm': '자료구조', 'course_id': 'c3', 'class_no': '1'},
      {'course_nm': '운영체제', 'course_id': 'c4', 'class_no': '1'},
      {'course_nm': '인공지능개론', 'course_id': 'c5', 'class_no': '1'},
    ];

    final theme = ThemeData(
      fontFamily: 'KoreanPreview',
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xff3448ae),
        brightness: Brightness.light,
      ),
      scaffoldBackgroundColor: const Color(0xfff8f9fc),
    );

    // ── Screen A: Tasks View ──
    final tasksBoundaryKey = GlobalKey();
    await tester.pumpWidget(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: theme,
        home: Scaffold(
          appBar: AppBar(
            title: const Text('할 일', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
            elevation: 0,
            actions: [
              IconButton(icon: const Icon(Icons.tune_rounded), onPressed: () {}),
            ],
          ),
          body: RepaintBoundary(
            key: tasksBoundaryKey,
            child: MobileTasksView(
              items: items,
              excludedKeys: const {},
              visibilityBusy: const {},
              isBusy: false,
              onRefresh: () {},
              onTaskTap: (_) {},
              onTaskVisibilityToggle: (_) {},
            ),
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: 1,
            destinations: const [
              NavigationDestination(icon: Icon(Icons.today_outlined), label: '오늘'),
              NavigationDestination(icon: Icon(Icons.checklist_rounded), selectedIcon: Icon(Icons.checklist), label: '할 일'),
              NavigationDestination(icon: Icon(Icons.school_outlined), label: '과목'),
              NavigationDestination(icon: Icon(Icons.more_horiz_rounded), label: '더보기'),
            ],
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    await tester.runAsync(() async {
      final boundary = tasksBoundaryKey.currentContext!.findRenderObject() as RenderRepaintBoundary;
      final image = await boundary.toImage(pixelRatio: 2.0);
      final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      final pngBytes = byteData!.buffer.asUint8List();
      final outFile = File('../../outputs/mobile-tasks-preview.png');
      await outFile.parent.create(recursive: true);
      await outFile.writeAsBytes(pngBytes);
      image.dispose();
      print('Tasks preview saved to ${outFile.path}');
    });

    // ── Screen B: Courses View ──
    final coursesBoundaryKey = GlobalKey();
    await tester.pumpWidget(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: theme,
        home: Scaffold(
          appBar: AppBar(
            title: const Text('과목', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
            elevation: 0,
            actions: [
              IconButton(icon: const Icon(Icons.search_rounded), onPressed: () {}),
            ],
          ),
          body: RepaintBoundary(
            key: coursesBoundaryKey,
            child: MobileCoursesView(
              courses: courses,
              pendingTasks: items.where((i) => !i.done).toList(),
              slots: const [],
              isLoading: false,
              isRefreshing: false,
              onRefresh: () {},
              onCourseTap: (_) {},
              onTimetableTap: () {},
            ),
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: 2,
            destinations: const [
              NavigationDestination(icon: Icon(Icons.today_outlined), label: '오늘'),
              NavigationDestination(icon: Icon(Icons.checklist_rounded), label: '할 일'),
              NavigationDestination(icon: Icon(Icons.school_outlined), selectedIcon: Icon(Icons.school), label: '과목'),
              NavigationDestination(icon: Icon(Icons.more_horiz_rounded), label: '더보기'),
            ],
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    await tester.runAsync(() async {
      final boundary = coursesBoundaryKey.currentContext!.findRenderObject() as RenderRepaintBoundary;
      final image = await boundary.toImage(pixelRatio: 2.0);
      final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      final pngBytes = byteData!.buffer.asUint8List();
      final outFile = File('../../outputs/mobile-courses-preview.png');
      await outFile.parent.create(recursive: true);
      await outFile.writeAsBytes(pngBytes);
      image.dispose();
      print('Courses preview saved to ${outFile.path}');
    });

    await tester.binding.setSurfaceSize(null);
  });
  });
}

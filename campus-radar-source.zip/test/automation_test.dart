import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/services.dart';
import 'package:campus_radar/campus.dart';
import 'package:campus_radar/ai.dart';
import 'package:campus_radar/ai_automation.dart';
import 'package:campus_radar/ai_pages.dart';

CampusNotice notice(
  String id, {
  DateTime? date,
  String body = '2026년 10월 20일 보고서 제출',
}) => CampusNotice(
  id: id,
  title: '예시 공지',
  course: '가상 수업',
  context: {},
  published: date,
  body: body,
  bodyFetched: true,
);
CampusItem item(
  String key, {
  DateTime? due,
  DateTime? starts,
  bool published = true,
  String status = 'pending',
}) => CampusItem(
  key: key,
  type: 'LR',
  title: '가상 과제 $key',
  course: '가상 과목',
  courseId: 'c',
  classNo: '1',
  contentsId: key,
  status: status,
  context: {},
  due: due,
  startsAt: starts,
  published: published,
);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test(
    'deadline intervals stay on the deadline day, midnight belongs to previous day',
    () {
      for (final times in [
        ['23:59', '23:49'],
        ['00:05', '00:00'],
        ['15:00', '14:50'],
        ['00:00', '23:50'],
      ]) {
        final due = DateTime.parse('2026-10-20T${times[0]}:00+09:00');
        final w = calendarWindow(due, deadline: true);
        expect(w.$2, due);
        expect(w.$1.isBefore(w.$2), isTrue);
        final local = w.$1
            .toUtc()
            .add(const Duration(hours: 9))
            .toIso8601String();
        expect(local.substring(11, 16), times[1]);
        expect(
          local.substring(0, 10),
          times[0] == '00:00' ? '2026-10-19' : '2026-10-20',
        );
      }
      final now = DateTime.utc(2026);
      expect(calendarWindow(now).$2, now.add(const Duration(minutes: 10)));
    },
  );
  test(
    'new notice scope keeps baseline and seven-day scope has exact boundary',
    () {
      final now = DateTime.utc(2026, 10, 15);
      expect(inAiScope(notice('old'), 'new', now, {'old'}), isFalse);
      expect(inAiScope(notice('new'), 'new', now, {'old'}), isTrue);
      expect(
        inAiScope(
          notice('edge', date: now.subtract(const Duration(days: 7))),
          'recent',
          now,
          {},
        ),
        isTrue,
      );
      expect(
        inAiScope(
          notice(
            'older',
            date: now.subtract(const Duration(days: 7, seconds: 1)),
          ),
          'recent',
          now,
          {},
        ),
        isFalse,
      );
      expect(
        inAiScope(notice('old', date: DateTime.utc(2025)), 'all', now, {}),
        isTrue,
      );
    },
  );
  test(
    'AI summary uses available unfinished items and rejects invented identifiers/status',
    () {
      final now = DateTime.utc(2026, 10, 15);
      final all = [
        item('soon', due: now.add(const Duration(hours: 1))),
        item('done', status: 'done'),
        item('future', starts: now.add(const Duration(hours: 1))),
        item('hidden', published: false),
        item('excluded'),
      ];
      final list = summaryItems(all, {'excluded'}, now);
      expect(list.map((i) => i.key), ['soon']);
      expect(
        renderAiSummary(
          {
            'focusKeys': ['soon'],
            'advice': 'start_soon',
          },
          list,
          now,
        ),
        contains('가상 과제 soon'),
      );
      for (final response in [
        {
          'focusKeys': ['fake'],
          'advice': 'steady',
        },
        {
          'focusKeys': ['soon', 'soon'],
          'advice': 'steady',
        },
        {'focusKeys': [], 'advice': 'nothing_pending'},
        {'focusKeys': [], 'advice': 'review_overdue'},
      ]) {
        expect(
          () => renderAiSummary(response, list, now),
          throwsA(isA<AiFailure>()),
        );
      }
    },
  );

  group('durable AI data with real SQLite', () {
    late Directory temp;
    setUpAll(() {
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
    });
    setUp(() async {
      temp = await Directory.systemTemp.createTemp('campus-ai-test-');
      await databaseFactory.setDatabasesPath(temp.path);
      SharedPreferences.setMockInitialValues({});
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(
            const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
            (c) async =>
                c.method == 'read' ? 'test-key-for-synthetic-transport' : null,
          );
    });
    tearDown(() async {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(
            const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
            null,
          );
      await temp.delete(recursive: true);
    });
    test(
      'queue restart recovers interrupted jobs without dropping failed attempts',
      () async {
        var s = await Store.open();
        await s.setMeta('aiAuto', 'yes');
        await s.setMeta('aiScope', 'all');
        await s.saveNotice(notice('n'));
        await enqueueNotices(s);
        expect(jsonDecode((await s.meta('aiQueue:n'))!)['status'], 'pending');
        await s.setMeta(
          'aiQueue:n',
          jsonEncode({
            'status': 'running',
            'checked': DateTime.now()
                .toUtc()
                .subtract(const Duration(minutes: 6))
                .toIso8601String(),
          }),
        );
        await s.db.close();
        s = await Store.open();
        await enqueueNotices(s);
        expect(jsonDecode((await s.meta('aiQueue:n'))!)['status'], 'pending');
        await s.setMeta(
          'aiQueue:n',
          jsonEncode({'status': 'failed', 'attempts': 3}),
        );
        await enqueueNotices(s);
        expect(jsonDecode((await s.meta('aiQueue:n'))!)['attempts'], 3);
        await s.db.close();
      },
    );
    test(
      'request lease prevents cross-connection concurrent requests',
      () async {
        final a = await Store.open(), b = await Store.open();
        await claimAiRequest(a);
        await expectLater(
          claimAiRequest(b),
          throwsA(isA<AiFailure>().having((e) => e.code, 'code', 'busy')),
        );
        await a.db.close();
        await b.db.close();
      },
    );
    test('confirmed state survives changed notice cache and reopen', () async {
      var s = await Store.open();
      final n = notice('n');
      const c = ScheduleCandidate(
        title: '보고서',
        date: '2026-10-20',
        time: '',
        action: 'add',
        evidence: '보고서 제출',
        uncertainty: '',
        category: 'task',
      );
      await rememberCandidates(s, n, [c]);
      final key = candidateKey(n, c);
      await s.setMeta(
        'aiState:$key',
        jsonEncode({'status': 'confirmed', 'start': '2026-10-20T00:00:00Z'}),
      );
      await s.saveNotice(notice('n', body: '변경된 공지입니다.'));
      await s.db.close();
      s = await Store.open();
      expect(await s.meta('aiCandidate:$key'), isNotNull);
      expect(
        jsonDecode((await s.meta('aiState:$key'))!)['status'],
        'confirmed',
      );
      await s.db.close();
    });
    test(
      'summary mock success caches verified text; failure preserves prior text',
      () async {
        final s = await Store.open();
        await s.setMeta('aiConsent', aiConsentVersion);
        await s.setMeta('aiSummary', 'yes');
        await s.setMeta('lastSuccess', 'snapshot');
        var calls = 0;
        await prepareAiSummary(
          s,
          transport: (key, request) async {
            calls++;
            return {
              'candidates': [
                {
                  'finishReason': 'STOP',
                  'content': {
                    'parts': [
                      {
                        'text': jsonEncode({
                          'focusKeys': [],
                          'advice': 'nothing_pending',
                        }),
                      },
                    ],
                  },
                },
              ],
            };
          },
        );
        final old = await s.meta('aiSummaryText');
        expect(old, contains('미완료 항목이 없습니다'));
        await prepareAiSummary(
          s,
          transport: (k, r) async {
            calls++;
            throw const AiFailure('offline');
          },
        );
        expect(calls, 1);
        await s.setMeta('aiSummaryHash', '');
        await s.setMeta('aiLastRequest', '');
        await prepareAiSummary(
          s,
          transport: (k, r) async {
            calls++;
            throw const AiFailure('offline');
          },
        );
        expect(await s.meta('aiSummaryText'), old);
        expect(await s.meta('aiSummaryFailHash'), isNotEmpty);
        await s.db.close();
      },
    );
  });
}

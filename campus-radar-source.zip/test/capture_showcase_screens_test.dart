import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:campus_radar/campus/campus_media.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/material_catalog.dart';
import 'package:campus_radar/courses/mobile_courses_view.dart';
import 'package:campus_radar/home/mobile_today_view.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/tasks/mobile_tasks_view.dart';

Future<void> loadFonts() async {
  final font = FontLoader('KoreanPreview')
    ..addFont(
      Future.value(
        ByteData.sublistView(File('C:/Windows/Fonts/malgun.ttf').readAsBytesSync()),
      ),
    );
  await font.load();

  final icons = FontLoader('MaterialIcons')
    ..addFont(
      Future.value(
        ByteData.sublistView(
          File(
            '../../work/tools/flutter/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf',
          ).readAsBytesSync(),
        ),
      ),
    );
  await icons.load();
}

final theme = ThemeData(
  fontFamily: 'KoreanPreview',
  useMaterial3: true,
  colorScheme: ColorScheme.fromSeed(
    seedColor: const Color(0xff3448ae),
    brightness: Brightness.light,
  ),
  scaffoldBackgroundColor: const Color(0xfff8f9fc),
);

final artifactDir = Directory(r'C:\Users\USER\.gemini\antigravity\brain\48131112-5f4d-422e-a195-4b58741dac6e');
final outDir = Directory('../../outputs');

Future<void> saveScreenshot(GlobalKey key, String filename) async {
  final boundary = key.currentContext!.findRenderObject() as RenderRepaintBoundary;
  final image = await boundary.toImage(pixelRatio: 2.0);
  final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
  final pngBytes = byteData!.buffer.asUint8List();

  final file1 = File('${artifactDir.path}/$filename');
  await file1.writeAsBytes(pngBytes);

  final file2 = File('${outDir.path}/$filename');
  await file2.writeAsBytes(pngBytes);

  image.dispose();
  print('Saved: ${file1.path}');
}

final now = DateTime.utc(2026, 11, 5, 8, 30); // KST 17:30
final items = [
  CampusItem(
    key: 'task-1',
    title: '중간 캡스톤 프로젝트 기획서 제출',
    course: '어드벤처디자인',
    courseId: 'c1',
    classNo: '1',
    contentsId: 'cnt1',
    type: 'LR',
    status: 'pending',
    due: now.add(const Duration(hours: 3)),
    context: const {'course_id': 'c1', 'class_no': '1'},
  ),
  CampusItem(
    key: 'task-2',
    title: '9주차 객체지향 프로그래밍 실습 강의',
    course: '컴퓨터프로그래밍 2',
    courseId: 'c2',
    classNo: '1',
    contentsId: 'cnt2',
    type: 'LV',
    status: 'pending',
    attendanceRequired: true,
    progress: '70% 수강',
    due: now.add(const Duration(hours: 6)),
    context: const {'course_id': 'c2', 'class_no': '1'},
  ),
  CampusItem(
    key: 'task-3',
    title: 'B-Tree 구현 및 성능 분석 과제',
    course: '자료구조',
    courseId: 'c3',
    classNo: '1',
    contentsId: 'cnt3',
    type: 'LR',
    status: 'pending',
    due: now.add(const Duration(days: 3)),
    context: const {'course_id': 'c3', 'class_no': '1'},
  ),
  CampusItem(
    key: 'task-4',
    title: '10주차 가상 메모리와 페이징 기법 강의',
    course: '운영체제',
    courseId: 'c4',
    classNo: '1',
    contentsId: 'cnt4',
    type: 'LV',
    status: 'pending',
    attendanceRequired: true,
    progress: '미수강',
    due: now.add(const Duration(days: 4)),
    context: const {'course_id': 'c4', 'class_no': '1'},
  ),
];

final courses = [
  {'course_nm': '어드벤처디자인', 'course_id': 'c1', 'class_no': '1'},
  {'course_nm': '컴퓨터프로그래밍 2', 'course_id': 'c2', 'class_no': '1'},
  {'course_nm': '자료구조', 'course_id': 'c3', 'class_no': '1'},
  {'course_nm': '운영체제', 'course_id': 'c4', 'class_no': '1'},
  {'course_nm': '인공지능개론', 'course_id': 'c5', 'class_no': '1'},
];

final slots = [
  const ClassSlot(
    courseKey: 'c1:1',
    course: '어드벤처디자인',
    weekday: 1,
    start: 10,
    end: 12,
    room: '공학관 302호',
  ),
  const ClassSlot(
    courseKey: 'c2:1',
    course: '컴퓨터프로그래밍 2',
    weekday: 2,
    start: 13,
    end: 15,
    room: 'IT관 401호',
  ),
  const ClassSlot(
    courseKey: 'c3:1',
    course: '자료구조',
    weekday: 3,
    start: 9,
    end: 11,
    room: '미래관 205호',
  ),
  const ClassSlot(
    courseKey: 'c4:1',
    course: '운영체제',
    weekday: 4,
    start: 14,
    end: 16,
    room: '공학관 510호',
  ),
];

void main() {
  final hasMalgun = File('C:/Windows/Fonts/malgun.ttf').existsSync();

  group(
    'Showcase screenshots',
    skip: !hasMalgun ? 'Windows font (C:/Windows/Fonts/malgun.ttf) not found' : null,
    () {
      setUpAll(() async {
        if (!hasMalgun) return;
        await loadFonts();
      });

  testWidgets('Capture 1: Mobile Today View', (tester) async {
    await tester.binding.setSurfaceSize(const Size(390, 844));
    final key = GlobalKey();

    final homeNotices = <CampusNotice>[
      CampusNotice(
        id: 'n1',
        title: '[중요] 2학기 중간 강의평가 및 학사일정 안내',
        course: '학과공통',
        published: now.subtract(const Duration(hours: 4)),
        read: false,
        context: const {'course_id': 'c0'},
      ),
    ];

    await tester.pumpWidget(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: theme,
        home: Scaffold(
          appBar: AppBar(
            title: const Text('오늘', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
            elevation: 0,
            actions: [
              IconButton(icon: const Icon(Icons.notifications_none_rounded), onPressed: () {}),
              IconButton(icon: const Icon(Icons.settings_outlined), onPressed: () {}),
            ],
          ),
          body: RepaintBoundary(
            key: key,
            child: MobileTodayView(
              now: now,
              pendingItems: items,
              urgentCount: 1,
              todayCount: 2,
              excludedKeys: const {},
              visibilityBusy: const {},
              isBusy: false,
              lastSyncTime: '방금 전',
              homeNotices: homeNotices,
              localRevision: 1,
              onRefresh: () {},
              onShowAllTasks: () {},
              onShowUrgentTasks: () {},
              onTaskTap: (_) {},
              onTaskVisibilityToggle: (_) {},
            ),
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: 0,
            destinations: const [
              NavigationDestination(icon: Icon(Icons.today_rounded), label: '오늘'),
              NavigationDestination(icon: Icon(Icons.checklist_rounded), label: '할 일'),
              NavigationDestination(icon: Icon(Icons.school_outlined), label: '과목'),
              NavigationDestination(icon: Icon(Icons.more_horiz_rounded), label: '더보기'),
            ],
          ),
        ),
      ),
    );
    await tester.pump();
    await tester.runAsync(() => saveScreenshot(key, 'mobile-today-preview.png'));
  });

  testWidgets('Capture 2: Mobile Tasks View', (tester) async {
    await tester.binding.setSurfaceSize(const Size(390, 844));
    final key = GlobalKey();

    await tester.pumpWidget(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: theme,
        home: Scaffold(
          appBar: AppBar(
            title: const Text('할 일', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
            elevation: 0,
            actions: [
              IconButton(icon: const Icon(Icons.tune_rounded), onPressed: () {}),
            ],
          ),
          body: RepaintBoundary(
            key: key,
            child: MobileTasksView(
              items: items,
              excludedKeys: const {},
              visibilityBusy: const {},
              isBusy: false,
              onRefresh: () {},
              onTaskTap: (_) {},
              onTaskVisibilityToggle: (_) {},
            ),
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: 1,
            destinations: const [
              NavigationDestination(icon: Icon(Icons.today_outlined), label: '오늘'),
              NavigationDestination(icon: Icon(Icons.checklist_rounded), label: '할 일'),
              NavigationDestination(icon: Icon(Icons.school_outlined), label: '과목'),
              NavigationDestination(icon: Icon(Icons.more_horiz_rounded), label: '더보기'),
            ],
          ),
        ),
      ),
    );
    await tester.pump();
    await tester.runAsync(() => saveScreenshot(key, 'mobile-tasks-preview.png'));
  });

  testWidgets('Capture 3: Mobile Courses View', (tester) async {
    await tester.binding.setSurfaceSize(const Size(390, 844));
    final key = GlobalKey();

    await tester.pumpWidget(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: theme,
        home: Scaffold(
          appBar: AppBar(
            title: const Text('과목', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
            elevation: 0,
            actions: [
              IconButton(icon: const Icon(Icons.search_rounded), onPressed: () {}),
            ],
          ),
          body: RepaintBoundary(
            key: key,
            child: MobileCoursesView(
              courses: courses,
              pendingTasks: items,
              slots: slots,
              isLoading: false,
              isRefreshing: false,
              onRefresh: () {},
              onCourseTap: (_) {},
              onTimetableTap: () {},
            ),
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: 2,
            destinations: const [
              NavigationDestination(icon: Icon(Icons.today_outlined), label: '오늘'),
              NavigationDestination(icon: Icon(Icons.checklist_rounded), label: '할 일'),
              NavigationDestination(icon: Icon(Icons.school_rounded), label: '과목'),
              NavigationDestination(icon: Icon(Icons.more_horiz_rounded), label: '더보기'),
            ],
          ),
        ),
      ),
    );
    await tester.pump();
    await tester.runAsync(() => saveScreenshot(key, 'mobile-courses-preview.png'));
  });

  testWidgets('Capture 4: Materials View', (tester) async {
    await tester.binding.setSurfaceSize(const Size(390, 844));
    final key = GlobalKey();

    // Render showcase list of modern material cards
    final sampleMaterials = [
      StudyMaterial(
        id: 'm1',
        sourceId: 's1',
        title: '9주차 강의자료: 트랜잭션과 동시성 제어.pdf',
        course: '자료구조',
        date: now.subtract(const Duration(days: 2)),
        body: '9주차 슬라이드 배포본입니다.',
        sourceType: 'LS',
        media: const CampusMedia(
          name: '트랜잭션_동시성_제어_v2.pdf',
          url: 'https://dcs-learning.cnu.ac.kr/file/1',
        ),
      ),
      StudyMaterial(
        id: 'm2',
        sourceId: 's2',
        title: '10주차 객체지향 디자인패턴 실습 강의자료',
        course: '컴퓨터프로그래밍 2',
        date: now.subtract(const Duration(days: 1)),
        body: '실습 PPTX 슬라이드입니다.',
        sourceType: 'LS',
        media: const CampusMedia(
          name: '컴퓨터프로그래밍2_10주차_실습.pptx',
          url: 'https://dcs-learning.cnu.ac.kr/file/2',
        ),
      ),
      StudyMaterial(
        id: 'm3',
        sourceId: 's3',
        title: '중간고사 대비 운영체제 핵심 총정리',
        course: '운영체제',
        date: now.subtract(const Duration(days: 5)),
        body: '1~8장 핵심 요약본 한글 문서',
        sourceType: 'LS',
        media: const CampusMedia(
          name: '운영체제_중간요약_핸드아웃.hwpx',
          url: 'https://dcs-learning.cnu.ac.kr/file/3',
        ),
      ),
      StudyMaterial(
        id: 'm4',
        sourceId: 's4',
        title: '10주차 실습 템플릿 코드 저장소 (GitHub)',
        course: '어드벤처디자인',
        date: now.subtract(const Duration(hours: 12)),
        body: 'https://github.com/example/course-week10-template',
        externalUrl: 'https://github.com/example/course-week10-template',
        sourceType: 'LS',
      ),
    ];

    await tester.pumpWidget(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: theme,
        home: Scaffold(
          appBar: AppBar(
            title: const Text('전체 자료실', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
            elevation: 0,
            actions: [
              IconButton(icon: const Icon(Icons.filter_list_rounded), onPressed: () {}),
            ],
          ),
          body: RepaintBoundary(
            key: key,
            child: ListView(
              padding: const EdgeInsets.only(top: 8, bottom: 40),
              children: [
                // Top Search Bar
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    child: Row(
                      children: [
                        Icon(Icons.search_rounded, size: 20, color: theme.colorScheme.onSurfaceVariant),
                        const SizedBox(width: 8),
                        Text(
                          '강의자료 또는 과목 검색',
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant.withValues(alpha: 0.7),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                // Material Showcase Cards
                for (final m in sampleMaterials)
                  _ShowcaseMaterialCard(material: m, isSaved: m.id == 'm1'),
              ],
            ),
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: 2,
            destinations: const [
              NavigationDestination(icon: Icon(Icons.today_outlined), label: '오늘'),
              NavigationDestination(icon: Icon(Icons.checklist_rounded), label: '할 일'),
              NavigationDestination(icon: Icon(Icons.school_rounded), label: '과목'),
              NavigationDestination(icon: Icon(Icons.more_horiz_rounded), label: '더보기'),
            ],
          ),
        ),
      ),
    );
    await tester.pump();
    await tester.runAsync(() => saveScreenshot(key, 'mobile-materials-preview.png'));
  });

  testWidgets('Capture 5: Course Detail Page', (tester) async {
    await tester.binding.setSurfaceSize(const Size(390, 844));
    final key = GlobalKey();

    await tester.pumpWidget(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: theme,
        home: Scaffold(
          appBar: AppBar(
            title: const Text('자료구조', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
            elevation: 0,
            actions: [
              IconButton(icon: const Icon(Icons.palette_outlined), onPressed: () {}),
            ],
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(48),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _TabItem(title: '과제 1', active: false),
                  _TabItem(title: '강의 0', active: false),
                  _TabItem(title: '자료 2', active: true),
                  _TabItem(title: '공지 1', active: false),
                ],
              ),
            ),
          ),
          body: RepaintBoundary(
            key: key,
            child: ListView(
              padding: const EdgeInsets.only(top: 10, bottom: 40),
              children: [
                // Filter bar
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: theme.colorScheme.primaryContainer,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.sort_rounded, size: 16, color: theme.colorScheme.onPrimaryContainer),
                            const SizedBox(width: 4),
                            Text(
                              '주차순 (자연어)',
                              style: theme.textTheme.labelMedium?.copyWith(
                                color: theme.colorScheme.onPrimaryContainer,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: theme.colorScheme.surfaceContainerHighest,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          '2개 자료',
                          style: theme.textTheme.labelMedium?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                _ShowcaseMaterialCard(
                  material: StudyMaterial(
                    id: 'c3-1',
                    sourceId: 's1',
                    title: '9주차: 트랜잭션과 동시성 제어',
                    course: '자료구조',
                    body: '9주차 슬라이드 배포본',
                    sourceType: 'LS',
                    media: const CampusMedia(name: '트랜잭션_동시성_제어_v2.pdf', url: 'https://campus...'),
                  ),
                  isSaved: true,
                ),
                _ShowcaseMaterialCard(
                  material: StudyMaterial(
                    id: 'c3-2',
                    sourceId: 's2',
                    title: '10주차: B-Tree 탐색 및 삽입 실습 가이드',
                    course: '자료구조',
                    body: 'B-Tree 구현 코드 설명서',
                    sourceType: 'LS',
                    media: const CampusMedia(name: 'B-Tree_구현_가이드.pdf', url: 'https://campus...'),
                  ),
                  isSaved: false,
                ),
              ],
            ),
          ),
        ),
      ),
    );
    await tester.pump();
    await tester.runAsync(() => saveScreenshot(key, 'mobile-course-detail-preview.png'));
  });
  });
}

class _TabItem extends StatelessWidget {
  final String title;
  final bool active;
  const _TabItem({required this.title, required this.active});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: active ? colorScheme.primary : Colors.transparent,
            width: 2.5,
          ),
        ),
      ),
      child: Text(
        title,
        style: theme.textTheme.titleSmall?.copyWith(
          color: active ? colorScheme.primary : colorScheme.onSurfaceVariant,
          fontWeight: active ? FontWeight.bold : FontWeight.normal,
        ),
      ),
    );
  }
}

class _ShowcaseMaterialCard extends StatelessWidget {
  final StudyMaterial material;
  final bool isSaved;
  const _ShowcaseMaterialCard({required this.material, required this.isSaved});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final ext = (material.media != null && material.media!.name.contains('.'))
        ? material.media!.name.split('.').last.toLowerCase()
        : '';

    Color badgeColor;
    IconData badgeIcon;
    String badgeLabel;

    if (material.externalUrl.isNotEmpty) {
      badgeColor = const Color(0xff00897b);
      badgeIcon = Icons.link_rounded;
      badgeLabel = '링크';
    } else if (ext == 'pdf') {
      badgeColor = const Color(0xffd32f2f);
      badgeIcon = Icons.picture_as_pdf_rounded;
      badgeLabel = 'PDF';
    } else if (ext == 'ppt' || ext == 'pptx') {
      badgeColor = const Color(0xffe65100);
      badgeIcon = Icons.slideshow_rounded;
      badgeLabel = 'PPT';
    } else if (ext == 'hwp' || ext == 'hwpx') {
      badgeColor = const Color(0xff1976d2);
      badgeIcon = Icons.description_rounded;
      badgeLabel = '한글';
    } else {
      badgeColor = colorScheme.primary;
      badgeIcon = Icons.notes_rounded;
      badgeLabel = '본문';
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerLowest,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: colorScheme.outlineVariant.withValues(alpha: 0.45),
        ),
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.02),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 13, 14, 13),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: badgeColor.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(badgeIcon, color: badgeColor, size: 20),
                  const SizedBox(height: 1),
                  Text(
                    badgeLabel,
                    style: TextStyle(
                      color: badgeColor,
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    material.title.isEmpty ? material.name : material.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w700,
                      fontSize: 14.5,
                      letterSpacing: -0.3,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6.5, vertical: 2),
                        decoration: BoxDecoration(
                          color: colorScheme.surfaceContainerHighest,
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Text(
                          material.course,
                          style: theme.textTheme.labelSmall?.copyWith(
                            color: colorScheme.onSurfaceVariant,
                            fontSize: 10.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      const SizedBox(width: 6),
                      if (material.media != null)
                        Expanded(
                          child: Text(
                            material.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: colorScheme.onSurfaceVariant,
                              fontSize: 11.5,
                            ),
                          ),
                        ),
                      if (isSaved) ...[
                        const SizedBox(width: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1.5),
                          decoration: BoxDecoration(
                            color: const Color(0xff2e7d32).withValues(alpha: 0.12),
                            borderRadius: BorderRadius.circular(5),
                          ),
                          child: const Text(
                            '저장됨',
                            style: TextStyle(
                              color: Color(0xff2e7d32),
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Icon(
              Icons.arrow_forward_ios_rounded,
              size: 13,
              color: colorScheme.outlineVariant,
            ),
          ],
        ),
      ),
    );
  }
}

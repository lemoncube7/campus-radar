// ignore_for_file: depend_on_referenced_packages
import 'dart:convert';
import 'dart:io';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/services.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/notification_gateway.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  late Directory temp;
  late Store store;
  final calls = <MethodCall>[];
  const channel = MethodChannel('dexterous.com/flutter/local_notifications');

  setUp(() async {
    temp = await Directory.systemTemp.createTemp('semester-protection-');
    await databaseFactory.setDatabasesPath(temp.path);
    calls.clear();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (c) async {
      calls.add(c);
      return c.method == 'initialize' || c.method == 'areNotificationsEnabled'
          ? true
          : null;
    });
    SharedPreferences.setMockInitialValues({});
    FlutterLocalNotificationsPlatform.instance =
        AndroidFlutterLocalNotificationsPlugin();
    await initNotifications();
    store = await Store.open();
  });

  tearDown(() async {
    await store.db.close();
    await temp.delete(recursive: true);
  });

  group('Failure mode 1: opening-week notification burst', () {
    test(
        'more than 5 imminent deadline reminders are bundled into a single summary notification',
        () async {
      final now = DateTime.now().toUtc();
      // 8 items due in 2 hours, well within the 1440m (24h) lead
      final items = List.generate(
        8,
        (i) => CampusItem(
          key: 'LR:c$i:1:item$i',
          type: 'LR',
          title: '과제 $i',
          course: '과목 $i',
          courseId: 'c$i',
          classNo: '1',
          contentsId: 'item$i',
          status: 'pending',
          context: const {},
          due: now.add(const Duration(hours: 2)),
        ),
      );

      await store.replace(items, courses: [
        for (var i = 0; i < 8; i++)
          {
            'course_id': 'c$i',
            'class_no': '1',
            'course_nm': '과목 $i',
            'term_year': '2027',
            'term_cd': '1',
          }
      ]);

      calls.clear();
      await reconcile(store);

      final showCalls = calls.where((c) => c.method == 'show').toList();
      // Exactly 1 summary show call for reminders (new: events were initialized on replace)
      final reminderSummaryCalls = showCalls.where((c) {
        final title = (c.arguments as Map)['title'] as String? ?? '';
        return title.contains('마감 임박');
      }).toList();

      expect(reminderSummaryCalls, hasLength(1),
          reason: '8 imminent reminders must be summarized into 1 notification');
      expect(
        (reminderSummaryCalls.single.arguments as Map)['title'],
        '마감 임박 과제·콘텐츠 8건',
      );

      // Verify that all 8 tokens were marked as 'sent' in store meta
      for (final item in items) {
        final token = 'due:${item.key}:${item.due!.toIso8601String()}';
        expect(await store.meta(token), 'sent');
      }
    });

    test(
        '5 or fewer imminent deadline reminders are sent individually',
        () async {
      final now = DateTime.now().toUtc();
      final items = List.generate(
        3,
        (i) => CampusItem(
          key: 'LR:few$i:1:item$i',
          type: 'LR',
          title: '과제 $i',
          course: '과목 $i',
          courseId: 'few$i',
          classNo: '1',
          contentsId: 'item$i',
          status: 'pending',
          context: const {},
          due: now.add(const Duration(hours: 2)),
        ),
      );

      await store.replace(items, courses: [
        for (var i = 0; i < 3; i++)
          {
            'course_id': 'few$i',
            'class_no': '1',
            'course_nm': '과목 $i',
            'term_year': '2027',
            'term_cd': '1',
          }
      ]);

      calls.clear();
      await reconcile(store);

      final reminderShows = calls.where((c) {
        if (c.method != 'show') return false;
        final title = (c.arguments as Map)['title'] as String? ?? '';
        return title.contains('마감');
      }).toList();

      expect(reminderShows, hasLength(3),
          reason: '3 imminent reminders must be sent individually');
    });

    test(
        'more than 5 new event items/notices are grouped into a single summary notification',
        () async {
      // First collection initializes visibleIds
      await store.replace([], courses: [
        {'course_id': 'c', 'class_no': '1', 'course_nm': '과목', 'term_year': '2027', 'term_cd': '1'}
      ]);

      // Second collection brings in 7 new assignments
      final now = DateTime.now().toUtc();
      final items = List.generate(
        7,
        (i) => CampusItem(
          key: 'LR:new$i:1:item$i',
          type: 'LR',
          title: '새 과제 $i',
          course: '과목 $i',
          courseId: 'new$i',
          classNo: '1',
          contentsId: 'item$i',
          status: 'pending',
          context: const {},
          // Due far in the future so no imminent reminder fires
          due: now.add(const Duration(days: 10)),
        ),
      );

      await store.replace(items, courses: [
        for (var i = 0; i < 7; i++)
          {
            'course_id': 'new$i',
            'class_no': '1',
            'course_nm': '과목 $i',
            'term_year': '2027',
            'term_cd': '1',
          }
      ]);

      calls.clear();
      await reconcile(store);

      final eventSummaryCalls = calls.where((c) {
        if (c.method != 'show') return false;
        final title = (c.arguments as Map)['title'] as String? ?? '';
        return title.contains('새 학교 소식');
      }).toList();

      expect(eventSummaryCalls, hasLength(1));
      expect(
        (eventSummaryCalls.single.arguments as Map)['title'],
        '새 학교 소식 7건',
      );
    });
  });

  group('Failure mode 3: empty course catalogue wiping existing local data', () {
    test(
        'empty course catalogue throws and preserves existing items and catalog when data exists',
        () async {
      final now = DateTime.now().toUtc();
      final initialItem = CampusItem(
        key: 'LR:initial:1:1',
        type: 'LR',
        title: '지난 학기 과제',
        course: '선형대수',
        courseId: 'c1',
        classNo: '1',
        contentsId: '1',
        status: 'pending',
        context: const {},
        due: now.add(const Duration(days: 5)),
      );

      final initialCatalog = [
        {
          'course_id': 'c1',
          'class_no': '1',
          'course_nm': '선형대수',
          'term_year': '2026',
          'term_cd': '2',
        }
      ];

      // Initial populate
      await store.replace([initialItem], courses: initialCatalog);
      expect(await store.items(), hasLength(1));
      expect(await store.meta(MetaKey.courses), jsonEncode(initialCatalog));

      // Attempting to replace with empty course catalogue throws FormatException
      expect(
        () => store.replace([], courses: []),
        throwsA(isA<FormatException>().having(
          (e) => e.message,
          'message',
          contains('학교가 수강 과목을 0개로 반환했어요'),
        )),
      );

      // Existing data must remain completely intact
      final preserved = await store.items();
      expect(preserved, hasLength(1));
      expect(preserved.single.key, initialItem.key);
      expect(await store.meta(MetaKey.courses), jsonEncode(initialCatalog));
    });

    test('initial fresh user with empty course catalogue does not throw',
        () async {
      expect(
        () => store.replace([], courses: []),
        returnsNormally,
      );
      expect(await store.items(), isEmpty);
    });
  });
}

// P3 repro: logout deletes credentials first; if the data-wipe step then fails
// (DB busy), previous-account data stays and, with credentials gone, the
// logout entry point (shown only when `loggedIn`) disappears, so the advised
// "다시 로그아웃해 주세요" retry is impossible.
import 'dart:io';
import 'package:campus_radar/campus/account_service.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/campus/freeboard_models.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:workmanager/workmanager.dart';
import 'package:workmanager_apple/workmanager_apple.dart';

class _TestLogoutScheduler extends WorkmanagerApple {
  @override
  Future<void> cancelByUniqueName(String uniqueName) async {}
  @override
  Future<void> cancelAll() async {}
  @override
  Future<void> cancelByTag(String tag) async {}
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  late Directory temp;

  setUp(() async {
    WorkmanagerPlatform.instance = _TestLogoutScheduler();
    temp = await Directory.systemTemp.createTemp('p3-logout-');
    databaseFactory = databaseFactoryFfi;
    await databaseFactory.setDatabasesPath(temp.path);
    SharedPreferences.setMockInitialValues({});
  });

  tearDown(() async {
    for (final channel in [
      'plugins.it_nomads.com/flutter_secure_storage',
      'plugins.flutter.io/path_provider',
      'campus_radar/native',
      'be.tramckmedia.workmanager',
    ]) {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(MethodChannel(channel), null);
    }
    const pigeonPrefix =
        'dev.flutter.pigeon.workmanager_platform_interface.WorkmanagerHostApi';
    for (final method in [
      'initialize',
      'registerPeriodicTask',
      'registerOneOffTask',
      'cancelByUniqueName',
      'cancelAll',
      'cancelByTag',
    ]) {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMessageHandler('$pigeonPrefix.$method', null);
    }
    try {
      if (temp.existsSync()) {
        await temp.delete(recursive: true);
      }
    } catch (_) {}
  });

  test('partial logout leaves old data with no way to retry', () async {
    final vault = <String, String>{'id': 'synthetic-a', 'pw': '***'};
    final m = TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    m.setMockMethodCallHandler(
      const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
      (c) async {
        final a = (c.arguments as Map?) ?? {};
        switch (c.method) {
          case 'read':
            return vault[a['key']];
          case 'deleteAll':
            vault.clear();
            return null;
        }
        return null;
      },
    );
    m.setMockMethodCallHandler(
      const MethodChannel('plugins.flutter.io/path_provider'),
      (c) async => temp.path,
    );
    m.setMockMethodCallHandler(
      const MethodChannel('campus_radar/native'),
      (c) async => null,
    );
    final seed = await Store.open();
    await seed.replace([
      CampusItem(
        key: 'LR:prev-account',
        type: 'LR',
        title: 'Previous account task',
        course: 'Previous course',
        courseId: 'c',
        classNo: '1',
        contentsId: 'x',
        status: 'pending',
        due: DateTime.now().toUtc().add(const Duration(days: 2)),
        context: const {},
      ),
    ]);
    await seed.db.close();
    // Another isolate (e.g. background collection) holds a write lock.
    final locker = await databaseFactoryFfi.openDatabase(
      '${temp.path}/campus.db',
    );
    late List<String> failures;
    try {
      await locker.execute('BEGIN EXCLUSIVE');
      failures = await performAccountLogout();
      await locker.execute('COMMIT');
    } finally {
      await locker.close();
    }
    final after = await Store.open();
    final items = await after.items();
    await after.db.close();
    final loggedIn =
        await credentials.read(key: 'id') != null &&
        await credentials.read(key: 'pw') != null;
    // ignore: avoid_print
    print('failures=$failures items=${items.length} loggedIn=$loggedIn');
    expect(failures, contains('수집 정보 삭제'));
    // Correct: either the data is gone, or the account is still "logged in"
    // so the logout button (settings_page.dart:170 `if (connected)`) remains.
    expect(
      items.isEmpty || loggedIn,
      isTrue,
      reason: 'old account data retained while logout entry is hidden',
    );
  }, timeout: const Timeout(Duration(minutes: 2)));

  test('successful logout clears freeboard posts and checked metadata', () async {
    final vault = <String, String>{'id': 'synthetic-a', 'pw': 'test-password'};
    final messenger = TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    messenger.setMockMethodCallHandler(
      const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'), (call) async {
        final args = (call.arguments as Map?) ?? {};
        if (call.method == 'read') return vault[args['key']];
        if (call.method == 'deleteAll') vault.clear();
        if (call.method == 'delete') vault.remove(args['key']);
        return null;
      },
    );
    messenger.setMockMethodCallHandler(
      const MethodChannel('plugins.flutter.io/path_provider'), (_) async => temp.path);
    messenger.setMockMethodCallHandler(
      const MethodChannel('campus_radar/native'), (_) async => null);
    final store = await Store.open();
    await store.saveFreeboardPost(const CampusFreeboardPost(
      id: 'private', courseId: 'c1', classNo: '1', course: '이전 계정',
      title: '이전 계정 글', context: {},
    ));
    await store.setMeta('freeboardChecked:c1:1', 'checked');
    await store.db.close();
    await performAccountLogout();
    final after = await Store.open();
    try {
      expect(await after.freeboardPosts(), isEmpty);
      expect(await after.meta('freeboardChecked:c1:1'), isNull);
      expect(vault['id'], isNull);
    } finally { await after.db.close(); }
  });
}

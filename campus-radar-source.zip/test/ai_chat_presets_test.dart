import 'dart:io';

import 'package:campus_radar/ai/ai_chat_page.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;

  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    temp = await Directory.systemTemp.createTemp('ai-presets-test-');
    await databaseFactory.setDatabasesPath(temp.path);
    final initialStore = await Store.open();
    await initialStore.db.close();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          (call) async => null,
        );
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('campus_radar/native'),
          (call) async => null,
        );
  });

  tearDown(() async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          null,
        );
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('campus_radar/native'),
          null,
        );
    try {
      if (temp.existsSync()) {
        await temp.delete(recursive: true);
      }
    } catch (_) {}
  });

  Future<void> settle(WidgetTester tester) async {
    await tester.pump();
    await tester.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 350)),
    );
    await tester.pumpAndSettle();
  }

  testWidgets(
    'General AI chat shows compact preset chips above composer and fills editable draft on tap',
    (tester) async {
      await tester.pumpWidget(const MaterialApp(home: AiChatPage()));
      await settle(tester);

      // Verify general chat question presets are visible
      expect(find.text('오늘 마감 뭐 있어?'), findsOneWidget);
      expect(find.text('다음 수업은 언제야?'), findsOneWidget);
      expect(find.text('최근 공지 요약해 줘'), findsOneWidget);
      expect(find.text('이번 주 과제 뭐 있어?'), findsOneWidget);
      expect(find.text('이번 주 마감은?'), findsOneWidget);

      // Tap preset chip
      await tester.tap(find.text('오늘 마감 뭐 있어?'));
      await tester.pumpAndSettle();

      // Filled editable draft in TextField with cursor at the end
      final textField = tester.widget<TextField>(find.byType(TextField));
      expect(textField.controller!.text, '오늘 마감 뭐 있어?');
      expect(
        textField.controller!.selection.baseOffset,
        '오늘 마감 뭐 있어?'.length,
      );

      // Once draft is non-empty, preset chips are hidden
      expect(find.text('오늘 마감 뭐 있어?'), findsOneWidget); // only in TextField
      expect(find.byType(ActionChip), findsNothing);

      // No message sent automatically (history remains empty)
      expect(find.byType(ListView), findsOneWidget);
      expect(find.textContaining('AI는 제출이나 일정 변경을 실행하지 않아요.'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets('Chips hide when draft is typed and reappear when draft is cleared', (
    tester,
  ) async {
    await tester.pumpWidget(const MaterialApp(home: AiChatPage()));
    await settle(tester);

    expect(find.text('오늘 마감 뭐 있어?'), findsOneWidget);

    // Enter draft
    await tester.enterText(find.byType(TextField), '직접 입력한 질문');
    await tester.pumpAndSettle();

    // Chips hidden
    expect(find.text('오늘 마감 뭐 있어?'), findsNothing);
    expect(find.byType(ActionChip), findsNothing);

    // Clear draft
    await tester.enterText(find.byType(TextField), '');
    await tester.pumpAndSettle();

    // Chips visible again
    expect(find.text('오늘 마감 뭐 있어?'), findsOneWidget);
    expect(find.byType(ActionChip), findsWidgets);
    expect(tester.takeException(), isNull);
  });

  testWidgets(
    'Course-specific chat shows relevant course-scoped question presets',
    (tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: AiChatPage(
            course: {
              'course_id': 'c101',
              'class_no': '1',
              'course_nm': '운영체제',
            },
          ),
        ),
      );
      await settle(tester);

      expect(find.text('이 과목 공지 요약'), findsOneWidget);
      expect(find.text('오늘 마감 뭐 있어?'), findsOneWidget);
      expect(find.text('다음 수업은 언제야?'), findsOneWidget);
      expect(find.text('이번 주 과제 뭐 있어?'), findsOneWidget);
      expect(find.text('최근 공지 요약해 줘'), findsNothing);
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets('No overflow at narrow screen widths', (tester) async {
    tester.view.physicalSize = const Size(320, 640);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(const MaterialApp(home: AiChatPage()));
    await settle(tester);

    expect(find.byType(SingleChildScrollView), findsWidgets);
    expect(tester.takeException(), isNull);
  });

}

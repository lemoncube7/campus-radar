import 'dart:io';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/services.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/notification_gateway.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  FlutterLocalNotificationsPlatform.instance = AndroidFlutterLocalNotificationsPlugin();

  setUp(() {
    debugDefaultTargetPlatformOverride = TargetPlatform.android;
  });

  tearDown(() {
    debugDefaultTargetPlatformOverride = null;
  });

  test('Item 3: material notification style should not have reviewAction ("공지 일정 검토함")', () {
    final style = notificationStyleFor(material: true);
    final androidActions = style.android?.actions;
    expect(androidActions, anyOf(isNull, isEmpty));
  });

  test('Item 4: imminent reminders summary notification is cancelled when tasks are completed', () async {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfiNoIsolate;
    final tempDir = await Directory.systemTemp.createTemp('notify_test_');
    await databaseFactory.setDatabasesPath(tempDir.path);

    SharedPreferences.setMockInitialValues({});
    final shownIds = <int>[];
    final cancelledIds = <int>[];

    final messenger = TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    messenger.setMockMethodCallHandler(
      const MethodChannel('dexterous.com/flutter/local_notifications'),
      (call) async {
        if (call.method == 'initialize') return true;
        if (call.method == 'areNotificationsEnabled') return true;
        if (call.method == 'show') {
          final args = Map<String, dynamic>.from(call.arguments as Map);
          shownIds.add(args['id'] as int);
          return null;
        }
        if (call.method == 'cancel') {
          final args = Map<String, dynamic>.from(call.arguments as Map);
          cancelledIds.add(args['id'] as int);
          return null;
        }
        return null;
      },
    );

    await ensureNotificationsInitialized();

    final store = await Store.open();
    try {
      // Create 6 imminent tasks (due in 2 hours, within 24h lead).
      final now = DateTime.now().toUtc();
      final items = List.generate(
        6,
        (i) => CampusItem(
          key: 'item$i',
          type: 'LR',
          title: '과제 $i',
          course: '알고리즘',
          courseId: 'c1',
          classNo: '1',
          contentsId: 'cnt$i',
          status: 'pending',
          due: now.add(const Duration(hours: 2)),
          context: const {},
        ),
      );
      await store.replace(items);

      // Run reconcile - should show summary notification because > 5 items
      await reconcile(store);

      expect(shownIds, isNotEmpty);
      final summaryId = shownIds.first;

      // Complete all tasks
      final completed = items
          .map(
            (i) => CampusItem(
              key: i.key,
              type: i.type,
              title: i.title,
              course: i.course,
              courseId: i.courseId,
              classNo: i.classNo,
              contentsId: i.contentsId,
              status: 'done',
              due: i.due,
              context: i.context,
            ),
          )
          .toList();
      await store.replace(completed);

      // Run reconcile again - summary notification MUST be cancelled
      await reconcile(store);

      expect(
        cancelledIds,
        contains(summaryId),
        reason: 'Summary notification must be cancelled when tasks finish',
      );
    } finally {
      await store.db.close();
      messenger.setMockMethodCallHandler(
        const MethodChannel('dexterous.com/flutter/local_notifications'),
        null,
      );
      try {
        await tempDir.delete(recursive: true);
      } catch (_) {}
    }
  });
}

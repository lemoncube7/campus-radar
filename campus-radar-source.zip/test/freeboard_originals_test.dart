import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_media.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/freeboard_models.dart';
import 'package:campus_radar/campus/media_cache.dart';
import 'package:campus_radar/export/drive_sync.dart';
import 'package:campus_radar/export/drive_uploader.dart';
import 'package:campus_radar/export/academic_export.dart';
import 'drive_uploader_test.dart' show FakeDrive;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Store store;
  late Directory dir;
  late MediaCache cache;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    dir = await Directory.systemTemp.createTemp('radar-freeboard-originals-');
    await databaseFactory.setDatabasesPath(dir.path);
    store = await Store.open();
    cache = MediaCache(Directory('${dir.path}/cache'));
    await cache.root.create();
    await store.setMeta('lastSuccess', DateTime.now().toUtc().toIso8601String());
  });
  tearDown(() async { await store.db.close(); await dir.delete(recursive: true); });
  Future<CampusMedia> seed(String id, {String course = '과목', String? content}) async {
    final media = CampusMedia(name: '$id.pdf', url: 'https://dcs-learning.cnu.ac.kr/file/$id');
    await store.saveFreeboardPost(CampusFreeboardPost(
      id: id, courseId: course, classNo: '1', course: course, title: id,
      context: {'course_id': course, 'class_no': '1'}, media: [media],
      bodyFetched: true, body: '본문',
    ));
    if (content != null) {
      await cache.data(media).writeAsString(content);
      await cache.record(media).writeAsString(jsonEncode({'mime': 'application/pdf'}));
    }
    return media;
  }

  test('default off; cached duplicates share a crKey and are placed in the freeboard folder', () async {
    final first = await seed('one', content: 'same');
    final second = await seed('two', content: 'same');
    expect(await buildDriveFilesPayload(store: store, cache: cache), isEmpty);
    final status = <String, String>{};
    final payload = await buildDriveFilesPayload(store: store, cache: cache,
        includeMaterials: false, includeFreeboard: true, freeboardStatuses: status);
    expect(payload.length, 1);
    expect(payload.keys.single, startsWith('자료/과목/자유게시판/'));
    expect(payload.values.single['section'], 'freeboard');
    expect(payload.values.single['crKey'], startsWith('att:freeboard:'));
    expect(status[freeboardAttachmentId('과목:1', first)], contains('전송 대상'));
    expect(status[freeboardAttachmentId('과목:1', second)], contains('전송 대상'));
    final fake = FakeDrive();
    final api = DriveApi('test', transport: fake.call);
    final state = <String, dynamic>{'cleanup066': true, 'cleanup066c': true};
    final documents = {startDocument: 'start'};
    await uploadDriveDocuments(api: api, state: state, documents: documents,
        fileEntries: payload, checkpoint: () async {});
    final folder = fake.files.values.singleWhere((f) => f['name'] == '자유게시판');
    final uploaded = fake.files.values.singleWhere((f) =>
        (f['appProperties'] as Map?)?['crKey'] == payload.values.single['crKey']);
    expect(uploaded['parents'], [folder['id']]);
    final count = fake.files.length;
    await uploadDriveDocuments(api: api, state: state, documents: documents,
        fileEntries: payload, checkpoint: () async {});
    expect(fake.files.length, count);
  });

  test('different files with the same name cannot overwrite a payload entry', () async {
    for (final id in ['a', 'b']) {
      final media = CampusMedia(name: 'same.pdf', url: 'https://dcs-learning.cnu.ac.kr/file/$id');
      await store.saveFreeboardPost(CampusFreeboardPost(
        id: id, courseId: 'c', classNo: '1', course: '과목', title: id,
        context: {}, media: [media], bodyFetched: true,
      ));
      await cache.data(media).writeAsString(id);
      await cache.record(media).writeAsString(jsonEncode({'mime': 'application/pdf'}));
    }
    final payload = await buildDriveFilesPayload(store: store, cache: cache,
        includeMaterials: false, includeFreeboard: true);
    expect(payload.length, 2);
    expect(payload.values.map((e) => e['crKey']).toSet().length, 2);
  });

  test('normal and freeboard attachments share the total byte budget', () async {
    const normal = CampusMedia(name: 'normal.pdf', url: 'https://dcs-learning.cnu.ac.kr/file/normal');
    await cache.data(normal).writeAsString('1234');
    await cache.record(normal).writeAsString(jsonEncode({'mime': 'application/pdf'}));
    final item = CampusItem(
      key: 'LS:c:1:n', type: 'LS', title: '자료', course: '과목',
      courseId: 'c', classNo: '1', contentsId: 'n', status: 'available',
      context: {}, media: [normal],
    );
    await store.db.insert('items', {'id': item.key, 'payload': jsonEncode(item.toJson())});
    final freeboard = await seed('board', content: '5678');
    final status = <String, String>{};
    final payload = await buildDriveFilesPayload(store: store, cache: cache,
        includeFreeboard: true, maxTotalBytes: 4, maxSingleFileBytes: 25 * 1024 * 1024, freeboardStatuses: status);
    expect(payload.length, 1);
    expect(payload.values.single['section'], isNot('freeboard'));
    expect(status[freeboardAttachmentId('과목:1', freeboard)], contains('합산'));
  });

  test('missing, oversized, total limit and unselected files have truthful status', () async {
    final missing = await seed('missing');
    final huge = await seed('huge', content: 'huge');
    final handle = await cache.data(huge).open(mode: FileMode.write);
    await handle.truncate(25 * 1024 * 1024 + 1);
    await handle.close();
    await seed('ok1', content: '1234');
    await seed('ok2', content: '5678');
    await seed('unselected', course: '다른과목', content: 'x');
    final status = <String, String>{};
    final payload = await buildDriveFilesPayload(store: store, cache: cache,
        includeMaterials: false, includeFreeboard: true, selectedCourses: {'과목'},
        maxTotalBytes: 4, maxSingleFileBytes: 25 * 1024 * 1024, freeboardStatuses: status);
    expect(payload.length, 1);
    expect(status[freeboardAttachmentId('과목:1', missing)], contains('기기에 받은 첨부가 없어요'));
    expect(status[freeboardAttachmentId('과목:1', huge)], contains('25MB'));
    expect(status.values.any((s) => s.contains('총') && s.contains('한도 초과')), true);
    expect(status.length, 4);
    final exported = await buildAcademicExport(store, '0123456789abcdef0123456789abcdef',
        exportFreeboard: true, selectedCourses: {'과목'}, freeboardOriginals: status);
    final text = exported.documents['과목/과목_자유게시판.txt']!;
    expect(text, contains('Drive 원본 없음 (기기에 받은 첨부가 없어요)'));
    expect(text, contains('Drive 원본 전송 대상: 자료/과목/자유게시판/'));
    expect(text, isNot(contains('https://dcs-learning')));
  });
}

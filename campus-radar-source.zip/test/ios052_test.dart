import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/ios_timetable.dart';
import 'package:campus_radar/timetable_model.dart';
import 'package:campus_radar/timetable_exceptions.dart';
import 'package:campus_radar/calendar_window.dart';

void main() {
  const slot = ClassSlot(
    courseKey: 'test',
    course: '프로그래밍',
    weekday: 1,
    start: 600,
    end: 660,
  );
  final now = DateTime.utc(2026, 10, 25, 12); // Sunday 21:00 KST
  final settings = {
    'enabled': true,
    'midnight': true,
    'lead': 30,
    'until': '2026-12-31',
  };
  test(
    'iOS dated reservations exclude cancelled class and retain next week',
    () {
      final alerts = iosClassAlerts(
        [slot],
        [ClassCancellation('c', slot.id, '2026-10-26', slot.course, 'notice')],
        settings,
        [],
        {},
        now,
      );
      final classes = alerts.where((a) => a.payload == '_timetable').toList();
      expect(classes.length, 1);
      expect(classes.single.at, DateTime.utc(2026, 11, 2, 0, 30));
      expect(
        alerts.where((a) => a.title == '오늘의 수업·마감').first.body,
        contains('수업 0개'),
      );
    },
  );
  test('iOS bounded nearest reservations, toggle off, and semester end', () {
    final slots = [
      for (var day = 1; day <= 7; day++)
        for (var hour = 8; hour <= 18; hour++)
          ClassSlot(
            courseKey: '$day:$hour',
            course: '수업',
            weekday: day,
            start: hour * 60,
            end: hour * 60 + 50,
          ),
    ];
    final alerts = iosClassAlerts(slots, [], settings, [], {}, now);
    expect(alerts.length, 24);
    expect(alerts.every((a) => a.at.isAfter(now)), isTrue);
    expect(
      iosClassAlerts(
        slots,
        [],
        {...settings, 'enabled': false, 'midnight': false},
        [],
        {},
        now,
      ),
      isEmpty,
    );
    expect(
      iosClassAlerts(
        slots,
        [],
        {...settings, 'until': '2026-10-24'},
        [],
        {},
        now,
      ),
      isEmpty,
    );
  });
  test('AI calendar 23:59 remains on same Korean date', () {
    final at = DateTime.utc(2026, 10, 27, 14, 59);
    final window = calendarWindow(at, allDay: false);
    expect(window.$2, at);
    expect(window.$1, at.subtract(const Duration(minutes: 10)));
  });
}

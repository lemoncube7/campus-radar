import 'package:campus_radar/campus_models.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/ios_features.dart';

CampusItem row(
  String key, {
  DateTime? starts,
  DateTime? due,
  bool published = true,
  String status = 'pending',
}) => CampusItem(
  key: key,
  type: 'LR',
  title: key,
  course: '가상 수업',
  courseId: 'c',
  classNo: '1',
  contentsId: key,
  status: status,
  context: {},
  startsAt: starts,
  due: due,
  published: published,
);
void main() {
  test(
    'iOS daily schedule reserves seven future occurrences across year boundary',
    () {
      final now = DateTime(2026, 12, 31, 18, 0);
      final times = iosDailyTimes(now, 18, 0);
      expect(times, hasLength(7));
      expect(times.first, DateTime(2027, 1, 1, 18));
      expect(times.last, DateTime(2027, 1, 7, 18));
      expect(
        iosDailyTimes(DateTime(2026, 10, 15, 17), 18, 0).first,
        DateTime(2026, 10, 15, 18),
      );
    },
  );
  test(
    'iOS summary filters unpublished, not-started, excluded and completed tasks',
    () {
      final now = DateTime.utc(2026, 10, 15, 9);
      final rows = [
        row('shown', due: now.add(const Duration(hours: 1))),
        row('future', starts: now.add(const Duration(hours: 1))),
        row('unpublished', published: false),
        row('excluded'),
        row('done', status: 'done'),
      ];
      final body = iosDailyBody(
        rows,
        {'excluded'},
        {'shown': now},
        now,
        now.toIso8601String(),
      );
      expect(body, contains('전체 미완료 1개'));
      expect(body, contains('오늘 마감 1개'));
      expect(body, contains('오늘 새 과제 1개'));
      expect(body, contains('마지막 수집 기준'));
    },
  );
}

import 'dart:io';
import 'package:flutter_test/flutter_test.dart';

/// lib/ source files by file name. Names are unique across the feature
/// folders, so the dependency graph below stays keyed by file name.
Map<String, File> libFiles() => {
  for (final f
      in Directory('lib')
          .listSync(recursive: true)
          .whereType<File>()
          .where((f) => f.path.endsWith('.dart')))
    f.uri.pathSegments.last: f,
};

Map<String, Set<String>> localImports() {
  final files = libFiles();
  // Only this app's files: package:campus_radar/... or a plain relative path
  // (other packages such as package:flutter/services.dart share names).
  final pattern = RegExp(
    r"^(?:import|export) '(?:package:campus_radar/)?([^':]+)'",
    multiLine: true,
  );
  return {
    for (final entry in files.entries)
      entry.key: pattern
          .allMatches(entry.value.readAsStringSync())
          .map((m) => m[1]!.split('/').last)
          .where(files.containsKey)
          .toSet(),
  };
}

void main() {
  test(
    'Foundation dependencies cannot reach screens or the sync coordinator',
    () {
      final graph = localImports();
      const roots = [
        'app_storage.dart',
        'app_credentials.dart',
        'native_bridge.dart',
        'notification_gateway.dart',
        'app_logging.dart',
        'session_scope.dart',
        'campus_models.dart',
        'course_labels.dart',
        'course_catalog.dart',
        'background_contract.dart',
        'account_service.dart',
      ];
      for (final root in roots) {
        final seen = <String>{};
        void visit(String file) {
          if (!seen.add(file)) return;
          expect(
            file == 'main.dart' ||
                file == 'services.dart' ||
                file.endsWith('_page.dart') ||
                file.endsWith('_pages.dart'),
            isFalse,
            reason: '$root must not depend on $file',
          );
          for (final dependency in graph[file] ?? <String>{}) {
            visit(dependency);
          }
        }

        visit(root);
      }
    },
  );
  test('Feature modules do not import the application entry point', () {
    final graph = localImports();
    for (final entry in graph.entries) {
      expect(
        entry.value,
        isNot(contains('main.dart')),
        reason: '${entry.key} should import the actual component or page',
      );
    }
  });
  test('Shared presentation does not depend on persistence or feature pages', () {
    final graph = localImports();
    for (final file in ['task_presentation.dart', 'ui_refresh.dart']) {
      expect(
        graph[file],
        everyElement(
          isIn([
            'campus_models.dart',
            'course_labels.dart',
            'course_colors.dart',
            // Pure card widget (imports only Flutter), shared with course tabs.
            'course_list_card.dart',
          ]),
        ),
        reason:
            '$file should render inputs without storage or navigation responsibilities',
      );
    }
  });
}

import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/campus_media.dart';
import 'package:campus_radar/campus/freeboard_models.dart';
import 'package:campus_radar/campus/freeboard_service.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/courses/freeboard_page.dart';
import 'package:campus_radar/export/academic_export.dart';

class MockFreeboardClient extends CampusClient {
  final Map<String, int> callCounts = {};
  bool failCourse2 = false;

  @override
  Future<dynamic> api(
    String route,
    Map<String, dynamic>? payload, {
    String host = CampusClient.learning,
  }) async {
    callCounts[route] = (callCounts[route] ?? 0) + 1;

    if (route == '/course/addSessionCourseInfo') {
      return {'data': {'session': 'ok'}};
    }

    if (route == '/board/bbs/list/top') {
      final courseId = '${payload?['course_id']}';
      if (courseId == 'c2' && failCourse2) {
        throw CampusException('500 Server Error');
      }
      if (courseId == 'empty') {
        return {'list': []};
      }
      return {
        'list': [
          {
            'boarditem_no': 'post-top-1',
            'boarditem_title': '고정 공지글입니다',
            'insert_dt': '2026-11-01 09:00:00',
            'update_dt': '2026-11-01 09:00:00',
            'course_id': courseId,
            'class_no': '1',
            'file_yn': 'N',
            'delete_yn': 'N',
            'complete_delete_yn': 'N',
            'temp_save_yn': 'N',
            'open_yn': 'Y',
            // Irrelevant writer PII:
            'writer_name': '관리자',
            'writeruser_name': '게시판 표시이름',
            'user_id': 'admin01',
            'tel': '010-0000-0000',
            'email': 'admin@cnu.ac.kr',
          },
        ],
      };
    }

    if (route == '/board/bbs/list') {
      final courseId = '${payload?['course_id']}';
      if (courseId == 'c2' && failCourse2) {
        throw CampusException('500 Server Error');
      }
      if (courseId == 'empty') {
        return {'list': [], 'tot_cnt': 0};
      }

      final offset = payload?['offset'] as int? ?? 0;

      // Course with pagination (> 100 items)
      if (courseId == 'paginated') {
        if (offset == 0) {
          return {
            'tot_cnt': 105,
            'list': [
              // Top post returned in regular list as well (for deduplication test)
              {
                'boarditem_no': 'post-top-1',
                'boarditem_title': '고정 공지글입니다',
                'insert_dt': '2026-11-01 09:00:00',
                'course_id': courseId,
                'class_no': '1',
                'file_yn': 'N',
                'delete_yn': 'N',
                'complete_delete_yn': 'N',
                'temp_save_yn': 'N',
                'open_yn': 'Y',
              },
              for (var i = 1; i < 100; i++)
                {
                  'boarditem_no': 'p-$i',
                  'boarditem_title': '자유글 $i',
                  'insert_dt': '2026-11-02 10:00:00',
                  'course_id': courseId,
                  'class_no': '1',
                  'file_yn': 'N',
                  'delete_yn': 'N',
                  'complete_delete_yn': 'N',
                  'temp_save_yn': 'N',
                  'open_yn': 'Y',
                  'user_nm': '익명',
                  'user_id': 'anon_$i',
                },
            ],
          };
        } else {
          return {
            'tot_cnt': 105,
            'list': [
              for (var i = 100; i < 105; i++)
                {
                  'boarditem_no': 'p-$i',
                  'boarditem_title': '자유글 $i',
                  'insert_dt': '2026-11-03 10:00:00',
                  'course_id': courseId,
                  'class_no': '1',
                  'file_yn': 'N',
                  'delete_yn': 'N',
                  'complete_delete_yn': 'N',
                  'temp_save_yn': 'N',
                  'open_yn': 'Y',
                },
            ],
          };
        }
      }

      // Standard course
      return {
        'tot_cnt': 5,
        'list': [
          // Deduplication: post-top-1 is also in top list
          {
            'boarditem_no': 'post-top-1',
            'boarditem_title': '고정 공지글입니다',
            'insert_dt': '2026-11-01 09:00:00',
            'course_id': courseId,
            'class_no': '1',
            'file_yn': 'N',
            'delete_yn': 'N',
            'complete_delete_yn': 'N',
            'temp_save_yn': 'N',
            'open_yn': 'Y',
          },
          // Valid regular post
          {
            'boarditem_no': 'post-reg-1',
            'boarditem_title': '자유게시판 질문입니다',
            'insert_dt': '2026-11-05 14:00:00',
            'update_dt': '2026-11-05 14:30:00',
            'course_id': courseId,
            'class_no': '1',
            'file_yn': 'Y',
            'delete_yn': 'N',
            'complete_delete_yn': 'N',
            'temp_save_yn': 'N',
            'open_yn': 'Y',
            'writer_name': '학생1',
            'user_no': '12345',
            'email': 'student1@cnu.ac.kr',
          },
          // Deleted post: delete_yn = 'Y'
          {
            'boarditem_no': 'post-del-1',
            'boarditem_title': '삭제된 글',
            'course_id': courseId,
            'class_no': '1',
            'delete_yn': 'Y',
            'open_yn': 'Y',
          },
          // Draft post: temp_save_yn = 'Y'
          {
            'boarditem_no': 'post-draft-1',
            'boarditem_title': '임시저장 글',
            'course_id': courseId,
            'class_no': '1',
            'delete_yn': 'N',
            'temp_save_yn': 'Y',
            'open_yn': 'Y',
          },
          // Private post: open_yn = 'N'
          {
            'boarditem_no': 'post-private-1',
            'boarditem_title': '비공개 글',
            'course_id': courseId,
            'class_no': '1',
            'delete_yn': 'N',
            'temp_save_yn': 'N',
            'open_yn': 'N',
          },
        ],
      };
    }

    if (route == '/board/bbs/info') {
      final no = payload?['no'];
      return {
        'boarditem_no': no,
        'boarditem_content': '<p>자유게시판 상세 내용입니다.</p><img src="/file/image1.png">',
        'update_dt': '2026-11-05 15:00:00',
        'attach_file_list': [
          {
            'file_name': 'lms_lecture.pdf',
            'save_name': '/upload/2026/lms_lecture.pdf',
            'upload_type': 'lms',
            'file_size': 2721431,
          },
          {
            'file_name': 'cms_note.pdf',
            'cms_file_no': '99001',
            'upload_type': 'cms',
            'file_size': 512000,
          },
        ],
      };
    }

    return {};
  }
}

class SchoolDateFreeboardClient extends MockFreeboardClient {
  @override
  Future<dynamic> api(String route, Map<String, dynamic>? payload, {
    String host = CampusClient.learning,
  }) async {
    final result = await super.api(route, payload, host: host);
    if (result is Map && result['list'] is List) {
      for (final row in result['list'] as List) {
        row['insert_dt'] = '2026-11-06';
        row['insert_dt_addtime'] = '2026-11-06 20:50';
      }
    }
    return result;
  }
}

class EndlessFreeboardClient extends MockFreeboardClient {
  @override
  Future<dynamic> api(String route, Map<String, dynamic>? payload, {
    String host = CampusClient.learning,
  }) async {
    if (route == '/board/bbs/list') {
      callCounts[route] = (callCounts[route] ?? 0) + 1;
      return {'list': List.generate(100, (i) => {
        'boarditem_no': 'same-$i', 'boarditem_title': '반복 목록',
      })};
    }
    return super.api(route, payload, host: host);
  }
}

class AttachmentOnlyFreeboardClient extends MockFreeboardClient {
  @override
  Future<dynamic> api(String route, Map<String, dynamic>? payload, {
    String host = CampusClient.learning,
  }) async {
    if (route == '/board/bbs/info') {
      return {'attach_file_list': [{
        'file_name': '첨부전용.pdf', 'save_name': '/upload/only.pdf',
        'upload_type': 'lms',
      }]};
    }
    return super.api(route, payload, host: host);
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;

  late Store store;
  late Directory tempDir;

  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    tempDir = await Directory.systemTemp.createTemp('freeboard-test-');
    await databaseFactory.setDatabasesPath(tempDir.path);
    store = await Store.open();
  });

  tearDown(() async {
    await store.db.close();
    await tempDir.delete(recursive: true);
  });

  group('Freeboard API and Schema', () {
    test('detail budget does not stop later course lists or falsely mark them complete', () async {
      final client = MockFreeboardClient();
      addTearDown(client.close);
      final courses = [
        {'course_id': 'c1', 'class_no': '1', 'course_nm': '과목1'},
        {'course_id': 'c2', 'class_no': '1', 'course_nm': '과목2'},
      ];
      final completed = await FreeboardService.prepareExportBodies(store, client,
          courses, maxDetails: 1);
      expect(await store.freeboardPosts('c2:1'), isNotEmpty);
      expect(completed, isEmpty);
      expect(client.callCounts['/board/bbs/info'], 1);
      expect(client.callCounts['/course/addSessionCourseInfo'], 2);
      final retry = await FreeboardService.prepareExportBodies(store, client, courses);
      expect(retry, {'c1:1', 'c2:1'});
      expect((await store.freeboardPosts()).every((p) => p.bodyFetched), true);
      expect(client.callCounts['/course/addSessionCourseInfo'], 4);
    });

    test('zero detail budget still lists courses and marks only cached/empty ones complete', () async {
      final client = MockFreeboardClient();
      addTearDown(client.close);
      final completed = await FreeboardService.prepareExportBodies(store, client, [
        {'course_id': 'c1', 'class_no': '1', 'course_nm': '과목1'},
        {'course_id': 'empty', 'class_no': '1', 'course_nm': '빈 과목'},
      ], maxDetails: 0);
      expect(completed, {'empty:1'});
      expect(client.callCounts['/board/bbs/list'], 2);
      expect(client.callCounts['/board/bbs/info'] ?? 0, 0);
    });

    test('repeat-filled pagination stops after five pages and retains the old cache', () async {
      final client = EndlessFreeboardClient();
      addTearDown(client.close);
      const old = CampusFreeboardPost(id: 'old', courseId: 'c1', classNo: '1',
          course: '과목1', title: '기존 글', context: {});
      await store.saveFreeboardPost(old);
      await expectLater(FreeboardService.syncCourseFreeboard(store, client,
          {'course_id': 'c1', 'class_no': '1'}), throwsA(isA<CampusException>()));
      expect(client.callCounts['/board/bbs/list'], 5);
      expect((await store.freeboardPosts('c1:1')).single.id, 'old');
    });

    test('attachment-only detail is successful and remains visible', () async {
      final client = AttachmentOnlyFreeboardClient();
      addTearDown(client.close);
      const post = CampusFreeboardPost(id: 'file', courseId: 'c1', classNo: '1',
          course: '과목1', title: '첨부 전용 글', context: {});
      final detail = await client.fetchFreeboardDetail(post);
      expect(detail.bodyFetched, true);
      expect(detail.body, isEmpty);
      expect(detail.media.single.name, '첨부전용.pdf');
    });

    test('version 3 storage adds a course index without dropping cached posts', () async {
      const post = CampusFreeboardPost(id: 'keep', courseId: 'c1', classNo: '1',
          course: '과목1', title: '보존 글', context: {});
      await store.saveFreeboardPost(post);
      await store.db.execute('DROP INDEX idx_freeboard_course_key');
      await store.db.setVersion(3);
      await store.db.close();
      store = await Store.open();
      expect(await store.db.getVersion(), 4);
      expect((await store.freeboardPosts('c1:1')).single.id, 'keep');
      final plan = await store.db.rawQuery(
          'EXPLAIN QUERY PLAN SELECT * FROM freeboard_posts WHERE course_key = ?', ['c1:1']);
      expect(plan.toString(), contains('idx_freeboard_course_key'));
    });
    test('opt-in still creates a document for an unfetched body', () async {
      await store.setMeta('lastSuccess', DateTime.now().toUtc().toIso8601String());
      await store.saveFreeboardPost(const CampusFreeboardPost(
        id: 'unfetched', courseId: 'c1', classNo: '1', course: '과목1',
        title: '미수집 글', context: {},
      ));
      final export = await buildAcademicExport(store,
          '0123456789abcdef0123456789abcdef', exportFreeboard: true,
          selectedCourses: {'과목1'});
      expect(export.documents['과목/과목1_자유게시판.txt'], contains('본문 미수집'));
    });
    test('opt-in preparation loads missing bodies without attachment downloads', () async {
      final client = MockFreeboardClient();
      addTearDown(client.close);
      await FreeboardService.prepareExportBodies(store, client, [
        {'course_id': 'c1', 'class_no': '1', 'course_nm': '과목1'},
      ], maxDetails: 1);
      final posts = await store.freeboardPosts('c1:1');
      expect(posts.where((p) => p.bodyFetched).length, 1);
      expect(client.callCounts['/board/bbs/info'], 1);
    });

    test('freeboard export defaults off and is scoped opt-in text only', () async {
      await store.setMeta('lastSuccess', DateTime.now().toUtc().toIso8601String());
      for (final course in ['과목1', '과목2']) {
        await store.saveFreeboardPost(CampusFreeboardPost(
          id: 'p', courseId: course, classNo: '1', course: course,
          title: '$course 질문', author: '표시이름', body: '자유게시판 본문',
          media: const [CampusMedia(name: '참고.pdf', url: 'https://dcs-learning.cnu.ac.kr/file/private-token')],
          bodyFetched: true, published: DateTime.utc(2026, 11, 6, 11, 50),
          context: {'course_id': course, 'class_no': '1'},
        ));
      }
      const profile = '0123456789abcdef0123456789abcdef';
      final off = await buildAcademicExport(store, profile);
      expect(off.documents.keys.any((k) => k.endsWith('_자유게시판.txt')), false);
      final on = await buildAcademicExport(store, profile,
          exportFreeboard: true, selectedCourses: {'과목1'});
      final text = on.documents['과목/과목1_자유게시판.txt']!;
      expect(text, contains('작성자: 표시이름'));
      expect(text, contains('2026/11/6 20:50'));
      expect(text, contains('자유게시판 본문'));
      expect(text, contains('첨부 이름: 참고.pdf'));
      expect(text, isNot(contains('private-token')));
      expect(on.documents.containsKey('과목/과목2_자유게시판.txt'), false);
      expect(on.originals, isEmpty);
      final disabled = await buildAcademicExport(store, profile, exportFreeboard: false);
      expect(disabled.documents.keys.any((k) => k.endsWith('_자유게시판.txt')), false);
    });
    test('school date-only and addtime fields populate pinned and normal dates', () async {
      final client = SchoolDateFreeboardClient();
      addTearDown(client.close);
      final posts = await client.fetchFreeboardPosts({'course_id': 'c1', 'class_no': '1'});
      expect(posts.any((p) => p.isPinned), true);
      expect(posts.any((p) => !p.isPinned), true);
      for (final post in posts) {
        expect(post.published, DateTime.utc(2026, 11, 6, 11, 50));
      }
    });

    test('freeboard date prefers addtime and falls back to KST date-only or old datetime', () {
      expect(freeboardDate({'insert_dt': '2026-11-06'}, 'insert_dt'),
          DateTime.utc(2026, 11, 5, 15));
      expect(freeboardDate({'insert_dt': '2026-11-06 09:14:30'}, 'insert_dt'),
          DateTime.utc(2026, 11, 6, 0, 14, 30));
      expect(freeboardDate({'update_dt_addtime': '2026-11-07 10:20'}, 'update_dt'),
          DateTime.utc(2026, 11, 7, 1, 20));
      expect(freeboardDate({'insert_dt': 'invalid'}, 'insert_dt'), isNull);
      expect(freeboardDate({}, 'insert_dt'), isNull);
    });

    test('addtime changes invalidate the freeboard list fingerprint', () {
      final row = {'boarditem_no': 'p', 'insert_dt': '2026-11-06'};
      expect(freeboardListSignature(row), isNot(freeboardListSignature({
        ...row, 'insert_dt_addtime': '2026-11-06 20:50',
      })));
    });
    test('version 2 storage upgrades without losing existing data', () async {
      await store.setMeta('migrationMarker', 'keep');
      await store.db.execute('DROP TABLE freeboard_posts');
      await store.db.setVersion(2);
      await store.db.close();
      store = await Store.open();
      expect(await store.db.getVersion(), 4);
      expect(await store.meta('migrationMarker'), 'keep');
      expect(await store.freeboardPosts(), isEmpty);
    });
    test('paginated list fetches all pages (>100 posts) and respects limit=100', () async {
      final client = MockFreeboardClient();
      addTearDown(client.close);

      final posts = await client.fetchFreeboardPosts(
        {
          'course_id': 'paginated',
          'class_no': '1',
          'term_year': '2026',
          'term_cd': '2',
        },
        courseName: '대형 강좌',
      );

      expect(posts.length, 105);
      // Pinned post is first
      expect(posts.first.id, 'post-top-1');
      expect(posts.first.isPinned, isTrue);
      // Calls to /board/bbs/list were paginated
      expect(client.callCounts['/board/bbs/list'], 2);
    });

    test('top-pinned deduplication keeps top post once and marks isPinned', () async {
      final client = MockFreeboardClient();
      addTearDown(client.close);

      final posts = await client.fetchFreeboardPosts(
        {
          'course_id': 'c1',
          'class_no': '1',
          'term_year': '2026',
          'term_cd': '2',
        },
        courseName: '컴퓨터프로그래밍',
      );

      // post-top-1 was returned by both /top and /list, but must appear only once!
      final ids = posts.map((p) => p.id).toList();
      expect(ids.where((id) => id == 'post-top-1').length, 1);
      final topPost = posts.firstWhere((p) => p.id == 'post-top-1');
      expect(topPost.isPinned, isTrue);
    });

    test('filtering surfaces only public, nondeleted, nondraft posts', () async {
      final client = MockFreeboardClient();
      addTearDown(client.close);

      final posts = await client.fetchFreeboardPosts(
        {
          'course_id': 'c1',
          'class_no': '1',
          'term_year': '2026',
          'term_cd': '2',
        },
      );

      final ids = posts.map((p) => p.id).toSet();
      expect(ids.contains('post-del-1'), isFalse, reason: 'delete_yn=Y must be omitted');
      expect(ids.contains('post-draft-1'), isFalse, reason: 'temp_save_yn=Y must be omitted');
      expect(ids.contains('post-private-1'), isFalse, reason: 'open_yn=N must be omitted');
      expect(ids.contains('post-reg-1'), isTrue);
    });

    test('writer identifiers and contacts are excluded, only display name is stored', () async {
      final client = MockFreeboardClient();
      addTearDown(client.close);

      final posts = await client.fetchFreeboardPosts(
        {
          'course_id': 'c1',
          'class_no': '1',
          'term_year': '2026',
          'term_cd': '2',
        },
        courseName: '데이터베이스',
      );

      await store.replaceCourseFreeboardPosts('c1:1', posts);

      final loaded = await store.freeboardPosts('c1:1');
      expect(loaded.isNotEmpty, isTrue);
      expect(loaded.firstWhere((p) => p.isPinned).author, '게시판 표시이름');

      for (final p in loaded) {
        final jsonStr = jsonEncode(p.toJson());
        expect(jsonStr, isNot(contains('홍길동')));
        expect(jsonStr, isNot(contains('student1@cnu.ac.kr')));
        expect(jsonStr, isNot(contains('010-0000-0000')));
        expect(jsonStr, isNot(contains('admin01')));
        expect(jsonStr, isNot(contains('12345')));
        expect(jsonStr, isNot(contains('writer_name')));
        expect(jsonStr, isNot(contains('user_id')));
        expect(jsonStr, isNot(contains('user_no')));
      }
    });

    test('same post IDs across courses and source namespaces do not collide', () async {
      // Course 1 has post ID "shared-99"
      final post1 = CampusFreeboardPost(
        id: 'shared-99',
        courseId: 'c1',
        classNo: '1',
        course: '수업1',
        title: '수업1의 질문',
        context: {'course_id': 'c1', 'class_no': '1'},
      );

      // Course 2 has post ID "shared-99"
      final post2 = CampusFreeboardPost(
        id: 'shared-99',
        courseId: 'c2',
        classNo: '1',
        course: '수업2',
        title: '수업2의 질문',
        context: {'course_id': 'c2', 'class_no': '1'},
      );

      // Notice has ID "shared-99"
      final notice = CampusNotice(
        id: 'shared-99',
        title: '공지사항 99',
        course: '수업1',
        context: {'course_id': 'c1', 'class_no': '1'},
      );

      await store.saveFreeboardPost(post1);
      await store.saveFreeboardPost(post2);
      await store.saveNotice(notice);

      final c1Posts = await store.freeboardPosts('c1:1');
      final c2Posts = await store.freeboardPosts('c2:1');
      final notices = await store.notices();

      expect(c1Posts.length, 1);
      expect(c1Posts.first.title, '수업1의 질문');
      expect(c1Posts.first.key, 'FB:c1:1:shared-99');

      expect(c2Posts.length, 1);
      expect(c2Posts.first.title, '수업2의 질문');
      expect(c2Posts.first.key, 'FB:c2:1:shared-99');

      expect(notices.length, 1);
      expect(notices.first.title, '공지사항 99');
      expect(notices.first.id, 'shared-99');
    });

    test('empty board returns empty list and is represented correctly', () async {
      final client = MockFreeboardClient();
      addTearDown(client.close);

      final posts = await client.fetchFreeboardPosts(
        {
          'course_id': 'empty',
          'class_no': '1',
          'term_year': '2026',
          'term_cd': '2',
        },
        courseName: '빈 게시판 과목',
      );

      expect(posts, isEmpty);

      await store.replaceCourseFreeboardPosts('empty:1', posts);
      final loaded = await store.freeboardPosts('empty:1');
      expect(loaded, isEmpty);
      expect(await store.meta('freeboardChecked:empty:1'), isNotNull);
    });

    test('detail HTML rendering and media extraction (LMS and CMS)', () async {
      final client = MockFreeboardClient();
      addTearDown(client.close);

      const initial = CampusFreeboardPost(
        id: 'post-reg-1',
        courseId: 'c1',
        classNo: '1',
        course: '테스트 과목',
        title: '자유게시판 질문입니다',
        context: {'course_id': 'c1', 'class_no': '1'},
      );

      final detail = await client.fetchFreeboardDetail(initial);

      expect(detail.bodyFetched, isTrue);
      expect(detail.body, contains('자유게시판 상세 내용입니다.'));
      expect(detail.bodyHtml, contains('<p>자유게시판 상세 내용입니다.</p>'));

      // Check media extracted:
      // 1 inline image, 1 LMS attachment (2.7MB), 1 CMS attachment
      expect(detail.media.length, 3);

      final inlineImage = detail.media.firstWhere((m) => m.image);
      expect(inlineImage.url, 'https://dcs-learning.cnu.ac.kr/file/image1.png');

      final lmsPdf = detail.media.firstWhere((m) => m.name == 'lms_lecture.pdf');
      expect(lmsPdf.url, 'https://dcs-learning.cnu.ac.kr/file/upload/2026/lms_lecture.pdf');
      expect(lmsPdf.size, 2721431);

      final cmsPdf = detail.media.firstWhere((m) => m.name == 'cms_note.pdf');
      expect(cmsPdf.url, 'https://dcs-lcms.cnu.ac.kr/api/v1/file/downloadSingleFile');
      expect(cmsPdf.form, {'file_no': '99001'});
      expect(cmsPdf.size, 512000);
    });

    test('detail reuse keeps unchanged body and attachments across refreshes', () async {
      final client = MockFreeboardClient();
      addTearDown(client.close);

      // First fetch: list
      final posts1 = await client.fetchFreeboardPosts({
        'course_id': 'c1',
        'class_no': '1',
        'term_year': '2026',
        'term_cd': '2',
      });
      final regPost = posts1.firstWhere((p) => p.id == 'post-reg-1');

      // Fetch detail once
      final withDetail = await client.fetchFreeboardDetail(regPost);
      expect(client.callCounts['/board/bbs/info'], 1);

      // Save to store
      await store.saveFreeboardPost(withDetail);

      // Second list fetch with previous posts map
      final cachedMap = {withDetail.key: withDetail};
      final posts2 = await client.fetchFreeboardPosts(
        {
          'course_id': 'c1',
          'class_no': '1',
          'term_year': '2026',
          'term_cd': '2',
        },
        previous: cachedMap,
      );

      final reused = posts2.firstWhere((p) => p.id == 'post-reg-1');
      expect(reused.bodyFetched, isTrue);
      expect(reused.body, contains('자유게시판 상세 내용입니다.'));
      expect(reused.media.length, 3);
      // No extra /board/bbs/info call made!
      expect(client.callCounts['/board/bbs/info'], 1);
    });

    test('partial failure retains previous per-course data', () async {
      final client = MockFreeboardClient();
      addTearDown(client.close);

      // Seed initial data for course 2
      final oldPost = CampusFreeboardPost(
        id: 'old-c2-1',
        courseId: 'c2',
        classNo: '1',
        course: '과목2',
        title: '이전 글',
        context: {'course_id': 'c2', 'class_no': '1'},
      );
      await store.replaceCourseFreeboardPosts('c2:1', [oldPost]);

      // Make course 2 fail during sync
      client.failCourse2 = true;

      final courses = [
        {'course_id': 'c1', 'class_no': '1', 'course_nm': '과목1'},
        {'course_id': 'c2', 'class_no': '1', 'course_nm': '과목2'},
      ];

      final results = await FreeboardService.syncAllCourseFreeboards(
        store,
        client,
        courses,
      );

      // Course 1 succeeded
      expect(results['c1:1']!.isNotEmpty, isTrue);

      // Course 2 failed, so previous data was retained!
      expect(results['c2:1']!.length, 1);
      expect(results['c2:1']!.first.id, 'old-c2-1');

      final c2InStore = await store.freeboardPosts('c2:1');
      expect(c2InStore.length, 1);
      expect(c2InStore.first.id, 'old-c2-1');
    });

    test('school shortcuts generate correct URLs for board and detail', () async {
      final client = MockFreeboardClient();
      addTearDown(client.close);

      final courseContext = {
        'term_year': '2026',
        'term_cd': '2',
        'course_id': 'c1',
        'class_no': '1',
      };

      // Board shortcut
      final boardNav = await client.freeboardNavigation(courseContext);
      expect(boardNav['url'], 'https://dcs-learning.cnu.ac.kr/std/board');

      // Post detail shortcut
      final detailNav = await client.freeboardNavigation(
        courseContext,
        postId: 'post-123',
      );
      expect(detailNav['url'], 'https://dcs-learning.cnu.ac.kr/std/boardDetail?no=post-123');
      expect(detailNav['target'], 'post-123');
    });

    test('freeboard posts are excluded from items, homework counts, notices, and Drive export', () async {
      final post = CampusFreeboardPost(
        id: 'fb-1',
        courseId: 'c1',
        classNo: '1',
        course: '테스트 과목',
        title: '자유게시판 질문',
        context: {'course_id': 'c1', 'class_no': '1'},
      );
      await store.saveFreeboardPost(post);

      // Must NOT be in items
      final items = await store.items();
      expect(items.any((i) => i.key.contains('fb-1')), isFalse);

      // Must NOT be in notices
      final notices = await store.notices();
      expect(notices.any((n) => n.id == 'fb-1'), isFalse);

      // Must NOT appear in academic export
      await store.setMeta('lastSuccess', DateTime.now().toUtc().toIso8601String());
      await store.setMeta('courses', jsonEncode([
        {'course_id': 'c1', 'class_no': '1', 'course_nm': '테스트 과목'},
      ]));
      final exportDoc = await buildAcademicExport(
        store,
        '0123456789abcdef0123456789abcdef',
      );
      final allText = exportDoc.documents.values.join('\n');
      expect(allText, isNot(contains('자유게시판 질문')));
    });
  });

  group('Freeboard UI Widgets', () {
    testWidgets('CourseFreeboardView renders list with pinned badge, title, date', (tester) async {
      final post1 = CampusFreeboardPost(
        id: 'p1',
        courseId: 'c1',
        classNo: '1',
        course: '소프트웨어공학',
        title: '필독: 프로젝트 안내',
        published: DateTime.parse('2026-11-01T12:00:00Z'),
        isPinned: true,
        hasAttachment: true,
        context: {'course_id': 'c1', 'class_no': '1'},
      );

      final post2 = CampusFreeboardPost(
        id: 'p2',
        courseId: 'c1',
        classNo: '1',
        course: '소프트웨어공학',
        title: '팀원 구합니다',
        published: DateTime.parse('2026-11-05T14:30:00Z'),
        isPinned: false,
        hasAttachment: false,
        context: {'course_id': 'c1', 'class_no': '1'},
      );

      await tester.runAsync(
        () => store.replaceCourseFreeboardPosts('c1:1', [post1, post2]),
      );

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CourseFreeboardView(
              course: const {
                'course_id': 'c1',
                'class_no': '1',
                'course_nm': '소프트웨어공학',
              },
            ),
          ),
        ),
      );

      await tester.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 500)));
      await tester.pumpAndSettle();

      expect(find.text('자유게시판 2개'), findsOneWidget);
      expect(find.text('필독: 프로젝트 안내'), findsOneWidget);
      expect(find.text('고정'), findsOneWidget);
      expect(find.text('팀원 구합니다'), findsOneWidget);
      expect(find.text('자유'), findsOneWidget);
      expect(find.text('원문 바로가기'), findsOneWidget);
      await tester.pumpWidget(const SizedBox.shrink());
      await tester.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 100)));
    });

    testWidgets('CourseFreeboardView displays empty board message when 0 posts', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CourseFreeboardView(
              course: const {
                'course_id': 'empty',
                'class_no': '1',
                'course_nm': '빈 과목',
              },
            ),
          ),
        ),
      );

      await tester.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 500)));
      await tester.pumpAndSettle();
      expect(find.text('등록된 자유게시판 글이 없어요.'), findsOneWidget);
      expect(find.text('새 글 확인'), findsOneWidget);
    });

    testWidgets('FreeboardDetailPage renders post content, media, and school button', (tester) async {
      const post = CampusFreeboardPost(
        id: 'p-detail',
        courseId: 'c1',
        classNo: '1',
        course: '알고리즘',
        title: '다익스트라 알고리즘 질문',
        body: '다익스트라에서 우선순위 큐 구현 질문입니다.',
        bodyHtml: '<p>다익스트라에서 우선순위 큐 구현 질문입니다.</p>',
        bodyFetched: true,
        context: {'course_id': 'c1', 'class_no': '1'},
      );

      await tester.pumpWidget(
        const MaterialApp(
          home: FreeboardDetailPage(post: post),
        ),
      );

      await tester.pumpAndSettle();

      expect(find.text('다익스트라 알고리즘 질문'), findsOneWidget);
      expect(find.text('다익스트라에서 우선순위 큐 구현 질문입니다.'), findsOneWidget);
      expect(find.text('사이버캠퍼스 열기'), findsOneWidget);
      expect(find.textContaining('댓글 작성·조회 및 글쓰기는 사이버캠퍼스 원문에서 확인해 주세요.'), findsOneWidget);
    });
  });
}

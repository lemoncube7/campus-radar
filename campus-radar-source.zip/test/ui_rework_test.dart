import 'package:campus_radar/background_status_page.dart';
import 'package:campus_radar/ai_settings_page.dart';
import 'dart:io';
import 'dart:convert';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/ai_turn_queue.dart';
import 'package:campus_radar/ai_request_budget.dart';
import 'package:campus_radar/ai_protocol.dart';
import 'package:campus_radar/app_storage.dart';
import 'package:campus_radar/chat_threads.dart';
import 'package:campus_radar/diagnostic_export.dart';
import 'package:campus_radar/syllabus_loader.dart';
import 'package:campus_radar/syllabus_reader.dart';
import 'package:campus_radar/notification_settings_page.dart';
import 'package:campus_radar/settings_page.dart';
import 'package:campus_radar/ai_chat_page.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    temp = await Directory.systemTemp.createTemp('ui-rework-');
    await databaseFactory.setDatabasesPath(temp.path);
    final initialStore = await Store.open();
    await initialStore.db.close();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('campus_radar/native'),
          (call) async => call.method == 'timetableSettings'
              ? {'until': '2099-12-31', 'exactAllowed': true}
              : null,
        );
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          (call) async => null,
        );
  });
  tearDown(() async {
    await temp.delete(recursive: true);
  });

  test('diagnostic defaults exclude details and redact credentials and URLs', () {
    final rows = [
      {
        'at': '2026-10-29T01:00:00Z',
        'kind': 'sync',
        'title': '수집 실패',
        'detail':
            'private assignment\npassword=secret\nCookie: abc\nhttps://school.example/a?token=x',
      },
    ];
    final safe = diagnosticReport(
      rows,
      platform: 'Android test',
      generatedAt: DateTime.utc(2026),
    );
    expect(safe, contains('수집 실패'));
    expect(safe, isNot(contains('private assignment')));
    final detail = diagnosticReport(
      rows,
      platform: 'test',
      generatedAt: DateTime.utc(2026),
      includeDetails: true,
    );
    for (final secret in ['secret', 'abc', 'school.example']) {
      expect(detail, isNot(contains(secret)));
    }
    expect(detail, contains('private assignment'));
  });
  test(
    'syllabus preserves table rows and rejects malformed or oversized structures',
    () {
      final rows = [
        [
          ['평가', '중간 40%'],
          ['1주', '소개\n실습'],
        ],
      ];
      expect(parseSyllabusTables(jsonEncode(rows)), rows);
      expect(
        parseSyllabusTables([
          [123],
        ]),
        isEmpty,
      );
      expect(
        parseSyllabusTables([
          [
            ['a' * 6001],
          ],
        ]),
        isEmpty,
      );
      expect(parseSyllabusTables('not json'), isEmpty);
    },
  );
  test(
    'busy AI waits then claims once; unrelated failures are not retried',
    () async {
      var attempts = 0, waits = 0, checks = 0;
      await waitForAiTurn(
        claim: () async {
          if (++attempts < 3) throw const AiFailure('busy', code: 'busy');
        },
        verify: () async {
          checks++;
        },
        cancelled: () => false,
        onWaiting: () {
          waits++;
        },
        delay: (_) async {},
      );
      expect(attempts, 3);
      expect(waits, 2);
      expect(checks, 3);
      attempts = 0;
      await expectLater(
        waitForAiTurn(
          claim: () async {
            attempts++;
            throw const AiFailure('invalid', code: 'credentials');
          },
          verify: () async {},
          cancelled: () => false,
          delay: (_) async {},
        ),
        throwsA(isA<AiFailure>().having((e) => e.code, 'code', 'credentials')),
      );
      expect(attempts, 1);
    },
  );
  test(
    'queued cancellation and changed consent never reach another claim',
    () async {
      var cancelled = false, attempts = 0;
      await expectLater(
        waitForAiTurn(
          claim: () async {
            attempts++;
            throw const AiFailure('busy', code: 'busy');
          },
          verify: () async {},
          cancelled: () => cancelled,
          delay: (_) async {
            cancelled = true;
          },
        ),
        throwsA(isA<AiFailure>().having((e) => e.code, 'code', 'cancelled')),
      );
      expect(attempts, 1);
      await expectLater(
        waitForAiTurn(
          claim: () async {
            attempts++;
          },
          verify: () async {
            throw const AiFailure('changed');
          },
          cancelled: () => false,
        ),
        throwsA(isA<AiFailure>()),
      );
      expect(attempts, 1);
    },
  );
  test('queue timeout leaves request unclaimed', () async {
    await expectLater(
      waitForAiTurn(
        claim: () async {
          throw const AiFailure('busy', code: 'busy');
        },
        verify: () async {},
        cancelled: () => false,
        timeout: Duration.zero,
      ),
      throwsA(isA<AiFailure>()),
    );
  });
  test(
    'interactive priority holds background requests and keeps ownership',
    () async {
      final s = await Store.open();
      try {
        await s.setMeta(
          'aiInteractiveUntil',
          '${DateTime.now().millisecondsSinceEpoch + 10000}',
        );
        await expectLater(
          claimAiRequest(s),
          throwsA(isA<AiFailure>().having((e) => e.code, 'code', 'busy')),
        );
        await claimAiRequest(s, interactive: true);
        expect(s.aiRequestOwner, isNotNull);
        await releaseAiRequest(s);
        expect(s.aiRequestOwner, isNull);
      } finally {
        await s.db.close();
      }
    },
  );
  test(
    'legacy conversation survives migration and new threads remain separate',
    () async {
      final s = await Store.open();
      try {
        final legacy = [
          {'role': 'user', 'text': 'old'},
          {'role': 'model', 'text': 'answer'},
        ];
        await s.setMeta('aiChat:all', jsonEncode(legacy));
        await saveChatThread(
          s,
          'aiChat:all',
          ChatThread('new', 'new question', [
            {'role': 'user', 'text': 'new'},
          ]),
        );
        final threads = await loadChatThreads(s, 'aiChat:all');
        expect(threads.map((e) => e.id), ['new', 'legacy']);
        expect(threads.last.messages, legacy);
        await saveChatThread(
          s,
          'aiChat:all',
          ChatThread('new', 'updated', [
            {'role': 'user', 'text': 'updated'},
          ]),
        );
        expect((await loadChatThreads(s, 'aiChat:all')).length, 2);
        expect(await s.meta('aiChat:all'), jsonEncode(legacy));
      } finally {
        await s.db.close();
      }
    },
  );

  Future<void> settle(WidgetTester tester) async {
    await tester.pump();
    await tester.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 350)),
    );
    await tester.pumpAndSettle();
  }

  testWidgets(
    'notification settings return directly to origin, never timetable grid',
    (tester) async {
      await tester.pumpWidget(
        const MaterialApp(home: NotificationSettingsPage()),
      );
      await tester.tap(find.text('수업 전·자정 알림'));
      await settle(tester);
      expect(find.text('수업·자정 알림'), findsOneWidget);
      await tester.tap(find.byTooltip('이전 화면으로'));
      await tester.pumpAndSettle();
      expect(find.text('알림 설정'), findsOneWidget);
      expect(find.text('시간표 만들기'), findsNothing);
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets(
    'permission check opens dedicated screen and returns to notifications',
    (tester) async {
      await tester.pumpWidget(
        const MaterialApp(home: NotificationSettingsPage()),
      );
      await tester.tap(find.text('알림·백그라운드 권한'));
      await settle(tester);
      expect(find.text('알림 허용'), findsOneWidget);
      expect(find.text('자동 수집 설정'), findsNothing);
      await tester.pageBack();
      await tester.pumpAndSettle();
      expect(find.text('알림 설정'), findsOneWidget);
    },
  );
  testWidgets('background details stay collapsed until requested', (
    tester,
  ) async {
    await tester.pumpWidget(const MaterialApp(home: BackgroundStatusPage()));
    await settle(tester);
    expect(find.text('자동 수집 켜짐'), findsOneWidget);
    expect(find.text('학교 자동 연결'), findsNothing);
    expect(find.textContaining('마지막 백그라운드 진입:'), findsNothing);
    await tester.tap(find.text('자동 수집 설정'));
    await tester.pumpAndSettle();
    expect(find.text('학교 자동 연결'), findsOneWidget);
  });
  testWidgets(
    'empty or previous-account auth-loss records never show a reconnect warning',
    (tester) async {
      await tester.runAsync(() async {
        final store = await Store.open();
        await store.setMeta('sessionEpoch', 'current');
        await store.setMeta('schoolSessionLostEpoch', 'current');
        await store.setMeta('schoolSessionLostAt', '');
        await store.db.close();
      });
      await tester.pumpWidget(const MaterialApp(home: BackgroundStatusPage()));
      await settle(tester);
      expect(find.text('학교 재연결 대기 중'), findsNothing);
      await tester.runAsync(() async {
        final store = await Store.open();
        await store.setMeta('schoolSessionLostEpoch', 'previous-account');
        await store.setMeta('schoolSessionLostAt', '2026-10-29T00:00:00Z');
        await store.db.close();
      });
      await tester.tap(find.byTooltip('상태 새로고침'));
      await settle(tester);
      expect(find.text('학교 재연결 대기 중'), findsNothing);
      await tester.pumpWidget(const SizedBox.shrink());
    },
  );
  testWidgets('new chat does not expose legacy conversation until selected', (
    tester,
  ) async {
    await tester.runAsync(() async {
      final s = await Store.open();
      await s.setMeta(
        'aiChat:all',
        jsonEncode([
          {'role': 'user', 'text': '오래된 비밀 질문'},
          {'role': 'model', 'text': '옛 답변'},
        ]),
      );
      await s.db.close();
    });
    await tester.pumpWidget(const MaterialApp(home: AiChatPage()));
    await settle(tester);
    expect(find.text('오래된 비밀 질문'), findsNothing);
    await tester.tap(find.text('이전 대화'));
    await settle(tester);
    await tester.tap(find.text('이전 버전의 대화'));
    await tester.pumpAndSettle();
    expect(find.text('오래된 비밀 질문'), findsOneWidget);
    await tester.tap(find.text('새 대화'));
    await tester.pumpAndSettle();
    expect(find.text('오래된 비밀 질문'), findsNothing);
    expect(tester.takeException(), isNull);
  });
  testWidgets('structured syllabus and settings fit narrow high text scale', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(412, 915);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(
      MaterialApp(
        home: MediaQuery(
          data: const MediaQueryData(
            size: Size(412, 915),
            textScaler: TextScaler.linear(1.5),
          ),
          child: SyllabusReader(
            course: '컴프2',
            text: '전체 본문',
            tables: [
              [
                ['항목', '내용'],
                ['평가 방법', '중간 40%\n기말 40%\n과제 20%'],
              ],
            ],
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.text('평가 방법'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
  testWidgets('capture settings and structured reader review screens', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(412, 915);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.runAsync(() async {
      for (final entry in {
        'Malgun': 'C:/Windows/Fonts/malgun.ttf',
        'MaterialIcons':
            '../../work/tools/flutter/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf',
      }.entries) {
        final font = FontLoader(entry.key);
        font.addFont(
          Future.value(
            ByteData.sublistView(await File(entry.value).readAsBytes()),
          ),
        );
        await font.load();
      }
    });
    final dir = Directory('../../outputs/tests/ui-rework')
      ..createSync(recursive: true);
    final boundary = GlobalKey();
    Future<void> capture(String name, Widget child) async {
      await tester.pumpWidget(
        MaterialApp(
          theme: ThemeData(
            fontFamily: 'Malgun',
            colorSchemeSeed: Colors.teal,
            brightness: Brightness.dark,
          ),
          home: RepaintBoundary(key: boundary, child: child),
        ),
      );
      await settle(tester);
      await tester.runAsync(() async {
        final image =
            await (boundary.currentContext!.findRenderObject()
                    as RenderRepaintBoundary)
                .toImage(pixelRatio: 1);
        final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
        File(
          '${dir.path}/$name.png',
        ).writeAsBytesSync(bytes!.buffer.asUint8List());
        image.dispose();
      });
    }

    await capture(
      'settings',
      SettingsHub(connected: true, connect: () {}, logout: () {}, test: () {}),
    );
    await capture(
      'syllabus',
      const SyllabusReader(
        course: '컴프2',
        text: '강의계획서 본문',
        tables: [
          [
            ['교과목', '컴퓨터프로그래밍2'],
            ['학습 목표', '객체 지향 프로그래밍 이해'],
            ['평가 방법', '중간 40%\n기말 40%\n과제 20%'],
          ],
          [
            ['주차', '수업 내용'],
            ['1주', 'Java 기본 문법'],
            ['2주', '배열과 메서드'],
          ],
        ],
      ),
    );
    await capture('chat', const AiChatPage());
    await capture('collection', const BackgroundStatusPage());
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          (call) async =>
              call.method == 'read' &&
                  (call.arguments as Map)['key'] == 'geminiApiKey'
              ? 'synthetic-key-for-preview'
              : null,
        );
    await tester.runAsync(() async {
      final store = await Store.open();
      await store.setMeta('aiConsent', aiConsentVersion);
      await store.db.close();
    });
    await capture('ai-settings', const AiSettingsPage());
    expect(find.byType(TextField), findsNothing);
    expect(tester.takeException(), isNull);
  });
}

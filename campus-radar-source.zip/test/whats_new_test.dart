import 'package:flutter_test/flutter_test.dart';

import 'package:campus_radar/home/whats_new.dart';

void main() {
  test('the sheet only applies to the release its items describe', () {
    expect(whatsNewApplies(whatsNewVersion), isTrue);
    expect(whatsNewApplies('0.6.2'), isFalse);
    expect(whatsNewApplies('9.9.9'), isFalse);
  });

  test('items are filled in', () {
    expect(whatsNew, isNotEmpty);
    for (final item in whatsNew) {
      expect(item.title.trim(), isNotEmpty);
      expect(item.body.trim(), isNotEmpty);
    }
  });
}

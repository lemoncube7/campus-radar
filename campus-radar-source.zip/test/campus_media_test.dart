import 'package:campus_radar/campus_models.dart';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/campus.dart';
import 'package:campus_radar/campus_media.dart';
import 'package:campus_radar/media_cache.dart';

class FakeDownload extends CampusClient {
  int requests = 0;
  bool fail = false;
  @override
  Future<({List<int> bytes, String mime})> downloadMedia(
    CampusMedia m, {
    int limit = 50 * 1024 * 1024,
  }) async {
    requests++;
    if (fail) throw CampusException('파일 응답 오류 (403)');
    return (bytes: [37, 80, 68, 70, 45], mime: 'application/pdf');
  }
}

void main() {
  test(
    'inline images and text retain document order, active content omitted',
    () {
      final pieces = campusBodyPieces(
        '<p>앞</p><img src="/file/a.png"><p>뒤<br>다음</p><script>BAD</script><img data-cms-no="42">',
      );
      expect(pieces.map((p) => p.imageIndex ?? p.text).toList(), [
        '앞',
        0,
        '뒤\n다음',
        1,
      ]);
    },
  );
  test(
    'LMS attachment uses full save_name, CMS notice and assignment use distinct routes',
    () {
      final f = [
        {
          'file_name': 'a.pdf',
          'save_name': '/2026/a.pdf',
          'upload_type': 'lms',
          'file_size': 5,
        },
        {'file_name': 'b.pdf', 'upload_type': 'cms', 'cms_file_no': 42},
      ];
      final n = extractCampusMedia('', f, notice: true),
          t = extractCampusMedia('', f, notice: false);
      expect(n.first.url, 'https://dcs-learning.cnu.ac.kr/file/2026/a.pdf');
      expect(n.first.size, 5);
      expect(n.last.url, endsWith('/file/downloadSingleFile'));
      expect(t.last.url, endsWith('/share/downloadFile'));
      expect(n.last.form, {'file_no': '42'});
    },
  );
  test(
    'image routes, html entities, relative paths, duplicate attachment links',
    () {
      final media = extractCampusMedia(
        '<img src="/file/x.png?a=1&amp;b=2"><img data-cms-no="4"><a href="/file/a.pdf">a.pdf</a><a href="/file/a.pdf">a.pdf</a>',
        [],
        notice: true,
      );
      expect(media.length, 3);
      expect(media.first.url, endsWith('?a=1&b=2'));
      expect(media[1].form, {'file_no': '4'});
      expect(media.where((m) => m.image).length, 2);
    },
  );
  test(
    'no credential forwarding to non campus hosts, non https, userinfo or ports',
    () {
      for (final u in [
        'https://evil.test/x',
        'http://dcs-learning.cnu.ac.kr/x',
        'https://dcs-learning.cnu.ac.kr.evil.test/x',
        'https://x@dcs-learning.cnu.ac.kr/x',
        'https://dcs-learning.cnu.ac.kr:444/x',
        'file:///x',
        'javascript:alert(1)',
      ]) {
        expect(allowedMediaUri(Uri.parse(u)), false, reason: u);
      }
      expect(
        allowedMediaUri(Uri.parse('https://dcs-learning.cnu.ac.kr/file/x')),
        true,
      );
    },
  );
  test(
    'legacy data remains readable, new media survives item and notice roundtrip',
    () {
      final m = extractCampusMedia('<img src="/file/a.png">', [], notice: true);
      final n = CampusNotice(
        id: 'n',
        title: 't',
        course: 'c',
        context: {},
        body: 't',
        bodyHtml: '<p>t</p>',
        media: m,
        bodyFetched: true,
      );
      final j = n.toJson();
      expect(CampusNotice.fromJson(j).media.single.url, m.single.url);
      expect(CampusItem.fromJson(n.item.toJson()).bodyHtml, n.bodyHtml);
      j.remove('bodyHtml');
      j.remove('media');
      expect(CampusNotice.fromJson(j).media, isEmpty);
    },
  );
  test(
    'binary downloads reject external destinations before making a request',
    () async {
      final c = CampusClient();
      try {
        await expectLater(
          c.downloadMedia(
            const CampusMedia(name: 'x', url: 'https://evil.test/x'),
          ),
          throwsA(isA<CampusException>()),
        );
      } finally {
        c.close();
      }
    },
  );
  test('bounded data URI image can be decoded without a session', () async {
    final c = CampusClient();
    try {
      final result = await c.downloadMedia(
        const CampusMedia(
          name: 'x',
          url: 'data:image/png;base64,AQID',
          image: true,
        ),
      );
      expect(result.bytes, [1, 2, 3]);
    } finally {
      c.close();
    }
  });
  test(
    'private cache sanitizes filenames, reuses complete bytes, recovers after eviction',
    () async {
      final dir = await Directory.systemTemp.createTemp('radar-media-test-');
      final cache = MediaCache(dir);
      final c = FakeDownload();
      const m = CampusMedia(
        name: '../../a.pdf',
        url: 'https://dcs-learning.cnu.ac.kr/file/a.pdf',
      );
      try {
        final f = await cache.fetch(c, m);
        expect(f.parent.path, dir.path);
        expect(await f.readAsBytes(), [37, 80, 68, 70, 45]);
        await cache.fetch(c, m);
        expect(c.requests, 1);
        expect(await cache.mime(m), 'application/pdf');
        await f.delete();
        expect(await cache.local(m), null);
        await cache.fetch(c, m);
        expect(c.requests, 2);
      } finally {
        c.close();
        await dir.delete(recursive: true);
      }
    },
  );
  test(
    'failed download is not treated as a cached file and can be retried',
    () async {
      final dir = await Directory.systemTemp.createTemp('radar-media-test-');
      final cache = MediaCache(dir);
      final c = FakeDownload()..fail = true;
      const m = CampusMedia(
        name: 'a.pdf',
        url: 'https://dcs-learning.cnu.ac.kr/file/a.pdf',
      );
      try {
        await expectLater(cache.fetch(c, m), throwsA(isA<CampusException>()));
        expect(await cache.local(m), null);
        expect(await cache.status(m), contains('403'));
        c.fail = false;
        await cache.fetch(c, m);
        expect(await cache.status(m), '기기에 저장됨');
      } finally {
        c.close();
        await dir.delete(recursive: true);
      }
    },
  );
}

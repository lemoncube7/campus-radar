import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:flutter_test/flutter_test.dart';

/// Semester-sized fake school: 6 courses, each with 4 assignments, 4 contents
/// and 9 material-board rows (about the size of the real account on 11/4).
class SemesterClient extends CampusClient {
  final calls = <String, int>{};
  String renamedMaterial = '';
  bool finished = false;
  String? dueOverride;
  final sentKeys = <String>{};
  @override
  Future<dynamic> api(
    String route,
    Map<String, dynamic>? payload, {
    String host = CampusClient.learning,
  }) async {
    calls[route] = (calls[route] ?? 0) + 1;
    final course = '${payload?['course_id']}';
    switch (route) {
      case '/term/getYearTermList':
        return {
          'list': [
            {'current_term_yn': 'Y', 'term_year': '2026', 'term_cd': '2'},
          ],
        };
      case '/course/getStdMyCourseList':
        return {
          'course_list': [
            for (var c = 0; c < 6; c++)
              {'course_id': 'c$c', 'class_no': '1', 'course_nm': '수업$c'},
          ],
        };
      case '/course/addSessionCourseInfo':
        return {};
      case '/week/getStdWeekList':
        return {
          'week_list': [
            {
              'seq_list': [
                {
                  'learning_list': [
                    for (var i = 0; i < 4; i++) ...[
                      {
                        'module_type': 'LR',
                        'contents_id': '$course-r$i',
                        'weekseq_no': 'w$i',
                      },
                      {
                        'module_type': 'LV',
                        'contents_id': '$course-v$i',
                        'weekseq_no': 'v$i',
                        'complete_yn': 'N',
                      },
                    ],
                  ],
                },
              ],
            },
          ],
        };
      case '/week/getStdEtcList':
        return {'etc_list': []};
      case '/archive/list':
        return {
          'tot_cnt': 9,
          'list': [
            for (var i = 0; i < 9; i++)
              {
                'boarditem_no': '$course-m$i',
                'boarditem_title': '$course-m$i' == renamedMaterial
                    ? '수정된 자료'
                    : '자료 $i',
              },
          ],
        };
      case '/archive/detail':
        return {'boarditem_content': '본문', 'attach_file_list': []};
      case '/week/getAttachFileList':
        return {'attach_file_list': []};
      case '/task/detail':
        sentKeys.addAll(payload!.keys);
        return {
          'report_nm': '과제',
          'report_apply_end_dt':
              dueOverride ?? (finished ? '2026-10-20' : '2026-11-20'),
          'report_apply_end_tm': '23:59',
        };
      case '/task/stdDetail':
        return finished
            ? {'report_apply_no': 's', 'apply_yn': 'Y', 'temp_yn': 'N'}
            : null;
      default:
        throw StateError('Unexpected route $route');
    }
  }

  int get total => calls.values.fold(0, (a, b) => a + b);
}

void main() {
  test('automatic collection reuses unchanged attachment details', () async {
    final first = SemesterClient();
    addTearDown(first.close);
    final stored = await first.fetchItems();
    final full = first.total;

    final again = SemesterClient();
    addTearDown(again.close);
    final items = await again.fetchItems(
      previous: {for (final i in stored) i.key: i},
      reuseDetailsFor: const Duration(hours: 6),
    );
    // ignore: avoid_print
    print(
      'requests full=$full incremental=${again.total} '
      '(archive/detail ${first.calls['/archive/detail']}→${again.calls['/archive/detail'] ?? 0}, '
      'getAttachFileList ${first.calls['/week/getAttachFileList']}→${again.calls['/week/getAttachFileList'] ?? 0})',
    );
    expect(first.calls['/archive/detail'], 54);
    expect(first.calls['/week/getAttachFileList'], 24);
    expect(again.calls['/archive/detail'], isNull);
    expect(again.calls['/week/getAttachFileList'], isNull);
    expect(items.map((i) => i.key).toSet(), stored.map((i) => i.key).toSet());
    final material = items.firstWhere((i) => i.type == 'LS');
    expect(material.body, '본문');
  });

  test('a changed list row or manual collection refetches details', () async {
    final first = SemesterClient();
    addTearDown(first.close);
    final stored = {for (final i in await first.fetchItems()) i.key: i};

    final changed = SemesterClient()..renamedMaterial = 'c2-m3';
    addTearDown(changed.close);
    await changed.fetchItems(
      previous: stored,
      reuseDetailsFor: const Duration(hours: 6),
    );
    expect(changed.calls['/archive/detail'], 1);

    final manual = SemesterClient();
    addTearDown(manual.close);
    await manual.fetchItems(previous: stored);
    expect(manual.calls['/archive/detail'], 54);
  });

  test('stale details are refetched after the reuse window', () async {
    final first = SemesterClient();
    addTearDown(first.close);
    final stored = {
      for (final i in await first.fetchItems())
        i.key: i.context.containsKey('detailAt')
            ? CampusItem.fromJson({
                ...i.toJson(),
                'context': {...i.context, 'detailAt': '2026-01-01T00:00:00Z'},
              })
            : i,
    };
    final later = SemesterClient();
    addTearDown(later.close);
    await later.fetchItems(
      previous: stored,
      reuseDetailsFor: const Duration(hours: 6),
    );
    expect(later.calls['/archive/detail'], 54);
  });

  test('finished past-due assignments are reused for a day', () async {
    final first = SemesterClient()..finished = true;
    addTearDown(first.close);
    final stored = {for (final i in await first.fetchItems()) i.key: i};
    expect(first.calls['/task/detail'], 24);
    expect(first.sentKeys.intersection({'listSig', 'detailAt'}), isEmpty);
    final again = SemesterClient()..finished = true;
    addTearDown(again.close);
    final items = await again.fetchItems(
      previous: stored,
      reuseDetailsFor: const Duration(hours: 6),
    );
    // ignore: avoid_print
    print('finished semester: full=${first.total} incremental=${again.total}');
    expect(again.calls['/task/detail'], isNull);
    expect(again.calls['/task/stdDetail'], isNull);
    expect(items.where((i) => i.type == 'LR' && i.done).length, 24);
    final manual = SemesterClient()..finished = true;
    addTearDown(manual.close);
    await manual.fetchItems(previous: stored);
    expect(manual.calls['/task/detail'], 24);
  });

  test(
    'pending assignments far from the deadline are reused for an hour',
    () async {
      final first = SemesterClient();
      addTearDown(first.close);
      final stored = {for (final i in await first.fetchItems()) i.key: i};
      final again = SemesterClient();
      addTearDown(again.close);
      await again.fetchItems(
        previous: stored,
        reuseDetailsFor: const Duration(hours: 6),
      );
      expect(again.calls['/task/detail'], isNull);
      final manual = SemesterClient();
      addTearDown(manual.close);
      await manual.fetchItems(previous: stored);
      expect(manual.calls['/task/detail'], 24);
    },
  );

  test('pending assignments near the deadline are always refreshed', () async {
    final soon = DateTime.now().add(const Duration(days: 1));
    final due =
        '${soon.year}-${soon.month.toString().padLeft(2, '0')}-${soon.day.toString().padLeft(2, '0')}';
    final first = SemesterClient()..dueOverride = due;
    addTearDown(first.close);
    final stored = {for (final i in await first.fetchItems()) i.key: i};
    final again = SemesterClient()..dueOverride = due;
    addTearDown(again.close);
    await again.fetchItems(
      previous: stored,
      reuseDetailsFor: const Duration(hours: 6),
    );
    expect(again.calls['/task/detail'], 24);
  });

  test('fetchCourses and fetchNotices throw CampusException when term list is missing', () async {
    final client = _EmptyTermClient();
    addTearDown(client.close);
    expect(() => client.fetchCourses(), throwsA(isA<CampusException>()));
    expect(() => client.fetchNotices(), throwsA(isA<CampusException>()));
  });

  test('LV due falls back to 23:59:00 when weekseq_end_dt_hour is omitted', () async {
    final client = _NullContentIdClient();
    addTearDown(client.close);
    final items = await client.fetchItems();
    final lv = items.firstWhere((i) => i.type == 'LV');
    expect(lv.due, campusDate('2026-11-25 23:59:00'));
  });

  test('assignment extraDue and extraStart fall back to list add_end_tm and add_str_tm', () async {
    final client = _MissingDetailTimeClient();
    addTearDown(client.close);
    final items = await client.fetchItems();
    final lr = items.firstWhere((i) => i.type == 'LR');
    expect(lr.additionalDue, campusDate('2026-11-20 18:00:00'));
    expect(lr.additionalStartsAt, campusDate('2026-11-10 09:00:00'));
  });
}

class _EmptyTermClient extends CampusClient {
  @override
  Future<dynamic> api(
    String route,
    Map<String, dynamic>? payload, {
    String host = CampusClient.learning,
  }) async {
    if (route == '/term/getYearTermList') return {};
    return {};
  }
}

class _NullContentIdClient extends SemesterClient {
  @override
  Future<dynamic> api(
    String route,
    Map<String, dynamic>? payload, {
    String host = CampusClient.learning,
  }) async {
    if (route == '/course/getStdMyCourseList') {
      return {
        'course_list': [
          {'course_id': 'c0', 'class_no': '1', 'course_nm': '수업0'},
        ],
      };
    }
    if (route == '/week/getStdWeekList') {
      return {
        'week_list': [
          {
            'seq_list': [
              {
                'learning_list': [
                  {
                    'module_type': 'LV',
                    'contents_id': null,
                    'weekseq_no': 'weekseq-99',
                    'weekseq_end_dt': '2026-11-25',
                  },
                ],
              },
            ],
          },
        ],
      };
    }
    return super.api(route, payload, host: host);
  }
}

class _MissingDetailTimeClient extends SemesterClient {
  @override
  Future<dynamic> api(
    String route,
    Map<String, dynamic>? payload, {
    String host = CampusClient.learning,
  }) async {
    if (route == '/course/getStdMyCourseList') {
      return {
        'course_list': [
          {'course_id': 'c0', 'class_no': '1', 'course_nm': '수업0'},
        ],
      };
    }
    if (route == '/week/getStdWeekList') {
      return {
        'week_list': [
          {
            'seq_list': [
              {
                'learning_list': [
                  {
                    'module_type': 'LR',
                    'contents_id': 'r0',
                    'weekseq_no': 'w0',
                    'add_str_dt': '2026-11-10',
                    'add_str_tm': '09:00',
                    'add_end_dt': '2026-11-20',
                    'add_end_tm': '18:00',
                  },
                ],
              },
            ],
          },
        ],
      };
    }
    if (route == '/task/detail') {
      return {
        'report_nm': '과제0',
      };
    }
    return super.api(route, payload, host: host);
  }
}

import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/export/drive_uploader.dart';
import 'drive_uploader_test.dart' show FakeDrive;

void main() {
  test('unknown archives merge without deleting real semesters or unique files', () async {
    final fake = FakeDrive();
    final api = DriveApi('test', transport: fake.call);
    for (final row in [
      ['root', '캠퍼스레이더', ''], ['course', '과목', 'root'],
      ['target', '선형대수', 'root'],
      ['old', '지난 내보내기 (학기 미확인) - 자료', 'root'],
      ['oldcourse', '선형대수', 'old'],
      ['real', '지난 내보내기 (2026-1) - 자료', 'root'],
    ]) {
      await api.createFolder(row[0], row[1], parent: row[2]);
    }
    Future<void> file(String id, String name, String parent, int size) async {
      await api.createFile(id, name, parent, 'application/pdf');
      fake.files[id]!['size'] = size;
    }
    await file('current', '강의.pdf', 'target', 100);
    await file('duplicate', '강의 (2).pdf', 'oldcourse', 100);
    await file('different', '강의.pdf', 'oldcourse', 200);
    await file('unique', '추가.pdf', 'oldcourse', 50);
    await file('realfile', '보관.pdf', 'real', 40);
    await file('zip', '지난 내보내기 (2026-1) - 첨부원본.zip', 'root', 80);
    final counts = await cleanupUnknownSemesterArchives(
      api: api, root: 'root', courseRoot: 'course',
      courseMaterialsFolder: (_) async => 'target', check: () {},
    );
    expect(counts, (folders: 2, files: 2));
    expect(fake.files['duplicate']!['trashed'], true);
    expect(fake.files['zip']!['trashed'], true);
    for (final id in ['different', 'unique']) {
      expect(fake.files[id]!['parents'], ['target']);
      expect(fake.files[id]!['trashed'], false);
      expect((fake.files[id]!['appProperties'] as Map)['crKind'], 'file');
    }
    expect(fake.files['real']!['trashed'], false);
    expect(fake.files['realfile']!['parents'], ['real']);
    final second = await cleanupUnknownSemesterArchives(
      api: api, root: 'root', courseRoot: 'course',
      courseMaterialsFolder: (_) async => 'target', check: () {},
    );
    expect(second, (folders: 0, files: 0));
    expect(fake.calls.any((call) => call.startsWith('DELETE')), false);
  });

  test('cancel propagates and never trashes a partially inspected archive', () async {
    final fake = FakeDrive();
    final api = DriveApi('test', transport: fake.call);
    await api.createFolder('old', '지난 내보내기 (학기 미확인) - 과목', parent: 'root');
    await expectLater(cleanupUnknownSemesterArchives(
      api: api, root: 'root', courseRoot: 'course',
      courseMaterialsFolder: (_) async => 'target',
      check: () => throw StateError('cancelled'),
    ), throwsStateError);
    expect(fake.files['old']!['trashed'], false);
  });
}

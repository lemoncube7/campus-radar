import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/export/drive_sync.dart';
import 'package:campus_radar/updates/updates.dart';

void main() {
  test(
    'stable install ignores a development preference retained by upgrade',
    () {
      expect(effectiveUpdateChannel('stable', 'development'), 'stable');
      expect(effectiveUpdateChannel('stable', null), 'stable');
      expect(effectiveUpdateChannel('development', 'stable'), 'stable');
      expect(effectiveUpdateChannel('development', null), 'development');
    },
  );
  test('Drive targets reject disabled or another school account', () {
    final hash = driveAccountHash('school-a');
    final row = {
      'enabled': true,
      'accountHash': hash,
      'binding': 'generation-a',
    };
    expect(driveTargetMatches(row, hash), isTrue);
    expect(driveTargetMatches(row, driveAccountHash('school-b')), isFalse);
    expect(driveTargetMatches({...row, 'enabled': false}, hash), isFalse);
    expect(driveTargetMatches({...row, 'binding': ''}, hash), isFalse);
  });
  test(
    'Drive revision ignores export clock but retains source collection age',
    () {
      Map<String, String> documents(
        String exported,
        String collected,
        String text,
      ) => {
        '캠퍼스레이더 시작.txt':
            'CAMPUS_RADAR_START_V1\n${jsonEncode({'exportedAt': exported, 'collectedAt': collected})}',
        '학업 현황.txt': '내보냄: $exported\n$text',
      };
      final a = driveDocumentRevision(
        documents('one', 'source-one', 'original'),
      );
      expect(
        driveDocumentRevision(documents('two', 'source-one', 'original')),
        a,
      );
      expect(
        driveDocumentRevision(documents('two', 'source-two', 'original')),
        isNot(a),
      );
      expect(
        driveDocumentRevision(documents('two', 'source-one', 'changed')),
        isNot(a),
      );
    },
  );
  test('driveEnqueueArguments carries manual flag for WorkManager replacement', () {
    expect(driveEnqueueArguments(manual: true), {'manual': true});
    expect(driveEnqueueArguments(manual: false), {'manual': false});
  });

  group('driveDocumentRevision with file:// zip ref', () {
    test('is stable across export times and detects zip digest changes', () {
      final doc1 = {
        '캠퍼스레이더 시작.txt': 'CAMPUS_RADAR_START_V1\n{"exportedAt":"2026-11-10T10:00:00Z","collectedAt":"2026-11-10T09:00:00Z"}',
        '학업 현황.txt': '내보냄: 2026-11-10T10:00:00Z\n내용',
        '캠퍼스레이더 첨부원본.zip': 'file:///app/support/drive-zip-acc1-digestA.zip',
      };
      final doc2 = {
        '캠퍼스레이더 시작.txt': 'CAMPUS_RADAR_START_V1\n{"exportedAt":"2026-11-10T10:30:00Z","collectedAt":"2026-11-10T09:00:00Z"}',
        '학업 현황.txt': '내보냄: 2026-11-10T10:30:00Z\n내용',
        '캠퍼스레이더 첨부원본.zip': 'file:///app/support/drive-zip-acc1-digestA.zip',
      };
      final docDifferentZip = {
        '캠퍼스레이더 시작.txt': 'CAMPUS_RADAR_START_V1\n{"exportedAt":"2026-11-10T10:00:00Z","collectedAt":"2026-11-10T09:00:00Z"}',
        '학업 현황.txt': '내보냄: 2026-11-10T10:00:00Z\n내용',
        '캠퍼스레이더 첨부원본.zip': 'file:///app/support/drive-zip-acc1-digestB.zip',
      };
      final rev1 = driveDocumentRevision(doc1);
      final rev2 = driveDocumentRevision(doc2);
      final revDiff = driveDocumentRevision(docDifferentZip);

      expect(rev1, rev2);
      expect(rev1, isNot(revDiff));
    });
  });

  group('collectReferencedZipNames', () {
    test('extracts zip filenames from payloads across accounts and ignores base64', () {
      final root = {
        'accounts': {
          'acc1': {
            'documents': {
              '캠퍼스레이더 시작.txt': 'some text',
              '캠퍼스레이더 첨부원본.zip': 'file:///data/user/0/files/drive-zip-hash1-digest1.zip',
            },
          },
          'acc2': {
            'documents': {
              '캠퍼스레이더 첨부원본.zip': 'file:///data/user/0/files/drive-zip-hash1-digest2.zip',
            },
          },
          'acc3': {
            'documents': {
              '캠퍼스레이더 첨부원본.zip': 'UEsDBBQAAAAIA...', // base64
            },
          },
          'acc4': {
            'documents': <String, dynamic>{},
          },
        },
      };

      final names = collectReferencedZipNames(root);
      expect(names, {'drive-zip-hash1-digest1.zip', 'drive-zip-hash1-digest2.zip'});
    });

    test('handles null or malformed input safely', () {
      expect(collectReferencedZipNames(null), isEmpty);
      expect(collectReferencedZipNames({}), isEmpty);
      expect(collectReferencedZipNames({'accounts': 'not a map'}), isEmpty);
    });
  });

  group('cleanupOldDriveZipFiles', () {
    late Directory tempDir;
    const hash = 'targetHash123';

    setUp(() async {
      tempDir = await Directory.systemTemp.createTemp('radar-zip-cleanup-test-');
    });

    tearDown(() async {
      if (await tempDir.exists()) {
        await tempDir.delete(recursive: true);
      }
    });

    test('retains active files, recent files, and other account files while deleting stale unreferenced files', () async {
      final activeFile = File('${tempDir.path}/drive-zip-$hash-active.zip');
      await activeFile.writeAsString('active');

      final recentFile = File('${tempDir.path}/drive-zip-$hash-recent.zip');
      await recentFile.writeAsString('recent');

      final staleFile = File('${tempDir.path}/drive-zip-$hash-stale.zip');
      await staleFile.writeAsString('stale');

      final otherAccountFile = File('${tempDir.path}/drive-zip-otherHash-stale.zip');
      await otherAccountFile.writeAsString('other');

      final unrelatedFile = File('${tempDir.path}/some-other-file.txt');
      await unrelatedFile.writeAsString('unrelated');

      final now = DateTime.now();
      // Set modification time on staleFile to 30 minutes in the past
      await staleFile.setLastModified(now.subtract(const Duration(minutes: 30)));
      // Set recentFile to 5 minutes in the past
      await recentFile.setLastModified(now.subtract(const Duration(minutes: 5)));
      // Set activeFile to 30 minutes in the past (to prove activeZipNames protects even stale files)
      await activeFile.setLastModified(now.subtract(const Duration(minutes: 30)));
      // Set otherAccountFile to 30 minutes in the past
      await otherAccountFile.setLastModified(now.subtract(const Duration(minutes: 30)));

      cleanupOldDriveZipFiles(
        folder: tempDir,
        hash: hash,
        activeZipNames: {'drive-zip-$hash-active.zip'},
        maxAge: const Duration(minutes: 15),
        now: now,
      );

      expect(await activeFile.exists(), isTrue, reason: 'Referenced active file must be kept');
      expect(await recentFile.exists(), isTrue, reason: 'Recent file (<15m) must be kept for in-flight workers');
      expect(await otherAccountFile.exists(), isTrue, reason: 'Other account files must not be deleted');
      expect(await unrelatedFile.exists(), isTrue, reason: 'Unrelated files must not be touched');
      expect(await staleFile.exists(), isFalse, reason: 'Stale unreferenced file must be cleaned up');
    });
  });
}

import 'package:campus_radar/export/academic_export.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('freeboard export hides phone numbers, e-mails and messenger IDs', () {
    final masked = maskFreeboardContacts(
      '스터디 모집 010-1234-5678, 01098765432 연락 주세요\n'
      '메일 student.kim@o.cnu.ac.kr\n'
      '카톡 ID: study_kim22 / 042-821-1234\n'
      '과제는 3장까지, 마감 11/16 23:59',
    );
    expect(masked, isNot(contains('1234-5678')));
    expect(masked, isNot(contains('01098765432')));
    expect(masked, isNot(contains('student.kim@o.cnu.ac.kr')));
    expect(masked, isNot(contains('study_kim22')));
    expect(masked, isNot(contains('821-1234')));
    expect(masked, contains('[전화번호 가림]'));
    expect(masked, contains('[이메일 가림]'));
    expect(masked, contains('[메신저 ID 가림]'));
    // Ordinary content stays.
    expect(masked, contains('과제는 3장까지, 마감 11/16 23:59'));
  });
}

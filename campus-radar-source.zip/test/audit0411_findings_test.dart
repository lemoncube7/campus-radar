import 'package:campus_radar/navigation/app_router.dart';
import 'package:campus_radar/schedule/calendar_draft_page.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/ai/notice_ai_service.dart';
import 'package:campus_radar/courses/course_catalog.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/ai/ai_automation.dart';
import 'dart:async';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/core/network_resilience.dart';
// Regression checks for the audited failures. All payloads and transports are synthetic.
// All accounts, notices, files and AI transports below are synthetic and local.
import 'dart:convert';
import 'dart:io';
import 'package:campus_radar/campus/campus_media.dart';
import 'package:campus_radar/ai/chat.dart';
import 'package:campus_radar/campus/media_cache.dart';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory directory;
  late Store store;
  setUp(() async {
    directory = await Directory.systemTemp.createTemp('audit0411-');
    await databaseFactory.setDatabasesPath(directory.path);
    SharedPreferences.setMockInitialValues({});
    store = await Store.open();
  });
  tearDown(() async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          null,
        );
    await store.db.close();
    await directory.delete(recursive: true);
  });

  test(
    'AUDIT A1: chat blocks transport after consent/account changed before dispatch',
    () async {
      await store.setMeta('aiChatConsent', '1');
      var account = 'audit-account-A';
      var switched = false;
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(
            const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
            (call) async {
              if (call.method != 'read') return null;
              final key = (call.arguments as Map)['key'];
              if (key == 'geminiApiKey') {
                return account == 'audit-account-A'
                    ? 'audit-key-A'
                    : 'audit-key-B';
              }
              if (key == 'id') {
                final snapshot = account;
                if (!switched) {
                  switched = true;
                  account = 'audit-account-B';
                  await store.setMeta('aiChatConsent', '0');
                }
                return snapshot;
              }
              return null;
            },
          );
      var transmittedAfterRevocation = false;
      await expectLater(
        askCampusAi(
          store,
          [],
          'AUDIT_PRIVATE_QUESTION_A',
          transport: (key, request) async {
            transmittedAfterRevocation =
                await store.meta('aiChatConsent') == '0' &&
                account == 'audit-account-B' &&
                jsonEncode(request).contains('AUDIT_PRIVATE_QUESTION_A');
            return {};
          },
        ),
        throwsA(isA<AiFailure>()),
      );
      expect(
        transmittedAfterRevocation,
        false,
        reason:
            'The response check is too late to prevent the outgoing request. No real provider was called.',
      );
    },
  );

  test('AUDIT A2: notice refresh marks cached body for revalidation', () async {
    await store.saveNotice(
      CampusNotice(
        id: 'n',
        title: 'old',
        course: 'audit',
        body: 'Old deadline',
        bodyHtml: '<p>Old deadline</p>',
        bodyFetched: true,
        context: {},
      ),
    );
    await store.replaceNotices([
      CampusNotice(
        id: 'n',
        title: 'deadline changed',
        course: 'audit',
        context: {},
      ),
    ]);
    final saved = (await store.notices()).single;
    expect(saved.title, 'deadline changed');
    expect(saved.body, 'Old deadline');
    expect(saved.bodyFetched, false);
  });

  test('AUDIT A3: current catalog excludes removed cached course', () async {
    await store.setMeta(
      'courses',
      jsonEncode([
        {'course_id': 'current', 'class_no': '1', 'course_nm': 'Current'},
      ]),
    );
    await store.saveNotice(
      CampusNotice(
        id: 'old',
        title: 'old',
        course: 'Removed course',
        context: {'course_id': 'removed', 'class_no': '1'},
      ),
    );
    final courses = await readCourses(store);
    expect(courses.map((c) => c['course_id']), equals(['current']));
  });

  test(
    'AUDIT A4: expired worker cannot clear replacement worker lease',
    () async {
      expect(await store.acquire(), true); // A owns the lease.
      await store.setMeta(
        'lease',
        '${DateTime.now().millisecondsSinceEpoch - 1}',
      ); // A has outlived the lease.
      final other = await Store.open();
      try {
        expect(await other.acquire(), true); // B now owns the lease.
        await store.releaseLease(); // A cannot release B's lease.
        expect(
          await store.acquire(),
          false,
        ); // C may start while B is still running.
      } finally {
        await other.db.close();
      }
    },
  );

  test('AUDIT A5: JSON attachments count towards cache quota', () async {
    SharedPreferences.setMockInitialValues({'limit.cacheBytes': 300 * 1024 * 1024}); // user-set cache limit (default none)
    final cache = MediaCache(Directory('${directory.path}/media'));
    await cache.root.create();
    final files = <File>[];
    for (var i = 0; i < 6; i++) {
      final media = CampusMedia(
        name: i.isEven ? 'attachment-$i.json' : 'attachment-$i.123.part',
        url: 'https://dcs-learning.cnu.ac.kr/file/$i',
      );
      expect(media.supported, true);
      final file = cache.data(media);
      final handle = await file.open(mode: FileMode.write);
      await handle.truncate(42 * 1024 * 1024);
      await handle.close();
      files.add(file);
    }
    // Every individual payload is below the actual 50 MiB limit.
    // 252 MiB existing + 50 MiB incoming should evict something, but does not.
    await cache.trim(50 * 1024 * 1024);
    expect(await Future.wait(files.map((f) => f.exists())), contains(false));
  });

  test('AUDIT A6: new notice creates one notification outbox event', () async {
    await store.replaceNotices([
      CampusNotice(id: 'first', title: 'first', course: 'audit', context: {}),
    ]);
    await store.replaceNotices([
      CampusNotice(id: 'first', title: 'first', course: 'audit', context: {}),
      CampusNotice(id: 'new', title: 'new', course: 'audit', context: {}),
    ]);
    expect((await store.notices()).length, 2);
    final events = await store.db.query('events');
    expect(events.length, 1);
    expect(jsonDecode(events.single['payload'] as String)['kind'], 'notice');
  });

  test('list refresh keeps a fetched body for an unchanged notice', () async {
    final row = CampusNotice(id: 'n', title: 'same', course: 'c', context: {});
    await store.replaceNotices([row]);
    await store.saveNotice(
      CampusNotice(
        id: 'n',
        title: 'same',
        course: 'c',
        context: {},
        body: 'body',
        bodyHtml: '<p>body</p>',
        bodyFetched: true,
      ),
    );
    await store.replaceNotices([row]);
    expect((await store.notices()).single.bodyFetched, isTrue);
    await store.replaceNotices([
      CampusNotice(id: 'n', title: 'edited', course: 'c', context: {}),
    ]);
    final edited = (await store.notices()).single;
    expect(edited.bodyFetched, isFalse);
    expect(edited.body, 'body');
  });

  test(
    'Logout attempts credential and database cleanup despite platform failures',
    () async {
      final calls = <String>[];
      final failures = await completeLogout([
        (
          'widget',
          () async {
            calls.add('widget');
            throw StateError('synthetic platform failure');
          },
        ),
        (
          'credentials',
          () async {
            calls.add('credentials');
          },
        ),
        (
          'database',
          () async {
            calls.add('database');
          },
        ),
      ]);
      expect(calls, ['widget', 'credentials', 'database']);
      expect(failures, ['widget']);
    },
  );
  test(
    'Logout and same-account login invalidate the old session generation',
    () async {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(
            const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
            (call) async => call.method == 'read' ? 'synthetic-account' : null,
          );
      final old = await SessionScope.capture(store);
      await SessionScope.rotate(store, blocked: true);
      await SessionScope.rotate(store, blocked: false);
      await expectLater(old.verify(), throwsA(isA<SessionChanged>()));
      await (await SessionScope.capture(store)).verify();
    },
  );
  test(
    'Revoking and restoring consent still invalidate an old request',
    () async {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(
            const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
            (call) async => null,
          );
      await store.setMeta('aiChatConsent', '1');
      final old = await SessionScope.capture(
        store,
        consents: {'aiChatConsent': '1'},
      );
      await store.setMeta('aiChatConsent', '0');
      await store.setMeta('aiChatConsent', '1');
      await expectLater(old.verify(), throwsA(isA<SessionChanged>()));
    },
  );
  test(
    'Total deadline cancels a slow stream even while chunks keep arriving',
    () async {
      var cancelled = false;
      final producer = Stream<int>.periodic(
        const Duration(milliseconds: 5),
        (i) => i,
      ).take(12);
      final result = requestDeadline(
        () async {
          await for (final _ in producer) {}
          return 1;
        },
        () {
          cancelled = true;
        },
        limit: const Duration(milliseconds: 35),
      );
      await expectLater(result, throwsA(isA<TimeoutException>()));
      expect(cancelled, true);
    },
  );
  test('Expired AI owner cannot release the replacement AI request', () async {
    await claimAiRequest(store);
    await store.setMeta('aiNetworkUntil', '0');
    await store.setMeta('aiLastRequest', '2000-01-01T00:00:00Z');
    final other = await Store.open();
    try {
      await claimAiRequest(other);
      await releaseAiRequest(store);
      expect(
        int.parse((await store.meta('aiNetworkUntil'))!),
        greaterThan(DateTime.now().millisecondsSinceEpoch),
      );
      await releaseAiRequest(other);
      expect(await store.meta('aiNetworkUntil'), '0');
    } finally {
      await other.db.close();
    }
  });
  test(
    'Notice outbox ignores initial history and repeated collection',
    () async {
      final n = CampusNotice(id: 'n', title: 'n', course: 'c', context: {});
      await store.replaceNotices([]);
      expect(await store.db.query('events'), isEmpty);
      await store.replaceNotices([n]);
      await store.replaceNotices([n]);
      expect((await store.db.query('events')).length, 1);
    },
  );

  test('Ambiguous AI transmission failures require manual retry', () {
    for (final code in [
      'network',
      'response',
      'incomplete',
      'validation',
      'credentials',
    ]) {
      expect(
        canAutomaticallyRetryAi(AiFailure('synthetic', code: code), 1),
        false,
      );
    }
    expect(
      canAutomaticallyRetryAi(const AiFailure('synthetic', code: 'busy'), 1),
      true,
    );
    expect(
      canAutomaticallyRetryAi(const AiFailure('synthetic', code: 'quota'), 1),
      true,
    );
    expect(
      canAutomaticallyRetryAi(const AiFailure('synthetic', code: 'quota'), 3),
      false,
    );
  });
  testWidgets(
    'AUDIT control: calendar evidence panel does not reproduce daily-card collision',
    (tester) async {
      final errors = <String>[];
      final previous = FlutterError.onError;
      FlutterError.onError = (details) =>
          errors.add(details.exceptionAsString());
      try {
        await tester.pumpWidget(
          const MaterialApp(
            onGenerateRoute: buildAppRoute,
            home: CalendarDraftPage(
              itemKey: 'audit',
              title: 'Audit title',
              description: 'AUDIT_EVIDENCE_TEXT',
              saveToCalendar: false,
            ),
          ),
        );
        await tester.pumpAndSettle();
        await tester.ensureVisible(find.text('근거·원문 내용'));
        await tester.tap(find.text('근거·원문 내용'));
        await tester.pumpAndSettle();
        expect(
          errors,
          isEmpty,
          reason:
              'Similar widget structure alone is not evidence of the same state collision.',
        );
        expect(find.text('AUDIT_EVIDENCE_TEXT'), findsOneWidget);
        await tester.pumpWidget(const SizedBox.shrink());
      } finally {
        FlutterError.onError = previous;
      }
    },
  );
}

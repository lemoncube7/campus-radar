import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:campus_radar/ai/ai_approval_policy.dart';
import 'package:campus_radar/ai/ai_cancellation_notification.dart';
import 'package:campus_radar/ai/ai_inbox_page.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/ai/ai_state_models.dart';
import 'package:campus_radar/ai/ai_state_repository.dart';
import 'package:campus_radar/ai/ai_timetable.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';
import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/today_classes_card.dart';

void main() {
  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  group('Item 1: revertAutoApproved loop prevention', () {
    test('reverting auto-approved schedule sets review state instead of deleting meta so auto-approval does not loop', () async {
      final db = await databaseFactoryFfi.openDatabase(inMemoryDatabasePath);
      await db.execute('CREATE TABLE meta (id TEXT PRIMARY KEY, value TEXT NOT NULL)');
      await db.execute('CREATE TABLE logs (id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL, detail TEXT NOT NULL)');
      final store = Store(db);

      final notice = CampusNotice(
        id: 'n1',
        title: '중간고사 일정 안내',
        course: '알고리즘',
        context: {},
        body: '중간고사는 2026-11-20 10:00에 진행됩니다.',
        bodyHtml: '',
        media: const [],
        bodyFetched: true,
      );

      final candidate = ScheduleCandidate(
        title: '중간고사',
        date: '2026-11-20',
        time: '10:00',
        action: 'add',
        evidence: '중간고사는 2026-11-20 10:00에 진행됩니다.',
        uncertainty: '',
        category: 'exam',
      );

      final key = candidateKey(notice, candidate);
      final repo = AiStateRepository(store);

      // Auto-approved state
      await repo.saveSchedule(
        key,
        ConfirmedSchedule.fromJson({
          'status': 'confirmed',
          'approvalMode': 'automatic',
          'approvalReason': '자동 반영됨',
          'approvedAt': DateTime.now().toUtc().toIso8601String(),
        }),
      );
      await store.setMeta(MetaKey.aiApproval(key), jsonEncode({'approved': true}));

      final row = {
        'key': key,
        'candidate': candidate,
        'notice': notice,
      };

      // Call revert
      await revertAutoApprovedCandidate(store, row);

      // Check state: must NOT be deleted/empty; status must be review with approvalMode reverted
      final state = await repo.schedule(key);
      expect(state.toJson().isNotEmpty, isTrue, reason: 'aiState가 완전히 삭제되면 백그라운드에서 다시 자동 승인됨');
      expect(state.decision, ScheduleDecision.review);
      expect(state.toJson()['approvalMode'], 'reverted');
      expect(await store.meta(MetaKey.aiApproval(key)), isNull);

      await db.close();
    });
  });

  group('Item 2: revertAutoApproved single cancellation selective deletion', () {
    test('reverting one cancellation only removes that candidate, keeping other cancellations for the same notice', () async {
      final db = await databaseFactoryFfi.openDatabase(inMemoryDatabasePath);
      await db.execute('CREATE TABLE meta (id TEXT PRIMARY KEY, value TEXT NOT NULL)');
      await db.execute('CREATE TABLE logs (id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL, detail TEXT NOT NULL)');
      final store = Store(db);

      final notice = CampusNotice(
        id: 'n_cancel_multi',
        title: '11월 4일 및 11월 11일 휴강 안내',
        course: '데이터베이스',
        context: {},
        body: '11월 4일과 11월 11일 수업은 휴강입니다.',
        bodyHtml: '',
        media: const [],
        bodyFetched: true,
      );

      final slot = ClassSlot(
        courseKey: 'c_db:01',
        course: '데이터베이스',
        weekday: 3, // 수요일
        start: 540,
        end: 615,
        room: '공101',
        source: '시간표',
      );
      await store.setMeta(MetaKey.timetableEntries, jsonEncode([slot.toJson()]));

      final candidate1 = ScheduleCandidate(
        title: '휴강',
        date: '2026-11-04',
        time: '09:00',
        action: 'cancel',
        evidence: '11월 4일과 11월 11일 수업은 휴강입니다.',
        uncertainty: '',
        category: 'class',
      );
      final candidate2 = ScheduleCandidate(
        title: '휴강',
        date: '2026-11-11',
        time: '09:00',
        action: 'cancel',
        evidence: '11월 4일과 11월 11일 수업은 휴강입니다.',
        uncertainty: '',
        category: 'class',
      );

      final c1 = ClassCancellation('2026-11-04:${slot.id}', slot.id, '2026-11-04', slot.course, notice.title, noticeId: notice.id);
      final c2 = ClassCancellation('2026-11-11:${slot.id}', slot.id, '2026-11-11', slot.course, notice.title, noticeId: notice.id);
      await CancellationRepository(store).apply([c1, c2]);

      final repo = AiStateRepository(store);
      final key1 = candidateKey(notice, candidate1);
      final key2 = candidateKey(notice, candidate2);
      await repo.saveSchedule(key1, ConfirmedSchedule.fromJson({'status': 'excluded', 'resolution': 'classCancellationApplied', 'approvalMode': 'automatic'}));
      await repo.saveSchedule(key2, ConfirmedSchedule.fromJson({'status': 'excluded', 'resolution': 'classCancellationApplied', 'approvalMode': 'automatic'}));

      // Revert only candidate 1 (11/04)
      await revertAutoApprovedCandidate(store, {
        'key': key1,
        'candidate': candidate1,
        'notice': notice,
      });

      final remaining = await readClassCancellations(store);
      expect(remaining.map((c) => c.date).toList(), ['2026-11-11'], reason: '11월 4일 휴강만 취소되고 11월 11일 휴강은 유지되어야 함');

      await db.close();
    });
  });

  group('Item 3: notifyConfirmedCancellations with auto-approved cancellations', () {
    test('sends cancellation notification even when candidate was already auto-approved', () async {
      final db = await databaseFactoryFfi.openDatabase(inMemoryDatabasePath);
      await db.execute('CREATE TABLE meta (id TEXT PRIMARY KEY, value TEXT NOT NULL)');
      await db.execute('CREATE TABLE logs (id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL, detail TEXT NOT NULL)');
      final store = Store(db);

      final notice = CampusNotice(
        id: 'n_notif',
        title: '휴강 공지',
        course: '운영체제',
        context: {},
        body: '2026-11-18 수업 휴강입니다.',
        bodyHtml: '',
        media: const [],
        bodyFetched: true,
      );

      final slot = ClassSlot(
        courseKey: 'os:01',
        course: '운영체제',
        weekday: 3,
        start: 600,
        end: 675,
        room: '공202',
        source: '시간표',
      );
      await store.setMeta(MetaKey.timetableEntries, jsonEncode([slot.toJson()]));

      final candidate = ScheduleCandidate(
        title: '휴강',
        date: '2026-11-18',
        time: '10:00',
        action: 'cancel',
        evidence: '2026-11-18 수업 휴강입니다.',
        uncertainty: '',
        category: 'class',
      );

      final key = candidateKey(notice, candidate);
      final repo = AiStateRepository(store);
      // Simulating auto-approved state created by autoApproveNotice
      await repo.saveSchedule(
        key,
        ConfirmedSchedule.fromJson({
          'status': 'excluded',
          'resolution': 'classCancellationApplied',
          'approvalMode': 'automatic',
          'approvedAt': DateTime.now().toUtc().toIso8601String(),
        }),
      );
      final cancellation = ClassCancellation('2026-11-18:${slot.id}', slot.id, '2026-11-18', slot.course, notice.title, noticeId: notice.id);
      await CancellationRepository(store).apply([cancellation]);

      var notified = 0;
      final sentCount = await notifyConfirmedCancellations(
        store,
        notice,
        [candidate],
        notifier: ({required body, required key, required payload, required title}) async {
          notified++;
          return true;
        },
      );

      expect(sentCount, 1, reason: '자동 반영된 휴강이어도 사용자에게 알림이 발송되어야 함');
      expect(notified, 1);

      await db.close();
    });
  });

  group('Item 4: aiTimetableContext with null published', () {
    test('falls back to reference time when notice.published is null', () async {
      final db = await databaseFactoryFfi.openDatabase(inMemoryDatabasePath);
      await db.execute('CREATE TABLE meta (id TEXT PRIMARY KEY, value TEXT NOT NULL)');
      final store = Store(db);

      final slot = ClassSlot(
        courseKey: 'algo:01',
        course: '알고리즘',
        weekday: 2, // 화요일
        start: 540, // 09:00
        end: 615,
        room: '공101',
        source: '시간표',
      );
      await store.setMeta(MetaKey.timetableEntries, jsonEncode([slot.toJson()]));

      final notice = CampusNotice(
        id: 'n_null_pub',
        title: '다음 수업 일정',
        course: '알고리즘',
        context: {},
        body: '다음 수업 안내입니다.',
        bodyHtml: '',
        media: const [],
        published: null, // null published!
      );

      // Now: 2026-11-10 (화) 08:00 KST (2026-11-09 23:00 UTC)
      final now = DateTime.utc(2026, 11, 9, 23, 0);
      final context = await aiTimetableContext(store, notice: notice, now: now);

      expect(context['referenceAt'], isNotNull, reason: 'published가 null이어도 referenceAt이 존재해야 함');
      final upcoming = context['upcoming'] as List;
      expect(upcoming, isNotEmpty, reason: 'published가 null이어도 upcoming occurrences가 비어있지 않아야 함');

      await db.close();
    });
  });

  group('Item 5: eligibleForAutoCancellation with past class today', () {
    test('returns false when class has already ended earlier today', () {
      final notice = CampusNotice(
        id: 'n_past',
        title: '오늘 휴강 안내',
        course: '컴퓨터네트워크',
        context: {},
        body: '오늘 수업 휴강합니다.',
        bodyHtml: '',
        media: const [],
        bodyFetched: true,
      );

      // Class was 09:00 ~ 10:15
      final candidate = ScheduleCandidate(
        title: '휴강',
        date: '2026-11-10',
        time: '09:00',
        endDate: '2026-11-10',
        endTime: '10:15',
        action: 'cancel',
        evidence: '오늘 수업 휴강합니다.',
        uncertainty: '',
        category: 'class',
      );

      // Now is 14:00 KST on the same day (2026-11-10 05:00 UTC)
      final nowAfterClass = DateTime.utc(2026, 11, 10, 5, 0);
      final resultAfter = eligibleForAutoCancellation(notice, candidate, nowAfterClass);
      expect(resultAfter, isFalse, reason: '오늘 이미 종료된 수업의 휴강은 자동 반영되지 않아야 함');

      // But before the class (08:00 KST = 2026-11-09 23:00 UTC)
      final nowBeforeClass = DateTime.utc(2026, 11, 9, 23, 0);
      final resultBefore = eligibleForAutoCancellation(notice, candidate, nowBeforeClass);
      expect(resultBefore, isTrue, reason: '수업 시작 전에는 정상적으로 자동 반영 가능해야 함');
    });
  });

  group('Item 6: matchNoticeCourseSlots section mismatch fallback', () {
    test('falls back to course name matching when course_id/class_no in context does not match timetable slot', () {
      final slot = ClassSlot(
        courseKey: 'CSE101:02', // Student is in section 02
        course: '컴퓨터구조',
        weekday: 1,
        start: 600,
        end: 675,
        room: '공303',
        source: '시간표',
      );

      final notice = CampusNotice(
        id: 'n_section',
        title: '컴퓨터구조 전체 공지',
        course: '컴퓨터구조',
        body: '휴강 공지입니다.',
        bodyHtml: '',
        media: const [],
        context: {
          'course_id': 'CSE101',
          'class_no': '01', // Notice was posted on section 01
        },
      );

      final matched = matchNoticeCourseSlots([slot], notice);
      expect(matched, isNotEmpty, reason: '공지 분반과 학생 분반이 달라도 과목명이 일치하면 폴백 매칭되어야 함');
      expect(matched.first.courseKey, 'CSE101:02');
    });
  });

  group('Item 7: TodayClassesCard during cancelled class time', () {
    testWidgets('shows cancellation status instead of "지금 수업" / "수업 중" during cancelled class hours', (tester) async {
      final slot = ClassSlot(
        courseKey: 'SE:01',
        course: '소프트웨어공학',
        weekday: 2, // 화요일
        start: 540, // 09:00
        end: 615,  // 10:15
        room: '공401',
        source: '시간표',
      );

      final cancellation = ClassCancellation(
        '2026-11-10:${slot.id}',
        slot.id,
        '2026-11-10',
        '소프트웨어공학',
        '학회 출장 휴강',
        noticeTitle: '학회 출장 휴강',
      );

      // Now is 2026-11-10 (화) 09:30 KST (class in progress!)
      final nowKst = DateTime(2026, 11, 10, 9, 30);

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: TodayClassesCard(
              entriesOverride: [slot],
              cancellationsOverride: [cancellation],
              now: nowKst,
            ),
          ),
        ),
      );

      // Verify that "지금 수업" and "수업 중" are NOT shown!
      expect(find.text('지금 수업'), findsNothing, reason: '휴강된 수업 시간에는 "지금 수업"으로 표시되지 않아야 함');
      expect(find.text('수업 중'), findsNothing, reason: '휴강된 수업 시간에는 "수업 중"으로 표시되지 않아야 함');
      expect(find.text('지금 휴강'), findsOneWidget, reason: '휴강된 수업 시간에는 "지금 휴강"으로 표시되어야 함');
      expect(find.text('휴강'), findsOneWidget, reason: '상태는 "휴강"으로 표시되어야 함');
    });
  });
}

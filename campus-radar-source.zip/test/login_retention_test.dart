import 'package:campus_radar/home_connection_status.dart';
import 'package:campus_radar/app_router.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:campus_radar/main.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const secure = MethodChannel('plugins.it_nomads.com/flutter_secure_storage');
  const sql = MethodChannel('com.tekartik.sqflite');
  final writes = <String>[];
  setUp(() {
    SharedPreferences.setMockInitialValues({});
    writes.clear();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(sql, (call) async {
          if (call.method == 'getDatabasesPath') return '/test';
          throw PlatformException(
            code: 'sqlite_error',
            message: 'database is locked',
          );
        });
  });
  tearDown(() {
    for (final channel in [secure, sql]) {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(channel, null);
    }
  });
  testWidgets('DB lock never changes a saved account to logged out', (
    tester,
  ) async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(secure, (call) async {
          if (call.method == 'read') {
            return call.arguments['key'] == 'id'
                ? 'example-id'
                : 'example-password';
          }
          writes.add(call.method);
          return null;
        });
    await tester.pumpWidget(
      const MaterialApp(onGenerateRoute: buildAppRoute, home: Dashboard()),
    );
    await tester.pumpAndSettle();
    expect(find.byType(HomeConnectionStatus), findsOneWidget);
    expect(find.text('포털 연결'), findsNothing);
    expect(find.textContaining('로그인 정보를 삭제하지 않았습니다'), findsOneWidget);
    expect(writes, isEmpty);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
  });
  testWidgets(
    'secure-storage read failure is unknown, never a new-login prompt',
    (tester) async {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(secure, (call) async {
            if (call.method == 'read') throw PlatformException(code: 'locked');
            writes.add(call.method);
            return null;
          });
      await tester.pumpWidget(
        const MaterialApp(onGenerateRoute: buildAppRoute, home: Dashboard()),
      );
      await tester.pumpAndSettle();
      expect(find.text('포털 연결'), findsNothing);
      expect(find.textContaining('로그인 정보 유실로 판단하지 않고'), findsOneWidget);
      expect(writes, isEmpty);
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox());
    },
  );
}

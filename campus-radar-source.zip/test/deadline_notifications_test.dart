import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/core/notification_gateway.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'dart:io';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/campus/services.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  late Directory temp;
  late Store store;
  final calls = <MethodCall>[];
  const channel = MethodChannel('dexterous.com/flutter/local_notifications');
  setUp(() async {
    calls.clear();
    temp = await Directory.systemTemp.createTemp('radar-deadline-test-');
    await databaseFactory.setDatabasesPath(temp.path);
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (c) async {
          calls.add(c);
          if (c.method == 'initialize' ||
              c.method == 'areNotificationsEnabled') {
            return true;
          }
          return null;
        });
    SharedPreferences.setMockInitialValues({});
    FlutterLocalNotificationsPlatform.instance =
        AndroidFlutterLocalNotificationsPlugin();
    await initNotifications();
    store = await Store.open();
  });
  tearDown(() async {
    await store.db.close();
    await temp.delete(recursive: true);
  });
  CampusItem item({
    String status = 'pending',
    int hours = 23,
    bool published = true,
  }) => CampusItem(
    key: 'test-only',
    type: 'LR',
    title: 'Synthetic task',
    course: 'Synthetic course',
    courseId: 'c',
    classNo: '1',
    contentsId: 'x',
    status: status,
    due: DateTime.now().toUtc().add(Duration(hours: hours)),
    published: published,
    context: {},
  );
  String token(CampusItem i) => 'due:${i.key}:${i.due!.toIso8601String()}';
  Future<void> seed(CampusItem i, {bool retained = true}) async {
    await store.replace([i]);
    await store.setMeta(token(i), 'scheduled');
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('scheduled', retained ? [token(i)] : []);
  }

  int count(String method) => calls.where((c) => c.method == method).length;
  test('Empty course response preserves last successful collection', () async {
    final task = item();
    await store.replace([task], courses: [
      {'course_id': 'c', 'class_no': '1', 'course_nm': task.course},
    ]);
    final courses = await store.meta(MetaKey.courses);
    final lastSuccess = await store.meta(MetaKey.lastSuccess);
    await expectLater(store.replace([], courses: []), throwsFormatException);
    expect((await store.items()).single.key, task.key);
    expect(await store.meta(MetaKey.courses), courses);
    expect(await store.meta(MetaKey.lastSuccess), lastSuccess);
  });
  test('Six visible new tasks produce one summary, once', () async {
    await store.replace([]);
    await store.replace([
      for (var i = 0; i < 6; i++)
        CampusItem(
          key: 'new-task-$i',
          type: 'LR',
          title: 'Synthetic task $i',
          course: 'Synthetic course',
          courseId: 'c',
          classNo: '1',
          contentsId: '$i',
          status: 'pending',
          due: null,
          published: true,
          context: {},
        ),
    ]);
    expect(await store.db.query('events', where: 'delivered=0'), hasLength(6));
    await reconcile(store);
    await reconcile(store);
    expect(count('show'), 1);
    expect(await store.db.query('events', where: 'delivered=0'), isEmpty);
  });
  test(
    'Passed trigger retains valid reminder without cancel or duplicate',
    () async {
      final i = item();
      await seed(i);
      await reconcile(store);
      await reconcile(store);
      expect(count('cancel'), 0);
      expect(count('show'), 0);
      expect(
        (await SharedPreferences.getInstance()).getStringList('scheduled'),
        [token(i)],
      );
    },
  );
  test('Previously cancelled reminder recovers once', () async {
    final i = item();
    await seed(i, retained: false);
    await reconcile(store);
    await reconcile(store);
    expect(count('show'), 1);
    expect(count('cancel'), 0);
    expect(await store.meta(token(i)), 'sent');
  });
  test(
    'Newly discovered task within a day sends once and stays tracked',
    () async {
      final i = item();
      await store.replace([i]);
      await reconcile(store);
      await reconcile(store);
      expect(count('show'), 1);
      expect(count('cancel'), 0);
    },
  );
  for (final reason in [
    'done',
    'excluded',
    'expired',
    'unpublished',
    'removed',
    'changed',
  ]) {
    test('Invalid reminder cancels for $reason', () async {
      final i = item(
        status: reason == 'done' ? 'done' : 'pending',
        hours: reason == 'expired' ? -1 : 23,
        published: reason != 'unpublished',
      );
      await seed(i);
      if (reason == 'excluded') await store.setMeta('excluded:${i.key}', 'yes');
      if (reason == 'removed') await store.db.delete('items');
      if (reason == 'changed') await store.replace([item(hours: 72)]);
      await reconcile(store);
      expect(count('cancel'), 1);
      expect(
        calls.where(
          (c) =>
              c.method == 'show' &&
              c.arguments['id'] == notificationId(token(i)),
        ),
        isEmpty,
      );
      expect(
        (await SharedPreferences.getInstance()).getStringList('scheduled'),
        isNot(contains(token(i))),
      );
    });
  }
  test('Future reminder remains scheduled', () async {
    final i = item(hours: 48);
    await seed(i);
    await reconcile(store);
    expect(count('zonedSchedule'), 1);
    expect(count('cancel'), 0);
    expect(count('show'), 0);
  });
}

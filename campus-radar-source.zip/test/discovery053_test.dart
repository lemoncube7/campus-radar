import 'dart:math';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:campus_radar/feature_discovery.dart';

void main() {
  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });
  test(
    'Daily rotation changes the recommendation without changing it on rebuild',
    () async {
      final today = DateTime(2026, 10, 27);
      final first = await FeatureDiscovery.choose(
        now: today,
        random: Random(3),
      );
      expect(
        await FeatureDiscovery.choose(now: today, random: Random(99)),
        first,
      );
      expect(
        await FeatureDiscovery.choose(
          now: today.add(const Duration(days: 1)),
          random: Random(3),
        ),
        isNot(first),
      );
    },
  );
  test(
    'Only unvisited features are chosen, selection is stable and another rotates',
    () async {
      await FeatureDiscovery.visit(DiscoverFeature.ai);
      await FeatureDiscovery.visit(DiscoverFeature.chat);
      final first = await FeatureDiscovery.choose(random: Random(7));
      expect(first, isNot(DiscoverFeature.ai));
      expect(first, isNot(DiscoverFeature.chat));
      expect(await FeatureDiscovery.choose(random: Random(91)), first);
      final next = await FeatureDiscovery.choose(
        another: true,
        random: Random(7),
      );
      expect(next, isNot(first));
      await FeatureDiscovery.visit(next!);
      expect(await FeatureDiscovery.choose(), isNot(next));
    },
  );
  test(
    'Historic configured features are adopted once, settings persist',
    () async {
      await (await SharedPreferences.getInstance()).setString(
        'radarTheme',
        'dark',
      );
      await FeatureDiscovery.adopt({
        DiscoverFeature.timetable,
        DiscoverFeature.calendar,
      });
      final p = await SharedPreferences.getInstance();
      expect(
        p.getStringList('discoveryVisited'),
        containsAll(['theme', 'timetable', 'calendar']),
      );
      await FeatureDiscovery.setEnabled(false);
      expect(await FeatureDiscovery.choose(), isNull);
      expect(p.getBool('discoveryEnabled'), false);
      await FeatureDiscovery.setEnabled(true);
      expect(await FeatureDiscovery.choose(), isNotNull);
    },
  );
  test(
    'Concurrent visit writes retain both records and exhausted catalog hides recommendation',
    () async {
      await Future.wait(DiscoverFeature.values.map(FeatureDiscovery.visit));
      expect(
        (await SharedPreferences.getInstance())
            .getStringList('discoveryVisited')!
            .toSet()
            .length,
        DiscoverFeature.values.length,
      );
      expect(await FeatureDiscovery.choose(), isNull);
    },
  );
}

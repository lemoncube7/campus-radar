import 'package:campus_radar/ai_timetable.dart';
import 'package:campus_radar/ai_protocol.dart';
import 'package:campus_radar/timetable_cancellations_page.dart';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/app_storage.dart';
import 'package:campus_radar/campus_models.dart';
import 'package:campus_radar/timetable_model.dart';
import 'package:campus_radar/timetable_exceptions.dart';
import 'package:campus_radar/transient_message.dart';
import 'package:campus_radar/lock_screen_settings_page.dart';
import 'package:campus_radar/native_bridge.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    temp = await Directory.systemTemp.createTemp('radar051-');
    await databaseFactory.setDatabasesPath(temp.path);
  });
  tearDown(() async {
    await temp.delete(recursive: true);
  });
  CampusItem item(DateTime due, {bool? attendance}) => CampusItem(
    key: 'x',
    type: 'LV',
    title: 'sample',
    course: 'sample',
    courseId: 'c',
    classNo: '1',
    contentsId: 'x',
    status: 'pending',
    due: due,
    attendanceRequired: attendance,
    context: {},
  );
  test(
    'Attendance metadata remains separate from completion and old cache unknown',
    () {
      final i = item(DateTime.utc(2030), attendance: false);
      final restored = CampusItem.fromJson(i.toJson());
      expect(restored.done, false);
      expect(restored.attendanceRequired, false);
      expect(restored.attendanceLabel, '출석 미반영');
      final old = Map<String, dynamic>.from(i.toJson())
        ..remove('attendanceRequired');
      expect(CampusItem.fromJson(old).attendanceRequired, null);
    },
  );
  test(
    'Default confirmation never hides, automatic policy supports restore and deadline extension',
    () async {
      final s = await Store.open();
      try {
        final due = DateTime.now().toUtc().subtract(const Duration(hours: 25));
        await s.replace([item(due)]);
        expect(await s.excluded(), isEmpty);
        await s.setMeta('overduePolicy', 'day');
        expect(await s.excluded(), contains('x'));
        await s.setTaskExcluded('x', false);
        expect(await s.excluded(), isEmpty);
        await s.replace([
          item(DateTime.now().toUtc().add(const Duration(hours: 2))),
        ]);
        expect(await s.excluded(), isEmpty);
        await s.setTaskExcluded('x', true);
        expect(await s.excluded(), contains('x'));
      } finally {
        await s.db.close();
      }
    },
  );
  test(
    'Cancellation excludes only exact date and selected slot, regular week remains',
    () {
      const slot = ClassSlot(
        courseKey: 'c',
        course: 'sample',
        weekday: 2,
        start: 600,
        end: 660,
      );
      const cancel = ClassCancellation(
        'cancel',
        'c:2:600',
        '2026-10-27',
        'sample',
        '공지',
      );
      final rows = decodeCancellations(jsonEncode([cancel.toJson()]));
      expect(classesOnDate([slot], rows, DateTime(2026, 10, 27)), isEmpty);
      expect(classesOnDate([slot], rows, DateTime(2026, 11, 3)), hasLength(1));
      expect(classesThisWeek([slot], rows, DateTime(2026, 10, 27)), isEmpty);
      expect(decodeCancellations('bad'), isEmpty);
    },
  );
  test('AI next class and upcoming both skip saved cancellation', () async {
    final store = await Store.open();
    try {
      const slot = ClassSlot(
        courseKey: 'c:1',
        course: 'sample',
        weekday: 2,
        start: 600,
        end: 660,
      );
      await store.setMeta('timetableEntries', jsonEncode([slot.toJson()]));
      await store.setMeta(
        'timetableCancellations',
        jsonEncode([
          const ClassCancellation(
            'x',
            'c:1:2:600',
            '2026-10-27',
            'sample',
            '',
          ).toJson(),
        ]),
      );
      final ctx = await aiTimetableContext(
        store,
        now: DateTime.utc(2026, 10, 27, 0),
      );
      expect((ctx['slots'] as List).single['nextDate'], '2026-11-03');
      expect(
        (ctx['upcoming'] as List).any((e) => e['date'] == '2026-10-27'),
        false,
      );
      expect((ctx['slots'] as List).single.containsKey('_localId'), false);
    } finally {
      await store.db.close();
    }
  });
  testWidgets(
    'Cancellation editor commits selected date using current session and refreshes native views',
    (t) async {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(
            const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
            (c) async => c.method == 'read' ? 'synthetic' : null,
          );
      var refreshed = false;
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(bridge, (c) async {
            if (c.method == 'refreshWidget') refreshed = true;
            return null;
          });
      await t.runAsync(() async {
        final s = await Store.open();
        await s.setMeta(
          'timetableEntries',
          jsonEncode([
            const ClassSlot(
              courseKey: 'c:1',
              course: 'sample',
              weekday: 2,
              start: 600,
              end: 660,
            ).toJson(),
          ]),
        );
        await s.db.close();
      });
      await t.pumpWidget(
        MaterialApp(
          home: Builder(
            builder: (c) => Scaffold(
              body: TextButton(
                onPressed: () => editCancellation(
                  c,
                  candidate: const ScheduleCandidate(
                    title: '휴강',
                    date: '2026-11-03',
                    time: '',
                    action: 'cancel',
                    evidence: '11월 3일 휴강',
                    uncertainty: '',
                    category: 'class',
                  ),
                ),
                child: const Text('open'),
              ),
            ),
          ),
        ),
      );
      await t.tap(find.text('open'));
      for (var i = 0; i < 8; i++) {
        await t.pump();
        await t.runAsync(
          () => Future<void>.delayed(const Duration(milliseconds: 80)),
        );
      }
      await t.pumpAndSettle();
      expect(find.byType(CheckboxListTile), findsOneWidget);
      await t.tap(find.text('선택한 날짜·수업에 휴강 적용'));
      for (var i = 0; i < 8; i++) {
        await t.pump();
        await t.runAsync(
          () => Future<void>.delayed(const Duration(milliseconds: 80)),
        );
      }
      await t.pumpAndSettle();
      await t.runAsync(() async {
        final saved = await Store.open();
        try {
          final rows = decodeCancellations(
            await saved.meta('timetableCancellations'),
          );
          expect(rows, hasLength(1));
          expect(rows.single.date, '2026-11-03');
          expect(refreshed, true);
        } finally {
          await saved.db.close();
        }
      });
      await t.pumpWidget(const SizedBox.shrink());
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(bridge, null);
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(
            const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
            null,
          );
    },
  );
  testWidgets(
    'Undo message expires even with accessible navigation without changing global semantics',
    (t) async {
      await t.pumpWidget(
        MaterialApp(
          home: MediaQuery(
            data: const MediaQueryData(accessibleNavigation: true),
            child: Scaffold(
              body: Builder(
                builder: (c) => TextButton(
                  onPressed: () => showTransientMessage(
                    c,
                    SnackBar(
                      content: const Text('finite'),
                      action: SnackBarAction(label: '실행 취소', onPressed: () {}),
                    ),
                  ),
                  child: const Text('show'),
                ),
              ),
            ),
          ),
        ),
      );
      await t.tap(find.text('show'));
      await t.pump();
      await t.pump(const Duration(milliseconds: 300));
      expect(find.text('finite'), findsOneWidget);
      await t.pump(const Duration(seconds: 9));
      await t.pump(const Duration(milliseconds: 300));
      expect(find.text('finite'), findsNothing);
      await t.pumpWidget(const SizedBox.shrink());
    },
  );
  testWidgets(
    'Preview reflects height and position, persists onscreen while settings scroll',
    (t) async {
      t.view.physicalSize = const Size(390, 844);
      t.view.devicePixelRatio = 1;
      addTearDown(t.view.resetPhysicalSize);
      addTearDown(t.view.resetDevicePixelRatio);
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(
            bridge,
            (c) async => c.method == 'lockSettings'
                ? {
                    'allowed': true,
                    'width': 270,
                    'height': 380,
                    'x': 100,
                    'y': 50,
                    'opacity': 80,
                  }
                : null,
          );
      await t.pumpWidget(const MaterialApp(home: LockScreenSettingsPage()));
      await t.pumpAndSettle();
      final before = t.getRect(find.byKey(const ValueKey('lock-preview-card')));
      await t.drag(find.byType(ListView), const Offset(0, -500));
      await t.pumpAndSettle();
      expect(
        t.getRect(find.byKey(const ValueKey('lock-preview-card'))),
        before,
      );
      expect(t.takeException(), isNull);
      await t.pumpWidget(const SizedBox.shrink());
      await t.pumpWidget(
        const MaterialApp(
          home: SizedBox(
            height: 200,
            child: LockCardPreview(
              width: 270,
              height: 180,
              x: 0,
              y: 0,
              opacity: 20,
              full: false,
              details: true,
            ),
          ),
        ),
      );
      await t.pump();
      final small = t.getSize(find.byKey(const ValueKey('lock-preview-card')));
      await t.pumpWidget(
        const MaterialApp(
          home: SizedBox(
            height: 200,
            child: LockCardPreview(
              width: 270,
              height: 640,
              x: 100,
              y: 100,
              opacity: 80,
              full: false,
              details: true,
            ),
          ),
        ),
      );
      await t.pump();
      expect(
        t.getSize(find.byKey(const ValueKey('lock-preview-card'))).height,
        greaterThan(small.height),
      );
      expect(t.takeException(), isNull);
      await t.pumpWidget(const SizedBox.shrink());
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(bridge, null);
    },
  );
}

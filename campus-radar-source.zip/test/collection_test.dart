import 'package:campus_radar/campus.dart';
import 'package:flutter_test/flutter_test.dart';

class CollectionClient extends CampusClient {
  final bool brokenExtra;
  final List<String> detailIds = [];
  CollectionClient({this.brokenExtra = false});
  @override
  Future<dynamic> api(
    String route,
    Map<String, dynamic>? payload, {
    String host = CampusClient.learning,
  }) async {
    switch (route) {
      case '/term/getYearTermList':
        return {
          'list': [
            {'current_term_yn': 'Y', 'term_year': '2026', 'term_cd': '2'},
          ],
        };
      case '/course/getStdMyCourseList':
        return {
          'course_list': [
            {'course_id': 'course', 'class_no': '1', 'course_nm': '수업'},
          ],
        };
      case '/course/addSessionCourseInfo':
        return {};
      case '/week/getStdWeekList':
        return {
          'week_list': [
            {
              'seq_list': [
                {
                  'learning_list': [
                    {
                      'module_type': 'LR',
                      'contents_id': 'weekly',
                      'weekseq_no': 'w1',
                    },
                    {
                      'module_type': 'LV',
                      'contents_id': null,
                      'weekseq_no': 'v1',
                      'complete_yn': 'N',
                    },
                  ],
                },
              ],
            },
          ],
        };
      case '/week/getStdEtcList':
        return brokenExtra
            ? {}
            : {
                'etc_list': [
                  {
                    'module_type': 'LR',
                    'report_no': 'extra',
                    'weekseq_no': null,
                  },
                  {
                    'module_type': 'LR',
                    'report_no': 'weekly',
                    'weekseq_no': 'w1',
                  },
                ],
              };
      case '/task/detail':
        detailIds.add('${payload!['report_no']}');
        return {
          'report_no': payload['report_no'],
          'report_nm': '과제',
          'report_apply_end_dt': '2026-10-21',
          'report_apply_end_tm': '23:59',
        };
      case '/task/stdDetail':
        return payload!['report_no'] == 'weekly'
            ? {'report_apply_no': 'submission', 'apply_yn': 'Y', 'temp_yn': 'N'}
            : null;
      default:
        throw StateError('Unexpected route $route');
    }
  }
}

void main() {
  test(
    'Collect weekly and unlinked tasks, deduplicate and preserve item identities',
    () async {
      final client = CollectionClient();
      addTearDown(client.close);
      final items = await client.fetchItems();
      expect(items.map((i) => i.key).toSet(), {
        'LR:course:1:weekly',
        'LR:course:1:extra',
        'LV:course:1:null:v1',
      });
      expect(client.detailIds, ['weekly', 'extra']);
      expect(items.singleWhere((i) => i.contentsId == 'weekly').status, 'done');
      expect(
        items.singleWhere((i) => i.contentsId == 'extra').status,
        'pending',
      );
      expect(
        items.singleWhere((i) => i.contentsId == 'extra').due,
        DateTime.utc(2026, 10, 21, 14, 59),
      );
    },
  );
  test(
    'Missing extra list fails instead of silently deleting unlinked tasks',
    () async {
      final client = CollectionClient(brokenExtra: true);
      addTearDown(client.close);
      await expectLater(client.fetchItems(), throwsA(isA<CampusException>()));
    },
  );
}

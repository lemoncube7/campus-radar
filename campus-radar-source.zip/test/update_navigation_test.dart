import 'package:campus_radar/app_navigation.dart';
import 'package:campus_radar/main.dart';
import 'package:campus_radar/update_notification.dart';
import 'package:campus_radar/update_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  testWidgets('Update notification opens update page without an item lookup', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(const RadarApp(home: Scaffold(body: Text('home'))));
    // Navigation futures resolve when the destination is popped.
    final opened = openItem(updateNotificationTarget);
    await tester.pumpAndSettle();
    expect(find.byType(UpdatePage), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.pageBack();
    await tester.pumpAndSettle();
    await opened;
    expect(find.text('home'), findsOneWidget);
    await tester.pumpWidget(const SizedBox.shrink());
  });
}

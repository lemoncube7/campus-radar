import 'package:campus_radar/app_router.dart';
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/portal_connect.dart';
import 'package:campus_radar/campus.dart';

void main() {
  testWidgets(
    'Reconnect pre-fills and locks current account without exposing a saved password',
    (tester) async {
      var called = false;
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: PortalConnectSheet(
              initialId: 'synthetic-account',
              lockAccount: true,
              connect: (_, __) async {
                called = true;
              },
            ),
          ),
        ),
      );
      final fields = tester
          .widgetList<TextField>(find.byType(TextField))
          .toList();
      expect(fields.first.controller!.text, 'synthetic-account');
      expect(fields.first.readOnly, true);
      expect(fields.last.controller!.text, isEmpty);
      expect(fields.last.obscureText, true);
      expect(called, false);
      await tester.pumpWidget(const SizedBox.shrink());
    },
  );
  test('rejected authentication never writes over saved account', () async {
    final values = <String, String?>{'id': 'old', 'pw': 'old-secret'};
    var writes = 0;
    await expectLater(
      verifyAndSavePortal(
        id: 'new',
        password: 'wrong',
        authenticate: (_, _) async => throw CampusException('로그인 거절'),
        read: (k) async => values[k],
        write: (k, v) async {
          writes++;
          values[k] = v;
        },
      ),
      throwsA(isA<CampusException>()),
    );
    expect(writes, 0);
    expect(values, {'id': 'old', 'pw': 'old-secret'});
  });
  test('empty input never authenticates or saves', () async {
    var calls = 0;
    await expectLater(
      verifyAndSavePortal(
        id: ' ',
        password: '',
        authenticate: (_, _) async {
          calls++;
        },
        read: (_) async => null,
        write: (_, _) async {
          calls++;
        },
      ),
      throwsA(isA<CampusException>()),
    );
    expect(calls, 0);
  });
  test(
    'save starts only after successful authentication and verifies readback',
    () async {
      final values = <String, String?>{};
      final order = <String>[];
      await verifyAndSavePortal(
        id: ' new ',
        password: 'secret',
        authenticate: (id, pw) async {
          expect(id, 'new');
          order.add('authenticated');
        },
        read: (k) async => values[k],
        write: (k, v) async {
          order.add('write');
          values[k] = v;
        },
      );
      expect(order.first, 'authenticated');
      expect(values, {'id': 'new', 'pw': 'secret'});
    },
  );
  test('partial secure storage failure restores both old values', () async {
    final values = <String, String?>{'id': 'old', 'pw': 'old-secret'};
    var failed = false;
    await expectLater(
      verifyAndSavePortal(
        id: 'new',
        password: 'secret',
        authenticate: (_, _) async {},
        read: (k) async => values[k],
        write: (k, v) async {
          if (k == 'id' && !failed) {
            failed = true;
            throw StateError('storage');
          }
          values[k] = v;
        },
      ),
      throwsA(isA<CampusException>()),
    );
    expect(values, {'id': 'old', 'pw': 'old-secret'});
  });
  test('transport errors are distinct and never expose raw exception text', () {
    expect(
      portalConnectionError(const SocketException('PRIVATE')),
      contains('인터넷'),
    );
    expect(portalConnectionError(TimeoutException('PRIVATE')), contains('늦어'));
    expect(
      portalConnectionError(StateError('PRIVATE')),
      isNot(contains('PRIVATE')),
    );
  });
  testWidgets(
    'rejection stays in sheet, allows correction, then closes on success',
    (tester) async {
      var attempts = 0;
      final gate = Completer<void>();
      await tester.pumpWidget(
        MaterialApp(
          onGenerateRoute: buildAppRoute,
          home: Builder(
            builder: (context) => Scaffold(
              body: TextButton(
                onPressed: () => showModalBottomSheet<bool>(
                  context: context,
                  isScrollControlled: true,
                  builder: (_) => PortalConnectSheet(
                    connect: (id, pw) async {
                      attempts++;
                      if (attempts == 1) {
                        await gate.future;
                        throw CampusException('아이디·비밀번호를 확인해 주세요.');
                      }
                    },
                  ),
                ),
                child: const Text('연결 화면'),
              ),
            ),
          ),
        ),
      );
      await tester.tap(find.text('연결 화면'));
      await tester.pumpAndSettle();
      await tester.enterText(find.byType(TextField).first, 'example');
      await tester.enterText(find.byType(TextField).last, 'wrong');
      await tester.tap(find.text('포털 연결'));
      await tester.pump();
      expect(find.text('로그인 확인 중…'), findsOneWidget);
      expect(
        tester.widget<TextField>(find.byType(TextField).first).enabled,
        false,
      );
      gate.complete();
      await tester.pumpAndSettle();
      expect(find.text('아이디·비밀번호를 확인해 주세요.'), findsOneWidget);
      expect(find.byType(PortalConnectSheet), findsOneWidget);
      await tester.enterText(find.byType(TextField).last, 'correct');
      await tester.tap(find.text('포털 연결'));
      await tester.pumpAndSettle();
      expect(attempts, 2);
      expect(find.byType(PortalConnectSheet), findsNothing);
      expect(tester.takeException(), isNull);
    },
  );
}

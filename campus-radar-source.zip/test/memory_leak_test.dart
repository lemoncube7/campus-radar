import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/home/home_agenda_card.dart';
import 'package:campus_radar/campus/campus_models.dart';

void main() {
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  late Directory temp;
  late Store store;

  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    temp = await Directory.systemTemp.createTemp('agenda-mem-');
    await databaseFactory.setDatabasesPath(temp.path);
    store = await Store.open();
    final notices = [
      for (var i = 0; i < 20; i++)
        CampusNotice(
          id: 'n$i',
          course: 'Course $i',
          title: 'Notice $i',
          context: const {},
        ),
    ];
    await store.replaceNotices(notices);
  });

  tearDown(() async {
    await store.db.close();
    await Future<void>.delayed(const Duration(milliseconds: 100));
    try {
      await temp.delete(recursive: true);
    } catch (_) {}
  });

  testWidgets('HomeAgendaCard with refreshToken stays bounded across 300 cycles', (tester) async {
    final rss0 = ProcessInfo.currentRss;
    for (var i = 0; i < 300; i++) {
      await tester.pumpWidget(MaterialApp(
        home: Scaffold(
          body: HomeAgendaCard(
            key: const ValueKey('agenda:stable'),
            refreshToken: i,
            compact: true,
          ),
        ),
      ));
      await tester.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 5)));
      await tester.pump();
    }
    await tester.pumpWidget(const SizedBox());
    await tester.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 50)));
    await tester.pump();

    final rss300 = ProcessInfo.currentRss;
    final diffMb = (rss300 - rss0) / (1024 * 1024);
    expect(diffMb, lessThan(60.0));
  });
}

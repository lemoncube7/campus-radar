import 'dart:convert';
import 'package:campus_radar/platform/desktop.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' show TZDateTime;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/campus/services.dart';

class TestWindowsAlerts extends FlutterLocalNotificationsPlatform
    implements FlutterLocalNotificationsWindows {
  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
  final shown = <int>[];
  final cancelled = <int>[];
  @override
  Future<void> show({
    required int id,
    String? title,
    String? body,
    String? payload,
    WindowsNotificationDetails? notificationDetails,
  }) async {
    shown.add(id);
  }

  @override
  Future<void> cancel({required int id}) async {
    cancelled.add(id);
  }

  @override
  Future<void> zonedSchedule({
    required int id,
    String? title,
    String? body,
    required TZDateTime scheduledDate,
    WindowsNotificationDetails? notificationDetails,
    String? payload,
    DateTimeComponents? matchDateTimeComponents,
  }) => throw UnimplementedError();

  @override
  Future<void> periodicallyShow({
    required int id,
    String? title,
    String? body,
    required RepeatInterval repeatInterval,
    WindowsNotificationDetails? notificationDetails,
    String? payload,
  }) => throw UnimplementedError();
}

void main() {
  if (!Platform.isWindows) {
    test(
      'Windows OS notification integration requires Windows',
      () {},
      skip: true,
    );
    return;
  }
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  late Directory temp;
  late Store store;
  late TestWindowsAlerts alerts;
  setUp(() async {
    debugDefaultTargetPlatformOverride = TargetPlatform.windows;
    SharedPreferences.setMockInitialValues({});
    alerts = TestWindowsAlerts();
    FlutterLocalNotificationsPlatform.instance = alerts;
    temp = await Directory.systemTemp.createTemp('radar-windows-alerts-');
    await databaseFactory.setDatabasesPath(temp.path);
    store = await Store.open();
  });
  tearDown(() async {
    await store.db.close();
    await temp.delete(recursive: true);
    debugDefaultTargetPlatformOverride = null;
  });
  test(
    'Timetable reminder sends once in its window and respects expiry',
    () async {
      final p = await SharedPreferences.getInstance();
      await p.setBool('desktopTimetableEnabled', true);
      await p.setInt('desktopTimetableLead', 30);
      await p.setString('desktopTimetableUntil', '2026-10-21');
      await store.setMeta(
        'timetableEntries',
        jsonEncode([
          const ClassSlot(
            courseKey: 'c',
            course: 'Synthetic',
            weekday: 3,
            start: 600,
            end: 660,
          ).toJson(),
        ]),
      );
      await desktopTimetableAlerts(
        store,
        p,
        clock: DateTime.utc(2026, 10, 21, 0, 20),
      );
      expect(alerts.shown, isEmpty);
      await desktopTimetableAlerts(
        store,
        p,
        clock: DateTime.utc(2026, 10, 21, 0, 31),
      );
      await desktopTimetableAlerts(
        store,
        p,
        clock: DateTime.utc(2026, 10, 21, 0, 32),
      );
      expect(alerts.shown.length, 1);
      await desktopTimetableAlerts(
        store,
        p,
        clock: DateTime.utc(2026, 10, 28, 0, 31),
      );
      expect(alerts.shown.length, 1);
    },
  );
  CampusItem item(int hours, {String status = 'pending'}) => CampusItem(
    key: 'windows-test',
    type: 'LR',
    title: 'Synthetic',
    course: 'Synthetic',
    courseId: 'c',
    classNo: '1',
    contentsId: 'x',
    status: status,
    due: DateTime.now().toUtc().add(Duration(hours: hours)),
    context: {},
  );
  Future<void> seed(CampusItem i) async {
    await store.replace([i]);
    await store.db.update('events', {'delivered': 1});
  }

  test(
    'Desktop future reminder is tracked without using unsupported OS scheduler',
    () async {
      final i = item(25);
      await seed(i);
      await reconcile(store);
      expect(alerts.shown, isEmpty);
      expect(
        (await SharedPreferences.getInstance()).getStringList('scheduled'),
        ['due:${i.key}:${i.due!.toIso8601String()}'],
      );
    },
  );
  test(
    'Desktop due reminder sends once, then completion removes tracked token',
    () async {
      final i = item(23);
      await seed(i);
      await reconcile(store);
      await reconcile(store);
      expect(alerts.shown.length, 1);
      await seed(item(23, status: 'done'));
      await reconcile(store);
      expect(alerts.shown.length, 1);
      expect(
        (await SharedPreferences.getInstance()).getStringList('scheduled'),
        isEmpty,
      );
    },
  );
}

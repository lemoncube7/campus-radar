import 'dart:convert';

import 'package:campus_radar/campus/campus_media.dart';
import 'package:campus_radar/campus/material_catalog.dart';
import 'package:campus_radar/export/academic_export.dart';
import 'package:campus_radar/export/drive_uploader.dart';
import 'package:flutter_test/flutter_test.dart';

/// In-memory Drive: files by id with name, parents, trashed, content.
class FakeDrive {
  final files = <String, Map<String, dynamic>>{};
  final calls = <String>[];
  var next = 0;
  Future<({int status, String body})> call(
    String method,
    Uri url,
    String token, {
    List<int>? body,
    String? contentType,
  }) async {
    calls.add('$method ${url.path}');
    final path = url.path;
    if (path.endsWith('/files/generateIds')) {
      return (
        status: 200,
        body: jsonEncode({
          'ids': ['id${next++}'],
        }),
      );
    }
    if (method == 'POST' && path.endsWith('/drive/v3/files')) {
      final m = jsonDecode(utf8.decode(body!)) as Map<String, dynamic>;
      if (files.containsKey(m['id'])) return (status: 409, body: '');
      final timeSeq = next.toString().padLeft(3, '0');
      files[m['id']] = {
        ...m,
        'trashed': false,
        'content': '',
        'size': m['size'] ?? 0,
        'parents': (m['parents'] as List?)?.map((p) => '$p').toList() ?? <String>[],
        'appProperties': m['appProperties'] != null
            ? Map<String, String>.from((m['appProperties'] as Map).map((k, v) => MapEntry('$k', '$v')))
            : <String, String>{},
        'createdTime': m['createdTime'] ?? '2026-11-10T00:00:$timeSeq.000Z',
      };
      return (status: 200, body: jsonEncode({'id': m['id']}));
    }
    if (method == 'GET' && path.endsWith('/drive/v3/files')) {
      final q = url.queryParameters['q'] ?? '';
      final parentMatch = RegExp(r"'([^']+)'\s+in\s+parents").firstMatch(q);
      final parent = parentMatch?.group(1);
      final nameMatch = RegExp(r"name='([^']*)'").firstMatch(q);
      final name = nameMatch
          ?.group(1)
          ?.replaceAll(r"\'", "'")
          .replaceAll(r'\\', r'\');
      final folderOnly =
          q.contains("mimeType='application/vnd.google-apps.folder'");
      final hasCrKind = q.contains("key='crKind' and value=");

      final matching = files.values.where((f) {
        if (f['trashed'] == true) return false;
        if (hasCrKind) {
          final props = f['appProperties'] as Map?;
          if (props == null || props['crKind'] == null || '${props['crKind']}'.isEmpty) {
            return false;
          }
        }
        if (parent != null) {
          final parents =
              (f['parents'] as List?)?.map((p) => '$p').toList() ?? [];
          if (parent == 'root') {
            if (parents.isNotEmpty && !parents.contains('root')) return false;
          } else {
            if (!parents.contains(parent)) return false;
          }
        }
        if (name != null && f['name'] != name) return false;
        if (folderOnly &&
            f['mimeType'] != 'application/vnd.google-apps.folder') {
          return false;
        }
        return true;
      }).toList();

      return (
        status: 200,
        body: jsonEncode({
          'files': matching
              .map(
                (f) => {
                  'id': f['id'],
                  'name': f['name'] ?? '',
                  'createdTime': f['createdTime'] ?? '',
                  'mimeType': f['mimeType'] ?? '',
                  'size': f['size']?.toString() ?? '0',
                  'parents': f['parents'] ?? <String>[],
                  'appProperties': f['appProperties'] ?? <String, String>{},
                },
              )
              .toList(),
        }),
      );
    }
    final id = path.split('/').last;
    final f = files[id];
    if (f == null) return (status: 404, body: '');
    if (method == 'GET') {
      return (
        status: 200,
        body: jsonEncode({'id': id, 'trashed': f['trashed']}),
      );
    }
    if (path.startsWith('/upload/')) {
      f['content'] = utf8.decode(body!);
      f['size'] = body.length;
      return (status: 200, body: '{}');
    }
    if (method == 'PATCH') {
      if (url.queryParameters['addParents'] != null) {
        final added = url.queryParameters['addParents']!.split(',');
        final curParents = (f['parents'] as List?)?.map((p) => '$p').toList() ?? [];
        for (final a in added) {
          if (!curParents.contains(a)) curParents.add(a);
        }
        f['parents'] = curParents;
      }
      if (url.queryParameters['removeParents'] != null) {
        final removed = url.queryParameters['removeParents']!.split(',');
        final curParents = (f['parents'] as List?)?.map((p) => '$p').toList() ?? [];
        curParents.removeWhere((p) => removed.contains(p));
        f['parents'] = curParents;
      }
      if (body != null && body.isNotEmpty) {
        final patchBody = jsonDecode(utf8.decode(body)) as Map;
        if (patchBody.containsKey('trashed')) {
          f['trashed'] = patchBody['trashed'];
        }
        if (patchBody.containsKey('name')) {
          f['name'] = patchBody['name'];
        }
        if (patchBody.containsKey('appProperties')) {
          final existingProps = (f['appProperties'] as Map?) ?? <String, String>{};
          f['appProperties'] = {
            ...existingProps,
            ...Map<String, String>.from((patchBody['appProperties'] as Map).map((k, v) => MapEntry('$k', '$v'))),
          };
        }
      }
      return (status: 200, body: '{}');
    }
    return (status: 200, body: '{}');
  }
}

void main() {
  test('creates the folder layout, skips unchanged, replaces trashed, '
      'trashes removed documents', () async {
    final drive = FakeDrive();
    final api = DriveApi('t', transport: drive.call);
    final state = <String, dynamic>{};
    final docs = {
      startDocument: 'start',
      '학업 현황.txt': 'status',
      '과목/물리.txt': 'physics',
    };
    var r = await uploadDriveDocuments(
      api: api,
      state: state,
      documents: docs,
      checkpoint: () async {},
    );
    expect(r, (writes: 3, complete: true));
    final physics = drive.files[state['files']['과목/물리.txt']]!;
    expect(physics['parents'], [state['courseFolder']]);
    expect(physics['name'], '물리.txt');
    expect(drive.files[state['files'][startDocument]]!['content'], 'start');

    // Unchanged: no writes.
    r = await uploadDriveDocuments(
      api: api,
      state: state,
      documents: docs,
      checkpoint: () async {},
    );
    expect(r.writes, 0);

    // User trashed one file: it gets a new id; a removed doc is trashed.
    final oldStatus = state['files']['학업 현황.txt'];
    drive.files[oldStatus]!['trashed'] = true;
    r = await uploadDriveDocuments(
      api: api,
      state: state,
      documents: {startDocument: 'start2', '학업 현황.txt': 'status'},
      checkpoint: () async {},
    );
    expect(r.writes, 2);
    expect(state['files']['학업 현황.txt'], isNot(oldStatus));
    expect(state['files'].containsKey('과목/물리.txt'), isFalse);
    expect(physics['trashed'], isTrue);
    // The start file is written last.
    final uploads = drive.calls.where((c) => c.startsWith('PATCH /upload/'));
    expect(uploads.last, contains(state['files'][startDocument]));
  });

  test('stops after the write budget and resumes', () async {
    final drive = FakeDrive();
    final api = DriveApi('t', transport: drive.call);
    final state = <String, dynamic>{};
    final docs = {for (var i = 0; i < 5; i++) '과목/$i.txt': '$i'};
    final first = await uploadDriveDocuments(
      api: api,
      state: state,
      documents: docs,
      checkpoint: () async {},
      maxWrites: 3,
    );
    expect(first, (writes: 3, complete: false));
    final second = await uploadDriveDocuments(
      api: api,
      state: state,
      documents: docs,
      checkpoint: () async {},
      maxWrites: 3,
    );
    expect(second, (writes: 2, complete: true));
  });

  test('a 401 surfaces as DriveHttpFailure', () async {
    final api = DriveApi(
      't',
      transport: (m, u, t, {body, contentType}) async =>
          (status: 401, body: ''),
    );
    expect(
      () => uploadDriveDocuments(
        api: api,
        state: {},
        documents: {startDocument: 'x'},
        checkpoint: () async {},
      ),
      throwsA(isA<DriveHttpFailure>().having((e) => e.status, 'status', 401)),
    );
  });

  group('DriveSyncLogic parity with Android DriveSyncLogic.kt', () {
    test('legacy upgrade with blank term does not archive current semester', () {
      final previousTerm = '';
      final currentTerm = '2026-2';
      expect(
        DriveSyncLogic.shouldArchiveSemester(previousTerm, currentTerm),
        isFalse,
      );
    });

    test('semester transition archives previous term', () {
      expect(DriveSyncLogic.shouldArchiveSemester('2026-1', '2026-2'), isTrue);
      expect(DriveSyncLogic.shouldArchiveSemester('2026-2', '2026-2'), isFalse);
      expect(DriveSyncLogic.shouldArchiveSemester('2026-1', ''), isFalse);
      expect(DriveSyncLogic.shouldArchiveSemester('   ', '2026-2'), isFalse);
    });

    test('reusing existing folder retains tracked files', () {
      expect(DriveSyncLogic.shouldPruneTrackedFiles(false), isFalse);
      expect(DriveSyncLogic.shouldPruneTrackedFiles(true), isTrue);
    });

    test('transient database lock retains active epoch', () {
      expect(
        DriveSyncLogic.isEpochValid(null, 'epoch-123', true),
        isTrue,
      );
      expect(
        DriveSyncLogic.isEpochValid('epoch-123', 'epoch-123', false),
        isTrue,
      );
      expect(
        DriveSyncLogic.isEpochValid('epoch-456', 'epoch-123', false),
        isFalse,
      );
      expect(
        DriveSyncLogic.isEpochValid(null, 'epoch-123', false),
        isFalse,
      );
    });

    test('semester archiving naming rules and resource key filters', () {
      expect(
        DriveSyncLogic.archivedCourseFolderName('2026-1'),
        '지난 내보내기 (2026-1) - 과목',
      );
      expect(
        DriveSyncLogic.archivedMaterialsFolderName('2026-1'),
        '지난 내보내기 (2026-1) - 자료',
      );
      expect(
        DriveSyncLogic.archivedZipName('2026-1'),
        '지난 내보내기 (2026-1) - 첨부원본.zip',
      );

      expect(DriveSyncLogic.isSemesterScopedKey('과목/물리.txt'), isTrue);
      expect(DriveSyncLogic.isSemesterScopedKey('자료/수학/1.pdf'), isTrue);
      expect(
        DriveSyncLogic.isSemesterScopedKey('캠퍼스레이더 첨부원본.zip'),
        isTrue,
      );
      expect(DriveSyncLogic.isSemesterScopedKey('캠퍼스레이더 시작.txt'), isFalse);
      expect(DriveSyncLogic.isSemesterScopedKey('학업 현황.txt'), isFalse);
    });
  });

  group('listChildren reuse and deduplication', () {
    test('reuses existing root, course and file IDs without duplicate creation', () async {
      final drive = FakeDrive();
      final api = DriveApi('t', transport: drive.call);

      // Pre-populate Drive with existing folders and files
      drive.files['rootFolder'] = {
        'id': 'rootFolder',
        'name': '캠퍼스레이더',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': <String>[],
        'trashed': false,
        'createdTime': '2026-11-01T00:00:00.000Z',
      };
      drive.files['courseFolder'] = {
        'id': 'courseFolder',
        'name': '과목',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': ['rootFolder'],
        'trashed': false,
        'createdTime': '2026-11-01T00:00:01.000Z',
      };
      drive.files['statusFile'] = {
        'id': 'statusFile',
        'name': '학업 현황.txt',
        'mimeType': 'text/plain',
        'parents': ['rootFolder'],
        'trashed': false,
        'createdTime': '2026-11-01T00:00:02.000Z',
        'content': 'old status',
      };

      final state = <String, dynamic>{};
      final docs = {
        '학업 현황.txt': 'new status',
        '과목/수학.txt': 'math',
      };

      final r = await uploadDriveDocuments(
        api: api,
        state: state,
        documents: docs,
        checkpoint: () async {},
      );

      expect(r.writes, 2);
      expect(r.complete, isTrue);

      // Verify that existing root and course folders were reused
      expect(state['folder'], 'rootFolder');
      expect(state['courseFolder'], 'courseFolder');

      // Verify that status file was reused
      expect(state['files']['학업 현황.txt'], 'statusFile');
      expect(drive.files['statusFile']!['content'], 'new status');

      // Verify that only the new math file was created, not duplicate folders
      final createdFolders = drive.files.values.where(
        (f) => f['mimeType'] == 'application/vnd.google-apps.folder',
      );
      expect(createdFolders.length, 2); // only the pre-populated 2 folders exist
    });
  });

  group('semester archiving & materials upload', () {
    test('archives previous semester on term transition and retains non-semester files', () async {
      final drive = FakeDrive();
      final api = DriveApi('t', transport: drive.call);
      final state = <String, dynamic>{
        'term': '2026-1',
      };

      // 1. First upload in 2026-1
      var r = await uploadDriveDocuments(
        api: api,
        state: state,
        term: '2026-1',
        documents: {
          '학업 현황.txt': 'status 1',
          '과목/물리.txt': 'physics 1',
          '캠퍼스레이더 첨부원본.zip': base64Encode(utf8.encode('zip1')),
        },
        fileEntries: {
          '자료/물리/실험.pdf': {
            'bytes': utf8.encode('pdf 1'),
            'sha256': DriveApi.digest('pdf 1'),
            'mime': 'application/pdf',
          },
        },
        checkpoint: () async {},
      );
      expect(r.complete, isTrue);
      expect(state['term'], '2026-1');

      final oldCourseFolderId = state['courseFolder'];
      final oldMaterialsFolderId = state['materialsFolder'];
      final oldZipId = state['files']['캠퍼스레이더 첨부원본.zip'];
      final oldStatusId = state['files']['학업 현황.txt'];

      // 2. Semester transition: upload in 2026-2
      r = await uploadDriveDocuments(
        api: api,
        state: state,
        term: '2026-2',
        documents: {
          '학업 현황.txt': 'status 2',
          '과목/화학.txt': 'chemistry 2',
          '캠퍼스레이더 첨부원본.zip': base64Encode(utf8.encode('zip2')),
        },
        fileEntries: {
          '자료/화학/실험2.pdf': {
            'bytes': utf8.encode('pdf 2'),
            'sha256': DriveApi.digest('pdf 2'),
            'mime': 'application/pdf',
          },
        },
        checkpoint: () async {},
      );
      expect(r.complete, isTrue);

      // Verify old folders and zip were renamed to "지난 내보내기 (2026-1) - ..."
      expect(
        drive.files[oldCourseFolderId]!['name'],
        '지난 내보내기 (2026-1) - 과목',
      );
      expect(
        drive.files[oldMaterialsFolderId]!['name'],
        '지난 내보내기 (2026-1) - 자료',
      );
      // 0.6.6 retired the ZIP: the root copy is trashed, not archived.
      expect(drive.files[oldZipId]!['trashed'], isTrue);

      // Verify state now reflects 2026-2 with new folder IDs
      expect(state['term'], '2026-2');
      expect(state['courseFolder'], isNot(oldCourseFolderId));
      expect(state['materialsFolder'], isNot(oldMaterialsFolderId));

      // Non-semester file "학업 현황.txt" retained its ID
      expect(state['files']['학업 현황.txt'], oldStatusId);

      // Old semester files were pruned from tracking
      expect(state['files'].containsKey('과목/물리.txt'), isFalse);
      expect(state['files'].containsKey('자료/물리/실험.pdf'), isFalse);

      // New semester files are tracked
      expect(state['files'].containsKey('과목/화학.txt'), isTrue);
      expect(state['files'].containsKey('자료/화학/실험2.pdf'), isTrue);
    });

    test('legacy upgrade with blank term does not rename folders', () async {
      final drive = FakeDrive();
      final api = DriveApi('t', transport: drive.call);
      final state = <String, dynamic>{
        'term': '', // legacy 0.6.4 user
      };

      // Initial run
      var r = await uploadDriveDocuments(
        api: api,
        state: state,
        term: '2026-2',
        documents: {
          '학업 현황.txt': 'status',
          '과목/물리.txt': 'physics',
        },
        checkpoint: () async {},
      );
      expect(r.complete, isTrue);
      expect(state['term'], '2026-2');

      final courseFolderId = state['courseFolder'];
      expect(drive.files[courseFolderId]!['name'], '과목');

      // Subsequent run with same term
      r = await uploadDriveDocuments(
        api: api,
        state: state,
        term: '2026-2',
        documents: {
          '학업 현황.txt': 'status',
          '과목/물리.txt': 'physics',
        },
        checkpoint: () async {},
      );
      expect(r.writes, 0);
      expect(drive.files[courseFolderId]!['name'], '과목');
    });

    test('upload write budget stops before start document and resumes', () async {
      final drive = FakeDrive();
      final api = DriveApi('t', transport: drive.call);
      final state = <String, dynamic>{};
      final docs = {
        startDocument: 'start',
        '과목/1.txt': '1',
        '과목/2.txt': '2',
      };
      final files = {
        '자료/수학/a.pdf': {
          'bytes': [1],
          'sha256': 'hash_a',
          'mime': 'application/pdf',
        },
        '자료/수학/b.pdf': {
          'bytes': [2],
          'sha256': 'hash_b',
          'mime': 'application/pdf',
        },
      };

      // maxWrites = 2: should write 2 docs and stop before start document
      final first = await uploadDriveDocuments(
        api: api,
        state: state,
        documents: docs,
        fileEntries: files,
        checkpoint: () async {},
        maxWrites: 2,
      );
      expect(first.writes, 2);
      expect(first.complete, isFalse);
      expect(state['files'].containsKey(startDocument), isFalse);

      // Second pass with maxWrites = 3: completes the remaining 2 materials + start document
      final second = await uploadDriveDocuments(
        api: api,
        state: state,
        documents: docs,
        fileEntries: files,
        checkpoint: () async {},
        maxWrites: 5,
      );
      expect(second.writes, 3);
      expect(second.complete, isTrue);
      expect(state['files'].containsKey(startDocument), isTrue);
    });
  });

  group('task 64 regression tests: duplicate prevention & upgrade reuse', () {
    test('same attachment across multiple assignments reuses filename and driveKey without (n) duplication', () {
      const media = CampusMedia(
        name: '(양식) 어드벤처디자인_팀활동보고서.hwp',
        url: 'https://dcs-lcms.cnu.ac.kr/api/v1/share/downloadFile',
        form: {'file_no': '47616'},
        size: 47616,
      );

      // 9 different study materials representing 9 assignments/notices attaching the same template
      final materials = List.generate(
        9,
        (i) => StudyMaterial(
          id: 'mat_id_$i',
          sourceId: 'src_id_$i',
          sourceType: 'LR',
          title: '과제 $i',
          course: '어드벤처디자인',
          media: media,
          date: DateTime.utc(2026, 11, i + 1),
        ),
      );

      final paths = resolveDriveAttachmentPaths(materials);
      expect(paths.length, 9);

      for (var i = 0; i < 9; i++) {
        final p = paths['mat_id_$i']!;
        expect(p.fileName, '(양식) 어드벤처디자인_팀활동보고서.hwp',
            reason: 'Item $i must not have (2) through (9) suffix');
        expect(p.driveKey, '자료/어드벤처디자인/(양식) 어드벤처디자인_팀활동보고서.hwp');
      }

      // If a different attachment with the same filename is attached, it receives (2)
      const differentMedia = CampusMedia(
        name: '(양식) 어드벤처디자인_팀활동보고서.hwp',
        url: 'https://dcs-lcms.cnu.ac.kr/api/v1/share/downloadFile',
        form: {'file_no': '99999'}, // different file_no!
        size: 50000,
      );
      final withDifferent = [
        ...materials,
        StudyMaterial(
          id: 'mat_different',
          sourceId: 'src_different',
          sourceType: 'LR',
          title: '다른 과제',
          course: '어드벤처디자인',
          media: differentMedia,
          date: DateTime.utc(2026, 11, 20),
        ),
      ];

      final pathsWithDiff = resolveDriveAttachmentPaths(withDifferent);
      expect(pathsWithDiff['mat_different']!.fileName,
          '(양식) 어드벤처디자인_팀활동보고서 (2).hwp');
    });

    test('0.6.5 state upgrade migrates legacy keys and skips redundant re-upload', () async {
      final drive = FakeDrive();
      final api = DriveApi('t', transport: drive.call);

      // Pre-populate Drive as 0.6.5 would have created
      drive.files['rootFolder'] = {
        'id': 'rootFolder',
        'name': '캠퍼스레이더',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': <String>[],
        'trashed': false,
        'createdTime': '2026-11-01T00:00:00.000Z',
      };
      drive.files['matFolder'] = {
        'id': 'matFolder',
        'name': '자료',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': ['rootFolder'],
        'trashed': false,
        'createdTime': '2026-11-01T00:00:01.000Z',
      };
      // 0.6.5 course folder (e.g. untrimmed course name)
      drive.files['courseFolder'] = {
        'id': 'courseFolder',
        'name': '어드벤처디자인 ',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': ['matFolder'],
        'trashed': false,
        'createdTime': '2026-11-01T00:00:02.000Z',
      };
      drive.files['existingFile'] = {
        'id': 'existingFile',
        'name': '(양식) 어드벤처디자인_팀활동보고서.hwp',
        'mimeType': 'application/octet-stream',
        'parents': ['courseFolder'],
        'trashed': false,
        'createdTime': '2026-11-01T00:00:03.000Z',
        'size': 47616,
      };

      // State tracking from 0.6.5 with legacy keys
      final state = <String, dynamic>{
        'folder': 'rootFolder',
        'materialsFolder': 'matFolder',
        'materialsCourses': {'어드벤처디자인 ': 'courseFolder'},
        'files': {
          '자료/어드벤처디자인 /(양식) 어드벤처디자인_팀활동보고서.hwp': 'existingFile',
        },
        'hashes': {
          '자료/어드벤처디자인 /(양식) 어드벤처디자인_팀활동보고서.hwp': 'hash_47616',
        },
        'cleanup065': true,
      };

      // 0.6.6 new export with sanitized trimmed key
      final newKey = '자료/어드벤처디자인/(양식) 어드벤처디자인_팀활동보고서.hwp';
      final fileEntries = {
        newKey: {
          'bytes': List.filled(47616, 0),
          'sha256': 'hash_47616',
          'mime': 'application/octet-stream',
        },
      };

      final r = await uploadDriveDocuments(
        api: api,
        state: state,
        documents: {},
        fileEntries: fileEntries,
        checkpoint: () async {},
      );

      expect(r.writes, 0, reason: 'Must not re-upload existing identical file');
      expect(r.complete, isTrue);

      // Existing file must NOT be trashed
      expect(drive.files['existingFile']!['trashed'], isFalse);

      // State must track the new key pointing to the existing file
      expect(state['files'][newKey], 'existingFile');
      expect(state['files'].containsKey('자료/어드벤처디자인 /(양식) 어드벤처디자인_팀활동보고서.hwp'), isFalse);
    });

    test('reusing existing file in parent folder by name and size when state tracking is missing', () async {
      final drive = FakeDrive();
      final api = DriveApi('t', transport: drive.call);

      drive.files['rootFolder'] = {
        'id': 'rootFolder',
        'name': '캠퍼스레이더',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': <String>[],
        'trashed': false,
        'createdTime': '2026-11-01T00:00:00.000Z',
      };
      drive.files['matFolder'] = {
        'id': 'matFolder',
        'name': '자료',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': ['rootFolder'],
        'trashed': false,
        'createdTime': '2026-11-01T00:00:01.000Z',
      };
      drive.files['courseFolder'] = {
        'id': 'courseFolder',
        'name': '어드벤처디자인',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': ['matFolder'],
        'trashed': false,
        'createdTime': '2026-11-01T00:00:02.000Z',
      };
      drive.files['existingReport'] = {
        'id': 'existingReport',
        'name': '(양식) 어드벤처디자인_팀활동보고서.hwp',
        'mimeType': 'application/octet-stream',
        'parents': ['courseFolder'],
        'trashed': false,
        'createdTime': '2026-11-01T00:00:03.000Z',
        'size': 47616,
      };

      // Completely empty state (e.g. tracking reset or fresh installation)
      final state = <String, dynamic>{
        'folder': 'rootFolder',
        'cleanup065': true,
      };

      final newKey = '자료/어드벤처디자인/(양식) 어드벤처디자인_팀활동보고서.hwp';
      final fileEntries = {
        newKey: {
          'bytes': List.filled(47616, 0),
          'sha256': 'hash_47616',
          'mime': 'application/octet-stream',
        },
      };

      final r = await uploadDriveDocuments(
        api: api,
        state: state,
        documents: {},
        fileEntries: fileEntries,
        checkpoint: () async {},
      );

      // Writes should be 0 because the file already exists on Drive with the same size
      expect(r.writes, 0);
      expect(r.complete, isTrue);
      expect(state['files'][newKey], 'existingReport');
      expect(drive.files['existingReport']!['trashed'], isFalse);
    });
  });

  group('task 65: Drive identity via appProperties & duplicate cleanup', () {
    test('(a) 0.6.5 state -> first sync creates 0 new files and adopts appProperties', () async {
      final drive = FakeDrive();
      final api = DriveApi('t', transport: drive.call);

      drive.files['rootFolder'] = {
        'id': 'rootFolder',
        'name': '캠퍼스레이더',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': <String>[],
        'trashed': false,
        'createdTime': '2026-11-01T00:00:00.000Z',
      };
      drive.files['courseFolder'] = {
        'id': 'courseFolder',
        'name': '과목',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': ['rootFolder'],
        'trashed': false,
        'createdTime': '2026-11-01T00:00:01.000Z',
      };
      drive.files['matFolder'] = {
        'id': 'matFolder',
        'name': '자료',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': ['rootFolder'],
        'trashed': false,
        'createdTime': '2026-11-01T00:00:02.000Z',
      };
      drive.files['cMatFolder'] = {
        'id': 'cMatFolder',
        'name': '어드벤처디자인',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': ['matFolder'],
        'trashed': false,
        'createdTime': '2026-11-01T00:00:03.000Z',
      };
      drive.files['legacyFile'] = {
        'id': 'legacyFile',
        'name': '(양식) 어드벤처디자인_팀활동보고서.hwp',
        'mimeType': 'application/octet-stream',
        'parents': ['cMatFolder'],
        'trashed': false,
        'size': 47616,
        'createdTime': '2026-11-01T00:00:04.000Z',
      };
      drive.files['legacyDoc'] = {
        'id': 'legacyDoc',
        'name': '어드벤처디자인.txt',
        'mimeType': 'text/plain',
        'parents': ['courseFolder'],
        'trashed': false,
        'size': utf8.encode('course_doc_content').length,
        'createdTime': '2026-11-01T00:00:05.000Z',
      };

      final initialFileCount = drive.files.length;

      // 0.6.5 state with legacy untracked keys
      final state = <String, dynamic>{
        'folder': 'rootFolder',
        'courseFolder': 'courseFolder',
        'materialsFolder': 'matFolder',
        'materialsCourses': {'어드벤처디자인': 'cMatFolder'},
        'files': {
          '자료/어드벤처디자인/(양식) 어드벤처디자인_팀활동보고서.hwp': 'legacyFile',
          '과목/어드벤처디자인.txt': 'legacyDoc',
        },
        'hashes': {
          '자료/어드벤처디자인/(양식) 어드벤처디자인_팀활동보고서.hwp': 'hash_47616',
          '과목/어드벤처디자인.txt': DriveApi.digest('course_doc_content'),
        },
      };

      final docs = {'과목/어드벤처디자인.txt': 'course_doc_content'};
      final fileEntries = {
        '자료/어드벤처디자인/(양식) 어드벤처디자인_팀활동보고서.hwp': {
          'bytes': List.filled(47616, 0),
          'sha256': 'hash_47616',
          'mime': 'application/octet-stream',
          'crKey': 'att:report_123',
        },
      };

      final r = await uploadDriveDocuments(
        api: api,
        state: state,
        documents: docs,
        fileEntries: fileEntries,
        checkpoint: () async {},
      );

      expect(r.writes, 0, reason: 'First sync from 0.6.5 state must write 0');
      expect(drive.files.length, initialFileCount, reason: 'No new files should be created');
      expect(drive.files['legacyFile']!['appProperties']['crKind'], 'file');
      expect(drive.files['legacyFile']!['appProperties']['crKey'], 'att:report_123');
      expect(drive.files['legacyDoc']!['appProperties']['crKind'], 'file');
    });

    test('(b) deleted local records (reinstallation) -> creates 0 new files and restores cache', () async {
      final drive = FakeDrive();
      final api = DriveApi('t', transport: drive.call);

      drive.files['rootFolder'] = {
        'id': 'rootFolder',
        'name': '캠퍼스레이더',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': <String>[],
        'trashed': false,
        'appProperties': {'crKind': 'root', 'crKey': 'root'},
        'createdTime': '2026-11-01T00:00:00.000Z',
      };
      drive.files['courseFolder'] = {
        'id': 'courseFolder',
        'name': '과목',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': ['rootFolder'],
        'trashed': false,
        'appProperties': {'crKind': 'course', 'crKey': 'course'},
        'createdTime': '2026-11-01T00:00:01.000Z',
      };
      drive.files['matFolder'] = {
        'id': 'matFolder',
        'name': '자료',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': ['rootFolder'],
        'trashed': false,
        'appProperties': {'crKind': 'materials', 'crKey': 'materials'},
        'createdTime': '2026-11-01T00:00:02.000Z',
      };
      drive.files['cMatFolder'] = {
        'id': 'cMatFolder',
        'name': '어드벤처디자인',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': ['matFolder'],
        'trashed': false,
        'appProperties': {'crKind': 'materials', 'crKey': 'materials:어드벤처디자인'},
        'createdTime': '2026-11-01T00:00:03.000Z',
      };
      drive.files['existingFile'] = {
        'id': 'existingFile',
        'name': '(양식) 어드벤처디자인_팀활동보고서.hwp',
        'mimeType': 'application/octet-stream',
        'parents': ['cMatFolder'],
        'trashed': false,
        'size': 47616,
        'appProperties': {'crKind': 'file', 'crKey': 'att:report_123', 'crHash': 'hash_47616'},
        'createdTime': '2026-11-01T00:00:04.000Z',
      };
      drive.files['existingDoc'] = {
        'id': 'existingDoc',
        'name': '어드벤처디자인.txt',
        'mimeType': 'text/plain',
        'parents': ['courseFolder'],
        'trashed': false,
        'size': utf8.encode('course_doc_content').length,
        'appProperties': {'crKind': 'file', 'crKey': 'doc:course:어드벤처디자인', 'crHash': DriveApi.digest('course_doc_content')},
        'createdTime': '2026-11-01T00:00:05.000Z',
      };

      final initialFileCount = drive.files.length;

      // Local state is completely empty (app reinstalled or data cleared)
      final state = <String, dynamic>{};

      final docs = {'과목/어드벤처디자인.txt': 'course_doc_content'};
      final fileEntries = {
        '자료/어드벤처디자인/(양식) 어드벤처디자인_팀활동보고서.hwp': {
          'bytes': List.filled(47616, 0),
          'sha256': 'hash_47616',
          'mime': 'application/octet-stream',
          'crKey': 'att:report_123',
        },
      };

      final r = await uploadDriveDocuments(
        api: api,
        state: state,
        documents: docs,
        fileEntries: fileEntries,
        checkpoint: () async {},
      );

      expect(r.writes, 0, reason: 'Fresh reinstall sync must write 0');
      expect(drive.files.length, initialFileCount, reason: 'Must not create any new files on Drive');
      expect(state['files']['자료/어드벤처디자인/(양식) 어드벤처디자인_팀활동보고서.hwp'], 'existingFile');
      expect(state['files']['과목/어드벤처디자인.txt'], 'existingDoc');
    });

    test('(c) (2)~(9) duplicates 9 items -> 1 remains and 8 moved to trash', () async {
      final drive = FakeDrive();
      final api = DriveApi('t', transport: drive.call);

      drive.files['rootFolder'] = {
        'id': 'rootFolder',
        'name': '캠퍼스레이더',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': <String>[],
        'trashed': false,
        'createdTime': '2026-11-01T00:00:00.000Z',
      };
      drive.files['matFolder'] = {
        'id': 'matFolder',
        'name': '자료',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': ['rootFolder'],
        'trashed': false,
        'createdTime': '2026-11-01T00:00:01.000Z',
      };
      drive.files['cMatFolder'] = {
        'id': 'cMatFolder',
        'name': '어드벤처디자인',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': ['matFolder'],
        'trashed': false,
        'createdTime': '2026-11-01T00:00:02.000Z',
      };

      // 1 base file + 8 duplicate files (2) ~ (9)
      drive.files['report_base'] = {
        'id': 'report_base',
        'name': '(양식) 어드벤처디자인_팀활동보고서.hwp',
        'mimeType': 'application/octet-stream',
        'parents': ['cMatFolder'],
        'trashed': false,
        'size': 47616,
        'createdTime': '2026-11-01T00:00:03.000Z',
      };
      for (var i = 2; i <= 9; i++) {
        drive.files['report_dup_$i'] = {
          'id': 'report_dup_$i',
          'name': '(양식) 어드벤처디자인_팀활동보고서 ($i).hwp',
          'mimeType': 'application/octet-stream',
          'parents': ['cMatFolder'],
          'trashed': false,
          'size': 47616,
          'createdTime': '2026-11-01T00:00:0${i + 3}.000Z',
        };
      }

      final state = <String, dynamic>{'folder': 'rootFolder'};

      final fileEntries = {
        '자료/어드벤처디자인/(양식) 어드벤처디자인_팀활동보고서.hwp': {
          'bytes': List.filled(47616, 0),
          'sha256': 'hash_47616',
          'mime': 'application/octet-stream',
          'crKey': 'att:report_123',
        },
      };

      final r = await uploadDriveDocuments(
        api: api,
        state: state,
        documents: {},
        fileEntries: fileEntries,
        checkpoint: () async {},
      );

      expect(r.complete, isTrue);
      expect(drive.files['report_base']!['trashed'], isFalse);
      for (var i = 2; i <= 9; i++) {
        expect(drive.files['report_dup_$i']!['trashed'], isTrue, reason: 'Duplicate ($i) must be trashed');
      }
      expect(state['cleanedFiles'], 8);
    });

    test('(d) 2 roots -> 1 root remains and duplicate root trashed', () async {
      final drive = FakeDrive();
      final api = DriveApi('t', transport: drive.call);

      drive.files['root1'] = {
        'id': 'root1',
        'name': '캠퍼스레이더',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': <String>[],
        'trashed': false,
        'createdTime': '2026-11-01T00:00:00.000Z',
      };
      drive.files['root2'] = {
        'id': 'root2',
        'name': '캠퍼스레이더',
        'mimeType': 'application/vnd.google-apps.folder',
        'parents': <String>[],
        'trashed': false,
        'createdTime': '2026-11-05T00:00:00.000Z',
      };

      final state = <String, dynamic>{};
      final r = await uploadDriveDocuments(
        api: api,
        state: state,
        documents: {},
        checkpoint: () async {},
      );

      expect(r.complete, isTrue);
      expect(drive.files['root1']!['trashed'], isFalse);
      expect(drive.files['root2']!['trashed'], isTrue, reason: 'Second root folder must be moved to trash');
      expect(state['folder'], 'root1');
      expect(state['cleanedFolders'], 1);
    });

    test('(e) two consecutive syncs -> second sync writes 0', () async {
      final drive = FakeDrive();
      final api = DriveApi('t', transport: drive.call);
      final state = <String, dynamic>{};

      final docs = {
        '과목/자료구조.txt': 'data structures',
        '학업 현황.txt': 'overview content',
      };
      final fileEntries = {
        '자료/자료구조/실습1.pdf': {
          'bytes': List.filled(1024, 1),
          'sha256': 'hash_lab1',
          'mime': 'application/pdf',
        },
      };

      // First sync
      final first = await uploadDriveDocuments(
        api: api,
        state: state,
        documents: docs,
        fileEntries: fileEntries,
        checkpoint: () async {},
      );
      expect(first.writes, 3);
      expect(first.complete, isTrue);

      // Second sync immediately after
      final second = await uploadDriveDocuments(
        api: api,
        state: state,
        documents: docs,
        fileEntries: fileEntries,
        checkpoint: () async {},
      );
      expect(second.writes, 0, reason: 'Second consecutive sync must perform 0 writes');
      expect(second.complete, isTrue);
    });
  });
}

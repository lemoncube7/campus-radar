import 'dart:convert';

import 'package:campus_radar/export/drive_uploader.dart';
import 'package:flutter_test/flutter_test.dart';

/// In-memory Drive: files by id with name, parents, trashed, content.
class FakeDrive {
  final files = <String, Map<String, dynamic>>{};
  final calls = <String>[];
  var next = 0;
  Future<({int status, String body})> call(
    String method,
    Uri url,
    String token, {
    List<int>? body,
    String? contentType,
  }) async {
    calls.add('$method ${url.path}');
    final path = url.path;
    if (path.endsWith('/files/generateIds')) {
      return (
        status: 200,
        body: jsonEncode({
          'ids': ['id${next++}'],
        }),
      );
    }
    if (method == 'POST' && path.endsWith('/drive/v3/files')) {
      final m = jsonDecode(utf8.decode(body!)) as Map<String, dynamic>;
      if (files.containsKey(m['id'])) return (status: 409, body: '');
      files[m['id']] = {...m, 'trashed': false, 'content': ''};
      return (status: 200, body: jsonEncode({'id': m['id']}));
    }
    final id = path.split('/').last;
    final f = files[id];
    if (f == null) return (status: 404, body: '');
    if (method == 'GET') {
      return (
        status: 200,
        body: jsonEncode({'id': id, 'trashed': f['trashed']}),
      );
    }
    if (path.startsWith('/upload/')) {
      f['content'] = utf8.decode(body!);
      return (status: 200, body: '{}');
    }
    f['trashed'] = (jsonDecode(utf8.decode(body!)) as Map)['trashed'];
    return (status: 200, body: '{}');
  }
}

void main() {
  test('creates the folder layout, skips unchanged, replaces trashed, '
      'trashes removed documents', () async {
    final drive = FakeDrive();
    final api = DriveApi('t', transport: drive.call);
    final state = <String, dynamic>{};
    final docs = {
      startDocument: 'start',
      '학업 현황.txt': 'status',
      '과목/물리.txt': 'physics',
    };
    var r = await uploadDriveDocuments(
      api: api,
      state: state,
      documents: docs,
      checkpoint: () async {},
    );
    expect(r, (writes: 3, complete: true));
    final physics = drive.files[state['files']['과목/물리.txt']]!;
    expect(physics['parents'], [state['courseFolder']]);
    expect(physics['name'], '물리.txt');
    expect(drive.files[state['files'][startDocument]]!['content'], 'start');

    // Unchanged: no writes.
    r = await uploadDriveDocuments(
      api: api,
      state: state,
      documents: docs,
      checkpoint: () async {},
    );
    expect(r.writes, 0);

    // User trashed one file: it gets a new id; a removed doc is trashed.
    final oldStatus = state['files']['학업 현황.txt'];
    drive.files[oldStatus]!['trashed'] = true;
    r = await uploadDriveDocuments(
      api: api,
      state: state,
      documents: {startDocument: 'start2', '학업 현황.txt': 'status'},
      checkpoint: () async {},
    );
    expect(r.writes, 2);
    expect(state['files']['학업 현황.txt'], isNot(oldStatus));
    expect(state['files'].containsKey('과목/물리.txt'), isFalse);
    expect(physics['trashed'], isTrue);
    // The start file is written last.
    final uploads = drive.calls.where((c) => c.startsWith('PATCH /upload/'));
    expect(uploads.last, contains(state['files'][startDocument]));
  });

  test('stops after the write budget and resumes', () async {
    final drive = FakeDrive();
    final api = DriveApi('t', transport: drive.call);
    final state = <String, dynamic>{};
    final docs = {for (var i = 0; i < 5; i++) '과목/$i.txt': '$i'};
    final first = await uploadDriveDocuments(
      api: api,
      state: state,
      documents: docs,
      checkpoint: () async {},
      maxWrites: 3,
    );
    expect(first, (writes: 3, complete: false));
    final second = await uploadDriveDocuments(
      api: api,
      state: state,
      documents: docs,
      checkpoint: () async {},
      maxWrites: 3,
    );
    expect(second, (writes: 2, complete: true));
  });

  test('a 401 surfaces as DriveHttpFailure', () async {
    final api = DriveApi(
      't',
      transport: (m, u, t, {body, contentType}) async =>
          (status: 401, body: ''),
    );
    expect(
      () => uploadDriveDocuments(
        api: api,
        state: {},
        documents: {startDocument: 'x'},
        checkpoint: () async {},
      ),
      throwsA(isA<DriveHttpFailure>().having((e) => e.status, 'status', 401)),
    );
  });
}

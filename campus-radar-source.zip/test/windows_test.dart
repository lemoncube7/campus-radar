import 'package:campus_radar/app_router.dart';
import 'package:campus_radar/task_presentation.dart';
import 'package:campus_radar/campus_models.dart';
import 'dart:convert';
import 'dart:io';
import 'package:archive/archive.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/desktop.dart';
import 'package:campus_radar/desktop_web.dart';
import 'package:campus_radar/radar_theme.dart';

void main() {
  Map<String, dynamic> manifest() => {
    'versionName': '0.4.1',
    'versionCode': 19,
    'platform': 'windows',
    'architecture': 'x64',
    'zipUrl':
        'https://github.com/lemoncube7/campus-radar/releases/download/windows-v0.4.1/campus-radar-windows.zip',
    'sha256': 'a' * 64,
  };
  Archive validArchive() {
    final a = Archive();
    a.addFile(
      ArchiveFile('campus_radar.exe', 10001, List<int>.filled(10001, 0)),
    );
    a.addFile(
      ArchiveFile.string(
        'windows-version.json',
        jsonEncode({'versionName': '0.4.1', 'versionCode': 19}),
      ),
    );
    return a;
  }

  test(
    'Chromium keeps parent-domain login cookies available to subdomains',
    () {
      expect(
        desktopCookieDomain(
          Cookie.fromSetCookieValue(
            'token=synthetic; Domain=cnu.ac.kr; Path=/',
          ),
        ),
        '.cnu.ac.kr',
      );
      expect(
        desktopCookieDomain(
          Cookie.fromSetCookieValue(
            'token=synthetic; Domain=.cnu.ac.kr; Path=/',
          ),
        ),
        '.cnu.ac.kr',
      );
      expect(
        desktopCookieDomain(
          Cookie.fromSetCookieValue('session=synthetic; Path=/'),
        ),
        isNull,
      );
    },
  );
  test(
    'Windows feed rejects mobile, insecure URL, external repo and mismatched tag',
    () {
      expect(validateDesktopManifest(manifest())['versionCode'], 19);
      for (final mutation in [
        {'platform': 'android'},
        {'architecture': 'arm64'},
        {'versionCode': 0},
        {
          'zipUrl':
              'http://github.com/lemoncube7/campus-radar/releases/download/windows-v0.4.1/campus-radar-windows.zip',
        },
        {
          'zipUrl':
              'https://github.com/elsewhere/app/releases/download/windows-v0.4.1/campus-radar-windows.zip',
        },
        {'versionName': '0.4.2'},
        {'sha256': 'bad'},
      ]) {
        expect(
          () => validateDesktopManifest({...manifest(), ...mutation}),
          throwsFormatException,
        );
      }
    },
  );
  test(
    'ZIP validation rejects traversal, absolute paths, symlinks and wrong version',
    () {
      final folder = '${Directory.systemTemp.path}/radar-stage';
      validateDesktopArchive(validArchive(), folder, manifest: manifest());
      for (final name in [
        '../outside.exe',
        r'..\outside.exe',
        '/absolute.exe',
        r'C:\outside.exe',
      ]) {
        final a = validArchive()..addFile(ArchiveFile.string(name, 'bad'));
        expect(
          () => validateDesktopArchive(a, folder, manifest: manifest()),
          throwsFormatException,
        );
      }
      expect(
        () => validateDesktopArchive(
          validArchive(),
          folder,
          manifest: {...manifest(), 'versionCode': 20},
        ),
        throwsFormatException,
      );
      final a = validArchive()
        ..addFile(
          ArchiveFile.string('data/link', 'bad')..symbolicLink = '../outside',
        );
      expect(
        () => validateDesktopArchive(a, folder, manifest: manifest()),
        throwsFormatException,
      );
    },
  );
  test(
    'Calendar export preserves UTC instants, escapes input and folds Korean UTF8 lines',
    () {
      final text = desktopCalendarText({
        'key': 'synthetic',
        'title': '컴프2, 과제; 제출\n다음 줄',
        'description': '설명' * 80,
        'start': DateTime.utc(2026, 10, 20, 14, 49).millisecondsSinceEpoch,
        'end': DateTime.utc(2026, 10, 20, 14, 59).millisecondsSinceEpoch,
        'allDay': false,
      });
      expect(text, contains('DTSTART:20261020T144900Z'));
      expect(text, contains('DTEND:20261020T145900Z'));
      expect(text, contains(r'컴프2\, 과제\; 제출\n다음 줄'));
      for (final line in text.split('\r\n')) {
        expect(utf8.encode(line).length, lessThanOrEqualTo(75));
      }
      expect(text.split('BEGIN:VEVENT').length, 2);
      final allDay = desktopCalendarText({
        'key': 'all',
        'title': '시험',
        'start': DateTime.utc(2026, 10, 20).millisecondsSinceEpoch,
        'end': DateTime.utc(2026, 10, 21).millisecondsSinceEpoch,
        'allDay': true,
      });
      expect(allDay, contains('DTSTART;VALUE=DATE:20261020'));
      expect(allDay, contains('DTEND;VALUE=DATE:20261021'));
    },
  );
  test('Embedded session pages only accept selected CNU HTTPS origins', () {
    expect(
      desktopTrustedUrl('https://dcs-learning.cnu.ac.kr/std/course'),
      isTrue,
    );
    expect(
      desktopTrustedUrl('https://cnuit.cnu.ac.kr/checkMenu.jsp', plan: true),
      isTrue,
    );
    for (final u in [
      'http://dcs-learning.cnu.ac.kr',
      'https://dcs-learning.cnu.ac.kr.evil.test',
      'https://user:pass@dcs-learning.cnu.ac.kr',
      'file:///C:/private',
    ]) {
      expect(desktopTrustedUrl(u), isFalse);
    }
  });
  testWidgets(
    'Desktop side preview renders long titles and enlarged dark text without overflow',
    (tester) async {
      tester.view.physicalSize = const Size(380, 700);
      tester.view.devicePixelRatio = 1;
      final item = CampusItem(
        key: 'synthetic',
        type: 'LR',
        title: '길이가 긴 과제 제목 ' * 5,
        course: '가상 과목',
        courseId: 'c',
        classNo: '1',
        contentsId: 'x',
        status: 'pending',
        context: {},
        body: '과제 설명 ' * 50,
        due: DateTime.now().add(const Duration(hours: 3)),
      );
      await tester.pumpWidget(
        MaterialApp(
          onGenerateRoute: buildAppRoute,
          theme: radarTheme(Brightness.dark),
          home: MediaQuery(
            data: MediaQueryData(textScaler: TextScaler.linear(1.5)),
            child: Scaffold(
              body: DesktopTaskPreview(item: item, close: () {}, open: () {}),
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();
      expect(find.text('상세 내용·강의실 바로가기'), findsOneWidget);
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox.shrink());
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    },
  );
}

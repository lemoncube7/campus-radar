import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/home/mobile_today_view.dart';

void main() {
  final hasMalgun = File('C:/Windows/Fonts/malgun.ttf').existsSync();

  group(
    'Capture mobile today view preview group',
    skip: !hasMalgun ? 'Windows font (C:/Windows/Fonts/malgun.ttf) not found' : null,
    () {
      testWidgets('Capture mobile today view preview', (tester) async {
        if (!hasMalgun) return;
        // 1. Load Korean font and Material icons
    final font = FontLoader('KoreanPreview')
      ..addFont(
        Future.value(
          ByteData.sublistView(File('C:/Windows/Fonts/malgun.ttf').readAsBytesSync()),
        ),
      );
    await font.load();

    final icons = FontLoader('MaterialIcons')
      ..addFont(
        Future.value(
          ByteData.sublistView(
            File(
              '../../work/tools/flutter/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf',
            ).readAsBytesSync(),
          ),
        ),
      );
    await icons.load();

    // 2. Set mobile device size (iPhone 14 / modern Android: 390 x 844)
    await tester.binding.setSurfaceSize(const Size(390, 844));

    final now = DateTime.utc(2026, 11, 5, 8, 30); // KST 17:30
    final items = [
      CampusItem(
        key: 'task-1',
        title: '중간 캡스톤 프로젝트 기획서 제출',
        course: '어드벤처디자인',
        courseId: 'c1',
        classNo: '1',
        contentsId: 'cnt1',
        type: 'LR',
        status: 'pending',
        due: now.add(const Duration(hours: 3)), // KST 20:30 (마감 3시간 전)
        context: {'course_id': 'c1', 'class_no': '1'},
      ),
      CampusItem(
        key: 'task-2',
        title: '9주차 객체지향 프로그래밍 실습 강의',
        course: '컴퓨터프로그래밍 2',
        courseId: 'c2',
        classNo: '1',
        contentsId: 'cnt2',
        type: 'LV',
        status: 'pending',
        attendanceRequired: true,
        progress: '70% 수강',
        due: now.add(const Duration(hours: 6)), // 오늘 23:30 마감
        context: {'course_id': 'c2', 'class_no': '1'},
      ),
      CampusItem(
        key: 'task-3',
        title: 'B-Tree 구현 및 성능 분석 과제',
        course: '자료구조',
        courseId: 'c3',
        classNo: '1',
        contentsId: 'cnt3',
        type: 'LR',
        status: 'pending',
        due: now.add(const Duration(days: 3)), // 3일 후
        context: {'course_id': 'c3', 'class_no': '1'},
      ),
    ];

    final homeNotices = <CampusNotice>[
      CampusNotice(
        id: 'n1',
        title: '[중요] 2학기 중간 강의평가 및 학사일정 안내',
        course: '학과공통',
        published: now.subtract(const Duration(hours: 4)),
        read: false,
        context: const {'course_id': 'c0'},
      ),
    ];

    final boundaryKey = GlobalKey();

    final theme = ThemeData(
      fontFamily: 'KoreanPreview',
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xff3448ae),
        brightness: Brightness.light,
      ),
      scaffoldBackgroundColor: const Color(0xfff8f9fc),
    );

    await tester.pumpWidget(
      MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: theme,
        home: Scaffold(
          appBar: AppBar(
            title: const Text(
              '오늘',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
            ),
            elevation: 0,
            actions: [
              IconButton(
                icon: const Icon(Icons.notifications_none_rounded),
                onPressed: () {},
              ),
              IconButton(
                icon: const Icon(Icons.settings_outlined),
                onPressed: () {},
              ),
            ],
          ),
          body: RepaintBoundary(
            key: boundaryKey,
            child: MobileTodayView(
              now: now,
              pendingItems: items,
              urgentCount: 1,
              todayCount: 2,
              excludedKeys: const {},
              visibilityBusy: const {},
              isBusy: false,
              lastSyncTime: '방금 전',
              homeNotices: homeNotices,
              localRevision: 1,
              onRefresh: () {},
              onShowAllTasks: () {},
              onShowUrgentTasks: () {},
              onTaskTap: (_) {},
              onTaskVisibilityToggle: (_) {},
            ),
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: 0,
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.today_outlined),
                selectedIcon: Icon(Icons.today_rounded),
                label: '오늘',
              ),
              NavigationDestination(
                icon: Icon(Icons.checklist_rounded),
                label: '할 일',
              ),
              NavigationDestination(
                icon: Icon(Icons.school_outlined),
                label: '과목',
              ),
              NavigationDestination(
                icon: Icon(Icons.more_horiz_rounded),
                label: '더보기',
              ),
            ],
          ),
        ),
      ),
    );

    await tester.pumpAndSettle();

    // 3. Render and save image
    await tester.runAsync(() async {
      final boundary =
          boundaryKey.currentContext!.findRenderObject()
              as RenderRepaintBoundary;
      final image = await boundary.toImage(pixelRatio: 2.0);
      final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      final pngBytes = byteData!.buffer.asUint8List();

      final outFile = File('../../outputs/mobile-today-preview.png');
      await outFile.parent.create(recursive: true);
      await outFile.writeAsBytes(pngBytes);
      image.dispose();
      print('Preview saved to ${outFile.path}');
    });

    await tester.binding.setSurfaceSize(null);
  });
  });
}

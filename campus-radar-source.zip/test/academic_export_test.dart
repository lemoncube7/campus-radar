import 'dart:convert';
import 'dart:io';
import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/export/academic_export.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/tasks/task_evaluation.dart';
import 'package:campus_radar/schedule/timetable_model.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Store s;
  late Directory dir;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    dir = await Directory.systemTemp.createTemp('radar-export-');
    await databaseFactory.setDatabasesPath(dir.path);
    s = await Store.open();
  });
  tearDown(() async {
    await s.db.close();
    await dir.delete(recursive: true);
  });
  const id = '0123456789abcdef0123456789abcdef';
  test(
    'per-account export scopes exclude unselected courses and categories',
    () async {
      await s.setMeta('lastSuccess', '2026-11-01T00:00:00Z');
      await s.setMeta('courses', '[]');
      for (final course in ['chosen', 'PRIVATE_OTHER_COURSE']) {
        await s.saveNotice(
          CampusNotice(
            id: course,
            context: const {},
            title: 'notice-$course',
            course: course,
            body: 'body-$course',
            bodyFetched: true,
          ),
        );
      }
      final scoped = await buildAcademicExport(
        s,
        id,
        selectedCourses: {'chosen'},
        exportTasks: false,
        exportMaterials: false,
        exportPlans: false,
        exportTimetable: false,
      );
      final text = scoped.documents.values.join('\n');
      expect(text, contains('body-chosen'));
      expect(text, isNot(contains('PRIVATE_OTHER_COURSE')));
      expect(scoped.documents.containsKey('시간표.txt'), isFalse);
      final withoutNotices = await buildAcademicExport(
        s,
        id,
        exportNotices: false,
        exportMaterials: false,
        exportPlans: false,
      );
      expect(
        withoutNotices.documents.values.join('\n'),
        isNot(contains('body-chosen')),
      );
    },
  );

  test('export is opt-in caller and no collection fails closed', () async {
    await expectLater(buildAcademicExport(s, id), throwsFormatException);
  });
  test(
    'real zip readback includes title body and accurate states without secrets or friends',
    () async {
      await s.setMeta('lastSuccess', '2026-11-01T00:00:00Z');
      await s.setMeta('courses', '[]');
      await s.setMeta('pw', 'PRIVATE_PASSWORD');
      await s.setMeta('friendTimetables', 'PRIVATE_FRIEND');
      final item = CampusItem(
        key: 'PRIVATE_KEY',
        type: 'LR',
        title: '중간 점수 확인',
        course: '선형대수',
        courseId: 'PRIVATE_COURSE',
        classNo: '1',
        contentsId: 'PRIVATE_CONTENT',
        status: 'pending',
        context: {'cookie': 'PRIVATE_COOKIE'},
        evaluation: const TaskEvaluation(
          score: 'PRIVATE_GRADE',
          feedback: 'PRIVATE_FEEDBACK',
        ),
      );
      await s.db.insert('items', {
        'id': item.key,
        'payload': jsonEncode(item.toJson()),
      });
      await s.setMeta('notTask:${item.key}', 'yes');
      await s.saveNotice(
        CampusNotice(
          id: 'PRIVATE_NOTICE',
          title: '11월 2일 휴강',
          course: '논비사',
          body: '다음 수업 없음',
          bodyFetched: true,
          context: {'token': 'PRIVATE_TOKEN'},
        ),
      );
      await s.setMeta(
        'timetableEntries',
        jsonEncode([
          const ClassSlot(
            courseKey: 'x:1',
            course: '논비사',
            weekday: 1,
            start: 600,
            end: 660,
          ).toJson(),
          const ClassSlot(
            courseKey: 'personal:x',
            course: 'PRIVATE_PERSONAL',
            weekday: 2,
            start: 600,
            end: 660,
          ).toJson(),
        ]),
      );
      final result = await buildAcademicExport(
        s,
        id,
        now: DateTime.utc(2026, 11, 1, 1),
      );
      final zip = ZipDecoder().decodeBytes(result.zip());
      expect(zip.length, result.documents.length);
      final index = utf8.decode(
        zip.findFile('캠퍼스레이더 시작.txt')!.content as List<int>,
      );
      expect(index, startsWith('CAMPUS_RADAR_START_V1\n'));
      final j = jsonDecode(index.substring(index.indexOf('\n') + 1));
      expect(j['collectedAt'], '2026-11-01T00:00:00.000Z');
      expect(j['fixture'], false);
      final text = result.documents.values.join('\n');
      expect(text, contains('11월 2일 휴강'));
      expect(text, contains('다음 수업 없음'));
      expect(text, contains('할 일 아님: true'));
      for (final secret in [
        'PRIVATE_PASSWORD',
        'PRIVATE_FRIEND',
        'PRIVATE_KEY',
        'PRIVATE_COURSE',
        'PRIVATE_CONTENT',
        'PRIVATE_COOKIE',
        'PRIVATE_GRADE',
        'PRIVATE_FEEDBACK',
        'PRIVATE_NOTICE',
        'PRIVATE_TOKEN',
        'PRIVATE_PERSONAL',
      ]) {
        expect(text, isNot(contains(secret)));
      }
    },
  );
  test('unsafe paths and oversized content cannot create partial package', () {
    expect(
      () => packAcademicDocuments(
        profileId: id,
        at: DateTime.now(),
        collectedAt: null,
        documents: {'../x.txt': 'bad'},
      ),
      throwsFormatException,
    );
    expect(
      () => packAcademicDocuments(
        profileId: id,
        at: DateTime.now(),
        collectedAt: null,
        documents: {'big.txt': 'x' * 1048577},
      ),
      throwsFormatException,
    );
  });
  test('markdown export strips .md extension from index titles', () async {
    await s.setMeta('lastSuccess', '2026-11-01T00:00:00Z');
    final result = await buildAcademicExport(
      s,
      id,
      now: DateTime.utc(2026, 11, 1, 1),
      markdown: true,
    );
    final startIndex = result.documents['캠퍼스레이더 시작.txt']!;
    final j = jsonDecode(startIndex.substring(startIndex.indexOf('\n') + 1));
    final docList = (j['documents'] as List).cast<Map<String, dynamic>>();
    expect(docList, isNotEmpty);
    for (final doc in docList) {
      final title = doc['title'] as String;
      expect(
        title.endsWith('.md'),
        isFalse,
        reason: 'title "$title" should not end with .md',
      );
    }
  });
}

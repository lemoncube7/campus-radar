import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:campus_radar/radar_theme.dart';
import 'package:campus_radar/main.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() {
    SharedPreferences.setMockInitialValues({});
    radarAccent.value = RadarAccent.teal;
    radarSecondaryAccent.value = RadarAccent.orange;
    radarThemeMode.value = ThemeMode.system;
  });
  tearDown(() {
    radarAccent.value = RadarAccent.teal;
    radarSecondaryAccent.value = RadarAccent.orange;
    radarThemeMode.value = ThemeMode.system;
  });
  double contrast(Color a, Color b) {
    final x = a.computeLuminance(), y = b.computeLuminance();
    return ((x > y ? x : y) + .05) / ((x < y ? x : y) + .05);
  }

  test(
    'all 64 two-color combinations remain readable in both brightness modes',
    () {
      for (final first in RadarAccent.values) {
        for (final second in RadarAccent.values) {
          for (final brightness in Brightness.values) {
            final c = radarTheme(
              brightness,
              accent: first,
              secondaryAccent: second,
            ).colorScheme;
            expect(
              contrast(c.primary, c.onPrimary),
              greaterThanOrEqualTo(4.5),
              reason: '$first $second $brightness primary',
            );
            expect(
              contrast(c.secondary, c.onSecondary),
              greaterThanOrEqualTo(4.5),
              reason: '$first $second $brightness secondary',
            );
            expect(
              contrast(c.secondaryContainer, c.onSecondaryContainer),
              greaterThanOrEqualTo(4.5),
            );
            expect(contrast(c.surface, c.onSurface), greaterThanOrEqualTo(4.5));
          }
        }
      }
    },
  );
  test(
    'secondary color changes secondary roles while retaining primary and error meaning',
    () {
      final a = radarTheme(
        Brightness.dark,
        accent: RadarAccent.blue,
        secondaryAccent: RadarAccent.orange,
      ).colorScheme;
      final b = radarTheme(
        Brightness.dark,
        accent: RadarAccent.blue,
        secondaryAccent: RadarAccent.rose,
      ).colorScheme;
      expect(a.primary, b.primary);
      expect(a.error, b.error);
      expect(a.secondary, isNot(b.secondary));
      expect(a.secondaryContainer, isNot(b.secondaryContainer));
    },
  );
  test(
    'legacy primary migrates without overwriting it and both selections persist',
    () async {
      SharedPreferences.setMockInitialValues({
        'radarAccent': 'purple',
        'radarTheme': 'dark',
      });
      await loadRadarTheme();
      expect(radarAccent.value, RadarAccent.purple);
      expect(radarSecondaryAccent.value, RadarAccent.teal);
      expect(radarThemeMode.value, ThemeMode.dark);
      await saveRadarSecondaryAccent(RadarAccent.rose);
      await saveRadarAccent(RadarAccent.blue);
      radarAccent.value = RadarAccent.slate;
      radarSecondaryAccent.value = RadarAccent.slate;
      await loadRadarTheme();
      expect(radarAccent.value, RadarAccent.blue);
      expect(radarSecondaryAccent.value, RadarAccent.rose);
      final p = await SharedPreferences.getInstance();
      expect(p.getString('radarAccent'), 'blue');
      expect(p.getString('radarSecondaryAccent'), 'rose');
      await p.setString('radarSecondaryAccent', 'unsupported');
      await loadRadarTheme();
      expect(radarSecondaryAccent.value, RadarAccent.orange);
    },
  );
  testWidgets(
    'second picker changes live theme independently and preserves route',
    (t) async {
      t.view.physicalSize = const Size(412, 915);
      t.view.devicePixelRatio = 1;
      addTearDown(t.view.resetPhysicalSize);
      addTearDown(t.view.resetDevicePixelRatio);
      await t.pumpWidget(const RadarApp(home: AppearancePage()));
      await t.pumpAndSettle();
      final before = t
          .widget<MaterialApp>(find.byType(MaterialApp))
          .theme!
          .colorScheme;
      await t.scrollUntilVisible(find.byTooltip('컬러 2 로즈'), 100);
      await t.pumpAndSettle();
      await t.tap(find.byTooltip('컬러 2 로즈'));
      await t.pumpAndSettle();
      final after = t
          .widget<MaterialApp>(find.byType(MaterialApp))
          .theme!
          .colorScheme;
      expect(after.primary, before.primary);
      expect(after.secondary, isNot(before.secondary));
      expect(radarSecondaryAccent.value, RadarAccent.rose);
      expect(find.text('화면 테마'), findsOneWidget);
      expect(find.text('컬러 1 · 주요 행동'), findsOneWidget);
      expect(t.takeException(), isNull);
      await t.pumpWidget(const SizedBox.shrink());
    },
  );
  testWidgets(
    'two-color settings fit narrow enlarged text with sticky preview',
    (t) async {
      t.view.physicalSize = const Size(320, 900);
      t.view.devicePixelRatio = 1;
      addTearDown(t.view.resetPhysicalSize);
      addTearDown(t.view.resetDevicePixelRatio);
      await t.pumpWidget(
        RadarApp(
          home: MediaQuery(
            data: const MediaQueryData(
              size: Size(320, 900),
              textScaler: TextScaler.linear(1.8),
            ),
            child: const AppearancePage(),
          ),
        ),
      );
      await t.pumpAndSettle();
      expect(t.takeException(), isNull);
      await t.scrollUntilVisible(find.text('다크'), 150);
      await t.pumpAndSettle();
      await t.tap(find.text('다크'));
      await t.pumpAndSettle();
      expect(radarThemeMode.value, ThemeMode.dark);
      expect(t.takeException(), isNull);
      await t.pumpWidget(const SizedBox.shrink());
    },
  );
  testWidgets(
    'capture two-color theme preview',
    (t) async {
      t.view.physicalSize = const Size(412, 915);
      t.view.devicePixelRatio = 1;
      addTearDown(t.view.resetPhysicalSize);
      addTearDown(t.view.resetDevicePixelRatio);
      await t.runAsync(() async {
        for (final e in {
          'Malgun': 'C:/Windows/Fonts/malgun.ttf',
          'MaterialIcons':
              '../../work/tools/flutter/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf',
        }.entries) {
          final f = FontLoader(e.key);
          f.addFont(
            Future.value(
              ByteData.sublistView(await File(e.value).readAsBytes()),
            ),
          );
          await f.load();
        }
      });
      final key = GlobalKey();
      await t.pumpWidget(
        MaterialApp(
          theme:
              radarTheme(
                Brightness.dark,
                accent: RadarAccent.teal,
                secondaryAccent: RadarAccent.orange,
              ).copyWith(
                textTheme: ThemeData.dark().textTheme.apply(
                  fontFamily: 'Malgun',
                ),
              ),
          home: RepaintBoundary(key: key, child: const AppearancePage()),
        ),
      );
      await t.pumpAndSettle();
      await t.runAsync(() async {
        final img =
            await (key.currentContext!.findRenderObject()
                    as RenderRepaintBoundary)
                .toImage();
        final bytes = await img.toByteData(format: ui.ImageByteFormat.png);
        final dir = Directory('../../outputs/tests/dual-color')
          ..createSync(recursive: true);
        File(
          '${dir.path}/appearance.png',
        ).writeAsBytesSync(bytes!.buffer.asUint8List());
        img.dispose();
      });
    },
    skip: !const bool.fromEnvironment('CAPTURE_DUAL_THEME'),
  );
}

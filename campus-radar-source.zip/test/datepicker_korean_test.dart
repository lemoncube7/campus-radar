import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/main.dart';

void main() {
  testWidgets('RadarApp configures Korean locale and localizations delegates', (
    tester,
  ) async {
    await tester.pumpWidget(const RadarApp(home: Scaffold(body: Text('홈'))));
    await tester.pumpAndSettle();

    final materialAppFinder = find.byType(MaterialApp);
    expect(materialAppFinder, findsOneWidget);

    final materialApp = tester.widget<MaterialApp>(materialAppFinder);
    expect(materialApp.locale, const Locale('ko', 'KR'));
    expect(materialApp.supportedLocales, contains(const Locale('ko', 'KR')));
    expect(
      materialApp.localizationsDelegates,
      contains(GlobalMaterialLocalizations.delegate),
    );
    expect(
      materialApp.localizationsDelegates,
      contains(GlobalWidgetsLocalizations.delegate),
    );
    expect(
      materialApp.localizationsDelegates,
      contains(GlobalCupertinoLocalizations.delegate),
    );
  });

  testWidgets(
    'showDateRangePicker displays Korean headers, months, and buttons',
    (tester) async {
      await tester.pumpWidget(
        RadarApp(
          home: Scaffold(
            body: Builder(
              builder: (context) => ElevatedButton(
                onPressed: () {
                  showDateRangePicker(
                    context: context,
                    firstDate: DateTime(2020),
                    lastDate: DateTime(2100),
                    initialDateRange: DateTimeRange(
                      start: DateTime(2026, 11, 10),
                      end: DateTime(2026, 11, 12),
                    ),
                  );
                },
                child: const Text('열기'),
              ),
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();

      await tester.tap(find.text('열기'));
      await tester.pumpAndSettle();

      // Korean localized strings: "저장" instead of "Save", "2026년 11월" instead of "November 2026"
      expect(find.text('저장'), findsOneWidget);
      expect(find.text('Save'), findsNothing);
      expect(find.text('Select range'), findsNothing);
      expect(find.textContaining('2026년 11월'), findsWidgets);
      expect(find.text('November 2026'), findsNothing);

      // Weekday abbreviations in Korean
      expect(find.text('일'), findsWidgets);
      expect(find.text('월'), findsWidgets);
      expect(find.text('화'), findsWidgets);
      expect(find.text('수'), findsWidgets);
      expect(find.text('목'), findsWidgets);
      expect(find.text('금'), findsWidgets);
      expect(find.text('토'), findsWidgets);
    },
  );

  testWidgets(
    'showDatePicker displays Korean header, months, and confirm button',
    (tester) async {
      await tester.pumpWidget(
        RadarApp(
          home: Scaffold(
            body: Builder(
              builder: (context) => ElevatedButton(
                onPressed: () {
                  showDatePicker(
                    context: context,
                    initialDate: DateTime(2026, 11, 10),
                    firstDate: DateTime(2020),
                    lastDate: DateTime(2100),
                  );
                },
                child: const Text('열기'),
              ),
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();

      await tester.tap(find.text('열기'));
      await tester.pumpAndSettle();

      expect(find.text('확인'), findsOneWidget);
      expect(find.text('취소'), findsOneWidget);
      expect(find.text('OK'), findsNothing);
      expect(find.text('CANCEL'), findsNothing);
      expect(find.textContaining('2026년 11월'), findsWidgets);
    },
  );

  testWidgets('showTimePicker displays Korean AM/PM and buttons', (
    tester,
  ) async {
    await tester.pumpWidget(
      RadarApp(
        home: Scaffold(
          body: Builder(
            builder: (context) => ElevatedButton(
              onPressed: () {
                showTimePicker(
                  context: context,
                  initialTime: const TimeOfDay(hour: 14, minute: 30),
                );
              },
              child: const Text('열기'),
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    await tester.tap(find.text('열기'));
    await tester.pumpAndSettle();

    expect(find.text('확인'), findsOneWidget);
    expect(find.text('취소'), findsOneWidget);
    expect(find.text('오전'), findsOneWidget);
    expect(find.text('오후'), findsOneWidget);
    expect(find.text('AM'), findsNothing);
    expect(find.text('PM'), findsNothing);
  });

  testWidgets('CalendarDatePicker displays Korean month and weekdays', (
    tester,
  ) async {
    await tester.pumpWidget(
      RadarApp(
        home: Scaffold(
          body: CalendarDatePicker(
            initialDate: DateTime(2026, 11, 10),
            firstDate: DateTime(2020),
            lastDate: DateTime(2100),
            onDateChanged: (_) {},
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.textContaining('2026년 11월'), findsOneWidget);
    expect(find.text('November 2026'), findsNothing);
    expect(find.text('일'), findsOneWidget);
    expect(find.text('월'), findsOneWidget);
  });

  test('lib directory has no other MaterialApp or raw unlocalized pickers', () {
    final libDir = Directory('lib');
    final files = libDir.listSync(recursive: true).whereType<File>();
    final materialAppFiles = <String>[];
    for (final file in files) {
      if (!file.path.endsWith('.dart')) continue;
      final content = file.readAsStringSync();
      if (content.contains('MaterialApp(')) {
        materialAppFiles.add(file.path.replaceAll('\\', '/'));
      }
    }
    expect(
      materialAppFiles,
      equals(['lib/main.dart']),
      reason: 'All app UI must inherit localization from lib/main.dart',
    );
  });
}

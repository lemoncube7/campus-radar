import 'dart:io';

import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/campus/site_canary.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;

  group('학교 사이트 정상 응답 샘플(fixtures) 검증', () {
    test('/term/getYearTermList 정상 응답', () {
      final normal = {
        'list': [
          {'term_year': '2026', 'term_cd': '2', 'current_term_yn': 'Y'},
        ],
      };
      expect(checkSiteResponseShape('/term/getYearTermList', normal), isNull);
    });

    test('/course/getStdMyCourseList 정상 응답', () {
      final normal = {
        'course_list': [
          {'course_id': 'c101', 'class_no': '01', 'course_nm': '운영체제'},
        ],
      };
      expect(
        checkSiteResponseShape('/course/getStdMyCourseList', normal),
        isNull,
      );
    });

    test('/week/getStdWeekList 및 /week/getStdEtcList 정상 응답', () {
      final weeks = {
        'week_list': [
          {
            'seq_list': [
              {
                'learning_list': [
                  {
                    'module_type': 'LR',
                    'contents_id': 'r1',
                    'weekseq_no': 'w1',
                  },
                ],
              },
            ],
          },
        ],
      };
      expect(checkSiteResponseShape('/week/getStdWeekList', weeks), isNull);

      final etc = {'etc_list': []};
      expect(checkSiteResponseShape('/week/getStdEtcList', etc), isNull);
    });

    test('/archive/list 및 /archive/detail 정상 응답', () {
      final list = {
        'tot_cnt': 1,
        'list': [
          {'boarditem_no': 'b100', 'boarditem_title': '강의자료 1주차'},
        ],
      };
      expect(checkSiteResponseShape('/archive/list', list), isNull);

      final detail = {
        'boarditem_content': '<p>자료 본문</p>',
        'attach_file_list': [],
      };
      expect(checkSiteResponseShape('/archive/detail', detail), isNull);
    });

    test('/week/getAttachFileList 정상 응답', () {
      final files = {
        'attach_file_list': [
          {'file_name': 'test.pdf', 'file_path': '/path/test.pdf'},
        ],
      };
      expect(checkSiteResponseShape('/week/getAttachFileList', files), isNull);
    });

    test('/task/detail 및 /task/stdDetail 정상 응답', () {
      final detail = {
        'report_no': 'rep123',
        'report_nm': '과제 1',
        'report_content': '과제 내용 안내',
      };
      expect(checkSiteResponseShape('/task/detail', detail), isNull);

      // 미제출 상태 (null 또는 empty)
      expect(checkSiteResponseShape('/task/stdDetail', null), isNull);
      expect(checkSiteResponseShape('/task/stdDetail', {}), isNull);

      // 제출 완료 상태
      final submitted = {
        'report_apply_no': 'sub123',
        'apply_yn': 'Y',
        'temp_yn': 'N',
      };
      expect(checkSiteResponseShape('/task/stdDetail', submitted), isNull);
    });

    test('/board/std/notice/list 및 /board/notice/info 정상 응답', () {
      final notices = {
        'tot_cnt': 1,
        'list': [
          {
            'boarditem_no': 'n1',
            'boarditem_title': '중간고사 안내',
            'course_nm': '운영체제',
            'insert_dt': '2026-10-15 09:00',
          },
        ],
      };
      expect(checkSiteResponseShape('/board/std/notice/list', notices), isNull);

      final info = {'boarditem_content': '<p>시험 일시 안내</p>'};
      expect(checkSiteResponseShape('/board/notice/info', info), isNull);
    });

    test('로그인 HTML 정상 구조 검증', () {
      const normalHtml = '''
<!DOCTYPE html>
<html>
<head>
  <script src="/common/js/gibberish-aes.js"></script>
</head>
<body>
  <form id="loginForm">
    <input type="hidden" name="key" value="sample_key_value">
    <input type="hidden" name="user_ip" value="127.0.0.1">
  </form>
</body>
</html>
''';
      expect(checkLoginHtmlStructure(normalHtml), isNull);
    });
  });

  group('학교 사이트 응답 형식 변경 감지', () {
    test('/term/getYearTermList: "list" 키 누락 또는 필드 이름 변경 감지', () {
      // 1. list 키가 terms로 변경됨
      final corrupted1 = {
        'terms': [
          {'term_year': '2026', 'term_cd': '2', 'current_term_yn': 'Y'},
        ],
      };
      final issue1 = checkSiteResponseShape(
        '/term/getYearTermList',
        corrupted1,
      );
      expect(issue1, isNotNull);
      expect(issue1!.route, '/term/getYearTermList');
      expect(issue1.reason, contains('list'));
      expect(issue1.actual, contains('Map(terms)'));

      // 2. 항목 내부 current_term_yn 필드 누락
      final corrupted2 = {
        'list': [
          {'term_year': '2026', 'term_cd': '2'},
        ],
      };
      final issue2 = checkSiteResponseShape(
        '/term/getYearTermList',
        corrupted2,
      );
      expect(issue2, isNotNull);
      expect(issue2!.reason, contains('current_term_yn'));
    });

    test('/course/getStdMyCourseList: "course_list" 누락 또는 비Map 응답 감지', () {
      // 1. Map 대신 List가 바로 응답으로 옴
      final issueNonMap = checkSiteResponseShape('/course/getStdMyCourseList', [
        {'course_id': 'c1'},
      ]);
      expect(issueNonMap, isNotNull);
      expect(issueNonMap!.actual, contains('List(1)'));

      // 2. course_list 필드가 누락됨
      final issueMissing = checkSiteResponseShape('/course/getStdMyCourseList', {
        'my_courses': [],
      });
      expect(issueMissing, isNotNull);
      expect(issueMissing!.reason, contains('course_list'));

      // 3. 과목 항목에 course_id 누락
      final issueField = checkSiteResponseShape('/course/getStdMyCourseList', {
        'course_list': [
          {'course_name': '운영체제'},
        ],
      });
      expect(issueField, isNotNull);
      expect(issueField!.reason, contains('course_id'));
    });

    test('/week/getStdWeekList: "week_list" 누락 감지', () {
      final corrupted = {'weeks': []};
      final issue = checkSiteResponseShape('/week/getStdWeekList', corrupted);
      expect(issue, isNotNull);
      expect(issue!.reason, contains('week_list'));
    });

    test('/archive/list 및 /archive/detail 형식 변경 감지', () {
      final corruptedList = {
        'list': [
          {'item_id': '101'}, // boarditem_no 누락
        ],
      };
      final issueList = checkSiteResponseShape(
        '/archive/list',
        corruptedList,
      );
      expect(issueList, isNotNull);
      expect(issueList!.reason, contains('boarditem_no'));

      final corruptedDetail = {'title': '제목만 있고 본문 없음'};
      final issueDetail = checkSiteResponseShape(
        '/archive/detail',
        corruptedDetail,
      );
      expect(issueDetail, isNotNull);
      expect(issueDetail!.reason, contains('상세 내용'));
    });

    test('/task/detail: 과제 필드 누락 감지', () {
      final corrupted = {'assignment_title': '과제제목만 있음'};
      final issue = checkSiteResponseShape('/task/detail', corrupted);
      expect(issue, isNotNull);
      expect(issue!.reason, contains('필수 필드'));
    });

    test('/board/std/notice/list: 공지 식별자 누락 감지', () {
      final corrupted = {
        'list': [
          {'notice_title': '제목만 있음'},
        ],
      };
      final issue = checkSiteResponseShape(
        '/board/std/notice/list',
        corrupted,
      );
      expect(issue, isNotNull);
      expect(issue!.reason, contains('boarditem_no'));
    });

    test('로그인 HTML: 스크립트 또는 키 input 누락 감지', () {
      const missingAes = '''
<!DOCTYPE html>
<html>
<head><script src="/common/js/other.js"></script></head>
<body><input name="key" value="123"></body>
</html>
''';
      final issueAes = checkLoginHtmlStructure(missingAes);
      expect(issueAes, isNotNull);
      expect(issueAes!.reason, contains('gibberish-aes'));

      const missingKey = '''
<!DOCTYPE html>
<html>
<head><script src="/common/js/gibberish-aes.js"></script></head>
<body><input name="other_field" value="123"></body>
</html>
''';
      final issueKey = checkLoginHtmlStructure(missingKey);
      expect(issueKey, isNotNull);
      expect(issueKey!.expected, contains('input'));
      expect(issueKey.reason, contains('key'));
    });
  });

  group('활동 로그 및 1일 1회 사용자 알림 검증', () {
    late Directory tempDir;
    late Store store;

    setUp(() async {
      tempDir = await Directory.systemTemp.createTemp('canary-test-');
      await databaseFactory.setDatabasesPath(tempDir.path);
      // ignore: invalid_use_of_visible_for_testing_member
      SharedPreferences.setMockInitialValues({});
      store = await Store.open();
    });

    tearDown(() async {
      await store.db.close();
      if (tempDir.existsSync()) {
        tempDir.deleteSync(recursive: true);
      }
    });

    test('형식 변경 발생 시 활동 로그에 기대/실제 형태 기록', () async {
      const issue = SiteFormatIssue(
        route: '/course/getStdMyCourseList',
        expected: 'Map(course_list: List)',
        actual: 'Map(my_courses)',
        reason: '수강 과목 목록("course_list") 필드가 누락되었거나 목록 형식이 아니에요.',
      );

      await logSiteFormatIssue(store, issue);

      final logs = await store.logs('sync');
      expect(logs, isNotEmpty);
      expect(logs.first['title'], '학교 사이트 구조 변경 감지');
      final detail = logs.first['detail'] as String;
      expect(detail, contains('/course/getStdMyCourseList'));
      expect(detail, contains('Map(course_list: List)'));
      expect(detail, contains('Map(my_courses)'));
    });

    test('동일 원인은 1일 1회만 알림(하루 1회 제한 및 다른 원인 허용)', () async {
      const issueCourse = SiteFormatIssue(
        route: '/course/getStdMyCourseList',
        expected: 'Map(course_list: List)',
        actual: 'Map(my_courses)',
        reason: '필드 누락',
      );

      final now = DateTime.utc(2026, 11, 10, 10, 0);

      // 1회차: 알림 발송 성공
      final notified1 = await notifySiteChangeIfDue(
        store,
        issueCourse,
        nowOverride: now,
      );
      expect(notified1, isTrue);

      // 상태 확인: lastError 및 meta 기록 확인
      expect(await store.meta(MetaKey.lastError), siteCanaryUserMessage);
      expect(
        await store.meta('siteCanaryNotified:/course/getStdMyCourseList'),
        now.toIso8601String(),
      );

      // 같은 원인으로 1시간 뒤 재시도: 하루 1회 제한으로 거부됨(false)
      final notifiedSameDay = await notifySiteChangeIfDue(
        store,
        issueCourse,
        nowOverride: now.add(const Duration(hours: 1)),
      );
      expect(notifiedSameDay, isFalse);

      // 다른 원인(/week/getStdWeekList) 발생: 다른 원인이므로 당일이라도 알림 발송 허용(true)
      const issueWeek = SiteFormatIssue(
        route: '/week/getStdWeekList',
        expected: 'Map(week_list: List)',
        actual: 'null',
        reason: '목록 누락',
      );
      final notifiedOther = await notifySiteChangeIfDue(
        store,
        issueWeek,
        nowOverride: now.add(const Duration(hours: 2)),
      );
      expect(notifiedOther, isTrue);

      // 25시간 경과(다음 날): 동일 원인이라도 다시 알림 발송 허용(true)
      final notifiedNextDay = await notifySiteChangeIfDue(
        store,
        issueCourse,
        nowOverride: now.add(const Duration(hours: 25)),
      );
      expect(notifiedNextDay, isTrue);
    });

    test('handleSiteFormatMismatch 호출 시 로그와 알림이 함께 동작', () async {
      const issue = SiteFormatIssue(
        route: '/board/std/notice/list',
        expected: 'Map(list: List)',
        actual: 'Map(items)',
        reason: '공지 목록 누락',
      );

      await handleSiteFormatMismatch(store, issue);

      final syncLogs = await store.logs('sync');
      expect(syncLogs.any((l) => l['title'] == '학교 사이트 구조 변경 감지'), isTrue);

      final notifLogs = await store.logs('notification');
      expect(notifLogs.any((l) => l['title'] == '학교 사이트 변경 알림 발송'), isTrue);
    });
  });

  group('CampusClient 통합 및 가상 학교 응답 형식 점검', () {
    test('CampusClient가 응답 형식 변경을 감지하여 formatIssues에 수집', () async {
      final fake = FakeBrokenCourseClient();
      addTearDown(fake.close);

      final issueList = <SiteFormatIssue>[];
      fake.onFormatMismatch = (issue) => issueList.add(issue);

      await expectLater(
        () => fake.fetchCourses(),
        throwsA(isA<CampusException>()),
      );

      expect(fake.formatIssues, isNotEmpty);
      expect(fake.formatIssues.first.route, '/course/getStdMyCourseList');
      expect(issueList, isNotEmpty);
      expect(issueList.first.route, '/course/getStdMyCourseList');
    });
  });
}

class FakeBrokenCourseClient extends CampusClient {
  @override
  Future<dynamic> api(
    String route,
    Map<String, dynamic>? payload, {
    String host = CampusClient.learning,
  }) async {
    switch (route) {
      case '/term/getYearTermList':
        return {
          'list': [
            {'current_term_yn': 'Y', 'term_year': '2026', 'term_cd': '2'},
          ],
        };
      case '/course/getStdMyCourseList':
        // 학교 서버가 course_list 대신 classes 라는 이름으로 변경하여 반환한 상황 시뮬레이션
        final body = {
          'classes': [
            {'id': 'c1', 'title': '소프트웨어공학'},
          ],
        };
        checkFormat(route, body);
        return body;
      default:
        return {};
    }
  }
}

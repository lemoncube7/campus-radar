import 'package:campus_radar/app_router.dart';
import 'package:campus_radar/course_labels.dart';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/timetable_model.dart';
import 'package:campus_radar/timetable_grid.dart';

ClassSlot slot(String key, int start, int end, {int day = 1}) => ClassSlot(
  courseKey: key,
  course: '컴퓨터프로그래밍 2',
  weekday: day,
  start: start,
  end: end,
  room: '공5412',
);
void main() {
  test(
    'Chained overlapping classes use consistent widths and distinct lanes when simultaneous',
    () {
      final rows = [
        slot('a', 540, 660),
        slot('b', 600, 720),
        slot('c', 690, 780),
        slot('d', 800, 850),
      ];
      final positions = timetableLanes(rows);
      expect(positions[rows[0].id]!.count, 2);
      expect(positions[rows[2].id]!.count, 2);
      expect(positions[rows[3].id]!.count, 1);
      for (final a in rows) {
        for (final b in rows) {
          if (a.id != b.id && a.start < b.end && b.start < a.end) {
            expect(positions[a.id]!.lane, isNot(positions[b.id]!.lane));
          }
        }
      }
    },
  );
  test(
    'Updating one syllabus retains failed courses and removes obsolete sessions',
    () {
      final old = [slot('success', 540, 600), slot('failed', 660, 720)];
      final fresh = slot('success', 800, 860, day: 3);
      final merged = replaceCourseSlots(old, 'success', [fresh]);
      expect(merged.map((e) => e.id), containsAll([old[1].id, fresh.id]));
      expect(merged.map((e) => e.id), isNot(contains(old[0].id)));
      expect(replaceCourseSlots(merged, 'success', []).single.id, old[1].id);
    },
  );
  testWidgets(
    'Narrow dark timetable supports aliases, weekends, early and late classes without layout exceptions',
    (tester) async {
      tester.view.physicalSize = const Size(360, 900);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      courseAliases = {'컴퓨터프로그래밍 2': '컴프2'};
      addTearDown(() => courseAliases = {});
      final rows = [
        slot('a', 480, 570),
        slot('b', 510, 600),
        slot('c', 1140, 1320, day: 7),
      ];
      await tester.pumpWidget(
        MaterialApp(
          onGenerateRoute: buildAppRoute,
          theme: ThemeData.dark(),
          home: Scaffold(
            body: SingleChildScrollView(child: TimetableGrid(entries: rows)),
          ),
        ),
      );
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      expect(find.textContaining('컴프2'), findsWidgets);
      await tester.drag(
        find.byType(SingleChildScrollView).last,
        const Offset(-650, 0),
      );
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets('Week timetable preview can be rendered as an artifact', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(760, 840);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.runAsync(() async {
      if (!await File('C:/Windows/Fonts/malgun.ttf').exists()) {
        return;
      }
      final font = FontLoader('Malgun');
      font.addFont(
        Future.value(
          ByteData.sublistView(
            await File('C:/Windows/Fonts/malgun.ttf').readAsBytes(),
          ),
        ),
      );
      await font.load();
    });
    final key = GlobalKey();
    await tester.pumpWidget(
      MaterialApp(
        onGenerateRoute: buildAppRoute,
        theme: ThemeData(fontFamily: 'Malgun'),
        home: Scaffold(
          body: RepaintBoundary(
            key: key,
            child: ColoredBox(
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: TimetableGrid(
                  entries: [
                    slot('a', 540, 630),
                    slot('b', 660, 780, day: 2),
                    slot('c', 900, 1080, day: 4),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    await tester.runAsync(() async {
      final image =
          await (key.currentContext!.findRenderObject()
                  as RenderRepaintBoundary)
              .toImage(pixelRatio: 1);
      final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
      final dir = await Directory.systemTemp.createTemp(
        'radar-timetable-render-',
      );
      await File(
        '${dir.path}/preview.png',
      ).writeAsBytes(bytes!.buffer.asUint8List());
      await dir.delete(recursive: true);
      image.dispose();
    });
  });
}

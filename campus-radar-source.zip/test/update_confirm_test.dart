import 'dart:convert';
import 'dart:io';
import 'package:campus_radar/ai.dart';
import 'package:campus_radar/ai_confirm.dart';
import 'package:campus_radar/campus.dart';
import 'package:campus_radar/services.dart';
import 'package:campus_radar/updates.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  late Directory dir;
  late Store store;
  final native = <MethodCall>[];
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    dir = await Directory.systemTemp.createTemp('radar031-');
    await databaseFactory.setDatabasesPath(dir.path);
    store = await Store.open();
    native.clear();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(bridge, (c) async {
          native.add(c);
          if (c.method == 'calendarPermission') return true;
          return 1;
        });
  });
  tearDown(() async {
    await store.db.close();
    await dir.delete(recursive: true);
  });
  Map<String, dynamic> manifest(int build, String channel) => {
    'versionName': 'test.$build',
    'versionCode': build,
    'channel': channel,
    'sha256': 'a' * 64,
    'apkUrl':
        'https://github.com/lemoncube7/campus-radar/releases/download/test/app.apk',
  };
  final n = CampusNotice(
    id: 'n',
    title: '가상 공지',
    course: '가상 과목',
    body: '2026년 10월 20일 23시 59분 제출',
    context: {},
  );
  ScheduleCandidate candidate({
    String date = '2026-10-20',
    String time = '23:59',
    String action = 'add',
  }) => ScheduleCandidate(
    title: '가상 제출',
    date: date,
    time: time,
    action: action,
    evidence: '2026년 10월 20일',
    uncertainty: '',
    category: 'task',
  );
  test('Stable channel ignores a higher development release', () {
    expect(
      chooseUpdate(
        [manifest(17, 'development'), manifest(16, 'stable')],
        'stable',
        15,
      )?['versionCode'],
      16,
    );
    expect(
      chooseUpdate(
        [manifest(17, 'development'), manifest(16, 'stable')],
        'development',
        15,
      )?['versionCode'],
      17,
    );
    expect(chooseUpdate([manifest(16, 'stable')], 'development', 16), isNull);
  });
  test('Manifest rejects wrong channel, insecure URL and malformed hash', () {
    expect(
      () => validateUpdate(manifest(16, 'development'), 'stable'),
      throwsFormatException,
    );
    expect(
      () => validateUpdate({
        ...manifest(16, 'stable'),
        'apkUrl': 'http://example.org/app.apk',
      }, 'stable'),
      throwsFormatException,
    );
    expect(
      () => validateUpdate({
        ...manifest(16, 'stable'),
        'sha256': 'bad',
      }, 'stable'),
      throwsFormatException,
    );
  });
  test('Automatic check persists candidate for foreground banner', () async {
    final p = await SharedPreferences.getInstance();
    await p.setString('updateChannel', 'development');
    await checkForUpdates(
      store,
      loader: (c) async => manifest(c == 'stable' ? 13 : 17, c),
    );
    expect((await cachedUpdate())?['versionCode'], 17);
    expect(p.getString('updateCheckedAt'), isNotNull);
  });
  test(
    'Changing channel removes development update from banner without downgrade',
    () async {
      final p = await SharedPreferences.getInstance();
      await p.setString('updateChannel', 'development');
      await checkForUpdates(
        store,
        loader: (c) async => manifest(c == 'stable' ? 13 : 17, c),
      );
      await p.setString('updateChannel', 'stable');
      expect(await cachedUpdate(), isNull);
      expect(await cachedUpdate(current: 12), containsPair('versionCode', 13));
    },
  );
  test(
    'Network errors preserve known update and do not fail collection caller',
    () async {
      final p = await SharedPreferences.getInstance();
      await p.setString('updateChannel', 'development');
      await checkForUpdates(store, loader: (c) async => manifest(17, c));
      await checkForUpdates(
        store,
        loader: (c) async => throw const SocketException('offline'),
      );
      expect((await cachedUpdate())?['versionCode'], 17);
      expect(p.getString('updateCheckError'), isNotEmpty);
    },
  );
  test('Unpublished development feed has no fabricated upgrade', () async {
    final p = await SharedPreferences.getInstance();
    await p.setString('updateChannel', 'development');
    await checkForUpdates(
      store,
      loader: (c) async => c == 'stable' ? manifest(13, c) : null,
    );
    expect(await cachedUpdate(), isNull);
  });
  test(
    'One-step confirmation saves KST instant without calendar access',
    () async {
      await confirmAiCandidate(store, 'AI:test', n, candidate());
      final s = jsonDecode((await store.meta('aiState:AI:test'))!);
      expect(s['status'], 'confirmed');
      expect(s['start'], '2026-10-20T14:59:00.000Z');
      expect(s['calendarSent'], false);
      expect(native, isEmpty);
    },
  );
  test(
    'Direct calendar save keeps date-only UTC semantics and stable event key',
    () async {
      await confirmAiCandidate(
        store,
        'AI:test',
        n,
        candidate(time: ''),
        calendar: true,
      );
      final w = native
          .singleWhere((c) => c.method == 'calendarWrite')
          .arguments;
      expect(w['key'], 'AI:test');
      expect(w['allDay'], true);
      expect(w['start'], DateTime.utc(2026, 10, 20).millisecondsSinceEpoch);
      expect(w['end'] - w['start'], 86400000);
    },
  );
  test(
    'Missing date and change candidates require editing rather than invented event',
    () async {
      await expectLater(
        confirmAiCandidate(store, 'AI:test', n, candidate(date: '', time: '')),
        throwsA(isA<AiFailure>()),
      );
      await expectLater(
        confirmAiCandidate(store, 'AI:test', n, candidate(action: 'change')),
        throwsA(isA<AiFailure>()),
      );
      expect(await store.meta('aiState:AI:test'), isNull);
      expect(native, isEmpty);
    },
  );
  test(
    'Previously edited values survive later direct calendar export',
    () async {
      await store.setMeta(
        'aiState:AI:test',
        jsonEncode({
          'title': 'Edited',
          'start': '2026-10-21T03:00:00.000Z',
          'allDay': false,
        }),
      );
      await confirmAiCandidate(
        store,
        'AI:test',
        n,
        candidate(),
        calendar: true,
      );
      final w = native
          .singleWhere((c) => c.method == 'calendarWrite')
          .arguments;
      expect(w['title'], 'Edited');
      expect(w['start'], DateTime.utc(2026, 10, 21, 3).millisecondsSinceEpoch);
    },
  );
}

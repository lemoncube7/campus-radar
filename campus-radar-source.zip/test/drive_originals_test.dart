import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/campus/campus_media.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/material_catalog.dart';
import 'package:campus_radar/campus/media_cache.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/export/academic_export.dart';
import 'package:campus_radar/export/drive_sync.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;

  group('attachmentOriginalLocation', () {
    test('reports separate file when uploaded', () {
      final loc = attachmentOriginalLocation(
        course: '자료구조',
        fileName: '과제.pdf',
        isSeparateUploaded: true,
      );
      expect(loc, 'Drive 원본: 자료/자료구조/과제.pdf');
    });

    test('reports zip only when only in zip', () {
      final loc = attachmentOriginalLocation(
        course: '운영체제 (01)',
        fileName: '실습.pdf',
        isSeparateUploaded: false,
        isZipUploaded: true,
      );
      expect(loc, 'Drive 원본: 캠퍼스레이더 첨부원본.zip 안 운영체제 _01_/실습.pdf');
    });

    test('reports none for un-uploaded A/B links', () {
      final loc = attachmentOriginalLocation(
        course: '컴퓨터네트워크',
        fileName: '교재.pdf',
        isSeparateUploaded: false,
        isZipUploaded: false,
        isFormMedia: false,
      );
      expect(loc, 'Drive 원본 없음');
    });

    test('reports none with login required message for C links', () {
      final loc = attachmentOriginalLocation(
        course: '알고리즘',
        fileName: '시험안내.pdf',
        isSeparateUploaded: false,
        isZipUploaded: false,
        isFormMedia: true,
      );
      expect(loc, 'Drive 원본 없음 (학교 로그인이 필요해 링크로 받을 수 없어요)');
    });
  });

  group('academicReadingRules', () {
    test('contains Drive original first rule and web error fallback without hallucination', () {
      expect(
        academicReadingRules.any(
          (r) => r.contains('Drive 원본') && r.contains('먼저 확인'),
        ),
        isTrue,
      );
      expect(
        academicReadingRules.any(
          (r) =>
              (r.contains('DNS') || r.contains('웹에 접근할 수 없는 환경')) &&
              r.contains('재시도') &&
              r.contains('학생에게 파일 첨부를 요청'),
        ),
        isTrue,
      );
      expect(
        academicReadingRules.any(
          (r) => r.contains('열어보지 못한') && r.contains('읽은 것처럼'),
        ),
        isTrue,
      );
      expect(
        academicReadingRules.any(
          (r) => r.contains('LLM이 직접 HTTP GET 요청') && r.contains('직접 다운로드하고 그 내용을 분석'),
        ),
        isFalse,
      );
    });
  });

  group('buildAcademicExport location lines in documents', () {
    late Store s;
    late Directory dir;
    const profile = '0123456789abcdef0123456789abcdef';

    setUp(() async {
      SharedPreferences.setMockInitialValues({});
      dir = await Directory.systemTemp.createTemp('radar-orig-test-');
      await databaseFactory.setDatabasesPath(dir.path);
      s = await Store.open();
      await s.setMeta('lastSuccess', '2026-11-01T00:00:00Z');
      await s.setMeta('courses', '[]');
    });

    tearDown(() async {
      await s.db.close();
      await dir.delete(recursive: true);
    });

    test('generates expected location lines and clean download links for all 4 cases', () async {
      final mSeparate = CampusItem(
        key: 'LS:c1:1:1',
        type: 'LS',
        title: '자료 1',
        course: '과목A',
        courseId: 'c1',
        classNo: '1',
        contentsId: '1',
        status: 'pending',
        context: const {},
        media: const [
          CampusMedia(
            name: 'sep.pdf',
            url: 'https://dcs-learning.cnu.ac.kr/file/sep.pdf',
            size: 1024,
          ),
        ],
      );
      final mZip = CampusItem(
        key: 'LS:c1:1:2',
        type: 'LS',
        title: '자료 2',
        course: '과목A',
        courseId: 'c1',
        classNo: '1',
        contentsId: '2',
        status: 'pending',
        context: const {},
        media: const [
          CampusMedia(
            name: 'zip.pdf',
            url: 'https://dcs-learning.cnu.ac.kr/file/zip.pdf',
            size: 2048,
          ),
        ],
      );
      final mNoneAB = CampusItem(
        key: 'LS:c1:1:3',
        type: 'LS',
        title: '자료 3',
        course: '과목A',
        courseId: 'c1',
        classNo: '1',
        contentsId: '3',
        status: 'pending',
        context: const {},
        media: const [
          CampusMedia(
            name: 'none.pdf',
            url: 'https://dcs-learning.cnu.ac.kr/file/none.pdf',
            size: 4096,
          ),
        ],
      );
      final mNoneC = CampusItem(
        key: 'LS:c1:1:4',
        type: 'LS',
        title: '자료 4',
        course: '과목A',
        courseId: 'c1',
        classNo: '1',
        contentsId: '4',
        status: 'pending',
        context: const {},
        media: const [
          CampusMedia(
            name: 'c.pdf',
            url: 'https://dcs-lcms.cnu.ac.kr/api/v1/file/downloadSingleFile',
            form: {'file_no': '123'},
            size: 8192,
          ),
        ],
      );

      for (final item in [mSeparate, mZip, mNoneAB, mNoneC]) {
        await s.db.insert('items', {
          'id': item.key,
          'payload': jsonEncode(item.toJson()),
        });
      }

      final bundle = await buildAcademicExport(
        s,
        profile,
        uploadedOriginals: {'자료/과목A/sep.pdf'},
        zipOriginals: {'과목A/zip.pdf'},
      );

      final courseDoc = bundle.documents['과목/과목A.txt']!;
      expect(courseDoc, contains('Drive 원본: 자료/과목A/sep.pdf'));
      expect(courseDoc, contains('Drive 원본: 캠퍼스레이더 첨부원본.zip 안 과목A/zip.pdf'));
      expect(courseDoc, contains('Drive 원본 없음\n'));
      expect(
        courseDoc,
        contains('Drive 원본 없음 (학교 로그인이 필요해 링크로 받을 수 없어요)'),
      );
      expect(
        courseDoc,
        contains('다운로드 링크: https://dcs-learning.cnu.ac.kr/file/sep.pdf (로그인/인증 없이 즉시 다운로드 가능)'),
      );
      expect(courseDoc, isNot(contains('LLM 웹 요청/다운로드 지원 직링크')));
      expect(courseDoc, isNot(contains('Google Drive "캠퍼스레이더 첨부원본.zip"에 원본 파일 보관됨')));

      final indexDoc = bundle.documents['첨부 자료 인덱스.txt']!;
      expect(indexDoc, contains('Drive 원본: 자료/과목A/sep.pdf'));
      expect(indexDoc, contains('Drive 원본: 캠퍼스레이더 첨부원본.zip 안 과목A/zip.pdf'));
      expect(indexDoc, contains('Drive 원본 없음\n'));
      expect(
        indexDoc,
        contains('Drive 원본 없음 (학교 로그인이 필요해 링크로 받을 수 없어요)'),
      );
    });
  });

  group('buildDriveFilesPayload', () {
    late Store s;
    late Directory dir;
    late MediaCache cache;

    setUp(() async {
      SharedPreferences.setMockInitialValues({});
      dir = await Directory.systemTemp.createTemp('radar-payload-test-');
      await databaseFactory.setDatabasesPath(dir.path);
      s = await Store.open();
      cache = MediaCache(Directory('${dir.path}/cache'));
      await cache.root.create(recursive: true);
    });

    tearDown(() async {
      await s.db.close();
      await dir.delete(recursive: true);
    });

    test('respects course scope, limits single file size, caps total bytes, and contains no file bytes in JSON', () async {
      // 1. Normal file in CourseA
      final m1 = CampusItem(
        key: 'LS:c1:1:1',
        type: 'LS',
        title: '자료 1',
        course: 'CourseA',
        courseId: 'c1',
        classNo: '1',
        contentsId: '1',
        status: 'pending',
        context: const {},
        media: const [
          CampusMedia(name: 'f1.pdf', url: 'https://dcs-learning.cnu.ac.kr/file/f1.pdf'),
        ],
      );
      final file1 = cache.data(m1.media.first);
      await file1.writeAsBytes(utf8.encode('PDF 1'));
      await cache.record(m1.media.first).writeAsString(jsonEncode({'mime': 'application/pdf'}));

      // 2. File in excluded course
      final m2 = CampusItem(
        key: 'LS:c2:1:1',
        type: 'LS',
        title: '자료 2',
        course: 'CourseB',
        courseId: 'c2',
        classNo: '1',
        contentsId: '1',
        status: 'pending',
        context: const {},
        media: const [
          CampusMedia(name: 'f2.pdf', url: 'https://dcs-learning.cnu.ac.kr/file/f2.pdf'),
        ],
      );
      final file2 = cache.data(m2.media.first);
      await file2.writeAsBytes(utf8.encode('PDF 2'));
      await cache.record(m2.media.first).writeAsString(jsonEncode({'mime': 'application/pdf'}));

      // 3. Oversized single file (> 25MB)
      final m3 = CampusItem(
        key: 'LS:c1:1:2',
        type: 'LS',
        title: '자료 3',
        course: 'CourseA',
        courseId: 'c1',
        classNo: '1',
        contentsId: '2',
        status: 'pending',
        context: const {},
        media: const [
          CampusMedia(name: 'f3.pdf', url: 'https://dcs-learning.cnu.ac.kr/file/f3.pdf'),
        ],
      );
      final file3 = cache.data(m3.media.first);
      await file3.writeAsBytes(utf8.encode('PDF 3 oversized content'));
      await cache.record(m3.media.first).writeAsString(jsonEncode({'mime': 'application/pdf'}));

      for (final item in [m1, m2, m3]) {
        await s.db.insert('items', {'id': item.key, 'payload': jsonEncode(item.toJson())});
      }

      // Test with maxSingleFileBytes = 10 bytes (f1 has 5 bytes, f3 has 24 bytes)
      final payload = await buildDriveFilesPayload(
        store: s,
        cache: cache,
        selectedCourses: {'CourseA'},
        maxSingleFileBytes: 10,
        maxTotalBytes: 1000,
      );

      expect(payload.containsKey('자료/CourseA/f1.pdf'), isTrue);
      expect(payload.containsKey('자료/CourseB/f2.pdf'), isFalse); // excluded course
      expect(payload.containsKey('자료/CourseA/f3.pdf'), isFalse); // oversized file

      // Check structure: no byte contents in JSON
      final entry = payload['자료/CourseA/f1.pdf']!;
      expect(entry['path'], file1.path);
      expect(entry['bytes'], 5);
      expect(entry['mime'], 'application/pdf');
      expect(entry['sha256'], isNotEmpty);
      expect(entry.containsKey('content'), isFalse);
      expect(entry.containsKey('data'), isFalse);

      // Test total bytes cap
      final payloadCapped = await buildDriveFilesPayload(
        store: s,
        cache: cache,
        selectedCourses: {'CourseA'},
        maxSingleFileBytes: 10,
        maxTotalBytes: 3, // Less than 5 bytes, so cannot add f1
      );
      expect(payloadCapped.isEmpty, isTrue);
    });
  });

  group('downloadDriveOriginals', () {
    late Store s;
    late Directory dir;
    late MediaCache cache;

    setUp(() async {
      SharedPreferences.setMockInitialValues({});
      dir = await Directory.systemTemp.createTemp('radar-download-test-');
      await databaseFactory.setDatabasesPath(dir.path);
      s = await Store.open();
      cache = MediaCache(Directory('${dir.path}/cache'));
      await cache.root.create(recursive: true);
    });

    tearDown(() async {
      await s.db.close();
      await dir.delete(recursive: true);
    });

    test('caps downloads at 20, respects 100MB cap, skips single >25MB, and handles failures gracefully', () async {
      final downloadedMedia = <String>[];

      // Add 25 uncached A/B items
      for (var i = 1; i <= 25; i++) {
        final item = CampusItem(
          key: 'LS:c1:1:$i',
          type: 'LS',
          title: '자료 $i',
          course: 'CourseA',
          courseId: 'c1',
          classNo: '1',
          contentsId: '$i',
          status: 'pending',
          context: const {},
          media: [
            CampusMedia(
              name: 'file_$i.pdf',
              url: 'https://dcs-learning.cnu.ac.kr/file/file_$i.pdf',
              size: 1024,
            ),
          ],
        );
        await s.db.insert('items', {'id': item.key, 'payload': jsonEncode(item.toJson())});
      }

      // Fake fetcher
      Future<File> fakeFetcher(CampusClient client, CampusMedia media) async {
        downloadedMedia.add(media.name);
        final file = File('${dir.path}/cache/${media.name}');
        await file.writeAsBytes(List.filled(1024, 0));
        return file;
      }

      final count = await downloadDriveOriginals(
        store: s,
        cache: cache,
        fetcher: fakeFetcher,
        maxNewDownloads: 20,
        maxTotalBytes: 100 * 1024 * 1024,
        maxSingleFileBytes: 25 * 1024 * 1024,
      );

      // Capped at 20
      expect(count, 20);
      expect(downloadedMedia.length, 20);
    });

    test('skips C files and non-learning.cnu.ac.kr URLs', () async {
      final mC = CampusItem(
        key: 'LS:c1:1:c',
        type: 'LS',
        title: 'C자료',
        course: 'CourseA',
        courseId: 'c1',
        classNo: '1',
        contentsId: 'c',
        status: 'pending',
        context: const {},
        media: const [
          CampusMedia(
            name: 'c.pdf',
            url: 'https://dcs-lcms.cnu.ac.kr/api/v1/file/downloadSingleFile',
            form: {'file_no': '99'},
          ),
        ],
      );
      final mOther = CampusItem(
        key: 'LS:c1:1:other',
        type: 'LS',
        title: 'Other자료',
        course: 'CourseA',
        courseId: 'c1',
        classNo: '1',
        contentsId: 'other',
        status: 'pending',
        context: const {},
        media: const [
          CampusMedia(
            name: 'other.pdf',
            url: 'https://other-domain.cnu.ac.kr/file/other.pdf',
          ),
        ],
      );
      for (final item in [mC, mOther]) {
        await s.db.insert('items', {'id': item.key, 'payload': jsonEncode(item.toJson())});
      }

      var downloaded = 0;
      final count = await downloadDriveOriginals(
        store: s,
        cache: cache,
        fetcher: (client, media) async {
          downloaded++;
          final file = File('${dir.path}/cache/${media.name}');
          await file.writeAsBytes([0]);
          return file;
        },
      );

      expect(count, 0);
      expect(downloaded, 0);
    });

    test('failure of one file does not stop subsequent files', () async {
      final m1 = CampusItem(
        key: 'LS:c1:1:1',
        type: 'LS',
        title: '자료 1',
        course: 'CourseA',
        courseId: 'c1',
        classNo: '1',
        contentsId: '1',
        status: 'pending',
        context: const {},
        media: const [
          CampusMedia(
            name: 'fail.pdf',
            url: 'https://dcs-learning.cnu.ac.kr/file/fail.pdf',
          ),
        ],
      );
      final m2 = CampusItem(
        key: 'LS:c1:1:2',
        type: 'LS',
        title: '자료 2',
        course: 'CourseA',
        courseId: 'c1',
        classNo: '1',
        contentsId: '2',
        status: 'pending',
        context: const {},
        media: const [
          CampusMedia(
            name: 'succeed.pdf',
            url: 'https://dcs-learning.cnu.ac.kr/file/succeed.pdf',
          ),
        ],
      );
      for (final item in [m1, m2]) {
        await s.db.insert('items', {'id': item.key, 'payload': jsonEncode(item.toJson())});
      }

      final count = await downloadDriveOriginals(
        store: s,
        cache: cache,
        fetcher: (client, media) async {
          if (media.name == 'fail.pdf') {
            throw const SocketException('Connection refused');
          }
          final file = File('${dir.path}/cache/${media.name}');
          await file.writeAsBytes([1, 2, 3]);
          return file;
        },
      );

      expect(count, 1);
    });
  });

  group('safeAttachmentFileName and safeCourseFolderName', () {
    test('sanitizes slashes, backslashes, and Windows invalid characters', () {
      expect(safeAttachmentFileName('ch1/notes.pdf'), 'ch1_notes.pdf');
      expect(safeAttachmentFileName('folder\\sub\\file.txt'), 'folder_sub_file.txt');
      expect(safeAttachmentFileName('과제: 1차?.pdf'), '과제_ 1차_.pdf');
      expect(safeAttachmentFileName('test<1>|2*"3".pdf'), 'test_1__2__3_.pdf');
      expect(safeAttachmentFileName('   '), '첨부파일');
      expect(safeAttachmentFileName('///'), '___');
    });

    test('buildCourseFolderMap disambiguates course folder names deterministically', () {
      final map1 = buildCourseFolderMap(['운영체제(1)', '운영체제[1]']);
      expect(map1['운영체제(1)'], '운영체제_1_');
      expect(map1['운영체제[1]'], '운영체제_1__2');

      // Regardless of input order, alphabetical sorting guarantees same assignment
      final map2 = buildCourseFolderMap(['운영체제[1]', '운영체제(1)']);
      expect(map2['운영체제(1)'], '운영체제_1_');
      expect(map2['운영체제[1]'], '운영체제_1__2');
    });
  });

  group('resolveDriveAttachmentPaths', () {
    test('disambiguates duplicate attachment names within course deterministically', () {
      final m1 = StudyMaterial(
        id: 'id-01',
        sourceId: 'src-1',
        sourceType: 'LS',
        title: '1주차 강의자료',
        course: '컴퓨터네트워크',
        date: DateTime.utc(2026, 9, 1),
        media: const CampusMedia(name: 'lecture.pdf', url: 'https://dcs-learning.cnu.ac.kr/file/1'),
      );
      final m2 = StudyMaterial(
        id: 'id-02',
        sourceId: 'src-2',
        sourceType: 'LS',
        title: '2주차 강의자료',
        course: '컴퓨터네트워크',
        date: DateTime.utc(2026, 9, 8),
        media: const CampusMedia(name: 'lecture.pdf', url: 'https://dcs-learning.cnu.ac.kr/file/2'),
      );
      final m3 = StudyMaterial(
        id: 'id-03',
        sourceId: 'src-3',
        sourceType: 'LS',
        title: '3주차 강의자료',
        course: '컴퓨터네트워크',
        date: DateTime.utc(2026, 9, 15),
        media: const CampusMedia(name: 'lecture.pdf', url: 'https://dcs-learning.cnu.ac.kr/file/3'),
      );
      final mSlash = StudyMaterial(
        id: 'id-04',
        sourceId: 'src-4',
        sourceType: 'LS',
        title: '4주차 실습자료',
        course: '컴퓨터네트워크',
        date: DateTime.utc(2026, 9, 22),
        media: const CampusMedia(name: 'ch1/notes.pdf', url: 'https://dcs-learning.cnu.ac.kr/file/4'),
      );

      final paths = resolveDriveAttachmentPaths([m3, m1, mSlash, m2]);
      expect(paths['id-01']!.fileName, 'lecture.pdf');
      expect(paths['id-01']!.driveKey, '자료/컴퓨터네트워크/lecture.pdf');
      expect(paths['id-01']!.zipKey, '컴퓨터네트워크/lecture.pdf');

      expect(paths['id-02']!.fileName, 'lecture (2).pdf');
      expect(paths['id-02']!.driveKey, '자료/컴퓨터네트워크/lecture (2).pdf');
      expect(paths['id-02']!.zipKey, '컴퓨터네트워크/lecture (2).pdf');

      expect(paths['id-03']!.fileName, 'lecture (3).pdf');
      expect(paths['id-03']!.driveKey, '자료/컴퓨터네트워크/lecture (3).pdf');
      expect(paths['id-03']!.zipKey, '컴퓨터네트워크/lecture (3).pdf');

      expect(paths['id-04']!.fileName, 'ch1_notes.pdf');
      expect(paths['id-04']!.driveKey, '자료/컴퓨터네트워크/ch1_notes.pdf');
      expect(paths['id-04']!.zipKey, '컴퓨터네트워크/ch1_notes.pdf');
    });

    test('separates materials for colliding courses into distinct folders', () {
      final mA = StudyMaterial(
        id: 'id-c1',
        sourceId: 'src-c1',
        sourceType: 'LS',
        title: '자료 A',
        course: '운영체제(1)',
        date: DateTime.utc(2026, 9, 1),
        media: const CampusMedia(name: 'code.c', url: 'https://dcs-learning.cnu.ac.kr/file/c1'),
      );
      final mB = StudyMaterial(
        id: 'id-c2',
        sourceId: 'src-c2',
        sourceType: 'LS',
        title: '자료 B',
        course: '운영체제[1]',
        date: DateTime.utc(2026, 9, 1),
        media: const CampusMedia(name: 'code.c', url: 'https://dcs-learning.cnu.ac.kr/file/c2'),
      );

      final paths = resolveDriveAttachmentPaths([mA, mB]);
      expect(paths['id-c1']!.safeCourse, '운영체제_1_');
      expect(paths['id-c2']!.safeCourse, '운영체제_1__2');
      expect(paths['id-c1']!.driveKey, '자료/운영체제_1_/code.c');
      expect(paths['id-c2']!.driveKey, '자료/운영체제_1__2/code.c');
    });
  });

  group('buildDriveFilesPayload with duplicates, slashes, and course collisions', () {
    late Store s;
    late Directory dir;
    late MediaCache cache;

    setUp(() async {
      SharedPreferences.setMockInitialValues({});
      dir = await Directory.systemTemp.createTemp('radar-dup-test-');
      await databaseFactory.setDatabasesPath(dir.path);
      s = await Store.open();
      cache = MediaCache(Directory('${dir.path}/cache'));
      await cache.root.create(recursive: true);
    });

    tearDown(() async {
      await s.db.close();
      await dir.delete(recursive: true);
    });

    test('includes all duplicate attachments with distinct keys and safe filenames', () async {
      final m1 = CampusItem(
        key: 'LS:c1:1:1',
        type: 'LS',
        title: '1주차',
        course: 'CourseA',
        courseId: 'c1',
        classNo: '1',
        contentsId: '1',
        status: 'pending',
        startsAt: DateTime.utc(2026, 9, 1),
        context: const {},
        media: const [
          CampusMedia(name: 'lecture.pdf', url: 'https://dcs-learning.cnu.ac.kr/file/1'),
        ],
      );
      final m2 = CampusItem(
        key: 'LS:c1:1:2',
        type: 'LS',
        title: '2주차',
        course: 'CourseA',
        courseId: 'c1',
        classNo: '1',
        contentsId: '2',
        status: 'pending',
        startsAt: DateTime.utc(2026, 9, 8),
        context: const {},
        media: const [
          CampusMedia(name: 'lecture.pdf', url: 'https://dcs-learning.cnu.ac.kr/file/2'),
        ],
      );
      final mSlash = CampusItem(
        key: 'LS:c1:1:3',
        type: 'LS',
        title: '3주차',
        course: 'CourseA',
        courseId: 'c1',
        classNo: '1',
        contentsId: '3',
        status: 'pending',
        startsAt: DateTime.utc(2026, 9, 15),
        context: const {},
        media: const [
          CampusMedia(name: 'ch1/notes.pdf', url: 'https://dcs-learning.cnu.ac.kr/file/3'),
        ],
      );

      for (final item in [m1, m2, mSlash]) {
        await s.db.insert('items', {'id': item.key, 'payload': jsonEncode(item.toJson())});
        final f = cache.data(item.media.first);
        await f.writeAsBytes(utf8.encode(item.title));
        await cache.record(item.media.first).writeAsString(jsonEncode({'mime': 'application/pdf'}));
      }

      final payload = await buildDriveFilesPayload(store: s, cache: cache);
      expect(payload.containsKey('자료/CourseA/lecture.pdf'), isTrue);
      expect(payload.containsKey('자료/CourseA/lecture (2).pdf'), isTrue);
      expect(payload.containsKey('자료/CourseA/ch1_notes.pdf'), isTrue);
      expect(payload['자료/CourseA/lecture.pdf']!['bytes'], utf8.encode('1주차').length);
      expect(payload['자료/CourseA/lecture (2).pdf']!['bytes'], utf8.encode('2주차').length);
    });
  });

  group('buildAcademicExport location lines with duplicate files and course collisions', () {
    late Store s;
    late Directory dir;
    const profile = '0123456789abcdef0123456789abcdef';

    setUp(() async {
      SharedPreferences.setMockInitialValues({});
      dir = await Directory.systemTemp.createTemp('radar-export-dup-');
      await databaseFactory.setDatabasesPath(dir.path);
      s = await Store.open();
      await s.setMeta('lastSuccess', '2026-11-01T00:00:00Z');
      await s.setMeta('courses', '[]');
    });

    tearDown(() async {
      await s.db.close();
      await dir.delete(recursive: true);
    });

    test('points each duplicate attachment to its distinct Drive location and separates colliding courses', () async {
      final m1 = CampusItem(
        key: 'LS:c1:1:1',
        type: 'LS',
        title: '자료 1',
        course: '운영체제(1)',
        courseId: 'c1',
        classNo: '1',
        contentsId: '1',
        status: 'pending',
        startsAt: DateTime.utc(2026, 9, 1),
        context: const {},
        media: const [
          CampusMedia(name: 'dup.pdf', url: 'https://dcs-learning.cnu.ac.kr/file/1', size: 100),
        ],
      );
      final m2 = CampusItem(
        key: 'LS:c1:1:2',
        type: 'LS',
        title: '자료 2',
        course: '운영체제(1)',
        courseId: 'c1',
        classNo: '1',
        contentsId: '2',
        status: 'pending',
        startsAt: DateTime.utc(2026, 9, 8),
        context: const {},
        media: const [
          CampusMedia(name: 'dup.pdf', url: 'https://dcs-learning.cnu.ac.kr/file/2', size: 200),
        ],
      );
      final mColliding = CampusItem(
        key: 'LS:c2:1:1',
        type: 'LS',
        title: '자료 3',
        course: '운영체제[1]',
        courseId: 'c2',
        classNo: '1',
        contentsId: '1',
        status: 'pending',
        startsAt: DateTime.utc(2026, 9, 1),
        context: const {},
        media: const [
          CampusMedia(name: 'dup.pdf', url: 'https://dcs-learning.cnu.ac.kr/file/3', size: 300),
        ],
      );
      for (final item in [m1, m2, mColliding]) {
        await s.db.insert('items', {'id': item.key, 'payload': jsonEncode(item.toJson())});
      }

      final bundle = await buildAcademicExport(
        s,
        profile,
        uploadedOriginals: {
          '자료/운영체제_1_/dup.pdf',
          '자료/운영체제_1_/dup (2).pdf',
          '자료/운영체제_1__2/dup.pdf',
        },
      );

      final doc1 = bundle.documents['과목/운영체제_1_.txt']!;
      expect(doc1, contains('Drive 원본: 자료/운영체제_1_/dup.pdf'));
      expect(doc1, contains('Drive 원본: 자료/운영체제_1_/dup (2).pdf'));

      final doc2 = bundle.documents['과목/운영체제_1__2.txt']!;
      expect(doc2, contains('Drive 원본: 자료/운영체제_1__2/dup.pdf'));

      final indexDoc = bundle.documents['첨부 자료 인덱스.txt']!;
      expect(indexDoc, contains('Drive 원본: 자료/운영체제_1_/dup.pdf'));
      expect(indexDoc, contains('Drive 원본: 자료/운영체제_1_/dup (2).pdf'));
      expect(indexDoc, contains('Drive 원본: 자료/운영체제_1__2/dup.pdf'));
    });
  });

  group('downloadDriveOriginals with null size and limit streaming', () {
    late Store s;
    late Directory dir;
    late MediaCache cache;

    setUp(() async {
      SharedPreferences.setMockInitialValues({});
      dir = await Directory.systemTemp.createTemp('radar-nullsize-test-');
      await databaseFactory.setDatabasesPath(dir.path);
      s = await Store.open();
      cache = MediaCache(Directory('${dir.path}/cache'));
      await cache.root.create(recursive: true);
    });

    tearDown(() async {
      await s.db.close();
      await dir.delete(recursive: true);
    });

    test('skips null-size file when fetched size exceeds single file limit', () async {
      final mOversized = CampusItem(
        key: 'LS:c1:1:huge',
        type: 'LS',
        title: '대용량 자료',
        course: 'CourseA',
        courseId: 'c1',
        classNo: '1',
        contentsId: 'huge',
        status: 'pending',
        context: const {},
        media: const [
          CampusMedia(
            name: 'huge.pdf',
            url: 'https://dcs-learning.cnu.ac.kr/file/huge.pdf',
            size: null,
          ),
        ],
      );
      final mNormal = CampusItem(
        key: 'LS:c1:1:normal',
        type: 'LS',
        title: '정상 자료',
        course: 'CourseA',
        courseId: 'c1',
        classNo: '1',
        contentsId: 'normal',
        status: 'pending',
        context: const {},
        media: const [
          CampusMedia(
            name: 'normal.pdf',
            url: 'https://dcs-learning.cnu.ac.kr/file/normal.pdf',
            size: null,
          ),
        ],
      );
      for (final item in [mOversized, mNormal]) {
        await s.db.insert('items', {'id': item.key, 'payload': jsonEncode(item.toJson())});
      }

      final downloadedFiles = <String>[];
      final count = await downloadDriveOriginals(
        store: s,
        cache: cache,
        maxSingleFileBytes: 100,
        maxTotalBytes: 500,
        fetcher: (client, media) async {
          downloadedFiles.add(media.name);
          final file = File('${dir.path}/cache/${media.name}');
          if (media.name == 'huge.pdf') {
            await file.writeAsBytes(List.filled(200, 0));
          } else {
            await file.writeAsBytes(List.filled(50, 0));
          }
          return file;
        },
      );

      expect(count, 1);
      expect(downloadedFiles, ['huge.pdf', 'normal.pdf']);
    });
  });

  group('MediaCache.fetch with maxBytes', () {
    late Directory dir;
    late MediaCache cache;

    setUp(() async {
      dir = await Directory.systemTemp.createTemp('radar-cache-fetch-');
      cache = MediaCache(Directory('${dir.path}/cache'));
      await cache.root.create(recursive: true);
    });

    tearDown(() async {
      await dir.delete(recursive: true);
    });

    test('rejects media when declared size exceeds maxBytes', () async {
      final client = CampusClient();
      const media = CampusMedia(
        name: 'large.pdf',
        url: 'https://dcs-learning.cnu.ac.kr/file/large.pdf',
        size: 30 * 1024 * 1024,
      );
      expect(
        () => cache.fetch(client, media, maxBytes: 25 * 1024 * 1024),
        throwsA(isA<CampusException>().having((e) => e.message, 'message', contains('저장 제한'))),
      );
      client.close();
    });
  });
}

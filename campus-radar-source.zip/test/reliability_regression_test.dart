import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/app_storage.dart';
import 'package:campus_radar/ai_inbox_repository.dart';
import 'package:campus_radar/ai_protocol.dart';
import 'package:campus_radar/campus_models.dart';
import 'package:campus_radar/timetable_model.dart';
import 'package:campus_radar/timetable_exceptions.dart';
import 'package:campus_radar/cancellation_repository.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  late Store store;
  setUp(() async {
    temp = await Directory.systemTemp.createTemp('radar-integrity-');
    await databaseFactory.setDatabasesPath(temp.path);
    store = await Store.open();
  });
  tearDown(() async {
    await store.db.close();
    await temp.delete(recursive: true);
  });
  const slot = ClassSlot(
    courseKey: 'sample:1',
    course: '예시 수업',
    weekday: 3,
    start: 780,
    end: 1020,
  );
  ClassCancellation cancellation(String id) =>
      ClassCancellation(id, slot.id, '2026-10-28', slot.course, '공지');
  test(
    'AI inbox isolates corrupt candidate, state, queue, chat and review without deleting source rows',
    () async {
      final notice = CampusNotice(
        id: 'n',
        title: '시험',
        course: slot.course,
        body: '10월 28일 13:00 시험입니다.',
        bodyFetched: true,
        context: {},
      );
      const candidate = ScheduleCandidate(
        title: '시험',
        date: '2026-10-28',
        time: '13:00',
        action: 'add',
        evidence: '10월 28일 13:00 시험입니다.',
        uncertainty: '',
        category: 'exam',
      );
      await store.saveNotice(notice);
      final key = candidateKey(notice, candidate);
      await store.setMeta(
        'aiCandidate:good',
        jsonEncode({
          'notice': notice.toJson(),
          'candidate': candidate.toJson(),
          'key': key,
        }),
      );
      await store.setMeta('aiCandidate:bad', '{');
      await store.setMeta('aiQueue:n', '[]');
      await store.setMeta('aiChat:all', '{');
      await store.setMeta('aiApproval:$key', '{');
      var result = await AiInboxRepository(store).read();
      expect(result.candidates.length, 1);
      expect(result.damagedRecords.toSet(), {
        'aiCandidate:bad',
        'aiQueue:n',
        'aiChat:all',
        'aiApproval:$key',
      });
      expect(await store.meta('aiCandidate:bad'), '{');
      await store.setMeta('aiState:$key', '{');
      result = await AiInboxRepository(store).read();
      expect(result.candidates, isEmpty);
      expect(await store.meta('aiState:$key'), '{');
    },
  );
  test(
    'Malformed cancellation row cannot discard a valid row or restore cancelled class',
    () {
      final valid = cancellation('good');
      final result = parseCancellationData(
        jsonEncode([
          valid.toJson(),
          {...valid.toJson(), 'id': 'bad-type', 'course': 42},
          {...valid.toJson(), 'id': 'bad-date', 'date': '2026-02-31'},
          12,
        ]),
      );
      expect(result.entries.map((r) => r.id), ['good']);
      expect(result.invalidRows, 3);
      expect(
        classesOnDate([slot], result.entries, DateTime(2026, 10, 28)),
        isEmpty,
      );
    },
  );
  test(
    'Cancellation repository restores last good snapshot and does not overwrite corrupt raw data on read',
    () async {
      final repo = CancellationRepository(store);
      await repo.apply([cancellation('one')]);
      await store.setMeta(CancellationRepository.key, '{');
      final read = await repo.read();
      expect(read.recovered, true);
      expect(read.entries.single.id, 'one');
      expect(await store.meta(CancellationRepository.key), '{');
      await repo.apply([cancellation('two')]);
      expect((await repo.read()).entries.length, 2);
      expect(await store.meta('${CancellationRepository.key}:unreadable'), '{');
    },
  );
  test(
    'Unreadable cancellation with no backup fails explicitly instead of fabricating an empty schedule',
    () async {
      await store.setMeta(CancellationRepository.key, '{');
      final repo = CancellationRepository(store);
      await expectLater(repo.read(), throwsFormatException);
      await expectLater(
        repo.apply([cancellation('one')]),
        throwsFormatException,
      );
      expect(await store.meta(CancellationRepository.key), '{');
    },
  );
  test(
    'Cancellation undo is atomic and refuses to overwrite a later edit',
    () async {
      final repo = CancellationRepository(store);
      final first = await repo.apply([cancellation('one')]);
      await repo.undo(first);
      expect((await repo.read()).entries, isEmpty);
      final second = await repo.apply([cancellation('one')]);
      await repo.apply([cancellation('two')]);
      await expectLater(repo.undo(second), throwsFormatException);
      expect((await repo.read()).entries.length, 2);
    },
  );
  test(
    'Cancellation plan covers a multi-day selection without altering next week',
    () {
      final plan = planCancellations(
        [slot],
        {slot.id},
        DateTime(2026, 10, 26),
        DateTime(2026, 10, 29),
      );
      expect(plan.single.date, '2026-10-28');
      expect(classesOnDate([slot], plan, DateTime(2026, 11, 4)).length, 1);
    },
  );
  CampusNotice source(String body, {String title = '휴강 안내'}) => CampusNotice(
    id: 'n',
    title: title,
    course: slot.course,
    body: body,
    context: {},
  );
  ScheduleCandidate event(String date) => ScheduleCandidate(
    title: '휴강',
    date: date,
    time: '',
    action: 'cancel',
    evidence: '',
    uncertainty: '',
    category: 'class',
  );
  test(
    'Coverage checks each enumerated date, including inherited month and title',
    () {
      final notice = source('10월 26일(월), 28일(수) 수업은 휴강입니다.');
      expect(aiCoverageGaps(notice, [event('2026-10-26')]), ['P1(10/28)']);
      expect(
        aiCoverageGaps(notice, [event('2026-10-26'), event('2026-10-28')]),
        isEmpty,
      );
      expect(aiCoverageGaps(source('상세는 추후 안내합니다.', title: '10월 28일 휴강'), []), [
        'P0(10/28)',
      ]);
    },
  );
  test(
    'Coverage ignores trailing edit date but retains a changed academic deadline and ISO dates',
    () {
      expect(
        aiCoverageGaps(source('과제 제출은 10월 26일까지 (수정 10/28)'), [
          event('2026-10-26'),
        ]),
        isEmpty,
      );
      expect(aiCoverageGaps(source('최종 제출일 수정 10/28'), []), ['P1(10/28)']);
      expect(aiCoverageGaps(source('2026-10-28 수업 휴강'), []), ['P1(10/28)']);
      expect(
        aiCoverageGaps(source('10월 26일 휴강이며 30일 이내에 보강합니다.'), [
          event('2026-10-26'),
        ]),
        isEmpty,
      );
    },
  );
}

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/material_catalog.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/demo_state.dart';
import 'package:campus_radar/tasks/dashboard_model.dart';
import 'package:campus_radar/tasks/mobile_tasks_view.dart';
import 'package:campus_radar/home/modern_task_card.dart';
import 'package:campus_radar/tasks/task_detail_page.dart';
import 'package:campus_radar/courses/courses_page.dart';

void main() {
  setUpAll(() {
    sqfliteFfiInit();
  });

  group('Item 1: AppStorage.excluded with overduePolicy', () {
    test('does not exclude task when extra submission window is active', () async {
      final db = await databaseFactoryFfi.openDatabase(inMemoryDatabasePath);
      await db.execute('CREATE TABLE items (id TEXT PRIMARY KEY, payload TEXT NOT NULL)');
      await db.execute('CREATE TABLE meta (id TEXT PRIMARY KEY, value TEXT NOT NULL)');

      final now = DateTime.now().toUtc();
      final item = CampusItem(
        key: 'LR:c1:01:task1',
        type: 'LR',
        title: '추가 제출 과제',
        course: '테스트과목',
        courseId: 'c1',
        classNo: '01',
        contentsId: 'task1',
        status: 'pending',
        due: now.subtract(const Duration(hours: 2)),
        additionalDue: now.add(const Duration(days: 2)),
        context: {},
      );

      await db.insert('items', {
        'id': item.key,
        'payload': jsonEncode(item.toJson()),
      });
      await db.insert('meta', {'id': 'overduePolicy', 'value': 'immediate'});

      final store = Store(db);
      final excludedSet = await store.excluded();

      expect(
        excludedSet.contains(item.key),
        isFalse,
        reason: '과제가 추가 제출 기간 중이면 overduePolicy=immediate여도 제외되지 않아야 함',
      );
      await db.close();
    });
  });

  group('Item 2: DashboardCounts and dueTodayKst with extra deadline', () {
    test('prioritizes extra deadline task and recognizes dueTodayKst', () {
      final now = DateTime.utc(2026, 11, 10, 5, 0); // KST 14:00
      final todayNightUtc = DateTime.utc(2026, 11, 10, 14, 0); // KST 23:00

      final extraTask = CampusItem(
        key: 'LR:c:1:extra',
        type: 'LR',
        title: '추가 제출 오늘 마감',
        course: '알고리즘',
        courseId: 'c',
        classNo: '1',
        contentsId: 'extra',
        status: 'pending',
        due: now.subtract(const Duration(hours: 3)),
        additionalDue: todayNightUtc,
        context: {},
      );

      final futureTask = CampusItem(
        key: 'LR:c:1:future',
        type: 'LR',
        title: '다음 주 마감 과제',
        course: '운영체제',
        courseId: 'c',
        classNo: '1',
        contentsId: 'future',
        status: 'pending',
        due: now.add(const Duration(days: 7)),
        context: {},
      );

      // 1. dueTodayKst test
      expect(dueTodayKst(extraTask, now), isTrue);

      // 2. DashboardCounts.of test
      final counts = DashboardCounts.of([extraTask, futureTask], {}, now);
      expect(counts.pending.first.key, extraTask.key, reason: '추가 제출 과제가 미래 과제보다 먼저 정렬되어야 함');
      expect(counts.urgent.map((i) => i.key), contains(extraTask.key), reason: '오늘 마감 추가 과제는 긴급 목록에 포함되어야 함');
      expect(counts.today, 1);
    });
  });

  group('Item 3: MobileTasksView shows waiting tasks', () {
    testWidgets('shows waiting assignment when showWaiting is true', (tester) async {
      final now = DateTime.now().toUtc();
      final waitingTask = CampusItem(
        key: 'LR:c:1:waiting',
        type: 'LR',
        title: '제출 대기 테스트 과제',
        course: '테스트과목',
        courseId: 'c',
        classNo: '1',
        contentsId: 'waiting',
        status: 'pending',
        startsAt: now.add(const Duration(days: 2)),
        due: now.add(const Duration(days: 5)),
        published: true,
        context: {},
      );

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: MobileTasksView(
              items: [waitingTask],
              excludedKeys: const {},
              visibilityBusy: const {},
              isBusy: false,
              onRefresh: () {},
              onTaskTap: (_) {},
              onTaskVisibilityToggle: (_) {},
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();

      expect(find.text('제출 대기 테스트 과제'), findsOneWidget);
    });
  });

  group('Item 4: ModernTaskCard isUrgent calculation', () {
    testWidgets('completed overdue task is not urgent', (tester) async {
      final now = DateTime.now();
      final doneOverdueTask = CampusItem(
        key: 'LR:c:1:done',
        type: 'LR',
        title: '완료된 지난 과제',
        course: '과목',
        courseId: 'c',
        classNo: '1',
        contentsId: 'done',
        status: 'done',
        due: now.subtract(const Duration(days: 2)),
        context: {},
      );

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: ModernTaskCard(
              item: doneOverdueTask,
              onTap: () {},
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();

      // Completed task should not display timer_outlined icon
      expect(find.byIcon(Icons.timer_outlined), findsNothing);
    });

    testWidgets('task with 5 days remaining in extra deadline is not urgent', (tester) async {
      final now = DateTime.now();
      final extraTask5Days = CampusItem(
        key: 'LR:c:1:extra5',
        type: 'LR',
        title: '추가 제출 5일 남음',
        course: '과목',
        courseId: 'c',
        classNo: '1',
        contentsId: 'extra5',
        status: 'pending',
        due: now.subtract(const Duration(days: 1)),
        additionalDue: now.add(const Duration(days: 5)),
        context: {},
      );

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: ModernTaskCard(
              item: extraTask5Days,
              onTap: () {},
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();

      expect(find.byIcon(Icons.timer_outlined), findsNothing);
    });
  });

  group('Item 5: MaterialsPage sorting by date across all courses', () {
    testWidgets('sorts by latest date regardless of course name when sortMode is date', (tester) async {
      SharedPreferences.setMockInitialValues({
        'materialsSortMode': 'date',
        'materialsSortDescending': false, // latest first
      });

      // Directly test the list comparator logic as used in MaterialsPage
      final list = [
        StudyMaterial(id: '1', sourceId: '1', sourceType: 'LS', course: '가상현실', title: '옛날 자료', date: DateTime.utc(2026, 9, 1)),
        StudyMaterial(id: '2', sourceId: '2', sourceType: 'LS', course: '컴퓨터구조', title: '최신 자료', date: DateTime.utc(2026, 11, 10)),
      ];

      void sortMaterials(List<StudyMaterial> items, {String? course, required String sortMode, required bool sortDescending}) {
        items.sort((a, b) {
          if (sortMode == 'date') {
            final aDate = a.date ?? DateTime.utc(2000);
            final bDate = b.date ?? DateTime.utc(2000);
            final c = bDate.compareTo(aDate);
            if (c != 0) return sortDescending ? -c : c;
          }
          if (course == null) {
            final c = a.course.compareTo(b.course);
            if (c != 0) return c;
          }
          final t = a.title.compareTo(b.title);
          if (t != 0) return sortDescending ? -t : t;
          final n = a.name.compareTo(b.name);
          return sortDescending ? -n : n;
        });
      }

      sortMaterials(list, course: null, sortMode: 'date', sortDescending: false);
      expect(list.first.title, '최신 자료');
    });
  });

  group('Item 6: CoursePage task sorting with active extra submission', () {
    test('sorts active extra deadline task ahead of past tasks and after near tasks', () {
      final now = DateTime.utc(2026, 11, 10, 5, 0);

      final extraTask = CampusItem(
        key: 'LR:c:1:extra',
        type: 'LR',
        title: '추가 제출 진행 중 과제',
        course: '테스트과목',
        courseId: 'c',
        classNo: '1',
        contentsId: 'extra',
        status: 'pending',
        due: now.subtract(const Duration(days: 1)),
        additionalDue: now.add(const Duration(days: 1)),
        context: {},
      );

      final nextWeekTask = CampusItem(
        key: 'LR:c:1:nextweek',
        type: 'LR',
        title: '다음 주 과제',
        course: '테스트과목',
        courseId: 'c',
        classNo: '1',
        contentsId: 'nextweek',
        status: 'pending',
        due: now.add(const Duration(days: 7)),
        context: {},
      );

      final pastTask = CampusItem(
        key: 'LR:c:1:past',
        type: 'LR',
        title: '마감 지난 과제',
        course: '테스트과목',
        courseId: 'c',
        classNo: '1',
        contentsId: 'past',
        status: 'pending',
        due: now.subtract(const Duration(days: 5)),
        context: {},
      );

      // Testing sorting with effectiveDue:
      final tasks = [pastTask, nextWeekTask, extraTask];
      tasks.sort((a, b) {
        final aEff = effectiveDue(a, now: now);
        final bEff = effectiveDue(b, now: now);
        final aPast = (aEff != null && !aEff.isAfter(now)) || a.done;
        final bPast = (bEff != null && !bEff.isAfter(now)) || b.done;
        if (aPast != bPast) return aPast ? 1 : -1;
        final due = (aEff ?? DateTime.utc(2100)).compareTo(
          bEff ?? DateTime.utc(2100),
        );
        if (due != 0) return due;
        return a.title.compareTo(b.title);
      });

      expect(tasks[0].key, extraTask.key, reason: '내일 마감인 추가 제출 과제가 1순위');
      expect(tasks[1].key, nextWeekTask.key, reason: '다음 주 과제가 2순위');
      expect(tasks[2].key, pastTask.key, reason: '마감 지난 과제는 3순위');
    });
  });

  group('Item 7: Demo mode check in DetailPage and CoursesPage', () {
    testWidgets('DetailPage shows demo message when tapping open campus shortcut in demo mode', (tester) async {
      demoModeNotifier.value = true;
      addTearDown(() => demoModeNotifier.value = false);

      final item = CampusItem(
        key: 'LR:c:1:t',
        type: 'LR',
        title: '테스트 과제',
        course: '과목',
        courseId: 'c',
        classNo: '1',
        contentsId: 't',
        status: 'pending',
        context: {},
      );

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: DetailPage(item: item),
          ),
        ),
      );
      await tester.pumpAndSettle();

      await tester.tap(find.text('사이버캠퍼스 열기'));
      await tester.pumpAndSettle();

      expect(find.text('체험 모드에서는 학교 사이트를 열 수 없어요.'), findsOneWidget);
      expect(find.text('포털을 다시 연결해 주세요.'), findsNothing);
    });

    testWidgets('CoursesPage shows demo message when refreshing courses in demo mode', (tester) async {
      demoModeNotifier.value = true;
      addTearDown(() => demoModeNotifier.value = false);

      await tester.pumpWidget(
        const MaterialApp(
          home: CoursesPage(),
        ),
      );
      await tester.pumpAndSettle();

      await tester.tap(find.byTooltip('학교에서 과목 다시 받기'));
      await tester.pumpAndSettle();

      expect(find.text('체험 모드에서는 학교 사이트를 열 수 없어요.'), findsOneWidget);
      expect(find.textContaining('포털을 먼저 연결해 주세요'), findsNothing);
    });
  });
}

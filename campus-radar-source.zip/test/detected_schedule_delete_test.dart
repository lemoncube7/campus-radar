import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/ai/ai_state_repository.dart';
import 'package:campus_radar/ai/ai_state_models.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/schedule/schedule_repository.dart';
import 'package:campus_radar/schedule/schedule_calendar.dart';
import 'package:campus_radar/schedule/detected_schedules_page.dart';
import 'package:campus_radar/schedule/timetable_page.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory dir;
  late Store store;
  late String key;
  final native = <String>[];
  const channel = MethodChannel('campus_radar/native');
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    FlutterSecureStorage.setMockInitialValues({'id': 'test-account'});
    dir = await Directory.systemTemp.createTemp('radar-detected-delete-');
    await databaseFactory.setDatabasesPath(dir.path);
    store = await Store.open();
    await store.setMeta('sessionEpoch', 'epoch-a');
    final day = DateTime.now().toIso8601String().substring(0, 10);
    final notice = CampusNotice(
      id: 'notice',
      title: '시험 안내',
      course: '예시 과목',
      context: {},
      body: '$day 14:00 중간고사',
    );
    final candidate = ScheduleCandidate(
      title: '중간고사',
      date: day,
      time: '14:00',
      action: 'add',
      evidence: notice.body,
      uncertainty: '',
      category: 'exam',
    );
    key = candidateKey(notice, candidate);
    await store.saveNotice(notice);
    await store.setMeta(
      'aiCache:${notice.id}:${noticeFingerprint(notice)}',
      jsonEncode([candidate.toJson()]),
    );
    await AiStateRepository(store).saveSchedule(
      key,
      ConfirmedSchedule.fromJson({
        'status': 'confirmed',
        'title': '중간고사',
        'date': day,
        'start': '${day}T05:00:00Z',
        'end': '${day}T06:00:00Z',
        'calendarSent': true,
        'approvalMode': 'automatic',
      }),
    );
    native.clear();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (call) async {
          native.add(call.method);
          return call.method == 'timetableSettings'
              ? <String, dynamic>{}
              : null;
        });
  });
  tearDown(() async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, null);
    await store.db.close();
    await dir.delete(recursive: true);
  });
  Future<void> io(WidgetTester t) async {
    for (var n = 0; n < 20; n++) {
      await t.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 30)),
      );
      await t.pump(const Duration(milliseconds: 30));
    }
  }

  test(
    'deleting a confirmed event persists exclusion and keeps source/calendar metadata',
    () async {
      expect(
        (await ScheduleRepository(store).read()).events.single['key'],
        key,
      );
      expect(await ScheduleRepository(store).excludeDetectedEvent(key), true);
      final state = await AiStateRepository(store).schedule(key);
      expect(state.decision, ScheduleDecision.excluded);
      expect(state.isExplicitDecision, true);
      expect(state.calendarSent, true);
      expect(await store.notices(), hasLength(1));
      expect(
        (await ScheduleRepository(store).read()).events.where(
          (r) => (r['state'] as Map)['status'] == 'confirmed',
        ),
        isEmpty,
      );
      expect(await ScheduleRepository(store).excludeDetectedEvent(key), false);
      expect(native, isEmpty);
    },
  );

  test(
    'a stale account session cannot delete another account schedule',
    () async {
      final mark = await SessionMark.capture(store);
      await store.setMeta('sessionEpoch', 'epoch-b');
      await expectLater(
        ScheduleRepository(store).excludeDetectedEvent(key, mark: mark),
        throwsA(isA<SessionChanged>()),
      );
      expect((await AiStateRepository(store).schedule(key)).isConfirmed, true);
    },
  );

  for (final page in <String, Widget>{
    'management': const DetectedSchedulesPage(),
    'calendar': const Scaffold(body: ScheduleCalendar()),
  }.entries) {
    testWidgets(
      '${page.key} exposes delete, cancel preserves it, confirm removes it',
      (t) async {
        await t.pumpWidget(MaterialApp(home: page.value));
        await io(t);
        expect(find.byTooltip('일정 삭제'), findsOneWidget);
        await t.ensureVisible(find.byTooltip('일정 삭제'));
        await t.tap(find.byTooltip('일정 삭제'));
        await t.pumpAndSettle();
        expect(find.textContaining('휴대폰 캘린더로 보낸 일정은 남아요'), findsOneWidget);
        await t.tap(find.text('취소'));
        await t.pumpAndSettle();
        expect(find.byTooltip('일정 삭제'), findsOneWidget);
        await t.tap(find.byTooltip('일정 삭제'));
        await t.pumpAndSettle();
        await t.tap(find.widgetWithText(FilledButton, '삭제'));
        await io(t);
        expect(find.byTooltip('일정 삭제'), findsNothing);
        expect(
          await t.runAsync(
            () async => (await AiStateRepository(store).schedule(key)).decision,
          ),
          ScheduleDecision.excluded,
        );
        expect(native.any((m) => m.startsWith('calendar')), false);
        await t.pumpWidget(const SizedBox.shrink());
      },
    );
  }

  testWidgets(
    'timetable exposes management and existing cancellation removal',
    (t) async {
      await t.pumpWidget(const MaterialApp(home: TimetablePage()));
      await io(t);
      final entry = find.text('감지한 일정·휴강 관리');
      await t.ensureVisible(entry);
      await t.tap(entry);
      await io(t);
      expect(find.text('적용한 휴강 관리'), findsOneWidget);
      await t.tap(find.text('적용한 휴강 관리'));
      await io(t);
      expect(find.text('날짜별 휴강 관리'), findsOneWidget);
      await t.pumpWidget(const SizedBox.shrink());
    },
  );
}

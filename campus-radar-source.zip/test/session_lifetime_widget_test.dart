import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/app_storage.dart';
import 'package:campus_radar/session_lifetime.dart';
import 'package:campus_radar/session_lifetime_card.dart';
import 'package:campus_radar/session_lifetime_repository.dart';

class NoSchoolRequests extends HttpOverrides {
  int calls = 0;
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    calls++;
    throw StateError('The diagnostic screen must not contact school');
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    temp = await Directory.systemTemp.createTemp('lifetime-ui-');
    await databaseFactory.setDatabasesPath(temp.path);
    final store = await Store.open();
    try {
      await store.setMeta('sessionEpoch', 'synthetic');
      final state = SessionLifetime()
        ..maxIdleMs = 1800000
        ..maxAgeMs = 7200000
        ..successes = 3;
      await store.setMeta(
        sessionLifetimeKey,
        jsonEncode({'epoch': 'synthetic', 'state': state.toJson()}),
      );
    } finally {
      await store.db.close();
    }
  });
  tearDown(() async {
    HttpOverrides.global = null;
    await temp.delete(recursive: true);
  });

  testWidgets(
    'Narrow status card shows local observations and handles corrupt history without network',
    (tester) async {
      tester.view.physicalSize = const Size(360, 1600);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final network = NoSchoolRequests();
      HttpOverrides.global = network;
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(child: SessionLifetimeCard()),
          ),
        ),
      );
      for (var i = 0; i < 8; i++) {
        await tester.runAsync(
          () => Future<void>.delayed(const Duration(milliseconds: 20)),
        );
        await tester.pump();
      }
      expect(find.text('앱 요청 없이 재사용: 30분 확인'), findsOneWidget);
      expect(find.text('재로그인 없이 인증 확인: 최소 2시간 0분'), findsOneWidget);
      expect(tester.takeException(), isNull);
      await tester.runAsync(() async {
        final store = await Store.open();
        try {
          await store.setMeta(sessionLifetimeKey, '{broken');
        } finally {
          await store.db.close();
        }
      });
      await tester.tap(find.byTooltip('관측 새로고침'));
      for (var i = 0; i < 8; i++) {
        await tester.runAsync(
          () => Future<void>.delayed(const Duration(milliseconds: 20)),
        );
        await tester.pump();
      }
      expect(find.text('관측 기록을 읽지 못했어요. 학교 연결과 기존 기록은 유지해요.'), findsOneWidget);
      expect(network.calls, 0);
      expect(tester.takeException(), isNull);
    },
  );
}

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/navigation/app_router.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/platform/desktop_update.dart';
import 'package:campus_radar/updates/update_page.dart';
import 'package:campus_radar/updates/app_notices.dart';
import 'package:campus_radar/updates/app_notices_page.dart';
import 'package:campus_radar/updates/release_history.dart';
import 'package:campus_radar/updates/release_history_page.dart';
import 'package:campus_radar/updates/updates.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  setUpAll(() {
    TestWidgetsFlutterBinding.ensureInitialized();
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() {
    SharedPreferences.setMockInitialValues({});
    desktopMethodHandler = null;
  });

  tearDown(() {
    desktopMethodHandler = null;
  });

  group('Bug 2: Windows Update routing', () {
    test('buildAppRoute routes UpdateDestination to DesktopUpdatePage on Windows', () {
      final route = buildAppRoute(
        const RouteSettings(
          name: '/radar/updates',
          arguments: UpdateDestination(),
        ),
        isWindows: true,
      );
      expect(route, isNotNull);
      final widget = (route as MaterialPageRoute).builder(FakeBuildContext());
      expect(widget, isA<DesktopUpdatePage>());
    });

    test('buildAppRoute routes UpdateDestination to UpdatePage on non-Windows', () {
      final route = buildAppRoute(
        const RouteSettings(
          name: '/radar/updates',
          arguments: UpdateDestination(),
        ),
        isWindows: false,
      );
      expect(route, isNotNull);
      final widget = (route as MaterialPageRoute).builder(FakeBuildContext());
      expect(widget, isA<UpdatePage>());
    });
  });

  group('Bug 3: Windows App Notice notification style and support', () {
    test('appNoticeNotificationStyle has WindowsNotificationDetails configured', () {
      expect(appNoticeNotificationStyle.windows, isNotNull);
    });
  });

  group('Bug 4: AppNoticesPage filters ineligible notices', () {
    testWidgets('AppNoticesPage does not display expired or future version notices', (tester) async {
      final json = jsonEncode({
        'schemaVersion': 1,
        'notices': [
          {
            'id': 'eligible-notice',
            'title': '정상 공지',
            'body': '표시되어야 함',
            'publishedAt': '2026-11-10T00:00:00Z',
          },
          {
            'id': 'expired-notice',
            'title': '만료된 공지',
            'body': '표시되면 안 됨',
            'publishedAt': '2026-01-01T00:00:00Z',
            'expiresAt': '2026-01-02T00:00:00Z',
          },
          {
            'id': 'future-build-notice',
            'title': '미래 빌드 공지',
            'body': '표시되면 안 됨',
            'publishedAt': '2026-11-10T00:00:00Z',
            'minVersionCode': 9999,
          },
        ],
      });

      await processAppNotices(
        json,
        currentBuild: 88,
        notifier: (_) async => true,
      );

      await tester.pumpWidget(
        const MaterialApp(
          home: AppNoticesPage(),
        ),
      );
      await tester.pumpAndSettle();

      expect(find.text('정상 공지'), findsOneWidget);
      expect(find.text('만료된 공지'), findsNothing);
      expect(find.text('미래 빌드 공지'), findsNothing);
    });
  });

  group('Bug 5: ReleaseHistoryPage default view with null fromBuild', () {
    testWidgets('shows all history by default when fromBuild is null even if updateHistoryPreviousBuild exists', (tester) async {
      SharedPreferences.setMockInitialValues({
        'updateChannel': 'stable',
        PrefKey.updateHistoryPreviousBuild: 40,
      });

      final repo = ReleaseHistoryRepository(
        bundled: () async => jsonEncode({
          'schemaVersion': 1,
          'releases': [
            {
              'versionName': '0.6.5',
              'versionCode': 88,
              'channel': 'stable',
              'publishedAt': '2026-11-10T00:00:00Z',
              'changes': ['최신 빌드 변경점'],
            },
            {
              'versionName': '0.6.0',
              'versionCode': 35,
              'channel': 'stable',
              'publishedAt': '2026-10-01T00:00:00Z',
              'changes': ['과거 빌드 변경점'],
            },
          ],
        }),
        remote: () async => throw Exception('offline'),
      );

      await tester.pumpWidget(
        MaterialApp(
          home: ReleaseHistoryPage(
            fromBuild: null,
            throughBuild: null,
            repository: repo,
          ),
        ),
      );
      await tester.pumpAndSettle();

      // Both recent and older releases should be visible
      expect(find.textContaining('최신 빌드 변경점'), findsOneWidget);
      expect(find.textContaining('과거 빌드 변경점'), findsOneWidget);
    });
  });

  group('Bug 1 & 8: candidate priority over updateCheckError and cached candidate selection', () {
    test('chooseUpdate selects correct candidate per channel and build', () {
      final stable = {
        'versionName': '0.6.6',
        'versionCode': 89,
        'channel': 'stable',
        'apkUrl': 'https://example.com/stable.apk',
        'sha256': 'a' * 64,
        'notes': '안정 버전',
      };
      final dev = {
        'versionName': '0.6.7-preview',
        'versionCode': 90,
        'channel': 'development',
        'apkUrl': 'https://example.com/dev.apk',
        'sha256': 'b' * 64,
        'notes': '개발 버전',
      };

      // When channel is stable, dev candidate is ignored
      final forStable = chooseUpdate([stable, dev], 'stable', 88);
      expect(forStable?['versionCode'], 89);

      // When channel is development, highest version candidate is chosen
      final forDev = chooseUpdate([stable, dev], 'development', 88);
      expect(forDev?['versionCode'], 90);

      // When already on latest build, returns null
      final upToDate = chooseUpdate([stable, dev], 'development', 91);
      expect(upToDate, isNull);
    });

    test('effectiveUpdateChannel respects installation and preferences', () {
      expect(effectiveUpdateChannel('stable', 'development'), 'stable');
      expect(effectiveUpdateChannel('development', 'development'), 'development');
      expect(effectiveUpdateChannel('development', 'stable'), 'stable');
    });
  });

  group('Bug 9: checkForUpdates calls loadInstalledVersion before processAppNotices', () {
    late Store store;

    setUp(() async {
      final db = await openDatabase(
        inMemoryDatabasePath,
        version: 2,
        onCreate: (db, _) async {
          await db.execute('CREATE TABLE items (id TEXT PRIMARY KEY, payload TEXT NOT NULL)');
          await db.execute('CREATE TABLE meta (id TEXT PRIMARY KEY, value TEXT NOT NULL)');
          await db.execute('CREATE TABLE events (id TEXT PRIMARY KEY, payload TEXT NOT NULL, delivered INTEGER NOT NULL DEFAULT 0)');
          await db.execute('CREATE TABLE notices (id TEXT PRIMARY KEY, payload TEXT NOT NULL)');
          await db.execute('CREATE TABLE logs (id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL, detail TEXT NOT NULL)');
        },
      );
      store = Store(db);
    });

    tearDown(() async {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(
            const MethodChannel('campus_radar/native'),
            null,
          );
      desktopMethodHandler = null;
      installedAppVersion = appVersion;
      installedAppBuild = appBuild;
      await store.db.close();
    });

    test('installed version is loaded before processAppNotices runs', () async {
      final mockVersion = {'name': '0.6.5-custom', 'code': 95};
      desktopMethodHandler = (method, args) async {
        if (method == NativeMethod.versionInfo.name) {
          return mockVersion;
        }
        return null;
      };
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(
            const MethodChannel('campus_radar/native'),
            (call) async {
              if (call.method == NativeMethod.versionInfo.name) {
                return mockVersion;
              }
              return null;
            },
          );

      int? buildSeenInNotices;
      final rawNotices = jsonEncode({
        'schemaVersion': 1,
        'notices': [
          {
            'id': 'build-check-notice',
            'title': '버전 검사',
            'body': '내용',
            'publishedAt': '2026-11-10T00:00:00Z',
          },
        ],
      });

      await checkForUpdates(
        store,
        loader: (channel) async => null,
        noticesLoader: () async => rawNotices,
        noticeNotifier: (notice) async {
          buildSeenInNotices = installedAppBuild;
          return true;
        },
      );

      expect(buildSeenInNotices, 95);
      expect(installedAppBuild, 95);
      expect(installedAppVersion, '0.6.5-custom');
    });
  });
}

class FakeBuildContext extends Fake implements BuildContext {}

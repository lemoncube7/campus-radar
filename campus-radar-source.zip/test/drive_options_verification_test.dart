import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/export/drive_sync.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory dir;
  Map<String, dynamic> persisted = {};
  var dropFreeboard = false;
  final calls = <String>[];
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    dir = await Directory.systemTemp.createTemp('radar-drive-options-');
    await databaseFactory.setDatabasesPath(dir.path);
    persisted = {};
    dropFreeboard = false;
    calls.clear();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(bridge, (MethodCall call) async {
      calls.add(call.method);
      if (call.method == 'driveConfigure') {
        persisted = Map<String, dynamic>.from(call.arguments['options'] as Map);
        if (dropFreeboard) persisted.remove('freeboard');
        return null;
      }
      if (call.method == 'driveAccounts') {
        return [{'id': 'target', 'enabled': true, 'options': jsonEncode(persisted)}];
      }
      return null;
    });
  });
  tearDown(() async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(bridge, null);
    await dir.delete(recursive: true);
  });

  test('saved freeboard scope is read back and logged before export preparation', () async {
    await saveDriveTargetOptions(id: 'target', enabled: true,
        accountHash: 'hash', options: {'freeboard': true, 'courses': []});
    expect(calls, ['driveConfigure', 'driveAccounts']);
    expect(persisted['freeboard'], true);
    final store = await Store.open();
    try {
      final rows = await store.db.query('logs');
      expect(rows.any((r) => r['title'] == 'Drive 전송 범위 저장 완료'), true);
      expect(rows.any((r) => '${r['detail']}'.contains('target')), false);
    } finally { await store.db.close(); }
  });

  test('missing persisted option is a visible failure, not silent success', () async {
    dropFreeboard = true;
    await expectLater(saveDriveTargetOptions(id: 'target', enabled: true,
        accountHash: 'hash', options: {'freeboard': true}), throwsFormatException);
    final store = await Store.open();
    try {
      expect((await store.db.query('logs')).any((r) =>
          r['title'] == 'Drive 전송 범위 저장 확인 실패'), true);
    } finally { await store.db.close(); }
  });

  test('explicit off is persisted and verified too', () async {
    await saveDriveTargetOptions(id: 'target', enabled: true,
        accountHash: 'hash', options: {'freeboard': false});
    expect(persisted['freeboard'], false);
  });
}

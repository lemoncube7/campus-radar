import 'package:campus_radar/ai_protocol.dart';
import 'package:campus_radar/ai_generation.dart';
import 'package:campus_radar/campus_models.dart';
import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/calendar_window.dart';

CampusNotice notice(String body) => CampusNotice(
  id: 'grounding',
  title: '일정 안내',
  course: '예시 과목',
  context: {'student_id': 'PRIVATE_CONTEXT'},
  body: body,
  bodyFetched: true,
  published: DateTime.parse('2026-10-12T19:32:00+09:00'),
);
Map<String, dynamic> event({
  String date = '2026-10-21',
  String time = '13:10',
  List<String> ids = const ['P1'],
  String endDate = '',
  String endTime = '',
  String condition = 'unspecified',
  String category = 'exam',
  String uncertainty = '',
}) => {
  'title': '예시 일정',
  'date': date,
  'time': time,
  'sourceIds': ids,
  'action': 'add',
  'category': category,
  'uncertainty': uncertainty,
  'endDate': endDate,
  'endTime': endTime,
  'condition': condition,
};
Map<String, dynamic> response(List events) => {
  'candidates': [
    {
      'finishReason': 'STOP',
      'content': {
        'parts': [
          {
            'text': jsonEncode({'events': events}),
          },
        ],
      },
    },
  ],
};

void main() {
  test(
    'real-device dotted dates with spaces validate against correct model output',
    () {
      final n = notice('시험일시: 2026. 10. 22.(목) 09:00~10:00 (1시간)');
      final c = parseAiResponse(
        response([
          event(
            date: '2026-10-22',
            time: '09:00',
            endDate: '2026-10-22',
            endTime: '10:00',
          ),
        ]),
        n,
      ).single;
      expect(c.date, '2026-10-22');
      expect(
        () => parseAiResponse(
          response([event(date: '2026-10-23', time: '09:00')]),
          n,
        ),
        throwsA(isA<AiFailure>()),
      );
    },
  );
  test(
    'real-device PM marker carries across a clock range, without accepting the wrong AM value',
    () {
      final n = notice('일시: 10월 19일 오후 3:00 ~ 4:30');
      final c = parseAiResponse(
        response([
          event(
            date: '2026-10-19',
            time: '15:00',
            endDate: '2026-10-19',
            endTime: '16:30',
          ),
        ]),
        n,
      ).single;
      expect(c.endTime, '16:30');
      expect(
        () => parseAiResponse(
          response([
            event(
              date: '2026-10-19',
              time: '15:00',
              endDate: '2026-10-19',
              endTime: '04:30',
            ),
          ]),
          n,
        ),
        throwsA(isA<AiFailure>()),
      );
    },
  );
  final exam = notice(
    '★ 시험:　10월 21일(수요일) 13:10 ~ 14:10\n출석 체크: 13:00\n강의실: 예시관 415호',
  );
  test(
    'paragraph IDs preserve original spacing, range, and nonadjacent evidence through cache roundtrip',
    () {
      final c = parseAiResponse(
        response([
          event(ids: ['P1', 'P3'], endDate: '2026-10-21', endTime: '14:10'),
        ]),
        exam,
      ).single;
      expect(c.evidence, contains('★ 시험:　10월 21일'));
      expect(c.evidence, contains('예시관 415호'));
      expect(c.endInstant, DateTime.parse('2026-10-21T14:10:00+09:00'));
      expect(
        ScheduleCandidate.parse(
          c.toJson(),
          '${exam.title}\n${exam.body}',
        ).toJson(),
        c.toJson(),
      );
    },
  );
  test(
    'reject unknown IDs and changed dates or clocks even with genuine evidence',
    () {
      for (final e in [
        event(ids: ['P999']),
        event(ids: ['P0']),
        event(date: '2026-10-22'),
        event(time: '13:30'),
        event(endDate: '2026-10-21', endTime: '14:30'),
      ]) {
        expect(
          () => parseAiResponse(response([e]), exam),
          throwsA(isA<AiFailure>()),
        );
      }
    },
  );
  test(
    'legacy whitespace normalization accepts formatting but rejects changed facts',
    () {
      final legacy = {...event(), 'evidence': '★ 시험: 10월 21일(수요일) 13:10∼14:10'}
        ..remove('sourceIds');
      expect(parseAiResponse(response([legacy]), exam), hasLength(1));
      expect(
        () => parseAiResponse(
          response([
            {...legacy, 'evidence': '★ 시험: 10월 22일(수요일) 13:10~14:10'},
          ]),
          exam,
        ),
        throwsA(isA<AiFailure>()),
      );
    },
  );
  test(
    'Korean PM, optional conditions and presentation dates survive extraction',
    () {
      final n = notice('자율 팀 구성 희망자는 9월 4일(금) 오후 3시까지 댓글 작성');
      final c = parseAiResponse(
        response([
          event(
            date: '2026-09-04',
            time: '15:00',
            condition: 'conditional',
            category: 'task',
          ),
        ]),
        n,
      ).single;
      expect(c.conditionLabel, contains('해당자만'));
      expect(c.description, contains('희망자는'));
      expect(c.deadline, isTrue);
    },
  );
  test(
    'discard unverified calendar/weekday reasoning rather than present it as advice',
    () {
      final c = parseAiResponse(
        response([event(uncertainty: '실제 달력상 화요일이나 원문에 수요일로 기재됨')]),
        exam,
      ).single;
      expect(c.uncertainty, isEmpty);
    },
  );
  test(
    'request uses only source paragraph IDs and preserves extraction policy',
    () {
      final r = aiRequest(exam);
      final text = jsonEncode(r);
      expect(text, isNot(contains('PRIVATE_CONTEXT')));
      final props =
          r['generationConfig']['responseJsonSchema']['properties']['events']['items']['properties']
              as Map;
      expect(props.containsKey('evidence'), isFalse);
      expect(
        props['sourceIds']['items']['enum'],
        containsAll(['P0', 'P1', 'P2', 'P3']),
      );
      expect(text, contains('선택 제출'));
      expect(text, contains('여러 주차 발표'));
    },
  );
  test(
    'one corrective call fixes grounding and includes exact validation cause',
    () async {
      var calls = 0;
      final invalid = <String>[];
      final r = await analyzeAiWithRepair(
        exam,
        'synthetic',
        transport: (key, request) async {
          calls++;
          if (calls == 2) expect(jsonEncode(request), contains('dateEvidence'));
          return response([
            event(date: calls == 1 ? '2026-10-22' : '2026-10-21'),
          ]);
        },
        onInvalid: (attempt, error, raw) async {
          invalid.add(error.code);
        },
      );
      expect(calls, 2);
      expect(invalid, ['dateEvidence']);
      expect(r.events.single.date, '2026-10-21');
    },
  );
  test(
    'persistent invalid evidence stops after two calls and never becomes a candidate',
    () async {
      var calls = 0;
      await expectLater(
        analyzeAiWithRepair(
          exam,
          'synthetic',
          transport: (key, r) async {
            calls++;
            return response([
              event(ids: ['P999']),
            ]);
          },
        ),
        throwsA(isA<AiFailure>().having((e) => e.code, 'code', 'evidence')),
      );
      expect(calls, 2);
    },
  );
  test('quota and network failures are not automatically repeated', () async {
    for (final code in ['quota', 'network', 'credentials']) {
      var calls = 0;
      await expectLater(
        analyzeAiWithRepair(
          exam,
          'synthetic',
          transport: (key, r) async {
            calls++;
            throw AiFailure('가상 오류', code: code);
          },
        ),
        throwsA(isA<AiFailure>()),
      );
      expect(calls, 1);
    }
  });
  test(
    'missing weekly presentation dates trigger one correction, then visible warning',
    () async {
      final n = notice(
        '초안 제출: 10월 12일 23:59까지 (선택)\n최종 제출: 10월 31일 23:59까지 (필수)\n10주차 11/04 - 발표\n11주차 11/11 - 발표',
      );
      var calls = 0;
      final r = await analyzeAiWithRepair(
        n,
        'synthetic',
        transport: (key, req) async {
          calls++;
          if (calls == 2) expect(jsonEncode(req), contains('P3(11/4)'));
          return response([
            event(
              date: '2026-10-12',
              time: '23:59',
              category: 'task',
              condition: 'optional',
            ),
          ]);
        },
      );
      expect(calls, 2);
      expect(r.events.single.conditionLabel, '선택 사항');
      expect(r.events.single.uncertainty, contains('원문에 추가 일정'));
      expect(r.events.single.uncertainty, contains('11/11'));
    },
  );
  test(
    '23:59 point/deadline windows stay 23:49–23:59 while explicit periods keep their endpoints',
    () {
      final due = DateTime.parse('2026-10-20T23:59:00+09:00');
      for (final deadline in [true, false]) {
        final w = calendarWindow(due, deadline: deadline);
        expect(w.$1, DateTime.parse('2026-10-20T23:49:00+09:00'));
        expect(w.$2, due);
      }
      final start = DateTime.parse('2026-10-20T23:00:00+09:00');
      final end = DateTime.parse('2026-10-21T01:00:00+09:00');
      expect(calendarWindow(start, end: end), (start, end));
    },
  );
}

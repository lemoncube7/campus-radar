import 'package:campus_radar/ai_protocol.dart';
import 'package:campus_radar/campus_models.dart';
import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';

CampusNotice sample({String body = '2026년 10월 20일 오후 3시까지 보고서를 제출하세요.'}) =>
    CampusNotice(
      id: 'example',
      title: '보고서 안내',
      course: '예시 수업',
      context: {'student_id': 'DO_NOT_SEND'},
      body: body,
      bodyFetched: true,
      published: DateTime.utc(2026, 10, 15),
    );
Map<String, dynamic> event({
  String date = '2026-10-20',
  String time = '15:00',
  String evidence = '2026년 10월 20일 오후 3시까지 보고서를 제출하세요.',
  String action = 'add',
}) => {
  'title': '보고서 제출',
  'date': date,
  'time': time,
  'category': 'task',
  'action': action,
  'evidence': evidence,
  'uncertainty': '',
};
Map<String, dynamic> response(List<dynamic> events, {String finish = 'STOP'}) =>
    {
      'candidates': [
        {
          'finishReason': finish,
          'content': {
            'parts': [
              {
                'text': jsonEncode({'events': events}),
              },
            ],
          },
        },
      ],
    };
void main() {
  test('valid evidence and Korean deadline survive schema validation', () {
    final c = parseAiResponse(response([event()]), sample()).single;
    expect(c.date, '2026-10-20');
    expect(c.time, '15:00');
  });
  test('rejects invented source quotations', () {
    expect(
      () => parseAiResponse(response([event(evidence: '원문에 없는 마감')]), sample()),
      throwsA(isA<AiFailure>()),
    );
  });
  test('rejects normalized invalid dates and invalid clock times', () {
    for (final e in [
      event(date: '2026-02-30'),
      event(time: '24:00'),
      event(date: '', time: '15:00'),
    ]) {
      expect(
        () => parseAiResponse(response([e]), sample()),
        throwsA(isA<AiFailure>()),
      );
    }
  });
  test('unknown dates remain empty, cancellation remains non-add', () {
    final c = parseAiResponse(
      response([event(date: '', time: '', action: 'cancel')]),
      sample(),
    ).single;
    expect(c.date, isEmpty);
    expect(c.action, 'cancel');
  });
  test('truncated or blocked responses are never accepted', () {
    expect(
      () =>
          parseAiResponse(response([event()], finish: 'MAX_TOKENS'), sample()),
      throwsA(isA<AiFailure>()),
    );
  });
  test('no-event notice and duplicate events handled', () {
    expect(parseAiResponse(response([]), sample()), isEmpty);
    expect(
      parseAiResponse(response([event(), event()]), sample()),
      hasLength(1),
    );
  });
  test('cache invalidates when source or publication context changes', () {
    expect(
      noticeFingerprint(sample()),
      isNot(noticeFingerprint(sample(body: '다른 본문'))),
    );
  });
  test('request never includes LMS context, credentials or tools', () {
    final request = aiRequest(sample());
    final encoded = jsonEncode(request);
    expect(encoded, isNot(contains('DO_NOT_SEND')));
    expect(request.containsKey('tools'), isFalse);
    expect(request['generationConfig']['responseMimeType'], 'application/json');
  });
  test('date-only validation does not depend on device timezone', () {
    expect(strictDate('2026-10-20'), DateTime.utc(2026, 10, 20));
    expect(strictDate('2026-13-01'), isNull);
  });
}

import 'package:campus_radar/campus/campus_media.dart';
import 'package:campus_radar/campus/material_catalog.dart';
import 'package:flutter_test/flutter_test.dart';

StudyMaterial row(
  String id,
  String source, {
  String body = '',
  String link = '',
  CampusMedia? media,
}) => StudyMaterial(
  id: id,
  sourceId: source,
  sourceType: 'LV',
  title: '1주차',
  course: 'C',
  body: body,
  externalUrl: link,
  media: media,
);

void main() {
  const pdf = CampusMedia(
    name: 'week1.pdf',
    url: 'https://lms.example/file/week1.pdf',
  );
  const ppt = CampusMedia(
    name: 'week1.pptx',
    url: 'https://lms.example/file/9',
  );

  test('body, file and link of one source become one card', () {
    final out = mergedStudyMaterials([
      row('b', 's1', body: '본문 내용'),
      row('f', 's1', media: pdf),
      row('l', 's1', link: 'https://lms.example/file/week1.pdf'),
    ]);
    expect(out, hasLength(1));
    expect(out.single.id, 'f');
    expect(out.single.media, pdf);
    expect(out.single.body, '본문 내용');
    expect(out.single.externalUrl, isEmpty, reason: 'link points at the file');
  });

  test('a link to somewhere else stays on the file card', () {
    final out = mergedStudyMaterials([
      row('f', 's1', media: pdf),
      row('l', 's1', link: 'https://youtube.example/v'),
    ]);
    expect(out.single.externalUrl, 'https://youtube.example/v');
  });

  test('each file keeps its own card; sources stay separate', () {
    final out = mergedStudyMaterials([
      row('b', 's1', body: '본문'),
      row('f1', 's1', media: pdf),
      row('f2', 's1', media: ppt),
      row('b2', 's2', body: '다른 본문'),
      row('l2', 's2', link: 'https://x.example'),
    ]);
    expect(out.map((m) => m.id), ['f1', 'f2', 'b2']);
    expect(out.where((m) => m.body == '본문'), hasLength(2));
    expect(out.last.body, '다른 본문');
    expect(out.last.externalUrl, 'https://x.example');
  });
}

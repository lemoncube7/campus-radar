import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/ai/ai_auto_approval.dart';
import 'package:campus_radar/ai/ai_approval_policy.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/ai/ai_state_models.dart';
import 'package:campus_radar/ai/ai_state_repository.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'package:campus_radar/ai/ai_automation.dart';

const evidence = '2030년 11월 1일 23:59까지 보고서를 제출하세요.';
CampusNotice notice() => CampusNotice(
  id: 'n',
  title: '보고서',
  course: '가상과목',
  context: {'secret': 'never send'},
  body: evidence,
  bodyFetched: true,
);
ScheduleCandidate candidate({
  String action = 'add',
  String uncertainty = '',
  String condition = 'required',
}) => ScheduleCandidate(
  title: '보고서 제출',
  date: '2030-11-01',
  time: '23:59',
  action: action,
  evidence: evidence,
  uncertainty: uncertainty,
  category: 'task',
  condition: condition,
  sourceQuotes: const [evidence],
);
Map<String, dynamic> response(List<Map<String, dynamic>> reviews) => {
  'candidates': [
    {
      'finishReason': 'STOP',
      'content': {
        'parts': [
          {
            'text': jsonEncode({'reviews': reviews}),
          },
        ],
      },
    },
  ],
};
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test(
    'Eligibility rejects uncertain, conditional, changed and past schedules',
    () {
      final now = DateTime.utc(2030, 10, 1);
      expect(eligibleForAutoApproval(notice(), candidate(), now), isTrue);
      for (final c in [
        candidate(action: 'cancel'),
        candidate(action: 'change'),
        candidate(uncertainty: '확인 필요'),
        candidate(condition: 'optional'),
        candidate(condition: 'conditional'),
      ]) {
        expect(eligibleForAutoApproval(notice(), c, now), isFalse);
      }
      expect(
        eligibleForAutoApproval(notice(), candidate(), DateTime.utc(2031)),
        isFalse,
      );
    },
  );
  test(
    'Review payload contains only the target notice and candidates; parser rejects incomplete and fabricated votes',
    () {
      final n = notice(),
          c = candidate(),
          key = candidateKey(notice(), candidate());
      final request = jsonEncode(approvalRequest(n, {key: c}));
      expect(request, isNot(contains('never send')));
      Map<String, dynamic> vote({String? k, String quote = evidence}) => {
        'key': k ?? key,
        'approve': true,
        'reason': '날짜와 마감이 명확함',
        'quote': quote,
      };
      expect(
        parseApprovalResponse(response([vote()]), n, {key})[key]!.approve,
        isTrue,
      );
      for (final rows in [
        <Map<String, dynamic>>[],
        [vote(k: 'unknown')],
        [vote(), vote()],
        [vote(quote: '없는 원문')],
      ]) {
        expect(
          () => parseApprovalResponse(response(rows), n, {key}),
          throwsA(isA<AiFailure>()),
        );
      }
    },
  );
  group('Automatic approval with synthetic transport', () {
    late Store store;
    setUp(() async {
      sqfliteFfiInit();
      SharedPreferences.setMockInitialValues({});
      final db = await databaseFactoryFfiNoIsolate.openDatabase(
        inMemoryDatabasePath,
      );
      await db.execute(
        'CREATE TABLE meta (id TEXT PRIMARY KEY,value TEXT NOT NULL)',
      );
      await db.execute(
        'CREATE TABLE notices (id TEXT PRIMARY KEY,payload TEXT NOT NULL)',
      );
      await db.execute(
        'CREATE TABLE logs (id INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT NOT NULL,kind TEXT NOT NULL,title TEXT NOT NULL,detail TEXT NOT NULL)',
      );
      store = Store(db);
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(
            const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
            (call) async => call.method == 'read' ? 'synthetic-test-key' : null,
          );
      await store.saveNotice(notice());
      await store.setAiSetting(AiSetting.aiConsent, aiConsentVersion);
      await store.setAiSetting(AiSetting.aiAutoApprove, 'yes');
    });
    tearDown(() async {
      desktopMethodHandler = null;
      await store.db.close();
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(
            const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
            null,
          );
    });
    Future<Map<String, dynamic>> approve(
      String key,
      Map<String, dynamic> body,
    ) async {
      final payload =
          jsonDecode(body['contents'][0]['parts'][0]['text']) as Map;
      final rows = (payload['candidates'] as List)
          .map(
            (c) => <String, dynamic>{
              'key': c['key'],
              'approve': true,
              'reason': '명확한 날짜·마감',
              'quote': evidence,
            },
          )
          .toList();
      return response(rows);
    }

    test(
      'Approves clear add candidate automatically without second review LLM call and preserves metadata',
      () async {
        var calls = 0;
        Future<Map<String, dynamic>> transport(
          String key,
          Map<String, dynamic> body,
        ) async {
          calls++;
          return approve(key, body);
        }

        await autoApproveNotice(
          store,
          notice(),
          [candidate()],
          transport: transport,
          beforeRequest: () async {},
        );
        final key = candidateKey(notice(), candidate());
        final state = await AiStateRepository(store).schedule(key);
        expect(state.isConfirmed, isTrue);
        expect(state.toJson()['approvalMode'], 'automatic');
        expect(state.calendarSent, isFalse);
        // Second review LLM call is omitted to save request budget and tokens
        expect(calls, 0);

        // Calling again does not re-process already confirmed schedule
        await autoApproveNotice(
          store,
          notice(),
          [candidate()],
          transport: transport,
          beforeRequest: () async {},
        );
        expect(calls, 0);
      },
    );
    test('Auto approve defaults to on when AI consent is granted, off when no', () async {
      expect(await isAutoApproveEnabled(store), isTrue);
      await store.setAiSetting(AiSetting.aiAutoApprove, 'no');
      expect(await isAutoApproveEnabled(store), isFalse);

      final key = candidateKey(notice(), candidate());
      await autoApproveNotice(
        store,
        notice(),
        [candidate()],
        beforeRequest: () async {},
      );
      expect((await AiStateRepository(store).schedule(key)).toJson(), isEmpty);

      // Re-enable (or delete setting so it defaults to true)
      await store.setAiSetting(AiSetting.aiAutoApprove, 'yes');
      expect(await isAutoApproveEnabled(store), isTrue);
    });
    test('Automatically applies clear class cancellation to timetable cancellations', () async {
      await store.setMeta(
        'timetableEntries',
        jsonEncode([
          {
            'id': 'slot1',
            'course': '가상과목',
            'courseKey': 'c:1',
            'weekday': 5, // 2030-11-01 is Friday
            'start': 540,
            'end': 630,
            'room': '101호',
          },
        ]),
      );
      const cancelEvidence = '2030년 11월 1일 09:00 가상과목 수업은 휴강입니다.';
      final cancelNotice = CampusNotice(
        id: 'n_cancel',
        title: '휴강 공지',
        course: '가상과목',
        context: {'secret': 'never send'},
        body: cancelEvidence,
        bodyFetched: true,
      );
      await store.saveNotice(cancelNotice);
      final cancelCand = ScheduleCandidate(
        title: '가상과목 휴강',
        date: '2030-11-01',
        time: '09:00',
        action: 'cancel',
        evidence: cancelEvidence,
        uncertainty: '',
        category: 'class',
        condition: 'unspecified',
        sourceQuotes: const [cancelEvidence],
      );
      final key = candidateKey(cancelNotice, cancelCand);
      await autoApproveNotice(
        store,
        cancelNotice,
        [cancelCand],
        beforeRequest: () async {},
      );
      final state = await AiStateRepository(store).schedule(key);
      expect(state.toJson()['status'], 'excluded');
      expect(state.toJson()['resolution'], 'classCancellationApplied');
      expect(state.toJson()['approvalMode'], 'automatic');

      // Check cancellation was saved in timetable cancellations with notice details
      final rawCanc = await store.meta('timetableCancellations');
      expect(rawCanc, isNotNull);
      final list = jsonDecode(rawCanc!) as List;
      expect(list.length, 1);
      expect(list.first['slotId'], 'c:1:5:540');
      expect(list.first['date'], '2030-11-01');
      expect(list.first['noticeId'], 'n_cancel');
      expect(list.first['noticeTitle'], '휴강 공지');
    });
    test(
      'Explicit hold and edits are never overwritten or sent for review',
      () async {
        final key = candidateKey(notice(), candidate());
        await AiStateRepository(store).saveSchedule(
          key,
          ConfirmedSchedule.fromJson({'status': 'hold', 'title': '직접 수정'}),
        );
        await autoApproveNotice(
          store,
          notice(),
          [candidate()],
          transport: (k, b) async => throw StateError('must not send'),
          beforeRequest: () async {},
        );
        expect((await AiStateRepository(store).schedule(key)).toJson(), {
          'status': 'hold',
          'title': '직접 수정',
        });
      },
    );
    test(
      'Ineligible candidate retains unapproved candidate, never confirms',
      () async {
        final uncertainCand = candidate(uncertainty: '시간 미정');
        await autoApproveNotice(
          store,
          notice(),
          [uncertainCand],
          beforeRequest: () async {},
        );
        expect(
          (await AiStateRepository(
            store,
          ).schedule(candidateKey(notice(), uncertainCand))).toJson(),
          isEmpty,
        );
      },
    );
    test('Calendar permission failure retains local approval', () async {
      await store.setMeta('aiCalendarDefault', 'yes');
      desktopMethodHandler = (method, args) async => false;
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(
            const MethodChannel('campus_radar/native'),
            (call) async => false,
          );
      try {
        await autoApproveNotice(
          store,
          notice(),
          [candidate()],
          transport: approve,
          beforeRequest: () async {},
        );
        final state = await AiStateRepository(
          store,
        ).schedule(candidateKey(notice(), candidate()));
        expect(state.isConfirmed, isTrue);
        expect(state.calendarSent, isFalse);
      } finally {
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(
              const MethodChannel('campus_radar/native'),
              null,
            );
      }
    });
    test(
      'Ineligible candidate with uncertainty or conditional action is never approved automatically',
      () async {
        final uncertainCand = candidate(uncertainty: '확인 필요');
        final keyUncertain = candidateKey(notice(), uncertainCand);
        await autoApproveNotice(
          store,
          notice(),
          [uncertainCand],
          beforeRequest: () async {},
        );
        expect(
          (await AiStateRepository(store).schedule(keyUncertain)).toJson(),
          isEmpty,
        );

        final condCand = candidate(condition: 'conditional');
        final keyCond = candidateKey(notice(), condCand);
        await autoApproveNotice(
          store,
          notice(),
          [condCand],
          beforeRequest: () async {},
        );
        expect(
          (await AiStateRepository(store).schedule(keyCond)).toJson(),
          isEmpty,
        );
      },
    );
    test('ClassCancellation serialization and legacy backward compatibility', () {
      const legacyJson =
          '[{"id":"2030-11-01:slot1","slotId":"slot1","date":"2030-11-01","course":"가상과목","source":"휴강 공지"}]';
      final parsedLegacy = decodeCancellations(legacyJson);
      expect(parsedLegacy.length, 1);
      expect(parsedLegacy.first.id, '2030-11-01:slot1');
      expect(parsedLegacy.first.noticeId, '');
      expect(parsedLegacy.first.noticeTitle, '휴강 공지');

      final canc = ClassCancellation(
        '2030-11-01:slot1',
        'slot1',
        '2030-11-01',
        '가상과목',
        '공지 제목',
        noticeId: 'n123',
        noticeTitle: '공지 제목',
      );
      final json = canc.toJson();
      expect(json['noticeId'], 'n123');
      expect(json['noticeTitle'], '공지 제목');

      final parsedNew = decodeCancellations(jsonEncode([json]));
      expect(parsedNew.length, 1);
      expect(parsedNew.first.noticeId, 'n123');
      expect(parsedNew.first.noticeTitle, '공지 제목');
    });
    test(
      'Definite Empty Status: does not re-enqueue when fingerprint matches, re-enqueues on body change',
      () async {
        await store.setMeta('aiAuto', 'yes');
        await store.setMeta('aiScope', 'all');
        final repo = AiStateRepository(store);
        final fp = noticeFingerprint(notice());
        await repo.saveJob(
          notice().id,
          AiJob.fromJson({
            'status': 'empty',
            'fingerprint': fp,
            'title': notice().title,
          }),
        );

        // Enqueueing same notice with same body should be skipped
        await enqueueNotices(store);
        var job = await repo.job(notice().id);
        expect(job.status, AiJobStatus.empty);

        // If notice body changes, fingerprint changes -> re-enqueue as pending
        final updatedNotice = CampusNotice(
          id: notice().id,
          title: notice().title,
          course: notice().course,
          context: notice().context,
          body: '2030년 11월 10일 휴강입니다.',
          bodyFetched: true,
        );
        expect(noticeFingerprint(updatedNotice), isNot(fp));
        await store.saveNotice(updatedNotice);

        await enqueueNotices(store);
        job = await repo.job(notice().id);
        expect(job.status, AiJobStatus.pending);
        expect(job.fingerprint, noticeFingerprint(updatedNotice));
      },
    );
  });
}

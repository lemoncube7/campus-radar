import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/ai_auto_approval.dart';
import 'package:campus_radar/ai_approval_policy.dart';
import 'package:campus_radar/ai_protocol.dart';
import 'package:campus_radar/ai_state_models.dart';
import 'package:campus_radar/ai_state_repository.dart';
import 'package:campus_radar/app_storage.dart';
import 'package:campus_radar/campus_models.dart';
import 'package:campus_radar/native_bridge.dart';

const evidence = '2030년 11월 1일 23:59까지 보고서를 제출하세요.';
CampusNotice notice() => CampusNotice(
  id: 'n',
  title: '보고서',
  course: '가상과목',
  context: {'secret': 'never send'},
  body: evidence,
  bodyFetched: true,
);
ScheduleCandidate candidate({
  String action = 'add',
  String uncertainty = '',
  String condition = 'required',
}) => ScheduleCandidate(
  title: '보고서 제출',
  date: '2030-11-01',
  time: '23:59',
  action: action,
  evidence: evidence,
  uncertainty: uncertainty,
  category: 'task',
  condition: condition,
  sourceQuotes: const [evidence],
);
Map<String, dynamic> response(List<Map<String, dynamic>> reviews) => {
  'candidates': [
    {
      'finishReason': 'STOP',
      'content': {
        'parts': [
          {
            'text': jsonEncode({'reviews': reviews}),
          },
        ],
      },
    },
  ],
};
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test(
    'Eligibility rejects uncertain, conditional, changed and past schedules',
    () {
      final now = DateTime.utc(2030, 10, 1);
      expect(eligibleForAutoApproval(notice(), candidate(), now), isTrue);
      for (final c in [
        candidate(action: 'cancel'),
        candidate(action: 'change'),
        candidate(uncertainty: '확인 필요'),
        candidate(condition: 'optional'),
        candidate(condition: 'conditional'),
      ]) {
        expect(eligibleForAutoApproval(notice(), c, now), isFalse);
      }
      expect(
        eligibleForAutoApproval(notice(), candidate(), DateTime.utc(2031)),
        isFalse,
      );
    },
  );
  test(
    'Review payload contains only the target notice and candidates; parser rejects incomplete and fabricated votes',
    () {
      final n = notice(),
          c = candidate(),
          key = candidateKey(notice(), candidate());
      final request = jsonEncode(approvalRequest(n, {key: c}));
      expect(request, isNot(contains('never send')));
      Map<String, dynamic> vote({String? k, String quote = evidence}) => {
        'key': k ?? key,
        'approve': true,
        'reason': '날짜와 마감이 명확함',
        'quote': quote,
      };
      expect(
        parseApprovalResponse(response([vote()]), n, {key})[key]!.approve,
        isTrue,
      );
      for (final rows in [
        <Map<String, dynamic>>[],
        [vote(k: 'unknown')],
        [vote(), vote()],
        [vote(quote: '없는 원문')],
      ]) {
        expect(
          () => parseApprovalResponse(response(rows), n, {key}),
          throwsA(isA<AiFailure>()),
        );
      }
    },
  );
  group('Automatic approval with synthetic transport', () {
    late Store store;
    setUp(() async {
      sqfliteFfiInit();
      SharedPreferences.setMockInitialValues({});
      final db = await databaseFactoryFfiNoIsolate.openDatabase(
        inMemoryDatabasePath,
      );
      await db.execute(
        'CREATE TABLE meta (id TEXT PRIMARY KEY,value TEXT NOT NULL)',
      );
      await db.execute(
        'CREATE TABLE notices (id TEXT PRIMARY KEY,payload TEXT NOT NULL)',
      );
      await db.execute(
        'CREATE TABLE logs (id INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT NOT NULL,kind TEXT NOT NULL,title TEXT NOT NULL,detail TEXT NOT NULL)',
      );
      store = Store(db);
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(
            const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
            (call) async => call.method == 'read' ? 'synthetic-test-key' : null,
          );
      await store.saveNotice(notice());
      await store.setAiSetting(AiSetting.aiConsent, aiConsentVersion);
      await store.setAiSetting(AiSetting.aiAutoApprove, 'yes');
    });
    tearDown(() async {
      desktopMethodHandler = null;
      await store.db.close();
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(
            const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
            null,
          );
    });
    Future<Map<String, dynamic>> approve(
      String key,
      Map<String, dynamic> body,
    ) async {
      final payload =
          jsonDecode(body['contents'][0]['parts'][0]['text']) as Map;
      final rows = (payload['candidates'] as List)
          .map(
            (c) => <String, dynamic>{
              'key': c['key'],
              'approve': true,
              'reason': '명확한 날짜·마감',
              'quote': evidence,
            },
          )
          .toList();
      return response(rows);
    }

    test(
      'Approves once, preserves metadata and does not call again for confirmed events',
      () async {
        var calls = 0;
        Future<Map<String, dynamic>> transport(
          String key,
          Map<String, dynamic> body,
        ) async {
          calls++;
          return approve(key, body);
        }

        await autoApproveNotice(
          store,
          notice(),
          [candidate()],
          transport: transport,
          beforeRequest: () async {},
        );
        final key = candidateKey(notice(), candidate());
        final state = await AiStateRepository(store).schedule(key);
        expect(state.isConfirmed, isTrue);
        expect(state.toJson()['approvalMode'], 'automatic');
        expect(state.calendarSent, isFalse);
        await autoApproveNotice(
          store,
          notice(),
          [candidate()],
          transport: transport,
          beforeRequest: () async {},
        );
        expect(calls, 1);
      },
    );
    test(
      'Explicit hold and edits are never overwritten or sent for review',
      () async {
        final key = candidateKey(notice(), candidate());
        await AiStateRepository(store).saveSchedule(
          key,
          ConfirmedSchedule.fromJson({'status': 'hold', 'title': '직접 수정'}),
        );
        await autoApproveNotice(
          store,
          notice(),
          [candidate()],
          transport: (k, b) async => throw StateError('must not send'),
          beforeRequest: () async {},
        );
        expect((await AiStateRepository(store).schedule(key)).toJson(), {
          'status': 'hold',
          'title': '직접 수정',
        });
      },
    );
    test(
      'Failed review retains unapproved candidate, never confirms',
      () async {
        await autoApproveNotice(
          store,
          notice(),
          [candidate()],
          transport: (k, b) async =>
              throw const AiFailure('quota', code: 'quota'),
          beforeRequest: () async {},
        );
        expect(
          (await AiStateRepository(
            store,
          ).schedule(candidateKey(notice(), candidate()))).toJson(),
          isEmpty,
        );
        expect(
          (await store.logs('all')).any((r) => r['title'] == 'AI 자동 승인 대기'),
          isTrue,
        );
      },
    );
    test('Turning off during response prevents approval', () async {
      await autoApproveNotice(
        store,
        notice(),
        [candidate()],
        transport: (k, b) async {
          await store.setAiSetting(AiSetting.aiAutoApprove, 'no');
          return approve(k, b);
        },
        beforeRequest: () async {},
      );
      expect(
        (await AiStateRepository(
          store,
        ).schedule(candidateKey(notice(), candidate()))).toJson(),
        isEmpty,
      );
    });
    test('Calendar permission failure retains local approval', () async {
      await store.setMeta('aiCalendarDefault', 'yes');
      desktopMethodHandler = (method, args) async => false;
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(
            const MethodChannel('campus_radar/native'),
            (call) async => false,
          );
      try {
        await autoApproveNotice(
          store,
          notice(),
          [candidate()],
          transport: approve,
          beforeRequest: () async {},
        );
        final state = await AiStateRepository(
          store,
        ).schedule(candidateKey(notice(), candidate()));
        expect(state.isConfirmed, isTrue);
        expect(state.calendarSent, isFalse);
      } finally {
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(
              const MethodChannel('campus_radar/native'),
              null,
            );
      }
    });
    test(
      'Negative review is retained without repeating the same request',
      () async {
        var calls = 0;
        Future<Map<String, dynamic>> reject(
          String key,
          Map<String, dynamic> body,
        ) async {
          calls++;
          return response([
            {
              'key': candidateKey(notice(), candidate()),
              'approve': false,
              'reason': '시각 근거 재확인 필요',
              'quote': '',
            },
          ]);
        }

        await autoApproveNotice(
          store,
          notice(),
          [candidate()],
          transport: reject,
          beforeRequest: () async {},
        );
        await autoApproveNotice(
          store,
          notice(),
          [candidate()],
          transport: reject,
          beforeRequest: () async {},
        );
        expect(calls, 1);
        final key = candidateKey(notice(), candidate());
        expect(
          (await AiStateRepository(store).schedule(key)).toJson(),
          isEmpty,
        );
        expect(
          jsonDecode((await store.meta('aiApproval:$key'))!)['reason'],
          '시각 근거 재확인 필요',
        );
      },
    );
    test('Notice edited while review is running cannot be approved', () async {
      await autoApproveNotice(
        store,
        notice(),
        [candidate()],
        transport: (key, body) async {
          await store.saveNotice(
            CampusNotice(
              id: 'n',
              title: '보고서',
              course: '가상과목',
              context: {},
              body: '공지 변경됨',
              bodyFetched: true,
            ),
          );
          return approve(key, body);
        },
        beforeRequest: () async {},
      );
      expect(
        (await AiStateRepository(
          store,
        ).schedule(candidateKey(notice(), candidate()))).toJson(),
        isEmpty,
      );
    });
  });
}

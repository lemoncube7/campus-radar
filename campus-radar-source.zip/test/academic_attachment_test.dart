import 'dart:convert';
import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/campus/academic_attachment.dart';
import 'package:campus_radar/export/academic_export.dart';
import 'package:campus_radar/campus/campus_media.dart';

List<int> doc(String path, String xml) {
  final a = Archive()..addFile(ArchiveFile.string(path, xml));
  return ZipEncoder().encode(a);
}

void main() {
  test('plain UTF8 and Office XML text is extracted locally', () {
    expect(
      extractAttachmentBytes(utf8.encode('과제 범위\n안내'), 'txt').text,
      contains('과제 범위'),
    );
    final ppt = extractAttachmentBytes(
      doc(
        'ppt/slides/slide1.xml',
        '<p:sld xmlns:p="p" xmlns:a="a"><a:p><a:r><a:t>시험 범위</a:t></a:r></a:p></p:sld>',
      ),
      'pptx',
    );
    expect(ppt.text, contains('시험 범위'));
    final hwp = extractAttachmentBytes(
      doc(
        'Contents/section0.xml',
        '<hs:sec xmlns:hs="hs" xmlns:hp="hp"><hp:p><hp:t>휴강 안내</hp:t></hp:p></hs:sec>',
      ),
      'hwpx',
    );
    expect(hwp.text, contains('휴강 안내'));
  });
  test(
    'unsupported binary malformed text and large XML report limitations',
    () {
      expect(extractAttachmentBytes([0, 1, 2], 'hwp').text, isEmpty);
      expect(extractAttachmentBytes([255, 255], 'txt').text, isEmpty);
      final oversized = extractAttachmentBytes(
        doc('Contents/section0.xml', 'x' * (1024 * 1024 + 1)),
        'hwpx',
      );
      expect(oversized.partial, isTrue);
      expect(oversized.text, isEmpty);
    },
  );
  test('download bytes must match type not just HTTP200', () {
    expect(
      isAttachmentBytes(
        utf8.encode('<html>login</html>'),
        'a.pdf',
        'text/html',
      ),
      isFalse,
    );
    expect(
      isAttachmentBytes(utf8.encode('%PDF-1.7'), 'a.pdf', 'application/pdf'),
      isTrue,
    );
    expect(
      isAttachmentBytes(
        utf8.encode('%PDF-1.7'),
        'a.pdf?version=2',
        'application/pdf',
      ),
      isTrue,
    );
    expect(
      isAttachmentBytes(
        utf8.encode('{"error":401}'),
        'a.txt',
        'application/json',
      ),
      isFalse,
    );
  });
  test('only known direct school links without auth query are exported', () {
    expect(
      directAcademicUrl(
        const CampusMedia(
          name: 'a.pdf',
          url: 'https://dcs-learning.cnu.ac.kr/file/a.pdf',
        ),
      ),
      isNotNull,
    );
    expect(
      directAcademicUrl(
        const CampusMedia(name: 'a.pdf', url: 'https://evil.test/a.pdf'),
      ),
      isNull,
    );
    expect(
      directAcademicUrl(
        const CampusMedia(
          name: 'a.pdf',
          url: 'https://dcs-learning.cnu.ac.kr/a.pdf?token=secret',
        ),
      ),
      isNull,
    );
    expect(
      directAcademicUrl(
        const CampusMedia(
          name: 'a.pdf',
          url: 'https://dcs-lcms.cnu.ac.kr/api/v1/share/downloadFile',
          form: {'file_no': 'private'},
        ),
      ),
      isNull,
    );
  });
  test('Markdown and explicitly selected original survive ZIP roundtrip', () {
    const id = '0123456789abcdef0123456789abcdef';
    final bundle = packAcademicDocuments(
      profileId: id,
      at: DateTime.utc(2026, 11, 2),
      collectedAt: null,
      documents: {'과목/예시.md': '# 수업\n내용'},
      originals: {'원본/0123456789abcdef.pdf': utf8.encode('%PDF-demo')},
    );
    final zip = ZipDecoder().decodeBytes(bundle.zip());
    expect(zip.findFile('과목/예시.md'), isNotNull);
    expect(
      utf8.decode(zip.findFile('원본/0123456789abcdef.pdf')!.content),
      startsWith('%PDF'),
    );
    final index = jsonDecode(
      bundle.documents['캠퍼스레이더 시작.txt']!.split('\n').skip(1).join('\n'),
    );
    expect(index['originalFiles'], hasLength(1));
  });
  test('original path traversal and oversized original are refused', () {
    const id = '0123456789abcdef0123456789abcdef';
    expect(
      () => packAcademicDocuments(
        profileId: id,
        at: DateTime.now(),
        collectedAt: null,
        documents: {},
        originals: {
          '../x.pdf': [1],
        },
      ),
      throwsFormatException,
    );
    expect(
      () => packAcademicDocuments(
        profileId: id,
        at: DateTime.now(),
        collectedAt: null,
        documents: {},
        originals: {
          '원본/0123456789abcdef.pdf': List.filled(10 * 1024 * 1024 + 1, 0),
        },
      ),
      throwsFormatException,
    );
  });
}

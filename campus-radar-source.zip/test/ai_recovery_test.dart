import 'package:campus_radar/app_router.dart';
import 'package:campus_radar/ai_inbox_page.dart';
import 'package:campus_radar/calendar_draft_page.dart';
import 'package:campus_radar/ai_protocol.dart';
import 'package:campus_radar/notice_ai_service.dart';
import 'package:campus_radar/app_storage.dart';
import 'package:campus_radar/campus_models.dart';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/ai_automation.dart';
import 'package:campus_radar/ai_recovery.dart';
import 'package:campus_radar/ai_recovery_page.dart';

CampusNotice notice(
  String id, {
  String course = 'a',
  String body = '10월 20일 보고서를 제출하세요.',
}) => CampusNotice(
  id: id,
  title: '$id 보고서 안내',
  course: '예시 과목',
  context: {
    'course_id': course,
    'class_no': '1',
    'student_id': 'PRIVATE_CONTEXT',
  },
  body: body,
  bodyFetched: true,
);
Map<String, dynamic> event(String evidence) => {
  'title': '보고서 제출',
  'date': '2026-10-20',
  'time': '',
  'category': 'task',
  'action': 'add',
  'evidence': evidence,
  'uncertainty': '',
};
Map<String, dynamic> response(List events) => {
  'candidates': [
    {
      'finishReason': 'STOP',
      'content': {
        'parts': [
          {
            'text': jsonEncode({'events': events}),
          },
        ],
      },
    },
  ],
};

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory directory;
  setUp(() async {
    directory = await Directory.systemTemp.createTemp('recovery046-');
    await databaseFactory.setDatabasesPath(directory.path);
    SharedPreferences.setMockInitialValues({});
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          (call) async => call.method == 'read' ? 'synthetic-key' : null,
        );
    final store = await Store.open();
    await store.setMeta('aiConsent', aiConsentVersion);
    await store.setMeta('aiAuto', 'yes');
    await store.setMeta('aiScope', 'all');
    await store.saveNotice(notice('target'));
    await store.saveNotice(notice('related'));
    await store.saveNotice(
      notice('other', course: 'b', body: 'OTHER_COURSE_PRIVATE'),
    );
    await store.setMeta(
      'coursePlan:a:1',
      jsonEncode({
        'linkedText': '수업 화 09:00, 보고서 평가 안내',
        'fetchedAt': '2026-10-01T00:00:00Z',
        'data': {'student': 'PRIVATE_PLAN_RESPONSE'},
      }),
    );
    await store.db.close();
  });
  tearDown(() async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          null,
        );
    await directory.delete(recursive: true);
  });

  test(
    'Title-only schedule reaches analysis and grounds P0 with empty fetched body',
    () async {
      final n = CampusNotice(
        id: 'title-only',
        title: '2026년 11월 9일 13:00 시험 안내',
        course: '가상 과목',
        context: {'course_id': 'title', 'class_no': '1'},
        body: '',
        bodyFetched: true,
      );
      var calls = 0;
      final result = await NoticeAi.analyze(
        n,
        force: true,
        transport: (key, request) async {
          calls++;
          final payload =
              jsonDecode(request['contents'][0]['parts'][0]['text'] as String)
                  as Map;
          expect((payload['sourceParagraphs'] as List).single['id'], 'P0');
          return response([
            {
              'title': '시험',
              'date': '2026-11-09',
              'time': '13:00',
              'category': 'exam',
              'action': 'add',
              'sourceIds': ['P0'],
              'uncertainty': '',
              'condition': 'required',
            },
          ]);
        },
      );
      expect(calls, 1);
      expect(result.single.evidence, n.title);
      expect(result.single.date, '2026-11-09');
      final store = await Store.open();
      try {
        expect(
          await store.meta('aiCache:${n.id}:${noticeFingerprint(n)}'),
          isNotNull,
        );
      } finally {
        await store.db.close();
      }
    },
  );

  test(
    'Recovery context selects only same class; preview excludes portal metadata and unselected plan',
    () async {
      final store = await Store.open();
      try {
        final data = await recoveryContext(store, notice('target'));
        expect(data.notices, hasLength(1));
        expect(data.syllabus, contains('화 09:00'));
        final encoded = data.selected(
          includeNotices: true,
          includeItems: true,
          includePlan: false,
        );
        expect(encoded, isNot(contains('OTHER_COURSE_PRIVATE')));
        expect(encoded, isNot(contains('PRIVATE_CONTEXT')));
        expect(encoded, isNot(contains('PRIVATE_PLAN_RESPONSE')));
        expect(encoded, isNot(contains('화 09:00')));
        final included = data.selected(
          includeNotices: false,
          includeItems: false,
          includePlan: true,
        );
        expect(included, contains('화 09:00'));
        expect(included, isNot(contains('related 보고서 안내')));
      } finally {
        await store.db.close();
      }
    },
  );

  test(
    'Validation identifies invented evidence independently of unsupported category; legacy remains uncertain',
    () {
      expect(
        () => ScheduleCandidate.parse(
          event('존재하지 않는 인용문'),
          notice('target').body,
        ),
        throwsA(isA<AiFailure>().having((e) => e.code, 'code', 'evidence')),
      );
      expect(
        () => ScheduleCandidate.parse({
          ...event('보고서'),
          'category': 'invalid',
        }, notice('target').body),
        throwsA(isA<AiFailure>().having((e) => e.code, 'code', 'category')),
      );
      expect(
        recoveryCode({'error': '원문 근거 또는 일정 유형을 검증하지 못했습니다.'}),
        'legacy_validation',
      );
    },
  );

  test(
    'Supplemental request passes selected context and failure reason but still rejects evidence from other notice',
    () async {
      final store = await Store.open();
      final extra = (await recoveryContext(
        store,
        notice('target'),
      )).selected(includeNotices: true, includeItems: false, includePlan: true);
      await store.db.close();
      var called = false;
      await expectLater(
        NoticeAi.analyze(
          notice('target'),
          force: true,
          supplemental: extra,
          repairHint: 'evidence 오류',
          transport: (key, request) async {
            called = true;
            final encoded = jsonEncode(request);
            expect(encoded, contains('supportingContext'));
            expect(encoded, contains('evidence 오류'));
            expect(encoded, isNot(contains('PRIVATE_CONTEXT')));
            return response([event('참고 자료에만 존재하는 문장')]);
          },
        ),
        throwsA(isA<AiFailure>().having((e) => e.code, 'code', 'evidence')),
      );
      expect(called, isTrue);
      final verify = await Store.open();
      expect(
        await verify.meta(
          'aiCache:target:${noticeFingerprint(notice('target'))}',
        ),
        isNull,
      );
      await verify.db.close();
    },
  );

  test(
    'Excluded notice does not return to pending on next collection; changed notice can re-enter',
    () async {
      final store = await Store.open();
      try {
        await excludeNoticeAnalysis(store, notice('target'));
        await enqueueNotices(store);
        expect(
          jsonDecode((await store.meta('aiQueue:target'))!)['status'],
          'excluded',
        );
        await store.saveNotice(notice('target', body: '새로운 일정으로 변경됐습니다.'));
        await enqueueNotices(store);
        expect(
          jsonDecode((await store.meta('aiQueue:target'))!)['status'],
          'pending',
        );
      } finally {
        await store.db.close();
      }
    },
  );
  test(
    'Prompt upgrade keeps manual/excluded decisions for unchanged source',
    () async {
      final s = await Store.open();
      try {
        await s.setMeta(
          'aiQueue:target',
          jsonEncode({
            'status': 'excluded',
            'fingerprint': noticeFingerprint(
              notice('target'),
              promptVersion: '2',
            ),
          }),
        );
        await enqueueNotices(s);
        expect(
          jsonDecode((await s.meta('aiQueue:target'))!)['status'],
          'excluded',
        );
      } finally {
        await s.db.close();
      }
    },
  );
  test(
    'Reanalysis preserves candidate keys, decisions and calendar links when source quotations change',
    () async {
      final s = await Store.open();
      try {
        final n = notice('target');
        final old = ScheduleCandidate.parse(event(n.body), n.body);
        await rememberCandidates(s, n, [old]);
        final key = candidateKey(n, old);
        await s.setMeta(
          'aiState:$key',
          jsonEncode({
            'status': 'confirmed',
            'calendarSent': true,
            'title': '수정한 제목',
          }),
        );
        final updated = [
          ScheduleCandidate.parse({
            ...event('보고서'),
            'title': '보고서 제출 안내',
          }, n.body),
        ];
        await rememberCandidates(s, n, updated);
        expect(candidateKey(n, updated.single), key);
        expect(jsonDecode((await s.meta('aiState:$key'))!)['title'], '수정한 제목');
        expect(
          await s.db.query(
            'meta',
            where: 'id LIKE ?',
            whereArgs: ['aiCandidate:%'],
          ),
          hasLength(1),
        );
      } finally {
        await s.db.close();
      }
    },
  );
  test(
    'Local diagnostics preserve the model output and redact API key without storing portal context',
    () async {
      final s = await Store.open();
      try {
        await saveAiDiagnostic(
          s,
          notice('target'),
          1,
          const AiFailure('검증 오류', code: 'evidence'),
          response([event('synthetic-secret')]),
          'synthetic-secret',
        );
        final raw = (await s.meta('aiDiagnostic:target'))!;
        expect(raw, contains('[API key removed]'));
        expect(raw, isNot(contains('synthetic-secret')));
        expect(raw, isNot(contains('PRIVATE_CONTEXT')));
        expect(jsonDecode(raw)['attempts'].single['code'], 'evidence');
      } finally {
        await s.db.close();
      }
    },
  );

  Future<void> settle(WidgetTester tester) async {
    for (var i = 0; i < 12; i++) {
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 30)),
      );
      await tester.pump(const Duration(milliseconds: 40));
    }
    await tester.pumpAndSettle();
  }

  testWidgets(
    'Failure has explanations, original and manual alternative; cancel creates no manual candidate',
    (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          onGenerateRoute: buildAppRoute,
          home: AiRecoveryPage(
            notice: notice('target'),
            job: const {
              'status': 'failed',
              'errorCode': 'evidence',
              'error': '인용문 불일치',
            },
          ),
        ),
      );
      addTearDown(() async {
        await tester.pumpWidget(const SizedBox.shrink());
        await settle(tester);
      });
      await settle(tester);
      expect(find.text('왜 실패했나요?'), findsOneWidget);
      expect(find.text('원문 확인'), findsOneWidget);
      await tester.ensureVisible(find.text('직접 일정 추가'));
      await tester.tap(find.text('직접 일정 추가'));
      await settle(tester);
      expect(find.byType(CalendarDraftPage), findsOneWidget);
      await tester.pageBack();
      await settle(tester);
      final store = await tester.runAsync(Store.open);
      final records = await tester.runAsync(
        () => store!.db.query(
          'meta',
          where: 'id LIKE ?',
          whereArgs: ['aiCandidate:%'],
        ),
      );
      expect(records, isEmpty);
      await tester.runAsync(() => store!.db.close());
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets(
    'Failed records are visible before collapsed completions and open recovery',
    (tester) async {
      final store = await tester.runAsync(Store.open);
      await tester.runAsync(() async {
        await store!.setMeta(
          'aiQueue:target',
          jsonEncode({
            'title': '실패 공지',
            'status': 'failed',
            'errorCode': 'evidence',
            'error': '인용문 불일치',
          }),
        );
        await store.setMeta(
          'aiQueue:related',
          jsonEncode({'title': '완료 공지', 'status': 'empty'}),
        );
        await store.db.close();
      });
      await tester.pumpWidget(
        const MaterialApp(
          onGenerateRoute: buildAppRoute,
          home: AiInboxPage(records: true),
        ),
      );
      addTearDown(() async {
        await tester.pumpWidget(const SizedBox.shrink());
        await settle(tester);
      });
      await settle(tester);
      expect(find.text('실패 공지'), findsOneWidget);
      expect(find.text('완료 공지').hitTestable(), findsNothing);
      await tester.tap(find.text('실패 공지'));
      await settle(tester);
      expect(find.byType(AiRecoveryPage), findsOneWidget);
      expect(find.text('왜 실패했나요?'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets(
    'Manual recovery saves a confirmed local schedule and resolves the failure',
    (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          onGenerateRoute: buildAppRoute,
          home: AiRecoveryPage(
            notice: notice('target'),
            job: const {
              'status': 'failed',
              'errorCode': 'date',
              'error': '날짜 검증 실패',
            },
          ),
        ),
      );
      addTearDown(() async {
        await tester.pumpWidget(const SizedBox.shrink());
        await settle(tester);
      });
      await settle(tester);
      await tester.ensureVisible(find.text('직접 일정 추가'));
      await tester.tap(find.text('직접 일정 추가'));
      await settle(tester);
      await tester.tap(find.text('날짜 선택'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('OK'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('일정에 추가'));
      await settle(tester);
      expect(find.byType(CalendarDraftPage), findsNothing);
      await tester.drag(find.byType(ListView).first, const Offset(0, 1200));
      await settle(tester);
      expect(find.text('직접 입력한 일정을 앱 일정함에 추가했어요.'), findsOneWidget);
      final store = await tester.runAsync(Store.open);
      await tester.runAsync(() async {
        final job = jsonDecode((await store!.meta('aiQueue:target'))!);
        expect(job['status'], 'manual');
        final candidates = await store.db.query(
          'meta',
          where: 'id LIKE ?',
          whereArgs: ['aiCandidate:%'],
        );
        expect(candidates, hasLength(1));
        final row = jsonDecode(candidates.single['value'] as String);
        final state = jsonDecode((await store.meta('aiState:${row['key']}'))!);
        expect(state['status'], 'confirmed');
        expect(state['calendarSent'], false);
        await store.db.close();
      });
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets(
    'Excluding from recovery removes the failure warning after returning to records',
    (tester) async {
      final store = await tester.runAsync(Store.open);
      await tester.runAsync(() async {
        await store!.setMeta(
          'aiQueue:target',
          jsonEncode({
            'title': '실패 공지',
            'status': 'failed',
            'error': '날짜 검증 실패',
          }),
        );
        await store.db.close();
      });
      await tester.pumpWidget(
        const MaterialApp(
          onGenerateRoute: buildAppRoute,
          home: AiInboxPage(records: true),
        ),
      );
      addTearDown(() async {
        await tester.pumpWidget(const SizedBox.shrink());
        await settle(tester);
      });
      await settle(tester);
      await tester.tap(find.text('실패 공지'));
      await settle(tester);
      await tester.ensureVisible(find.text('이 공지 분석 제외'));
      await tester.tap(find.text('이 공지 분석 제외'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('분석 제외'));
      await settle(tester);
      expect(find.byType(AiRecoveryPage), findsNothing);
      expect(find.text('해결할 분석 문제가 없어요.'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );
}

import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:campus_radar/release_history.dart';
import 'package:campus_radar/release_history_page.dart';

Map<String, dynamic> row(int build, String channel) => {
  'versionName': 'test.$build',
  'versionCode': build,
  'channel': channel,
  'publishedAt': '2026-10-29T00:00:00Z',
  'changes': ['변경 사항 $build'],
};
String catalog(List<Map<String, dynamic>> rows) =>
    jsonEncode({'schemaVersion': 1, 'releases': rows});

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));
  final raw = catalog([
    row(35, 'stable'),
    row(36, 'development'),
    row(39, 'development'),
    row(46, 'stable'),
  ]);
  test(
    'Packaged catalog contains prior and current published history',
    () async {
      final entries = parseReleaseHistory(
        await rootBundle.loadString('assets/update-history.json'),
      );
      expect(entries.length, greaterThan(30));
      expect(entries.any((e) => e.build == 46 && e.channel == 'stable'), true);
      expect(entries.any((e) => e.build == 35 && e.channel == 'stable'), true);
    },
  );
  test('Skipped versions respect channel and build boundaries in order', () {
    final entries = parseReleaseHistory(raw);
    expect(
      selectReleaseHistory(
        entries,
        channel: 'stable',
        after: 35,
        through: 46,
      ).map((e) => e.build),
      [46],
    );
    expect(
      selectReleaseHistory(
        entries,
        channel: 'development',
        after: 35,
        through: 46,
      ).map((e) => e.build),
      [36, 39, 46],
    );
    expect(
      selectReleaseHistory(entries, channel: 'stable').map((e) => e.build),
      [46, 35],
    );
    expect(
      selectReleaseHistory(
        entries,
        channel: 'development',
        after: 46,
        through: 46,
      ),
      isEmpty,
    );
  });
  test(
    'Invalid dates, duplicate releases and unsupported channels are rejected',
    () {
      for (final value in [
        catalog([row(46, 'stable'), row(46, 'stable')]),
        catalog([
          {...row(46, 'stable'), 'publishedAt': '20260101'},
        ]),
        catalog([row(46, 'unknown')]),
        catalog([
          {...row(46, 'stable'), 'changes': []},
        ]),
      ]) {
        expect(() => parseReleaseHistory(value), throwsFormatException);
      }
    },
  );
  test(
    'Old cache merges new bundled release; failed refresh retains it',
    () async {
      final p = await SharedPreferences.getInstance();
      await p.setString('releaseHistoryV1', catalog([row(35, 'stable')]));
      final repo = ReleaseHistoryRepository(
        bundled: () async => raw,
        remote: () async => throw Exception('offline'),
      );
      expect((await repo.read()).map((e) => e.build), contains(46));
      await expectLater(repo.refresh(), throwsException);
      expect((await repo.read()).map((e) => e.build), containsAll([35, 46]));
      await p.setString('releaseHistoryV1', 'damaged');
      expect(await repo.read(), hasLength(4));
    },
  );
  testWidgets(
    'Stable/development modes and all-history switch expose skipped releases',
    (t) async {
      final repo = ReleaseHistoryRepository(
        bundled: () async => raw,
        remote: () async => throw Exception('offline'),
      );
      await t.pumpWidget(
        MaterialApp(
          home: ReleaseHistoryPage(
            fromBuild: 35,
            throughBuild: 46,
            repository: repo,
          ),
        ),
      );
      await t.pumpAndSettle();
      expect(find.text('• 변경 사항 46'), findsOneWidget);
      expect(find.text('• 변경 사항 36'), findsNothing);
      await t.tap(find.text('개발 모드'));
      await t.pumpAndSettle();
      expect(find.text('• 변경 사항 36'), findsOneWidget);
      await t.tap(find.byType(SwitchListTile));
      await t.pumpAndSettle();
      expect(find.text('test.46 (46) · 정식 릴리스'), findsOneWidget);
      await t.tap(find.byTooltip('내역 새로고침'));
      await t.pumpAndSettle();
      expect(find.textContaining('저장된 내역을 표시'), findsOneWidget);
      expect(find.text('• 변경 사항 46'), findsOneWidget);
      expect(t.takeException(), isNull);
    },
  );
}

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:campus_radar/desktop.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() => SharedPreferences.setMockInitialValues({}));
  test('Windows timetable settings survive bridge reload', () async {
    expect((await desktopMethod('timetableSettings', null))['enabled'], false);
    await desktopMethod('setTimetableSettings', {
      'enabled': true,
      'midnight': true,
      'lead': 15,
      'until': '2026-12-31',
    });
    final result = await desktopMethod('timetableSettings', null);
    expect(result, {
      'enabled': true,
      'midnight': true,
      'lead': 15,
      'until': '2026-12-31',
      'exactAllowed': true,
    });
    await desktopMethod('refreshWidget', null);
  });
  test('Invalid timetable settings preserve previous state', () async {
    await expectLater(
      desktopMethod('setTimetableSettings', {
        'enabled': true,
        'lead': 1,
        'until': 'invalid',
      }),
      throwsFormatException,
    );
    expect((await desktopMethod('timetableSettings', null))['enabled'], false);
  });
}

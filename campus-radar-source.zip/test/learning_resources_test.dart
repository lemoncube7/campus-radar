import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/learning_resources.dart';

void main(){
  final course={'course_id':'c','class_no':'1','course_nm':'과목'};
  test('archive and other modules keep separate kinds and never assume participation',(){
    for(final pair in {'LS':'boarditem_no','LD':'discuss_no','LT':'team_project_no','LQ':'exam_no','LE':'exam_no'}.entries){
      final i=parseAdditionalLearning({'module_type':pair.key,pair.value:'x','weekseq_nm':'제목'},course,{});
      expect(i,isNotNull);expect(i!.type,pair.key);expect(i.status,pair.key=='LS'?'available':'unknown');expect(taskTypeMatches(i,'OTHER'),pair.key!='LS');
    }
  });
  test('week-based exam has actual published interval and no invented completion',(){
    final i=parseAdditionalLearning({'module_type':'LE','contents_id':'e','weekseq_nm':'시험','weekseq_str_dt':'2026-11-02','weekseq_str_dt_hour':'10','weekseq_str_dt_min':'00','weekseq_end_dt':'2026-11-02','weekseq_end_dt_hour':'12','weekseq_end_dt_min':'00'},course,{});
    expect(i!.startsAt,DateTime.utc(2026,11,2,1));expect(i.due,DateTime.utc(2026,11,2,3));expect(i.status,'unknown');
  });
  test('a date-only deadline is due at the end of that day',(){
    final i=parseAdditionalLearning({'module_type':'LD','discuss_no':'d','discuss_topic':'토론','discuss_str_dt':'2026-11-02','discuss_end_dt':'2026-11-05'},course,{});
    expect(i!.startsAt,DateTime.utc(2026,11,1,15));expect(i.due,DateTime.utc(2026,11,5,14,59));
  });
  test('new fields survive old and new persisted payloads',(){
    final i=CampusItem(key:'x',type:'LR',title:'과제',course:'과목',courseId:'c',classNo:'1',contentsId:'x',status:'pending',context:{},originalDue:DateTime.utc(2026,10,30),additionalDue:DateTime.utc(2026,11,2),due:DateTime.utc(2026,11,2));
    final restored=CampusItem.fromJson(i.toJson());expect(restored.originalDue,i.originalDue);expect(restored.additionalDue,i.additionalDue);
    final old=Map<String,dynamic>.from(i.toJson())..remove('additionalDue')..remove('externalUrl')..remove('progress');expect(CampusItem.fromJson(old).additionalDue,isNull);
  });
  test('school content duration in minutes and learned seconds rendered compactly',(){
    expect(contentProgress({'study_time':50,'lv_complete_rst':'1500','complete_yn':'N'}),'학습 25/50분');
    expect(contentProgress({'study_time':50,'lv_complete_rst':'3000','complete_yn':'Y'}),'학습 50/50분');
    expect(contentProgress({}),'');
  });
  test('external links cannot contain script schemes or export viewer auth queries',(){
    expect(safeExternalLink('javascript:alert(1)'),'');
    expect(safeExternalLink('https://user:pw@example.com/video'),'');
    expect(safeExternalLink('https://example.com/watch?v=abc&token=SECRET',cloud:true),isNot(contains('SECRET')));
    expect(safeExternalLink('https://example.com/watch?v=abc&token=SECRET',cloud:true),contains('v=abc'));
  });
  test('quiz and exam startsAt prioritizes activity start over creation/insert timestamp', () {
    final item = parseAdditionalLearning({
      'module_type': 'LE',
      'exam_no': 'e1',
      'exam_title': '중간고사',
      'insert_dt': '2026-09-01 10:00:00',
      'exam_sdate': '2026-12-15 09:00:00',
      'exam_edate': '2026-12-15 11:00:00',
    }, course, {});
    expect(item, isNotNull);
    expect(item!.startsAt, campusDate('2026-12-15 09:00:00'));
  });
  test('weekly due parsing falls back to 23:59:00 when hour/minute are null', () {
    final item = parseAdditionalLearning({
      'module_type': 'LQ',
      'exam_no': 'q1',
      'exam_title': '퀴즈',
      'weekseq_end_dt': '2026-11-20',
    }, course, {});
    expect(item, isNotNull);
    expect(item!.due, campusDate('2026-11-20 23:59:00'));
  });
}

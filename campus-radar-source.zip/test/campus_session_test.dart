import 'package:campus_radar/session_lifetime_probe.dart';
import 'package:campus_radar/collection_control.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:campus_radar/app_storage.dart';
import 'package:campus_radar/campus.dart';
import 'package:campus_radar/campus_session.dart';
import 'package:campus_radar/session_scope.dart';
import 'package:campus_radar/session_lifetime_repository.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

class FakeCampus extends CampusClient {
  int logins = 0, reads = 0;
  Object? readError;
  Completer<void>? gate;
  @override
  Future<void> login(String id, String password) async {
    logins++;
    transportKey = '01234567890123456789012345678901';
    await jar.saveFromResponse(Uri.parse(CampusClient.learning), [
      Cookie('session', 'synthetic')..path = '/',
    ]);
    await gate?.future;
  }

  @override
  Future<List<Map<String, dynamic>>> fetchCourses() async {
    reads++;
    if (readError is CampusAuthenticationLost) await authenticationLost?.call();
    if (readError != null) throw readError!;
    return [];
  }
}

class ResponseCampus extends CampusClient {
  String response = '';
  Object? failure;
  @override
  Future<String> request(
    Uri url, {
    Map<String, String>? form,
    int redirects = 0,
  }) async {
    if (failure != null) throw failure!;
    return response;
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  late Map<String, String> secure;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    secure = {'id': 'synthetic', 'pw': 'not-a-real-password'};
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          (call) async {
            final args = Map<String, dynamic>.from(call.arguments as Map);
            switch (call.method) {
              case 'read':
                return secure[args['key']];
              case 'write':
                secure[args['key'] as String] = args['value'] as String;
                return null;
              case 'delete':
                secure.remove(args['key']);
                return null;
            }
            return null;
          },
        );
    temp = await Directory.systemTemp.createTemp('school-session-');
    await databaseFactory.setDatabasesPath(temp.path);
  });
  tearDown(() async {
    await temp.delete(recursive: true);
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          null,
        );
  });

  test(
    'Stable policy defaults to two hours and preserves explicit preferences',
    () async {
      expect(await schoolReconnectMinutes(), 120);
      final p = await SharedPreferences.getInstance();
      await p.setInt('schoolReconnectMinutes', 240);
      expect(await schoolReconnectMinutes(), 240);
      await saveSchoolReconnectMinutes(null);
      expect(await schoolReconnectMinutes(), isNull);
      await saveSchoolReconnectMinutes(480);
      expect(await schoolReconnectMinutes(), 480);
    },
  );

  test(
    'Retirement clears exclusive mode without changing normal collection or session data',
    () async {
      final p = await SharedPreferences.getInstance();
      await p.setBool('schoolLifetimeProbeEnabled', true);
      await p.setBool('automaticSchoolConnection', false);
      await p.setInt('schoolCollectionMinutes', 30);
      await retireSessionExploration();
      await retireSessionExploration();
      expect(await sessionLifetimeProbeEnabled(), false);
      expect(await automaticSchoolConnectionEnabled(), false);
      expect(await schoolCollectionMinutes(), 30);
      expect(secure['id'], 'synthetic');
      await p.setBool('automaticSchoolConnection', true);
      expect(await automaticSchoolConnectionEnabled(), true);
    },
  );

  test(
    'Default hold blocks new login before two hours and reconnects at a later collection',
    () async {
      final first = FakeCampus(), held = FakeCampus(), later = FakeCampus();
      for (final c in [first, held, later]) {
        addTearDown(c.close);
      }
      await first.connectSchool('synthetic', 'unused');
      await first.authenticationLost!();
      final store = await Store.open();
      try {
        await store.setMeta(
          'schoolSessionLostAt',
          DateTime.now()
              .toUtc()
              .subtract(const Duration(minutes: 119))
              .toIso8601String(),
        );
        await expectLater(
          held.connectSchool('synthetic', 'unused'),
          throwsA(isA<CampusReconnectDeferred>()),
        );
        expect(held.logins, 0);
        expect(held.reads, 0);
        await store.setMeta(
          'schoolSessionLostAt',
          DateTime.now()
              .toUtc()
              .subtract(const Duration(minutes: 121))
              .toIso8601String(),
        );
        await later.connectSchool('synthetic', 'unused');
        expect(later.logins, 1);
        expect(await store.meta('schoolSessionLostAt'), '');
      } finally {
        await store.db.close();
      }
    },
  );

  test(
    'Read-only lifetime probe cannot log in even with credentials or expired hold',
    () async {
      final first = FakeCampus();
      addTearDown(first.close);
      await expectLater(
        first.connectSchool('synthetic', 'unused', allowFreshLogin: false),
        throwsA(isA<CampusReconnectDeferred>()),
      );
      expect(first.logins, 0);
      expect(first.reads, 0);
      await first.connectSchool('synthetic', 'unused');
      final readOnly = FakeCampus();
      addTearDown(readOnly.close);
      await readOnly.connectSchool(
        'synthetic',
        'unused',
        allowFreshLogin: false,
      );
      expect(readOnly.logins, 0);
      expect(readOnly.reads, 1);
      await readOnly.authenticationLost!();
      await saveSchoolReconnectMinutes(15);
      final store = await Store.open();
      await store.setMeta(
        'schoolSessionLostAt',
        DateTime.now()
            .toUtc()
            .subtract(const Duration(days: 1))
            .toIso8601String(),
      );
      await store.db.close();
      await expectLater(
        readOnly.connectSchool('synthetic', 'unused', allowFreshLogin: false),
        throwsA(isA<CampusReconnectDeferred>()),
      );
      expect(readOnly.logins, 0);
    },
  );

  test(
    'Exclusive test blocks ordinary new login but permits preparing its baseline session',
    () async {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('schoolLifetimeProbeEnabled', true);
      final client = FakeCampus(), manual = FakeCampus();
      addTearDown(client.close);
      addTearDown(manual.close);
      await expectLater(
        client.connectSchool('synthetic', 'unused'),
        throwsA(isA<CampusReconnectDeferred>()),
      );
      expect(client.logins, 0);
      await client.connectSchool('synthetic', 'unused', forSessionTest: true);
      expect(client.logins, 1);
      await manual.connectSchool('synthetic', 'unused');
      expect(manual.logins, 0);
      expect(manual.reads, 1);
    },
  );

  test(
    'Lifetime record survives worker recreation, rejects stale epoch and ignores damaged optional diagnostics',
    () async {
      final first = FakeCampus(), next = FakeCampus();
      addTearDown(first.close);
      addTearDown(next.close);
      await first.connectSchool('synthetic', 'unused');
      final store = await Store.open();
      final scope = await SessionScope.capture(store);
      final before = await SessionLifetimeRepository(store).read(scope.epoch);
      expect(before.successes, 1);
      await next.connectSchool('synthetic', 'unused');
      final after = await SessionLifetimeRepository(store).read(scope.epoch);
      expect(after.successes, 2);
      expect(after.session, before.session);
      await store.setMeta(sessionLifetimeKey, '{broken');
      final damaged = FakeCampus();
      addTearDown(damaged.close);
      await damaged.connectSchool('synthetic', 'unused');
      expect(damaged.logins, 0);
      expect(await store.meta(sessionLifetimeKey), '{broken');
      await SessionScope.rotate(store, blocked: false);
      await expectLater(
        SessionLifetimeRepository(
          store,
        ).change(scope.epoch, (s) => s.successes++),
        throwsA(isA<SessionChanged>()),
      );
      await store.db.close();
    },
  );

  test(
    'Only authentication responses trigger hold, never malformed JSON or forbidden resource',
    () async {
      final client = ResponseCampus()
        ..transportKey = '01234567890123456789012345678901';
      addTearDown(client.close);
      var lost = 0;
      client.authenticationLost = () async {
        lost++;
      };
      client.response = '<html>maintenance</html>';
      await expectLater(
        client.api('/term/getYearTermList', null),
        throwsA(isA<CampusException>()),
      );
      expect(lost, 0);
      client.failure = CampusHttpException(403, '/test');
      await expectLater(
        client.api('/term/getYearTermList', null),
        throwsA(isA<CampusHttpException>()),
      );
      expect(lost, 0);
      client.failure = null;
      client.response = '<form name="loginForm"></form>';
      await expectLater(
        client.api('/term/getYearTermList', null),
        throwsA(isA<CampusAuthenticationLost>()),
      );
      expect(lost, 1);
      client.response = '{"header":{"code":401}}';
      await expectLater(
        client.api('/term/getYearTermList', null),
        throwsA(isA<CampusAuthenticationLost>()),
      );
      expect(lost, 2);
    },
  );

  test('Two worker stores cannot reserve the same active probe', () async {
    final client = FakeCampus();
    addTearDown(client.close);
    await client.connectSchool('synthetic', 'unused');
    final first = await Store.open(), second = await Store.open();
    try {
      // No-isolate FFI cannot progress the first transaction while the second
      // synchronously waits. Shorten only this test connection's busy wait.
      await second.db.rawQuery('PRAGMA busy_timeout = 10');
      final scope = await SessionScope.capture(first);
      final now = DateTime.now()
          .toUtc()
          .add(const Duration(minutes: 16))
          .millisecondsSinceEpoch;
      final outcomes = await Future.wait([
        SessionLifetimeRepository(
          first,
        ).change(scope.epoch, (state) => state.reserveProbe(now)),
        SessionLifetimeRepository(
          second,
        ).change(scope.epoch, (state) => state.reserveProbe(now)),
      ]);
      expect(outcomes.where((result) => result).length, 1);
    } finally {
      await first.db.close();
      await second.db.close();
    }
  });

  test(
    'Successful new login survives first-read timeout and rotated cookie persists after coordinator closes',
    () async {
      final first = FakeCampus()..readError = TimeoutException('synthetic');
      final next = FakeCampus(), restored = FakeCampus();
      for (final c in [first, next, restored]) {
        addTearDown(c.close);
      }
      await expectLater(
        first.connectSchool('synthetic', 'unused'),
        throwsA(isA<TimeoutException>()),
      );
      expect(first.logins, 1);
      await next.connectSchool('synthetic', 'unused');
      expect(next.logins, 0);
      await next.jar.saveFromResponse(Uri.parse(CampusClient.learning), [
        Cookie('rotated', 'synthetic')..path = '/',
      ]);
      await next.sessionUpdated!();
      await restored.connectSchool('synthetic', 'unused');
      expect(restored.logins, 0);
      expect(
        (await restored.jar.loadForRequest(
          Uri.parse(CampusClient.learning),
        )).map((c) => c.name),
        contains('rotated'),
      );
    },
  );

  test(
    'Session snapshot restores path cookies and creation time without extending max-age',
    () async {
      final first = FakeCampus(), next = FakeCampus();
      addTearDown(first.close);
      addTearDown(next.close);
      await first.login('synthetic', 'unused');
      await first.jar.saveFromResponse(
        Uri.parse('${CampusClient.learning}/api/private'),
        [
          Cookie('pathOnly', 'synthetic')
            ..path = '/api'
            ..maxAge = 3600,
        ],
      );
      final saved = first.exportSession();
      next.restoreSession(
        jsonDecode(jsonEncode(saved)) as Map<String, dynamic>,
      );
      expect(next.transportKey, first.transportKey);
      expect(next.exportSession(), saved);
      expect(
        (await next.jar.loadForRequest(
          Uri.parse('${CampusClient.learning}/api/private'),
        )).map((c) => c.name),
        contains('pathOnly'),
      );
      expect(
        (await next.jar.loadForRequest(
          Uri.parse(CampusClient.learning),
        )).map((c) => c.name),
        isNot(contains('pathOnly')),
      );
    },
  );

  test(
    'Separate clients reuse encrypted session; timeout never logs in again or starts cooldown',
    () async {
      final first = FakeCampus(), next = FakeCampus(), third = FakeCampus();
      for (final c in [first, next, third]) {
        addTearDown(c.close);
      }
      await first.connectSchool('synthetic', 'unused');
      expect(first.logins, 1);
      next.readError = TimeoutException('synthetic');
      await expectLater(
        next.connectSchool('synthetic', 'unused'),
        throwsA(isA<TimeoutException>()),
      );
      expect(next.logins, 0);
      final store = await Store.open();
      expect(await store.meta('schoolSessionLostAt'), anyOf(isNull, ''));
      await store.db.close();
      await third.connectSchool('synthetic', 'unused');
      expect(third.logins, 0);
      expect(
        secure.keys.where((k) => k.startsWith('schoolSession:')).length,
        1,
      );
    },
  );

  test(
    'Authentication loss holds all callers; user-selected wait then permits one new login',
    () async {
      final first = FakeCampus(),
          lost = FakeCampus(),
          held = FakeCampus(),
          later = FakeCampus();
      for (final c in [first, lost, held, later]) {
        addTearDown(c.close);
      }
      await first.connectSchool('synthetic', 'unused');
      lost.readError = CampusAuthenticationLost();
      await expectLater(
        lost.connectSchool('synthetic', 'unused'),
        throwsA(isA<CampusAuthenticationLost>()),
      );
      expect(lost.logins, 0);
      await expectLater(
        held.connectSchool('synthetic', 'unused'),
        throwsA(isA<CampusException>()),
      );
      expect(held.reads, 0);
      expect(held.logins, 0);
      await saveSchoolReconnectMinutes(30);
      await expectLater(
        held.connectSchool('synthetic', 'unused'),
        throwsA(isA<CampusException>()),
      );
      final store = await Store.open();
      await store.setMeta(
        'schoolSessionLostAt',
        DateTime.now()
            .toUtc()
            .subtract(const Duration(minutes: 31))
            .toIso8601String(),
      );
      await store.db.close();
      await later.connectSchool('synthetic', 'unused');
      expect(later.logins, 1);
      expect(await schoolReconnectMinutes(), 30);
    },
  );

  test('Concurrent authentication cannot trigger two fresh logins', () async {
    final first = FakeCampus()..gate = Completer<void>(), next = FakeCampus();
    addTearDown(first.close);
    addTearDown(next.close);
    final pending = first.connectSchool('synthetic', 'unused');
    while (first.logins == 0) {
      await Future<void>.delayed(const Duration(milliseconds: 5));
    }
    await expectLater(
      next.connectSchool('synthetic', 'unused'),
      throwsA(isA<CampusException>()),
    );
    expect(next.logins, 0);
    first.gate!.complete();
    await pending;
    await next.connectSchool('synthetic', 'unused');
    expect(next.logins, 0);
  });

  test(
    'Old account callback cannot pause the new account; corrupt snapshot does not force login',
    () async {
      final first = FakeCampus(), next = FakeCampus();
      addTearDown(first.close);
      addTearDown(next.close);
      await first.connectSchool('synthetic', 'unused');
      final store = await Store.open();
      await SessionScope.rotate(store, blocked: false);
      await expectLater(
        first.authenticationLost!(),
        throwsA(isA<SessionChanged>()),
      );
      await store.db.close();
      await next.connectSchool('synthetic', 'unused');
      final key = secure.keys.singleWhere(
        (k) => k.startsWith('schoolSession:'),
      );
      secure[key] = '{broken';
      final damaged = FakeCampus();
      addTearDown(damaged.close);
      await expectLater(
        damaged.connectSchool('synthetic', 'unused'),
        throwsA(isA<CampusException>()),
      );
      expect(damaged.logins, 0);
    },
  );
}

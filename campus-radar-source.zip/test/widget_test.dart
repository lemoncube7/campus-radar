import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/campus.dart';

void main() {
  test('Korean campus time is parsed independently of device timezone', () {
    expect(
      campusDate('2026-10-21 23:59:00'),
      DateTime.utc(2026, 10, 21, 14, 59),
    );
    expect(campusDate('unknown'), isNull);
  });
  test('Persisted item preserves identity, status and UTC deadline', () {
    final i = CampusItem(
      key: 'LR:c:1:task',
      type: 'LR',
      title: '과제',
      course: '수업',
      courseId: 'c',
      classNo: '1',
      contentsId: 'task',
      status: 'pending',
      due: DateTime.utc(2026, 10, 21, 14, 59),
      context: {'report_no': 'task'},
    );
    final restored = CampusItem.fromJson(i.toJson());
    expect(restored.key, i.key);
    expect(restored.due, i.due);
    expect(restored.done, isFalse);
    expect(restored.context['report_no'], 'task');
  });
  test('HTML display text discards script markup', () {
    expect(textOf('<p>제출 <b>안내</b></p>'), '제출 안내');
  });
}

import 'package:campus_radar/app_router.dart';
import 'package:campus_radar/task_detail_page.dart';
import 'package:campus_radar/campus_models.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/main.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  testWidgets('Startup failure renders a retry screen instead of hiding UI', (
    tester,
  ) async {
    var attempts = 0;
    await tester.pumpWidget(
      MaterialApp(
        onGenerateRoute: buildAppRoute,
        home: StartupGate(
          initializer: () async {
            attempts++;
            throw PlatformException(code: 'invalid_icon');
          },
        ),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.text('캠퍼스레이더'), findsNWidgets(2));
    expect(find.textContaining('invalid_icon'), findsOneWidget);
    expect(find.text('다시 시도'), findsOneWidget);
    await tester.tap(find.text('다시 시도'));
    await tester.pumpAndSettle();
    expect(attempts, 2);
  });
  testWidgets('Item detail has deadline, state and campus shortcut', (
    tester,
  ) async {
    final item = CampusItem(
      key: 'test',
      type: 'LR',
      title: '과제 상세 테스트',
      course: '테스트 수업',
      courseId: 'c',
      classNo: '1',
      contentsId: 't',
      status: 'pending',
      body: '제출 안내',
      due: DateTime.utc(2026, 10, 21, 14, 59),
      context: {},
    );
    await tester.pumpWidget(
      MaterialApp(
        onGenerateRoute: buildAppRoute,
        home: DetailPage(item: item),
      ),
    );
    expect(find.text('과제 상세 테스트'), findsOneWidget);
    expect(find.text('미제출'), findsOneWidget);
    expect(find.text('사이버캠퍼스 열기'), findsOneWidget);
    await tester.tap(find.byType(PopupMenuButton<String>));
    await tester.pumpAndSettle();
    expect(find.text('목록에서 제외'), findsOneWidget);
    await tester.tap(find.text('목록에서 제외'));
    await tester.pumpAndSettle();
    expect(find.text('목록에서 제외할까요?'), findsOneWidget);
    await tester.tap(find.text('취소'));
    await tester.pumpAndSettle();
    expect(find.text('목록에서 제외'), findsNothing);
  });
  testWidgets('Excluded detail provides a restore action', (tester) async {
    final item = CampusItem(
      key: 'hidden',
      type: 'LR',
      title: '제외된 과제',
      course: '수업',
      courseId: 'c',
      classNo: '1',
      contentsId: 't',
      status: 'pending',
      context: {},
    );
    await tester.pumpWidget(
      MaterialApp(
        onGenerateRoute: buildAppRoute,
        home: DetailPage(item: item, excluded: true),
      ),
    );
    await tester.tap(find.byType(PopupMenuButton<String>));
    await tester.pumpAndSettle();
    expect(find.text('목록에 복구'), findsOneWidget);
    expect(find.text('목록에서 제외됨 · 알림 꺼짐'), findsOneWidget);
  });
  test('Korean campus time is parsed independently of device timezone', () {
    expect(
      campusDate('2026-10-21 23:59:00'),
      DateTime.utc(2026, 10, 21, 14, 59),
    );
    expect(campusDate('unknown'), isNull);
  });
  test('Persisted item preserves identity, status and UTC deadline', () {
    final i = CampusItem(
      key: 'LR:c:1:task',
      type: 'LR',
      title: '과제',
      course: '수업',
      courseId: 'c',
      classNo: '1',
      contentsId: 'task',
      status: 'pending',
      due: DateTime.utc(2026, 10, 21, 14, 59),
      context: {'report_no': 'task'},
    );
    final restored = CampusItem.fromJson(i.toJson());
    expect(restored.key, i.key);
    expect(restored.due, i.due);
    expect(restored.done, isFalse);
    expect(restored.context['report_no'], 'task');
  });
  test('HTML display text discards script markup', () {
    expect(textOf('<p>제출 <b>안내</b></p>'), '제출 안내');
  });
}

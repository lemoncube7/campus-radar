import 'package:campus_radar/app_router.dart';
import 'package:campus_radar/ai_daily_card.dart';
import 'dart:async';
import 'dart:io';
import 'package:campus_radar/plan_fetch.dart';
import 'package:campus_radar/widget_text_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('Daily expansion does not read a scroll offset as bool', (
    tester,
  ) async {
    final bucket = PageStorageBucket();
    await tester.pumpWidget(
      MaterialApp(
        onGenerateRoute: buildAppRoute,
        home: PageStorage(
          bucket: bucket,
          child: Builder(
            builder: (context) {
              bucket.writeState(context, 350.0);
              return const ListViewTest();
            },
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    expect(find.text('오늘 요약'), findsOneWidget);
    await tester.tap(find.text('오늘 요약'));
    await tester.pumpAndSettle();
    expect(find.text('AI 설정'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
  test('Transient request retries once, but cancellation does not', () async {
    var attempts = 0;
    expect(
      await retryPlanConnection(() async {
        if (++attempts == 1) throw const SocketException('offline');
        return 1;
      }),
      1,
    );
    expect(attempts, 2);
    attempts = 0;
    await expectLater(
      retryPlanConnection(() async {
        attempts++;
        throw PlatformException(code: 'syllabus_cancelled');
      }),
      throwsA(isA<PlatformException>()),
    );
    expect(attempts, 1);
    expect(planFailure(TimeoutException('private')), contains('시간이 초과'));
    expect(
      planFailure(PlatformException(code: 'syllabus', message: '본문 인식 실패')),
      '본문 인식 실패',
    );
  });
  testWidgets('Widget text changes persist all three independent values', (
    tester,
  ) async {
    const channel = MethodChannel('campus_radar/native');
    Map<dynamic, dynamic>? saved;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (call) async {
          if (call.method == 'widgetTextSettings') {
            return {'tasks': 110, 'timetable': 120, 'lock': 90};
          }
          if (call.method == 'widgetTextConfigure') {
            saved = call.arguments as Map;
          }
          return null;
        });
    await tester.pumpWidget(
      const MaterialApp(onGenerateRoute: buildAppRoute, home: WidgetTextPage()),
    );
    await tester.pumpAndSettle();
    expect(find.text('과제·콘텐츠 위젯 · 110%'), findsOneWidget);
    final slider = tester.widget<Slider>(find.byKey(const ValueKey('tasks')));
    slider.onChanged!(140);
    slider.onChangeEnd!(140);
    await tester.pumpAndSettle();
    expect(saved, {'tasks': 140, 'timetable': 120, 'lock': 90});
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, null);
  });
}

class ListViewTest extends StatelessWidget {
  const ListViewTest({super.key});
  @override
  Widget build(BuildContext context) =>
      const Scaffold(body: SingleChildScrollView(child: AiDailyCard()));
}

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/navigation/app_router.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/platform/desktop_update.dart';
import 'package:campus_radar/settings/app_help_catalog.dart';
import 'package:campus_radar/updates/app_notices.dart';
import 'package:campus_radar/updates/app_notices_page.dart';
import 'package:campus_radar/updates/updates.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  group('AppNotice JSON Parsing', () {
    test('parses valid notices with required and optional fields', () {
      final json = jsonEncode({
        'schemaVersion': 1,
        'notices': [
          {
            'id': '2026-11-10-drive-dup',
            'title': 'Drive 중복 폴더 안내',
            'body': '0.6.3 버전에서 발생한 중복 폴더 문제를 0.6.4에서 해결했어요.',
            'publishedAt': '2026-11-10T04:00:00Z',
            'level': 'important',
            'url': 'https://github.com/lemoncube7/campus-radar/releases/tag/v0.6.4',
            'minVersionCode': 86,
            'maxVersionCode': 86,
            'platforms': ['android'],
            'expiresAt': '2026-12-31T00:00:00Z',
            'extraUnknownField': 'should be ignored',
          },
        ],
      });

      final notices = parseAppNoticesJson(json);
      expect(notices.length, 1);
      final n = notices.first;
      expect(n.id, '2026-11-10-drive-dup');
      expect(n.title, 'Drive 중복 폴더 안내');
      expect(n.body, '0.6.3 버전에서 발생한 중복 폴더 문제를 0.6.4에서 해결했어요.');
      expect(n.publishedAt, DateTime.utc(2026, 11, 10, 4));
      expect(n.level, 'important');
      expect(n.isImportant, true);
      expect(n.url, 'https://github.com/lemoncube7/campus-radar/releases/tag/v0.6.4');
      expect(n.minVersionCode, 86);
      expect(n.maxVersionCode, 86);
      expect(n.platforms, ['android']);
      expect(n.expiresAt, DateTime.utc(2026, 12, 31, 0));
    });

    test('skips invalid items and parses only valid ones', () {
      final json = jsonEncode({
        'schemaVersion': 1,
        'notices': [
          {'id': '', 'title': '빈 아이디', 'body': 'b', 'publishedAt': '2026-11-10T00:00:00Z'},
          {'id': 'valid-1', 'title': '유효 공지', 'body': '내용', 'publishedAt': '2026-11-10T00:00:00Z'},
          {'id': 'no-title', 'body': 'b', 'publishedAt': '2026-11-10T00:00:00Z'},
          {'id': 'bad-date', 'title': 't', 'body': 'b', 'publishedAt': 'not-a-date'},
          {'id': 'bad-url', 'title': 't', 'body': 'b', 'publishedAt': '2026-11-10T00:00:00Z', 'url': 'ftp://bad'},
          'just-a-string-not-a-map',
        ],
      });

      final notices = parseAppNoticesJson(json);
      expect(notices.length, 1);
      expect(notices.first.id, 'valid-1');
    });

    test('broken or non-json input returns empty list without throwing', () {
      expect(parseAppNoticesJson('<html>404 Not Found</html>'), isEmpty);
      expect(parseAppNoticesJson('{"broken json...'), isEmpty);
      expect(parseAppNoticesJson(''), isEmpty);
      expect(parseAppNoticesJson('[]'), isEmpty);
      expect(parseAppNoticesJson('{"notices": "not a list"}'), isEmpty);
    });
  });

  group('Notice Filters (Version, Platform, Expiry)', () {
    final baseNotice = AppNotice(
      id: 'test-1',
      title: '테스트',
      body: '본문',
      publishedAt: DateTime.utc(2026, 11, 10),
      minVersionCode: 80,
      maxVersionCode: 90,
      platforms: ['android', 'windows'],
      expiresAt: DateTime.utc(2026, 12, 1),
    );

    test('matches when within version, platform, and expiry', () {
      expect(
        isNoticeEligible(
          baseNotice,
          currentBuild: 85,
          currentPlatform: 'android',
          now: DateTime.utc(2026, 11, 15),
        ),
        isTrue,
      );
      expect(
        isNoticeEligible(
          baseNotice,
          currentBuild: 80,
          currentPlatform: 'windows',
          now: DateTime.utc(2026, 11, 15),
        ),
        isTrue,
      );
    });

    test('filters out when build is below minVersionCode', () {
      expect(
        isNoticeEligible(
          baseNotice,
          currentBuild: 79,
          currentPlatform: 'android',
          now: DateTime.utc(2026, 11, 15),
        ),
        isFalse,
      );
    });

    test('filters out when build is above maxVersionCode', () {
      expect(
        isNoticeEligible(
          baseNotice,
          currentBuild: 91,
          currentPlatform: 'android',
          now: DateTime.utc(2026, 11, 15),
        ),
        isFalse,
      );
    });

    test('filters out when platform does not match', () {
      expect(
        isNoticeEligible(
          baseNotice,
          currentBuild: 85,
          currentPlatform: 'ios',
          now: DateTime.utc(2026, 11, 15),
        ),
        isFalse,
      );
    });

    test('filters out when notice has expired', () {
      expect(
        isNoticeEligible(
          baseNotice,
          currentBuild: 85,
          currentPlatform: 'android',
          now: DateTime.utc(2026, 12, 2),
        ),
        isFalse,
      );
    });

    test('notice without optional filters is eligible for all', () {
      final openNotice = AppNotice(
        id: 'open',
        title: '전체 공지',
        body: '누구에게나 표시',
        publishedAt: DateTime.utc(2026, 11, 1),
      );
      expect(
        isNoticeEligible(
          openNotice,
          currentBuild: 1,
          currentPlatform: 'linux',
          now: DateTime.utc(2030, 1, 1),
        ),
        isTrue,
      );
    });
  });

  group('Notifications: Send Once & Ignore Seen', () {
    test('sends notification for new notice exactly once and stores id in SharedPreferences', () async {
      final notified = <String>[];
      Future<bool> fakeNotifier(AppNotice n) async {
        notified.add(n.id);
        return true;
      }

      final json = jsonEncode({
        'schemaVersion': 1,
        'notices': [
          {
            'id': 'notice-once',
            'title': '새 공지',
            'body': '공지 내용',
            'publishedAt': '2026-11-10T00:00:00Z',
          },
        ],
      });

      // First run: should notify
      await processAppNotices(
        json,
        notifier: fakeNotifier,
        currentBuild: 87,
        currentPlatform: 'android',
        now: DateTime.utc(2026, 11, 10),
      );

      expect(notified, ['notice-once']);
      final prefs = await SharedPreferences.getInstance();
      expect(prefs.getStringList(PrefKey.appNoticesNotified), contains('notice-once'));

      // Second run with same notice: should ignore already seen notice
      await processAppNotices(
        json,
        notifier: fakeNotifier,
        currentBuild: 87,
        currentPlatform: 'android',
        now: DateTime.utc(2026, 11, 10),
      );

      // Notifier must NOT be called again
      expect(notified.length, 1);
    });

    test('does not consume notification if notifier returns false (permission missing)', () async {
      var allow = false;
      final notified = <String>[];
      Future<bool> fakeNotifier(AppNotice n) async {
        if (!allow) return false;
        notified.add(n.id);
        return true;
      }

      final json = jsonEncode({
        'schemaVersion': 1,
        'notices': [
          {
            'id': 'retry-notice',
            'title': '재시도 공지',
            'body': '권한 허용 시 재발송',
            'publishedAt': '2026-11-10T00:00:00Z',
          },
        ],
      });

      // 1. Permission absent
      await processAppNotices(
        json,
        notifier: fakeNotifier,
        currentBuild: 87,
        currentPlatform: 'android',
        now: DateTime.utc(2026, 11, 10),
      );
      expect(notified, isEmpty);
      final prefs = await SharedPreferences.getInstance();
      expect(prefs.getStringList(PrefKey.appNoticesNotified) ?? [], isEmpty);

      // 2. Permission now allowed
      allow = true;
      await processAppNotices(
        json,
        notifier: fakeNotifier,
        currentBuild: 87,
        currentPlatform: 'android',
        now: DateTime.utc(2026, 11, 10),
      );
      expect(notified, ['retry-notice']);
      expect(prefs.getStringList(PrefKey.appNoticesNotified), contains('retry-notice'));
    });
  });

  group('Home Display & Dismissal', () {
    test('important notices show on home until closed by user', () async {
      final json = jsonEncode({
        'schemaVersion': 1,
        'notices': [
          {
            'id': 'imp-1',
            'title': '중요 공지',
            'body': '홈 상단 카드에 표시',
            'level': 'important',
            'publishedAt': '2026-11-10T00:00:00Z',
          },
          {
            'id': 'info-1',
            'title': '일반 공지',
            'body': '홈 카드에는 안 뜸',
            'level': 'info',
            'publishedAt': '2026-11-10T00:00:00Z',
          },
        ],
      });

      await processAppNotices(
        json,
        notifier: (_) async => true,
        currentBuild: 87,
        currentPlatform: 'android',
        now: DateTime.utc(2026, 11, 10),
      );

      var active = await activeImportantNotices(
        currentBuild: 87,
        currentPlatform: 'android',
        now: DateTime.utc(2026, 11, 10),
      );
      expect(active.map((n) => n.id), ['imp-1']);

      // User dismisses the important notice
      await dismissAppNotice('imp-1');

      // Now no active important notice for home
      active = await activeImportantNotices(
        currentBuild: 87,
        currentPlatform: 'android',
        now: DateTime.utc(2026, 11, 10),
      );
      expect(active, isEmpty);

      // But cached past notices still list both notices
      final allCached = await loadCachedAppNotices();
      expect(allCached.map((n) => n.id), containsAll(['imp-1', 'info-1']));
    });
  });

  group('Integration with checkForUpdates: 404, Broken JSON, and Normal Flow', () {
    late Store store;

    setUp(() async {
      final db = await openDatabase(
        inMemoryDatabasePath,
        version: 2,
        onCreate: (db, _) async {
          await db.execute('CREATE TABLE items (id TEXT PRIMARY KEY, payload TEXT NOT NULL)');
          await db.execute('CREATE TABLE meta (id TEXT PRIMARY KEY, value TEXT NOT NULL)');
          await db.execute('CREATE TABLE events (id TEXT PRIMARY KEY, payload TEXT NOT NULL, delivered INTEGER NOT NULL DEFAULT 0)');
          await db.execute('CREATE TABLE notices (id TEXT PRIMARY KEY, payload TEXT NOT NULL)');
          await db.execute('CREATE TABLE logs (id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL, detail TEXT NOT NULL)');
        },
      );
      store = Store(db);
    });

    tearDown(() async {
      await store.db.close();
    });

    test('404 on notices feed does not abort update check', () async {
      Future<Map<String, dynamic>?> manifestLoader(String channel) async => {
            'versionCode': appBuild + 1,
            'versionName': '0.6.5',
            'apkUrl': 'https://example.com/app.apk',
            'sha256': 'a' * 64,
          };

      Future<String?> notices404() async => null;

      final notifiedUpdates = <String>[];
      Future<bool> updateNotifier(Map<String, dynamic> u) async {
        notifiedUpdates.add(u['versionName']);
        return true;
      }

      final notifiedNotices = <String>[];
      Future<bool> noticeNotifier(AppNotice n) async {
        notifiedNotices.add(n.id);
        return true;
      }

      await checkForUpdates(
        store,
        loader: manifestLoader,
        notifier: updateNotifier,
        noticesLoader: notices404,
        noticeNotifier: noticeNotifier,
      );

      // Update check succeeded and notified new update
      expect(notifiedUpdates, ['0.6.5']);
      expect(notifiedNotices, isEmpty);

      final candidate = await cachedUpdate(current: 87);
      expect(candidate?['versionCode'], appBuild + 1);
    });

    test('broken JSON in notices feed does not break update check', () async {
      Future<Map<String, dynamic>?> manifestLoader(String channel) async => {
            'versionCode': appBuild + 1,
            'versionName': '0.6.5',
            'apkUrl': 'https://example.com/app.apk',
            'sha256': 'a' * 64,
          };

      Future<String?> brokenNotices() async => '<html>502 Bad Gateway</html>';

      final notifiedUpdates = <String>[];
      await checkForUpdates(
        store,
        loader: manifestLoader,
        notifier: (u) async {
          notifiedUpdates.add(u['versionName']);
          return true;
        },
        noticesLoader: brokenNotices,
        noticeNotifier: (_) async => true,
      );

      expect(notifiedUpdates, ['0.6.5']);
      final candidate = await cachedUpdate(current: 87);
      expect(candidate?['versionCode'], appBuild + 1);
    });

    test('corrupt/thrown network error in notices feed allows update check to proceed', () async {
      Future<Map<String, dynamic>?> manifestLoader(String channel) async => {
            'versionCode': appBuild + 1,
            'versionName': '0.6.5',
            'apkUrl': 'https://example.com/app.apk',
            'sha256': 'a' * 64,
          };

      Future<String?> throwingNotices() async =>
          throw const FormatException('connection reset');

      final notifiedUpdates = <String>[];
      await checkForUpdates(
        store,
        loader: manifestLoader,
        notifier: (u) async {
          notifiedUpdates.add(u['versionName']);
          return true;
        },
        noticesLoader: throwingNotices,
        noticeNotifier: (_) async => true,
      );

      expect(notifiedUpdates, ['0.6.5']);
    });

    test('both update and new notice notifications are dispatched at same checkpoint', () async {
      Future<Map<String, dynamic>?> manifestLoader(String channel) async => {
            'versionCode': appBuild + 1,
            'versionName': '0.6.5',
            'apkUrl': 'https://example.com/app.apk',
            'sha256': 'a' * 64,
          };

      Future<String?> validNotices() async => jsonEncode({
            'schemaVersion': 1,
            'notices': [
              {
                'id': 'notice-co-check',
                'title': '공지 동시 확인',
                'body': '업데이트 확인과 같은 시점에 도착',
                'publishedAt': '2026-11-10T00:00:00Z',
              },
            ],
          });

      final notifiedUpdates = <String>[];
      final notifiedNotices = <String>[];

      await checkForUpdates(
        store,
        loader: manifestLoader,
        notifier: (u) async {
          notifiedUpdates.add(u['versionName']);
          return true;
        },
        noticesLoader: validNotices,
        noticeNotifier: (n) async {
          notifiedNotices.add(n.id);
          return true;
        },
      );

      expect(notifiedUpdates, ['0.6.5']);
      expect(notifiedNotices, ['notice-co-check']);
    });
  });

  group('Windows desktop_update Integration', () {
    test('checkDesktopUpdate processes notices using shared code and handles broken notice feeds', () async {
      final notifiedNotices = <String>[];
      Future<bool> noticeNotifier(AppNotice n) async {
        notifiedNotices.add(n.id);
        return true;
      }

      // Check with broken notices: checkDesktopUpdate does not crash
      await checkDesktopUpdate(
        silent: true,
        noticesLoader: () async => 'corrupted notice json',
        noticeNotifier: noticeNotifier,
      ).catchError((_) => null); // network call for windowsFeed might fail in unit test

      // Now check with valid notice
      final raw = jsonEncode({
        'schemaVersion': 1,
        'notices': [
          {
            'id': 'desktop-notice-1',
            'title': 'PC 공지',
            'body': 'Windows 지원 안내',
            'publishedAt': '2026-11-10T00:00:00Z',
          },
        ],
      });

      await processAppNotices(
        raw,
        notifier: noticeNotifier,
        currentBuild: 87,
        currentPlatform: 'windows',
        now: DateTime.utc(2026, 11, 10),
      );

      expect(notifiedNotices, ['desktop-notice-1']);
    });
  });

  group('Help Catalog & Navigation', () {
    test('appHelpCatalog contains "공지" topic and keyword', () {
      final topic = appHelpTopic('app-notices');
      expect(topic, isNotNull);
      expect(topic!.title, '공지');
      expect(topic.keywords, contains('공지'));
      expect(topic.steps.any((s) => s.contains('공지 목록')), isTrue);
    });

    test('HelpTool.appNotices routes to AppNoticesPage', () {
      final route = buildAppRoute(
        const RouteSettings(
          name: '/radar/help/tool',
          arguments: HelpToolDestination(HelpTool.appNotices),
        ),
      );
      expect(route, isNotNull);
      expect((route as MaterialPageRoute).builder(FakeBuildContext()), isA<AppNoticesPage>());
    });

    test('AppNoticeDestination routes to AppNoticesPage', () {
      final route = buildAppRoute(
        const RouteSettings(
          name: '/radar/app-notices',
          arguments: AppNoticeDestination(),
        ),
      );
      expect(route, isNotNull);
      expect((route as MaterialPageRoute).builder(FakeBuildContext()), isA<AppNoticesPage>());
    });
  });
}

class FakeBuildContext extends Fake implements BuildContext {}

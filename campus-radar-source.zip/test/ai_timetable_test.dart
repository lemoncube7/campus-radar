import 'package:campus_radar/ai_protocol.dart';
import 'package:campus_radar/ai_timetable_rules.dart';
import 'package:campus_radar/app_storage.dart';
import 'package:campus_radar/campus_models.dart';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/ai_timetable.dart';
import 'package:campus_radar/ai_automation.dart';
import 'package:campus_radar/chat.dart';
import 'package:campus_radar/timetable_model.dart';

CampusNotice example({
  String body = '다음 수업 시간에 중간고사를 실시합니다.',
  DateTime? published,
  bool noDate = false,
}) => CampusNotice(
  id: 'timetable-example',
  title: '시험 안내',
  course: '예시 수업',
  context: {
    'course_id': 'c1',
    'class_no': '1',
    'student_id': 'PRIVATE_CONTEXT',
  },
  published: noDate
      ? null
      : (published ?? DateTime.parse('2026-10-16T22:00:00+09:00')),
  body: body,
  bodyFetched: true,
);
Map<String, dynamic> inferred({
  String date = '2026-10-19',
  String time = '09:00',
  String id = 'T1',
  List<String> fields = const ['date', 'time', 'endDate', 'endTime'],
}) => {
  'title': '중간고사',
  'date': date,
  'time': time,
  'category': 'exam',
  'action': 'add',
  'sourceIds': ['P1'],
  'endDate': date,
  'endTime': '10:15',
  'condition': 'unspecified',
  'uncertainty': '',
  'inferredFields': fields,
  'timetableIds': [id],
};
Map<String, dynamic> response(List events) => {
  'candidates': [
    {
      'finishReason': 'STOP',
      'content': {
        'parts': [
          {
            'text': jsonEncode({'events': events}),
          },
        ],
      },
    },
  ],
};
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory dir;
  late Store store;
  Future<void> saveSlots({int start = 540}) async {
    await store.setMeta(
      'timetableEntries',
      jsonEncode([
        ClassSlot(
          courseKey: 'c1:1',
          course: '예시 수업',
          weekday: 1,
          start: start,
          end: 615,
        ).toJson(),
        const ClassSlot(
          courseKey: 'c1:1',
          course: '예시 수업',
          weekday: 3,
          start: 780,
          end: 855,
        ).toJson(),
        const ClassSlot(
          courseKey: 'other:2',
          course: 'OTHER_COURSE',
          weekday: 1,
          start: 480,
          end: 525,
          source: 'PRIVATE_PLAN',
        ).toJson(),
      ]),
    );
  }

  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    dir = await Directory.systemTemp.createTemp('ai-timetable-');
    await databaseFactory.setDatabasesPath(dir.path);
    store = await Store.open();
    await saveSlots();
    await store.setMeta('aiConsent', aiConsentVersion);
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          (c) async => 'synthetic-key',
        );
  });
  tearDown(() async {
    await store.db.close();
    await dir.delete(recursive: true);
  });
  test(
    'notice context uses publication time and only exact course/section, without raw portal context',
    () async {
      final context = await aiTimetableContext(
        store,
        notice: example(),
        now: DateTime.utc(2030),
      );
      expect(context['slots'], hasLength(2));
      expect(context['upcoming'].first['date'], '2026-10-19');
      expect(context['upcoming'].first['start'], '09:00');
      expect(jsonEncode(context), isNot(contains('OTHER_COURSE')));
      expect(jsonEncode(context), isNot(contains('PRIVATE_CONTEXT')));
      expect(jsonEncode(context), isNot(contains('PRIVATE_PLAN')));
    },
  );
  test(
    'next class handles same day before/after start and Sunday crossing in KST',
    () {
      expect(
        nextClassStart(DateTime.utc(2026, 10, 19, 8, 59), 1, 540),
        DateTime.utc(2026, 10, 19, 9),
      );
      expect(
        nextClassStart(DateTime.utc(2026, 10, 19, 9), 1, 540),
        DateTime.utc(2026, 10, 26, 9),
      );
      expect(
        nextClassStart(DateTime.utc(2026, 10, 18, 23, 59), 1, 540),
        DateTime.utc(2026, 10, 19, 9),
      );
    },
  );
  test(
    'next class inference has validated provenance and survives persistent candidate parsing',
    () async {
      final n = example(),
          context = await aiTimetableContext(store, notice: example());
      final c = parseAiResponse(
        response([inferred()]),
        n,
        timetable: context,
      ).single;
      expect(c.inferenceLabel, contains('시간표로 추정'));
      expect(c.description, contains('09:00–10:15'));
      expect(
        ScheduleCandidate.parse(
          c.toJson(),
          '${n.title}\n${n.body}',
        ).inferenceLabel,
        c.inferenceLabel,
      );
    },
  );
  test(
    'unknown slots, wrong weekday, later class, wrong clock, and unknown publication are rejected',
    () async {
      final n = example(),
          context = await aiTimetableContext(store, notice: example());
      for (final e in [
        inferred(id: 'OTHER'),
        inferred(date: '2026-10-20'),
        inferred(date: '2026-10-26'),
        inferred(time: '09:30'),
      ]) {
        expect(
          () => parseAiResponse(response([e]), n, timetable: context),
          throwsA(isA<AiFailure>()),
        );
      }
      final noDate = example(noDate: true);
      expect(
        () => parseAiResponse(
          response([inferred()]),
          noDate,
          timetable: context..['referenceAt'] = null,
        ),
        throwsA(isA<AiFailure>()),
      );
    },
  );
  test('explicit announcement clocks override timetable inference', () async {
    final n = example(body: '10월 19일 수업 시간에 시험을 봅니다. 시험 시작은 11:00입니다.');
    final context = await aiTimetableContext(store, notice: n);
    expect(
      () => parseAiResponse(
        response([
          inferred(fields: ['time', 'endTime']),
        ]),
        n,
        timetable: context,
      ),
      throwsA(isA<AiFailure>()),
    );
  });
  test(
    'no timetable and ambiguous same-name sections do not allow inference',
    () async {
      await store.setMeta(
        'timetableEntries',
        jsonEncode([
          const ClassSlot(
            courseKey: 'a:1',
            course: '예시 수업',
            weekday: 1,
            start: 540,
            end: 615,
          ).toJson(),
          const ClassSlot(
            courseKey: 'a:2',
            course: '예시 수업',
            weekday: 1,
            start: 540,
            end: 615,
          ).toJson(),
        ]),
      );
      final n = CampusNotice(
        id: 'ambiguous',
        title: '공지',
        course: '예시 수업',
        context: {},
        body: example().body,
        bodyFetched: true,
      );
      final context = await aiTimetableContext(store, notice: n);
      expect(context['slots'], isEmpty);
      expect(
        () => parseAiResponse(response([inferred()]), n, timetable: context),
        throwsA(isA<AiFailure>()),
      );
    },
  );
  test(
    'chat context uses current time and course filtering; sharing-off excludes timetable',
    () async {
      final data = jsonDecode(await chatContext(store, courseId: 'c1:1'));
      expect(data['timetable']['slots'], hasLength(2));
      await store.setMeta('aiChatConsent', '1');
      await askCampusAi(
        store,
        [],
        '다음 수업은?',
        includeData: false,
        transport: (k, r) async {
          expect(jsonEncode(r), isNot(contains('예시 수업')));
          return {
            'candidates': [
              {
                'finishReason': 'STOP',
                'content': {
                  'parts': [
                    {'text': '시간표를 공유하면 확인할 수 있어요.'},
                  ],
                },
              },
            ],
          };
        },
      );
    },
  );
  test(
    'timetable change invalidates a notice cache and queue, preserving user exclusions',
    () async {
      final n = example();
      await store.saveNotice(n);
      await store.setMeta('aiAuto', 'yes');
      await store.setMeta('aiScope', 'all');
      final context = await aiTimetableContext(store, notice: n);
      await store.setMeta(
        'aiTimetableHash:${n.id}',
        timetableContextHash(context),
      );
      await store.setMeta('aiCache:${n.id}:${noticeFingerprint(n)}', '[]');
      await store.setMeta(
        'aiQueue:${n.id}',
        jsonEncode({'status': 'empty', 'fingerprint': noticeFingerprint(n)}),
      );
      await saveSlots(start: 570);
      await enqueueNotices(store);
      expect(
        jsonDecode((await store.meta('aiQueue:${n.id}'))!)['status'],
        'pending',
      );
      await store.setMeta(
        'aiQueue:${n.id}',
        jsonEncode({'status': 'excluded', 'fingerprint': noticeFingerprint(n)}),
      );
      await saveSlots(start: 580);
      await enqueueNotices(store);
      expect(
        jsonDecode((await store.meta('aiQueue:${n.id}'))!)['status'],
        'excluded',
      );
    },
  );
  test(
    'generate synthetic live request; replay saved real response if present',
    () async {
      final n = example(),
          context = await aiTimetableContext(store, notice: example());
      final dir = Directory('../../outputs/tests/ai-timetable-live')
        ..createSync(recursive: true);
      File('${dir.path}/fixture.json').writeAsStringSync(
        jsonEncode({
          'notice': n.toJson()..['context'] = {},
          'timetable': context,
        }),
      );
      File(
        '${dir.path}/request.json',
      ).writeAsStringSync(jsonEncode(aiRequest(n, timetable: context)));
      final explicit = example(body: '시험은 10월 21일 13:10부터 14:10까지입니다.');
      File(
        '${dir.path}/request-none.json',
      ).writeAsStringSync(jsonEncode(aiRequest(explicit)));
      final none = File('${dir.path}/response-none.json');
      if (none.existsSync()) {
        final events = parseAiResponse(
          Map<String, dynamic>.from(jsonDecode(none.readAsStringSync())),
          explicit,
        );
        expect(events.single.date, '2026-10-21');
        expect(events.single.time, '13:10');
        expect(events.single.inferenceLabel, isEmpty);
      }
      final raw = File('${dir.path}/response.json');
      if (raw.existsSync()) {
        final events = parseAiResponse(
          Map<String, dynamic>.from(jsonDecode(raw.readAsStringSync())),
          n,
          timetable: context,
        );
        expect(events, hasLength(1));
        expect(events.single.date, '2026-10-19');
        expect(events.single.time, '09:00');
        expect(events.single.inferenceLabel, contains('시간표로 추정'));
        File(
          '${dir.path}/validated.json',
        ).writeAsStringSync(jsonEncode(events.map((e) => e.toJson()).toList()));
      }
    },
  );
}

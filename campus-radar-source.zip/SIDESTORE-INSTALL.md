# iPhone에 캠퍼스레이더 설치하기 (iloader + SideStore)

소규모 테스트 배포용 안내예요. App Store 배포가 아니라, 내 Apple 계정으로 앱에 직접 서명해서 설치하는 방식이에요.
**처음 한 번만 PC가 필요하고**, 그 뒤 설치·업데이트·서명 갱신은 iPhone에서 해요.

> 이 경로는 아직 실제 iPhone으로 끝까지 검증하지 않았어요. 아래 "확인 상태"를 같이 봐 주세요.

## 준비물
- iPhone: **iOS 15 이상**, 기기 암호 설정, Wi-Fi
- PC: Windows 8 이상(또는 macOS·Linux), 데이터 전송이 되는 USB 케이블
- Apple 계정: 무료 계정도 돼요. 평소 쓰는 계정 대신 **설치용 보조 계정**을 권장해요.

## 1. PC 준비 (처음 한 번)
1. **iTunes 설치(Windows):** iloader가 iPhone과 통신하는 데 필요해요. macOS는 따로 필요 없어요.
2. **iloader 내려받기:** 공식 배포처는 [github.com/nab138/iloader](https://github.com/nab138/iloader/releases)와 iloader.app뿐이에요. 다른 사이트에서 받지 마세요.

## 2. iPhone 준비
1. App Store에서 **LocalDevVPN**을 설치해요. SideStore가 설치·업데이트·서명 갱신을 할 때 이 VPN이 켜져 있어야 해요.
2. iPhone을 USB로 PC에 연결하고 "이 컴퓨터를 신뢰"를 눌러요.

## 3. SideStore 설치 (iloader)
1. iloader를 열고 Apple 계정으로 로그인해요.
2. **Install SideStore**를 선택해요. 인증서 가져오기와 페어링 파일 배치도 iloader가 자동으로 해요.
3. iPhone 설정 → 일반 → **VPN 및 기기 관리**에서 내 Apple 계정의 개발자 앱을 신뢰해요.
4. 설정 → 개인정보 보호 및 보안 → **개발자 모드**를 켜고(iOS 16 이상), 재시작 안내를 따라요.
5. 이제 PC 연결은 필요 없어요.

## 4. 캠퍼스레이더 설치 (SideStore)
1. **LocalDevVPN을 켜고** SideStore를 열어요.
2. Sources → **+** → 아래 주소를 추가해요.
   `https://github.com/lemoncube7/campus-radar/releases/download/ios-preview/altstore-source.json`
3. 캠퍼스레이더를 찾아 설치해요. **위젯 확장을 유지할지 물으면 유지**해요. 빼면 홈·잠금화면 위젯이 나타나지 않아요.
4. 캠퍼스레이더를 열어 학교 계정을 연결하고, 알림을 허용하고, 백그라운드 앱 새로 고침을 켜요.

## 5. 7일마다 서명 갱신
- 무료 Apple 계정으로 서명한 앱은 **7일 뒤 실행되지 않아요.**
- 만료 전에 LocalDevVPN을 켜고 SideStore → My Apps → **Refresh All**을 눌러요(Wi-Fi 필요).
- 앱 데이터(학교 계정, 수집 자료)는 갱신해도 그대로 남아요.

## 6. 업데이트
- 새 버전이 나오면 SideStore의 My Apps에 업데이트가 표시돼요.
- 캠퍼스레이더의 업데이트 화면에서 "업데이트"를 누르면 SideStore의 소스 화면이 열려요. SideStore가 없으면 AltStore Classic을 열어요.
- **기존 앱을 지우지 말고** 업데이트로 설치해요. 지우면 학교 계정과 자료가 사라져요.

## 무료 Apple 계정 제한
- **동시에 쓸 수 있는 앱은 3개**예요(SideStore 포함). 캠퍼스레이더까지 2개를 써요.
- **7일 동안 만들 수 있는 App ID는 10개**예요. 캠퍼스레이더는 앱과 위젯 확장으로 2개를 써요. 앱을 여러 번 지웠다 다시 설치하면 이 한도에 걸릴 수 있어요.

## 문제가 생기면
- **설치·갱신이 안 될 때:** LocalDevVPN이 켜져 있는지, Wi-Fi에 연결돼 있는지 확인해요.
- **iOS를 업데이트하거나 기기를 초기화한 뒤 SideStore가 동작하지 않을 때:** 페어링 파일이 무효가 됐을 수 있어요. PC에서 iloader를 열어 페어링 파일을 다시 배치해요.
- **위젯이 안 보일 때:** 설치할 때 위젯 확장을 뺐는지 확인하고, 다시 설치하면서 유지해요.
- 캠퍼스레이더 → 설정 → 기록·지원 → 활동 로그를 **로그 저장·공유**로 보내 주세요.

## 확인 상태 (2026-11-04)
| 항목 | 상태 |
|---|---|
| 소스 형식 | SideStore와 AltStore Classic이 같은 AltStore 형식 소스를 읽어요(기존 `altstore-source.json` 재사용) |
| 앱 업데이트 버튼 → SideStore | `sidestore://source?url=` 스킴을 먼저 열고, 안 되면 `altstore-classic://`을 열어요. **SideStore 스킴은 공식 문서가 아니라 커뮤니티 자료로 확인한 값이라 실기기 확인이 필요해요** |
| iloader 설치·페어링 파일 | 공식 위키 기준 절차예요. 실기기 미검증 |
| 위젯 App Group 재매핑 | AltStore Classic에서는 이전에 확인했어요. SideStore에서는 미검증 |
| 백그라운드 수집·알림 | iOS가 실행 시각을 정해요. 보장되지 않아요 |

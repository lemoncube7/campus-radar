import 'package:flutter/material.dart';

/// Modern mobile hero briefing card for the 'Today' home tab.
/// Presents the day's critical tasks, sync status, and quick actions at a glance.
class TodayHeroBriefing extends StatelessWidget {
  final DateTime now;
  final int urgentCount;
  final int todayCount;
  final int pendingCount;
  final String? lastSyncTime;
  final bool isSyncing;
  final String? syncPhase;
  final VoidCallback? onSyncPressed;
  final VoidCallback? onUrgentPressed;

  const TodayHeroBriefing({
    super.key,
    required this.now,
    required this.urgentCount,
    required this.todayCount,
    required this.pendingCount,
    this.lastSyncTime,
    this.isSyncing = false,
    this.syncPhase,
    this.onSyncPressed,
    this.onUrgentPressed,
  });

  static const _weekdays = ['월', '화', '수', '목', '금', '토', '일'];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final kst = now.toUtc().add(const Duration(hours: 9));
    final weekdayStr = _weekdays[kst.weekday - 1];

    final hasUrgent = urgentCount > 0;
    final primaryContainer = hasUrgent
        ? colorScheme.errorContainer
        : colorScheme.primaryContainer;
    final onPrimaryContainer = hasUrgent
        ? colorScheme.onErrorContainer
        : colorScheme.onPrimaryContainer;

    return Container(
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: colorScheme.outlineVariant.withValues(alpha: 0.45),
        ),
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.04),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                colorScheme.surfaceContainerLow,
                colorScheme.surfaceContainerLowest,
              ],
            ),
          ),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Top row: Date and Sync Status / Action
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 6,
                              height: 6,
                              decoration: BoxDecoration(
                                color: colorScheme.primary,
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 6),
                            Flexible(
                              child: Text(
                                '${kst.month}월 ${kst.day}일 $weekdayStr요일',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: theme.textTheme.labelMedium?.copyWith(
                                  color: colorScheme.primary,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: -0.2,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '오늘의 학업 요약',
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w800,
                            fontSize: 20,
                            letterSpacing: -0.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  // Sync button / spinner
                  _SyncPill(
                    isSyncing: isSyncing,
                    syncPhase: syncPhase,
                    lastSyncTime: lastSyncTime,
                    onTap: onSyncPressed,
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // Middle row: Urgent deadline callout banner (if any)
              if (hasUrgent)
                InkWell(
                  onTap: onUrgentPressed,
                  borderRadius: BorderRadius.circular(16),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 12,
                    ),
                    decoration: BoxDecoration(
                      color: primaryContainer.withValues(alpha: 0.85),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: onPrimaryContainer.withValues(alpha: 0.15),
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: onPrimaryContainer.withValues(alpha: 0.12),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            Icons.alarm_on_rounded,
                            size: 18,
                            color: onPrimaryContainer,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '24시간 이내 마감 $urgentCount개',
                                style: theme.textTheme.titleSmall?.copyWith(
                                  color: onPrimaryContainer,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: -0.2,
                                ),
                              ),
                              Text(
                                '놓치지 않도록 지금 바로 확인하세요',
                                style: theme.textTheme.bodySmall?.copyWith(
                                  fontSize: 11,
                                  color: onPrimaryContainer.withValues(alpha: 0.8),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          size: 13,
                          color: onPrimaryContainer.withValues(alpha: 0.7),
                        ),
                      ],
                    ),
                  ),
                ),

              if (hasUrgent) const SizedBox(height: 12),

              // Stat Counter Row: Today Due / Total Pending
              Row(
                children: [
                  Expanded(
                    child: _StatBox(
                      title: '오늘 마감',
                      value: '$todayCount개',
                      icon: Icons.calendar_today_rounded,
                      highlight: todayCount > 0,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _StatBox(
                      title: '미완료 할 일',
                      value: '$pendingCount개',
                      icon: Icons.checklist_rounded,
                      highlight: false,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatBox extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final bool highlight;

  const _StatBox({
    required this.title,
    required this.value,
    required this.icon,
    required this.highlight,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final bgColor = highlight
        ? colorScheme.tertiaryContainer.withValues(alpha: 0.5)
        : colorScheme.surfaceContainerHighest.withValues(alpha: 0.5);
    final iconColor = highlight
        ? colorScheme.tertiary
        : colorScheme.primary;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: highlight
              ? colorScheme.tertiary.withValues(alpha: 0.25)
              : colorScheme.outlineVariant.withValues(alpha: 0.25),
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              color: (highlight ? colorScheme.tertiary : colorScheme.primary)
                  .withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              icon,
              size: 18,
              color: iconColor,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: colorScheme.onSurfaceVariant,
                    fontSize: 11,
                    letterSpacing: -0.1,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.4,
                    color: highlight
                        ? colorScheme.onTertiaryContainer
                        : colorScheme.onSurface,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SyncPill extends StatelessWidget {
  final bool isSyncing;
  final String? syncPhase;
  final String? lastSyncTime;
  final VoidCallback? onTap;

  const _SyncPill({
    required this.isSyncing,
    this.syncPhase,
    this.lastSyncTime,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    if (isSyncing) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: colorScheme.primary.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 12,
              height: 12,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: colorScheme.primary,
              ),
            ),
            const SizedBox(width: 6),
            Text(
              syncPhase ?? '확인 중',
              style: theme.textTheme.labelSmall?.copyWith(
                color: colorScheme.primary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      );
    }

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.sync_rounded,
              size: 14,
              color: colorScheme.onSurfaceVariant,
            ),
            const SizedBox(width: 4),
            Text(
              lastSyncTime != null ? '동기화 완료' : '지금 확인',
              style: theme.textTheme.labelSmall?.copyWith(
                color: colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/demo_state.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/settings/permissions_page.dart';
import 'package:campus_radar/settings/widget_settings_page.dart';

const setupChecklistDismissedKey = 'setupChecklistDismissed';
const setupWidgetSeenKey = 'setupWidgetSeen';

class SetupStep {
  final String id, title, hint;
  final IconData icon;
  final bool done;
  const SetupStep(this.id, this.title, this.hint, this.icon, this.done);
}

/// Pure status rules, kept separate from the widget for tests.
List<SetupStep> setupSteps({
  required bool notificationsAllowed,
  required List<String> powerWarnings,
  required bool widgetSeen,
  required bool hasTimetable,
  required bool hasGeminiKey,
  bool android = true,
}) => [
  SetupStep(
    'notify',
    '알림 허용',
    '마감·새 과제를 놓치지 않게 알려 줘요',
    Icons.notifications_active_outlined,
    notificationsAllowed,
  ),
  if (android)
    SetupStep(
      'battery',
      '배터리 제한 풀기',
      '앱을 안 열어도 자동으로 확인해요',
      Icons.battery_charging_full_outlined,
      powerWarnings.isEmpty,
    ),
  SetupStep(
    'widget',
    '홈 화면 위젯 추가',
    '앱을 안 열고 다음 수업·마감을 봐요',
    Icons.widgets_outlined,
    widgetSeen,
  ),
  SetupStep(
    'timetable',
    '시간표 만들기',
    '다음 수업·강의실과 휴강을 보여 줘요',
    Icons.calendar_view_week_outlined,
    hasTimetable,
  ),
  SetupStep(
    'gemini',
    '공지에서 일정 찾기 켜기',
    '공지 속 시험·휴강을 AI가 모아 줘요 (선택)',
    Icons.auto_awesome_outlined,
    hasGeminiKey,
  ),
];

/// "처음 설정" card on the today screen: the few settings without which the
/// app silently does less. Disappears when everything is done or dismissed;
/// a battery problem stays visible as one line because it stops collection.
class SetupChecklistCard extends StatefulWidget {
  final List<String> powerWarnings;
  final int revision;
  const SetupChecklistCard({
    super.key,
    this.powerWarnings = const [],
    this.revision = 0,
  });

  @override
  State<SetupChecklistCard> createState() => _SetupChecklistCardState();
}

class _SetupChecklistCardState extends State<SetupChecklistCard> {
  List<SetupStep>? steps;
  bool dismissed = false;
  bool expanded = false;

  @override
  void initState() {
    super.initState();
    demoModeNotifier.addListener(_onDemoChanged);
    load();
  }

  @override
  void dispose() {
    demoModeNotifier.removeListener(_onDemoChanged);
    super.dispose();
  }

  void _onDemoChanged() {
    if (mounted) {
      if (!isDemoActive) {
        load();
      } else {
        setState(() {});
      }
    }
  }

  @override
  void didUpdateWidget(SetupChecklistCard old) {
    super.didUpdateWidget(old);
    if (old.revision != widget.revision ||
        old.powerWarnings.length != widget.powerWarnings.length) {
      load();
    }
  }

  Future<void> load() async {
    if (isDemoActive) return;
    try {
      final prefs = await SharedPreferences.getInstance();
      final store = await Store.open();
      bool allowed, timetable;
      try {
        allowed = await store.meta(MetaKey.notificationPermission) == 'yes';
        final raw = await store.meta(MetaKey.timetableEntries);
        timetable = raw != null && (jsonDecode(raw) as List).isNotEmpty;
      } finally {
        await store.db.close();
      }
      final key = await credentials.read(key: 'geminiApiKey');
      if (!mounted) return;
      setState(() {
        dismissed = prefs.getBool(setupChecklistDismissedKey) ?? false;
        steps = setupSteps(
          notificationsAllowed: allowed,
          powerWarnings: widget.powerWarnings,
          widgetSeen: prefs.getBool(setupWidgetSeenKey) ?? false,
          hasTimetable: timetable,
          hasGeminiKey: key != null && key.isNotEmpty,
          android: Platform.isAndroid,
        );
      });
    } catch (_) {
      // Optional guidance; never block the today screen.
    }
  }

  Future<void> open(SetupStep step) async {
    switch (step.id) {
      case 'notify':
      case 'battery':
        await Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const PermissionsPage()),
        );
      case 'widget':
        (await SharedPreferences.getInstance()).setBool(
          setupWidgetSeenKey,
          true,
        );
        if (!mounted) return;
        await Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const WidgetSettingsPage()),
        );
      case 'timetable':
        await navigateTo(context, const TimetableDestination());
      case 'gemini':
        await navigateTo(context, const AiSettingsDestination());
    }
    await load();
  }

  @override
  Widget build(BuildContext context) {
    if (isDemoActive) return const SizedBox.shrink();
    final list = steps;
    if (list == null) return const SizedBox.shrink();
    final theme = Theme.of(context);
    final colors = theme.colorScheme;
    final left = list.where((s) => !s.done).toList();
    if (left.isEmpty) return const SizedBox.shrink();
    if (dismissed) {
      final battery = left.where((s) => s.id == 'battery').firstOrNull;
      if (battery == null) return const SizedBox.shrink();
      return Card(
        color: colors.errorContainer,
        child: ListTile(
          leading: Icon(battery.icon, color: colors.onErrorContainer),
          title: Text(battery.title),
          subtitle: Text(widget.powerWarnings.firstOrNull ?? battery.hint),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => open(battery),
        ),
      );
    }
    final done = list.length - left.length;
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 8, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '캠퍼스레이더 제대로 쓰기 ($done/${list.length})',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () async {
                    await (await SharedPreferences.getInstance()).setBool(
                      setupChecklistDismissedKey,
                      true,
                    );
                    if (mounted) setState(() => dismissed = true);
                  },
                  child: const Text('나중에'),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(right: 8, bottom: 4),
              child: LinearProgressIndicator(
                value: done / list.length,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            for (final s in expanded ? list : left.take(2))
              ListTile(
                dense: true,
                contentPadding: const EdgeInsets.only(right: 8),
                leading: Icon(
                  s.done ? Icons.check_circle : s.icon,
                  color: s.done ? colors.primary : colors.onSurfaceVariant,
                ),
                title: Text(
                  s.title,
                  style: s.done
                      ? TextStyle(
                          decoration: TextDecoration.lineThrough,
                          color: colors.onSurfaceVariant,
                        )
                      : null,
                ),
                subtitle: s.done ? null : Text(s.hint),
                trailing: s.done ? null : const Icon(Icons.chevron_right),
                onTap: s.done ? null : () => open(s),
              ),
            if (!expanded && list.length > 2)
              TextButton(
                onPressed: () => setState(() => expanded = true),
                child: Text(
                  left.length > 2 ? '나머지 ${left.length - 2}개 보기' : '전체 보기',
                ),
              ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:campus_radar/updates/updates.dart' show appVersion;

const whatsNewSeenKey = 'whatsNewSeenVersion';

class WhatsNewItem {
  final IconData icon;
  final String title, body;
  const WhatsNewItem(this.icon, this.title, this.body);
}

/// The release [whatsNew] describes. The sheet only appears when this equals
/// [appVersion], so a release that forgets to update the list shows nothing
/// instead of an older release's features.
const whatsNewVersion = '0.6.5';

/// Features worth pointing out after an update to [whatsNewVersion]. When
/// releasing, replace the items and bump [whatsNewVersion] together.
const whatsNew = <WhatsNewItem>[
  WhatsNewItem(
    Icons.auto_awesome_rounded,
    'AI가 일정·휴강을 바로 반영',
    '공지에서 찾은 명확한 일정과 휴강을 승인 없이 바로 반영해요. AI 검토함에서 언제든 반영을 취소할 수 있어요.',
  ),
  WhatsNewItem(
    Icons.event_busy_rounded,
    '휴강은 지우지 않고 표시',
    '휴강으로 인식된 수업도 시간표와 알림에 그대로 남기고 "휴강"으로 표시해요. 누르면 근거 공지로 이동해요.',
  ),
  WhatsNewItem(
    Icons.campaign_rounded,
    '앱 공지',
    '중요한 안내를 앱 안에서 알려 드려요. 지난 공지는 더보기에서 다시 볼 수 있어요.',
  ),
  WhatsNewItem(
    Icons.cleaning_services_rounded,
    'Drive 겹친 폴더 정리',
    '0.6.3에서 Drive에 겹쳐 생긴 과목 폴더와 파일을 한 번 정리해 휴지통으로 옮겨요.',
  ),
];

/// Whether the sheet has anything to say for the running [version].
bool whatsNewApplies(String version) =>
    whatsNew.isNotEmpty && whatsNewVersion == version;

/// Shows the sheet once per version for people updating from an earlier
/// one. A fresh install only records the version (the setup checklist
/// introduces the app instead).
Future<void> maybeShowWhatsNew(
  BuildContext context, {
  required bool existingUser,
}) async {
  if (!whatsNewApplies(appVersion)) return;
  final SharedPreferences prefs;
  try {
    prefs = await SharedPreferences.getInstance();
  } catch (_) {
    return;
  }
  final seen = prefs.getString(whatsNewSeenKey);
  if (seen == appVersion) return;
  await prefs.setString(whatsNewSeenKey, appVersion);
  if (!existingUser || !context.mounted) return;
  await showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (sheet) => SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '$appVersion에서 새로 생겼어요',
              style: Theme.of(sheet).textTheme.titleLarge,
            ),
            const SizedBox(height: 12),
            for (final item in whatsNew)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(item.icon),
                title: Text(item.title),
                subtitle: Text(item.body),
              ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => Navigator.pop(sheet),
                child: const Text('확인'),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

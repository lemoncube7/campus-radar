import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:campus_radar/campus/services.dart' show reconcile;
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/demo_mode.dart';
import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/core/notification_gateway.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/export/drive_connection_page.dart';
import 'package:campus_radar/home/setup_checklist.dart';
import 'package:campus_radar/schedule/calendar_settings_page.dart';
import 'package:campus_radar/schedule/timetable_page.dart';

const onboardingDoneKey = 'onboardingDone';

enum SetupPreset { all, essential, keep }

/// What each preset turns on. Kept as data so tests and the summary screen
/// show exactly what was applied.
class PresetPlan {
  final List<int> deadlineLeads; // minutes before the deadline
  final bool classAlerts, midnightSummary, dailySummary;
  final int classLead, dailyHour;
  const PresetPlan({
    required this.deadlineLeads,
    required this.classAlerts,
    required this.midnightSummary,
    required this.dailySummary,
    this.classLead = 30,
    this.dailyHour = 18,
  });

  List<String> get summary => [
    '마감 알림: ${deadlineLeads.map((m) => m % 1440 == 0 ? '${m ~/ 1440}일 전' : '${m ~/ 60}시간 전').join(' · ')}',
    if (classAlerts) '수업 $classLead분 전 알림',
    if (midnightSummary) '자정에 오늘 수업·과제 요약',
    if (dailySummary) '매일 $dailyHour:00 하루 요약 알림',
  ];
}

PresetPlan presetPlan(SetupPreset p) => switch (p) {
  SetupPreset.all => const PresetPlan(
    deadlineLeads: [1440, 180],
    classAlerts: true,
    midnightSummary: true,
    dailySummary: true,
  ),
  SetupPreset.essential => const PresetPlan(
    deadlineLeads: [1440],
    classAlerts: true,
    midnightSummary: false,
    dailySummary: false,
  ),
  SetupPreset.keep => const PresetPlan(
    deadlineLeads: [],
    classAlerts: false,
    midnightSummary: false,
    dailySummary: false,
  ),
};

/// Applies a preset through the same storage/native calls the individual
/// settings screens use. Each part is independent: one failure (e.g. no
/// exact-alarm permission) does not stop the others.
Future<List<String>> applyPreset(PresetPlan plan) async {
  final failed = <String>[];
  var saved = false;
  Object? lastError;
  for (var attempt = 0; attempt < 3 && !saved; attempt++) {
    try {
      final s = await Store.open();
      try {
        await s.setMeta(
          MetaKey.deadlineLeadMinutes,
          jsonEncode(plan.deadlineLeads.toList()..sort()),
        );
        saved = true;
        await s.log('notification', '시작 설정 적용', plan.summary.join(' · '));
        try {
          await reconcile(s);
        } catch (e) {
          await systemLog(
            '시작 설정: 알림 다시 예약 지연',
            '설정은 저장했어요. 다음 확인 때 다시 예약해요.',
            kind: 'notification',
            error: e,
          );
        }
      } finally {
        await s.db.close();
      }
    } catch (e) {
      lastError = e;
      await Future<void>.delayed(Duration(seconds: 1 + attempt));
    }
  }
  if (!saved) {
    failed.add('마감 알림');
    await systemLog(
      '시작 설정: 마감 알림 저장 실패',
      '더보기 → 알림에서 다시 설정해 주세요.',
      kind: 'notification',
      error: lastError,
    );
  }
  try {
    final now = DateTime.now();
    final until = DateTime(
      now.year,
      now.month <= 6 ? 6 : 12,
      now.month <= 6 ? 30 : 31,
    );
    await bridge.invokeNative(NativeMethod.setTimetableSettings, {
      'enabled': plan.classAlerts,
      'midnight': plan.midnightSummary,
      'lead': plan.classLead,
      'countdownAfter': 0,
      'until':
          '${until.year}-${until.month.toString().padLeft(2, '0')}-${until.day.toString().padLeft(2, '0')}',
    });
  } catch (_) {
    failed.add('수업 알림');
  }
  try {
    await bridge.invokeNative(NativeMethod.setDailySettings, {
      'enabled': plan.dailySummary,
      'hour': plan.dailyHour,
      'minute': 0,
    });
  } catch (_) {
    failed.add('하루 요약');
  }
  return failed;
}

Future<bool> _notificationsAllowed() async {
  if (Platform.isAndroid) {
    return await notifications
            .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin
            >()
            ?.areNotificationsEnabled() ??
        false;
  }
  if (Platform.isIOS) {
    return (await notifications
                .resolvePlatformSpecificImplementation<
                  IOSFlutterLocalNotificationsPlugin
                >()
                ?.checkPermissions())
            ?.isEnabled ??
        false;
  }
  return true;
}

Future<bool> _batteryOk() async {
  if (!Platform.isAndroid) return true;
  try {
    final s = await bridge.invokeNativeMap<String, dynamic>(
      NativeMethod.backgroundStatus,
    );
    return s?['batteryExempt'] == true && s?['backgroundRestricted'] != true;
  } catch (_) {
    return false;
  }
}

/// Required first-run setup wizard:
/// 1. Preset (all / essential / keep)
/// 2. Guide cards (overview of features)
/// 3. Permissions (notify & battery)
/// 4. Academic tools (Timetable & Home Widget)
/// 5. AI & Cloud (Gemini API key, Google Drive & Device Calendar)
/// 6. Done (summary & start)
class OnboardingPage extends StatefulWidget {
  final bool allowDemo;
  final Future<void> Function()? onStartDemo;
  const OnboardingPage({
    super.key,
    this.allowDemo = true,
    this.onStartDemo,
  });
  @override
  State<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage>
    with WidgetsBindingObserver {
  int step = 0;
  SetupPreset? preset;
  int guidePage = 0;
  final guide = PageController();
  bool notifyOk = false, batteryOk = false, batteryTried = false;
  bool applying = false;
  List<String> failed = const [];

  // Step 4: Academic tools
  bool timetableOk = false;
  bool widgetPinned = false;

  // Step 5: AI & Cloud
  final geminiController = TextEditingController();
  bool geminiOk = false;
  String? geminiMessage;
  bool driveOk = false;
  bool driveAccountOnly = false; // account linked but auto upload off
  String? driveEmail;
  bool calendarAuto = false;
  bool calendarMissing = false; // no device calendar found

  static const guideCards = [
    (
      Icons.radar,
      '알아서 모아요',
      '사이버캠퍼스의 과제·영상·자료·공지를 앱이 주기적으로 확인해요. 앱을 열지 않아도 돼요.',
    ),
    (
      Icons.notifications_active_outlined,
      '놓치기 전에 알려요',
      '새 과제, 마감 몇 시간 전, 수업 전에 알림이 와요. 알림의 [할 일 목록]을 누르면 바로 이동해요.',
    ),
    (
      Icons.event_busy_outlined,
      '공지 속 휴강도 찾아요',
      '개인 Gemini 키를 연결하면 공지에서 시험·휴강을 찾아 검토함에 모아요. 확인하면 시간표에 반영돼요.',
    ),
    (
      Icons.search,
      '모르면 검색하세요',
      '더보기 맨 위 "기능 찾기"에 "위젯", "휴강", "드라이브"처럼 단어를 치면 설정으로 바로 가요.',
    ),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    refreshAll();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    guide.dispose();
    geminiController.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) refreshAll();
  }

  Future<void> refreshAll() async {
    final n = await _notificationsAllowed();
    final b = await _batteryOk();
    if (mounted) {
      setState(() {
        notifyOk = n;
        batteryOk = b;
      });
    }
    await checkTimetable();
    await checkGeminiKey();
    await checkDrive();
    await checkCalendar();
  }

  Future<void> checkTimetable() async {
    try {
      final s = await Store.open();
      try {
        final raw = await s.meta(MetaKey.timetableEntries);
        final ok = raw != null && (jsonDecode(raw) as List).isNotEmpty;
        if (mounted) setState(() => timetableOk = ok);
      } finally {
        await s.db.close();
      }
    } catch (_) {}
  }

  Future<void> checkGeminiKey() async {
    if (isDemoActive) return;
    try {
      final key = await credentials.read(key: 'geminiApiKey');
      if (mounted) setState(() => geminiOk = key != null && key.isNotEmpty);
    } catch (_) {}
  }

  /// Drive counts as connected only when an account was saved with
  /// `enabled: true` through DriveConnectionPage (driveConfigure), not when
  /// the Google account is merely authorized.
  Future<void> checkDrive() async {
    try {
      final rows =
          (await bridge.invokeNativeList<dynamic>(NativeMethod.driveAccounts) ??
                  [])
              .map((r) => Map<String, dynamic>.from(r as Map))
              .toList();
      final enabled = rows.where((r) => r['enabled'] == true).toList();
      if (mounted) {
        setState(() {
          driveOk = enabled.isNotEmpty;
          driveAccountOnly = enabled.isEmpty && rows.isNotEmpty;
          driveEmail = enabled.isEmpty
              ? null
              : enabled.first['email'] as String? ?? '연결됨';
        });
      }
    } catch (_) {}
  }

  Future<void> checkCalendar() async {
    try {
      final settings =
          await bridge.invokeNativeMap<String, dynamic>(
            NativeMethod.calendarSettings,
          ) ??
          {};
      var missing = false;
      if (settings['allowed'] == true) {
        final list =
            (await bridge.invokeNativeList<dynamic>(
                      NativeMethod.calendarList,
                    ) ??
                    [])
                .map((c) => Map<String, dynamic>.from(c as Map))
                .toList();
        missing = resolveTargetCalendar(list, settings['calendarId']) == null;
      }
      if (mounted) {
        setState(() {
          calendarAuto = settings['auto'] == true;
          calendarMissing = missing;
        });
      }
    } catch (_) {}
  }

  /// Same rule as CalendarSettingsPage: keep the linked calendar, else the
  /// device calendar, never an account calendar.
  Future<void> toggleCalendar(bool v) async {
    try {
      final settings =
          await bridge.invokeNativeMap<String, dynamic>(
            NativeMethod.calendarSettings,
          ) ??
          {};
      if (!v) {
        // Turn off automatic saving only; keep the linked calendar.
        await bridge.invokeNative(NativeMethod.calendarConfigure, {
          'calendarId': settings['calendarId'] ?? -1,
          'auto': false,
        });
        if (mounted) setState(() => calendarAuto = false);
        return;
      }
      final ok = await bridge.invokeNative<bool>(
        NativeMethod.calendarPermission,
      );
      if (ok != true) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('캘린더 권한 허용이 필요해요.')),
          );
        }
        return;
      }
      final cals =
          await bridge.invokeNativeList<dynamic>(NativeMethod.calendarList) ??
          [];
      final list = cals
          .map((c) => Map<String, dynamic>.from(c as Map))
          .toList();
      final target = resolveTargetCalendar(list, settings['calendarId']);
      if (target == null) {
        if (mounted) {
          setState(() => calendarMissing = true);
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('기기 캘린더를 찾지 못해 자동 저장을 켜지 않았어요.')),
          );
        }
        return;
      }
      await bridge.invokeNative(NativeMethod.calendarConfigure, {
        'calendarId': target['id'],
        'auto': true,
      });
      await bridge.invokeNative(NativeMethod.calendarSync);
      if (mounted) {
        setState(() {
          calendarAuto = true;
          calendarMissing = false;
        });
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('캘린더 설정을 바꾸지 못했어요. 캘린더 전송 설정에서 다시 시도해 주세요.'),
          ),
        );
      }
    }
  }

  bool get canNext => switch (step) {
    0 => preset != null,
    1 => guidePage == guideCards.length - 1,
    2 => notifyOk && (batteryOk || batteryTried),
    3 => true,
    4 => true,
    _ => !applying,
  };

  Future<void> next() async {
    if (step < 5) {
      if (step == 3) {
        // Leaving academic tools: mark widget as visited
        final prefs = await SharedPreferences.getInstance();
        await prefs.setBool(setupWidgetSeenKey, true);
      }
      setState(() => step++);
      if (step == 5) await finish();
      return;
    }
    await (await SharedPreferences.getInstance()).setBool(
      onboardingDoneKey,
      true,
    );
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> finish() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(setupWidgetSeenKey, true);
    if (preset == SetupPreset.keep) return;
    setState(() => applying = true);
    final result = await applyPreset(presetPlan(preset!));
    if (mounted) {
      setState(() {
        failed = result;
        applying = false;
      });
    }
  }

  bool lineFailed(String line) =>
      (failed.contains('마감 알림') && line.startsWith('마감 알림')) ||
      (failed.contains('수업 알림') &&
          (line.startsWith('수업') || line.startsWith('자정'))) ||
      (failed.contains('하루 요약') && line.startsWith('매일'));

  Widget presetCard(SetupPreset p, String title, String body) {
    final selected = preset == p;
    final colors = Theme.of(context).colorScheme;
    return Card(
      color: selected ? colors.primaryContainer : null,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => setState(() => preset = p),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Icon(
                selected ? Icons.radio_button_checked : Icons.radio_button_off,
                color: colors.primary,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 4),
                    if (p != SetupPreset.keep)
                      for (final line in presetPlan(p).summary) Text('· $line'),
                    if (body.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(body),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget permissionRow(
    String title,
    String why,
    bool ok,
    String action,
    Future<void> Function() onTap,
  ) => Card(
    child: ListTile(
      leading: Icon(
        ok ? Icons.check_circle : Icons.error_outline,
        color: ok
            ? Theme.of(context).colorScheme.primary
            : Theme.of(context).colorScheme.error,
      ),
      title: Text(title),
      subtitle: Text(why),
      trailing: ok
          ? null
          : FilledButton.tonal(onPressed: onTap, child: Text(action)),
    ),
  );

  Widget academicToolsStep() => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      Text('시간표와 홈 화면 위젯', style: Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height: 6),
      const Text('앱을 열지 않아도 다음 수업과 마감 과제를 한눈에 확인해요.'),
      const SizedBox(height: 16),
      Card(
        child: ListTile(
          leading: Icon(
            timetableOk ? Icons.check_circle : Icons.calendar_view_week_outlined,
            color: timetableOk
                ? Theme.of(context).colorScheme.primary
                : null,
          ),
          title: const Text('주간 시간표'),
          subtitle: Text(
            timetableOk
                ? '시간표가 이미 등록되어 있어요.'
                : '과목별 강의 시간을 불러와 주간 시간표를 만들어요.',
          ),
          trailing: FilledButton.tonal(
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const TimetablePage()),
              );
              await checkTimetable();
            },
            child: Text(timetableOk ? '확인하기' : '시간표 만들기'),
          ),
        ),
      ),
      const SizedBox(height: 8),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(
                    widgetPinned ? Icons.check_circle : Icons.widgets_outlined,
                    color: widgetPinned
                        ? Theme.of(context).colorScheme.primary
                        : null,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('홈 화면 위젯', style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 4),
                        const Text('바탕화면에서 다음 수업과 마감 현황을 바로 봐요.'),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              if (Platform.isAndroid)
                FilledButton.tonalIcon(
                  onPressed: () async {
                    try {
                      await bridge.invokeNative(NativeMethod.pinTimetableWidget);
                      if (mounted) setState(() => widgetPinned = true);
                    } catch (_) {}
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.setBool(setupWidgetSeenKey, true);
                  },
                  icon: const Icon(Icons.add_to_home_screen),
                  label: const Text('시간표 위젯 홈 화면에 추가'),
                ),
              const SizedBox(height: 8),
              const Text(
                '💡 과제 현황 위젯: 홈 화면 빈 공간 길게 누르기 → [위젯] → [캠퍼스레이더] 선택',
                style: TextStyle(fontSize: 12),
              ),
            ],
          ),
        ),
      ),
      const SizedBox(height: 12),
      const Text(
        '시간표와 위젯은 지금 바로 하지 않고 나중에 과목 탭과 홈 화면에서도 추가할 수 있어요.',
        style: TextStyle(color: Colors.grey),
      ),
    ],
  );

  Widget aiAndCloudStep() => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      Text('AI & 스마트 연동 (선택)', style: Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height: 6),
      const Text('공지 자동 분석과 외부 기기 연동을 위한 기능이에요. 지금 건너뛰어도 돼요.'),
      const SizedBox(height: 16),
      // 1. Gemini key
      Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(
                    geminiOk ? Icons.check_circle : Icons.auto_awesome_outlined,
                    color: geminiOk ? Theme.of(context).colorScheme.primary : null,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('공지 속 시험·휴강 AI 분석', style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 2),
                        const Text('개인 Google AI Studio(Gemini) 키 연결'),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              if (!geminiOk) ...[
                TextField(
                  controller: geminiController,
                  decoration: InputDecoration(
                    labelText: 'Gemini API 키 (AIzaSy...)',
                    hintText: 'Google AI Studio에서 발급받은 키',
                    border: const OutlineInputBorder(),
                    isDense: true,
                    errorText: geminiMessage,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    FilledButton.tonal(
                      onPressed: () async {
                        final key = geminiController.text.trim();
                        if (key.length < 20 || key.contains(RegExp(r'\s'))) {
                          setState(() => geminiMessage = 'API 키 형식을 확인해 주세요.');
                          return;
                        }
                        await credentials.write(key: 'geminiApiKey', value: key);
                        final store = await Store.open();
                        try {
                          await store.setAiSetting(AiSetting.aiConsent, aiConsentVersion);
                        } finally {
                          await store.db.close();
                        }
                        setState(() {
                          geminiOk = true;
                          geminiMessage = null;
                        });
                      },
                      child: const Text('키 등록하기'),
                    ),
                  ],
                ),
              ] else
                const Text('✓ Gemini API 키가 연결되어 있어요.'),
            ],
          ),
        ),
      ),
      const SizedBox(height: 8),
      // 2. Google Drive
      Card(
        child: ListTile(
          leading: Icon(
            driveOk ? Icons.check_circle : Icons.cloud_outlined,
            color: driveOk ? Theme.of(context).colorScheme.primary : null,
          ),
          title: const Text('Google Drive 연결'),
          subtitle: Text(
            driveOk
                ? '자동 전송 켜짐 (${driveEmail ?? "계정 연결됨"})'
                : driveAccountOnly
                ? '계정은 연결됐지만 자동 전송이 꺼져 있어요. 전송 범위와 동의를 설정해 주세요.'
                : 'PC 드라이브 모드 및 외부 LLM 과제 분석용 백업',
          ),
          trailing: FilledButton.tonal(
            // Consent and scope live in DriveConnectionPage; reuse it so
            // driveConfigure/prepareDriveSnapshot actually run.
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const DriveConnectionPage()),
              );
              await checkDrive();
            },
            child: Text(driveOk ? '설정 보기' : '연결하기'),
          ),
        ),
      ),
      const SizedBox(height: 8),
      // 3. Device Calendar (fixed to device calendar)
      Card(
        child: SwitchListTile(
          secondary: const Icon(Icons.event_available_outlined),
          title: const Text('스마트폰 기본 캘린더에 마감 등록'),
          subtitle: Text(
            calendarMissing
                ? '기기 캘린더를 찾지 못했어요. 외부 계정 캘린더에는 자동으로 저장하지 않아요.'
                : '기기 로컬 캘린더에 과제 마감 일정을 자동 저장해요.',
          ),
          value: calendarAuto,
          onChanged: calendarMissing && !calendarAuto ? null : toggleCalendar,
        ),
      ),
    ],
  );

  Widget summaryStep() => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      Text(
        applying ? '설정을 적용하고 있어요…' : '준비 끝!',
        style: Theme.of(context).textTheme.headlineSmall,
      ),
      const SizedBox(height: 12),
      if (applying) const LinearProgressIndicator(),
      if (!applying) ...[
        if (preset == SetupPreset.keep)
          const ListTile(
            leading: Icon(Icons.check),
            title: Text('알림 설정은 바꾸지 않았어요.'),
          ),
        if (preset != SetupPreset.keep)
          for (final line in presetPlan(preset!).summary)
            ListTile(
              dense: true,
              leading: lineFailed(line)
                  ? Icon(
                      Icons.warning_amber_rounded,
                      color: Theme.of(context).colorScheme.error,
                    )
                  : Icon(
                      Icons.check,
                      color: Theme.of(context).colorScheme.primary,
                    ),
              title: Text(line),
            ),
        if (failed.isNotEmpty)
          Text(
            '${failed.join(', ')} 설정은 적용하지 못했어요. 더보기 → 알림에서 다시 켜 주세요.',
            style: TextStyle(color: Theme.of(context).colorScheme.error),
          ),
        const Divider(height: 24),
        const Text('스마트 도구 준비 상태:'),
        ListTile(
          dense: true,
          leading: Icon(
            timetableOk ? Icons.check_circle : Icons.remove_circle_outline,
            color: timetableOk ? Theme.of(context).colorScheme.primary : Colors.grey,
          ),
          title: Text(timetableOk ? '시간표 등록됨' : '시간표: 나중에 등록'),
        ),
        ListTile(
          dense: true,
          leading: Icon(
            Icons.check_circle,
            color: Theme.of(context).colorScheme.primary,
          ),
          title: const Text('홈 화면 위젯 안내 확인'),
        ),
        ListTile(
          dense: true,
          leading: Icon(
            geminiOk ? Icons.check_circle : Icons.remove_circle_outline,
            color: geminiOk ? Theme.of(context).colorScheme.primary : Colors.grey,
          ),
          title: Text(geminiOk ? 'Gemini AI 공지 분석 켜짐' : 'Gemini AI: 나중에 등록'),
        ),
        ListTile(
          dense: true,
          leading: Icon(
            driveOk ? Icons.check_circle : Icons.remove_circle_outline,
            color: driveOk ? Theme.of(context).colorScheme.primary : Colors.grey,
          ),
          title: Text(driveOk ? 'Google Drive 연결됨 (${driveEmail ?? ""})' : 'Google Drive: 미연결'),
        ),
        ListTile(
          dense: true,
          leading: Icon(
            calendarAuto ? Icons.check_circle : Icons.remove_circle_outline,
            color: calendarAuto ? Theme.of(context).colorScheme.primary : Colors.grey,
          ),
          title: Text(calendarAuto ? '기기 캘린더 자동 등록 켜짐' : '기기 캘린더 동기화: 꺼짐'),
        ),
      ],
    ],
  );

  Widget body() => switch (step) {
    0 => ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text('어떻게 쓸지 골라 주세요', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 6),
        const Text('나중에 더보기 → 알림에서 언제든 바꿀 수 있어요.'),
        const SizedBox(height: 16),
        presetCard(SetupPreset.all, '전부 켜기 (추천)', ''),
        presetCard(SetupPreset.essential, '필수만', '알림을 적게 받고 싶을 때'),
        presetCard(
          SetupPreset.keep,
          '지금 설정 그대로',
          '이미 알림 시간 등을 바꿔 쓰고 있다면 아무것도 바꾸지 않아요.',
        ),
      ],
    ),
    1 => Column(
      children: [
        Expanded(
          child: PageView(
            controller: guide,
            onPageChanged: (i) => setState(() => guidePage = i),
            children: [
              for (final (icon, title, text) in guideCards)
                Padding(
                  padding: const EdgeInsets.all(32),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(icon, size: 64),
                      const SizedBox(height: 20),
                      Text(
                        title,
                        style: Theme.of(context).textTheme.headlineSmall,
                      ),
                      const SizedBox(height: 12),
                      Text(text, textAlign: TextAlign.center),
                    ],
                  ),
                ),
            ],
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            for (var i = 0; i < guideCards.length; i++)
              Container(
                margin: const EdgeInsets.all(4),
                width: i == guidePage ? 18 : 8,
                height: 8,
                decoration: BoxDecoration(
                  color: i <= guidePage
                      ? Theme.of(context).colorScheme.primary
                      : Theme.of(context).colorScheme.outlineVariant,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
          ],
        ),
        if (guidePage < guideCards.length - 1)
          TextButton(
            onPressed: () => guide.nextPage(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOut,
            ),
            child: const Text('옆으로 넘겨 끝까지 읽어 주세요 →'),
          ),
      ],
    ),
    2 => ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text('꼭 필요한 권한', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 6),
        const Text('이게 없으면 알림이 오지 않거나 자동 확인이 멈춰요.'),
        const SizedBox(height: 16),
        permissionRow(
          '알림 허용',
          '마감·새 과제·수업 알림을 받으려면 필요해요.',
          notifyOk,
          '허용하기',
          () async {
            await requestNotificationPermission();
            await refreshAll();
          },
        ),
        if (Platform.isAndroid)
          permissionRow(
            '배터리 제한 풀기',
            '앱 정보 → 배터리 → "제한 없음"을 골라 주세요. 그래야 앱을 안 열어도 확인해요.',
            batteryOk,
            '설정 열기',
            () async {
              setState(() => batteryTried = true);
              await bridge.invokeNative(NativeMethod.openAppSettings);
            },
          ),
        if (Platform.isAndroid && !batteryOk && batteryTried)
          const Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text('기기에서 바꿀 수 없다면 다음으로 넘어가도 돼요. 오늘 화면 위 카드에 계속 안내가 남아요.'),
          ),
      ],
    ),
    3 => academicToolsStep(),
    4 => aiAndCloudStep(),
    _ => summaryStep(),
  };

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: false,
    child: Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text('시작 설정 ${step + 1}/6'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(4),
          child: LinearProgressIndicator(value: (step + 1) / 6),
        ),
      ),
      body: SafeArea(child: body()),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: step == 0 && widget.allowDemo && !isDemoActive
              ? Row(
                  children: [
                    OutlinedButton(
                      onPressed: applying
                          ? null
                          : () async {
                              setState(() => applying = true);
                              try {
                                if (widget.onStartDemo != null) {
                                  await widget.onStartDemo!();
                                } else {
                                  await enterDemoMode(
                                    entrySource: 'onboarding',
                                  );
                                }
                                if (!mounted) return;
                                final nav = Navigator.of(this.context);
                                if (nav.canPop()) nav.pop();
                              } finally {
                                if (mounted) setState(() => applying = false);
                              }
                            },
                      child: const Text('로그인 없이 둘러보기'),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton(
                        onPressed: canNext ? next : null,
                        child: const Text('다음'),
                      ),
                    ),
                  ],
                )
              : FilledButton(
                  onPressed: canNext ? next : null,
                  child: Text(
                    step == 5
                        ? '시작하기'
                        : step == 2 && notifyOk && !batteryOk && batteryTried
                        ? '나중에 할게요 · 다음'
                        : '다음',
                  ),
                ),
        ),
      ),
    ),
  );
}

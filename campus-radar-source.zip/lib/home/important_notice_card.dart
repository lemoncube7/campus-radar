import 'package:flutter/material.dart';
import 'package:campus_radar/updates/app_notices.dart';

class ImportantNoticeCard extends StatelessWidget {
  final AppNotice notice;
  final VoidCallback onDismiss;
  final void Function(String url)? onOpenUrl;

  const ImportantNoticeCard({
    super.key,
    required this.notice,
    required this.onDismiss,
    this.onOpenUrl,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Card(
      color: colorScheme.errorContainer,
      elevation: 0,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 10, 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.campaign_rounded,
                  color: colorScheme.onErrorContainer,
                  size: 22,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    notice.title,
                    style: theme.textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: colorScheme.onErrorContainer,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close_rounded, size: 20),
                  tooltip: '닫기',
                  color: colorScheme.onErrorContainer,
                  visualDensity: VisualDensity.compact,
                  onPressed: onDismiss,
                ),
              ],
            ),
            const SizedBox(height: 4),
            Padding(
              padding: const EdgeInsets.only(left: 30, right: 6),
              child: Text(
                notice.body,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: colorScheme.onErrorContainer,
                  height: 1.35,
                ),
              ),
            ),
            if (notice.url != null && notice.url!.isNotEmpty) ...[
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.only(left: 30),
                child: FilledButton.tonal(
                  style: FilledButton.styleFrom(
                    backgroundColor: colorScheme.surface.withValues(alpha: 0.7),
                    foregroundColor: colorScheme.onSurface,
                    visualDensity: VisualDensity.compact,
                  ),
                  onPressed: () => onOpenUrl?.call(notice.url!),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('자세히 보기'),
                      SizedBox(width: 4),
                      Icon(Icons.open_in_new_rounded, size: 16),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

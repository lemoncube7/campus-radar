import 'app_storage.dart';

Future<void> systemLog(String title, String detail) async {
  Store? store;
  try {
    store = await Store.open();
    await store.log('system', title, detail);
  } catch (_) {
    // The main operation remains available if local logging fails.
  } finally {
    await store?.db.close();
  }
}

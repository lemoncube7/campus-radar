import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'dart:async';
import 'dart:convert';
import 'package:campus_radar/ai/ai_approval_policy.dart';
import 'package:campus_radar/ai/ai_cancellation_notification.dart';
import 'package:campus_radar/ai/ai_confirm.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/ai/ai_state_repository.dart';
import 'package:campus_radar/ai/ai_state_models.dart';
import 'package:campus_radar/ai/ai_transport.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';
import 'package:campus_radar/schedule/timetable_model.dart';

Future<bool> isAutoApproveEnabled(Store store) async {
  if (await store.meta(MetaKey.aiConsent) != aiConsentVersion) return false;
  final pref = await store.meta(MetaKey.aiAutoApprove);
  return pref != 'no';
}

/// Automatic schedule and cancellation approval without second review LLM call.
Future<void> autoApproveNotice(
  Store store,
  CampusNotice notice,
  List<ScheduleCandidate> candidates, {
  AiTransport transport = geminiTransport,
  SessionScope? sourceScope,
  Future<void> Function()? beforeRequest,
}) async {
  if (!await isAutoApproveEnabled(store)) return;
  try {
    final scope = await SessionScope.capture(
      store,
      ai: true,
      consents: {'aiConsent': aiConsentVersion},
    );
    final apiKey = await credentials.read(key: 'geminiApiKey');
    if (apiKey == null || apiKey.isEmpty) return;
    final hash = noticeFingerprint(notice), repo = AiStateRepository(store);
    final now = DateTime.now().toUtc();
    if (beforeRequest != null) await beforeRequest();
    for (final c in candidates) {
      await sourceScope?.verify();
      await scope.verify();
      final key = candidateKey(notice, c);
      final state = await repo.schedule(key);
      if (state.toJson().isNotEmpty) continue;

      if (c.action == 'add' && eligibleForAutoApproval(notice, c, now)) {
        await confirmAiCandidate(
          store,
          key,
          notice,
          c,
          beforeCommit: () async {
            await sourceScope?.verify();
            await scope.verify();
            if ((await repo.schedule(key)).toJson().isNotEmpty) {
              throw SessionChanged();
            }
          },
        );
        await scope.verify();
        final current = await repo.schedule(key);
        await repo.saveSchedule(
          key,
          ConfirmedSchedule.fromJson({
            ...current.toJson(),
            'approvalMode': 'automatic',
            'approvalReason': '자동 반영됨',
            'approvedAt': DateTime.now().toUtc().toIso8601String(),
          }),
        );
        if (await store.meta(MetaKey.aiCalendarDefault) == 'yes') {
          try {
            await scope.verify();
            await confirmAiCandidate(
              store,
              key,
              notice,
              c,
              calendar: true,
              beforeCommit: scope.verify,
            );
          } catch (e) {
            if (e is SessionChanged) rethrow;
            await scope.verify();
            await store.log(
              'ai',
              '자동 승인 일정 캘린더 전송 대기',
              '${notice.title} · 일정함에서 다시 보낼 수 있어요.',
            );
          }
        }
        await scope.verify();
        await store.setMeta(
          MetaKey.aiApproval(key),
          jsonEncode({
            'fingerprint': hash,
            'policy': approvalPolicyVersion,
            'candidate': jsonEncode(c.toJson()),
            'approved': true,
            'reason': '자동 반영됨',
            'quote': c.evidence,
            'checkedAt': DateTime.now().toUtc().toIso8601String(),
          }),
        );
        await store.log(
          'ai',
          'AI 일정 자동 승인',
          '${notice.title} · ${c.title}',
        );
      } else if (c.action == 'cancel' &&
          c.category == 'class' &&
          eligibleForAutoCancellation(notice, c, now)) {
        final allSlots = decodeSlots(await store.meta(MetaKey.timetableEntries));
        final planned = matchCandidateCancellations(allSlots, notice, c);
        if (planned.isNotEmpty) {
          // Same guard as the add path: stop if the session or account changed,
          // or someone already decided this candidate.
          await sourceScope?.verify();
          await scope.verify();
          if ((await repo.schedule(key)).toJson().isNotEmpty) continue;
          await CancellationRepository(store).apply(planned);
          await repo.saveSchedule(
            key,
            ConfirmedSchedule.fromJson({
              'status': 'excluded',
              'resolution': 'classCancellationApplied',
              'approvalMode': 'automatic',
              'approvalReason': '자동 반영됨',
              'approvedAt': DateTime.now().toUtc().toIso8601String(),
            }),
          );
          try {
            await bridge.invokeNative(NativeMethod.refreshWidget);
          } catch (_) {}
          cancellationRefresh.value++;
          await store.setMeta(
            MetaKey.aiApproval(key),
            jsonEncode({
              'fingerprint': hash,
              'policy': approvalPolicyVersion,
              'candidate': jsonEncode(c.toJson()),
              'approved': true,
              'reason': '자동 반영됨',
              'quote': c.evidence,
              'checkedAt': DateTime.now().toUtc().toIso8601String(),
            }),
          );
          await store.log(
            'ai',
            'AI 휴강 자동 반영',
            '${notice.title} · ${planned.length}개 수업',
          );
        }
      }
    }
  } on SessionChanged {
    return;
  } catch (e) {
    await store.log(
      'ai',
      'AI 자동 승인 대기',
      e is AiFailure ? e.message : '자동 반영을 완료하지 못해 일정 후보를 유지했어요.',
    );
  }
}

/// Reads saved candidates independently of extraction scheduling. A malformed
/// old row cannot block the rest of the collection/analysis worker.
Future<void> autoApproveSavedCandidates(
  Store store,
  SessionScope scope, {
  required bool Function() keepGoing,
}) async {
  if (!await isAutoApproveEnabled(store)) return;
  final records = await store.db.query(
    'meta',
    where: 'id LIKE ?',
    whereArgs: ['aiCandidate:%'],
  );
  final current = {for (final n in await store.notices()) n.id: n};
  final grouped = <String, (CampusNotice, List<ScheduleCandidate>)>{};
  for (final row in records) {
    try {
      final saved = jsonDecode(row['value'] as String) as Map;
      final n = CampusNotice.fromJson(
        Map<String, dynamic>.from(saved['notice']),
      );
      if (current[n.id] == null ||
          noticeFingerprint(current[n.id]!) != noticeFingerprint(n)) {
        continue;
      }
      final c = ScheduleCandidate.parse(
        Map<String, dynamic>.from(saved['candidate']),
        '${n.title}\n${n.body}',
      );
      (grouped[n.id] ??= (n, <ScheduleCandidate>[])).$2.add(c);
    } catch (e) {
      await store.log(
        'ai',
        '자동 승인 후보 읽기 건너뜀',
        withCause('이전 후보 형식을 읽지 못했어요. 원본 후보는 유지해요.', e),
      );
    }
  }
  for (final group in grouped.values) {
    if (!keepGoing() || !await isAutoApproveEnabled(store)) break;
    await scope.verify();
    await autoApproveNotice(store, group.$1, group.$2, sourceScope: scope);
  }
}

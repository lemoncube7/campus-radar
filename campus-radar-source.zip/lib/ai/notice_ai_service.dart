export 'package:campus_radar/ai/ai_request_budget.dart';
import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/ai/ai_request_budget.dart';
import 'package:campus_radar/ai/ai_auto_approval.dart';
import 'package:campus_radar/ai/ai_state_repository.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/ai/ai_transport.dart';
import 'package:campus_radar/ai/ai_generation.dart';
import 'package:campus_radar/ai/ai_timetable_rules.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/ai/ai_timetable.dart';
import 'dart:async';
import 'dart:convert';

Future<void> saveAiDiagnostic(
  Store store,
  CampusNotice notice,
  int attempt,
  AiFailure error,
  Map<String, dynamic> response,
  String key,
) async {
  // Local only. Never persist transport headers, credentials or portal context.
  String clip(String value, int size) {
    final clean = key.isEmpty
        ? value
        : value.replaceAll(key, '[API key removed]');
    return clean.length > size ? clean.substring(0, size) : clean;
  }

  final candidates = response['candidates'];
  String output = '';
  if (candidates is List && candidates.isNotEmpty) {
    final first = candidates.first;
    final content = first is Map ? first['content'] : null;
    final parts = content is Map ? content['parts'] : null;
    if (parts is List) {
      output = parts
          .whereType<Map>()
          .where((p) => p['thought'] != true)
          .map((p) => p['text'] ?? '')
          .join();
    }
  }
  final id = MetaKey.aiDiagnostic(notice.id);
  final previous = jsonDecode(await store.meta(id) ?? '{}') as Map;
  final attempts = attempt == 1
      ? <dynamic>[]
      : List<dynamic>.from(previous['attempts'] ?? []);
  attempts.add({
    'attempt': attempt,
    'code': error.code,
    'error': clip(error.message, 1000),
    'detail': clip(error.detail, 5000),
    'output': clip(output, 20000),
  });
  await store.setMeta(
    id,
    jsonEncode({
      'savedAt': DateTime.now().toUtc().toIso8601String(),
      'model': aiModel,
      'promptVersion': aiPromptVersion,
      'attempts': attempts.take(2).toList(),
      'sourceParagraphs': sourceParagraphs(
        notice,
      ).map((p) => {'id': p['id'], 'text': clip(p['text']!, 30000)}).toList(),
    }),
  );
  final rows = (await store.db.query(
    'meta',
    where: 'id LIKE ?',
    whereArgs: ['aiDiagnostic:%'],
  )).toList();
  rows.sort(
    (a, b) => '${(jsonDecode(b['value'] as String) as Map)['savedAt']}'
        .compareTo('${(jsonDecode(a['value'] as String) as Map)['savedAt']}'),
  );
  for (final row in rows.skip(20)) {
    await store.db.delete('meta', where: 'id=?', whereArgs: [row['id']]);
  }
}

class NoticeAi {
  static bool _running = false;
  static Future<List<ScheduleCandidate>> analyze(
    CampusNotice n, {
    AiTransport transport = geminiTransport,
    String supplemental = '',
    String repairHint = '',
    bool force = false,
    SessionScope? sourceScope,
  }) async {
    if (_running) {
      throw const AiFailure('다른 공지를 분석 중이에요. 완료 후 다시 시도해 주세요.', code: 'busy');
    }
    _running = true;
    Store? store;
    var claimed = false;
    String? analysisOwner;
    try {
      store = await Store.open();
      analysisOwner = await claimNoticeAnalysis(store, n.id);
      await sourceScope?.verify();
      final scope = await SessionScope.capture(
        store,
        consents: {'aiConsent': aiConsentVersion},
        ai: true,
      );
      if (!n.bodyFetched || (n.body.trim().isEmpty && n.title.trim().isEmpty)) {
        throw const AiFailure(
          '공지 본문을 가져오지 못했어요.',
          code: 'source',
          detail: '원문 확인에서 본문을 먼저 불러온 뒤 다시 분석해 주세요.',
        );
      }
      final hash = noticeFingerprint(n);
      final timetable = await aiTimetableContext(store, notice: n);
      final timetableHash = timetableContextHash(timetable);
      final savedTimetableHash = await store.meta(MetaKey.aiTimetableHash(n.id));
      final cached = await store.meta('aiCache:${n.id}:$hash');
      if (cached != null &&
          !force &&
          supplemental.isEmpty &&
          (savedTimetableHash == timetableHash ||
              savedTimetableHash == null &&
                  (timetable['slots'] as List).isEmpty)) {
        // Cache hits are routine; logging each one filled the activity log.
        final restored = (jsonDecode(cached) as List)
            .map(
              (e) => ScheduleCandidate.parse(
                Map<String, dynamic>.from(e),
                '${n.title}\n${n.body}',
              ),
            )
            .toList();
        await scope.verify();
        await sourceScope?.verify();
        await rememberCandidates(store, n, restored);
        await autoApproveNotice(
          store,
          n,
          restored,
          transport: transport,
          sourceScope: sourceScope,
        );
        return restored;
      }
      if (n.body.length > 30000) {
        throw const AiFailure(
          '공지 본문이 분석 길이 제한을 넘었어요.',
          code: 'length',
          detail:
              '본문 30,000자까지 지원해요. 추가 자료를 보내도 해결되지 않아 원문 확인이나 직접 일정 추가가 필요해요.',
        );
      }
      final account = await credentials.read(key: 'id');
      final key = await credentials.read(key: 'geminiApiKey');
      if (key == null ||
          key.trim().isEmpty ||
          await store.meta(MetaKey.aiConsent) != aiConsentVersion) {
        throw const AiFailure('AI 설정에서 개인 API 키를 저장하고 외부 전송에 동의해 주세요.');
      }
      await claimAiRequest(store);
      claimed = true;
      await store.log('ai', 'AI 분석 요청', '${n.course} · ${n.title} · $aiModel');
      Future<void> verifyAccount() async {
        await sourceScope?.verify();
        await scope.verify();
        if (await credentials.read(key: 'id') != account ||
            await credentials.read(key: 'geminiApiKey') != key ||
            await store!.meta(MetaKey.aiConsent) != aiConsentVersion) {
          throw const AiFailure(
            'AI 설정이 변경되어 분석을 중지했어요.',
            code: 'settings_changed',
          );
        }
      }

      final result = await analyzeAiWithRepair(
        n,
        key.trim(),
        transport: (key, body) async {
          await sourceScope?.verify();
          return guardedAiTransport(scope, transport, key, body);
        },
        timetable: timetable,
        supplemental: supplemental,
        repairHint: repairHint,
        beforeRequest: (attempt) async {
          await verifyAccount();
          if (attempt == 2) {
            // Count/rate-limit the corrective call like every other API request.
            await Future<void>.delayed(const Duration(seconds: 5));
            await verifyAccount();
            await renewAiRequest(store!);
            await store!.log('ai', 'AI 검증 자동 수정 요청', '${n.title} · 최대 1회');
          }
        },
        onInvalid: (attempt, error, raw) async {
          await verifyAccount();
          await saveAiDiagnostic(store!, n, attempt, error, raw, key.trim());
          await store!.log(
            'ai',
            'AI 응답 검증 실패',
            '${error.code} · ${error.message} · 시도 $attempt',
          );
        },
      );
      final response = result.response;
      if (await credentials.read(key: 'id') != account ||
          await credentials.read(key: 'geminiApiKey') != key ||
          await store.meta(MetaKey.aiConsent) != aiConsentVersion) {
        throw const AiFailure('AI 설정이 변경되어 응답 저장을 중지했어요.');
      }
      await verifyAccount();
      final events = result.events;
      await rememberCandidates(store, n, events);
      // Replace only this notice cache; older content never silently reuses a result.
      await store.db.delete(
        'meta',
        where: 'id LIKE ?',
        whereArgs: ['aiCache:${n.id}:%'],
      );
      await store.setMeta(
        'aiCache:${n.id}:$hash',
        jsonEncode(events.map((e) => e.toJson()).toList()),
      );
      await store.setMeta(MetaKey.aiTimetableHash(n.id), timetableHash);
      await store.log(
        'ai',
        'AI 분석 완료',
        '${n.title} · 후보 ${events.length}개 · 입력 ${response['usageMetadata']?['promptTokenCount'] ?? "미확인"} / 출력 ${response['usageMetadata']?['candidatesTokenCount'] ?? "미확인"}토큰',
      );
      await releaseAiRequest(store);
      claimed = false;
      await autoApproveNotice(
        store,
        n,
        events,
        transport: transport,
        sourceScope: sourceScope,
      );
      return events;
    } on SessionChanged {
      throw const AiFailure(
        '계정 또는 AI 설정이 변경되어 이전 분석을 중지했어요.',
        code: 'settings_changed',
      );
    } on AiFailure catch (e) {
      await store?.log('ai', 'AI 분석 실패', e.message);
      rethrow;
    } catch (e) {
      await store?.log('ai', 'AI 분석 실패', withCause('기기 처리 오류', e));
      throw const AiFailure('AI 분석 결과를 저장하지 못했어요.');
    } finally {
      try {
        if (claimed && store != null) {
          await releaseAiRequest(store);
        }
        if (analysisOwner != null && store != null) {
          await releaseNoticeAnalysis(store, n.id, analysisOwner);
        }
        await store?.db.close();
      } finally {
        _running = false;
      }
    }
  }
}

// Keep user decisions even when the notice body changes or leaves the current list.
Future<void> rememberCandidates(
  Store store,
  CampusNotice notice,
  List<ScheduleCandidate> events,
) async {
  final rows = await store.db.query(
    'meta',
    where: 'id LIKE ?',
    whereArgs: ['aiCandidate:%'],
  );
  final previous = rows
      .map((row) => jsonDecode(row['value'] as String) as Map)
      .where((record) => record['notice']['id'] == notice.id)
      .toList();
  String slot(Map c) =>
      jsonEncode([c['date'], c['time'], c['action'], c['category']]);
  final retained = <String>{};
  for (var i = 0; i < events.length; i++) {
    var c = events[i];
    final exact = previous
        .where(
          (r) => [
            'title',
            'date',
            'time',
            'action',
            'category',
          ].every((f) => r['candidate'][f] == c.toJson()[f]),
        )
        .toList();
    final sameSlot = previous
        .where((r) => slot(r['candidate'] as Map) == slot(c.toJson()))
        .toList();
    final uniqueSlot =
        c.date.isNotEmpty &&
        sameSlot.length == 1 &&
        events.where((e) => slot(e.toJson()) == slot(c.toJson())).length == 1;
    final match = exact.isNotEmpty
        ? exact.first
        : uniqueSlot
        ? sameSlot.single
        : null;
    if (match != null) {
      c = ScheduleCandidate.parse({
        ...c.toJson(),
        'originKey': match['key'],
      }, '${notice.title}\n${notice.body}');
      events[i] = c;
    }
    var k = candidateKey(notice, c);
    if (retained.contains(k)) {
      // One sentence can list several dates ("11월 4일, 11일 퀴즈"); title and
      // evidence alone would give them the same key and hide all but one.
      c = ScheduleCandidate.parse({
        ...c.toJson(),
        'originKey': distinctCandidateKey(notice, c),
      }, '${notice.title}\n${notice.body}');
      events[i] = c;
      k = candidateKey(notice, c);
    }
    retained.add(k);
    await store.setMeta(
      MetaKey.aiCandidate(k),
      jsonEncode({
        'notice': notice.toJson(),
        'candidate': c.toJson(),
        'key': k,
      }),
    );
  }
  // Refresh unreviewed results of this notice; keep every explicit user decision.
  for (final record in previous) {
    final key = record['key'] as String;
    if (retained.contains(key)) continue;
    final state = await AiStateRepository(store).schedule(key);
    if (state.isExplicitDecision) continue;
    await store.db.delete(
      'meta',
      where: 'id=?',
      whereArgs: [MetaKey.aiCandidate(key)],
    );
  }
}

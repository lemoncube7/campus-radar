import 'package:campus_radar/core/storage_keys.dart';
import 'package:flutter/material.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/ai/ai_automation.dart';
import 'package:campus_radar/ai/ai_auto_approval.dart';

class AutoApprovalSettings extends StatefulWidget {
  const AutoApprovalSettings({super.key});
  @override
  State<AutoApprovalSettings> createState() => _AutoApprovalSettingsState();
}

class _AutoApprovalSettingsState extends State<AutoApprovalSettings> {
  bool enabled = false, ready = false, saving = false;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    Store? store;
    try {
      store = await Store.open();
      final value = await isAutoApproveEnabled(store);
      final allowed = await store.meta(MetaKey.aiConsent) == aiConsentVersion;
      if (mounted) {
        setState(() {
          enabled = value;
          ready = allowed;
        });
      }
    } catch (_) {
      if (mounted) setState(() => ready = false);
    } finally {
      await store?.db.close();
    }
  }

  Future<void> change(bool value) async {
    setState(() => saving = true);
    Store? store;
    try {
      store = await Store.open();
      await store.setAiSetting(AiSetting.aiAutoApprove, value ? 'yes' : 'no');
      await store.log(
        'ai',
        'AI 자동 승인 설정',
        value ? '명확한 일정·휴강 승인 없이 자동 반영' : '자동 반영 끔',
      );
      if (value) await scheduleAiWork();
      if (mounted) setState(() => enabled = value);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('자동 승인 설정을 저장하지 못했어요.')));
      }
    } finally {
      await store?.db.close();
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => SwitchListTile.adaptive(
    contentPadding: EdgeInsets.zero,
    title: const Text('명확한 AI 일정·휴강 자동 반영'),
    subtitle: const Text(
      '공지에서 감지된 명확한 일정과 휴강을 승인 없이 바로 반영해요. 불확실하거나 조건부 일정은 검토함에 남겨요. 캘린더 전송은 일정 추가 기본 위치를 따라요.',
    ),
    value: enabled,
    onChanged: !ready || saving ? null : change,
  );
}

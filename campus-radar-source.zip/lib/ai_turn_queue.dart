import 'dart:async';
import 'ai_protocol.dart';

/// Retry only a busy lease. Other failures must remain visible and never trigger
/// a second network request. No transaction is held during the wait.
Future<void> waitForAiTurn({
  required Future<void> Function() claim,
  required Future<void> Function() verify,
  required bool Function() cancelled,
  void Function()? onWaiting,
  Future<void> Function(Duration)? delay,
  Duration timeout = const Duration(minutes: 4),
}) async {
  final clock = Stopwatch()..start();
  while (true) {
    if (cancelled()) throw const AiFailure('질문 대기를 취소했어요.', code: 'cancelled');
    await verify();
    try {
      await claim();
      return;
    } on AiFailure catch (e) {
      if (e.code != 'busy') rethrow;
      if (clock.elapsed >= timeout) {
        throw const AiFailure(
          '앞선 작업이 오래 걸리고 있어요. 질문은 남겨 두었으니 다시 보내 주세요.',
          code: 'busy',
        );
      }
      onWaiting?.call();
      await (delay ?? Future<void>.delayed)(const Duration(milliseconds: 500));
    }
  }
}

import 'package:flutter/foundation.dart';

enum ScheduleView { tasks, calendar, timetable, review }

class HomeRequest {
  final bool today;
  final ScheduleView view;
  const HomeRequest({this.today = false, this.view = ScheduleView.tasks});
}

final homeNavigation = ValueNotifier<HomeRequest?>(null);

/// Local observations, not a claim about the school's configured timeout.
/// Authentication loss can also be caused by a login on another device.
class SessionLifetime {
  SessionLifetime();
  String session = '';
  int? bornAt, lastTrafficAt, lastValidatedAt;
  int maxIdleMs = 0, maxAgeMs = 0, successes = 0, losses = 0;
  int networkErrors = 0, unknownErrors = 0, targetMinutes = 15;
  int searchFloorMs = 0;
  int? searchCeilingMs;
  int? retryAfter;
  bool lost = false;
  final Map<String, Map<String, dynamic>> requests = {};
  final Map<String, Map<String, dynamic>> validations = {};
  final List<Map<String, dynamic>> history = [];
  final List<int> probes = [];

  factory SessionLifetime.fromJson(Map<String, dynamic> data) {
    if (data['version'] != 1) throw const FormatException('세션 관측 버전 오류');
    final state = SessionLifetime()
      ..session = data['session'] as String
      ..bornAt = data['bornAt'] as int?
      ..lastTrafficAt = data['lastTrafficAt'] as int?
      ..lastValidatedAt = data['lastValidatedAt'] as int?
      ..maxIdleMs = data['maxIdleMs'] as int
      ..maxAgeMs = data['maxAgeMs'] as int
      ..successes = data['successes'] as int
      ..losses = data['losses'] as int
      ..networkErrors = data['networkErrors'] as int
      ..unknownErrors = data['unknownErrors'] as int
      ..targetMinutes = data['targetMinutes'] as int
      ..searchFloorMs = data['searchFloorMs'] as int? ?? 0
      ..searchCeilingMs = data['searchCeilingMs'] as int?
      ..retryAfter = data['retryAfter'] as int?
      ..lost = data['lost'] as bool;
    for (final field in ['requests', 'validations']) {
      final target = field == 'requests' ? state.requests : state.validations;
      for (final entry in (data[field] as Map).entries) {
        target[entry.key as String] = Map<String, dynamic>.from(
          entry.value as Map,
        );
      }
    }
    state.history.addAll(
      (data['history'] as List).map((e) => Map<String, dynamic>.from(e as Map)),
    );
    state.probes.addAll((data['probes'] as List).cast<int>());
    bool stamp(dynamic value) =>
        value is int && value >= 0 && value <= 8640000000000000;
    final validRows =
        state.history.every((e) => stamp(e['at']) && e['kind'] is String) &&
        state.requests.values.every(
          (e) => stamp(e['at']) && e['group'] is String,
        ) &&
        state.validations.values.every(
          (e) =>
              stamp(e['at']) &&
              (e['gap'] == null || e['gap'] is int && (e['gap'] as int) >= 0) &&
              e['clean'] is bool &&
              e['networkError'] is bool,
        ) &&
        state.probes.every(stamp) &&
        [
          state.bornAt,
          state.lastTrafficAt,
          state.lastValidatedAt,
          state.retryAfter,
        ].every((v) => v == null || stamp(v));
    if (state.targetMinutes < 15 ||
        state.targetMinutes > 1440 ||
        state.maxIdleMs < 0 ||
        state.maxAgeMs < 0 ||
        state.history.length > 60 ||
        state.probes.length > 8 ||
        state.requests.length > 64 ||
        state.validations.length > 8 ||
        !validRows ||
        state.searchFloorMs < 0 ||
        state.searchCeilingMs != null && state.searchCeilingMs! < 0 ||
        [
          state.successes,
          state.losses,
          state.networkErrors,
          state.unknownErrors,
        ].any((v) => v < 0)) {
      throw const FormatException('세션 관측 범위 오류');
    }
    state.probes.sort();
    return state;
  }

  Map<String, dynamic> toJson() => {
    'version': 1,
    'session': session,
    'bornAt': bornAt,
    'lastTrafficAt': lastTrafficAt,
    'lastValidatedAt': lastValidatedAt,
    'maxIdleMs': maxIdleMs,
    'maxAgeMs': maxAgeMs,
    'successes': successes,
    'losses': losses,
    'networkErrors': networkErrors,
    'unknownErrors': unknownErrors,
    'targetMinutes': targetMinutes,
    'searchFloorMs': searchFloorMs,
    'searchCeilingMs': searchCeilingMs,
    'retryAfter': retryAfter,
    'lost': lost,
    'requests': requests,
    'validations': validations,
    'history': history,
    'probes': probes,
  };

  void beginSession(String id, int now, {required bool freshlyLoggedIn}) {
    if (session == id) return;
    session = id;
    bornAt = freshlyLoggedIn ? now : null;
    lastTrafficAt = freshlyLoggedIn ? now : null;
    lastValidatedAt = null;
    requests.clear();
    validations.clear();
    lost = false;
    retryAfter = null;
    _record(now, freshlyLoggedIn ? 'newSession' : 'adoptedSession');
  }

  void _record(int now, String kind, [Map<String, dynamic> detail = const {}]) {
    history.add({'at': now, 'kind': kind, ...detail});
    if (history.length > 60) history.removeRange(0, history.length - 60);
  }

  void _expire(int now) {
    // A killed worker or clock discontinuity must never become a long idle
    // success. In-flight request deadline is shorter than this stale window.
    final stale = requests.values.any(
      (r) => now - (r['at'] as int) > 120000 || now < (r['at'] as int),
    );
    final staleValidation = validations.values.any(
      (v) => now - (v['at'] as int) > 420000 || now < (v['at'] as int),
    );
    if (stale ||
        staleValidation ||
        lastTrafficAt != null && now < lastTrafficAt!) {
      requests.clear();
      validations.clear();
      lastTrafficAt = now;
      lastValidatedAt = null;
      _record(now, 'observationInterrupted');
    }
    probes.removeWhere((at) => at > now || now - at >= 86400000);
  }

  void beginValidation(String group, int now) {
    _expire(now);
    if (validations.length >= 8) validations.clear();
    validations[group] = {
      'at': now,
      'gap':
          lastValidatedAt != null && lastTrafficAt != null && requests.isEmpty
          ? now - lastTrafficAt!
          : null,
      'clean': requests.isEmpty,
      'networkError': false,
    };
  }

  void requestStarted(String group, String token, int now) {
    _expire(now);
    for (final entry in validations.entries) {
      if (entry.key != group) entry.value['clean'] = false;
    }
    if (requests.isNotEmpty) {
      for (final value in validations.values) {
        value['clean'] = false;
      }
    }
    requests[token] = {'at': now, 'group': group};
    lastTrafficAt = now;
  }

  void requestFinished(
    String group,
    String token,
    int now, {
    bool failed = false,
  }) {
    requests.remove(token);
    lastTrafficAt = now;
    if (failed) {
      validations[group]?['networkError'] = true;
    }
  }

  void validated(String group, int now) {
    _expire(now);
    final candidate = validations.remove(group);
    final gap = candidate?['gap'] as int?;
    final clean =
        candidate?['clean'] == true && candidate?['networkError'] == false;
    if (gap != null && gap >= 0 && clean) {
      if (gap > maxIdleMs) maxIdleMs = gap;
      if (gap > searchFloorMs) searchFloorMs = gap;
      if (searchCeilingMs != null && gap >= searchCeilingMs!) {
        searchCeilingMs = null;
      }
      if (gap >= targetMinutes * 60000) {
        // Expand until a loss, then bisect an experimental bracket. The
        // bracket chooses probes; it is never a proven timeout range.
        final next = <int>[
          15,
          30,
          60,
          120,
          240,
          480,
          720,
          1440,
        ].firstWhere((m) => m * 60000 > gap, orElse: () => 1440);
        targetMinutes = searchCeilingMs != null
            ? (((searchFloorMs + searchCeilingMs!) / 2 / 60000 / 15).ceil() *
                      15)
                  .clamp(15, 1440)
            : next;
      }
    }
    if (bornAt != null && now >= bornAt! && now - bornAt! > maxAgeMs) {
      maxAgeMs = now - bornAt!;
    }
    successes++;
    lost = false;
    retryAfter = null;
    lastValidatedAt = now;
    lastTrafficAt = now;
    _record(now, 'validated', {
      'idleMs': clean ? gap : null,
      'clean': clean,
      'targetMinutes': targetMinutes,
    });
  }

  void failedValidation(
    String group,
    int now, {
    required bool authentication,
    required bool network,
  }) {
    final candidate = validations.remove(group);
    if (authentication) {
      if (lost) return;
      losses++;
      lost = true;
      final gap = candidate?['gap'] as int?;
      // A failed attempt guides the next experiment; it is NOT a timeout
      // upper bound. Other-device login and hard lifetime remain confounders.
      if (gap != null && gap > searchFloorMs && candidate?['clean'] == true) {
        if (searchCeilingMs == null || gap < searchCeilingMs!) {
          searchCeilingMs = gap;
        }
        targetMinutes =
            (((searchFloorMs + searchCeilingMs!) / 2 / 60000 / 15).ceil() * 15)
                .clamp(15, 1440);
      } else if (gap != null && gap <= searchFloorMs) {
        // Shorter failure contradicts the hypothesis, not historical evidence.
        searchFloorMs = 0;
        searchCeilingMs = null;
        targetMinutes = 15;
      }
      _record(now, 'authenticationLost', {
        'attemptedIdleMs': gap,
        'lastValidatedAt': lastValidatedAt,
        'cause': 'unknown',
        'isTimeoutUpperBound': false,
      });
    } else {
      if (network) {
        networkErrors++;
      } else {
        unknownErrors++;
      }
      final recent = history.reversed
          .takeWhile((e) => e['kind'] != 'validated')
          .where(
            (e) => e['kind'] == 'networkError' || e['kind'] == 'responseError',
          )
          .length;
      final delay = (15 * (1 << recent.clamp(0, 3))).clamp(15, 120);
      retryAfter = now + delay * 60000;
      _record(now, network ? 'networkError' : 'responseError', {
        'retryMinutes': delay,
      });
    }
    lastTrafficAt = now;
  }

  int? nextProbeAt(int now) {
    _expire(now);
    if (session.isEmpty ||
        lost ||
        lastValidatedAt == null ||
        lastTrafficAt == null ||
        requests.isNotEmpty ||
        validations.isNotEmpty) {
      return null;
    }
    var at = lastTrafficAt! + targetMinutes * 60000;
    if (retryAfter != null && retryAfter! > at) at = retryAfter!;
    if (probes.length >= 8) {
      final budgetAt = probes.first + 86400000;
      if (budgetAt > at) at = budgetAt;
    }
    return at;
  }

  bool reserveProbe(int now, {bool prepareSession = false}) {
    int? next;
    if (prepareSession) {
      _expire(now);
      if (requests.isNotEmpty || validations.isNotEmpty) return false;
      next = retryAfter ?? now;
      if (probes.length >= 8 && probes.first + 86400000 > next) {
        next = probes.first + 86400000;
      }
    } else {
      next = nextProbeAt(now);
    }
    if (next == null || now < next) return false;
    probes.add(now);
    // Protect against duplicate workers until a validation actually starts.
    retryAfter = now + 15 * 60000;
    return true;
  }
}

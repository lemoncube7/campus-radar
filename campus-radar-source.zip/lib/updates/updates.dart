import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/updates/update_notification.dart';
import 'package:campus_radar/updates/app_notices.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'dart:async';
import 'package:campus_radar/core/app_logging.dart';
import 'dart:convert';
import 'package:campus_radar/core/network_resilience.dart';
import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';

const appVersion = '0.6.6';
const appBuild = 92;
String installedAppVersion = appVersion;
int installedAppBuild = appBuild;

/// The OS package is authoritative; constants are only an offline fallback.
Future<void> loadInstalledVersion() async {
  try {
    final info = await bridge
        .invokeNativeMap<String, dynamic>(NativeMethod.versionInfo)
        .timeout(const Duration(seconds: 2));
    final name = info?['name'];
    final code = info?['code'];
    if (name is String &&
        name.trim().isNotEmpty &&
        code is num &&
        code.toInt() > 0) {
      installedAppVersion = name;
      installedAppBuild = code.toInt();
    }
  } catch (_) {
    // Preserve the last known package version when the native bridge is unavailable.
  }
}

String releaseChannelForVersion(String version, {String configured = ''}) {
  if (configured == 'stable' || configured == 'development') return configured;
  return version.contains('-') ? 'development' : 'stable';
}

final appReleaseChannel = releaseChannelForVersion(
  appVersion,
  configured: const String.fromEnvironment('RELEASE_CHANNEL'),
);
String channelLabel(String c) => c == 'development' ? '개발 버전' : '정식 릴리스';
const updateRoot =
    'https://raw.githubusercontent.com/lemoncube7/campus-radar/main/updates';
typedef ManifestLoader = Future<Map<String, dynamic>?> Function(String channel);
Map<String, dynamic> validateUpdate(Map<String, dynamic> m, String channel) {
  if (m['versionCode'] is! int ||
      (m['versionCode'] as int) < 1 ||
      m['versionName'] is! String ||
      m['apkUrl'] is! String ||
      !RegExp(r'^[a-fA-F0-9]{64}$').hasMatch(m['sha256']?.toString() ?? '')) {
    throw const FormatException('업데이트 정보 형식이 잘못됐어요.');
  }
  final uri = Uri.tryParse(m['apkUrl']);
  if (uri == null ||
      uri.scheme != 'https' ||
      uri.host.isEmpty ||
      uri.userInfo.isNotEmpty) {
    throw const FormatException('업데이트 파일은 HTTPS 주소여야 해요.');
  }
  if (m['channel'] != null && m['channel'] != channel) {
    throw const FormatException('업데이트 채널이 일치하지 않아요.');
  }
  return {...m, 'channel': channel};
}

Future<Map<String, dynamic>?> loadUpdateManifest(String channel) async {
  return retryNetworkRead(() => _loadUpdateManifestOnce(channel));
}

Future<Map<String, dynamic>?> _loadUpdateManifestOnce(String channel) async {
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
  final timer = Timer(
    const Duration(seconds: 20),
    () => client.close(force: true),
  );
  ActiveRequests.add(client);
  try {
    final uri = Uri.parse('$updateRoot/$channel.json').replace(
      queryParameters: {'check': '${DateTime.now().millisecondsSinceEpoch}'},
    );
    final req = await client.getUrl(uri);
    req.headers.set('Cache-Control', 'no-cache');
    final response = await req.close().timeout(const Duration(seconds: 10));
    if (response.statusCode == 404) {
      await response.listen((_) {}).cancel();
      return null;
    }
    if (response.statusCode != 200) {
      throw NetworkHttpException(response.statusCode);
    }
    final bytes = <int>[];
    await for (final chunk in response.timeout(const Duration(seconds: 10))) {
      bytes.addAll(chunk);
      if (bytes.length > 100000) {
        throw const FormatException('업데이트 정보가 너무 커요.');
      }
    }
    return validateUpdate(
      Map<String, dynamic>.from(jsonDecode(utf8.decode(bytes))),
      channel,
    );
  } finally {
    timer.cancel();
    ActiveRequests.remove(client);
    client.close(force: true);
  }
}

Future<String> updateChannel() async {
  final p = await SharedPreferences.getInstance();
  await p.reload();
  return effectiveUpdateChannel(
    appReleaseChannel,
    p.getString(PrefKey.updateChannel),
  );
}

Map<String, dynamic>? chooseUpdate(
  Iterable<Map<String, dynamic>> manifests,
  String channel,
  int current,
) {
  final eligible =
      manifests
          .where(
            (m) =>
                m['versionCode'] > current &&
                (m['channel'] == 'stable' || channel == 'development'),
          )
          .toList()
        ..sort(
          (a, b) =>
              (b['versionCode'] as int).compareTo(a['versionCode'] as int),
        );
  return eligible.firstOrNull;
}

Future<Map<String, dynamic>?> cachedUpdate({int? current}) async {
  if (current == null) await loadInstalledVersion();
  final p = await SharedPreferences.getInstance();
  await p.reload();
  final channel = await updateChannel();
  final values = <Map<String, dynamic>>[];
  for (final c in ['stable', if (channel == 'development') 'development']) {
    try {
      final raw = p.getString('updateInfo:$c');
      if (raw != null) {
        values.add(
          validateUpdate(Map<String, dynamic>.from(jsonDecode(raw)), c),
        );
      }
    } catch (_) {
      // A damaged cached feed is ignored; the next check replaces it.
    }
  }
  return chooseUpdate(values, channel, current ?? installedAppBuild);
}

Future<void> checkForUpdates(
  Store store, {
  ManifestLoader loader = loadUpdateManifest,
  UpdateNotifier notifier = showUpdateNotification,
  NoticesFeedLoader noticesLoader = loadAppNoticesFeed,
  NoticeNotifier noticeNotifier = showNoticeNotification,
}) async {
  await loadInstalledVersion();
  final p = await SharedPreferences.getInstance();
  await p.reload();
  final channel = await updateChannel();
  var failures = 0;
  String? detail;
  final fresh = <Map<String, dynamic>>[];
  for (final c in ['stable', if (channel == 'development') 'development']) {
    try {
      final m = await loader(c);
      if (m == null) {
        await p.remove('updateInfo:$c');
      } else {
        final valid = validateUpdate(m, c);
        await p.setString('updateInfo:$c', jsonEncode(valid));
        fresh.add(valid);
      }
    } catch (e) {
      failures++;
      detail = '업데이트 정보를 가져오지 못했어요. 마지막으로 확인한 정보는 유지해요.';
      await systemLog('업데이트 확인 실패', '$c 채널 · $detail', kind: 'app', error: e);
    }
  }
  try {
    final rawNotices = await noticesLoader();
    if (rawNotices != null) {
      await processAppNotices(
        rawNotices,
        store: store,
        notifier: noticeNotifier,
        currentBuild: installedAppBuild,
      );
    }
  } catch (e) {
    // 공지 파일이 없거나 형식이 깨져도 업데이트 확인은 그대로 진행한다.
    await systemLog('앱 공지 확인 실패', '공지 정보를 가져오지 못했어요.', kind: 'app', error: e);
  }
  await p.setString(
    PrefKey.updateCheckedAt,
    DateTime.now().toUtc().toIso8601String(),
  );
  await p.setString(PrefKey.updateCheckError, failures == 0 ? '' : detail!);
  final candidate = await cachedUpdate();
  await store.log(
    'app',
    failures > 0
        ? '업데이트 자동 확인 일부 실패'
        : candidate == null
        ? '업데이트 확인 완료'
        : '업데이트 가능',
    '${channelLabel(channel)} 채널 · ${candidate == null ? '새 버전 없음' : '${candidate['versionName']} (${channelLabel(candidate['channel'])})'}',
  );
  // Never announce a stale cached candidate after a failed network check, or
  // a lower fresh release while the preferred cached channel is unavailable.
  if (candidate != null &&
      fresh.any(
        (m) =>
            m['channel'] == candidate['channel'] &&
            m['versionCode'] == candidate['versionCode'],
      )) {
    await notifyNewUpdate(store, candidate, notifier: notifier);
  }
}

/// Stable builds never offer development APKs, including an old saved choice.
String effectiveUpdateChannel(String installed, String? saved) =>
    installed == 'development' && saved != 'stable' ? 'development' : 'stable';

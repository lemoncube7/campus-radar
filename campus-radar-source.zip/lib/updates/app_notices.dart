import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/network_resilience.dart';
import 'package:campus_radar/core/notification_gateway.dart';
import 'package:campus_radar/core/storage_keys.dart';

const appNoticesRoot =
    'https://raw.githubusercontent.com/lemoncube7/campus-radar/main/updates';


/// Application notice published through GitHub repository (updates/notices.json).
class AppNotice {
  final String id;
  final String title;
  final String body;
  final DateTime publishedAt;
  final String level;
  final String? url;
  final int? minVersionCode;
  final int? maxVersionCode;
  final List<String>? platforms;
  final DateTime? expiresAt;

  const AppNotice({
    required this.id,
    required this.title,
    required this.body,
    required this.publishedAt,
    this.level = 'info',
    this.url,
    this.minVersionCode,
    this.maxVersionCode,
    this.platforms,
    this.expiresAt,
  });

  bool get isImportant => level == 'important';

  factory AppNotice.fromJson(Map<String, dynamic> json) {
    final id = json['id'];
    final title = json['title'];
    final body = json['body'];
    final publishedAtRaw = json['publishedAt'];

    if (id is! String || id.trim().isEmpty) {
      throw const FormatException('공지 id가 올바르지 않아요.');
    }
    if (title is! String || title.trim().isEmpty) {
      throw const FormatException('공지 제목이 올바르지 않아요.');
    }
    if (body is! String) {
      throw const FormatException('공지 본문이 올바르지 않아요.');
    }
    if (publishedAtRaw is! String) {
      throw const FormatException('공지 게시 시각이 올바르지 않아요.');
    }
    final publishedAt = DateTime.tryParse(publishedAtRaw);
    if (publishedAt == null) {
      throw const FormatException('공지 게시 시각 형식이 올바르지 않아요.');
    }

    final level = json['level'] is String ? (json['level'] as String) : 'info';

    String? url;
    if (json['url'] != null) {
      if (json['url'] is! String) {
        throw const FormatException('공지 url이 올바르지 않아요.');
      }
      final u = Uri.tryParse(json['url'] as String);
      if (u == null || (!u.isScheme('http') && !u.isScheme('https'))) {
        throw const FormatException('공지 url은 웹 주소여야 해요.');
      }
      url = json['url'] as String;
    }

    int? minVersionCode;
    if (json['minVersionCode'] != null) {
      if (json['minVersionCode'] is! int) {
        throw const FormatException('minVersionCode가 올바르지 않아요.');
      }
      minVersionCode = json['minVersionCode'] as int;
    }

    int? maxVersionCode;
    if (json['maxVersionCode'] != null) {
      if (json['maxVersionCode'] is! int) {
        throw const FormatException('maxVersionCode가 올바르지 않아요.');
      }
      maxVersionCode = json['maxVersionCode'] as int;
    }

    List<String>? platforms;
    if (json['platforms'] != null) {
      if (json['platforms'] is! List) {
        throw const FormatException('platforms가 올바르지 않아요.');
      }
      platforms = (json['platforms'] as List)
          .whereType<String>()
          .map((p) => p.trim().toLowerCase())
          .where((p) => p.isNotEmpty)
          .toList();
    }

    DateTime? expiresAt;
    if (json['expiresAt'] != null) {
      if (json['expiresAt'] is! String) {
        throw const FormatException('expiresAt이 올바르지 않아요.');
      }
      expiresAt = DateTime.tryParse(json['expiresAt'] as String);
      if (expiresAt == null) {
        throw const FormatException('expiresAt 형식이 올바르지 않아요.');
      }
    }

    return AppNotice(
      id: id.trim(),
      title: title.trim(),
      body: body,
      publishedAt: publishedAt,
      level: level,
      url: url,
      minVersionCode: minVersionCode,
      maxVersionCode: maxVersionCode,
      platforms: platforms,
      expiresAt: expiresAt,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'body': body,
    'publishedAt': publishedAt.toUtc().toIso8601String(),
    'level': level,
    if (url != null) 'url': url,
    if (minVersionCode != null) 'minVersionCode': minVersionCode,
    if (maxVersionCode != null) 'maxVersionCode': maxVersionCode,
    if (platforms != null) 'platforms': platforms,
    if (expiresAt != null) 'expiresAt': expiresAt!.toUtc().toIso8601String(),
  };
}

/// Parses the notices array from [rawJson]. Skips any invalid items and ignores
/// unknown fields. Returns an empty list if JSON parsing completely fails.
List<AppNotice> parseAppNoticesJson(String rawJson) {
  try {
    final decoded = jsonDecode(rawJson);
    if (decoded is! Map) return [];
    final list = decoded['notices'];
    if (list is! List) return [];
    final result = <AppNotice>[];
    for (final item in list) {
      if (item is! Map) continue;
      try {
        result.add(AppNotice.fromJson(Map<String, dynamic>.from(item)));
      } catch (_) {
        // 잘못된 항목은 건너뛴다
      }
    }
    return result;
  } catch (_) {
    // 형식이 깨져도 빈 목록 반환 (업데이트 확인은 계속 진행)
    return [];
  }
}

/// Checks whether [notice] meets the version, platform, and expiry criteria.
bool isNoticeEligible(
  AppNotice notice, {
  // Callers pass appBuild (updates.dart owns it; importing it here would be a cycle).
  required int currentBuild,
  String? currentPlatform,
  DateTime? now,
}) {
  final build = currentBuild;
  final platform = (currentPlatform ?? Platform.operatingSystem).toLowerCase();
  final currentNow = (now ?? DateTime.now()).toUtc();

  if (notice.minVersionCode != null && build < notice.minVersionCode!) {
    return false;
  }
  if (notice.maxVersionCode != null && build > notice.maxVersionCode!) {
    return false;
  }
  if (notice.platforms != null && notice.platforms!.isNotEmpty) {
    if (!notice.platforms!.contains(platform)) {
      return false;
    }
  }
  if (notice.expiresAt != null && currentNow.isAfter(notice.expiresAt!.toUtc())) {
    return false;
  }
  return true;
}

/// Loads cached notices from local SharedPreferences.
Future<List<AppNotice>> loadCachedAppNotices() async {
  try {
    final prefs = await SharedPreferences.getInstance();
    await prefs.reload();
    final raw = prefs.getString(PrefKey.appNoticesFeed);
    if (raw == null || raw.isEmpty) return [];
    final decoded = jsonDecode(raw);
    if (decoded is! List) return [];
    final result = <AppNotice>[];
    for (final item in decoded) {
      if (item is Map) {
        try {
          result.add(AppNotice.fromJson(Map<String, dynamic>.from(item)));
        } catch (_) {}
      }
    }
    result.sort((a, b) => b.publishedAt.compareTo(a.publishedAt));
    return result;
  } catch (_) {
    return [];
  }
}

/// Returns notices that are level == 'important', match client conditions, and have
/// not been closed by the user yet.
Future<List<AppNotice>> activeImportantNotices({
  // Callers pass appBuild (updates.dart owns it; importing it here would be a cycle).
  required int currentBuild,
  String? currentPlatform,
  DateTime? now,
}) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  final dismissed = (prefs.getStringList(PrefKey.appNoticesDismissed) ?? []).toSet();
  final all = await loadCachedAppNotices();
  return all
      .where(
        (n) =>
            n.isImportant &&
            !dismissed.contains(n.id) &&
            isNoticeEligible(
              n,
              currentBuild: currentBuild,
              currentPlatform: currentPlatform,
              now: now,
            ),
      )
      .toList();
}

/// Records that the user has closed this notice in the app.
Future<void> dismissAppNotice(String id) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  final dismissed = (prefs.getStringList(PrefKey.appNoticesDismissed) ?? []).toSet();
  if (dismissed.add(id)) {
    await prefs.setStringList(PrefKey.appNoticesDismissed, dismissed.toList());
  }
}

const appNoticeNotificationStyle = NotificationDetails(
  windows: WindowsNotificationDetails(),
  android: AndroidNotificationDetails(
    'app_notices',
    '앱 공지',
    channelDescription: '앱 중요 안내와 공지',
    importance: Importance.high,
    priority: Priority.high,
  ),
);

typedef NoticeNotifier = Future<bool> Function(AppNotice notice);
typedef NoticesFeedLoader = Future<String?> Function();

/// Shows a native notification on Android or Windows for [notice].
Future<bool> showNoticeNotification(AppNotice notice) async {
  if (Platform.isAndroid) {
    final android = notifications
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >();
    if (await android?.areNotificationsEnabled() != true) return false;
  } else if (!Platform.isWindows) {
    return false;
  }

  await notifications.show(
    id: notificationId('app_notice:${notice.id}'),
    title: notice.title,
    body: notice.body,
    notificationDetails: appNoticeNotificationStyle,
    payload: 'app_notice:${notice.id}',
  );
  return true;
}

/// Sends notifications for new eligible notices that have not been notified yet.
Future<void> notifyNewNotices(
  List<AppNotice> eligibleNotices, {
  NoticeNotifier notifier = showNoticeNotification,
  Store? store,
}) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  final notified = (prefs.getStringList(PrefKey.appNoticesNotified) ?? []).toSet();

  for (final notice in eligibleNotices) {
    if (notified.contains(notice.id)) continue;
    try {
      final sent = await notifier(notice);
      if (sent) {
        notified.add(notice.id);
        await prefs.setStringList(PrefKey.appNoticesNotified, notified.toList());
        if (store != null) {
          await store.log(
            'notification',
            '앱 공지 알림 발송',
            '${notice.title} · ${notice.id}',
          );
        }
      }
    } catch (e) {
      if (store != null) {
        await store.log(
          'notification',
          '앱 공지 알림 요청 실패',
          withCause('다음 업데이트 확인 때 다시 시도해요.', e),
        );
      }
    }
  }
}

/// Fetches `updates/notices.json` raw content from GitHub.
Future<String?> loadAppNoticesFeed() async {
  return retryNetworkRead(() => _loadAppNoticesFeedOnce());
}

Future<String?> _loadAppNoticesFeedOnce() async {
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
  final timer = Timer(
    const Duration(seconds: 20),
    () => client.close(force: true),
  );
  ActiveRequests.add(client);
  try {
    final uri = Uri.parse('$appNoticesRoot/notices.json').replace(
      queryParameters: {'check': '${DateTime.now().millisecondsSinceEpoch}'},
    );
    final req = await client.getUrl(uri);
    req.headers.set('Cache-Control', 'no-cache');
    final response = await req.close().timeout(const Duration(seconds: 10));
    if (response.statusCode == 404) {
      await response.listen((_) {}).cancel();
      return null;
    }
    if (response.statusCode != 200) {
      throw NetworkHttpException(response.statusCode);
    }
    final bytes = <int>[];
    await for (final chunk in response.timeout(const Duration(seconds: 10))) {
      bytes.addAll(chunk);
      if (bytes.length > 200000) {
        throw const FormatException('공지 정보가 너무 커요.');
      }
    }
    return utf8.decode(bytes);
  } finally {
    timer.cancel();
    ActiveRequests.remove(client);
    client.close(force: true);
  }
}

/// Processes incoming notice feed: caches notices, filters eligible ones, and
/// triggers notifications for new items.
Future<List<AppNotice>> processAppNotices(
  String rawJson, {
  Store? store,
  NoticeNotifier notifier = showNoticeNotification,
  // Callers pass appBuild (updates.dart owns it; importing it here would be a cycle).
  required int currentBuild,
  String? currentPlatform,
  DateTime? now,
}) async {
  final notices = parseAppNoticesJson(rawJson);

  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  await prefs.setString(
    PrefKey.appNoticesFeed,
    jsonEncode(notices.map((n) => n.toJson()).toList()),
  );

  final eligible = notices
      .where(
        (n) => isNoticeEligible(
          n,
          currentBuild: currentBuild,
          currentPlatform: currentPlatform,
          now: now,
        ),
      )
      .toList();

  await notifyNewNotices(
    eligible,
    notifier: notifier,
    store: store,
  );

  return eligible;
}

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:campus_radar/updates/app_notices.dart';
import 'package:campus_radar/updates/updates.dart' show installedAppBuild;

class AppNoticesPage extends StatefulWidget {
  const AppNoticesPage({super.key});

  @override
  State<AppNoticesPage> createState() => _AppNoticesPageState();
}

class _AppNoticesPageState extends State<AppNoticesPage> {
  List<AppNotice> notices = [];
  bool busy = true;
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load({bool refreshNetwork = false}) async {
    setState(() {
      busy = true;
      error = null;
    });
    try {
      if (refreshNetwork) {
        try {
          final raw = await loadAppNoticesFeed();
          if (raw != null) {
            await processAppNotices(raw, currentBuild: installedAppBuild);
          }
        } catch (_) {
          // Network errors during refresh don't block displaying cached notices
        }
      }
      final loaded = await loadCachedAppNotices();
      final eligible = loaded
          .where((n) => isNoticeEligible(n, currentBuild: installedAppBuild))
          .toList();
      if (mounted) {
        setState(() {
          notices = eligible;
          busy = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          busy = false;
          error = '공지 목록을 읽지 못했어요.';
        });
      }
    }
  }

  Future<void> openUrl(String url) async {
    final uri = Uri.tryParse(url);
    if (uri != null && (uri.isScheme('http') || uri.isScheme('https'))) {
      try {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } catch (_) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('링크를 열지 못했어요.')),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('공지'),
      ),
      body: RefreshIndicator(
        onRefresh: () => load(refreshNetwork: true),
        child: busy
            ? const Center(child: CircularProgressIndicator())
            : error != null
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(error!),
                          const SizedBox(height: 12),
                          OutlinedButton(
                            onPressed: () => load(refreshNetwork: true),
                            child: const Text('다시 시도'),
                          ),
                        ],
                      ),
                    ),
                  )
                : notices.isEmpty
                    ? ListView(
                        physics: const AlwaysScrollableScrollPhysics(),
                        children: [
                          SizedBox(
                            height: MediaQuery.sizeOf(context).height * 0.4,
                            child: Center(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    Icons.campaign_outlined,
                                    size: 48,
                                    color: colorScheme.outline,
                                  ),
                                  const SizedBox(height: 16),
                                  Text(
                                    '등록된 공지가 없어요.',
                                    style: theme.textTheme.bodyLarge?.copyWith(
                                      color: colorScheme.onSurfaceVariant,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      )
                    : ListView.separated(
                        physics: const AlwaysScrollableScrollPhysics(),
                        padding: EdgeInsets.fromLTRB(
                          16,
                          16,
                          16,
                          32 + MediaQuery.paddingOf(context).bottom,
                        ),
                        itemCount: notices.length,
                        separatorBuilder: (context, index) => const SizedBox(height: 12),
                        itemBuilder: (context, index) {
                          final item = notices[index];
                          final dateStr =
                              '${item.publishedAt.year}. ${item.publishedAt.month.toString().padLeft(2, '0')}. ${item.publishedAt.day.toString().padLeft(2, '0')}';
                          return Card(
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                              side: BorderSide(
                                color: item.isImportant
                                    ? colorScheme.error.withValues(alpha: 0.5)
                                    : colorScheme.outlineVariant,
                              ),
                            ),
                            color: item.isImportant
                                ? colorScheme.errorContainer.withValues(alpha: 0.25)
                                : colorScheme.surfaceContainerLow,
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      if (item.isImportant) ...[
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 8,
                                            vertical: 2,
                                          ),
                                          decoration: BoxDecoration(
                                            color: colorScheme.errorContainer,
                                            borderRadius:
                                                BorderRadius.circular(6),
                                          ),
                                          child: Text(
                                            '중요',
                                            style: theme.textTheme.labelSmall
                                                ?.copyWith(
                                              fontWeight: FontWeight.bold,
                                              color:
                                                  colorScheme.onErrorContainer,
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 8),
                                      ],
                                      Expanded(
                                        child: Text(
                                          item.title,
                                          style: theme.textTheme.titleMedium
                                              ?.copyWith(
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    dateStr,
                                    style: theme.textTheme.labelSmall?.copyWith(
                                      color: colorScheme.onSurfaceVariant,
                                    ),
                                  ),
                                  const SizedBox(height: 12),
                                  SelectableText(
                                    item.body,
                                    style: theme.textTheme.bodyMedium?.copyWith(
                                      height: 1.4,
                                    ),
                                  ),
                                  if (item.url != null &&
                                      item.url!.isNotEmpty) ...[
                                    const SizedBox(height: 12),
                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: OutlinedButton.icon(
                                        icon: const Icon(
                                          Icons.open_in_new,
                                          size: 16,
                                        ),
                                        label: const Text('자세히 보기'),
                                        onPressed: () => openUrl(item.url!),
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          );
                        },
                      ),
      ),
    );
  }
}

import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/core/developer_mode.dart';
import 'package:campus_radar/updates/release_history_page.dart';
import 'package:campus_radar/updates/app_notices_page.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/updates/update_download.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/network_resilience.dart';
import 'package:campus_radar/updates/updates.dart';
import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UpdatePage extends StatefulWidget {
  const UpdatePage({super.key});
  @override
  State<UpdatePage> createState() => _UpdatePageState();
}

class _UpdatePageState extends State<UpdatePage> {
  final url = TextEditingController();
  bool busy = false;
  String message = '';
  Map<String, dynamic>? update;
  String channel = appReleaseChannel == 'development'
      ? 'development'
      : 'stable';
  @override
  void initState() {
    super.initState();
    if (Platform.isAndroid) {
      unawaited(loadChannel());
    }
    SharedPreferences.getInstance().then((p) {
      if (mounted) {
        setState(
          () => url.text =
              p.getString(Platform.isIOS ? 'iosUpdateUrl' : 'updateUrl') ??
              (Platform.isIOS
                  ? 'https://github.com/lemoncube7/campus-radar/releases/download/ios-preview/ios-latest.json'
                  : 'https://github.com/lemoncube7/campus-radar/releases/latest/download/latest.json'),
        );
      }
    });
  }

  Future<void> loadChannel() async {
    final c = await updateChannel();
    final candidate = await cachedUpdate();
    if (mounted) {
      setState(() {
        channel = c;
        update = candidate;
        if (candidate != null) {
          message =
              '새 버전 ${candidate['versionName']} · ${channelLabel(candidate['channel'])}\n${candidate['notes'] ?? ''}';
        }
      });
    }
  }

  Future<void> checkAndroid() async {
    setState(() {
      busy = true;
      message = '업데이트 확인 중…';
    });
    Store? s;
    try {
      s = await Store.open();
      await checkForUpdates(s);
      final candidate = await cachedUpdate();
      final p = await SharedPreferences.getInstance();
      await p.reload();
      final raw = p.getString('updateInfo:$channel');
      final latest = raw == null ? null : jsonDecode(raw) as Map;
      if (mounted) {
        setState(() {
          update = candidate;
          message = candidate != null
              ? '새 버전 ${candidate['versionName']} · ${channelLabel(candidate['channel'])}\n${candidate['notes'] ?? ''}'
              : p.getString(PrefKey.updateCheckError)?.isNotEmpty == true
              ? p.getString(PrefKey.updateCheckError)!
              : latest == null
              ? '이 채널에 게시된 버전이 없어요.'
              : '${channelLabel(channel)} 최신 게시: ${latest['versionName']}\n현재 설치 버전보다 새로운 업데이트가 없어요.';
        });
      }
    } catch (_) {
      if (mounted) setState(() => message = '업데이트 정보를 가져오지 못했어요.');
    } finally {
      await s?.db.close();
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> check() async {
    if (Platform.isAndroid) {
      await checkAndroid();
      return;
    }
    setState(() {
      busy = true;
      update = null;
    });
    try {
      await systemLog('업데이트 확인 시작', '업데이트 정보를 요청해요.');
      final uri = Uri.parse(url.text.trim());
      final bytes = await downloadUpdateFile(uri, limit: 100000);
      final manifest = jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
      final current =
          await bridge.invokeNative<int>(NativeMethod.versionCode) ?? 1;
      final fileKey = Platform.isIOS ? 'ipaUrl' : 'apkUrl';
      if (manifest['versionCode'] is! int ||
          manifest[fileKey] is! String ||
          !RegExp(r'^[a-fA-F0-9]{64}$').hasMatch(manifest['sha256'] ?? '')) {
        throw const FormatException('업데이트 정보 형식이 잘못됐어요.');
      }
      if (Uri.parse(manifest[fileKey]).scheme != 'https' ||
          (Platform.isIOS &&
              (manifest['sourceUrl'] is! String ||
                  Uri.parse(manifest['sourceUrl']).scheme != 'https'))) {
        throw const FormatException('업데이트 파일과 소스는 HTTPS로 제공해야 해요.');
      }
      final p = await SharedPreferences.getInstance();
      await p.setString(
        Platform.isIOS ? 'iosUpdateUrl' : 'updateUrl',
        uri.toString(),
      );
      await systemLog(
        '업데이트 확인 결과',
        '현재 빌드 $current · 제공 버전 ${manifest['versionName']} (${manifest['versionCode']})',
      );
      if (!mounted) return;
      setState(() {
        if (manifest['versionCode'] > current) {
          update = manifest;
          message =
              '새 버전 ${manifest['versionName']}\n${manifest['notes'] ?? ''}';
        } else {
          message = '최신 버전이에요.';
        }
      });
    } catch (e) {
      await systemLog(
        '업데이트 확인 실패',
        e is FormatException ? e.message.toString() : '네트워크 또는 업데이트 정보 처리 오류',
      );
      if (mounted) {
        setState(
          () => message = e is FormatException
              ? e.message.toString()
              : '업데이트 정보를 가져오지 못했어요.',
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> install() async {
    setState(() => busy = true);
    try {
      if (Platform.isIOS) {
        await bridge.invokeNative(NativeMethod.openAltStoreSource, {
          'url': update!['sourceUrl'],
        });
        if (mounted) {
          setState(() => message = 'AltStore Classic에서 캠퍼스레이더의 업데이트를 선택해 주세요.');
        }
        return;
      }
      await systemLog(
        '업데이트 다운로드 시작',
        '대상 ${update!["versionName"]} (${update!["versionCode"]})',
      );
      final bytes = await retryNetworkRead(
        () => downloadUpdateFile(Uri.parse(update!['apkUrl'])),
      );
      if (sha256.convert(bytes).toString() !=
          update!['sha256'].toString().toLowerCase()) {
        throw const FormatException('APK 검증에 실패했어요.');
      }
      await systemLog(
        '업데이트 다운로드 검증 완료',
        'SHA-256 일치 · ${bytes.length}바이트. 설치 완료는 아직 확인되지 않았어요.',
      );
      final file = File(
        '${(await getTemporaryDirectory()).path}/campus-radar-update.apk',
      );
      await file.writeAsBytes(bytes, flush: true);
      final outcome = await bridge.invokeNative<String>(
        NativeMethod.installApk,
        {'path': file.path, 'versionCode': update!['versionCode']},
      );
      await systemLog(
        outcome == 'permission' ? '업데이트 설치 권한 요청' : '업데이트 설치 화면 열림',
        '대상 ${update!["versionName"]} · ${outcome == "permission" ? "설치 권한을 허용한 후 업데이트를 다시 눌러 주세요." : "설치 완료 여부는 변경된 버전의 다음 실행 때 확인해요."}',
      );
      if (mounted) {
        setState(
          () => message = '설치 화면에서 업데이트를 확인해 주세요. 설치 권한을 켰다면 업데이트 버튼을 다시 누르세요.',
        );
      }
    } catch (e) {
      await systemLog(
        '업데이트 설치 실패',
        e is FormatException
            ? e.message.toString()
            : e is PlatformException
            ? '기기 설치 요청 오류 (${e.code})'
            : '다운로드 또는 설치 처리 오류',
      );
      if (mounted) {
        setState(
          () => message = e is FormatException
              ? e.message.toString()
              : e is PlatformException
              ? e.message ?? '설치 실패'
              : '${networkFailureMessage(e)} 설치된 앱은 그대로 유지돼요.',
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    url.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('앱 업데이트')),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Card(
          child: ListTile(
            leading: const Icon(Icons.verified_outlined),
            title: Text('현재 $installedAppVersion ($installedAppBuild)'),
            subtitle: Text(
              appReleaseChannel == 'development'
                  ? '개발 버전 설치 · 받을 업데이트를 선택해 주세요.'
                  : '정식 버전 설치 · 정식 업데이트만 안내해요.',
            ),
          ),
        ),
        if (Platform.isAndroid &&
            (appReleaseChannel == 'development' || isDeveloperMode))
          DropdownButtonFormField<String>(
            initialValue: channel,
            key: ValueKey(channel),
            decoration: const InputDecoration(labelText: '업데이트 채널'),
            items: const [
              DropdownMenuItem(value: 'stable', child: Text('정식 버전만 받기')),
              DropdownMenuItem(value: 'development', child: Text('개발 버전도 받기')),
            ],
            onChanged: busy
                ? null
                : (value) async {
                    if (value == null) return;
                    final p = await SharedPreferences.getInstance();
                    await p.setString(PrefKey.updateChannel, value);
                    setState(() {
                      channel = value;
                      update = null;
                    });
                    await checkAndroid();
                  },
          ),
        if (Platform.isAndroid &&
            (appReleaseChannel == 'development' || isDeveloperMode))
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 12),
            child: Text(
              '개발 버전은 새 기능을 먼저 제공하며 검증이 진행 중일 수 있어요. 정식 채널로 바꿔도 낮은 버전으로 자동 되돌리지 않아요. 자동 수집 시에도 업데이트를 확인해요.',
            ),
          ),
        if (Platform.isAndroid) ...[
          OutlinedButton.icon(
            icon: const Icon(Icons.history),
            label: Text(update == null ? '업데이트 내역 보기' : '건너뛴 버전까지 변경 내역 보기'),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute<void>(
                builder: (_) => ReleaseHistoryPage(
                  fromBuild: update == null ? null : installedAppBuild,
                  throughBuild: update?['versionCode'] as int?,
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            icon: const Icon(Icons.campaign_outlined),
            label: const Text('공지 목록 보기'),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute<void>(
                builder: (_) => const AppNoticesPage(),
              ),
            ),
          ),
        ],
        const SizedBox(height: 16),
        if (Platform.isIOS && isDeveloperMode)
          TextField(
            controller: url,
            decoration: const InputDecoration(
              labelText: '업데이트 정보 주소 (HTTPS)',
              hintText: 'https://…/latest.json',
            ),
          ),
        const SizedBox(height: 16),
        FilledButton.tonal(
          onPressed: busy ? null : check,
          child: const Text('업데이트 확인'),
        ),
        if (busy) const LinearProgressIndicator(),
        const SizedBox(height: 16),
        Text(message),
        if (update != null)
          FilledButton(
            onPressed: busy ? null : install,
            child: const Text('업데이트'),
          ),
        const SizedBox(height: 16),
        Text(
          Platform.isIOS
              ? '업데이트를 누르면 AltStore Classic의 소스를 열어요. 설치는 AltStore에서 확인해요.'
              : '업데이트 파일을 받은 뒤 안드로이드 설치 화면에서 최종 확인해요.',
        ),
      ],
    ),
  );
}

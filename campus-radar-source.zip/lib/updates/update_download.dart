import 'dart:async';
import 'dart:io';
import 'package:campus_radar/core/network_resilience.dart';

Future<List<int>> downloadUpdateFile(
  Uri uri, {
  int limit = 100000000,
  int redirects = 0,
  DateTime? deadline,
}) async {
  deadline ??= DateTime.now().add(const Duration(seconds: 120));
  if (!deadline.isAfter(DateTime.now())) {
    throw TimeoutException('다운로드 전체 시간 초과');
  }
  if (redirects > 8) throw const FormatException('다운로드 주소가 반복돼요.');
  if (uri.scheme != 'https') {
    throw const FormatException('HTTPS 주소를 사용해 주세요.');
  }
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 20);
  final timer = Timer(
    deadline.difference(DateTime.now()),
    () => client.close(force: true),
  );
  ActiveRequests.add(client);
  try {
    final req = await client.getUrl(uri);
    req.followRedirects = false;
    final response = await req.close().timeout(const Duration(seconds: 30));
    if (response.isRedirect) {
      final location = response.headers.value('location');
      if (location == null) throw const FormatException('다운로드 이동 실패');
      return await downloadUpdateFile(
        uri.resolve(location),
        limit: limit,
        redirects: redirects + 1,
        deadline: deadline,
      );
    }
    if (response.statusCode != 200) {
      throw NetworkHttpException(response.statusCode);
    }
    final bytes = <int>[];
    await for (final chunk in response.timeout(const Duration(seconds: 60))) {
      bytes.addAll(chunk);
      if (bytes.length > limit) {
        throw const FormatException('파일 크기 제한을 초과했어요.');
      }
    }
    return bytes;
  } finally {
    timer.cancel();
    ActiveRequests.remove(client);
    client.close(force: true);
  }
}

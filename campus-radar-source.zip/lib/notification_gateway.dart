import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;

final notifications = FlutterLocalNotificationsPlugin();
int notificationId(String key) {
  final b = sha256.convert(utf8.encode(key)).bytes;
  return ((b[0] << 24) | (b[1] << 16) | (b[2] << 8) | b[3]) & 0x7fffffff;
}

const noticeStyle = NotificationDetails(
  windows: WindowsNotificationDetails(),
  iOS: DarwinNotificationDetails(),
  android: AndroidNotificationDetails(
    'assignments',
    '과제·콘텐츠 알림',
    channelDescription: '새 과제와 마감 하루 전 알림',
    importance: Importance.high,
    priority: Priority.high,
  ),
);
Future<void> initNotifications({void Function(String?)? onTap}) async {
  tzdata.initializeTimeZones();
  await notifications.initialize(
    const InitializationSettings(
      windows: WindowsInitializationSettings(
        appName: 'Campus Radar',
        appUserModelId: 'CampusRadar.Desktop',
        guid: 'b145528f-3d6a-4d94-b532-1be39e636b50',
      ),
      android: AndroidInitializationSettings('ic_stat_radar'),
      iOS: DarwinInitializationSettings(
        requestAlertPermission: false,
        requestBadgePermission: false,
        requestSoundPermission: false,
      ),
    ),
    onDidReceiveNotificationResponse: (r) => onTap?.call(r.payload),
  );
}

Future<void> requestNotificationPermission() async {
  if (Platform.isIOS) {
    await notifications
        .resolvePlatformSpecificImplementation<
          IOSFlutterLocalNotificationsPlugin
        >()
        ?.requestPermissions(alert: true, badge: true, sound: true);
  } else {
    await notifications
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >()
        ?.requestNotificationsPermission();
  }
}

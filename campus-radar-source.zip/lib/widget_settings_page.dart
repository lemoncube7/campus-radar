import 'package:flutter/material.dart';
import 'lock_screen_settings_page.dart';
import 'widget_text_page.dart';
import 'native_bridge.dart';
import 'native_contract.dart';

class WidgetSettingsPage extends StatelessWidget {
  const WidgetSettingsPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('위젯·잠금화면')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const ListTile(
          leading: Icon(Icons.checklist),
          title: Text('과제·콘텐츠 위젯'),
          subtitle: Text(
            '휴대전화 홈 화면을 길게 누르고 위젯에서 캠퍼스레이더 과제 현황을 선택하세요. 항목은 상세, 배경은 전체 할 일로 연결됩니다.',
          ),
        ),
        ListTile(
          leading: const Icon(Icons.calendar_view_week),
          title: const Text('시간표 위젯 추가'),
          subtitle: const Text('일정의 시간표에서 만든 수업을 표시합니다.'),
          onTap: () async {
            try {
              await bridge.invokeNative(NativeMethod.pinTimetableWidget);
            } catch (_) {
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('홈 화면의 위젯 목록에서 시간표를 추가해 주세요.')),
                );
              }
            }
          },
        ),
        ListTile(
          leading: const Icon(Icons.lock_outline),
          title: const Text('잠금화면 카드'),
          subtitle: const Text('접근성 권한 · 전체/작은 카드 · 위치·투명도'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const LockScreenSettingsPage()),
          ),
        ),
        ListTile(
          leading: const Icon(Icons.text_fields),
          title: const Text('글씨 크기'),
          subtitle: const Text('과제 위젯 · 시간표 · 잠금화면'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const WidgetTextPage()),
          ),
        ),
      ],
    ),
  );
}

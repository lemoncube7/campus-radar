import 'chat_threads.dart';
import 'app_help_catalog.dart';
import 'app_help_page.dart';
import 'feature_discovery.dart';
import 'navigation_contract.dart';
import 'native_contract.dart';
import 'ai_protocol.dart';
import 'course_catalog.dart';
import 'app_storage.dart';
import 'native_bridge.dart';
import 'course_labels.dart';
import 'package:flutter_markdown_plus/flutter_markdown_plus.dart';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'chat.dart';

class AiChatPage extends StatefulWidget {
  final Map<String, dynamic>? course;
  const AiChatPage({
    super.key,
    this.course,
    this.embedded = false,
    this.initialQuestion,
  });
  final String? initialQuestion;
  final bool embedded;
  @override
  State<AiChatPage> createState() => _AiChatPageState();
}

class _AiChatPageState extends State<AiChatPage> {
  final input = TextEditingController();
  final scroll = ScrollController();
  List<Map<String, String>> history = [];
  bool loading = true, busy = false, share = false, consent = false;
  String? error;
  bool waiting = false, cancelled = false;
  String? pendingQuestion;
  String threadId = DateTime.now().microsecondsSinceEpoch.toString();
  String get key =>
      'aiChat:${widget.course == null ? 'all' : courseKey(widget.course!)}';
  @override
  void initState() {
    super.initState();
    FeatureDiscovery.record(DiscoverFeature.chat);
    input.text = widget.initialQuestion ?? '';
    unawaited(load());
  }

  @override
  void dispose() {
    input.dispose();
    scroll.dispose();
    super.dispose();
  }

  Future<void> load() async {
    Store? s;
    try {
      s = await Store.open();
      // Previous conversations are available explicitly, not forced into a new visit.
      await loadChatThreads(s, key);
      final agreed = await s.meta('aiChatConsent') == '1';
      final savedShare = await s.meta('aiChatShare');
      if (mounted) {
        setState(() {
          history = [];
          consent = agreed;
          share = savedShare == 'yes';
        });
      }
    } catch (_) {
      if (mounted) setState(() => error = '저장된 대화를 읽지 못했습니다.');
    } finally {
      await s?.db.close();
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> send() async {
    if (busy || input.text.trim().isEmpty) return;
    final preferenceStore = await Store.open();
    String? savedPreference;
    try {
      savedPreference = await preferenceStore.meta('aiChatShare');
    } finally {
      await preferenceStore.db.close();
    }
    if (savedPreference == null && mounted) {
      final choice = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('과제·공지·시간표를 답변에 활용할까요?'),
          content: const Text(
            '허용하면 수집한 과제·공지 일부와 저장된 시간표를 Gemini에 함께 보내요. 선택은 다음 대화에도 유지되며 참고 자료 메뉴에서 바꿀 수 있어요.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('대화만 보내기'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('참고하기'),
            ),
          ],
        ),
      );
      if (choice == null) return;
      final store = await Store.open();
      try {
        await store.setMeta('aiChatShare', choice ? 'yes' : 'no');
      } finally {
        await store.db.close();
      }
      if (!mounted) return;
      setState(() => share = choice);
    }
    final question = input.text.trim();
    if (busy || question.isEmpty) return;
    if (!mounted) return;
    if (!consent) {
      final accepted = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('AI 채팅 전송 동의'),
          content: const Text(
            '질문과 최근 대화가 개인 키를 통해 Google Gemini로 전송됩니다. ‘수집 정보 공유’를 켜면 해당 범위의 과제·콘텐츠와 저장된 공지 본문 일부와 시간표도 함께 전송됩니다. 무료 API의 데이터 처리 조건을 확인해 주세요. 로그인 비밀번호와 API 키는 대화 자료에 포함하지 않습니다.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('취소'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('동의하고 질문'),
            ),
          ],
        ),
      );
      if (accepted != true) return;
      consent = true;
    }
    setState(() {
      busy = true;
      cancelled = false;
      waiting = true;
      pendingQuestion = question;
      error = null;
    });
    Store? s;
    try {
      s = await Store.open();
      await s.setAiSetting(AiSetting.aiChatConsent, '1');
      final answer = await askCampusAi(
        s,
        history,
        question,
        includeData: share,
        cancelled: () => !mounted || cancelled,
        onProgress: (value) {
          if (mounted) setState(() => waiting = value);
        },
        courseId: widget.course == null ? null : courseKey(widget.course!),
      );
      final next = [
        ...history,
        {'role': 'user', 'text': question},
        {'role': 'model', 'text': answer},
      ];
      final retained = next
          .skip(next.length > 40 ? next.length - 40 : 0)
          .toList();
      await saveChatThread(
        s,
        key,
        ChatThread(
          threadId,
          retained.first['text']!
              .replaceAll('\n', ' ')
              .characters
              .take(48)
              .toString(),
          retained,
        ),
      );
      if (mounted) {
        setState(() {
          history = retained;
          input.clear();
        });
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (scroll.hasClients) {
            scroll.animateTo(
              scroll.position.maxScrollExtent,
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOut,
            );
          }
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => error = e is AiFailure ? e.message : '채팅을 완료하지 못했습니다.');
      }
    } finally {
      await s?.db.close();
      if (mounted) {
        setState(() {
          busy = false;
          waiting = false;
          pendingQuestion = null;
        });
      }
    }
  }

  void newConversation() {
    if (busy) return;
    setState(() {
      history = [];
      threadId = DateTime.now().microsecondsSinceEpoch.toString();
      error = null;
      input.clear();
    });
  }

  Future<void> previousConversations() async {
    try {
      final store = await Store.open();
      late List<ChatThread> threads;
      try {
        threads = await loadChatThreads(store, key);
      } finally {
        await store.db.close();
      }
      if (!mounted) return;
      final selected = await showModalBottomSheet<ChatThread>(
        context: context,
        isScrollControlled: true,
        builder: (ctx) => SafeArea(
          child: SizedBox(
            height: MediaQuery.sizeOf(ctx).height * .65,
            child: Column(
              children: [
                const ListTile(
                  title: Text('이전 대화'),
                  subtitle: Text('선택한 대화만 답변의 맥락으로 사용해요.'),
                ),
                Expanded(
                  child: threads.isEmpty
                      ? const Center(child: Text('저장된 대화가 없어요.'))
                      : ListView.builder(
                          itemCount: threads.length,
                          itemBuilder: (ctx, i) => ListTile(
                            title: Text(
                              threads[i].title,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            subtitle: Text(
                              '${threads[i].messages.length ~/ 2}개 질문',
                            ),
                            trailing: const Icon(Icons.chevron_right),
                            onTap: () => Navigator.pop(ctx, threads[i]),
                          ),
                        ),
                ),
              ],
            ),
          ),
        ),
      );
      if (selected != null && mounted) {
        setState(() {
          threadId = selected.id;
          history = selected.messages;
          error = null;
        });
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (scroll.hasClients) scroll.jumpTo(scroll.position.maxScrollExtent);
        });
      }
    } catch (_) {
      if (mounted) setState(() => error = '이전 대화를 불러오지 못했어요.');
    }
  }

  Future<void> clear() async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('대화를 지울까요?'),
        content: const Text(
          '이 화면에 저장된 대화를 삭제합니다. 이미 전송된 데이터는 Google 측 보관 정책을 따릅니다.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('지우기'),
          ),
        ],
      ),
    );
    if (yes != true) return;
    final s = await Store.open();
    try {
      final threads = await loadChatThreads(s, key);
      threads.removeWhere((t) => t.id == threadId);
      await s.setMeta(
        '$key:threads',
        jsonEncode(threads.map((t) => t.toJson()).toList()),
      );
      if (threadId == 'legacy') await s.setMeta(key, '[]');
      if (mounted) setState(() => history = []);
    } finally {
      await s.db.close();
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: widget.embedded
        ? null
        : AppBar(
            title: Text(
              widget.course == null
                  ? 'AI 채팅'
                  : '${courseLabel('${widget.course!['course_nm']}')} 질문',
            ),
            actions: [
              IconButton(
                tooltip: 'AI 설정',
                onPressed: () => navigateTo(context, AiSettingsDestination()),
                icon: const Icon(Icons.settings_outlined),
              ),
              IconButton(
                tooltip: '대화 지우기',
                onPressed: busy ? null : clear,
                icon: const Icon(Icons.delete_outline),
              ),
            ],
          ),
    body: SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                FilledButton.tonalIcon(
                  onPressed: busy ? null : newConversation,
                  icon: const Icon(Icons.add),
                  label: const Text('새 대화'),
                ),
                const SizedBox(width: 8),
                TextButton.icon(
                  onPressed: busy ? null : previousConversations,
                  icon: const Icon(Icons.history),
                  label: const Text('이전 대화'),
                ),
              ],
            ),
          ),
          if (widget.embedded)
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: busy ? null : clear,
                icon: const Icon(Icons.delete_outline),
                label: const Text('대화 지우기'),
              ),
            ),
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton.icon(
              icon: const Icon(Icons.help_outline),
              label: const Text('기능 안내·빠른 설정'),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute<void>(builder: (_) => const AppHelpPage()),
              ),
            ),
          ),
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton.icon(
              icon: Icon(
                share
                    ? Icons.library_books_outlined
                    : Icons.chat_bubble_outline,
                size: 18,
              ),
              label: Text(share ? '과제·공지 참고 중' : '참고 자료 선택'),
              onPressed: busy
                  ? null
                  : () async {
                      final selected = await showModalBottomSheet<bool>(
                        context: context,
                        builder: (ctx) => SafeArea(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const ListTile(
                                title: Text('과제·공지·시간표를 답변에 활용할까요?'),
                                subtitle: Text(
                                  '허용하면 수집 자료 최대 60개·공지 25개·시간표 64칸을 Gemini로 전송해요. 선택을 기억하며, 첨부파일·계정 비밀번호는 보내지 않아요. 이전 대화는 공유 설정과 관계없이 전송돼요.',
                                ),
                              ),
                              ListTile(
                                title: const Text('과제·공지 참고하기'),
                                trailing: share
                                    ? const Icon(Icons.check)
                                    : null,
                                onTap: () => Navigator.pop(ctx, true),
                              ),
                              ListTile(
                                title: const Text('질문과 대화만 보내기'),
                                trailing: !share
                                    ? const Icon(Icons.check)
                                    : null,
                                onTap: () => Navigator.pop(ctx, false),
                              ),
                            ],
                          ),
                        ),
                      );
                      if (selected == null) return;
                      final store = await Store.open();
                      try {
                        await store.setMeta(
                          'aiChatShare',
                          selected ? 'yes' : 'no',
                        );
                      } finally {
                        await store.db.close();
                      }
                      if (mounted) setState(() => share = selected);
                    },
            ),
          ),
          if (share)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextButton(
                onPressed: busy
                    ? null
                    : () async {
                        final s = await Store.open();
                        try {
                          final preview = await chatContext(
                            s,
                            courseId: widget.course == null
                                ? null
                                : courseKey(widget.course!),
                          );
                          if (context.mounted) {
                            showDialog<void>(
                              context: context,
                              builder: (ctx) => AlertDialog(
                                title: const Text('현재 전송 자료'),
                                content: SingleChildScrollView(
                                  child: SelectableText(preview),
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.pop(ctx),
                                    child: const Text('닫기'),
                                  ),
                                ],
                              ),
                            );
                          }
                        } finally {
                          await s.db.close();
                        }
                      },
                child: const Text('전송 자료 미리보기'),
              ),
            ),
          Expanded(
            child: loading
                ? const Center(child: CircularProgressIndicator())
                : ListView(
                    controller: scroll,
                    padding: const EdgeInsets.all(16),
                    children: [
                      if (history.isEmpty)
                        const Padding(
                          padding: EdgeInsets.all(24),
                          child: Text(
                            '“이번 주에 먼저 할 과제는?”처럼 질문해 보세요. 내 과제에 대한 질문은 참고 자료를 선택해 주세요. AI는 제출이나 일정 변경을 실행하지 않습니다.',
                          ),
                        ),
                      if (history.isEmpty)
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            for (final q in [
                              'AI 공지 일정을 캘린더에 표시하려면?',
                              '오늘 먼저 할 일은?',
                              '이번 주 마감은?',
                              '이 과목 공지 요약',
                            ])
                              ActionChip(
                                label: Text(q),
                                onPressed: busy
                                    ? null
                                    : () {
                                        input.text = q;
                                      },
                              ),
                          ],
                        ),
                      ...history.map(
                        (m) => Align(
                          alignment: m['role'] == 'user'
                              ? Alignment.centerRight
                              : Alignment.centerLeft,
                          child: Container(
                            margin: const EdgeInsets.symmetric(vertical: 5),
                            padding: const EdgeInsets.all(14),
                            constraints: const BoxConstraints(maxWidth: 620),
                            decoration: BoxDecoration(
                              color: m['role'] == 'user'
                                  ? Theme.of(
                                      context,
                                    ).colorScheme.primaryContainer
                                  : Theme.of(
                                      context,
                                    ).colorScheme.surfaceContainerHighest,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: m['role'] == 'model'
                                ? MarkdownBody(
                                    data: displayCourseText(m['text']!),
                                    selectable: true,
                                    imageBuilder: (uri, title, alt) =>
                                        Text(alt ?? '이미지'),
                                    onTapLink: (text, href, title) async {
                                      if (href == null) return;
                                      final help = appHelpLink(href);
                                      if (help != null) {
                                        await openHelpGuide(context, help);
                                        return;
                                      }
                                      final u = Uri.tryParse(href);
                                      if (u == null ||
                                          u.scheme != 'https' ||
                                          u.host.isEmpty ||
                                          u.userInfo.isNotEmpty) {
                                        return;
                                      }
                                      try {
                                        await bridge.invokeNative(
                                          NativeMethod.openChatLink,
                                          {'url': u.toString()},
                                        );
                                      } catch (_) {
                                        if (context.mounted) {
                                          ScaffoldMessenger.of(
                                            context,
                                          ).showSnackBar(
                                            const SnackBar(
                                              content: Text('링크를 열지 못했습니다.'),
                                            ),
                                          );
                                        }
                                      }
                                    },
                                  )
                                : SelectableText(m['text']!),
                          ),
                        ),
                      ),
                    ],
                  ),
          ),
          if (error != null)
            Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                error!,
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            ),
          if (busy) ...[
            const LinearProgressIndicator(),
            ListTile(
              title: Text(
                pendingQuestion ?? '',
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              subtitle: Text(
                waiting ? '질문 접수됨 · 앞선 AI 작업이 끝나면 답변해요' : '답변을 만들고 있어요',
              ),
              trailing: waiting
                  ? TextButton(
                      onPressed: () => setState(() => cancelled = true),
                      child: const Text('대기 취소'),
                    )
                  : null,
            ),
          ],
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Expanded(
                  child: TextField(
                    controller: input,
                    enabled: !busy,
                    maxLength: 2000,
                    minLines: 1,
                    maxLines: 4,
                    decoration: const InputDecoration(
                      hintText: '질문 입력',
                      counterText: '',
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(
                  tooltip: '질문 보내기',
                  onPressed: busy ? null : send,
                  icon: const Icon(Icons.send),
                ),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.only(bottom: 8),
            child: Text(
              '개인 Gemini 키 사용 · 대화별 최근 20개 질문 보관',
              style: TextStyle(fontSize: 12),
            ),
          ),
        ],
      ),
    ),
  );
}

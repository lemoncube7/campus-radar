import 'native_contract.dart';
import 'ai_state_repository.dart';
import 'ai_state_models.dart';
import 'dart:convert';
import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'app_storage.dart';
import 'native_bridge.dart';
import 'campus_models.dart';
import 'course_labels.dart';

Future<void> loadCourseAliases() async {
  final prefs = await SharedPreferences.getInstance();
  final raw = prefs.getString('courseAliases');
  try {
    courseAliases = raw == null
        ? {}
        : Map<String, String>.from(jsonDecode(raw));
  } catch (_) {
    courseAliases = {};
  }
  // Repair already-linked calendar titles even when an alias is not edited again.
  final migration = jsonEncode(courseAliases);
  if ((Platform.isAndroid || Platform.isIOS) &&
      prefs.getString('calendarAliasMigration040') != migration) {
    try {
      for (final entry in courseAliases.entries) {
        await bridge.invokeNative(NativeMethod.calendarRenameCourse, {
          'original': entry.key,
          'previous': entry.key,
          'label': entry.value,
        });
      }
      await prefs.setString('calendarAliasMigration040', migration);
    } catch (_) {
      // Retry next launch; the native queue survives missing calendar permission.
    }
  }
}

Future<void> setCourseAlias(String name, String alias) async {
  final value = alias.trim();
  if (value.length > 30) throw const FormatException('과목 약자는 30자 이내로 입력해 주세요.');
  final previous = courseLabel(name);
  final next = {...courseAliases};
  if (value.isEmpty || value == name) {
    next.remove(name);
  } else {
    next[name] = value;
  }
  final prefs = await SharedPreferences.getInstance();
  if (!await prefs.setString('courseAliases', jsonEncode(next))) {
    throw const FormatException('과목 약자를 저장하지 못했습니다.');
  }
  courseAliases = next;
  final store = await Store.open();
  try {
    final records = await store.db.query(
      'meta',
      where: 'id LIKE ?',
      whereArgs: ['aiCandidate:%'],
    );
    for (final row in records) {
      try {
        final record = jsonDecode(row['value'] as String) as Map;
        final n = CampusNotice.fromJson(
          Map<String, dynamic>.from(record['notice']),
        );
        if (n.course.replaceAll(RegExp(r'\s+'), '') !=
            name.replaceAll(RegExp(r'\s+'), '')) {
          continue;
        }
        final key = record['key'] as String;
        final raw = await store.meta('aiState:$key');
        if (raw == null) continue;
        final state = Map<String, dynamic>.from(jsonDecode(raw));
        if (state['title'] is String) {
          state['title'] = courseEventTitle(
            state['title'],
            n.course,
            oldLabel: state['courseLabel'] as String? ?? previous,
          );
        }
        state['courseName'] = n.course;
        state['courseLabel'] = courseLabel(n.course);
        await AiStateRepository(
          store,
        ).saveSchedule(key, ConfirmedSchedule.fromJson(state));
      } catch (_) {}
    }
    await store.setMeta('aiSummaryHash', '');
    await store.setMeta('aiSummaryFailHash', '');
    await store.setMeta(
      'aiSummaryRevision',
      '${DateTime.now().microsecondsSinceEpoch}',
    );
    await prefs.remove('aiSummaryText');
    await prefs.remove('aiSummaryLast');
  } finally {
    await store.db.close();
  }
  if (Platform.isAndroid || Platform.isIOS) {
    try {
      await bridge.invokeNative(NativeMethod.calendarRenameCourse, {
        'original': name,
        'previous': previous,
        'label': courseLabel(name),
      });
    } catch (_) {}
  }
}

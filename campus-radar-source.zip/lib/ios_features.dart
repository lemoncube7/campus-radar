import 'ios_timetable.dart';
import 'dart:convert';
import 'timetable_model.dart';
import 'timetable_exceptions.dart';
import 'native_contract.dart';
import 'app_storage.dart';
import 'native_bridge.dart';
import 'notification_gateway.dart';
import 'course_labels.dart';
import 'campus_models.dart';
import 'school_time.dart';
import 'dart:io';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/timezone.dart' as tz;

List<DateTime> iosDailyTimes(DateTime now, int hour, int minute) {
  var next = DateTime(now.year, now.month, now.day, hour, minute);
  if (!next.isAfter(now)) {
    next = DateTime(now.year, now.month, now.day + 1, hour, minute);
  }
  return List.generate(
    7,
    (i) => DateTime(next.year, next.month, next.day + i, hour, minute),
  );
}

String iosDailyBody(
  List<CampusItem> items,
  Set<String> excluded,
  Map<String, DateTime> discovered,
  DateTime at,
  String? last,
) {
  final rows = items
      .where((i) => i.availableAt(at) && !excluded.contains(i.key))
      .toList();
  final pending = rows.where((i) => i.status == 'pending').toList();
  final today = pending
      .where(
        (i) =>
            i.due != null &&
            i.due!.isAfter(at) &&
            schoolDay(i.due!) == schoolDay(at),
      )
      .length;
  final soon = pending
      .where((i) => deadlineState(i.due, now: at) == DeadlineState.withinDay)
      .length;
  final fresh = rows
      .where(
        (i) =>
            i.type == 'LR' &&
            discovered[i.key] != null &&
            schoolDay(discovered[i.key]!) == schoolDay(at),
      )
      .length;
  return '오늘 새 과제 $fresh개 · 전체 미완료 ${pending.length}개\n오늘 마감 $today개 · 24시간 이내 $soon개\n마지막 확인 ${last == null ? "수집 기록 없음" : koreanTime(DateTime.parse(last))}\n마지막 수집 기준 예약 알림입니다.';
}

Future<void> refreshIosFeatures(Store store, {bool test = false}) async {
  if (!Platform.isIOS) return;
  final items = await store.items(), excluded = await store.excluded();
  final last = await store.meta('lastSuccess');
  final now = DateTime.now().toUtc();
  final slots = decodeSlots(await store.meta('timetableEntries'));
  final cancelled = decodeCancellations(
    await store.meta('timetableCancellations'),
  );
  final classSettings =
      await bridge.invokeNativeMap<String, dynamic>(
        NativeMethod.timetableSettings,
      ) ??
      {};
  await refreshIosTimetable(
    slots,
    cancelled,
    classSettings,
    items,
    excluded,
    now,
  );
  final schoolNow = now.add(const Duration(hours: 9));
  final classes = <Map<String, dynamic>>[];
  for (var n = 0; n < 8; n++) {
    final day = DateTime.utc(
      schoolNow.year,
      schoolNow.month,
      schoolNow.day + n,
    );
    for (final slot in classesOnDate(slots, cancelled, day)) {
      final start = day
          .add(Duration(minutes: slot.start))
          .subtract(const Duration(hours: 9));
      final end = day
          .add(Duration(minutes: slot.end))
          .subtract(const Duration(hours: 9));
      classes.add({
        'course': courseLabel(slot.course),
        'room': slot.room,
        'start': start.millisecondsSinceEpoch / 1000,
        'end': end.millisecondsSinceEpoch / 1000,
      });
    }
  }
  await bridge.invokeMethod('publishWidgetSnapshot', {
    'snapshot': jsonEncode({
      'updated': now.millisecondsSinceEpoch / 1000,
      'connected': await store.meta('lastSuccess') != null,
      'tasks': items
          .where(
            (i) => !i.done && i.availableAt(now) && !excluded.contains(i.key),
          )
          .take(8)
          .map(
            (i) => {
              'key': i.key,
              'course': courseLabel(i.course),
              'title': i.title,
              'due': i.due == null
                  ? null
                  : i.due!.millisecondsSinceEpoch / 1000,
            },
          )
          .toList(),
      'classes': classes,
    }),
  });
  try {
    await bridge.invokeNative(NativeMethod.calendarSync, {
      'aliases': courseAliases,
      'items': items
          .where((i) => i.availableAt(now) && !excluded.contains(i.key))
          .map((i) => i.toJson())
          .toList(),
    });
    final logs =
        await bridge.invokeNativeList<dynamic>(NativeMethod.drainNativeLogs) ??
        [];
    for (final row in logs) {
      await store.log(
        'calendar',
        row['title'] as String,
        row['detail'] as String,
      );
    }
  } catch (_) {
    await store.log('calendar', '캘린더 동기화 대기', '설정에서 권한과 저장할 캘린더를 확인해 주세요.');
  }
  final settings =
      await bridge.invokeNativeMap<String, dynamic>(
        NativeMethod.dailySettings,
      ) ??
      {};
  if (!test && settings['enabled'] != true) {
    for (var i = 0; i < 7; i++) {
      await notifications.cancel(notificationId('ios-daily-$i'));
    }
    return;
  }
  final discovered = <String, DateTime>{};
  for (final i in items) {
    final d = DateTime.tryParse(await store.meta('discovered:${i.key}') ?? '');
    if (d != null) discovered[i.key] = d;
  }
  final p = await SharedPreferences.getInstance();
  await p.reload();
  final times = test
      ? [DateTime.now().add(const Duration(seconds: 2))]
      : iosDailyTimes(
          DateTime.now(),
          settings['hour'] as int? ?? 18,
          settings['minute'] as int? ?? 0,
        );
  final stamp =
      '${settings['enabled']}:${settings['hour']}:${settings['minute']}:$last:${excluded.join(",")}:${p.getString('aiSummaryText')}';
  for (var n = 0; n < times.length; n++) {
    final at = times[n];
    var body = iosDailyBody(items, excluded, discovered, at, last);
    if (p.getBool('aiSummaryEnabled') == true &&
        p.getString('aiSummaryLast') == last &&
        p.getString('aiSummaryDay') == schoolDay(at) &&
        (p.getInt('aiSummaryExpires') ?? 0) > at.millisecondsSinceEpoch) {
      final text = p.getString('aiSummaryText');
      if (text?.isNotEmpty == true) body += '\nAI 우선 확인\n$text';
    }
    await notifications.zonedSchedule(
      notificationId(test ? 'ios-daily-test' : 'ios-daily-$n'),
      '오늘의 캠퍼스레이더',
      body,
      tz.TZDateTime.from(at, tz.local),
      noticeStyle,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      payload: '_summary',
    );
  }
  if (test || await store.meta('iosDailyStamp') != stamp) {
    await store.log(
      'notification',
      test ? '데일리 요약 테스트 예약' : '데일리 요약 예약 갱신',
      '현재 수집 기록 기준 ${times.length}회 · 새로운 수집 후 예약을 갱신합니다.',
    );
    await store.setMeta('iosDailyStamp', stamp);
  }
}

Future<void> updateIosFeatures({bool test = false}) async {
  if (!Platform.isIOS) return;
  final s = await Store.open();
  try {
    await refreshIosFeatures(s, test: test);
  } finally {
    await s.db.close();
  }
}

Future<void> testIosMidnight() async {
  final s = await Store.open();
  try {
    final now = DateTime.now().toUtc().add(const Duration(hours: 9));
    final classes = classesOnDate(
      decodeSlots(await s.meta('timetableEntries')),
      decodeCancellations(await s.meta('timetableCancellations')),
      now,
    );
    final body = iosDailyBody(
      await s.items(),
      await s.excluded(),
      {},
      DateTime.now().toUtc(),
      await s.meta('lastSuccess'),
    );
    await notifications.show(
      notificationId('ios-midnight-test'),
      '오늘의 수업·마감 테스트',
      '수업 ${classes.length}개\n$body',
      noticeStyle,
      payload: '_summary',
    );
    await s.log('notification', '자정 요약 테스트 요청', '실제 알림 도착은 기기에서 확인해 주세요.');
  } finally {
    await s.db.close();
  }
}

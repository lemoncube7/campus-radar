import 'package:flutter/material.dart';
import 'home_navigation.dart';
import 'ai_inbox_page.dart';
import 'timetable_page.dart';
import 'schedule_calendar.dart';

Future<void> openWorkspaceTool(BuildContext context, ScheduleView view) async {
  final Widget page = switch (view) {
    ScheduleView.review => const AiInboxPage(showTools: false, compactReview: true),
    ScheduleView.timetable => const TimetablePage(),
    ScheduleView.calendar => Scaffold(
      appBar: AppBar(title: const Text('캘린더')),
      body: const ScheduleCalendar(),
    ),
    ScheduleView.tasks => throw ArgumentError('할 일은 기본 화면에서 엽니다.'),
  };
  await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
}

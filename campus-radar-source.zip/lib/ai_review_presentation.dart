import 'ai_protocol.dart';

enum AiReviewKind {
  cancellation,
  change,
  audience,
  missingDate,
  uncertain,
  ready,
}

AiReviewKind reviewKind(ScheduleCandidate c, {Map? state}) {
  if (c.action == 'cancel') return AiReviewKind.cancellation;
  if (c.action == 'change') return AiReviewKind.change;
  if (c.date.isEmpty) return AiReviewKind.missingDate;
  if ((c.condition == 'conditional' || c.condition == 'optional') &&
      state?['audienceConfirmed'] != true) {
    return AiReviewKind.audience;
  }
  if (c.uncertainty.isNotEmpty || c.timetableProof.isNotEmpty) {
    return AiReviewKind.uncertain;
  }
  return AiReviewKind.ready;
}

String reviewLabel(AiReviewKind kind) => switch (kind) {
  AiReviewKind.cancellation => '휴강·취소',
  AiReviewKind.change => '변경 확인',
  AiReviewKind.audience => '내 해당 여부',
  AiReviewKind.missingDate => '날짜 입력',
  AiReviewKind.uncertain => '추정 확인',
  AiReviewKind.ready => '바로 추가',
};

String reviewInstruction(ScheduleCandidate c, {Map? state}) =>
    state?['audienceConfirmed'] == true
    ? '본인에게 해당하는 항목으로 확인했어요. 날짜와 시간을 확인한 뒤 추가하세요.'
    : switch (reviewKind(c, state: state)) {
        AiReviewKind.cancellation =>
          c.category == 'class'
              ? '아래에서 실제로 빠지는 날짜와 수업을 확인하고 휴강을 반영하세요.'
              : '취소된 대상이 어떤 일정인지 원문과 함께 확인해 주세요.',
        AiReviewKind.change => '기존 일정과 바뀐 날짜·시간을 비교해 주세요.',
        AiReviewKind.audience =>
          c.condition == 'optional'
              ? '선택 사항이에요. 본인에게 필요한 경우에만 추가하세요.'
              : '본인의 발표·제출 대상인지 확인한 뒤 추가하세요.',
        AiReviewKind.missingDate => '날짜를 정하지 못했어요. 추가할 날짜를 입력해 주세요.',
        AiReviewKind.uncertain =>
          c.timetableProof.isNotEmpty
              ? '저장된 시간표로 추정한 일정이에요. 날짜와 시간을 확인해 주세요.'
              : '확실하지 않은 부분이 있어요. 근거를 펼쳐 확인해 주세요.',
        AiReviewKind.ready => '날짜와 시간을 확인하면 바로 추가할 수 있어요.',
      };

import 'dart:convert';
import 'app_storage.dart';
import 'campus_models.dart';
import 'ai_protocol.dart';
import 'ai_state_repository.dart';

/// Read-only join of durable candidates, current notice caches and queue records.
/// Stale confirmed records remain visible; stale unreviewed records are omitted.
class AiInboxSnapshot {
  final List<Map<String, dynamic>> candidates, jobs;
  final bool enabled;
  final String recentQuestion;
  final String? blockedCode;
  const AiInboxSnapshot(
    this.candidates,
    this.jobs,
    this.enabled,
    this.recentQuestion,
    this.blockedCode,
  );
}

class AiInboxRepository {
  final Store s;
  const AiInboxRepository(this.s);
  Future<AiInboxSnapshot> read() async {
    final notices = await s.notices();
    final list = <Map<String, dynamic>>[], queue = <Map<String, dynamic>>[];
    final records = await s.db.query(
      'meta',
      where: 'id LIKE ?',
      whereArgs: ['aiCandidate:%'],
    );
    final seen = <String>{};
    for (final r in records) {
      final record = Map<String, dynamic>.from(
        jsonDecode(r['value'] as String),
      );
      final n = CampusNotice.fromJson(
        Map<String, dynamic>.from(record['notice']),
      );
      final c = ScheduleCandidate.parse(
        Map<String, dynamic>.from(record['candidate']),
        '${n.title}\n${n.body}',
      );
      final k = record['key'] as String,
          st = (await AiStateRepository(s).schedule(k)).toJson();
      final current = notices.where((x) => x.id == n.id).firstOrNull;
      final stale =
          current == null || noticeFingerprint(current) != noticeFingerprint(n);
      if (stale && st['status'] != 'confirmed') continue;
      seen.add(k);
      list.add({'notice': n, 'candidate': c, 'key': k, 'state': st});
    }
    for (final n in notices) {
      final raw = await s.meta('aiCache:${n.id}:${noticeFingerprint(n)}');
      if (raw != null) {
        for (final e in jsonDecode(raw) as List) {
          final c = ScheduleCandidate.parse(
            Map<String, dynamic>.from(e),
            '${n.title}\n${n.body}',
          );
          final k = candidateKey(n, c);
          final state = (await AiStateRepository(s).schedule(k)).toJson();
          if (seen.add(k)) {
            list.add({'notice': n, 'candidate': c, 'key': k, 'state': state});
          }
        }
      }
      final q = await s.meta('aiQueue:${n.id}');
      if (q != null) {
        queue.add({'id': n.id, ...Map<String, dynamic>.from(jsonDecode(q))});
      }
    }
    final enabled = await s.meta('aiAuto') == 'yes';
    final chat = jsonDecode(await s.meta('aiChat:all') ?? '[]') as List;
    final lastQuestion = chat.where((m) => m['role'] == 'user').lastOrNull;
    final blocked = queue
        .where(
          (j) => j['status'] == 'failed' && j['errorCode'] == 'credentials',
        )
        .firstOrNull;
    for (final row in list) {
      final raw = await s.meta('aiApproval:${row['key']}');
      if (raw == null) continue;
      final review = jsonDecode(raw) as Map;
      final n = row['notice'] as CampusNotice;
      if (review['fingerprint'] == noticeFingerprint(n)) {
        row['approvalReview'] = review;
      }
    }
    return AiInboxSnapshot(
      list,
      queue,
      enabled,
      lastQuestion?['text'] as String? ?? '',
      blocked?['errorCode'] as String?,
    );
  }
}

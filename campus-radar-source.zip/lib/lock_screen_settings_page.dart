import 'timetable_page.dart';
import 'native_contract.dart';
import 'native_bridge.dart';
import 'dart:async';
import 'package:flutter/material.dart';

class LockScreenSettingsPage extends StatefulWidget {
  const LockScreenSettingsPage({super.key});
  @override
  State<LockScreenSettingsPage> createState() => _LockScreenSettingsPageState();
}

class _LockScreenSettingsPageState extends State<LockScreenSettingsPage>
    with WidgetsBindingObserver {
  bool enabled = false, allowed = false, details = false, busy = true;
  bool dismissOutside = false,
      dismissSwipe = true,
      hideOtherWindows = false,
      preferTop = true;
  String mode = 'compact', position = 'right';
  double cardWidth = 270,
      cardHeight = 380,
      cardX = 100,
      cardY = 50,
      opacity = 80;
  String? error;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    unawaited(load());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) unawaited(load());
  }

  Future<void> load() async {
    try {
      final s =
          await bridge.invokeNativeMap<String, dynamic>(
            NativeMethod.lockSettings,
          ) ??
          {};
      if (mounted) {
        setState(() {
          enabled = s['enabled'] == true;
          allowed = s['allowed'] == true;
          details = s['details'] == true;
          dismissOutside = s['dismissOutside'] == true;
          dismissSwipe = s['dismissSwipe'] != false;
          hideOtherWindows = s['hideOtherWindows'] == true;
          preferTop = s['preferTop'] != false;
          mode = s['mode'] ?? 'compact';
          position = s['position'] ?? 'right';
          cardWidth = (s['width'] as num?)?.toDouble() ?? 270;
          cardHeight = (s['height'] as num?)?.toDouble() ?? 380;
          cardX =
              (s['x'] as num?)?.toDouble() ?? (position == 'left' ? 0 : 100);
          cardY = (s['y'] as num?)?.toDouble() ?? 50;
          opacity = (s['opacity'] as num?)?.toDouble() ?? 80;
          busy = false;
          error = null;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          busy = false;
          error = '기기 설정을 읽지 못했습니다.';
        });
      }
    }
  }

  Future<void> save(bool value) async {
    setState(() => busy = true);
    try {
      await bridge.invokeNative(NativeMethod.lockConfigure, {
        'enabled': value,
        'mode': mode,
        'details': details,
        'position': position,
        'width': cardWidth.round(),
        'height': cardHeight.round(),
        'x': cardX.round(),
        'y': cardY.round(),
        'opacity': opacity.round(),
        'dismissOutside': dismissOutside,
        'dismissSwipe': dismissSwipe,
        'hideOtherWindows': hideOtherWindows,
        'preferTop': preferTop,
      });
      await load();
    } catch (_) {
      if (mounted) {
        setState(() {
          error = '접근성 설정에서 캠퍼스레이더 잠금화면을 켠 후 다시 시도해 주세요.';
          busy = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('잠금화면 정보')),
    body: Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
          child: Column(
            children: [
              const Text('실시간 카드 미리보기 · 예시 정보'),
              const SizedBox(height: 6),
              SizedBox(
                height: (MediaQuery.sizeOf(context).height * .25).clamp(
                  130,
                  220,
                ),
                child: LockCardPreview(
                  width: cardWidth,
                  height: cardHeight,
                  x: cardX,
                  y: cardY,
                  opacity: opacity,
                  full: mode == 'full',
                  details: details,
                ),
              ),
            ],
          ),
        ),
        const Divider(height: 1),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              ListTile(
                title: const Text('수업 카운트다운 설정'),
                subtitle: const Text('수업 시작 후 -분 표시 유지 시간'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const TimetablePage(initialMode: 2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                '휴대전화를 잠그고 화면을 켜면 마지막 수집한 과제 정보를 표시합니다. 잠금 해제를 대신하지 않으며, 화면을 켜거나 다른 앱 사용 중에 강제로 띄우지 않습니다.',
              ),
              const SizedBox(height: 16),
              SwitchListTile(
                title: const Text('잠금화면 카드 사용'),
                subtitle: const Text('접근성 서비스가 켜져 있어야 합니다. 기본값은 꺼짐입니다.'),
                value: enabled,
                onChanged: busy ? null : save,
              ),
              if (!allowed)
                FilledButton(
                  onPressed: () =>
                      bridge.invokeNative(NativeMethod.lockPermission),
                  child: const Text('접근성 서비스 설정 열기'),
                ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                key: ValueKey('mode:$mode'),
                initialValue: mode,
                decoration: const InputDecoration(labelText: '표시 방식'),
                items: const [
                  DropdownMenuItem(value: 'compact', child: Text('작은 카드')),
                  DropdownMenuItem(value: 'full', child: Text('전체 카드')),
                ],
                onChanged: busy
                    ? null
                    : (v) async {
                        setState(() => mode = v!);
                        await save(enabled);
                      },
              ),
              const SizedBox(height: 16),
              SwitchListTile(
                title: const Text('과목명·과제명 표시'),
                subtitle: const Text(
                  '끄면 개수만 표시합니다. 켜면 잠금 상태에서도 주변 사람이 내용을 볼 수 있습니다.',
                ),
                value: details,
                onChanged: busy
                    ? null
                    : (v) async {
                        setState(() => details = v);
                        await save(enabled);
                      },
              ),
              const Divider(height: 28),
              const Text('표시 우선순위·숨김 조건'),
              SwitchListTile(
                title: const Text('가능한 범위에서 위에 표시'),
                subtitle: const Text(
                  '접근성 오버레이를 사용하고 바깥 터치 후 표시 순서를 다시 요청합니다. 다른 접근성 서비스보다 항상 위에 표시되는 것은 Android가 보장하지 않습니다.',
                ),
                value: preferTop,
                onChanged: busy
                    ? null
                    : (v) async {
                        setState(() => preferTop = v);
                        await save(enabled);
                      },
              ),
              SwitchListTile(
                title: const Text('카드 바깥 터치 시 숨기기'),
                subtitle: const Text('다른 잠금화면 위젯을 조작해도 카드를 유지하려면 꺼 두세요.'),
                value: dismissOutside,
                onChanged: busy
                    ? null
                    : (v) async {
                        setState(() => dismissOutside = v);
                        await save(enabled);
                      },
              ),
              SwitchListTile(
                title: const Text('카드 스와이프 시 숨기기'),
                value: dismissSwipe,
                onChanged: busy
                    ? null
                    : (v) async {
                        setState(() => dismissSwipe = v);
                        await save(enabled);
                      },
              ),
              SwitchListTile(
                title: const Text('다른 앱 창이 나타나면 숨기기'),
                subtitle: const Text('다른 오버레이 위젯에서 창을 열 때도 숨겨질 수 있어요.'),
                value: hideOtherWindows,
                onChanged: busy
                    ? null
                    : (v) async {
                        setState(() => hideOtherWindows = v);
                        await save(enabled);
                      },
              ),
              const Text('잠금 해제·화면 끄기·카메라·확인된 잠금 인증 화면에서는 항상 숨깁니다.'),
              const Divider(height: 28),
              if (mode == 'compact') ...[
                _adjuster(
                  '배경 불투명도',
                  opacity,
                  0,
                  100,
                  '${opacity.round()}% · 글자는 선명하게 유지',
                  (v) => opacity = v,
                ),
                const Text('작은 카드 크기와 위치'),
                const Text('화면 가장자리 안에서 배치됩니다. 내용이 길면 카드 안을 스크롤할 수 있습니다.'),
                _adjuster(
                  '카드 폭',
                  cardWidth,
                  180,
                  360,
                  '${cardWidth.round()}',
                  (v) => cardWidth = v,
                ),
                _adjuster(
                  '카드 높이',
                  cardHeight,
                  180,
                  640,
                  '${cardHeight.round()}',
                  (v) => cardHeight = v,
                ),
                _adjuster(
                  '가로 위치',
                  cardX,
                  0,
                  100,
                  '${cardX.round()}% · 왼쪽 → 오른쪽',
                  (v) => cardX = v,
                ),
                _adjuster(
                  '세로 위치',
                  cardY,
                  0,
                  100,
                  '${cardY.round()}% · 위 → 아래',
                  (v) => cardY = v,
                ),
              ] else
                const Text('전체 카드는 어느 방향으로든 스와이프하면 닫힙니다. 원래 잠금화면에서 잠금을 해제하세요.'),
              if (error != null) Text(error!),
              const SizedBox(height: 16),
              const Text(
                '접근성에서 ‘캠퍼스레이더 잠금화면’을 직접 켜 주세요. 화면 내용 읽기·입력 조작은 요청하지 않습니다. 위 설정에 따라 바깥 터치나 카드 스와이프로 숨길 수 있습니다. 세로 스크롤로 카드 내용을 볼 수 있습니다.',
              ),
            ],
          ),
        ),
      ],
    ),
  );

  Widget _adjuster(
    String label,
    double value,
    double min,
    double max,
    String description,
    void Function(double) update,
  ) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const SizedBox(height: 16),
      Text('$label · $description'),
      Slider(
        semanticFormatterCallback: (v) => '$label ${v.round()}',
        value: value.clamp(min, max),
        min: min,
        max: max,
        divisions: ((max - min) / 10).round(),
        onChanged: busy ? null : (v) => setState(() => update(v)),
        onChangeEnd: busy ? null : (_) => save(enabled),
      ),
    ],
  );
}

class LockCardPreview extends StatelessWidget {
  final double width, height, x, y, opacity;
  final bool full, details;
  const LockCardPreview({
    super.key,
    required this.width,
    required this.height,
    required this.x,
    required this.y,
    required this.opacity,
    required this.full,
    required this.details,
  });
  @override
  Widget build(BuildContext context) => Center(
    child: AspectRatio(
      aspectRatio:
          MediaQuery.sizeOf(context).width / MediaQuery.sizeOf(context).height,
      child: LayoutBuilder(
        builder: (context, box) {
          final screen = MediaQuery.sizeOf(context);
          final scale = box.maxWidth / screen.width;
          final cw = full
              ? screen.width
              : width.clamp(180, 360).clamp(0, screen.width - 24).toDouble();
          final ch = full
              ? screen.height
              : height.clamp(180, 640).clamp(0, screen.height - 96).toDouble();
          final w = cw * scale, h = ch * scale;
          return ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Stack(
              children: [
                const Positioned.fill(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Color(0xff415668), Color(0xff192331)],
                      ),
                    ),
                  ),
                ),
                const Positioned(
                  top: 8,
                  left: 6,
                  right: 6,
                  child: Text(
                    '12:30',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white, fontSize: 14),
                  ),
                ),
                Positioned(
                  key: const ValueKey('lock-preview-card'),
                  left: full
                      ? 0
                      : 12 * scale +
                            (box.maxWidth - w - 24 * scale).clamp(
                                  0,
                                  box.maxWidth,
                                ) *
                                x /
                                100,
                  top: full
                      ? 0
                      : (box.maxHeight - h - 24 * scale).clamp(
                              0,
                              box.maxHeight,
                            ) *
                            y /
                            100,
                  width: w,
                  height: h,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      color: const Color(
                        0xff142225,
                      ).withValues(alpha: full ? 1 : opacity / 100),
                      borderRadius: BorderRadius.circular(
                        full ? 0 : 16 * scale,
                      ),
                    ),
                    child: FittedBox(
                      fit: BoxFit.contain,
                      alignment: Alignment.topLeft,
                      child: SizedBox(
                        width: cw,
                        height: ch,
                        child: Padding(
                          padding: const EdgeInsets.all(18),
                          child: DefaultTextStyle(
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                if (full)
                                  const Text(
                                    '캠퍼스레이더',
                                    style: TextStyle(fontSize: 24),
                                  ),
                                const Text('24시간 이내 2개 · 미완료 4개'),
                                if (details) ...[
                                  const SizedBox(height: 12),
                                  const Text('컴프2 · 실습 과제'),
                                  const Text('오늘 23:59 · 4시간 남음'),
                                ],
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    ),
  );
}

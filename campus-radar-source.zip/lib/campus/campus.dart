import 'package:campus_radar/tasks/task_evaluation.dart';
import 'package:campus_radar/campus/learning_resources.dart';
import 'package:campus_radar/tasks/task_response.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/campus_media.dart';
import 'package:campus_radar/campus/freeboard_models.dart';
import 'package:campus_radar/campus/site_canary.dart';
import 'package:campus_radar/core/network_resilience.dart';
import 'package:campus_radar/core/sync_timing.dart';
import 'package:crypto/crypto.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:cookie_jar/cookie_jar.dart';
import 'package:encrypt/encrypt.dart' as enc;
import 'package:html/parser.dart' as html;

class CampusException implements Exception {
  final String message;
  CampusException(this.message);
  @override
  String toString() => message;
}

class CampusHttpException extends CampusException implements HttpStatusError {
  @override
  final int status;
  CampusHttpException(this.status, String route)
    : super('서버 응답 오류 ($status, $route)');
}

class CampusLoginRejected extends CampusException {
  CampusLoginRejected(super.message);
}

class CampusAuthenticationLost extends CampusException {
  CampusAuthenticationLost()
    : super('학교 연결이 끊겼어요. 다른 기기 접속 또는 세션 만료일 수 있어요. 재연결 설정을 확인해 주세요.');
}

class CampusClient {
  final void Function(String)? diagnostic;
  SyncTiming? apiTiming;

  /// Skip repeated course-session switches for consecutive reports of the
  /// same course. The CLI turns it off to compare against the old behaviour.
  bool reuseCourseSession = true;
  CampusClient({this.diagnostic}) {
    ActiveRequests.add(http);
  }
  bool _closed = false;
  void _abortRequest() {
    final previous = http;
    ActiveRequests.remove(previous);
    previous.close(force: true);
    if (!_closed) {
      http = HttpClient()..connectionTimeout = const Duration(seconds: 20);
      ActiveRequests.add(http);
    }
  }

  static const learning = 'https://dcs-learning.cnu.ac.kr';
  static const loginHost = 'https://dcs-lcms.cnu.ac.kr';
  HttpClient http = HttpClient()
    ..connectionTimeout = const Duration(seconds: 20);
  final CookieJar jar = CookieJar();
  String transportKey = '';
  List<Map<String, dynamic>> courseList = [];
  final resourceWarnings = <String>{};
  final Map<String, String> taskWarnings = {};
  final formatIssues = <SiteFormatIssue>[];
  void Function(SiteFormatIssue issue)? onFormatMismatch;

  SiteFormatIssue? checkFormat(String route, dynamic body) {
    final issue = checkSiteResponseShape(route, body);
    if (issue != null) {
      if (!formatIssues.any(
        (i) => i.route == issue.route && i.reason == issue.reason,
      )) {
        formatIssues.add(issue);
        onFormatMismatch?.call(issue);
        diagnostic?.call('Format mismatch: $issue');
      }
    }
    return issue;
  }

  Future<void> Function()? authenticationLost;
  Future<void> Function()? sessionUpdated;
  Future<String?> Function()? trafficStarted;
  Future<void> Function(String? token, bool failed)? trafficFinished;

  /// Includes cookie creation timestamps: restoring must not extend Max-Age.
  Map<String, dynamic> exportSession() {
    final cookies = jar as DefaultCookieJar;
    Map<String, dynamic> encode(
      Map<String, Map<String, Map<String, SerializableCookie>>> source,
    ) => source.map(
      (host, paths) => MapEntry(
        host,
        paths.map(
          (path, values) => MapEntry(
            path,
            values.map((name, value) => MapEntry(name, value.toJson())),
          ),
        ),
      ),
    );
    return {
      'version': 1,
      'key': transportKey,
      'hostCookies': encode(cookies.hostCookies),
      'domainCookies': encode(cookies.domainCookies),
    };
  }

  /// Drops all school cookies so the next login starts clean.
  void clearSession() {
    final cookies = jar as DefaultCookieJar;
    cookies.hostCookies.clear();
    cookies.domainCookies.clear();
  }

  void restoreSession(Map<String, dynamic> snapshot) {
    if (snapshot['version'] != 1 ||
        snapshot['key'] is! String ||
        (snapshot['key'] as String).length != 32) {
      throw const FormatException('학교 연결 저장 형식 오류');
    }
    Map<String, Map<String, Map<String, SerializableCookie>>> decode(
      dynamic raw,
    ) {
      final result = <String, Map<String, Map<String, SerializableCookie>>>{};
      for (final entry in (raw as Map).entries) {
        final host = entry.key as String;
        if (!{
          'dcs-learning.cnu.ac.kr',
          'dcs-lcms.cnu.ac.kr',
          'cnu.ac.kr',
        }.contains(host.replaceFirst(RegExp(r'^\.'), ''))) {
          throw const FormatException('학교 연결 주소 오류');
        }
        result[host] = (entry.value as Map).map(
          (path, values) => MapEntry(
            path as String,
            (values as Map).map(
              (name, value) => MapEntry(
                name as String,
                SerializableCookie.fromJson(value as String),
              ),
            ),
          ),
        );
      }
      return result;
    }

    final hosts = decode(snapshot['hostCookies']);
    final domains = decode(snapshot['domainCookies']);
    final cookies = jar as DefaultCookieJar;
    cookies.hostCookies
      ..clear()
      ..addAll(hosts);
    cookies.domainCookies
      ..clear()
      ..addAll(domains);
    transportKey = snapshot['key'] as String;
  }

  Future<String> request(
    Uri url, {
    Map<String, String>? form,
    int redirects = 0,
  }) async {
    if (_closed) throw CampusException('연결이 종료되었어요. 다시 시도해 주세요.');
    final token = await trafficStarted?.call();
    var failed = true;
    try {
      final result = await requestDeadline(
        () => _request(url, form: form, redirects: redirects),
        _abortRequest,
        limit: const Duration(seconds: 50),
      );
      failed = false;
      return result;
    } finally {
      await trafficFinished?.call(token, failed);
    }
  }

  Future<String> _request(
    Uri url, {
    Map<String, String>? form,
    int redirects = 0,
    HttpClient? transport,
  }) async {
    transport ??= http;
    if (url.scheme != 'https' ||
        !{'dcs-learning.cnu.ac.kr', 'dcs-lcms.cnu.ac.kr'}.contains(url.host)) {
      throw CampusException('예상하지 못한 로그인 이동 주소예요.');
    }
    if (redirects > 10) throw CampusException('로그인 이동이 반복돼요.');
    final req = await transport
        .openUrl(form == null ? 'GET' : 'POST', url)
        .timeout(const Duration(seconds: 20));
    req.followRedirects = false;
    req.headers.set(
      HttpHeaders.userAgentHeader,
      'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/130.0.0.0 Mobile Safari/537.36',
    );
    req.cookies.addAll(await jar.loadForRequest(url));
    if (form != null) {
      req.headers.set(
        HttpHeaders.contentTypeHeader,
        'application/x-www-form-urlencoded; charset=UTF-8',
      );
      req.headers.set('Origin', '${url.scheme}://${url.host}');
      req.headers.set('Referer', '${url.scheme}://${url.host}/home');
      req.headers.set('X-Requested-With', 'XMLHttpRequest');
      final bytes = utf8.encode(
        form.entries
            .map(
              (e) =>
                  '${Uri.encodeQueryComponent(e.key)}=${Uri.encodeQueryComponent(e.value)}',
            )
            .join('&'),
      );
      req.contentLength = bytes.length;
      req.add(bytes);
    }
    final response = await req.close().timeout(const Duration(seconds: 30));
    await jar.saveFromResponse(url, response.cookies);
    if (response.cookies.isNotEmpty) await sessionUpdated?.call();
    final location = response.headers.value(HttpHeaders.locationHeader);
    if (response.isRedirect && location != null) {
      await response.listen((_) {}).cancel();
      return _request(
        url.resolve(location),
        form: response.statusCode == 307 || response.statusCode == 308
            ? form
            : null,
        redirects: redirects + 1,
        transport: transport,
      );
    }
    if (response.statusCode != 200) {
      await response.listen((_) {}).cancel();
      throw CampusHttpException(response.statusCode, url.path);
    }
    final bytes = <int>[];
    await for (final chunk in response.timeout(const Duration(seconds: 30))) {
      bytes.addAll(chunk);
      if (bytes.length > 8 * 1024 * 1024) {
        throw CampusException('서버 응답이 너무 커서 처리를 중단했어요. 기존 목록은 유지해요.');
      }
    }
    return utf8.decode(bytes);
  }

  Future<dynamic> api(
    String route,
    Map<String, dynamic>? payload, {
    String host = learning,
  }) async {
    const safeReads = {
      '/term/getYearTermList',
      '/course/getStdMyCourseList',
      '/course/addSessionCourseInfo',
      '/week/getStdWeekList',
      '/week/getStdEtcList',
      '/archive/list',
      '/archive/detail',
      '/task/detail',
      '/task/stdDetail',
      '/board/std/notice/list',
      '/board/notice/info',
      '/board/bbs/list',
      '/board/bbs/list/top',
      '/board/bbs/info',
      '/coursePlan/getInfo',
    };
    Future<dynamic> call() {
      if (!safeReads.contains(route)) {
        return _apiOnce(route, payload, host: host);
      }
      return retryNetworkRead(
        () => _apiOnce(route, payload, host: host),
        onRetry: () => diagnostic?.call('Retry ${Uri.parse(route).path}'),
      );
    }

    return apiTiming?.measure(Uri.parse(route).path, call) ?? call();
  }

  Future<dynamic> _apiOnce(
    String route,
    Map<String, dynamic>? payload, {
    required String host,
  }) async {
    diagnostic?.call('API ${Uri.parse(route).path}');
    final cipher = enc.Encrypter(
      enc.AES(enc.Key.fromUtf8(transportKey), mode: enc.AESMode.cbc),
    );
    final form = payload == null
        ? <String, String>{}
        : {
            'e': cipher
                .encrypt(jsonEncode(payload), iv: enc.IV.allZerosOfLength(16))
                .base64,
          };
    String raw;
    try {
      raw = await request(Uri.parse('$host/api/v1$route'), form: form);
    } on CampusHttpException catch (e) {
      if (e.status != 401) rethrow;
      await authenticationLost?.call();
      throw CampusAuthenticationLost();
    }
    if (RegExp(
      r'''name\s*=\s*["']loginForm["']''',
      caseSensitive: false,
    ).hasMatch(raw)) {
      await authenticationLost?.call();
      throw CampusAuthenticationLost();
    }
    Map<String, dynamic> result;
    try {
      result = jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      throw CampusException('로그인 만료 또는 데이터 형식 변경으로 수집하지 못했어요.');
    }
    if (result['header']?['code'] == 401) {
      await authenticationLost?.call();
      throw CampusAuthenticationLost();
    }
    if (result['header']?['code'] != 200) {
      throw CampusException('사이버캠퍼스 요청이 거절됐어요. 계정 또는 사이트 상태를 확인해 주세요.');
    }
    final body = result['body'];
    checkFormat(route, body);
    return body;
  }

  Future<void> login(String id, String password) async {
    final homeRaw = await request(Uri.parse('$learning/home'));
    final htmlIssue = checkLoginHtmlStructure(homeRaw);
    if (htmlIssue != null) {
      if (!formatIssues.any(
        (i) => i.route == htmlIssue.route && i.reason == htmlIssue.reason,
      )) {
        formatIssues.add(htmlIssue);
        onFormatMismatch?.call(htmlIssue);
        diagnostic?.call('Format mismatch: $htmlIssue');
      }
    }
    final page = html.parse(homeRaw);
    final aesPath = page
        .querySelectorAll('script[src]')
        .map((e) => e.attributes['src']!)
        .where((s) => s.contains('gibberish-aes'))
        .firstOrNull;
    if (aesPath == null) throw CampusException('로그인 페이지 구조가 변경됐어요.');
    final js = await request(Uri.parse(loginHost).resolve(aesPath));
    transportKey =
        RegExp(
          r"function getSecKey\(\)\s*\{\s*return '([^']+)'",
        ).firstMatch(js)?.group(1) ??
        '';
    if (transportKey.length != 32) {
      throw CampusException('로그인 통신 형식을 확인하지 못했어요.');
    }
    final payload = <String, dynamic>{
      'redirect_url': '$learning/home',
      'key': page.querySelector('input[name=key]')?.attributes['value'] ?? '',
      'univ_no': 'CNU',
      'org_password': '',
      'user_id': id,
      'user_password': password,
      'cnu_auth': 'Y',
      'user_ip':
          page.querySelector('input[name=user_ip]')?.attributes['value'] ?? '',
    };
    final data = await api(
      '/user/apiCnuAuthLogin?redirectUrl=${Uri.encodeComponent('$learning/home')}',
      payload,
      host: loginHost,
    );
    if (data is! Map || data['redirect_url'] == null) {
      throw CampusLoginRejected(
        '로그인이 승인되지 않았어요. 아이디·비밀번호를 확인하고, 추가 인증이 필요한 경우 사이버캠퍼스에서 확인해 주세요.',
      );
    }
    final home = await request(Uri.parse(data['redirect_url']));
    if (home.contains('name="loginForm"')) {
      throw CampusLoginRejected(
        '로그인에 실패했어요. 아이디·비밀번호 또는 학교의 추가 인증 여부를 확인해 주세요.',
      );
    }
  }

  Future<List<Map<String, dynamic>>> fetchCourses() async {
    final terms = await api('/term/getYearTermList', null);
    checkFormat('/term/getYearTermList', terms);
    if (terms is! Map || terms['list'] is! List) {
      throw CampusException('학기 목록 응답 형식이 변경됐어요.');
    }
    final term = (terms['list'] as List)
        .cast<Map>()
        .where((m) => m['current_term_yn'] == 'Y')
        .firstOrNull;
    if (term == null) throw CampusException('현재 학기를 찾지 못했어요.');
    final base = <String, dynamic>{
      'term_year': term['term_year'],
      'term_cd': term['term_cd'],
    };
    final courses = await api('/course/getStdMyCourseList', {
      ...base,
      'is_current': 'Y',
    });
    checkFormat('/course/getStdMyCourseList', courses);
    if (courses is! Map || courses['course_list'] is! List) {
      throw CampusException('수강 과목 응답 형식이 변경됐어요. 기존 목록은 유지해요.');
    }
    courseList = (courses['course_list'] as List)
        .map(
          (c) => <String, dynamic>{
            ...base,
            'course_id': c['course_id'],
            'class_no': c['class_no'],
            'course_nm': textOf(c['course_nm']),
          },
        )
        .toList();
    diagnostic?.call(
      'Course count: ${(courses['course_list'] as List).length}',
    );
    return courseList;
  }

  Future<List<Map<String, dynamic>>> fetchArchiveRows(
    Map<String, dynamic> course,
  ) async {
    final rows = <String, Map<String, dynamic>>{};
    for (var offset = 0; offset < 2000; offset += 100) {
      final response = await api('/archive/list', {
        ...course,
        'limit': 100,
        'offset': offset,
      });
      checkFormat('/archive/list', response);
      if (response is! Map || response['list'] is! List) {
        throw CampusException('자료실 목록 형식이 변경됐어요.');
      }
      final page = response['list'] as List;
      for (final raw in page) {
        if (raw is! Map || raw['boarditem_no'] == null) {
          throw CampusException('자료실 항목 식별자를 확인하지 못했어요.');
        }
        rows['${raw['boarditem_no']}'] = Map<String, dynamic>.from(raw);
      }
      final total = int.tryParse('${response['tot_cnt']}');
      if (total != null && rows.length >= total) return rows.values.toList();
      if (page.isEmpty || page.length < 100) {
        if (total != null && rows.length < total) {
          throw CampusException('자료실 목록 일부를 받지 못했어요.');
        }
        return rows.values.toList();
      }
    }
    throw CampusException('자료실 목록이 수집 한도를 초과했어요.');
  }

  /// [previous] lets unchanged material/content rows reuse their stored
  /// attachment details for [reuseDetailsFor] instead of one request per row
  /// on every collection. Zero (manual collection) always refetches.
  Future<List<CampusItem>> fetchItems({
    Future<void> Function(List<Map<String, dynamic>>)? onCourses,
    Map<String, CampusItem> previous = const {},
    Duration reuseDetailsFor = Duration.zero,
  }) async {
    final now = DateTime.now().toUtc();
    CampusItem? reusable(CampusItem listed) {
      if (reuseDetailsFor == Duration.zero) return null;
      final old = previous[listed.key];
      final at = DateTime.tryParse('${old?.context['detailAt'] ?? ''}');
      if (old == null ||
          at == null ||
          now.difference(at) > reuseDetailsFor ||
          old.context['listSig'] != listSignature(listed)) {
        return null;
      }
      return old;
    }

    Map<String, dynamic> stamped(CampusItem listed) => {
      ...listed.context,
      'listSig': listSignature(listed),
      'detailAt': now.toIso8601String(),
    };
    taskWarnings.clear();
    resourceWarnings.clear();
    final list = await fetchCourses();
    await onCourses?.call(list);
    final base = <String, dynamic>{
      if (list.isNotEmpty) 'term_year': list.first['term_year'],
      if (list.isNotEmpty) 'term_cd': list.first['term_cd'],
    };
    final result = <String, CampusItem>{};
    final reports = <String, Map<String, dynamic>>{};
    for (final raw in list) {
      final c = Map<String, dynamic>.from(raw);
      await api('/course/addSessionCourseInfo', {
        'course_id': c['course_id'],
        'class_no': c['class_no'],
        ...base,
      });
      final weeks = await api('/week/getStdWeekList', {
        'course_id': c['course_id'],
        'class_no': c['class_no'],
        'is_current': 'N',
      });
      checkFormat('/week/getStdWeekList', weeks);

      void visit(dynamic node) {
        if (node is List) {
          for (final child in node) {
            visit(child);
          }
        } else if (node is Map) {
          final m = Map<String, dynamic>.from(node);
          if (m['module_type'] != null) {
            diagnostic?.call('Module: ${m['module_type']}');
          }
          final extraItem = parseAdditionalLearning(m, c, base);
          if (extraItem != null) result[extraItem.key] = extraItem;
          if (m['module_type'] == 'LR') {
            final reportId = m['report_no'] ?? m['contents_id'];
            if (reportId == null || reportId.toString().isEmpty) {
              throw CampusException('과제 식별자를 확인하지 못했어요.');
            }
            final key = '${c['course_id']}:${c['class_no']}:$reportId';
            reports[key] = {
              ...m,
              'course_id': c['course_id'],
              'class_no': c['class_no'],
              'course_nm': c['course_nm'],
              'contents_id': reportId,
              'item_title_temp': m['report_nm'] ?? m['weekseq_nm'],
            };
          }
          if (m['module_type'] == 'LV' && m['weekseq_no'] != null) {
            final contentId =
                m['contents_id']?.toString() ?? str(m, 'weekseq_no');
            final key =
                'LV:${c['course_id']}:${c['class_no']}:${m['contents_id']}:${m['weekseq_no']}';
            final context = <String, dynamic>{
              ...base,
              'course_id': c['course_id'],
              'class_no': c['class_no'],
              'weekseq_no': m['weekseq_no'],
              'contents_id': m['contents_id'],
              'module_type': 'LV',
            };
            result[key] = CampusItem(
              key: key,
              type: 'LV',
              progress: contentProgress(m),
              externalUrl: safeExternalLink(m['contents_url']),
              bodyHtml: '${m['weekseq_content'] ?? ''}',
              media: extractCampusMedia(
                '${m['weekseq_content'] ?? ''}',
                m['attach_file_list'],
                notice: false,
              ),
              attendanceRequired: m['attend_apply_yn'] == 'Y'
                  ? true
                  : m['attend_apply_yn'] == 'N'
                  ? false
                  : null,
              title: textOf(m['weekseq_nm']),
              course: textOf(c['course_nm']),
              courseId: str(c, 'course_id'),
              classNo: str(c, 'class_no'),
              contentsId: contentId,
              startsAt: moduleStart(m),
              published: m['learning_open_yn'] != 'N',
              status: m.containsKey('complete_yn')
                  ? m['complete_yn'] == 'Y'
                        ? 'done'
                        : 'pending'
                  : 'unknown',
              body: textOf(m['weekseq_content']),
              due: m['weekseq_end_dt'] == null
                  ? null
                  : campusDate(
                      '${m['weekseq_end_dt']} ${m['weekseq_end_dt_hour'] ?? '23'}:${m['weekseq_end_dt_min'] ?? '59'}:00',
                    ),
              context: context,
            );
          }
          for (final value in m.values) {
            if (value is List || value is Map) visit(value);
          }
        }
      }

      if (weeks is! Map || weeks['week_list'] is! List) {
        throw CampusException('콘텐츠 목록 형식이 변경됐어요.');
      }
      visit(weeks['week_list']);
      // Assignments outside the weekly curriculum are listed separately.
      final extra = await api('/week/getStdEtcList', {
        'course_id': c['course_id'],
        'is_current': 'N',
      });
      checkFormat('/week/getStdEtcList', extra);
      if (extra is! Map || extra['etc_list'] is! List) {
        throw CampusException('기타 학습요소 목록 형식이 변경됐어요.');
      }
      visit(extra['etc_list']);
      try {
        for (final row in await fetchArchiveRows(c)) {
          final archive = parseAdditionalLearning(
            {...row, 'module_type': 'LS'},
            c,
            base,
          );
          if (archive != null) result[archive.key] = archive;
        }
      } catch (_) {
        resourceWarnings.add('LSCOURSE:${c['course_id']}:${c['class_no']}');
        diagnostic?.call(
          'Archive board list unavailable; keep previous course materials',
        );
      }
    }
    for (final entry in result.entries.toList()) {
      final i = entry.value;
      if (i.type != 'LS') continue;
      final kept = reusable(i);
      if (kept != null) {
        result[entry.key] = CampusItem.fromJson({
          ...i.toJson(),
          'body': kept.body,
          'bodyHtml': kept.bodyHtml,
          'published': kept.published,
          'media': kept.media.map((m) => m.toJson()).toList(),
          'context': kept.context,
        });
        continue;
      }
      try {
        final detail = await api('/archive/detail', {
          'course_id': i.courseId,
          'boarditem_no': i.contentsId,
          'is_view': 'N',
        });
        checkFormat('/archive/detail', detail);
        if (detail is! Map) throw CampusException('자료실 상세 형식 확인 필요');
        final body = '${detail['boarditem_content'] ?? i.bodyHtml}';
        result[entry.key] = CampusItem.fromJson({
          ...i.toJson(),
          'body': textOf(body),
          'bodyHtml': body,
          'published': detail['status'] == 'B' ? false : i.published,
          'media': extractCampusMedia(
            body,
            detail['attach_file_list'],
            notice: true,
          ).map((m) => m.toJson()).toList(),
          'context': stamped(i),
        });
      } catch (_) {
        resourceWarnings.add(i.key);
        diagnostic?.call('Archive attachment list unavailable');
      }
    }
    // Content attachments use the same download/cache path as notice and task files.
    for (final entry in result.entries.toList()) {
      final i = entry.value;
      if (i.type != 'LV' || i.context['weekseq_no'] == null) continue;
      final kept = reusable(i);
      if (kept != null) {
        result[entry.key] = CampusItem.fromJson({
          ...i.toJson(),
          'media': kept.media.map((m) => m.toJson()).toList(),
          'context': kept.context,
        });
        continue;
      }
      try {
        final files = await api('/week/getAttachFileList', {
          'course_id': i.courseId,
          'class_no': i.classNo,
          'weekseq_no': i.context['weekseq_no'],
        });
        checkFormat('/week/getAttachFileList', files);
        if (files is Map) {
          result[entry.key] = CampusItem.fromJson({
            ...i.toJson(),
            'media': extractCampusMedia(
              i.bodyHtml,
              files['attach_file_list'],
              notice: false,
            ).map((m) => m.toJson()).toList(),
            'context': stamped(i),
          });
        }
      } catch (_) {
        resourceWarnings.add(i.key);
        diagnostic?.call('Content attachment list unavailable');
      }
    }
    String? sessionCourse;
    for (final m in reports.values) {
      final context = <String, dynamic>{
        ...base,
        'course_id': m['course_id'],
        'class_no': m['class_no'],
        'report_no': m['contents_id'],
        'weekseq_no': m['weekseq_no'],
        'item_id': m['item_id'],
      };
      // A submitted assignment whose deadlines have passed rarely changes;
      // automatic collections reuse it for a day when its list row is the
      // same (3 requests each: build 79 spent 7 s on 19 assignments). Grades
      // released later therefore appear within a day, or at once on a
      // manual collection.
      final reportKey =
          'LR:${m['course_id']}:${m['class_no']}:${m['contents_id']}';
      final reportSig = sha256.convert(utf8.encode(jsonEncode(m))).toString();
      final old = previous[reportKey];
      final oldAt = DateTime.tryParse('${old?.context['detailAt'] ?? ''}');
      Duration? reportReuse() {
        if (reuseDetailsFor == Duration.zero ||
            old == null ||
            old.due == null) {
          return null;
        }
        if (old.context['listSig'] != reportSig) return null;
        final dueIn = old.due!.difference(now);
        // Submitted and closed: grades may appear later, so once a day.
        if (old.done && dueIn.isNegative) return const Duration(hours: 24);
        // Submitted, still open: a submission is not withdrawn by itself.
        if (old.done) return reuseDetailsFor;
        // Not submitted and the deadline is days away: hourly is enough.
        // Near deadlines are always checked so a submission shows at once.
        if (dueIn > const Duration(days: 3)) return const Duration(hours: 1);
        return null;
      }

      final window = reportReuse();
      if (old != null &&
          window != null &&
          oldAt != null &&
          now.difference(oldAt) < window) {
        result[reportKey] = old;
        continue;
      }
      // Reports arrive grouped by course; the school session only needs to
      // switch when the course changes (build 82: 19 calls for 6 courses).
      final course = '${m['course_id']}:${m['class_no']}';
      if (!reuseCourseSession || course != sessionCourse) {
        await api('/course/addSessionCourseInfo', context);
        sessionCourse = course;
      }
      final rawDetail = await api('/task/detail', context);
      checkFormat('/task/detail', rawDetail);
      final submitted = await api('/task/stdDetail', context);
      checkFormat('/task/stdDetail', submitted);
      final parsed = taskDetail(rawDetail);
      final detail = parsed ?? <String, dynamic>{};
      final status = parsed == null ? 'unknown' : submissionStatus(submitted);
      final key = 'LR:${m['course_id']}:${m['class_no']}:${m['contents_id']}';
      if (parsed == null || status == 'unknown') {
        taskWarnings[key] =
            '/task/detail ${responseShape(rawDetail)} · /task/stdDetail ${responseShape(submitted)}';
      }
      DateTime? parseDue(dynamic d, dynamic t) =>
          campusDate('${d ?? ''} ${t ?? '23:59'}');
      final normalDue =
          parseDue(
            detail['report_apply_end_dt'],
            detail['report_apply_end_tm'],
          ) ??
          campusDate(str(m, 'info'));
      // A start without a time opens at the start of the day, not 23:59.
      final extraStart = parseDue(
        detail['report_add_str_dt'] ?? m['add_str_dt'],
        detail['report_add_str_tm'] ?? m['add_str_tm'] ?? '00:00',
      );
      final extraDue = parseDue(
        detail['report_add_end_dt'] ?? m['add_end_dt'],
        detail['report_add_end_tm'] ?? m['add_end_tm'],
      );
      result[key] = CampusItem(
        key: key,
        evaluation: releasedTaskEvaluation(submitted, detail),
        originalDue: normalDue,
        additionalStartsAt: extraStart,
        additionalDue: extraDue,
        type: 'LR',
        title: textOf(detail['report_nm'] ?? m['item_title_temp']),
        course: textOf(m['course_nm']),
        courseId: str(m, 'course_id'),
        classNo: str(m, 'class_no'),
        contentsId: str(m, 'contents_id'),
        status: status,
        startsAt: laterDate(
          moduleStart(m),
          campusDate(
            '${detail['report_apply_str_dt']} ${detail['report_apply_str_tm'] ?? '00:00'}',
          ),
        ),
        published: m['learning_open_yn'] != 'N',
        body: textOf(detail['report_content']),
        bodyHtml: '${detail['report_content'] ?? ''}',
        media: extractCampusMedia(
          '${detail['report_content'] ?? ''}',
          detail['attach_file_list'],
          notice: false,
        ),
        due: laterDate(normalDue, extraDue),
        // Bookkeeping stays on the stored item, never in request payloads.
        context: {
          ...context,
          'listSig': reportSig,
          'detailAt': now.toIso8601String(),
        },
      );
    }
    return result.values.toList()..sort(
      (a, b) =>
          (a.due ?? DateTime.utc(2100)).compareTo(b.due ?? DateTime.utc(2100)),
    );
  }

  Future<Map<String, dynamic>> navigation(CampusItem item) async {
    // Local reuse bookkeeping (listSig, detailAt) is not school data.
    final ctx = await api(
      '/course/addSessionCourseInfo',
      Map.of(item.context)
        ..remove('listSig')
        ..remove('detailAt'),
    );
    final cookies = <Map<String, String>>[];
    for (final host in [learning, loginHost]) {
      for (final c in await jar.loadForRequest(Uri.parse('$host/'))) {
        cookies.add({'url': host, 'cookie': c.toString()});
      }
    }
    final data = ctx['data'];
    if (data is! Map) {
      throw CampusException('강의실 정보를 확인하지 못했어요. 다시 수집해 주세요.');
    }
    return {
      'context': data,
      'cookies': cookies,
      'url': item.type == 'LS'
          ? '$learning/std/archiveView'
          : item.type == 'LD'
          ? '$learning/std/debateView'
          : item.type == 'LT'
          ? '$learning/std/teamProjectView'
          : (item.type == 'LQ' || item.type == 'LE')
          ? '$learning/std/examDetail'
          : item.type == 'NT'
          ? '$learning/std/noticeDetail?no=${Uri.encodeQueryComponent(item.contentsId)}'
          : '$learning${item.type == 'LR' ? '/std/taskView' : '/std/course'}',
      'target': item.contentsId,
    };
  }

  Future<List<CampusNotice>> fetchNotices() async {
    final terms = await api('/term/getYearTermList', null);
    checkFormat('/term/getYearTermList', terms);
    if (terms is! Map || terms['list'] is! List) {
      throw CampusException('공지의 학기 목록 형식이 변경됐어요.');
    }
    final term = (terms['list'] as List)
        .cast<Map>()
        .where((m) => m['current_term_yn'] == 'Y')
        .firstOrNull;
    if (term == null) throw CampusException('공지의 현재 학기를 찾지 못했어요.');
    final notices = <String, CampusNotice>{};
    for (var offset = 0; offset < 10000; offset += 100) {
      final data = await api('/board/std/notice/list', {
        'type': 'notice',
        'term_year': term['term_year'],
        'term_cd': term['term_cd'],
        'limit': 100,
        'offset': offset,
      });
      checkFormat('/board/std/notice/list', data);
      if (data is! Map || data['list'] is! List) {
        throw CampusException('공지 목록 형식이 변경됐어요.');
      }
      final rows = data['list'] as List;
      for (final raw in rows) {
        final row = Map<String, dynamic>.from(raw);
        final id = str(row, 'boarditem_no');
        if (id.isEmpty || notices.containsKey(id)) {
          throw CampusException('공지 페이지를 정확하게 확인하지 못했어요.');
        }
        notices[id] = CampusNotice(
          id: id,
          title: textOf(row['boarditem_title']),
          course: textOf(row['course_nm']),
          published: campusDate(str(row, 'insert_dt')),
          read: row['read_yn'] == 'Y',
          context: {
            'term_year': term['term_year'],
            'term_cd': term['term_cd'],
            'course_id': row['course_id'],
            'class_no': row['class_no'],
          },
        );
      }
      final total = int.tryParse('${data['tot_cnt']}');
      if ((total != null && notices.length >= total) || rows.length < 100) {
        return notices.values.toList()..sort(
          (a, b) => (b.published ?? DateTime.utc(1970)).compareTo(
            a.published ?? DateTime.utc(1970),
          ),
        );
      }
    }
    throw CampusException('공지 수가 많아 전체 수집을 끝내지 못했어요.');
  }

  Future<CampusNotice> fetchNoticeBody(CampusNotice notice) async {
    final context = await api('/course/addSessionCourseInfo', notice.context);
    final session = context is Map && context['data'] is Map
        ? Map<String, dynamic>.from(context['data'])
        : <String, dynamic>{};
    final info = await api('/board/notice/info', {
      ...notice.context,
      ...session,
      'no': notice.id,
    });
    checkFormat('/board/notice/info', info);
    if (info is! Map || !info.containsKey('boarditem_content')) {
      throw CampusException('공지 본문을 확인하지 못했어요.');
    }
    return CampusNotice(
      id: notice.id,
      title: notice.title,
      course: notice.course,
      context: notice.context,
      published: notice.published,
      read: notice.read,
      body: textOf(info['boarditem_content']),
      bodyHtml: '${info['boarditem_content'] ?? ''}',
      media: extractCampusMedia(
        '${info['boarditem_content'] ?? ''}',
        info['attach_file_list'],
        notice: true,
      ),
      bodyFetched: true,
    );
  }

  Future<List<CampusFreeboardPost>> fetchFreeboardPosts(
    Map<String, dynamic> courseContext, {
    String courseName = '',
    Map<String, CampusFreeboardPost> previous = const {},
  }) async {
    final termYear = str(courseContext, 'term_year');
    final termCd = str(courseContext, 'term_cd');
    final courseId = str(courseContext, 'course_id');
    final classNo = str(courseContext, 'class_no');
    final baseContext = <String, dynamic>{
      if (termYear.isNotEmpty) 'term_year': termYear,
      if (termCd.isNotEmpty) 'term_cd': termCd,
      'course_id': courseId,
      'class_no': classNo,
    };

    await api('/course/addSessionCourseInfo', baseContext);

    final pinnedMap = <String, CampusFreeboardPost>{};
    try {
      final topData = await api('/board/bbs/list/top', baseContext);
      checkFormat('/board/bbs/list/top', topData);
      if (topData is! Map || topData['list'] is! List) {
        throw CampusException('자유게시판 고정글 목록 형식이 변경됐어요.');
      }
      if (topData['list'] is List) {
        for (final raw in (topData['list'] as List).whereType<Map>()) {
          final row = Map<String, dynamic>.from(raw);
          if (!isPublicFreeboardPost(row)) continue;
          final id = str(row, 'boarditem_no');
          if (id.isEmpty) continue;
          final sig = freeboardListSignature(row);
          final old = previous['FB:$courseId:$classNo:$id'];
          final reuse = old != null && old.bodyFetched && old.listSig == sig;
          final files = row['attach_file_list'];
          pinnedMap[id] = CampusFreeboardPost(
            id: id,
            courseId: courseId,
            classNo: classNo,
            course: courseName,
            title: textOf(row['boarditem_title']),
            body: reuse ? old.body : '',
            bodyHtml: reuse ? old.bodyHtml : '',
            media: reuse
                ? old.media
                : extractCampusMedia('', files, notice: true),
            published: freeboardDate(row, 'insert_dt'),
            updated: freeboardDate(row, 'update_dt'),
            isPinned: true,
            author: textOf(row['writeruser_name']),
            hasAttachment:
                row['file_yn'] == 'Y' ||
                (files is List && files.isNotEmpty),
            bodyFetched: reuse,
            context: baseContext,
            listSig: sig,
          );
        }
      }
    } catch (_) {
      // Never replace the cache with a list missing pinned posts.
      rethrow;
    }

    final regularList = <CampusFreeboardPost>[];
    final seenRegular = <String>{};
    for (var offset = 0; offset < 500; offset += 100) {
      final data = await api('/board/bbs/list', {
        ...baseContext,
        'q_key': '',
        'q_where_type': 'BOARDITEM_TITLE',
        'offset': offset,
        'limit': 100,
      });
      checkFormat('/board/bbs/list', data);
      if (data is! Map || data['list'] is! List) {
        throw CampusException('자유게시판 목록 형식이 변경됐어요.');
      }
      final rows = (data['list'] as List).cast<Map>();
      for (final raw in rows) {
        final row = Map<String, dynamic>.from(raw);
        if (!isPublicFreeboardPost(row)) continue;
        final id = str(row, 'boarditem_no');
        if (id.isEmpty || pinnedMap.containsKey(id) || !seenRegular.add(id)) continue;
        final sig = freeboardListSignature(row);
        final old = previous['FB:$courseId:$classNo:$id'];
        final reuse = old != null && old.bodyFetched && old.listSig == sig;
        final files = row['attach_file_list'];
        regularList.add(
          CampusFreeboardPost(
            id: id,
            courseId: courseId,
            classNo: classNo,
            course: courseName,
            title: textOf(row['boarditem_title']),
            body: reuse ? old.body : '',
            bodyHtml: reuse ? old.bodyHtml : '',
            media: reuse
                ? old.media
                : extractCampusMedia('', files, notice: true),
            published: freeboardDate(row, 'insert_dt'),
            updated: freeboardDate(row, 'update_dt'),
            isPinned: false,
            author: textOf(row['writeruser_name']),
            hasAttachment:
                row['file_yn'] == 'Y' ||
                (files is List && files.isNotEmpty),
            bodyFetched: reuse,
            context: baseContext,
            listSig: sig,
          ),
        );
      }
      final total = int.tryParse(
        '${data['total'] ?? data['tot_cnt'] ?? data['total_cnt'] ?? ''}',
      );
      if (rows.length < 100 || (total != null && offset + rows.length >= total)) {
        break;
      }
      if (offset == 400) throw CampusException('자유게시판 목록이 500건을 넘어 기존 저장본을 유지해요.');
    }

    return [...pinnedMap.values, ...regularList];
  }

  Future<CampusFreeboardPost> fetchFreeboardDetail(
    CampusFreeboardPost post, {
    bool courseSessionReady = false,
  }) async {
    if (!courseSessionReady || !reuseCourseSession) {
      await api('/course/addSessionCourseInfo', post.context);
    }
    final info = await api('/board/bbs/info', {
      ...post.context,
      'no': post.id,
    });
    checkFormat('/board/bbs/info', info);
    if (info is! Map || (!info.containsKey('boarditem_content') &&
        !info.containsKey('attach_file_list'))) {
      throw CampusException('자유게시판 본문을 확인하지 못했어요.');
    }
    final infoMap = Map<String, dynamic>.from(info);
    if (!isPublicFreeboardPost(infoMap)) {
      throw CampusException('삭제되었거나 공개되지 않은 자유게시판 글이에요.');
    }
    final content = '${infoMap['boarditem_content'] ?? ''}';
    final media = extractCampusMedia(
      content,
      infoMap['attach_file_list'],
      notice: true,
    );
    return post.copyWith(
      author: textOf(infoMap['writeruser_name']).isNotEmpty
          ? textOf(infoMap['writeruser_name']) : post.author,
      body: textOf(content),
      bodyHtml: content,
      media: media,
      bodyFetched: true,
      updated: freeboardDate(infoMap, 'update_dt') ?? post.updated,
    );
  }

  Future<Map<String, dynamic>> freeboardNavigation(
    Map<String, dynamic> courseContext, {
    String? postId,
  }) async {
    final ctx = await api('/course/addSessionCourseInfo', {
      'term_year': courseContext['term_year'],
      'term_cd': courseContext['term_cd'],
      'course_id': courseContext['course_id'],
      'class_no': courseContext['class_no'],
    });
    final cookies = <Map<String, String>>[];
    for (final host in [learning, loginHost]) {
      for (final c in await jar.loadForRequest(Uri.parse('$host/'))) {
        cookies.add({'url': host, 'cookie': c.toString()});
      }
    }
    final data = ctx is Map && ctx['data'] is Map ? ctx['data'] : {};
    final path = postId != null && postId.isNotEmpty
        ? '/std/boardDetail?no=${Uri.encodeQueryComponent(postId)}'
        : '/std/board';
    return {
      'context': data,
      'cookies': cookies,
      'url': '$learning$path',
      'target': postId ?? '',
    };
  }

  Future<({List<int> bytes, String mime})> downloadMedia(
    CampusMedia media, {
    int limit = 50 * 1024 * 1024,
  }) => retryNetworkRead(() async {
    if (_closed) throw CampusException('연결이 종료되었어요.');
    final local = media.url.startsWith('data:');
    final token = local ? null : await trafficStarted?.call();
    var failed = true;
    try {
      final result = await requestDeadline(
        () => _downloadMediaOnce(media, limit: limit),
        _abortRequest,
        limit: const Duration(seconds: 75),
      );
      failed = false;
      return result;
    } on CampusHttpException catch (error) {
      if (error.status != 401) rethrow;
      await authenticationLost?.call();
      throw CampusAuthenticationLost();
    } finally {
      if (!local) await trafficFinished?.call(token, failed);
    }
  });

  Future<({List<int> bytes, String mime})> _downloadMediaOnce(
    CampusMedia media, {
    required int limit,
  }) async {
    if (media.image && media.url.startsWith('data:') && media.supported) {
      if (media.url.length > limit * 2) {
        throw CampusException('이미지 크기 제한을 초과했어요.');
      }
      final bytes = base64Decode(media.url.split(',').last);
      if (bytes.length > limit) throw CampusException('이미지 크기 제한을 초과했어요.');
      return (
        bytes: bytes,
        mime: media.url.substring(5, media.url.indexOf(';')),
      );
    }
    var url = Uri.parse(media.url);
    var form = media.form;
    for (var hop = 0; hop < 6; hop++) {
      if (!allowedMediaUri(url)) {
        throw CampusException('외부 이미지·파일은 사이버캠퍼스에서 확인해 주세요.');
      }
      final req = await http
          .openUrl(form.isEmpty ? 'GET' : 'POST', url)
          .timeout(const Duration(seconds: 20));
      req.followRedirects = false;
      req.cookies.addAll(await jar.loadForRequest(url));
      req.headers.set(HttpHeaders.refererHeader, '$learning/home');
      req.headers.set(HttpHeaders.userAgentHeader, 'Mozilla/5.0 CampusRadar');
      if (form.isNotEmpty) {
        final cipher = enc.Encrypter(
          enc.AES(enc.Key.fromUtf8(transportKey), mode: enc.AESMode.cbc),
        );
        final e = cipher
            .encrypt(jsonEncode(form), iv: enc.IV.allZerosOfLength(16))
            .base64;
        req.headers.contentType = ContentType(
          'application',
          'x-www-form-urlencoded',
          charset: 'utf-8',
        );
        req.write('e=${Uri.encodeQueryComponent(e)}');
      }
      final res = await req.close().timeout(const Duration(seconds: 25));
      await jar.saveFromResponse(url, res.cookies);
      if (res.cookies.isNotEmpty) await sessionUpdated?.call();
      if (res.isRedirect) {
        final location = res.headers.value('location');
        await res.listen((_) {}).cancel();
        if (location == null) throw CampusException('파일 이동 주소가 없어요.');
        url = url.resolve(location);
        if (res.statusCode != 307 && res.statusCode != 308) form = {};
        continue;
      }
      if (res.statusCode != 200 || res.contentLength > limit) {
        await res.listen((_) {}).cancel();
        if (res.statusCode != 200) {
          throw CampusHttpException(res.statusCode, url.path);
        }
        throw CampusException(
          res.contentLength > limit
              ? '파일당 50MB 저장 제한을 초과했어요.'
              : '파일 응답 오류 (${res.statusCode})',
        );
      }
      var mime =
          res.headers.contentType?.mimeType ?? 'application/octet-stream';
      if (mime == 'text/html' || mime == 'application/json') {
        await res.listen((_) {}).cancel();
        throw CampusException('파일 대신 로그인 또는 오류 응답이 왔습니다. 다시 수집해 주세요.');
      }
      final bytes = <int>[];
      await for (final chunk in res.timeout(const Duration(seconds: 25))) {
        bytes.addAll(chunk);
        if (bytes.length > limit) {
          throw CampusException('파일당 50MB 저장 제한을 초과했어요.');
        }
      }
      if (bytes.isEmpty) throw CampusException('파일 내용이 비어 있어요.');
      // Some CMS downloads use octet-stream for valid image bytes.
      if (media.image) {
        if (bytes.length >= 8 &&
            bytes[0] == 137 &&
            bytes[1] == 80 &&
            bytes[2] == 78 &&
            bytes[3] == 71) {
          mime = 'image/png';
        } else if (bytes.length >= 3 &&
            bytes[0] == 255 &&
            bytes[1] == 216 &&
            bytes[2] == 255) {
          mime = 'image/jpeg';
        } else if (bytes.length >= 6 &&
            ascii
                .decode(bytes.take(6).toList(), allowInvalid: true)
                .startsWith('GIF8')) {
          mime = 'image/gif';
        } else if (bytes.length >= 12 &&
            ascii.decode(bytes.take(4).toList(), allowInvalid: true) ==
                'RIFF' &&
            ascii.decode(bytes.sublist(8, 12), allowInvalid: true) == 'WEBP') {
          mime = 'image/webp';
        } else if (bytes.length >= 2 && bytes[0] == 0x42 && bytes[1] == 0x4D) {
          // CampusMedia.image counts .bmp as an image, so accept its bytes.
          mime = 'image/bmp';
        } else {
          throw CampusException(
            '지원하는 이미지 형식(PNG·JPEG·GIF·WebP·BMP)이 아니에요. 원문에서 확인해 주세요.',
          );
        }
      }
      if (mime == 'application/octet-stream' &&
          utf8
              .decode(bytes.take(256).toList(), allowMalformed: true)
              .trimLeft()
              .toLowerCase()
              .startsWith('<!doctype html')) {
        throw CampusException('파일 대신 로그인 화면이 왔습니다. 다시 수집해 주세요.');
      }
      return (bytes: bytes, mime: mime);
    }
    throw CampusException('파일 이동이 반복돼요.');
  }

  void close() {
    _closed = true;
    ActiveRequests.remove(http);
    http.close(force: true);
  }
}

/// Fingerprint of a list row as parsed before its detail request: if the
/// school's list entry is unchanged, the stored detail is still current.
String listSignature(CampusItem listed) {
  final json = listed.toJson()
    ..remove('context')
    ..remove('media');
  return sha256.convert(utf8.encode(jsonEncode(json))).toString();
}

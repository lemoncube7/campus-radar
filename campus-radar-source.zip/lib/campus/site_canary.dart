import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/notification_gateway.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/tasks/task_response.dart';
import 'package:html/parser.dart' as html;

/// 학교 사이트(사이버캠퍼스 API·HTML) 응답 형식 또는 구조 변경 감지 결과.
class SiteFormatIssue {
  final String route;
  final String expected;
  final String actual;
  final String reason;

  const SiteFormatIssue({
    required this.route,
    required this.expected,
    required this.actual,
    required this.reason,
  });

  /// 1일 1회 알림 빈도 제한을 위한 원인 식별자.
  String get causeKey => route;

  @override
  String toString() => '[$route] $reason (기대: $expected, 실제: $actual)';
}

/// 사이트 형식 변경 시 사용자에게 알리는 안내 문구.
const siteCanaryUserMessage = '학교 사이트가 바뀌어 일부 수집이 안 될 수 있어요.';

/// 수집 코드(lib/campus/)가 기대하는 응답 형태(필드 이름, 목록 구조)를 확인하는 형식 점검 함수.
/// 기존 [responseShape] 진단 코드를 재사용하여 실제 형태를 요약한다.
SiteFormatIssue? checkSiteResponseShape(String route, dynamic response) {
  final cleanRoute = Uri.parse(route).path;
  if (response == null) {
    if (cleanRoute == '/task/stdDetail') return null; // 미제출 과제는 null이 정상
    return SiteFormatIssue(
      route: cleanRoute,
      expected: 'Map 응답',
      actual: 'null',
      reason: '서버 응답 본문이 비어 있어요(null).',
    );
  }

  if (cleanRoute == '/task/stdDetail') {
    final status = submissionStatus(response);
    if (status == 'unknown') {
      return SiteFormatIssue(
        route: cleanRoute,
        expected: '제출 상태 확인 가능한 Map 또는 List (temp_yn, apply_yn, report_apply_no 등)',
        actual: responseShape(response),
        reason: '과제 제출 상태 형식을 판정하지 못했어요.',
      );
    }
    return null;
  }

  if (cleanRoute == '/task/detail') {
    final parsed = taskDetail(response);
    if (parsed == null) {
      return SiteFormatIssue(
        route: cleanRoute,
        expected: 'Map(report_no, report_nm, report_content 중 하나 이상 포함)',
        actual: responseShape(response),
        reason: '과제 상세 필수 필드가 누락되었어요.',
      );
    }
    return null;
  }

  if (response is! Map) {
    return SiteFormatIssue(
      route: cleanRoute,
      expected: 'Map 응답',
      actual: responseShape(response),
      reason: '서버 응답이 Map 객체 형식이 아니에요.',
    );
  }

  final map = response;

  switch (cleanRoute) {
    case '/term/getYearTermList':
      final list = map['list'];
      if (list is! List) {
        return SiteFormatIssue(
          route: cleanRoute,
          expected: 'Map(list: List)',
          actual: list == null ? responseShape(map) : responseShape(list),
          reason: '학기 목록("list") 필드가 누락되었거나 목록 형식이 아니에요.',
        );
      }
      for (final item in list) {
        if (item is! Map) {
          return SiteFormatIssue(
            route: cleanRoute,
            expected: 'List 내 Map 항목',
            actual: responseShape(item),
            reason: '학기 항목이 객체 형식이 아니에요.',
          );
        }
        if (!item.containsKey('current_term_yn') ||
            !item.containsKey('term_year') ||
            !item.containsKey('term_cd')) {
          return SiteFormatIssue(
            route: cleanRoute,
            expected: 'Map(current_term_yn, term_year, term_cd)',
            actual: responseShape(item),
            reason: '학기 항목에 필수 필드(current_term_yn, term_year, term_cd)가 누락되었어요.',
          );
        }
      }
      break;

    case '/course/getStdMyCourseList':
      final courses = map['course_list'];
      if (courses is! List) {
        return SiteFormatIssue(
          route: cleanRoute,
          expected: 'Map(course_list: List)',
          actual: courses == null ? responseShape(map) : responseShape(courses),
          reason: '수강 과목 목록("course_list") 필드가 누락되었거나 목록 형식이 아니에요.',
        );
      }
      for (final item in courses) {
        if (item is! Map) {
          return SiteFormatIssue(
            route: cleanRoute,
            expected: 'List 내 Map 항목',
            actual: responseShape(item),
            reason: '수강 과목 항목이 객체 형식이 아니에요.',
          );
        }
        if (!item.containsKey('course_id') ||
            !item.containsKey('class_no') ||
            !item.containsKey('course_nm')) {
          return SiteFormatIssue(
            route: cleanRoute,
            expected: 'Map(course_id, class_no, course_nm)',
            actual: responseShape(item),
            reason: '수강 과목 항목에 필수 필드(course_id, class_no, course_nm)가 누락되었어요.',
          );
        }
      }
      break;

    case '/week/getStdWeekList':
      final weeks = map['week_list'];
      if (weeks is! List) {
        return SiteFormatIssue(
          route: cleanRoute,
          expected: 'Map(week_list: List)',
          actual: weeks == null ? responseShape(map) : responseShape(weeks),
          reason: '주차별 학습 목록("week_list") 필드가 누락되었거나 목록 형식이 아니에요.',
        );
      }
      break;

    case '/week/getStdEtcList':
      final etc = map['etc_list'];
      if (etc is! List) {
        return SiteFormatIssue(
          route: cleanRoute,
          expected: 'Map(etc_list: List)',
          actual: etc == null ? responseShape(map) : responseShape(etc),
          reason: '기타 학습요소 목록("etc_list") 필드가 누락되었거나 목록 형식이 아니에요.',
        );
      }
      break;

    case '/archive/list':
      final list = map['list'];
      if (list is! List) {
        return SiteFormatIssue(
          route: cleanRoute,
          expected: 'Map(list: List)',
          actual: list == null ? responseShape(map) : responseShape(list),
          reason: '자료실 목록("list") 필드가 누락되었거나 목록 형식이 아니에요.',
        );
      }
      for (final item in list) {
        if (item is! Map || item['boarditem_no'] == null) {
          return SiteFormatIssue(
            route: cleanRoute,
            expected: 'List 내 Map(boarditem_no)',
            actual: responseShape(item),
            reason: '자료실 항목 식별자(boarditem_no)가 누락되었어요.',
          );
        }
      }
      break;

    case '/archive/detail':
      if (!map.containsKey('boarditem_content') &&
          !map.containsKey('attach_file_list')) {
        return SiteFormatIssue(
          route: cleanRoute,
          expected: 'Map(boarditem_content 또는 attach_file_list 포함)',
          actual: responseShape(map),
          reason: '자료실 상세 내용 필드가 누락되었어요.',
        );
      }
      break;

    case '/week/getAttachFileList':
      if (map.containsKey('attach_file_list') &&
          map['attach_file_list'] != null &&
          map['attach_file_list'] is! List) {
        return SiteFormatIssue(
          route: cleanRoute,
          expected: 'Map(attach_file_list: List)',
          actual: responseShape(map['attach_file_list']),
          reason: '첨부파일 목록("attach_file_list")이 목록 형식이 아니에요.',
        );
      }
      break;

    case '/board/std/notice/list':
      final list = map['list'];
      if (list is! List) {
        return SiteFormatIssue(
          route: cleanRoute,
          expected: 'Map(list: List)',
          actual: list == null ? responseShape(map) : responseShape(list),
          reason: '공지 목록("list") 필드가 누락되었거나 목록 형식이 아니에요.',
        );
      }
      for (final item in list) {
        if (item is! Map || item['boarditem_no'] == null) {
          return SiteFormatIssue(
            route: cleanRoute,
            expected: 'List 내 Map(boarditem_no)',
            actual: responseShape(item),
            reason: '공지 항목 식별자(boarditem_no)가 누락되었어요.',
          );
        }
      }
      break;

    case '/board/notice/info':
      if (!map.containsKey('boarditem_content')) {
        return SiteFormatIssue(
          route: cleanRoute,
          expected: 'Map(boarditem_content)',
          actual: responseShape(map),
          reason: '공지 본문("boarditem_content") 필드가 누락되었어요.',
        );
      }
      break;

    case '/board/bbs/list/top':
      final list = map['list'];
      if (list is! List) {
        return SiteFormatIssue(
          route: cleanRoute,
          expected: 'Map(list: List)',
          actual: list == null ? responseShape(map) : responseShape(list),
          reason: '고정 자유게시판 목록("list") 필드가 누락되었거나 목록 형식이 아니에요.',
        );
      }
      break;

    case '/board/bbs/list':
      final list = map['list'];
      if (list is! List) {
        return SiteFormatIssue(
          route: cleanRoute,
          expected: 'Map(list: List)',
          actual: list == null ? responseShape(map) : responseShape(list),
          reason: '자유게시판 목록("list") 필드가 누락되었거나 목록 형식이 아니에요.',
        );
      }
      break;

    case '/board/bbs/info':
      if (!map.containsKey('boarditem_content') &&
          !map.containsKey('attach_file_list')) {
        return SiteFormatIssue(
          route: cleanRoute,
          expected: 'Map(boarditem_content 또는 attach_file_list 포함)',
          actual: responseShape(map),
          reason: '자유게시판 상세 내용 필드가 누락되었어요.',
        );
      }
      break;

    case '/user/apiCnuAuthLogin':
      if (map['redirect_url'] == null) {
        return SiteFormatIssue(
          route: cleanRoute,
          expected: 'Map(redirect_url)',
          actual: responseShape(map),
          reason: '로그인 응답에 redirect_url이 누락되었어요.',
        );
      }
      break;

    case '/course/addSessionCourseInfo':
      if (map.containsKey('data') &&
          map['data'] != null &&
          map['data'] is! Map) {
        return SiteFormatIssue(
          route: cleanRoute,
          expected: 'Map(data: Map)',
          actual: responseShape(map['data']),
          reason: '강의실 세션 data 필드가 Map 형식이 아니에요.',
        );
      }
      break;
  }

  return null;
}

/// 사이버캠퍼스 로그인 HTML 문서의 암호화 스크립트 및 키 필드 구조를 점검한다.
SiteFormatIssue? checkLoginHtmlStructure(String htmlText) {
  try {
    final page = html.parse(htmlText);
    final aesScript = page
        .querySelectorAll('script[src]')
        .map((e) => e.attributes['src'] ?? '')
        .where((s) => s.contains('gibberish-aes'))
        .firstOrNull;
    if (aesScript == null) {
      return const SiteFormatIssue(
        route: 'html:login',
        expected: '<script src="*gibberish-aes*">',
        actual: 'script 태그 없음 또는 gibberish-aes 미포함',
        reason: '로그인 페이지 암호화 스크립트(gibberish-aes) 경로를 찾을 수 없어요.',
      );
    }
    final keyInput = page.querySelector('input[name=key]');
    if (keyInput == null) {
      return const SiteFormatIssue(
        route: 'html:login',
        expected: '<input name="key">',
        actual: 'input[name=key] 태그 없음',
        reason: '로그인 페이지 전송 키(key) 입력 필드를 찾을 수 없어요.',
      );
    }
  } catch (e) {
    return SiteFormatIssue(
      route: 'html:login',
      expected: 'HTML 문서',
      actual: e.runtimeType.toString(),
      reason: '로그인 HTML 구문 분석 실패: $e',
    );
  }
  return null;
}

/// 학교 사이트 구조 변경 감지 사항을 활동 로그에 남긴다.
Future<void> logSiteFormatIssue(Store store, SiteFormatIssue issue) async {
  await store.log(
    'sync',
    '학교 사이트 구조 변경 감지',
    '${issue.route} 응답 형식이 변경되었어요.\n'
    '원인: ${issue.reason}\n'
    '기대: ${issue.expected}\n'
    '실제: ${issue.actual}',
  );
}

/// 사용자에게 형식 변경을 알린다. 동일 원인(causeKey)은 1일 1회만 발송한다.
Future<bool> notifySiteChangeIfDue(
  Store store,
  SiteFormatIssue issue, {
  DateTime? nowOverride,
}) async {
  final now = nowOverride ?? DateTime.now().toUtc();
  final metaKey = 'siteCanaryNotified:${issue.causeKey}';
  final lastStr = await store.meta(metaKey);
  if (lastStr != null) {
    final last = DateTime.tryParse(lastStr);
    if (last != null && now.difference(last) < const Duration(hours: 24)) {
      return false;
    }
  }

  await store.setMeta(metaKey, now.toIso8601String());
  await store.setMeta(MetaKey.lastError, siteCanaryUserMessage);

  try {
    await notifications.show(
      id: notificationId('site-canary:${issue.causeKey}'),
      title: '학교 사이트 변경 감지',
      body: siteCanaryUserMessage,
      notificationDetails: noticeStyle,
      payload: '_tasks',
    );
  } catch (_) {
    // 테스트 또는 비GUI 환경에서는 알림 플러그인이 미등록일 수 있음.
  }

  await store.log(
    'notification',
    '학교 사이트 변경 알림 발송',
    '$siteCanaryUserMessage\n원인: ${issue.route} (${issue.reason})',
  );

  return true;
}

/// 활동 로그 기록과 1일 1회 사용자 알림을 통합 처리한다.
Future<void> handleSiteFormatMismatch(
  Store store,
  SiteFormatIssue issue, {
  DateTime? nowOverride,
}) async {
  await logSiteFormatIssue(store, issue);
  await notifySiteChangeIfDue(store, issue, nowOverride: nowOverride);
}

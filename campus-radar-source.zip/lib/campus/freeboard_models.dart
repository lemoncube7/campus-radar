import 'dart:convert';
import 'package:campus_radar/campus/campus_media.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:crypto/crypto.dart';

/// Representation of a cyber campus course freeboard post.
/// Only the writer's display name is kept; account IDs and contacts are omitted.
class CampusFreeboardPost {
  final String id;
  final String courseId;
  final String classNo;
  final String course;
  final String title;
  final String author;
  final String body;
  final String bodyHtml;
  final List<CampusMedia> media;
  final DateTime? published;
  final DateTime? updated;
  final bool isPinned;
  final bool hasAttachment;
  final bool bodyFetched;
  final Map<String, dynamic> context;
  final String listSig;

  const CampusFreeboardPost({
    required this.id,
    required this.courseId,
    required this.classNo,
    required this.course,
    required this.title,
    this.author = '',
    this.body = '',
    this.bodyHtml = '',
    this.media = const [],
    this.published,
    this.updated,
    this.isPinned = false,
    this.hasAttachment = false,
    this.bodyFetched = false,
    required this.context,
    this.listSig = '',
  });

  /// Compound key separating course and source namespaces (e.g. FB:c0:1:123).
  String get key => 'FB:$courseId:$classNo:$id';

  /// Course key matching the app's course identification (e.g. c0:1).
  String get courseKey => '$courseId:$classNo';

  Map<String, dynamic> toJson() => {
    'id': id,
    'courseId': courseId,
    'classNo': classNo,
    'course': course,
    'title': title,
    'author': author,
    'body': body,
    'bodyHtml': bodyHtml,
    'media': media.map((m) => m.toJson()).toList(),
    'published': published?.toIso8601String(),
    'updated': updated?.toIso8601String(),
    'isPinned': isPinned,
    'hasAttachment': hasAttachment,
    'bodyFetched': bodyFetched,
    'context': context,
    'listSig': listSig,
  };

  factory CampusFreeboardPost.fromJson(Map<String, dynamic> json) =>
      CampusFreeboardPost(
        id: json['id'] as String,
        courseId: json['courseId'] as String,
        classNo: json['classNo'] as String,
        course: json['course'] as String? ?? '',
        title: json['title'] as String? ?? '',
        author: json['author'] as String? ?? '',
        body: json['body'] as String? ?? '',
        bodyHtml: json['bodyHtml'] as String? ?? '',
        media: (json['media'] as List? ?? [])
            .map((m) => CampusMedia.fromJson(Map<String, dynamic>.from(m as Map)))
            .toList(),
        published: json['published'] != null
            ? DateTime.tryParse(json['published'] as String)
            : null,
        updated: json['updated'] != null
            ? DateTime.tryParse(json['updated'] as String)
            : null,
        isPinned: json['isPinned'] == true,
        hasAttachment: json['hasAttachment'] == true,
        bodyFetched: json['bodyFetched'] == true,
        context: Map<String, dynamic>.from(json['context'] as Map? ?? {}),
        listSig: json['listSig'] as String? ?? '',
      );

  CampusFreeboardPost copyWith({
    String? author,
    String? body,
    String? bodyHtml,
    List<CampusMedia>? media,
    bool? bodyFetched,
    DateTime? updated,
    String? listSig,
  }) => CampusFreeboardPost(
    id: id,
    courseId: courseId,
    classNo: classNo,
    course: course,
    title: title,
    author: author ?? this.author,
    body: body ?? this.body,
    bodyHtml: bodyHtml ?? this.bodyHtml,
    media: media ?? this.media,
    published: published,
    updated: updated ?? this.updated,
    isPinned: isPinned,
    hasAttachment: hasAttachment,
    bodyFetched: bodyFetched ?? this.bodyFetched,
    context: context,
    listSig: listSig ?? this.listSig,
  );
}

/// Fingerprint of a freeboard list row before detail fetch for caching & reuse.
String freeboardListSignature(Map<String, dynamic> row) {
  final canonical = {
    'id': '${row['boarditem_no'] ?? ''}',
    'title': '${row['boarditem_title'] ?? ''}',
    'insert_dt': '${row['insert_dt'] ?? ''}',
    'insert_dt_addtime': '${row['insert_dt_addtime'] ?? ''}',
    'update_dt': '${row['update_dt'] ?? ''}',
    'update_dt_addtime': '${row['update_dt_addtime'] ?? ''}',
    'file_yn': '${row['file_yn'] ?? ''}',
  };
  return sha256.convert(utf8.encode(jsonEncode(canonical))).toString();
}

/// The board supplies date-only *_dt and, when available, *_dt_addtime in KST.
DateTime? freeboardDate(Map<String, dynamic> row, String field) {
  for (final key in ['${field}_addtime', field]) {
    final value = '${row[key] ?? ''}'.trim();
    final parsed = campusDate(RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(value)
        ? '$value 00:00' : value);
    if (parsed != null) return parsed;
  }
  return null;
}

/// Filter for only public, nondeleted, and nondraft posts.
bool isPublicFreeboardPost(Map<String, dynamic> row) {
  if (row['delete_yn'] == 'Y' || row['complete_delete_yn'] == 'Y') return false;
  if (row['temp_save_yn'] == 'Y') return false;
  if (row['open_yn'] == 'N') return false;
  return true;
}

String freeboardAttachmentId(String courseKey, CampusMedia media) =>
    sha256.convert(utf8.encode('$courseKey|${media.identity}')).toString();

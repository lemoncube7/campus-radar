import 'dart:async';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/campus/freeboard_models.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/campus/media_cache.dart';

/// Service for collecting and synchronizing course freeboard posts.
/// Preserves course context, limits concurrent requests, reuses unchanged details,
/// and retains previous per-course data on partial failure.
class FreeboardService {
  /// Opt-in export preparation: bodies, and (with [cache]) every missing attachment.
  static Future<Set<String>> prepareExportBodies(Store store, CampusClient client,
      List<Map<String, dynamic>> courses, {int maxDetails = 100,
      Future<void> Function()? verifyScope, MediaCache? cache}) async {
    var remaining = maxDetails;
    final completed = <String>{};
    for (final course in courses) {
      await verifyScope?.call();
      final key = '${course['course_id']}:${course['class_no']}';
      final old = await store.freeboardPosts(key);
      final posts = await client.fetchFreeboardPosts(course,
          courseName: '${course['course_nm'] ?? ''}',
          previous: {for (final post in old) post.key: post});
      await verifyScope?.call();
      await store.replaceCourseFreeboardPosts(key, posts);
      var complete = true;
      for (final post in posts.where((p) => !p.bodyFetched)) {
        await verifyScope?.call();
        if (remaining <= 0) {
          complete = false;
          break; // Still fetch and save the remaining courses' lists.
        }
        remaining--;
        try {
          final detail = await client.fetchFreeboardDetail(post, courseSessionReady: true);
          await verifyScope?.call();
          await store.saveFreeboardPost(detail);
        } catch (e) {
          complete = false;
          await store.log('sync', '자유게시판 내보내기 본문 준비 실패',
              withCause('글 본문을 읽지 못해 미수집으로 표시해요. 첨부 원본은 받지 않아요.', e));
        }
      }
      if (cache != null) {
        await downloadMissingAttachments(store, client, cache,
            await store.freeboardPosts(key), verifyScope: verifyScope);
      }
      if (complete) completed.add(key);
    }
    return completed;
  }
  /// Downloads every freeboard attachment that is not in the device cache yet, one at a
  /// time (school requests stay sequential). Already cached files are not requested again.
  /// Failures are logged and skipped. Returns how many files were downloaded.
  static Future<int> downloadMissingAttachments(Store store, CampusClient client,
      MediaCache cache, Iterable<CampusFreeboardPost> posts,
      {Future<void> Function()? verifyScope}) async {
    var downloaded = 0;
    for (final post in posts) {
      for (final media in post.media) {
        if (!media.supported) continue;
        if (await cache.local(media) != null) continue;
        await verifyScope?.call();
        try {
          await cache.fetch(client, media);
          downloaded++;
        } catch (e) {
          await store.log('sync', '자유게시판 첨부 받기 실패',
              withCause('${media.name}을(를) 받지 못했어요. 다음 확인 때 다시 받아요.', e));
        }
      }
    }
    return downloaded;
  }

  /// Fetches and saves the freeboard posts for a single course.
  /// Reuses unchanged details from previous stored posts.
  static Future<List<CampusFreeboardPost>> syncCourseFreeboard(
    Store store,
    CampusClient client,
    Map<String, dynamic> courseContext, {
    String courseName = '',
  }) async {
    final courseId = '${courseContext['course_id'] ?? ''}';
    final classNo = '${courseContext['class_no'] ?? ''}';
    final courseKey = '$courseId:$classNo';

    final previousList = await store.freeboardPosts(courseKey);
    final previousMap = {for (final p in previousList) p.key: p};

    final freshPosts = await client.fetchFreeboardPosts(
      courseContext,
      courseName: courseName,
      previous: previousMap,
    );

    await store.replaceCourseFreeboardPosts(courseKey, freshPosts);
    return freshPosts;
  }

  /// Synchronizes freeboard posts across multiple courses with limited concurrency.
  /// If a course fails to load, its previously stored posts are retained (partial failure resilience).
  static Future<Map<String, List<CampusFreeboardPost>>> syncAllCourseFreeboards(
    Store store,
    CampusClient client,
    List<Map<String, dynamic>> courses, {
    int concurrency = 2,
  }) async {
    final results = <String, List<CampusFreeboardPost>>{};
    if (courses.isEmpty) return results;

    var index = 0;
    Future<void> worker() async {
      while (true) {
        final current = index++;
        if (current >= courses.length) break;
        final c = courses[current];
        final courseId = '${c['course_id'] ?? ''}';
        final classNo = '${c['class_no'] ?? ''}';
        final courseKey = '$courseId:$classNo';
        final courseName = '${c['course_nm'] ?? ''}';

        try {
          final posts = await syncCourseFreeboard(
            store,
            client,
            c,
            courseName: courseName,
          );
          results[courseKey] = posts;
        } catch (e) {
          // On partial failure, retain previous per-course data from store
          results[courseKey] = await store.freeboardPosts(courseKey);
          await store.log(
            'sync',
            '자유게시판 수집 일부 실패',
            withCause('${courseName.isEmpty ? courseKey : courseName} 자유게시판 수집 중 오류가 발생하여 기존 저장본을 유지해요.', e),
          );
        }
      }
    }

    // Course selection mutates the shared school session. Serialize courses
    // until independent sessions are available, even if callers ask for more.
    final workerCount = 1;
    final workers = List.generate(workerCount, (_) => worker());
    await Future.wait(workers);
    return results;
  }
}

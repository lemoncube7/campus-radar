import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_media.dart';
import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:campus_radar/campus/learning_resources.dart';

String cloudId(String value) => sha256.convert(utf8.encode(value)).toString();

class StudyMaterial {
  final String id, sourceId, sourceType, title, course, body, externalUrl;
  final CampusMedia? media;
  final DateTime? date;
  const StudyMaterial({
    required this.id,
    required this.sourceId,
    required this.sourceType,
    required this.title,
    required this.course,
    this.body = '',
    this.externalUrl = '',
    this.media,
    this.date,
  });
  String get name =>
      media?.name ?? (externalUrl.isNotEmpty ? '외부 링크' : '본문.txt');
  Map<String, dynamic> toCloudJson() => {
    'id': id,
    'sourceId': sourceId,
    'sourceType': sourceType,
    'alias': courseLabel(course),
    'title': title.length > 600 ? title.substring(0, 600) : title,
    'course': course.length > 160 ? course.substring(0, 160) : course,
    'name': name.length > 300 ? name.substring(0, 300) : name,
    'size': media?.size,
    if (externalUrl.isNotEmpty)
      'externalUrl': safeExternalLink(externalUrl, cloud: true),
  };
}

Future<List<StudyMaterial>> studyMaterials(Store store, {DateTime? now}) async {
  final rows = <StudyMaterial>[];
  final hidden = await store.excluded(includeNotTasks: false);
  final at = now ?? DateTime.now();
  void add(
    String key,
    String type,
    String title,
    String course,
    String body,
    List<CampusMedia> media,
    String link, {
    DateTime? date,
  }
  ) {
    final source = cloudId(key);
    if (body.trim().isNotEmpty) {
      rows.add(
        StudyMaterial(
          id: cloudId('$key:body'),
          sourceId: source,
          sourceType: type,
          title: title,
          course: course,
          body: body,
          date: date,
        ),
      );
    }
    for (final m in media) {
      rows.add(
        StudyMaterial(
          id: cloudId('$key:${m.identity}'),
          sourceId: source,
          sourceType: type,
          title: title,
          course: course,
          media: m,
          date: date,
        ),
      );
    }
    if (link.isNotEmpty) {
      rows.add(
        StudyMaterial(
          id: cloudId('$key:link'),
          sourceId: source,
          sourceType: type,
          title: title,
          course: course,
          externalUrl: link,
          date: date,
        ),
      );
    }
  }

  for (final i in await store.items()) {
    if (!const {'LR', 'LV', 'LS'}.contains(i.type) ||
        !i.availableAt(at) ||
        hidden.contains(i.key)) {
      continue;
    }
    add(i.key, i.type, i.title, i.course, i.body, i.media, i.externalUrl, date: i.startsAt ?? i.due);
  }
  for (final n in await store.notices()) {
    add('NT:${n.id}', 'NT', n.title, n.course, n.body, n.media, '', date: n.published);
  }
  final seen = <String>{};
  return rows.where((r) => seen.add(r.id)).toList();
}

/// Rows for the materials list: one card per file, with the source's body text
/// and external link folded into it instead of showing as separate cards.
/// A source with no files becomes a single card holding both body and link.
/// [studyMaterials] keeps the split rows because Drive export relies on them.
List<StudyMaterial> mergedStudyMaterials(List<StudyMaterial> rows) {
  final groups = <String, List<StudyMaterial>>{};
  for (final r in rows) {
    (groups[r.sourceId] ??= []).add(r);
  }
  final out = <StudyMaterial>[];
  for (final g in groups.values) {
    final body = g
        .firstWhere((r) => r.body.trim().isNotEmpty, orElse: () => g.first)
        .body;
    final link = g
        .firstWhere((r) => r.externalUrl.isNotEmpty, orElse: () => g.first)
        .externalUrl;
    final files = g.where((r) => r.media != null).toList();
    StudyMaterial merged(StudyMaterial base, CampusMedia? media) =>
        StudyMaterial(
          id: base.id,
          sourceId: base.sourceId,
          sourceType: base.sourceType,
          title: base.title,
          course: base.course,
          body: body,
          externalUrl: media != null && _sameTarget(link, media) ? '' : link,
          media: media,
          date: base.date,
        );
    if (files.isEmpty) {
      out.add(merged(g.first, null));
    } else {
      for (final f in files) {
        out.add(merged(f, f.media));
      }
    }
  }
  return out;
}

bool _sameTarget(String link, CampusMedia media) {
  if (link.isEmpty) return false;
  if (link == media.url) return true;
  final path = Uri.tryParse(link)?.pathSegments;
  final last = path == null || path.isEmpty ? '' : path.last;
  return last.isNotEmpty && last == media.name;
}

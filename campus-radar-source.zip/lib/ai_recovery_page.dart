import 'navigation_contract.dart';
import 'ui_formatters.dart';
import 'calendar_draft_page.dart';
import 'ai_state_repository.dart';
import 'ai_state_models.dart';
import 'ai_protocol.dart';
import 'notice_ai_service.dart';
import 'app_storage.dart';
import 'app_credentials.dart';
import 'course_labels.dart';
import 'campus_models.dart';
import 'dart:convert';
import 'ai_timetable.dart';
import 'package:flutter/material.dart';
import 'ai_recovery.dart';

class AiRecoveryPage extends StatefulWidget {
  final CampusNotice notice;
  final Map<String, dynamic> job;
  const AiRecoveryPage({super.key, required this.notice, required this.job});
  @override
  State<AiRecoveryPage> createState() => _AiRecoveryState();
}

class _AiRecoveryState extends State<AiRecoveryPage> {
  late CampusNotice notice = widget.notice;
  late Map<String, dynamic> job = {...widget.job};
  RecoveryContext data = const RecoveryContext();
  bool loading = true,
      busy = false,
      withNotices = false,
      withItems = false,
      withPlan = false;
  String? message;
  String? diagnostic;
  Map<String, dynamic> timetable = {};
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final s = await Store.open();
    try {
      final current =
          (await s.notices()).where((n) => n.id == notice.id).firstOrNull ??
          notice;
      final context = await recoveryContext(s, current);
      final savedDiagnostic = await s.meta('aiDiagnostic:${notice.id}');
      final classContext = await aiTimetableContext(s, notice: current);
      if (mounted) {
        setState(() {
          notice = current;
          data = context;
          diagnostic = savedDiagnostic;
          timetable = classContext;
          loading = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          loading = false;
          message = '추가 자료를 읽지 못했어요. 원문 확인과 직접 일정 추가는 사용할 수 있어요.';
        });
      }
    } finally {
      await s.db.close();
    }
  }

  String get extra => data.selected(
    includeNotices: withNotices,
    includeItems: withItems,
    includePlan: withPlan,
  );
  bool get hasExtra =>
      withNotices && data.notices.isNotEmpty ||
      withItems && data.items.isNotEmpty ||
      withPlan && data.syllabus.isNotEmpty;

  Future<void> retry() async {
    if (busy) return;
    final account = await credentials.read(key: 'id');
    setState(() {
      busy = true;
      message = null;
    });
    final s = await Store.open();
    try {
      final events = await NoticeAi.analyze(
        notice,
        force: true,
        supplemental: hasExtra ? extra : '',
        repairHint: '${job['error'] ?? ''} ${job['errorDetail'] ?? ''}',
      );
      if (await credentials.read(key: 'id') != account) {
        throw const AiFailure('계정이 변경되어 결과 반영을 중단했어요.');
      }
      await AiStateRepository(s).saveJob(
        notice.id,
        AiJob.fromJson({
          'status': events.isEmpty ? 'empty' : 'done',
          'count': events.length,
          'title': notice.title,
          'fingerprint': noticeFingerprint(notice),
          'checked': DateTime.now().toUtc().toIso8601String(),
          'attempts': 0,
          'usedExtraContext': hasExtra,
        }),
      );
      await s.log(
        'ai',
        '사용자 요청 재분석 완료',
        hasExtra ? '사용자가 선택한 같은 과목 참고 자료 사용' : '대상 공지와 이전 실패 이유 사용',
      );
      if (!mounted) return;
      setState(() {
        job = {'status': events.isEmpty ? 'empty' : 'done'};
        message = events.isEmpty
            ? '분석을 마쳤어요. 대상 공지에서 추가할 일정을 찾지 못했어요. 필요하면 직접 추가할 수 있어요.'
            : '확인할 일정 ${events.length}개를 찾았어요. 일정함에서 날짜와 근거를 확인해 주세요.';
      });
    } catch (e) {
      if (e is AiFailure && e.code == 'busy') {
        if (mounted) {
          setState(
            () =>
                message = '다른 AI 요청이 처리 중이에요. 완료된 뒤 시도해 주세요. 기존 작업 상태는 유지했어요.',
          );
        }
        return;
      }
      if (await credentials.read(key: 'id') == account) {
        final next = {
          ...job,
          'status': 'failed',
          'title': notice.title,
          'error': userError(e),
          'errorCode': e is AiFailure ? e.code : 'network',
          'validationVersion': aiValidationVersion,
          'errorDetail': e is AiFailure ? e.detail : '',
          'checked': DateTime.now().toUtc().toIso8601String(),
          'fingerprint': noticeFingerprint(notice),
        };
        await AiStateRepository(s).saveJob(notice.id, AiJob.fromJson(next));
        if (mounted) {
          setState(() {
            job = next;
            message = '이번 재분석도 완료하지 못했어요. 아래 오류를 확인하거나 직접 추가·분석 제외를 선택해 주세요.';
          });
        }
      } else if (mounted) {
        setState(() => message = '계정이 변경되어 작업을 중단했어요.');
      }
    } finally {
      final savedDiagnostic = await s.meta('aiDiagnostic:${notice.id}');
      if (mounted) setState(() => diagnostic = savedDiagnostic);
      await s.db.close();
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> manual() async {
    final candidate = ScheduleCandidate(
      title: notice.title,
      date: '',
      time: '',
      action: 'add',
      evidence: notice.title,
      uncertainty: '사용자가 원문을 확인하고 직접 입력한 일정',
      category: 'other',
    );
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => CalendarDraftPage(
          itemKey: candidateKey(notice, candidate),
          courseName: notice.course,
          title: '[${courseLabel(notice.course)}] ${notice.title}',
          description: '공지에서 직접 입력한 일정\n${notice.title}\n${notice.body}',
          allDay: true,
          closeAfterSave: true,
          saveToCalendar: false,
        ),
      ),
    );
    if (saved != true) return;
    final s = await Store.open();
    try {
      await rememberCandidates(s, notice, [candidate]);
      await AiStateRepository(s).saveJob(
        notice.id,
        AiJob.fromJson({
          ...job,
          'status': 'manual',
          'fingerprint': noticeFingerprint(notice),
          'title': notice.title,
        }),
      );
      if (mounted) {
        setState(() {
          job = {...job, 'status': 'manual'};
          message = '직접 입력한 일정을 앱 일정함에 추가했어요.';
        });
      }
    } finally {
      await s.db.close();
    }
  }

  Future<void> exclude() async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('이 공지의 분석을 제외할까요?'),
        content: const Text(
          '원문 공지는 유지하고, 같은 내용의 자동 분석과 실패 경고에서 제외해요. 기록에서 다시 분석할 수 있어요.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('분석 제외'),
          ),
        ],
      ),
    );
    if (yes != true) return;
    final s = await Store.open();
    try {
      await excludeNoticeAnalysis(s, notice);
    } finally {
      await s.db.close();
    }
    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final code = recoveryCode(job);
    return Scaffold(
      appBar: AppBar(title: const Text('분석 문제 해결')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            courseLabel(notice.course),
            style: Theme.of(context).textTheme.labelLarge,
          ),
          Text(notice.title, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 16),
          if (job['status'] == 'failed')
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '왜 실패했나요?',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 8),
                    Text(recoveryExplanation(code)),
                    const SizedBox(height: 12),
                    const Text('실제 오류'),
                    SelectableText('${job['error'] ?? '상세 오류 기록 없음'}'),
                    if ('${job['errorDetail'] ?? ''}'.isNotEmpty)
                      Text('${job['errorDetail']}'),
                    if (job['checked'] != null)
                      Text(
                        '마지막 시도: ${DateTime.tryParse('${job['checked']}') == null ? '시각 미확인' : koreanTime(DateTime.parse('${job['checked']}'))}',
                      ),
                  ],
                ),
              ),
            ),
          if (message != null)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Text(message!),
            ),
          if (diagnostic != null)
            ExpansionTile(
              title: const Text('기기에 저장된 검증 기록'),
              subtitle: const Text('실패한 응답·원문 문단·오류 · 외부로 자동 전송하지 않아요'),
              children: [
                SelectableText(
                  const JsonEncoder.withIndent(
                    '  ',
                  ).convert(jsonDecode(diagnostic!)),
                ),
              ],
            ),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              OutlinedButton.icon(
                onPressed: busy
                    ? null
                    : () async {
                        await navigateTo(
                          context,
                          NoticeDestination(notice: notice),
                        );
                        await load();
                      },
                icon: const Icon(Icons.article_outlined),
                label: const Text('원문 확인'),
              ),
              FilledButton.icon(
                onPressed: busy ? null : manual,
                icon: const Icon(Icons.edit_calendar_outlined),
                label: const Text('직접 일정 추가'),
              ),
              TextButton(
                onPressed: busy ? null : exclude,
                child: const Text('이 공지 분석 제외'),
              ),
            ],
          ),
          if (code == 'credentials' || code == 'quota' || code == 'request')
            TextButton(
              onPressed: () => navigateTo(context, AiSettingsDestination()),
              child: Text(code == 'quota' ? 'AI 설정·사용량 확인' : 'API 키 설정'),
            ),
          const Divider(height: 32),
          Text(
            '관련 자료와 함께 다시 분석',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 8),
          const Text(
            '선택한 같은 과목의 저장 자료만 Gemini에 추가 전송해요. 다른 공지 최대 4개, 과제·콘텐츠 최대 6개, 실제 강의계획서 본문 최대 6,000자예요. 자료는 일부이거나 오래됐을 수 있어요. 추가 자료가 있어도 분석 성공을 보장하지 않아요.',
          ),
          if (loading) const LinearProgressIndicator(),
          CheckboxListTile(
            contentPadding: EdgeInsets.zero,
            title: Text('다른 공지 ${data.notices.length}개'),
            subtitle: data.notices.isEmpty
                ? const Text('저장된 같은 과목 공지가 없어요.')
                : Text(
                    data.notices.map((n) => n['title']).join(' · '),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
            value: withNotices,
            onChanged: busy || loading || data.notices.isEmpty
                ? null
                : (v) => setState(() => withNotices = v!),
          ),
          CheckboxListTile(
            contentPadding: EdgeInsets.zero,
            title: Text('과제·콘텐츠 ${data.items.length}개'),
            subtitle: data.items.isEmpty
                ? const Text('공개된 같은 과목 자료가 없어요.')
                : Text(
                    data.items.map((i) => i['title']).join(' · '),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
            value: withItems,
            onChanged: busy || loading || data.items.isEmpty
                ? null
                : (v) => setState(() => withItems = v!),
          ),
          CheckboxListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(
              data.syllabus.isEmpty
                  ? '저장된 실제 강의계획서 없음'
                  : '강의계획서 ${data.syllabus.length}자',
            ),
            subtitle: const Text('같은 과목의 바로가기에서 수집한 실제 계획서 본문'),
            value: withPlan,
            onChanged: busy || loading || data.syllabus.isEmpty
                ? null
                : (v) => setState(() => withPlan = v!),
          ),
          if (data.syllabus.isEmpty)
            TextButton(
              onPressed: busy
                  ? null
                  : () async {
                      await navigateTo(
                        context,
                        CourseDestination(
                          course: {
                            ...notice.context,
                            'course_nm': notice.course,
                          },
                        ),
                      );
                      await load();
                    },
              child: const Text('과목에서 강의계획서 불러오기'),
            ),
          ExpansionTile(
            title: const Text('실제로 보낼 자료 미리보기'),
            children: [
              SelectableText(
                const JsonEncoder.withIndent('  ').convert(
                  aiRequest(
                    notice,
                    timetable: timetable,
                    supplemental: hasExtra ? extra : '',
                    repairHint:
                        '${job['error'] ?? ''} ${job['errorDetail'] ?? ''}',
                  )['contents'],
                ),
              ),
            ],
          ),
          const Text(
            '계정·쿠키·API 키·첨부파일은 참고 자료에 포함하지 않아요. 추가 자료는 해석을 돕고, 일정의 인용 근거는 대상 공지에서 검증해요.',
          ),
          Text(
            '같은 과목의 저장 시간표 ${(timetable['slots'] as List? ?? []).length}칸 참고 · 공지 게시 시각 기준으로 다음 수업을 추정해요.',
          ),
          TextButton(
            onPressed: busy
                ? null
                : () async {
                    await navigateTo(context, TimetableDestination());
                    await load();
                  },
            child: const Text('시간표 확인·수정'),
          ),
          const SizedBox(height: 12),
          if (!notice.bodyFetched ||
              (notice.body.trim().isEmpty && notice.title.trim().isEmpty))
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Text(
                '원문 확인에서 공지 본문을 불러온 뒤 재분석할 수 있어요. 직접 일정 추가·분석 제외는 지금도 사용할 수 있어요.',
              ),
            ),
          FilledButton(
            onPressed:
                busy ||
                    loading ||
                    code == 'length' ||
                    !notice.bodyFetched ||
                    (notice.body.trim().isEmpty && notice.title.trim().isEmpty)
                ? null
                : retry,
            child: Text(
              busy
                  ? '재분석 중…'
                  : hasExtra
                  ? '선택 자료를 보내고 재분석'
                  : '실패 이유를 포함해 재분석',
            ),
          ),
          if (busy) const LinearProgressIndicator(),
          TextButton(
            onPressed: busy
                ? null
                : () => navigateTo(context, AiInboxDestination()),
            child: const Text('일정함 열기'),
          ),
        ],
      ),
    );
  }
}

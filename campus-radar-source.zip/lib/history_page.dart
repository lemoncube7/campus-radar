import 'task_presentation.dart';
import 'background_status_page.dart';
import 'app_storage.dart';
import 'ui_refresh.dart';
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';

class HistoryPage extends StatefulWidget {
  final bool notificationsOnly;
  const HistoryPage({super.key, required this.notificationsOnly});
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  List<Map<String, Object?>> rows = [];
  bool loading = true;
  String? error;
  String query = '', category = 'all';
  bool issuesOnly = false;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final store = await Store.open();
      try {
        final data = await store.logs(
          widget.notificationsOnly ? 'notification' : 'all',
        );
        if (mounted) {
          setState(() {
            rows = data;
            error = null;
          });
        }
      } finally {
        await store.db.close();
      }
    } catch (_) {
      if (mounted) setState(() => error = '기록을 읽지 못했습니다. 다시 시도해 주세요.');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final visible = rows
        .where(
          (r) =>
              (category == 'all' || r['kind'] == category) &&
              (!issuesOnly ||
                  RegExp(
                    '실패|오류|거절',
                  ).hasMatch('${r['title']} ${r['detail']}')) &&
              '${r['title']} ${r['detail']}'.toLowerCase().contains(
                query.toLowerCase(),
              ),
        )
        .toList();
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.notificationsOnly ? '알림 로그' : '활동 로그'),
        actions: [
          if (!widget.notificationsOnly && Platform.isAndroid)
            IconButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const BackgroundStatusPage()),
              ),
              icon: const Icon(Icons.troubleshoot),
              tooltip: '백그라운드 상태',
            ),
          IconButton(
            onPressed: load,
            icon: const Icon(Icons.refresh),
            tooltip: '기록 새로고침',
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.notificationsOnly
                      ? '예약·취소·발송 요청·클릭 기록입니다. 발송 요청은 실제 화면 표시를 보장하지 않습니다.'
                      : '수집한 과제·콘텐츠·공지와 수집 성공·실패 기록입니다.',
                ),
                const Text(
                  '기기에 최근 2,000건을 보관합니다. 수집 로그에는 업데이트와 배터리 설정 변경도 기록됩니다.',
                  style: TextStyle(fontSize: 12),
                ),
                if (!widget.notificationsOnly)
                  Wrap(
                    spacing: 6,
                    children: [
                      for (final c in {
                        'all': '전체',
                        'sync': '수집',
                        'notification': '알림',
                        'ai': 'AI',
                        'calendar': '캘린더',
                        'system': '앱·업데이트',
                        'received': '수신',
                      }.entries)
                        ChoiceChip(
                          label: Text(c.value),
                          selected: category == c.key,
                          onSelected: (_) => setState(() => category = c.key),
                        ),
                    ],
                  ),
                FilterChip(
                  label: const Text('실패·오류 문구'),
                  selected: issuesOnly,
                  onSelected: (v) => setState(() => issuesOnly = v),
                ),
                const SizedBox(height: 8),
                TextField(
                  decoration: const InputDecoration(
                    labelText: '기록 검색',
                    prefixIcon: Icon(Icons.search),
                  ),
                  onChanged: (v) => setState(() => query = v),
                ),
              ],
            ),
          ),
          if (loading) const LinearProgressIndicator(),
          if (error != null)
            Padding(padding: const EdgeInsets.all(16), child: Text(error!)),
          Expanded(
            child: RefreshIndicator(
              onRefresh: load,
              child: ListView.builder(
                physics: const AlwaysScrollableScrollPhysics(),
                itemCount: visible.isEmpty ? 1 : visible.length,
                itemBuilder: (context, index) {
                  if (visible.isEmpty) {
                    return const Padding(
                      padding: EdgeInsets.all(24),
                      child: Text('표시할 기록이 없습니다.'),
                    );
                  }
                  final row = visible[index];
                  final day = formatDate(
                    DateTime.parse(row['at'] as String),
                  ).split(' ').first;
                  final previous = index == 0
                      ? ''
                      : formatDate(
                          DateTime.parse(visible[index - 1]['at'] as String),
                        ).split(' ').first;
                  final issue = RegExp(
                    '실패|오류|거절',
                  ).hasMatch('${row['title']} ${row['detail']}');
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      if (day != previous) SectionHeading(day),
                      Card(
                        margin: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 4,
                        ),
                        child: ExpansionTile(
                          leading: Icon(
                            issue
                                ? Icons.error_outline
                                : row['kind'] == 'notification'
                                ? Icons.notifications_outlined
                                : Icons.history,
                            color: issue
                                ? Theme.of(context).colorScheme.error
                                : null,
                          ),
                          title: Text(
                            '${row['title']}',
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          subtitle: Text(
                            formatDate(DateTime.parse(row['at'] as String)),
                          ),
                          childrenPadding: const EdgeInsets.fromLTRB(
                            16,
                            0,
                            16,
                            16,
                          ),
                          expandedCrossAxisAlignment: CrossAxisAlignment.start,
                          children: [SelectableText('${row['detail']}')],
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

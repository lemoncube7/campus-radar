import 'app_storage.dart';
import 'campus_models.dart';

class DashboardSnapshot {
  final List<CampusItem> items;
  final List<CampusNotice> notices;
  final Set<String> excluded;
  final String? lastSuccess, lastError;
  const DashboardSnapshot(
    this.items,
    this.notices,
    this.excluded,
    this.lastSuccess,
    this.lastError,
  );
}

/// Read-only local view. Authentication and remote synchronization stay separate.
class DashboardRepository {
  final Store store;
  const DashboardRepository(this.store);
  Future<DashboardSnapshot> read() async => DashboardSnapshot(
    await store.items(),
    await store.notices(),
    await store.excluded(),
    await store.meta('lastSuccess'),
    await store.meta('lastError'),
  );
}

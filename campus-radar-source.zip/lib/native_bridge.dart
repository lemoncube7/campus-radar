import 'native_contract.dart';
import 'dart:io';
import 'package:flutter/services.dart';

Future<dynamic> Function(String, dynamic)? desktopMethodHandler;
Future<void> Function()? iosRefreshHandler;
Future<void> Function()? iosMidnightTestHandler;

class RadarMethodChannel extends MethodChannel {
  const RadarMethodChannel() : super('campus_radar/native');
  Future<T?> invokeNative<T>(NativeMethod method, [dynamic arguments]) =>
      invokeMethod<T>(method.name, arguments);
  Future<Map<K, V>?> invokeNativeMap<K, V>(
    NativeMethod method, [
    dynamic arguments,
  ]) => invokeMapMethod<K, V>(method.name, arguments);
  Future<List<T>?> invokeNativeList<T>(
    NativeMethod method, [
    dynamic arguments,
  ]) => invokeListMethod<T>(method.name, arguments);
  @override
  Future<T?> invokeMethod<T>(String method, [dynamic arguments]) async {
    if (Platform.isWindows && desktopMethodHandler != null) {
      return (await desktopMethodHandler!(method, arguments)) as T?;
    }
    if (Platform.isIOS && method == 'testMidnightSummary') {
      await iosMidnightTestHandler?.call();
      return null;
    }
    if (Platform.isIOS && method == 'refreshWidget') {
      await iosRefreshHandler?.call();
      return null;
    }
    final value = await super.invokeMethod<T>(method, arguments);
    if (Platform.isIOS && method == 'setTimetableSettings') {
      await iosRefreshHandler?.call();
    }
    return value;
  }
}

const bridge = RadarMethodChannel();

import 'package:flutter/material.dart';
import 'ios_features.dart';
import 'native_bridge.dart';

class IosWidgetSettings extends StatefulWidget {
  const IosWidgetSettings({super.key});
  @override
  State<IosWidgetSettings> createState() => _IosWidgetSettingsState();
}

class _IosWidgetSettingsState extends State<IosWidgetSettings> {
  String status = '위젯 확장 설치와 공유 저장소 접근을 확인해 주세요.';
  bool busy = false;
  Future<void> refresh() async {
    setState(() => busy = true);
    try {
      await updateIosFeatures();
      final result = await bridge.invokeMapMethod<String, dynamic>(
        'widgetStatus',
      );
      if (mounted) {
        setState(
          () => status = result?['available'] == true
              ? '표시 정보를 갱신했어요. 실제 위젯 갱신 시각은 iOS가 결정합니다.'
              : '위젯 공유 저장소를 사용할 수 없어요. AltStore 설치 시 위젯 확장을 유지했는지 확인해 주세요.',
        );
      }
    } catch (_) {
      if (mounted) {
        setState(() => status = '표시 정보 갱신에 실패했어요. 수집·알림·서명 상태를 확인해 주세요.');
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('iPhone 위젯')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('홈 화면: 길게 누르기 → 위젯 추가 → 캠퍼스레이더에서 할 일 또는 시간표를 선택하세요.'),
        const SizedBox(height: 16),
        const Text(
          '잠금화면: 길게 누르기 → 사용자화 → 위젯 추가에서 다음 수업·할 일 개수를 선택하세요. 위젯 확장은 iOS 16 이상입니다.',
        ),
        const SizedBox(height: 16),
        const Text(
          'Android의 전체 화면·자유 위치 카드와는 표시 방식이 다릅니다. 위젯은 마지막 수집 정보이며 앱 실행·수집·시간표 변경 때 갱신을 요청합니다. 시스템이 갱신을 늦출 수 있습니다.',
        ),
        const SizedBox(height: 16),
        const Text(
          '위젯 확장은 AltStore의 App ID를 추가로 사용합니다. 확장을 제거하고 설치하면 위젯이 나타나지 않습니다. 잠금화면 표시 내용은 기기의 개인정보 보호 설정도 확인하세요.',
        ),
        const SizedBox(height: 16),
        Text(status),
        FilledButton(
          onPressed: busy ? null : refresh,
          child: const Text('표시 정보 갱신·접근 확인'),
        ),
      ],
    ),
  );
}

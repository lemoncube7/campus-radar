import 'dart:convert';
import 'app_storage.dart';
import 'ai_state_models.dart';

/// Owns the legacy wire keys. Callers use typed state while stored JSON remains
/// compatible with released versions and preserves unknown fields.
class AiStateRepository {
  final Store store;
  const AiStateRepository(this.store);
  Future<AiJob> job(String noticeId) async =>
      AiJob.decode(await store.meta('aiQueue:$noticeId'));
  Future<void> saveJob(String noticeId, AiJob job) =>
      store.setMeta('aiQueue:$noticeId', jsonEncode(job.toJson()));
  Future<ConfirmedSchedule> schedule(String key) async =>
      ConfirmedSchedule.decode(await store.meta('aiState:$key'));
  Future<void> saveSchedule(String key, ConfirmedSchedule state) =>
      store.setMeta('aiState:$key', jsonEncode(state.toJson()));
  Future<bool> hasActiveJobs() async {
    final rows = await store.db.query(
      'meta',
      where: 'id LIKE ?',
      whereArgs: ['aiQueue:%'],
    );
    return rows.any((r) => AiJob.decode(r['value'] as String).isActive);
  }
}

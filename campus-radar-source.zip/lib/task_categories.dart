import 'campus_models.dart';

bool waitingAssignment(CampusItem i, DateTime now) => i.waitingAt(now);

bool categoryMatches(
  CampusItem i,
  DateTime now,
  Set<String> hidden, {
  bool waiting = false,
  bool completed = false,
  bool hiddenOnly = false,
  bool showHidden = false,
  bool showDone = false,
}) {
  if (hiddenOnly) return hidden.contains(i.key);
  if (hidden.contains(i.key)) return showHidden;
  if (waiting) return waitingAssignment(i, now);
  if (!i.availableAt(now)) return false;
  if (completed) return i.type == 'LR' && i.done;
  return showDone || !i.done;
}

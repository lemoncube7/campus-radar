import 'calendar_window.dart';
import 'native_contract.dart';
import 'ui_formatters.dart';
import 'calendar_settings_page.dart';
import 'ai_state_repository.dart';
import 'ai_state_models.dart';
import 'ai_protocol.dart';
import 'app_storage.dart';
import 'native_bridge.dart';
import 'course_labels.dart';
import 'ui_refresh.dart';
import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';

class CalendarDraftPage extends StatefulWidget {
  final String itemKey, title, description;
  final DateTime? start, end;
  final bool allDay, deadline, closeAfterSave, saveToCalendar;
  final String? deadlineCourse, courseName;
  const CalendarDraftPage({
    super.key,
    required this.itemKey,
    required this.title,
    required this.description,
    this.start,
    this.end,
    this.allDay = false,
    this.deadline = false,
    this.closeAfterSave = false,
    this.saveToCalendar = true,
    this.deadlineCourse,
    this.courseName,
  });
  @override
  State<CalendarDraftPage> createState() => _CalendarDraftState();
}

class _CalendarDraftState extends State<CalendarDraftPage> {
  late final TextEditingController title = TextEditingController(
    text: widget.courseName == null
        ? widget.title
        : courseEventTitle(widget.title, widget.courseName!),
  );
  late DateTime? day = widget.start == null
      ? null
      : widget.allDay
      ? widget.start!.toUtc()
      : widget.start!.toUtc().add(const Duration(hours: 9));
  late TimeOfDay time = day == null
      ? const TimeOfDay(hour: 9, minute: 0)
      : TimeOfDay(hour: day!.hour, minute: day!.minute);
  late bool allDay = widget.allDay;
  bool busy = false;
  String? message;
  Future<void> save({bool calendar = true}) async {
    if (day == null || title.text.trim().isEmpty) {
      setState(() => message = '제목과 날짜를 확인해 주세요.');
      return;
    }
    setState(() => busy = true);
    try {
      if (calendar) {
        final granted = await bridge.invokeNative<bool>(
          NativeMethod.calendarPermission,
        );
        if (granted != true) throw const AiFailure('캘린더 권한이 필요합니다.');
      }
      final start = allDay
          ? DateTime.utc(day!.year, day!.month, day!.day)
          : DateTime.utc(
              day!.year,
              day!.month,
              day!.day,
              time.hour,
              time.minute,
            ).subtract(const Duration(hours: 9));
      final window = calendarWindow(
        start,
        allDay: allDay,
        deadline: widget.deadline,
        end:
            widget.end != null &&
                widget.start != null &&
                allDay == widget.allDay
            ? widget.end!.add(start.difference(widget.start!))
            : null,
      );
      if (calendar) {
        await bridge.invokeNative(NativeMethod.calendarWrite, {
          'key': widget.itemKey,
          'title': widget.deadline && widget.deadlineCourse != null
              ? calendarDeadlineTitle(
                  widget.deadlineCourse!,
                  title.text.trim(),
                  start,
                )
              : widget.courseName == null
              ? title.text.trim()
              : courseEventTitle(title.text.trim(), widget.courseName!),
          'start': window.$1.millisecondsSinceEpoch,
          'end': window.$2.millisecondsSinceEpoch,
          'allDay': allDay,
          'description': widget.description,
        });
      }
      if (widget.itemKey.startsWith('AI:')) {
        final s = await Store.open();
        try {
          final old =
              jsonDecode(await s.meta('aiState:${widget.itemKey}') ?? '{}')
                  as Map;
          final unchanged =
              old['start'] == start.toIso8601String() &&
              old['title'] == title.text.trim() &&
              old['allDay'] == allDay;
          await AiStateRepository(s).saveSchedule(
            widget.itemKey,
            ConfirmedSchedule.fromJson({
              ...old,
              if (widget.courseName != null) 'courseName': widget.courseName,
              if (widget.courseName != null)
                'courseLabel': courseLabel(widget.courseName!),
              'status': 'confirmed',
              'title': title.text.trim(),
              'start': start.toIso8601String(),
              'date': dateText(day!),
              'allDay': allDay,
              'end':
                  widget.end == null ||
                      widget.start == null ||
                      allDay != widget.allDay
                  ? null
                  : window.$2.toUtc().toIso8601String(),
              'deadline': widget.deadline,
              'calendarSent':
                  calendar || unchanged && old['calendarSent'] == true,
            }),
          );
          await s.log(
            'ai',
            'AI 일정 확정',
            calendar
                ? (Platform.isWindows
                      ? '확인한 일정을 .ics 파일로 저장했습니다.'
                      : '확인한 일정을 캘린더에 전송했습니다.')
                : '앱 일정함에 확정했습니다.',
          );
        } finally {
          await s.db.close();
        }
      }
      if (mounted && widget.closeAfterSave) {
        Navigator.pop(context, true);
        return;
      }
      if (mounted) {
        setState(
          () => message = calendar
              ? (Platform.isWindows
                    ? '일정 파일을 저장했습니다. 같은 항목을 다시 저장하면 해당 파일을 갱신합니다.'
                    : '캘린더에 저장했습니다. 같은 항목을 다시 저장하면 연결 일정을 갱신합니다.')
              : '일정함에 확정했습니다. 캘린더에는 전송하지 않았습니다.',
        );
      }
    } catch (e) {
      if (mounted) setState(() => message = userError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    title.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('캘린더 일정 확인')),
    bottomNavigationBar: PinnedAction(
      child: FilledButton(
        onPressed: busy ? null : () => save(calendar: widget.saveToCalendar),
        child: Text(
          busy
              ? '저장 중…'
              : !widget.saveToCalendar
              ? '일정에 추가'
              : Platform.isWindows
              ? '일정 파일 저장'
              : '캘린더에 저장',
        ),
      ),
    ),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        TextField(
          controller: title,
          decoration: const InputDecoration(labelText: '일정 제목'),
        ),
        const SizedBox(height: 16),
        Text(day == null ? '날짜를 선택해 주세요.' : dateText(day!)),
        TextButton(
          onPressed: busy
              ? null
              : () async {
                  final d = await showDatePicker(
                    context: context,
                    initialDate: day ?? DateTime.now(),
                    firstDate: DateTime(2000),
                    lastDate: DateTime(2100),
                  );
                  if (d != null && mounted) setState(() => day = d);
                },
          child: const Text('날짜 선택'),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          value: allDay,
          onChanged: busy ? null : (v) => setState(() => allDay = v),
          title: const Text('종일 일정'),
        ),
        if (!allDay)
          TextButton(
            onPressed: busy
                ? null
                : () async {
                    final t = await showTimePicker(
                      context: context,
                      initialTime: time,
                    );
                    if (t != null && mounted) setState(() => time = t);
                  },
            child: Text(
              '한국 시간 ${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')} · 변경',
            ),
          ),
        Text(
          widget.end != null
              ? '원문에 있는 기간을 유지합니다. 날짜·시각을 변경하면 종료도 같은 만큼 이동합니다.'
              : widget.deadline
              ? '선택 시각을 마감으로 하여 당일 최대 10분 전부터 표시합니다. 23:59 마감은 23:49–23:59입니다. 정각 00:00 마감은 전날 마지막 10분으로 표시합니다.'
              : '시각이 있는 일정은 기본 10분이며 자정을 넘으면 선택 시각 전 10분으로 표시합니다. 제목·날짜·한국 시간을 확인하세요. 과제·콘텐츠로 연결한 일정은 이후 수집한 원래 마감·제목으로 갱신됩니다. AI 일정은 수동 확인한 값을 유지합니다.',
        ),
        const SizedBox(height: 16),
        ExpansionTile(
          title: const Text('근거·원문 내용'),
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: SelectableText(widget.description),
            ),
          ],
        ),
        if (message != null)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(message!),
          ),
        if (widget.itemKey.startsWith('AI:') && widget.saveToCalendar)
          FilledButton.tonal(
            onPressed: busy ? null : () => save(calendar: false),
            child: const Text('일정함에만 확정'),
          ),
        TextButton(
          onPressed: busy
              ? null
              : () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const CalendarSettingsPage(),
                  ),
                ),
          child: const Text('저장할 캘린더 설정'),
        ),
      ],
    ),
  );
}

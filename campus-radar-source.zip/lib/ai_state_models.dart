import 'dart:convert';

enum AiJobStatus {
  pending,
  running,
  done,
  empty,
  failed,
  excluded,
  manual,
  unknown,
}

enum ScheduleDecision { review, confirmed, hold, excluded, unknown }

/// Immutable adapters retain fields written by older and newer app versions.
/// Reading a missing/default value never adds it to the persisted JSON.
class AiJob {
  final Map<String, dynamic> _json;
  AiJob.fromJson(Map json)
    : _json = Map.unmodifiable(Map<String, dynamic>.from(json));
  factory AiJob.decode(String? raw) =>
      AiJob.fromJson(raw == null ? {} : jsonDecode(raw) as Map);
  AiJobStatus get status =>
      AiJobStatus.values.where((s) => s.name == _json['status']).firstOrNull ??
      AiJobStatus.unknown;
  String? get wireStatus => _json['status'] as String?;
  String? get fingerprint => _json['fingerprint'] as String?;
  String? get validationVersion => _json['validationVersion'] as String?;
  String get errorCode => _json['errorCode'] as String? ?? '';
  String get error => _json['error'] as String? ?? '';
  String get errorDetail => _json['errorDetail'] as String? ?? '';
  String get title => _json['title'] as String? ?? '';
  int get attempts => _json['attempts'] as int? ?? 0;
  int get count => _json['count'] as int? ?? 0;
  DateTime? get checked => DateTime.tryParse(_json['checked'] as String? ?? '');
  DateTime? get retryAt => DateTime.tryParse(_json['retryAt'] as String? ?? '');
  bool get isEmpty => _json.isEmpty;
  bool get isActive =>
      status == AiJobStatus.pending || status == AiJobStatus.running;
  bool get isUserDecision =>
      status == AiJobStatus.excluded || status == AiJobStatus.manual;
  bool get isComplete =>
      status == AiJobStatus.done || status == AiJobStatus.empty;
  AiJob withStatus(
    AiJobStatus status, {
    Map<String, dynamic> fields = const {},
  }) {
    if (status == AiJobStatus.unknown) {
      throw ArgumentError.value(status, 'status');
    }
    return AiJob.fromJson({..._json, ...fields, 'status': status.name});
  }

  Map<String, dynamic> toJson() => Map.of(_json);
}

class ConfirmedSchedule {
  final Map<String, dynamic> _json;
  ConfirmedSchedule.fromJson(Map json)
    : _json = Map.unmodifiable(Map<String, dynamic>.from(json));
  factory ConfirmedSchedule.decode(String? raw) =>
      ConfirmedSchedule.fromJson(raw == null ? {} : jsonDecode(raw) as Map);
  ScheduleDecision get decision => _json['status'] == null
      ? ScheduleDecision.review
      : ScheduleDecision.values
                .where((s) => s.name == _json['status'])
                .firstOrNull ??
            ScheduleDecision.unknown;
  bool get isConfirmed => decision == ScheduleDecision.confirmed;
  bool get isExplicitDecision => const {
    ScheduleDecision.confirmed,
    ScheduleDecision.hold,
    ScheduleDecision.excluded,
  }.contains(decision);
  DateTime? get start => DateTime.tryParse(_json['start'] as String? ?? '');
  DateTime? get end => DateTime.tryParse(_json['end'] as String? ?? '');
  bool get calendarSent => _json['calendarSent'] == true;
  ConfirmedSchedule withDecision(ScheduleDecision decision) {
    if (decision == ScheduleDecision.unknown) {
      throw ArgumentError.value(decision, 'decision');
    }
    return ConfirmedSchedule.fromJson({..._json, 'status': decision.name});
  }

  Map<String, dynamic> toJson() => Map.of(_json);
}

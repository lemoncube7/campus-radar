import 'native_contract.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';
import 'app_storage.dart';
import 'app_credentials.dart';
import 'native_bridge.dart';
import 'notification_gateway.dart';
import 'course_labels.dart';
import 'network_resilience.dart';
import 'session_scope.dart';
import 'background_contract.dart';

/// Logout policy has no widget lifecycle or dialog dependencies. Cleanup order
/// and independent failure reporting remain identical to the released behavior.
Future<List<String>> performAccountLogout() async {
  Store? scopeStore;
  final failures = await completeLogout([
    (
      '세션 차단',
      () async {
        ActiveRequests.cancelAll();
        scopeStore = await Store.open();
        await SessionScope.rotate(scopeStore!, blocked: true);
      },
    ),
    (
      '로그인 정보 삭제',
      () async {
        await credentials.deleteAll();
        if (await credentials.read(key: 'id') != null ||
            await credentials.read(key: 'pw') != null ||
            await credentials.read(key: 'geminiApiKey') != null) {
          throw StateError('credential deletion failed');
        }
      },
    ),
    if (Platform.isAndroid)
      ('AI 작업 취소', () => Workmanager().cancelByTag('campus-ai')),
    if (!Platform.isWindows)
      ('수집 작업 취소', () => Workmanager().cancelByUniqueName(periodicTask)),
    if (Platform.isAndroid)
      (
        '진단 작업 취소',
        () => Workmanager().cancelByUniqueName('campus-radar-probe'),
      ),
    if (Platform.isAndroid || Platform.isIOS)
      (
        '캘린더 연결 해제',
        () async {
          await bridge.invokeNative(NativeMethod.calendarUnlink);
        },
      ),
    if (Platform.isAndroid)
      (
        '잠금화면 해제',
        () async {
          await bridge.invokeNative(NativeMethod.lockConfigure, {
            'enabled': false,
            'mode': 'compact',
            'position': 'right',
            'details': false,
          });
        },
      ),
    (
      '첨부 캐시 삭제',
      () async {
        final root = Directory(
          '${(await getTemporaryDirectory()).path}/campus_media',
        );
        if (await root.exists()) await root.delete(recursive: true);
      },
    ),
    ('알림 취소', () => notifications.cancelAll()),
    (
      '웹 로그인 삭제',
      () async {
        await bridge.invokeNative(NativeMethod.clearWebSession);
      },
    ),
    (
      '수집 정보 삭제',
      () async {
        scopeStore ??= await Store.open();
        await scopeStore!.db.transaction((txn) async {
          for (final table in ['items', 'events', 'notices', 'logs']) {
            await txn.delete(table);
          }
          await txn.delete(
            'meta',
            where: 'id NOT IN (?,?)',
            whereArgs: ['sessionEpoch', 'sessionBlocked'],
          );
        });
      },
    ),
    (
      '요약·과목 설정 삭제',
      () async {
        final prefs = await SharedPreferences.getInstance();
        for (final key in ['scheduled', 'courseAliases', 'aiSummaryText']) {
          await prefs.remove(key);
        }
        courseAliases = {};
        await prefs.setBool('aiSummaryEnabled', false);
        await prefs.setBool('aiDailyEnabled', false);
      },
    ),
    if (Platform.isAndroid || Platform.isIOS)
      (
        '매일 알림 해제',
        () async {
          await bridge.invokeNative(NativeMethod.setDailySettings, {
            'enabled': false,
            'hour': 18,
            'minute': 0,
          });
        },
      ),
    if (Platform.isAndroid || Platform.isIOS)
      (
        '위젯 갱신',
        () async {
          await bridge.invokeNative(NativeMethod.refreshWidget);
        },
      ),
  ]);
  await scopeStore?.db.close();
  return failures;
}

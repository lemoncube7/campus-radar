import 'navigation_key.dart';
import 'dart:async';
import 'dart:collection';
import 'dart:convert';
import 'dart:io' as io;
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';

WebViewEnvironment? _environment;
Future<WebViewEnvironment> desktopEnvironment() async {
  if (_environment != null) return _environment!;
  final data = await getApplicationSupportDirectory();
  _environment = await WebViewEnvironment.create(
    settings: WebViewEnvironmentSettings(
      userDataFolder: path.join(data.path, 'webview'),
    ),
  );
  return _environment!;
}

Future<void> clearDesktopWeb() async {
  final env = await desktopEnvironment();
  await CookieManager.instance(webViewEnvironment: env).deleteAllCookies();
  await InAppWebViewController.clearAllCache();
}

bool desktopTrustedUrl(String value, {bool plan = false}) {
  final uri = Uri.tryParse(value);
  return uri != null &&
      uri.scheme == 'https' &&
      uri.userInfo.isEmpty &&
      (plan
              ? {'cnuit.cnu.ac.kr', 'tlsn.cnu.ac.kr'}
              : {'dcs-learning.cnu.ac.kr', 'dcs-lcms.cnu.ac.kr'})
          .contains(uri.host);
}

String? desktopCookieDomain(io.Cookie cookie) {
  final domain = cookie.domain;
  // Chromium treats an explicit domain without a leading dot as host-only.
  // Dart's parsed Domain attribute has already lost that leading dot.
  return domain == null ? null : '.${domain.replaceFirst(RegExp(r"^\.+"), "")}';
}

Future<void> openDesktopCampus(Map<String, dynamic> a) async {
  final dest = a['url'] as String? ?? '';
  if (!desktopTrustedUrl(dest)) throw const FormatException('강의실 주소를 확인해 주세요.');
  final env = await desktopEnvironment();
  final manager = CookieManager.instance(webViewEnvironment: env);
  for (final row in (a['cookies'] as List? ?? [])) {
    final host = row['url'] as String;
    if (!desktopTrustedUrl(host)) continue;
    final cookie = io.Cookie.fromSetCookieValue(row['cookie'] as String);
    await manager.setCookie(
      url: WebUri(host),
      name: cookie.name,
      value: cookie.value,
      domain: desktopCookieDomain(cookie),
      path: cookie.path ?? '/',
      isSecure: true,
      isHttpOnly: cookie.httpOnly,
      expiresDate: cookie.expires?.millisecondsSinceEpoch,
    );
  }
  for (final host in {
    'https://dcs-learning.cnu.ac.kr',
    'https://dcs-lcms.cnu.ac.kr',
  }) {
    final expected = (a['cookies'] as List? ?? [])
        .where((row) => row['url'] == host)
        .map((row) => io.Cookie.fromSetCookieValue(row['cookie'] as String));
    final installed = await manager.getCookies(url: WebUri('$host/'));
    if (expected.any(
      (cookie) => !installed.any(
        (c) => c.name == cookie.name && c.value == cookie.value,
      ),
    )) {
      throw const FormatException('로그인 세션을 화면에 전달하지 못했습니다. 다시 시도해 주세요.');
    }
  }
  await navKey.currentState!.push(
    MaterialPageRoute(
      builder: (_) => DesktopWebPage(
        environment: env,
        url: dest,
        contextData: a['context'],
        target: a['target'] as String?,
      ),
    ),
  );
}

Future<Map<String, dynamic>?> openDesktopPlan(
  Map<String, dynamic> a, {
  required bool capture,
}) async {
  final url = a['url'] as String? ?? '';
  if (!desktopTrustedUrl(url, plan: true)) {
    throw const FormatException('계획서 주소를 확인해 주세요.');
  }
  final result = await navKey.currentState!.push<Map<String, dynamic>>(
    MaterialPageRoute(
      builder: (_) => DesktopWebPage(
        environment: null,
        url: url,
        plan: true,
        capture: capture,
        course: a['course'] as String? ?? '',
      ),
    ),
  );
  if (capture && result == null) {
    throw const FormatException('계획서 가져오기가 취소됐습니다.');
  }
  return result;
}

class DesktopWebPage extends StatefulWidget {
  final WebViewEnvironment? environment;
  final String url, course;
  final dynamic contextData;
  final String? target;
  final bool plan, capture;
  const DesktopWebPage({
    super.key,
    required this.environment,
    required this.url,
    this.contextData,
    this.target,
    this.plan = false,
    this.capture = false,
    this.course = '',
  });
  @override
  State<DesktopWebPage> createState() => _DesktopWebState();
}

class _DesktopWebState extends State<DesktopWebPage> {
  InAppWebViewController? web;
  Timer? timer;
  DateTime started = DateTime.now();
  String previous = '';
  int stable = 0;
  String? error;
  double progress = 0;
  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> poll() async {
    if (!mounted || web == null) return;
    if (DateTime.now().difference(started) > const Duration(seconds: 60)) {
      timer?.cancel();
      setState(() => error = '계획서 로딩 시간이 초과됐습니다. 원문을 확인하거나 다시 시도해 주세요.');
      return;
    }
    try {
      final raw = await web!.evaluateJavascript(source: planExtractScript);
      final data = raw is String ? jsonDecode(raw) : raw;
      final text = data['text'] as String? ?? '';
      final norm = text.replaceAll(RegExp(r'\s+'), '');
      final course = widget.course.replaceAll(RegExp(r'\s+'), '');
      final valid =
          (data['fields'] as num? ?? 0) >= 8 &&
          text.length >= 400 &&
          norm.contains('교과목') &&
          (course.isEmpty || norm.contains(course));
      stable = valid && previous == text ? stable + 1 : 0;
      previous = text;
      if (valid && stable >= 2 && mounted) {
        timer?.cancel();
        Navigator.pop(context, {
          'text': text.length > 120000 ? text.substring(0, 120000) : text,
          'sourceUrl': widget.url,
        });
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(widget.plan ? '강의계획서' : '사이버캠퍼스'),
      actions: [
        IconButton(
          tooltip: '새로고침',
          onPressed: () => web?.reload(),
          icon: const Icon(Icons.refresh),
        ),
      ],
    ),
    body: Column(
      children: [
        if (progress < 1)
          LinearProgressIndicator(value: progress == 0 ? null : progress),
        if (error != null)
          Padding(padding: const EdgeInsets.all(12), child: Text(error!)),
        Expanded(
          child: InAppWebView(
            webViewEnvironment: widget.environment,
            initialUrlRequest: URLRequest(url: WebUri(widget.url)),
            initialSettings: InAppWebViewSettings(
              javaScriptEnabled: true,
              useShouldOverrideUrlLoading: true,
              isInspectable: false,
              transparentBackground: false,
            ),
            initialUserScripts: UnmodifiableListView<UserScript>([
              if (!widget.plan)
                UserScript(
                  injectionTime: UserScriptInjectionTime.AT_DOCUMENT_START,
                  source:
                      "if(location.origin==='https://dcs-learning.cnu.ac.kr'){sessionStorage.setItem('currentCourseData',${jsonEncode(widget.contextData is String ? widget.contextData : jsonEncode(widget.contextData ?? {}))});}",
                ),
            ]),
            onWebViewCreated: (c) => web = c,
            onProgressChanged: (c, p) {
              if (mounted) setState(() => progress = p / 100);
            },
            shouldOverrideUrlLoading: (c, action) async {
              final u = action.request.url;
              if (u == null) return NavigationActionPolicy.CANCEL;
              if (desktopTrustedUrl(u.toString(), plan: widget.plan)) {
                return NavigationActionPolicy.ALLOW;
              }
              if (!widget.plan && u.scheme == 'https') {
                await launchUrl(
                  Uri.parse(u.toString()),
                  mode: LaunchMode.externalApplication,
                );
              }
              return NavigationActionPolicy.CANCEL;
            },
            onReceivedError: (c, request, e) {
              if (request.isForMainFrame == true && mounted) {
                setState(() => error = '페이지를 불러오지 못했습니다. 연결 상태를 확인해 주세요.');
              }
            },
            onLoadStop: (c, u) async {
              if (widget.capture && timer == null) {
                started = DateTime.now();
                timer = Timer.periodic(
                  const Duration(seconds: 1),
                  (_) => poll(),
                );
              }
              if (!widget.plan &&
                  u?.path == '/std/course' &&
                  widget.target?.isNotEmpty == true) {
                await c.evaluateJavascript(
                  source:
                      "(function(){var id=${jsonEncode(widget.target)},attempts=0;function jump(){var e=Array.from(document.querySelectorAll('[data-contentsid]')).find(e=>e.dataset.moduletype==='LV'&&(e.dataset.contentsid===id||e.dataset.weekseqno===id));if(e){var box=e.closest('.collapse');if(box)box.classList.add('show');e.scrollIntoView({block:'center'});if(window.courseAttend)courseAttend.detailContents(window.jQuery(e));}else if(attempts++<20)setTimeout(jump,500);}jump();})();",
                );
              }
            },
          ),
        ),
      ],
    ),
  );
}

const planExtractScript =
    r'''(function(){var lines=[],fields=0;function walk(n){if(n.nodeType===3){var t=n.textContent.trim();if(t)lines.push(t);return;}if(n.nodeType!==1)return;var tag=n.tagName;if(['SCRIPT','STYLE','NOSCRIPT'].indexOf(tag)>=0)return;var s=getComputedStyle(n);if(s.display==='none'||s.visibility==='hidden')return;if(n.getAttribute('role')==='textbox'&&!n.querySelector('input,textarea')){var rv=n.getAttribute('aria-valuetext')||n.innerText||'';if(rv.trim()){lines.push(rv.trim());fields++;}return;}if(tag==='INPUT'||tag==='TEXTAREA'){if(['password','hidden','checkbox','radio','button','submit'].indexOf(n.type)>=0)return;var v=n.value||'';if(v.trim()){lines.push(v.trim());fields++;}return;}for(var c=n.firstChild;c;c=c.nextSibling)walk(c);}walk(document.body);return JSON.stringify({text:lines.join('\n'),fields:fields});})();''';

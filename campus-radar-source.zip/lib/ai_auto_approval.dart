import 'dart:async';
import 'dart:convert';
import 'ai_approval_policy.dart';
import 'ai_confirm.dart';
import 'ai_protocol.dart';
import 'ai_request_budget.dart';
import 'ai_state_repository.dart';
import 'ai_state_models.dart';
import 'ai_transport.dart';
import 'app_credentials.dart';
import 'app_storage.dart';
import 'campus_models.dart';
import 'session_scope.dart';

/// Optional second review. Extraction success never depends on approval success.
Future<void> autoApproveNotice(
  Store store,
  CampusNotice notice,
  List<ScheduleCandidate> candidates, {
  AiTransport transport = geminiTransport,
  SessionScope? sourceScope,
  Future<void> Function()? beforeRequest,
}) async {
  if (await store.meta('aiAutoApprove') != 'yes') return;
  var claimed = false;
  try {
    final scope = await SessionScope.capture(
      store,
      ai: true,
      consents: {'aiConsent': aiConsentVersion, 'aiAutoApprove': 'yes'},
    );
    final apiKey = await credentials.read(key: 'geminiApiKey');
    if (apiKey == null || apiKey.isEmpty) return;
    final hash = noticeFingerprint(notice), repo = AiStateRepository(store);
    final selected = <String, ScheduleCandidate>{};
    for (final c in candidates) {
      final key = candidateKey(notice, c),
          state = await repo.schedule(candidateKey(notice, c));
      // Any prior edit or decision remains the user's responsibility.
      if (state.toJson().isNotEmpty ||
          !eligibleForAutoApproval(notice, c, DateTime.now().toUtc())) {
        continue;
      }
      final checked = await store.meta('aiApproval:$key');
      if (checked != null) {
        final prior = jsonDecode(checked) as Map;
        if (prior['fingerprint'] == hash &&
            prior['policy'] == approvalPolicyVersion &&
            prior['candidate'] == jsonEncode(c.toJson())) {
          continue;
        }
      }
      selected[key] = c;
      if (selected.length == 15) break;
    }
    if (selected.isEmpty) return;
    if (beforeRequest != null) {
      await beforeRequest();
    } else {
      await Future<void>.delayed(const Duration(seconds: 5));
    }
    await sourceScope?.verify();
    await scope.verify();
    await claimAiRequest(store);
    claimed = true;
    await store.log(
      'ai',
      'AI 자동 승인 검토 요청',
      '${notice.title} · 후보 ${selected.length}개',
    );
    final raw = await guardedAiTransport(
      scope,
      transport,
      apiKey,
      approvalRequest(notice, selected),
    );
    final reviews = parseApprovalResponse(raw, notice, selected.keys.toSet());
    for (final entry in selected.entries) {
      await sourceScope?.verify();
      await scope.verify();
      final current = (await store.notices())
          .where((n) => n.id == notice.id)
          .firstOrNull;
      if (current == null || noticeFingerprint(current) != hash) {
        throw SessionChanged();
      }
      final review = reviews[entry.key]!;
      if ((await repo.schedule(entry.key)).toJson().isNotEmpty) continue;
      if (review.approve &&
          eligibleForAutoApproval(
            notice,
            entry.value,
            DateTime.now().toUtc(),
          )) {
        // Persist local approval first: denied calendar permission cannot lose it.
        await confirmAiCandidate(
          store,
          entry.key,
          notice,
          entry.value,
          beforeCommit: () async {
            await sourceScope?.verify();
            await scope.verify();
            if ((await repo.schedule(entry.key)).toJson().isNotEmpty) {
              throw SessionChanged();
            }
          },
        );
        await scope.verify();
        var state = await repo.schedule(entry.key);
        await repo.saveSchedule(
          entry.key,
          ConfirmedSchedule.fromJson({
            ...state.toJson(),
            'approvalMode': 'automatic',
            'approvalReason': review.reason,
            'approvedAt': DateTime.now().toUtc().toIso8601String(),
          }),
        );
        if (await store.meta('aiCalendarDefault') == 'yes') {
          try {
            await scope.verify();
            await confirmAiCandidate(
              store,
              entry.key,
              notice,
              entry.value,
              calendar: true,
              beforeCommit: scope.verify,
            );
          } catch (e) {
            if (e is SessionChanged) rethrow;
            await scope.verify();
            await store.log(
              'ai',
              '자동 승인 일정 캘린더 전송 대기',
              '${notice.title} · 일정함에서 다시 보낼 수 있어요.',
            );
          }
        }
      }
      await scope.verify();
      await store.setMeta(
        'aiApproval:${entry.key}',
        jsonEncode({
          'fingerprint': hash,
          'policy': approvalPolicyVersion,
          'candidate': jsonEncode(entry.value.toJson()),
          'approved': review.approve,
          'reason': review.reason,
          'quote': review.quote,
          'checkedAt': DateTime.now().toUtc().toIso8601String(),
        }),
      );
      await store.log(
        'ai',
        review.approve ? 'AI 일정 자동 승인' : 'AI 일정 수동 검토 유지',
        '${notice.title} · ${review.reason}',
      );
    }
  } on SessionChanged {
    // The caller's extraction scope decides whether extraction is also stale.
    return;
  } catch (e) {
    await store.log(
      'ai',
      'AI 자동 승인 대기',
      e is AiFailure ? e.message : '재검토를 완료하지 못해 일정 후보를 유지했어요.',
    );
  } finally {
    if (claimed) await releaseAiRequest(store);
  }
}

/// Reads saved candidates independently of extraction scheduling. A malformed
/// old row cannot block the rest of the collection/analysis worker.
Future<void> autoApproveSavedCandidates(
  Store store,
  SessionScope scope, {
  required bool Function() keepGoing,
}) async {
  if (await store.meta('aiAutoApprove') != 'yes') return;
  final records = await store.db.query(
    'meta',
    where: 'id LIKE ?',
    whereArgs: ['aiCandidate:%'],
  );
  final current = {for (final n in await store.notices()) n.id: n};
  final grouped = <String, (CampusNotice, List<ScheduleCandidate>)>{};
  for (final row in records) {
    try {
      final saved = jsonDecode(row['value'] as String) as Map;
      final n = CampusNotice.fromJson(
        Map<String, dynamic>.from(saved['notice']),
      );
      if (current[n.id] == null ||
          noticeFingerprint(current[n.id]!) != noticeFingerprint(n)) {
        continue;
      }
      final c = ScheduleCandidate.parse(
        Map<String, dynamic>.from(saved['candidate']),
        '${n.title}\n${n.body}',
      );
      (grouped[n.id] ??= (n, <ScheduleCandidate>[])).$2.add(c);
    } catch (_) {
      await store.log(
        'ai',
        '자동 승인 후보 읽기 건너뜀',
        '이전 후보 형식을 읽지 못했어요. 원본 후보는 유지합니다.',
      );
    }
  }
  for (final group in grouped.values) {
    if (!keepGoing() || await store.meta('aiAutoApprove') != 'yes') break;
    await scope.verify();
    await autoApproveNotice(store, group.$1, group.$2, sourceScope: scope);
  }
}

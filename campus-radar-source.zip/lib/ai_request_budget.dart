import 'package:sqflite/sqflite.dart';
import 'app_storage.dart';
import 'operation_token.dart';
import 'ai_protocol.dart';

Future<void> releaseAiRequest(Store store) async {
  final owner = store.aiRequestOwner;
  if (owner == null) return;
  await store.db.transaction((txn) async {
    final rows = await txn.query(
      'meta',
      where: 'id=?',
      whereArgs: ['aiNetworkOwner'],
    );
    if (rows.isNotEmpty && rows.single['value'] == owner) {
      await txn.delete('meta', where: 'id=?', whereArgs: ['aiNetworkOwner']);
      await txn.insert('meta', {
        'id': 'aiNetworkUntil',
        'value': '0',
      }, conflictAlgorithm: ConflictAlgorithm.replace);
    }
  });
  store.aiRequestOwner = null;
}

Future<void> claimAiRequest(Store store, {bool interactive = false}) async {
  await store.db.transaction((txn) async {
    Future<String?> value(String key) async {
      final r = await txn.query('meta', where: 'id=?', whereArgs: [key]);
      return r.isEmpty ? null : r.first['value'] as String;
    }

    final now = DateTime.now().toUtc();
    final lease = int.tryParse(await value('aiNetworkUntil') ?? '0') ?? 0;
    final pending = int.tryParse(await value('aiInteractiveUntil') ?? '0') ?? 0;
    if (!interactive && pending > now.millisecondsSinceEpoch) {
      throw const AiFailure('사용자 질문 대기 중', code: 'busy');
    }
    final last = DateTime.tryParse(await value('aiLastRequest') ?? '');
    if (lease > now.millisecondsSinceEpoch ||
        last != null && now.difference(last) < const Duration(seconds: 5)) {
      throw const AiFailure('다른 요청 완료 후 잠시 기다려 주세요.', code: 'busy');
    }
    Future<void> set(String key, String data) => txn
        .insert('meta', {
          'id': key,
          'value': data,
        }, conflictAlgorithm: ConflictAlgorithm.replace)
        .then((_) {});
    final owner = freshToken();
    await set('aiNetworkOwner', owner);
    store.aiRequestOwner = owner;
    await set('aiNetworkUntil', '${now.millisecondsSinceEpoch + 180000}');
    await set('aiLastRequest', now.toIso8601String());
    final counter =
        'aiRequests:${now.add(const Duration(hours: 9)).toIso8601String().substring(0, 10)}';
    await set(
      counter,
      '${(int.tryParse(await value(counter) ?? '0') ?? 0) + 1}',
    );
  });
}

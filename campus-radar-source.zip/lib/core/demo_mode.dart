import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/schedule/timetable_model.dart';

/// Simulator and screenshot builds (`--dart-define=DEMO=true`) start with a
/// synthetic semester instead of a school login. Nothing here is real school
/// data, so these builds can run in public CI. Never enabled in releases.
const demoMode = bool.fromEnvironment('DEMO');

const _courses = [
  ('d1', '인공지능과 미래사회', 4, 540, 630, '교404A'),
  ('d2', '물리학개론', 4, 990, 1080, '교301'),
  ('d3', '선형대수', 1, 660, 750, '공5405'),
  ('d4', '논리와비판적사고', 1, 540, 630, '교207'),
  ('d5', '어드벤처디자인', 2, 900, 1020, '공5412'),
];

Future<void> seedDemo() async {
  if (!demoMode) return;
  final store = await Store.open();
  try {
    if (await store.meta(MetaKey.lastSuccess) != null) return;
    final now = DateTime.now().toUtc();
    Map<String, dynamic> ctx(String id) => {'course_id': id, 'class_no': '1'};
    CampusItem item(
      String id,
      String type,
      String title,
      String course,
      Duration due, {
      String status = 'pending',
    }) => CampusItem.fromJson({
      'key': '$type:$course:1:$id',
      'type': type,
      'title': title,
      'course': _courses.firstWhere((c) => c.$1 == course).$2,
      'courseId': course,
      'classNo': '1',
      'contentsId': id,
      'status': status,
      'due': now.add(due).toIso8601String(),
      'published': true,
      'attendanceRequired': type == 'LV' ? true : null,
      'context': ctx(course),
    });
    await store.replace([
      item('r1', 'LR', '10주차 팀 활동 보고서 제출', 'd5', const Duration(hours: 20)),
      item('r2', 'LR', '(과제2) 머신러닝 학습 방법 리포트', 'd1', const Duration(days: 4)),
      item('v1', 'LV', '9-2. 연습문제', 'd4', const Duration(days: 5)),
      item('v2', 'LV', '8주차 강의 영상', 'd2', const Duration(days: 9)),
      item('r3', 'LR', '중간 과제', 'd3', const Duration(days: -3), status: 'done'),
    ]);
    await store.replaceNotices([
      for (var i = 0; i < 4; i++)
        CampusNotice(
          id: 'n$i',
          title: ['보강 안내', '중간고사 성적 공개', '팀 편성 결과', '휴강 공지'][i],
          course: _courses[i].$2,
          context: ctx(_courses[i].$1),
          published: now.subtract(Duration(hours: 6 + i * 20)),
          read: i > 1,
        ),
    ]);
    await store.setMeta(
      MetaKey.courses,
      jsonEncode([
        for (final c in _courses)
          {'course_id': c.$1, 'class_no': '1', 'course_nm': c.$2},
      ]),
    );
    await store.setMeta(
      MetaKey.timetableEntries,
      jsonEncode([
        for (final c in _courses)
          ClassSlot(
            courseKey: '${c.$1}:1',
            course: c.$2,
            weekday: c.$3,
            start: c.$4,
            end: c.$5,
            room: c.$6,
            source: 'demo',
          ).toJson(),
      ]),
    );
    await store.setMeta(MetaKey.lastSuccess, now.toIso8601String());
    await credentials.write(key: 'id', value: 'demo');
    await credentials.write(key: 'pw', value: 'demo');
  } finally {
    await store.db.close();
  }
}

/// Root section requested by the simulator workflow (Documents/demo_tab).
Future<int?> demoStartTab() async {
  if (!demoMode) return null;
  try {
    final dir = await getApplicationDocumentsDirectory();
    return int.tryParse(
      (await File('${dir.path}/demo_tab').readAsString()).trim(),
    );
  } catch (_) {
    return null;
  }
}

import 'package:campus_radar/core/demo_state.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

const _secureStorage = FlutterSecureStorage(
  // v10 ignores encryptedSharedPreferences and migrates its data on first access.
  aOptions: AndroidOptions(),
  iOptions: IOSOptions(
    accessibility: KeychainAccessibility.first_unlock_this_device,
  ),
);

/// Blocks all reads/writes/deletes to real OS secure storage while demo mode is active.
class AppCredentials {
  const AppCredentials();

  Future<String?> read({required String key}) async {
    if (isDemoActive) return null;
    return _secureStorage.read(key: key);
  }

  Future<void> write({required String key, required String? value}) async {
    if (isDemoActive) return;
    return _secureStorage.write(key: key, value: value);
  }

  Future<void> delete({required String key}) async {
    if (isDemoActive) return;
    return _secureStorage.delete(key: key);
  }

  Future<void> deleteAll() async {
    if (isDemoActive) return;
    return _secureStorage.deleteAll();
  }

  Future<Map<String, String>> readAll() async {
    if (isDemoActive) return const <String, String>{};
    return _secureStorage.readAll();
  }
}

const credentials = AppCredentials();

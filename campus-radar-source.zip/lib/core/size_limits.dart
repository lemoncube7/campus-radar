import 'package:shared_preferences/shared_preferences.dart';

/// User-adjustable size limits for attachments. `null` means no limit (the default).
class SizeLimits {
  static const _cacheKey = 'limit.cacheBytes';
  static const _fileKey = 'limit.driveFileBytes';
  static const _totalKey = 'limit.driveTotalBytes';

  /// Choices shown in settings; null = no limit.
  static const choices = <int?>[
    null,
    25 * 1024 * 1024,
    100 * 1024 * 1024,
    300 * 1024 * 1024,
    1024 * 1024 * 1024,
    5 * 1024 * 1024 * 1024,
  ];

  static String label(int? bytes) {
    if (bytes == null) return '제한 없음';
    if (bytes >= 1024 * 1024 * 1024) return '${bytes ~/ (1024 * 1024 * 1024)}GB';
    return '${bytes ~/ (1024 * 1024)}MB';
  }

  static Future<int?> _get(String key) async {
    try {
      final p = await SharedPreferences.getInstance();
      final v = p.getInt(key);
      return v == null || v <= 0 ? null : v;
    } catch (_) {
      return null;
    }
  }

  static Future<void> _set(String key, int? bytes) async {
    final p = await SharedPreferences.getInstance();
    if (bytes == null || bytes <= 0) {
      await p.remove(key);
    } else {
      await p.setInt(key, bytes);
    }
  }

  /// Device attachment cache size; older files are evicted above it.
  static Future<int?> cacheBytes() => _get(_cacheKey);
  static Future<void> setCacheBytes(int? v) => _set(_cacheKey, v);

  /// Largest single original sent to Drive.
  static Future<int?> driveFileBytes() => _get(_fileKey);
  static Future<void> setDriveFileBytes(int? v) => _set(_fileKey, v);

  /// Total originals (materials + freeboard) sent to Drive per account.
  static Future<int?> driveTotalBytes() => _get(_totalKey);
  static Future<void> setDriveTotalBytes(int? v) => _set(_totalKey, v);
}

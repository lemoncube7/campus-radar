import 'package:campus_radar/core/demo_state.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'dart:io';
import 'package:flutter/services.dart';

Future<dynamic> Function(String, dynamic)? desktopMethodHandler;
Future<void> Function()? iosRefreshHandler;

/// iPhone: the Drive channel is implemented in Dart (export/drive_ios.dart).
Future<dynamic> Function(String, dynamic)? iosDriveHandler;
Future<void> Function()? iosMidnightTestHandler;

const _demoBlockedNativeMethods = <String>{
  'refreshWidget',
  'themeRefresh',
  'publishWidgetSnapshot',
  'pinTimetableWidget',
  'pinCompactWidget',
  'compactWidgetConfigure',
  'widgetTextConfigure',
  'setTimetableSettings',
  'setDailySettings',
  'testDailySummary',
  'testMidnightSummary',
  'calendarConfigure',
  'calendarWrite',
  'calendarSync',
  'calendarUnlink',
  'calendarRenameCourse',
  'driveConnect',
  'driveConfigure',
  'driveDisconnect',
  'driveEnqueue',
  'lockConfigure',
  'clearWebSession',
};

class RadarMethodChannel extends MethodChannel {
  const RadarMethodChannel() : super('campus_radar/native');
  Future<T?> invokeNative<T>(NativeMethod method, [dynamic arguments]) =>
      invokeMethod<T>(method.name, arguments);
  Future<Map<K, V>?> invokeNativeMap<K, V>(
    NativeMethod method, [
    dynamic arguments,
  ]) => invokeMapMethod<K, V>(method.name, arguments);
  Future<List<T>?> invokeNativeList<T>(
    NativeMethod method, [
    dynamic arguments,
  ]) => invokeListMethod<T>(method.name, arguments);
  @override
  Future<T?> invokeMethod<T>(String method, [dynamic arguments]) async {
    if (isDemoActive) {
      if (_demoBlockedNativeMethods.contains(method)) {
        return null;
      }
      if (method == 'driveAccounts') return <dynamic>[] as T?;
      if (method == 'calendarSettings') {
        return <String, dynamic>{'allowed': false, 'auto': false} as T?;
      }
      if (method == 'calendarPermission') return false as T?;
    }
    if (Platform.isWindows && desktopMethodHandler != null) {
      return (await desktopMethodHandler!(method, arguments)) as T?;
    }
    if (Platform.isIOS &&
        method.startsWith('drive') &&
        iosDriveHandler != null) {
      return (await iosDriveHandler!(method, arguments)) as T?;
    }
    if (Platform.isIOS && method == 'testMidnightSummary') {
      await iosMidnightTestHandler?.call();
      return null;
    }
    if (Platform.isIOS && method == 'refreshWidget') {
      await iosRefreshHandler?.call();
      return null;
    }
    final value = await super.invokeMethod<T>(method, arguments);
    if (Platform.isIOS &&
        (method == 'setTimetableSettings' ||
            method == 'calendarRenameCourse')) {
      await iosRefreshHandler?.call();
    }
    return value;
  }
}

const bridge = RadarMethodChannel();

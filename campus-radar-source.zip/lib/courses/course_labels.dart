int naturalCompare(String a, String b) {
  final reg = RegExp(r'(\d+)|(\D+)');
  final matchesA = reg.allMatches(a).toList();
  final matchesB = reg.allMatches(b).toList();
  final len = matchesA.length < matchesB.length ? matchesA.length : matchesB.length;
  for (var i = 0; i < len; i++) {
    final strA = matchesA[i].group(0)!;
    final strB = matchesB[i].group(0)!;
    final numA = int.tryParse(strA);
    final numB = int.tryParse(strB);
    if (numA != null && numB != null) {
      final c = numA.compareTo(numB);
      if (c != 0) return c;
    } else {
      final c = strA.compareTo(strB);
      if (c != 0) return c;
    }
  }
  return matchesA.length.compareTo(matchesB.length);
}

Map<String, String> courseAliases = {};
String courseLabel(String name) {
  final direct = courseAliases[name];
  if (direct != null) return direct;
  final normalized = name.replaceAll(RegExp(r'\s+'), '');
  for (final e in courseAliases.entries) {
    if (e.key.replaceAll(RegExp(r'\s+'), '') == normalized) return e.value;
  }
  return name;
}

String displayCourseText(String text) {
  final keys = courseAliases.keys.where((k) => k.isNotEmpty).toList()
    ..sort((a, b) => b.length.compareTo(a.length));
  if (keys.isEmpty) return text;
  // One pass, longest name first, so an alias is never itself rewritten by a
  // shorter course name it happens to contain.
  return text.replaceAllMapped(
    RegExp(keys.map(RegExp.escape).join('|')),
    (m) => courseAliases[m[0]]!,
  );
}

String courseEventTitle(String title, String original, {String? oldLabel}) {
  final label = courseLabel(original);
  final bracket = RegExp(r'^\[([^\]]+)\]').firstMatch(title);
  if (bracket != null) {
    final inner = bracket.group(1)!;
    final time = RegExp(r'\s+\d{2}:\d{2}$').firstMatch(inner)?.group(0) ?? '';
    final course = inner
        .substring(0, inner.length - time.length)
        .replaceAll(RegExp(r'\s+'), '');
    if ({
      original,
      ?oldLabel,
    }.any((p) => p.replaceAll(RegExp(r'\s+'), '') == course)) {
      return '[$label$time]${title.substring(bracket.end)}';
    }
  }
  return title;
}

String calendarDeadlineTitle(String course, String name, DateTime due) {
  final k = due.toUtc().add(const Duration(hours: 9));
  final clock =
      '${k.hour.toString().padLeft(2, '0')}:${k.minute.toString().padLeft(2, '0')}';
  return '[${courseLabel(course)} $clock] $name';
}

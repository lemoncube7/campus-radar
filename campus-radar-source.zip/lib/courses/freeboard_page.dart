import 'package:campus_radar/campus/media_cache.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/campus/freeboard_models.dart';
import 'package:campus_radar/campus/freeboard_service.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/campus_session.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/demo_state.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/core/ui_refresh.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/courses/course_list_card.dart';
import 'package:campus_radar/courses/media_widgets.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';

/// Embedded freeboard tab view inside [CoursePage].
class CourseFreeboardView extends StatefulWidget {
  final Map<String, dynamic> course;
  final bool active;

  const CourseFreeboardView({
    super.key,
    required this.course,
    this.active = true,
  });

  @override
  State<CourseFreeboardView> createState() => _CourseFreeboardViewState();
}

class _CourseFreeboardViewState extends State<CourseFreeboardView> {
  List<CampusFreeboardPost> posts = [];
  bool loading = true;
  bool refreshing = false;
  bool started = false;
  String? error;
  String query = '';

  String get courseKey =>
      '${widget.course['course_id']}:${widget.course['class_no']}';
  String get courseName => '${widget.course['course_nm'] ?? ''}';

  @override
  void initState() {
    super.initState();
    if (widget.active) load();
  }

  @override
  void didUpdateWidget(CourseFreeboardView old) {
    super.didUpdateWidget(old);
    if (widget.active && !started) load();
  }

  Future<void> load() async {
    started = true;
    Store? store;
    try {
      store = await Store.open();
      final data = await store.freeboardPosts(courseKey);
      if (mounted) {
        setState(() {
          posts = data;
          loading = false;
          error = null;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          error = '저장된 자유게시판 글을 읽지 못했어요.';
          loading = false;
        });
      }
    } finally {
      await store?.db.close();
      if (mounted && loading) setState(() => loading = false);
    }
  }

  Future<void> refreshFreeboard() async {
    if (refreshing) return;
    if (isDemoActive) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('체험 모드에서는 학교 사이트를 열 수 없어요.')),
        );
      }
      return;
    }

    setState(() {
      refreshing = true;
      error = null;
    });

    CampusClient? client;
    Store? store;
    try {
      final id = await credentials.read(key: 'id');
      final pw = await credentials.read(key: 'pw');
      if (id == null || pw == null) {
        throw CampusException('포털을 먼저 연결해 주세요.');
      }
      client = CampusClient();
      await client.connectSchool(id, pw);
      store = await Store.open();
      final fresh = await FreeboardService.syncCourseFreeboard(
        store,
        client,
        widget.course,
        courseName: courseName,
      );
      if (mounted) {
        setState(() {
          posts = fresh;
          error = null;
        });
      }
      // Keep every attachment on the device so it opens offline and can go to Drive.
      await FreeboardService.downloadMissingAttachments(
          store, client, await MediaCache.open(id), fresh);
    } catch (e) {
      if (mounted) {
        setState(() {
          error = e is CampusException
              ? e.message
              : '자유게시판 새로고침 중 오류가 발생했어요. 저장된 글은 유지해요.';
        });
      }
    } finally {
      client?.close();
      await store?.db.close();
      if (mounted) setState(() => refreshing = false);
    }
  }

  Future<void> openSchoolBoard() async {
    if (isDemoActive) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('체험 모드에서는 학교 사이트를 열 수 없어요.')),
        );
      }
      return;
    }
    CampusClient? client;
    try {
      final id = await credentials.read(key: 'id');
      final pw = await credentials.read(key: 'pw');
      if (id == null || pw == null) {
        throw CampusException('포털을 먼저 연결해 주세요.');
      }
      client = CampusClient();
      await client.connectSchool(id, pw);
      final nav = await client.freeboardNavigation(widget.course);
      await bridge.invokeNative(NativeMethod.openCampus, nav);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              e is CampusException ? e.message : '사이버캠퍼스 자유게시판을 열지 못했어요.',
            ),
          ),
        );
      }
    } finally {
      client?.close();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.active) return const SizedBox.shrink();

    final filtered = posts
        .where(
          (p) =>
              query.isEmpty ||
              p.title.toLowerCase().contains(query.toLowerCase()),
        )
        .toList();

    return RefreshIndicator(
      onRefresh: refreshFreeboard,
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // Header card: post count, open school shortcut, and refresh action
          Card(
            margin: EdgeInsets.zero,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          courseLabel(courseName),
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '자유게시판 ${posts.length}개',
                          style: Theme.of(context).textTheme.titleSmall,
                        ),
                      ],
                    ),
                  ),
                  TextButton.icon(
                    onPressed: openSchoolBoard,
                    icon: const Icon(Icons.open_in_new, size: 18),
                    label: const Text('원문 바로가기'),
                  ),
                  IconButton(
                    tooltip: '자유게시판 새로고침',
                    onPressed: refreshing ? null : refreshFreeboard,
                    icon: const Icon(Icons.refresh),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (refreshing) const LinearProgressIndicator(),
          if (error != null)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Text(
                error!,
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            ),
          if (posts.isNotEmpty) ...[
            TextField(
              decoration: const InputDecoration(
                labelText: '자유게시판 글 검색',
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: (v) => setState(() => query = v),
            ),
            const SizedBox(height: 12),
          ],
          if (loading)
            const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: CircularProgressIndicator(),
              ),
            )
          else if (posts.isEmpty)
            Padding(
              padding: const EdgeInsets.all(32),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.forum_outlined,
                      size: 48,
                      color: Theme.of(context).colorScheme.outline,
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      '등록된 자유게시판 글이 없어요.',
                      style: TextStyle(fontSize: 16),
                    ),
                    const SizedBox(height: 8),
                    FilledButton.tonalIcon(
                      onPressed: refreshing ? null : refreshFreeboard,
                      icon: const Icon(Icons.refresh),
                      label: const Text('새 글 확인'),
                    ),
                  ],
                ),
              ),
            )
          else if (filtered.isEmpty)
            const Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: Text('검색 결과가 없어요.')),
            )
          else
            ...filtered.map(
              (p) => CourseListCard(
                icon: p.isPinned
                    ? Icons.push_pin_rounded
                    : Icons.forum_outlined,
                color: p.isPinned
                    ? Theme.of(context).colorScheme.primary
                    : null,
                badgeLabel: p.isPinned ? '고정' : '자유',
                title: p.title,
                details: [
                  CourseCardDetail(
                    [
                      p.published == null
                          ? '작성일 미확인'
                          : koreanTime(p.published!),
                      if (p.hasAttachment || p.media.isNotEmpty)
                        '첨부 ${p.media.isNotEmpty ? p.media.length : 1}개',
                    ].join(' · '),
                  ),
                ],
                onTap: () async {
                  await navigateTo(
                    context,
                    FreeboardPostDestination(post: p),
                  );
                  await load();
                },
              ),
            ),
        ],
      ),
    );
  }
}

/// Detail screen for a single [CampusFreeboardPost].
class FreeboardDetailPage extends StatefulWidget {
  final CampusFreeboardPost post;

  const FreeboardDetailPage({super.key, required this.post});

  @override
  State<FreeboardDetailPage> createState() => _FreeboardDetailPageState();
}

class _FreeboardDetailPageState extends State<FreeboardDetailPage> {
  late CampusFreeboardPost post = widget.post;
  bool loading = false;
  bool opening = false;
  String? error;

  @override
  void initState() {
    super.initState();
    if (!post.bodyFetched) {
      loadBody();
    }
  }

  Future<void> loadBody({bool force = false}) async {
    if (post.bodyFetched && !force) return;
    if (isDemoActive) return;

    setState(() {
      loading = true;
      error = null;
    });

    CampusClient? client;
    Store? store;
    try {
      final id = await credentials.read(key: 'id');
      final pw = await credentials.read(key: 'pw');
      if (id == null || pw == null) {
        throw CampusException('포털을 먼저 연결해 주세요.');
      }
      client = CampusClient();
      await client.connectSchool(id, pw);
      final updated = await client.fetchFreeboardDetail(post);
      store = await Store.open();
      await store.saveFreeboardPost(updated);
      if (mounted) {
        setState(() {
          post = updated;
          error = null;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          error = e is CampusException
              ? e.message
              : '자유게시판 본문을 불러오지 못했어요. 저장된 내용은 유지해요.';
        });
      }
    } finally {
      client?.close();
      await store?.db.close();
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> openSchoolPost() async {
    if (isDemoActive) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('체험 모드에서는 학교 사이트를 열 수 없어요.')),
        );
      }
      return;
    }
    setState(() => opening = true);
    CampusClient? client;
    try {
      final id = await credentials.read(key: 'id');
      final pw = await credentials.read(key: 'pw');
      if (id == null || pw == null) {
        throw CampusException('포털을 먼저 연결해 주세요.');
      }
      client = CampusClient();
      await client.connectSchool(id, pw);
      final nav = await client.freeboardNavigation(
        post.context,
        postId: post.id,
      );
      await bridge.invokeNative(NativeMethod.openCampus, nav);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              e is CampusException ? e.message : '사이버캠퍼스 글을 열지 못했어요.',
            ),
          ),
        );
      }
    } finally {
      client?.close();
      if (mounted) setState(() => opening = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('자유게시판 상세'),
      actions: [
        IconButton(
          tooltip: '본문·첨부 새로고침',
          onPressed: loading ? null : () => loadBody(force: true),
          icon: const Icon(Icons.refresh),
        ),
      ],
    ),
    bottomNavigationBar: PinnedAction(
      child: FilledButton.icon(
        onPressed: opening ? null : openSchoolPost,
        icon: const Icon(Icons.open_in_new),
        label: Text(opening ? '연결 중…' : '사이버캠퍼스 열기'),
      ),
    ),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Row(
          children: [
            Text(courseLabel(post.course)),
            if (post.isPinned) ...[
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 6,
                  vertical: 2,
                ),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  '고정글',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.onPrimaryContainer,
                  ),
                ),
              ),
            ],
          ],
        ),
        const SizedBox(height: 8),
        Text(
          post.title,
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        if (post.published != null) ...[
          const SizedBox(height: 4),
          Text(
            koreanTime(post.published!),
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
        const SizedBox(height: 16),
        if (loading) const LinearProgressIndicator(),
        if (error != null) ...[
          Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          const SizedBox(height: 8),
          TextButton(
            onPressed: () => loadBody(force: true),
            child: const Text('본문 다시 불러오기'),
          ),
        ],
        if (!post.bodyFetched && post.body.isNotEmpty)
          const Padding(
            padding: EdgeInsets.only(bottom: 8),
            child: Text('저장된 본문이에요. 최신 내용을 확인하고 있어요.'),
          ),
        CampusBodyView(
          body: post.body.isEmpty && post.media.isEmpty
              ? (loading ? '본문을 불러오는 중이에요.' : '본문이 없어요.')
              : post.body,
          bodyHtml: post.bodyHtml,
          media: post.media,
        ),
        const SizedBox(height: 24),
        const Text(
          '댓글 작성·조회 및 글쓰기는 사이버캠퍼스 원문에서 확인해 주세요.',
          style: TextStyle(fontSize: 12, color: Colors.grey),
        ),
      ],
    ),
  );
}

import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/core/demo_state.dart';
import 'package:campus_radar/core/adaptive_content.dart';
import 'package:campus_radar/campus/campus_session.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/ai/ai_chat_page.dart';
import 'package:campus_radar/notices/notice_pages.dart';
import 'package:campus_radar/courses/course_catalog.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/courses/course_aliases.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/campus/plan_fetch.dart';
import 'package:campus_radar/courses/course_colors.dart';
import 'dart:io';
import 'package:campus_radar/core/ui_refresh.dart';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';
import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/today_class_model.dart';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/courses/mobile_courses_view.dart';

class CoursesPage extends StatefulWidget {
  final bool embedded;
  const CoursesPage({super.key, this.embedded = false});
  @override
  State<CoursesPage> createState() => _CoursesPageState();
}

class _CoursesPageState extends State<CoursesPage> {
  List<Map<String, dynamic>> courses = [];
  String? error;
  List<CampusItem> pending = [];
  List<ClassSlot> slots = [];
  List<ClassCancellation> cancellations = [];
  bool loading = true;
  bool refreshing = false;
  @override
  void initState() {
    super.initState();
    unawaited(load());
  }

  Future<void> load() async {
    Store? store;
    try {
      await loadCourseAliases();
      store = await Store.open();
      final data = await readCourses(store);
      final excluded = await store.excluded();
      final timetable = decodeSlots(await store.meta(MetaKey.timetableEntries));
      final cancelled = await readClassCancellations(store);
      final tasks =
          (await store.items())
              .where(
                (i) =>
                    i.openTask &&
                    i.availableAt(DateTime.now().toUtc()) &&
                    !excluded.contains(i.key),
              )
              .toList()
            ..sort(
              (a, b) => (a.due ?? DateTime.utc(2100)).compareTo(
                b.due ?? DateTime.utc(2100),
              ),
            );
      if (mounted) {
        setState(() {
          courses = data;
          pending = tasks;
          slots = timetable;
          cancellations = cancelled;
          error = null;
          loading = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          error = '과목 목록을 읽지 못했어요.';
          loading = false;
        });
      }
    } finally {
      await store?.db.close();
    }
  }

  Future<void> refreshCourses() async {
    if (refreshing) return;
    if (isDemoActive) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('체험 모드에서는 학교 사이트를 열 수 없어요.')),
        );
      }
      return;
    }
    setState(() {
      refreshing = true;
      error = null;
    });
    CampusClient? client;
    Store? store;
    final account = await credentials.read(key: 'id');
    try {
      store = await Store.open();
      final scope = await SessionScope.capture(store);
      final password = await credentials.read(key: 'pw');
      if (account == null || password == null) {
        throw CampusException('포털을 먼저 연결해 주세요.');
      }
      client = CampusClient();
      await client.connectSchool(account, password);
      final rows = await client.fetchCourses();
      if (await credentials.read(key: 'id') != account) {
        throw CampusException('계정이 변경되어 과목 갱신을 중지했어요.');
      }
      await scope.verify();
      await store.setMeta(MetaKey.courses, jsonEncode(rows));
      await store.log(
        'sync',
        '수강 과목 목록 새로고침',
        '${rows.length}과목 · 학교 수강 목록에서 조회',
      );
      await load();
    } catch (e) {
      if (mounted) setState(() => error = '과목 새로고침: ${planFailure(e)}');
    } finally {
      client?.close();
      await store?.db.close();
      if (mounted) setState(() => refreshing = false);
    }
  }

  String? nextCourseClass(String key) => nextCourseClassLabel(
    slots,
    cancellations,
    key,
    DateTime.now().toUtc().add(const Duration(hours: 9)),
  );

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.paddingOf(context).bottom;

    final content = AdaptiveContent(
      child: loading
          ? const Center(child: CircularProgressIndicator())
          : (Platform.isAndroid || Platform.isIOS || MediaQuery.sizeOf(context).width < 760)
              ? MobileCoursesView(
                  courses: courses,
                  pendingTasks: pending,
                  slots: slots,
                  isLoading: loading,
                  isRefreshing: refreshing,
                  onRefresh: refreshCourses,
                  onCourseTap: (c) async {
                    await navigateTo(context, CourseDestination(course: c));
                    await load();
                  },
                  onTimetableTap: () => navigateTo(context, TimetableDestination()),
                )
              : RefreshIndicator(
                  onRefresh: refreshCourses,
                  child: ListView(
                    padding: EdgeInsets.fromLTRB(20, 20, 20, 80 + bottomInset),
                    children: [
                      SectionHeading(
                        '이번 학기 ${courses.length}과목',
                        subtitle: '과목별 미완료와 가까운 마감을 확인하세요.',
                      ),
                      if (refreshing) const LinearProgressIndicator(),
                      if (Platform.isAndroid || Platform.isIOS)
                        Card(
                          child: ListTile(
                            leading: const Icon(Icons.calendar_month_outlined),
                            title: const Text('나의 시간표'),
                            subtitle: const Text('주간 수업 · 시간표 편집 · 알림'),
                            trailing: const Icon(Icons.chevron_right),
                            onTap: () =>
                                navigateTo(context, TimetableDestination()),
                          ),
                        ),
                      const SizedBox(height: 16),
                      if (error != null) Text(error!),
                      if (courses.isEmpty)
                        const Padding(
                          padding: EdgeInsets.all(24),
                          child: Text('수집된 과목이 없어요. 포털 연결 후 지금 새로고침을 눌러 주세요.'),
                        ),
                      ...courses.map((c) {
                        final original = '${c['course_nm']}';
                        final label = courseLabel(original);
                        final tasks = pending
                            .where((i) => courseKey(i.context) == courseKey(c))
                            .toList();
                        final next = nextCourseClass(courseKey(c));
                        return Card(
                          child: ListTile(
                            leading: CircleAvatar(
                              backgroundColor: courseAccent(
                                courseKey(c),
                              ).withValues(alpha: .15),
                              foregroundColor:
                                  Theme.of(context).brightness == Brightness.dark
                                  ? Color.lerp(
                                      courseAccent(courseKey(c)),
                                      Colors.white,
                                      .45,
                                    )
                                  : courseAccent(courseKey(c)),
                              child: Text(
                                label.isEmpty ? '?' : label.substring(0, 1),
                              ),
                            ),
                            title: Text(label),
                            subtitle: Text(
                              [
                                if (label != original) original,
                                if (next != null) '다음 수업 $next',
                                tasks.isEmpty
                                    ? '미완료 없음'
                                    : '미완료 ${tasks.length}개'
                                          '${tasks.first.due == null ? '' : ' · ${remainingText(tasks.first)}'}',
                              ].join('\n'),
                              maxLines: 3,
                              overflow: TextOverflow.ellipsis,
                            ),
                            trailing: const Icon(Icons.chevron_right),
                            onTap: () async {
                              await navigateTo(
                                context,
                                CourseDestination(course: c),
                              );
                              await load();
                            },
                          ),
                        );
                      }),
                    ],
                  ),
                ),
    );

    if (widget.embedded) return content;

    return Scaffold(
      appBar: AppBar(
        title: const Text('내 과목'),
        actions: [
          IconButton(
            tooltip: '학교에서 과목 다시 받기',
            onPressed: refreshing ? null : refreshCourses,
            icon: const Icon(Icons.refresh),
          ),
          IconButton(
            tooltip: '전체 공지',
            icon: const Icon(Icons.campaign_outlined),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const NoticesPage()),
            ),
          ),
          PopupMenuButton<String>(
            tooltip: '더보기',
            onSelected: (v) => v == 'ai'
                ? Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const AiChatPage()),
                  )
                : navigateTo(context, TimetableDestination()),
            itemBuilder: (_) => [
              if (Platform.isAndroid || Platform.isIOS)
                const PopupMenuItem(value: 'timetable', child: Text('시간표·수업 알림')),
              const PopupMenuItem(value: 'ai', child: Text('AI 채팅')),
            ],
          ),
        ],
      ),
      body: content,
    );
  }
}

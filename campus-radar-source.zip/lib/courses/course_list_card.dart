import 'package:flutter/material.dart';

/// Rounded list card shared by the course tabs (할 일·공지·자료·수업 정보):
/// a tinted badge on the left, title and detail lines, and a trailing widget.
class CourseListCard extends StatelessWidget {
  final IconData icon;
  final Color? color;
  final String? badgeLabel;
  final String title;
  final List<Widget> details;
  final Widget? trailing;
  final VoidCallback? onTap, onLongPress;
  const CourseListCard({
    super.key,
    required this.icon,
    required this.title,
    this.color,
    this.badgeLabel,
    this.details = const [],
    this.trailing,
    this.onTap,
    this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colors = theme.colorScheme;
    final accent = color ?? colors.primary;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4.5),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLowest,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: colors.outlineVariant.withValues(alpha: 0.45),
        ),
        boxShadow: [
          BoxShadow(
            color: colors.shadow.withValues(alpha: 0.02),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          onLongPress: onLongPress,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 13, 14, 13),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(icon, color: accent, size: 20),
                      if (badgeLabel != null) ...[
                        const SizedBox(height: 1),
                        Text(
                          badgeLabel!,
                          maxLines: 1,
                          style: TextStyle(
                            color: accent,
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w700,
                          fontSize: 14.5,
                          letterSpacing: -0.3,
                        ),
                      ),
                      if (details.isNotEmpty) const SizedBox(height: 5),
                      ...details,
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                trailing ??
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      size: 13,
                      color: colors.outlineVariant,
                    ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Small grey detail line used under a [CourseListCard] title.
class CourseCardDetail extends StatelessWidget {
  final String text;
  const CourseCardDetail(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Text(
    text,
    maxLines: 2,
    overflow: TextOverflow.ellipsis,
    style: Theme.of(context).textTheme.bodySmall?.copyWith(
      color: Theme.of(context).colorScheme.onSurfaceVariant,
      fontSize: 11.5,
    ),
  );
}

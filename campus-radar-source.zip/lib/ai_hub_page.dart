import 'navigation_contract.dart';
import 'ai_inbox_page.dart';
import 'package:flutter/material.dart';

class AiHubPage extends StatelessWidget {
  const AiHubPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('AI 도우미'),
      actions: [
        IconButton(
          tooltip: 'AI 설정',
          icon: const Icon(Icons.tune),
          onPressed: () => navigateTo(context, AiSettingsDestination()),
        ),
      ],
    ),
    body: const AiInboxPage(embedded: true, home: true),
  );
}

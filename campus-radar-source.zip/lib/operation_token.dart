import 'dart:convert';
import 'dart:math';

String freshToken() =>
    base64UrlEncode(List.generate(24, (_) => Random.secure().nextInt(256)));

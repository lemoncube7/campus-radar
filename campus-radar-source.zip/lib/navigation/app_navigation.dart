import 'package:flutter/material.dart';
import 'package:campus_radar/home/home_navigation.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/core/navigation_key.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/platform/desktop.dart';
import 'dart:async';
import 'dart:io';
import 'package:campus_radar/ai/ai_cancellation_notification.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';
import 'package:campus_radar/updates/update_notification.dart';
import 'package:campus_radar/updates/app_notices.dart';
import 'package:url_launcher/url_launcher.dart';

Future<void> openItem(String? key) async {
  if (key == null) return;
  if (key == updateNotificationTarget) {
    const target = UpdateDestination();
    navKey.currentState?.pushNamed(target.path, arguments: target);
    return;
  }
  if (key == '_app_notices') {
    const target = AppNoticeDestination();
    navKey.currentState?.pushNamed(target.path, arguments: target);
    return;
  }
  if (key.startsWith('app_notice:')) {
    final noticeId = key.substring('app_notice:'.length);
    await handleAppNoticeNotificationTap(noticeId);
    return;
  }
  if (Platform.isWindows) {
    await desktopRuntime.show();
    if (key == '_desktop') return;
  }
  if (key == '_review') {
    const target = AiInboxDestination();
    navKey.currentState?.pushNamed(target.path, arguments: target);
    return;
  }
  if (key.startsWith(cancellationPayloadPrefix)) {
    final resolved = await resolveCancellationNotificationTarget(key);
    if (resolved == null) {
      const target = AiInboxDestination();
      navKey.currentState?.pushNamed(target.path, arguments: target);
      return;
    }
    CancellationReceipt? receipt;
    final target = CancellationDestination(
      notice: resolved.notice,
      candidate: resolved.candidate,
      onApplied: (value) => receipt = value,
    );
    final applied =
        await navKey.currentState?.pushNamed<bool>(
          target.path,
          arguments: target,
        ) ??
        false;
    if (applied) {
      await finishCandidateCancellation(
        navKey.currentContext,
        candidateKey: resolved.candidateKey,
        receipt: receipt,
        mark: resolved.mark,
      );
    }
    return;
  }
  if (key == '_tasks' || key == '_summary') {
    navKey.currentState?.popUntil((route) => route.isFirst);
    homeNavigation.value = HomeRequest(today: key == '_summary');
    return;
  }
  if (key.startsWith('NOTICE:')) {
    final s = await Store.open();
    CampusNotice? notice;
    try {
      notice = (await s.notices())
          .where((n) => n.id == key.substring(7))
          .firstOrNull;
    } finally {
      await s.db.close();
    }
    if (notice == null) {
      _missingTarget();
    } else {
      navKey.currentState?.pushNamed(
        NoticeDestination(notice: notice).path,
        arguments: NoticeDestination(notice: notice),
      );
    }
    return;
  }
  if (key == '_timetable') {
    navKey.currentState?.pushNamed(
      TimetableDestination().path,
      arguments: TimetableDestination(),
    );
    return;
  }
  final store = await Store.open();
  final item = (await store.items()).where((i) => i.key == key).firstOrNull;
  final excluded = (await store.excluded()).contains(key);
  await store.log(
    'notification',
    '알림 클릭',
    item == null
        ? '현재 목록에 없는 항목의 알림이에요.'
        : '${courseLabel(item.course)} · ${item.title}',
  );
  await store.db.close();
  if (item == null) {
    _missingTarget();
  } else {
    navKey.currentState?.pushNamed(
      TaskDestination(item: item, excluded: excluded).path,
      arguments: TaskDestination(item: item, excluded: excluded),
    );
  }
}

void _missingTarget() =>
    openTaskList(message: '현재 목록에서 이 항목을 찾지 못했어요. 목록을 새로 확인해 주세요.');

/// Root navigation and feedback stay independent of the durable target lookup.
void openTaskList({String? message}) {
  navKey.currentState?.popUntil((route) => route.isFirst);
  homeNavigation.value = const HomeRequest();
  final context = navKey.currentContext;
  if (context != null && message != null) {
    ScaffoldMessenger.maybeOf(
      context,
    )?.showSnackBar(SnackBar(content: Text(message)));
  }
}

Future<void> handleAppNoticeNotificationTap(String noticeId) async {
  final notices = await loadCachedAppNotices();
  final notice = notices.where((n) => n.id == noticeId).firstOrNull;
  if (notice?.url != null && notice!.url!.isNotEmpty) {
    final uri = Uri.tryParse(notice.url!);
    if (uri != null && (uri.isScheme('http') || uri.isScheme('https'))) {
      try {
        final launched = await launchUrl(
          uri,
          mode: LaunchMode.externalApplication,
        );
        if (launched) return;
      } catch (_) {
        // Fall back to opening the notices page
      }
    }
  }
  const target = AppNoticeDestination();
  navKey.currentState?.pushNamed(target.path, arguments: target);
}

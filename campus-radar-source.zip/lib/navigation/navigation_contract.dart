import 'package:flutter/material.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/freeboard_models.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';

sealed class AppDestination {
  const AppDestination();
  String get path;
}

class TaskDestination extends AppDestination {
  final CampusItem item;
  final bool excluded;
  const TaskDestination({required this.item, this.excluded = false});
  @override
  String get path => '/radar/task';
}

class NoticeDestination extends AppDestination {
  final CampusNotice notice;
  const NoticeDestination({required this.notice});
  @override
  String get path => '/radar/notice';
}

class FreeboardPostDestination extends AppDestination {
  final CampusFreeboardPost post;
  const FreeboardPostDestination({required this.post});
  @override
  String get path => '/radar/freeboard/post';
}

class CourseDestination extends AppDestination {
  final Map<String, dynamic> course;
  const CourseDestination({required this.course});
  @override
  String get path => '/radar/course';
}

class TimetableDestination extends AppDestination {
  const TimetableDestination();
  @override
  String get path => '/radar/timetable';
}

class CancellationDestination extends AppDestination {
  final CampusNotice notice;
  final ScheduleCandidate candidate;
  final void Function(CancellationReceipt)? onApplied;
  const CancellationDestination({
    required this.notice,
    required this.candidate,
    this.onApplied,
  });
  @override
  String get path => '/radar/timetable/cancellation';
}

class UpdateDestination extends AppDestination {
  const UpdateDestination();
  @override
  String get path => '/radar/updates';
}

class SummaryDestination extends AppDestination {
  final bool settings;
  const SummaryDestination({this.settings = false});
  @override
  String get path => '/radar/summary';
}

class AiInboxDestination extends AppDestination {
  final bool embedded, home, records;
  final String? noticeId, candidateId;
  final String initialFilter;
  const AiInboxDestination({
    this.embedded = false,
    this.home = false,
    this.records = false,
    this.noticeId,
    this.candidateId,
    this.initialFilter = 'review',
  });
  @override
  String get path => '/radar/ai/inbox';
}

class AiSettingsDestination extends AppDestination {
  const AiSettingsDestination();
  @override
  String get path => '/radar/ai/settings';
}

class AppNoticeDestination extends AppDestination {
  const AppNoticeDestination();
  @override
  String get path => '/radar/app-notices';
}

Future<T?> navigateTo<T>(BuildContext context, AppDestination target) =>
    Navigator.of(context).pushNamed<T>(target.path, arguments: target);

enum HelpTool {
  ai,
  calendarSettings,
  review,
  calendar,
  notices,
  timetable,
  notifications,
  permissions,
  classNotifications,
  background,
  widgets,
  appearance,
  tasks,
  history,
  drive,
  materials,
  appNotices,
}

class HelpToolDestination extends AppDestination {
  final HelpTool tool;
  const HelpToolDestination(this.tool);
  @override
  String get path => '/radar/help/tool';
}

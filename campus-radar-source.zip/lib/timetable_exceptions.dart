import 'dart:convert';
import 'timetable_model.dart';

/// Date-specific cancellation; the weekly source timetable is never mutated.
class ClassCancellation {
  final String id, slotId, date, course, source;
  const ClassCancellation(
    this.id,
    this.slotId,
    this.date,
    this.course,
    this.source,
  );
  Map<String, dynamic> toJson() => {
    'id': id,
    'slotId': slotId,
    'date': date,
    'course': course,
    'source': source,
  };
}

class CancellationData {
  final List<ClassCancellation> entries;
  final int invalidRows;
  const CancellationData(this.entries, this.invalidRows);
}

CancellationData parseCancellationData(String? raw) {
  if (raw == null) return const CancellationData([], 0);
  final data = jsonDecode(raw);
  if (data is! List) throw const FormatException('휴강 저장 형식이 올바르지 않습니다.');
  final valid = <String, ClassCancellation>{};
  var invalid = 0;
  for (final row in data) {
    if (row is! Map ||
        row['id'] is! String ||
        row['slotId'] is! String ||
        row['date'] is! String ||
        row['id'].isEmpty ||
        row['slotId'].isEmpty ||
        row['course'] != null && row['course'] is! String ||
        row['source'] != null && row['source'] is! String) {
      invalid++;
      continue;
    }
    final date = row['date'] as String;
    final parsed = DateTime.tryParse(date);
    if (!RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(date) ||
        parsed == null ||
        classDate(parsed) != date) {
      invalid++;
      continue;
    }
    valid[row['id']] = ClassCancellation(
      row['id'],
      row['slotId'],
      date,
      row['course'] ?? '',
      row['source'] ?? '',
    );
  }
  return CancellationData(valid.values.toList(), invalid);
}

/// Legacy tolerant reader: invalid individual rows cannot erase valid exceptions.
/// Storage-aware readers should use CancellationRepository for root recovery.
List<ClassCancellation> decodeCancellations(String? raw) {
  try {
    return parseCancellationData(raw).entries;
  } on FormatException {
    return [];
  }
}

List<ClassCancellation> planCancellations(
  List<ClassSlot> slots,
  Set<String> selected,
  DateTime start,
  DateTime end, {
  String source = '',
}) {
  final first = DateTime(start.year, start.month, start.day);
  final last = DateTime(end.year, end.month, end.day);
  if (last.isBefore(first) || last.difference(first).inDays > 366) {
    throw const FormatException('휴강 날짜 범위를 확인해 주세요.');
  }
  final planned = <String, ClassCancellation>{};
  for (var d = first; !d.isAfter(last); d = d.add(const Duration(days: 1))) {
    for (final slot in slots.where(
      (s) => selected.contains(s.id) && s.weekday == d.weekday,
    )) {
      final id = '${classDate(d)}:${slot.id}';
      planned[id] = ClassCancellation(
        id,
        slot.id,
        classDate(d),
        slot.course,
        source,
      );
    }
  }
  return planned.values.toList();
}

String classDate(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
List<ClassSlot> classesOnDate(
  List<ClassSlot> base,
  List<ClassCancellation> cancelled,
  DateTime date,
) {
  final day = classDate(date);
  final hidden = cancelled
      .where((c) => c.date == day)
      .map((c) => c.slotId)
      .toSet();
  return base
      .where((s) => s.weekday == date.weekday && !hidden.contains(s.id))
      .toList();
}

List<ClassSlot> classesThisWeek(
  List<ClassSlot> base,
  List<ClassCancellation> cancelled,
  DateTime now,
) {
  final monday = DateTime(
    now.year,
    now.month,
    now.day,
  ).subtract(Duration(days: now.weekday - 1));
  return [
    for (var i = 0; i < 7; i++)
      ...classesOnDate(base, cancelled, monday.add(Duration(days: i))),
  ];
}

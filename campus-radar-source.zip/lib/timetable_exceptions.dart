import 'dart:convert';
import 'timetable_model.dart';

/// Date-specific cancellation; the weekly source timetable is never mutated.
class ClassCancellation {
  final String id, slotId, date, course, source;
  const ClassCancellation(
    this.id,
    this.slotId,
    this.date,
    this.course,
    this.source,
  );
  Map<String, dynamic> toJson() => {
    'id': id,
    'slotId': slotId,
    'date': date,
    'course': course,
    'source': source,
  };
}

List<ClassCancellation> decodeCancellations(String? raw) {
  if (raw == null) return [];
  try {
    return (jsonDecode(raw) as List)
        .whereType<Map>()
        .where(
          (m) =>
              m['id'] is String &&
              m['slotId'] is String &&
              m['date'] is String &&
              DateTime.tryParse(m['date']) != null,
        )
        .map(
          (m) => ClassCancellation(
            m['id'],
            m['slotId'],
            m['date'],
            m['course'] ?? '',
            m['source'] ?? '',
          ),
        )
        .toList();
  } catch (_) {
    return [];
  }
}

String classDate(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
List<ClassSlot> classesOnDate(
  List<ClassSlot> base,
  List<ClassCancellation> cancelled,
  DateTime date,
) {
  final day = classDate(date);
  final hidden = cancelled
      .where((c) => c.date == day)
      .map((c) => c.slotId)
      .toSet();
  return base
      .where((s) => s.weekday == date.weekday && !hidden.contains(s.id))
      .toList();
}

List<ClassSlot> classesThisWeek(
  List<ClassSlot> base,
  List<ClassCancellation> cancelled,
  DateTime now,
) {
  final monday = DateTime(
    now.year,
    now.month,
    now.day,
  ).subtract(Duration(days: now.weekday - 1));
  return [
    for (var i = 0; i < 7; i++)
      ...classesOnDate(base, cancelled, monday.add(Duration(days: i))),
  ];
}

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'app_storage.dart';
import 'session_probe_policy.dart';
import 'session_lifetime.dart';
import 'session_lifetime_repository.dart';
import 'services.dart';
import 'task_presentation.dart';

class SessionExplorationPage extends StatefulWidget {
  const SessionExplorationPage({super.key});
  @override
  State<SessionExplorationPage> createState() => _SessionExplorationState();
}

class _SessionExplorationState extends State<SessionExplorationPage> {
  bool enabled = false, scheduled = false, busy = true;
  Set<int> days = {6, 7};
  int start = 0, end = 24, gap = 60;
  SessionLifetime? snapshot;
  SessionProbePolicy savedPolicy = const SessionProbePolicy();
  String? message;
  Timer? timer;
  @override
  void initState() {
    super.initState();
    load();
    timer = Timer.periodic(
      const Duration(seconds: 30),
      (_) => refreshObservation(),
    );
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> refreshObservation() async {
    Store? store;
    try {
      store = await Store.open();
      final value = await SessionLifetimeRepository(
        store,
      ).read(await store.meta('sessionEpoch') ?? '');
      if (mounted) setState(() => snapshot = value);
    } catch (_) {
      if (mounted) setState(() => message = '관측 기록을 읽지 못했어요. 기존 설정은 유지해요.');
    } finally {
      await store?.db.close();
    }
  }

  Future<void> load() async {
    try {
      final p = await readSessionProbePolicy();
      if (mounted) {
        setState(() {
          savedPolicy = p;
          enabled = p.enabled;
          scheduled = p.scheduled;
          days = p.days.toSet();
          start = p.startHour;
          end = p.endHour;
          gap = p.initialMinutes;
        });
      }
      await refreshObservation();
    } catch (_) {
      if (mounted) setState(() => message = '설정을 읽지 못했어요.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  String duration(int minutes) => minutes < 60
      ? '$minutes분'
      : '${minutes ~/ 60}시간${minutes % 60 == 0 ? "" : " ${minutes % 60}분"}';
  Future<void> apply(bool value) async {
    if (value && scheduled && days.isEmpty) {
      setState(() => message = '탐색할 요일을 하나 이상 선택해 주세요.');
      return;
    }
    if (value && !enabled) {
      final agreed = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('접속을 쉬면서 세션을 관측할까요?'),
          content: const Text(
            '탐색 구간에는 평소 자동 수집과 앱 복귀 수집을 멈춰 새 공지·과제 알림이 늦어질 수 있어요. 기존 세션만 확인하며 새 로그인은 하지 않아요. 다른 기기 접속이 있으면 관측에 영향을 줘요. 종료하면 원래 수집 설정을 적용해요.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('취소'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('탐색 켜기'),
            ),
          ],
        ),
      );
      if (agreed != true) return;
    }
    setState(() => busy = true);
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('sessionProbeMode', scheduled ? 'scheduled' : 'manual');
      await p.setStringList(
        'sessionProbeDays',
        (days.toList()..sort()).map((d) => '$d').toList(),
      );
      await p.setInt('sessionProbeStartHour', start);
      await p.setInt('sessionProbeEndHour', end);
      await p.setInt('sessionProbeInitialMinutes', gap);
      final store = await Store.open();
      try {
        final epoch = await store.meta('sessionEpoch');
        if (value && epoch != null) {
          await SessionLifetimeRepository(store).change(epoch, (state) {
            state.targetMinutes = gap;
          });
        }
        await store.log(
          'sync',
          value ? '세션 탐색 설정' : '세션 탐색 종료',
          value
              ? '${scheduled ? "요일 예약" : "직접 시작"} · 첫 유휴 목표 $gap분 · 새 로그인 안 함'
              : '원래 자동 수집 선택과 간격을 다시 적용해요.',
        );
      } finally {
        await store.db.close();
      }
      await setExclusiveSessionLifetimeTest(value);
      if (mounted) {
        setState(
          () => message = value
              ? '탐색 설정을 저장했어요. 요청 시각은 Android 실행 조건에 따라 늦어질 수 있어요.'
              : '탐색을 종료하고 원래 수집 설정을 적용했어요.',
        );
      }
    } catch (_) {
      if (mounted) {
        setState(() => message = '작업 예약을 확인하지 못했어요. 상태를 새로 확인해 주세요.');
      }
    } finally {
      await load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final active = savedPolicy.activeAt(DateTime.now());
    return Scaffold(
      appBar: AppBar(
        title: const Text('세션 유지 시간 탐색'),
        actions: [
          IconButton(
            onPressed: busy ? null : load,
            tooltip: '관측 새로고침',
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: ListTile(
              leading: Icon(active ? Icons.science : Icons.schedule),
              title: Text(
                !enabled
                    ? '탐색 꺼짐'
                    : active
                    ? '탐색 구간 · 평소 수집 일시 중지'
                    : '예약 대기 · 평소 수집 유지',
              ),
              subtitle: const Text('실제 학교의 만료 시간을 확정하는 기능은 아니에요.'),
            ),
          ),
          const SizedBox(height: 16),
          SegmentedButton<bool>(
            segments: const [
              ButtonSegment(value: false, label: Text('직접 시작')),
              ButtonSegment(value: true, label: Text('요일·시간 예약')),
            ],
            selected: {scheduled},
            onSelectionChanged: busy
                ? null
                : (v) => setState(() => scheduled = v.single),
          ),
          if (scheduled) ...[
            const SizedBox(height: 16),
            Wrap(
              spacing: 6,
              children: [
                for (var d = 1; d <= 7; d++)
                  FilterChip(
                    label: Text(
                      const ['월', '화', '수', '목', '금', '토', '일'][d - 1],
                    ),
                    selected: days.contains(d),
                    onSelected: busy
                        ? null
                        : (v) => setState(() {
                            if (v) {
                              days.add(d);
                            } else {
                              days.remove(d);
                            }
                          }),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<int>(
              key: ValueKey('probe-start-$start'),
              initialValue: start,
              decoration: const InputDecoration(labelText: '시작 시각 (한국 시간)'),
              items: [
                for (var h = 0; h < 24; h++)
                  DropdownMenuItem(value: h, child: Text('$h:00')),
              ],
              onChanged: busy ? null : (v) => setState(() => start = v!),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<int>(
              key: ValueKey('probe-end-$end'),
              initialValue: end,
              decoration: const InputDecoration(labelText: '종료 시각'),
              items: [
                for (var h = 1; h <= 24; h++)
                  DropdownMenuItem(value: h, child: Text('$h:00')),
              ],
              onChanged: busy ? null : (v) => setState(() => end = v!),
            ),
            const Text('주말 기본값은 토·일 종일이에요. 종료가 시작보다 이르면 다음 날까지 이어져요.'),
          ],
          const SizedBox(height: 16),
          DropdownButtonFormField<int>(
            key: ValueKey('probe-gap-$gap'),
            initialValue: gap,
            decoration: const InputDecoration(labelText: '첫 무요청 목표'),
            items: [
              for (final n in [15, 30, 60, 120, 240, 480, 720, 1440])
                DropdownMenuItem(value: n, child: Text(duration(n))),
            ],
            onChanged: busy ? null : (v) => setState(() => gap = v!),
          ),
          const SizedBox(height: 12),
          const Text(
            '목표 시간 동안 학교 요청 없이 기다린 뒤 기존 세션을 확인해요. 성공하면 목표를 늘리고, 인증 종료와 통신 오류는 구분해 기록해요. 앱에서 직접 원문을 조회하면 유휴 시간이 다시 시작될 수 있어요.',
          ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: busy ? null : () => apply(true),
            child: Text(enabled ? '탐색 설정 저장' : '탐색 시작'),
          ),
          if (enabled)
            OutlinedButton(
              onPressed: busy ? null : () => apply(false),
              child: const Text('탐색 종료·평소 수집 복원'),
            ),
          if (message != null)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Text(message!),
            ),
          if (snapshot != null) ...[
            const Divider(),
            Text(
              '앱 무요청 후 재사용 성공: ${snapshot!.maxIdleMs == 0 ? "아직 관측 전" : duration(snapshot!.maxIdleMs ~/ 60000)}',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            Text(
              '인증 확인 ${snapshot!.successes}회 · 인증 종료 ${snapshot!.losses}회 · 통신 오류 ${snapshot!.networkErrors}회',
            ),
            if (snapshot!.lost)
              const Text(
                '세션이 종료됐어요. 탐색을 위한 자동 재로그인은 하지 않아요. 학교 연결을 다시 준비한 뒤 관측할 수 있어요.',
              ),
            ExpansionTile(
              title: const Text('최근 관측 기록'),
              children: [
                for (final row in snapshot!.history.reversed.take(10))
                  ListTile(
                    title: Text(switch (row['kind']) {
                      'validated' => '기존 세션 확인',
                      'authenticationLost' => '인증 종료 · 원인 미확정',
                      'networkError' => '통신 오류 · 측정 제외',
                      _ => '관측 상태 변경',
                    }),
                    subtitle: Text(
                      '${formatDate(DateTime.fromMillisecondsSinceEpoch(row['at'] as int, isUtc: true))}${row['idleMs'] is int ? " · 유휴 ${duration((row['idleMs'] as int) ~/ 60000)}" : ""}',
                    ),
                  ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

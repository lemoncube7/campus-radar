import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'ai.dart';
import 'ai_automation.dart';
import 'ai_pages.dart';
import 'campus.dart';
import 'services.dart';
import 'main.dart';
import 'features.dart';

class AutomationControls extends StatefulWidget {
  const AutomationControls({super.key});
  @override
  State<AutomationControls> createState() => _AutomationControlsState();
}

class _AutomationControlsState extends State<AutomationControls> {
  bool auto = false, summary = false, busy = true;
  String scope = 'recent', message = '';
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    Store? s;
    try {
      s = await Store.open();
      final a = await s.meta('aiAuto') == 'yes',
          d = await s.meta('aiSummary') == 'yes',
          sc = await s.meta('aiScope') ?? 'recent';
      if (mounted) {
        setState(() {
          auto = a;
          summary = d;
          scope = sc;
          busy = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          busy = false;
          message = "설정을 읽지 못했습니다. 화면을 다시 열어 주세요.";
        });
      }
    } finally {
      await s?.db.close();
    }
  }

  Future<void> save() async {
    setState(() => busy = true);
    final s = await Store.open();
    try {
      if ((auto || summary) &&
          (await credentials.read(key: 'geminiApiKey') == null ||
              await s.meta('aiConsent') != aiConsentVersion)) {
        throw const AiFailure('먼저 위에서 개인 키와 공지 외부 전송 동의를 저장해 주세요.');
      }
      final oldScope = await s.meta('aiScope');
      if (auto && (await s.meta('aiAuto') != 'yes' || oldScope != scope)) {
        if (scope == 'new') {
          await s.setMeta(
            'aiBaseline',
            jsonEncode((await s.notices()).map((n) => n.id).toList()),
          );
        }
        await s.db.delete('meta', where: 'id LIKE ?', whereArgs: ['aiQueue:%']);
      }
      await s.setMeta('aiScope', scope);
      await s.setMeta('aiAuto', auto ? 'yes' : 'no');
      await s.setMeta('aiSummary', summary ? 'yes' : 'no');
      final p = await SharedPreferences.getInstance();
      await p.setBool('aiSummaryEnabled', summary);
      if (!summary) {
        await p.remove('aiSummaryText');
        await s.setMeta('aiSummaryText', '');
      }
      await enqueueNotices(s);
      await s.log(
        'ai',
        'AI 자동화 설정 저장',
        '공지 자동 분석 ${auto ? "켬" : "끔"} · 요약 ${summary ? "켬" : "끔"} · 범위 $scope',
      );
      if (auto || summary) {
        await scheduleSummaryWarmup(
          p.getInt('aiDailyHour') ?? 18,
          p.getInt('aiDailyMinute') ?? 0,
          p.getBool('aiDailyEnabled') ?? false,
        );
        await scheduleAiWork();
        unawaited(processAiWork());
      }
      if (mounted) {
        setState(
          () => message = '저장했습니다. AI 일정함에서 진행 상황을 확인하세요. 실행 중 요청은 완료 후 중지됩니다.',
        );
      }
    } catch (e) {
      if (mounted) setState(() => message = userError(e));
    } finally {
      await s.db.close();
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Divider(height: 40),
      const Text(
        '자동 분석과 요약',
        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
      ),
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('공지 자동 순차 분석'),
        subtitle: const Text(
          '선택 범위의 공지 본문을 가져와 Google에 전송합니다. 분석 결과는 일정함에 모으며 캘린더에 자동 등록하지 않습니다.',
        ),
        value: auto,
        onChanged: busy ? null : (v) => setState(() => auto = v),
      ),
      DropdownButtonFormField<String>(
        key: ValueKey(scope),
        initialValue: scope,
        decoration: const InputDecoration(labelText: '처음 분석할 공지 범위'),
        items: const [
          DropdownMenuItem(value: 'new', child: Text('설정 이후 신규 공지만')),
          DropdownMenuItem(value: 'recent', child: Text('최근 7일 (권장)')),
          DropdownMenuItem(value: 'all', child: Text('현재 수집된 학기 전체')),
        ],
        onChanged: busy ? null : (v) => setState(() => scope = v ?? 'recent'),
      ),
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('AI 데일리 요약 사용'),
        subtitle: const Text(
          '미완료 과제·콘텐츠의 과목명·제목·마감·상태를 Google에 전송하는 데 동의합니다. LLM이 우선 항목을 고르고 실제 일정 값은 앱이 표시합니다. 실패하면 기본 요약을 사용합니다.',
        ),
        value: summary,
        onChanged: busy ? null : (v) => setState(() => summary = v),
      ),
      if (message.isNotEmpty) Text(message),
      FilledButton.tonal(
        onPressed: busy ? null : save,
        child: const Text('자동화 설정 저장·시작'),
      ),
    ],
  );
}

class AiInboxPage extends StatefulWidget {
  const AiInboxPage({super.key});
  @override
  State<AiInboxPage> createState() => _AiInboxState();
}

class _AiInboxState extends State<AiInboxPage> with WidgetsBindingObserver {
  Timer? timer;
  bool loading = true, auto = false;
  String filter = 'review', error = '';
  List<Map<String, dynamic>> candidates = [], jobs = [];
  int done = 0, total = 0;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    load();
    timer = Timer.periodic(const Duration(seconds: 3), (_) {
      if (WidgetsBinding.instance.lifecycleState == AppLifecycleState.resumed) {
        load();
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  bool reading = false;
  Future<void> load() async {
    if (reading) return;
    reading = true;
    Store? s;
    try {
      s = await Store.open();
      final notices = await s.notices();
      final list = <Map<String, dynamic>>[], queue = <Map<String, dynamic>>[];
      final records = await s.db.query(
        'meta',
        where: 'id LIKE ?',
        whereArgs: ['aiCandidate:%'],
      );
      final seen = <String>{};
      for (final r in records) {
        final record = Map<String, dynamic>.from(
          jsonDecode(r['value'] as String),
        );
        final n = CampusNotice.fromJson(
          Map<String, dynamic>.from(record['notice']),
        );
        final c = ScheduleCandidate.parse(
          Map<String, dynamic>.from(record['candidate']),
          '${n.title}\n${n.body}',
        );
        final k = record['key'] as String,
            st = jsonDecode(await s.meta('aiState:$k') ?? '{}') as Map;
        final current = notices.where((x) => x.id == n.id).firstOrNull;
        final stale =
            current == null ||
            noticeFingerprint(current) != noticeFingerprint(n);
        if (stale && st['status'] != 'confirmed') continue;
        seen.add(k);
        list.add({'notice': n, 'candidate': c, 'key': k, 'state': st});
      }
      for (final n in notices) {
        final raw = await s.meta('aiCache:${n.id}:${noticeFingerprint(n)}');
        if (raw != null) {
          for (final e in jsonDecode(raw) as List) {
            final c = ScheduleCandidate.parse(
              Map<String, dynamic>.from(e),
              '${n.title}\n${n.body}',
            );
            final k = candidateKey(n, c);
            final state = jsonDecode(await s.meta('aiState:$k') ?? '{}') as Map;
            if (seen.add(k)) {
              list.add({'notice': n, 'candidate': c, 'key': k, 'state': state});
            }
          }
        }
        final q = await s.meta('aiQueue:${n.id}');
        if (q != null) {
          queue.add({'id': n.id, ...Map<String, dynamic>.from(jsonDecode(q))});
        }
      }
      final enabled = await s.meta('aiAuto') == 'yes';
      if (mounted) {
        setState(() {
          candidates = list;
          jobs = queue;
          total = queue.length;
          done = queue
              .where((j) => ['done', 'empty'].contains(j['status']))
              .length;
          auto = enabled;
          loading = false;
          error = '';
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          error = '일정함을 읽지 못했습니다. 다시 확인해 주세요.';
          loading = false;
        });
      }
    } finally {
      await s?.db.close();
      reading = false;
    }
  }

  Future<void> state(String key, String value) async {
    final s = await Store.open();
    try {
      final old = jsonDecode(await s.meta('aiState:$key') ?? '{}') as Map;
      await s.setMeta('aiState:$key', jsonEncode({...old, 'status': value}));
    } finally {
      await s.db.close();
    }
    await load();
  }

  Future<void> pause() async {
    final s = await Store.open();
    try {
      if (!auto &&
          (await credentials.read(key: 'geminiApiKey') == null ||
              await s.meta('aiConsent') != aiConsentVersion)) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('AI 설정에서 키와 전송 동의를 먼저 저장하세요.')),
          );
        }
        return;
      }
      await s.setMeta('aiAuto', auto ? 'no' : 'yes');
      await s.log(
        'ai',
        auto ? 'AI 대기열 일시 중지' : 'AI 대기열 재개',
        '진행 중 요청은 완료 후 중지됩니다.',
      );
    } finally {
      await s.db.close();
    }
    if (!auto) {
      await scheduleAiWork();
      unawaited(processAiWork());
    }
    await load();
  }

  Future<void> retry(String id) async {
    if (!auto) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('대기열을 재개한 뒤 재시도해 주세요.')));
      return;
    }
    final s = await Store.open();
    try {
      final q = jsonDecode(await s.meta('aiQueue:$id') ?? '{}') as Map;
      await s.setMeta('aiCooldown', '0');
      await s.setMeta(
        'aiQueue:$id',
        jsonEncode({...q, 'status': 'pending', 'attempts': 0, 'retryAt': ''}),
      );
    } finally {
      await s.db.close();
    }
    await scheduleAiWork();
    unawaited(processAiWork());
    await load();
  }

  @override
  Widget build(BuildContext context) {
    final list = candidates.where((r) {
      final status = (r['state'] as Map)['status'] ?? 'review';
      return filter == 'all' || status == filter;
    }).toList();
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI 일정함'),
        actions: [
          IconButton(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AiSettingsPage()),
            ),
            icon: const Icon(Icons.tune),
            tooltip: 'AI 설정',
          ),
          IconButton(
            onPressed: load,
            icon: const Icon(Icons.refresh),
            tooltip: '새로고침',
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '$done / $total개 분석 완료',
                      style: const TextStyle(
                        fontSize: 23,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '확인할 일정 ${candidates.where((r) => (r['state'] as Map)['status'] == null || (r['state'] as Map)['status'] == 'review').length}개 · ${auto ? '자동 분석 켜짐' : '자동 분석 꺼짐'}',
                    ),
                    if (total > 0) LinearProgressIndicator(value: done / total),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      children: [
                        TextButton(
                          onPressed: pause,
                          child: Text(auto ? '일시 중지' : '대기열 재개'),
                        ),
                        TextButton(
                          onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const AiSettingsPage(),
                            ),
                          ),
                          child: const Text('키·범위 설정'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const Text(
              'AI 결과는 일정 후보입니다. 날짜·원문을 확인해 확정하세요. 백그라운드 실행 시각은 운영체제에 따라 지연될 수 있습니다.',
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 6,
              children: [
                for (final f in {
                  'review': '확인 필요',
                  'confirmed': '확정',
                  'hold': '보류',
                  'excluded': '제외',
                  'all': '전체',
                }.entries)
                  ChoiceChip(
                    label: Text(f.value),
                    selected: filter == f.key,
                    onSelected: (_) => setState(() => filter = f.key),
                  ),
              ],
            ),
            if (loading) const LinearProgressIndicator(),
            if (error.isNotEmpty) Text(error),
            if (!loading && list.isEmpty)
              const Padding(
                padding: EdgeInsets.all(30),
                child: Text('이 분류에 일정이 없습니다. 자동 분석을 켜거나 공지 상세에서 직접 분석해 보세요.'),
              ),
            for (final row in list)
              Builder(
                builder: (context) {
                  final n = row['notice'] as CampusNotice,
                      c = row['candidate'] as ScheduleCandidate;
                  final st = row['state'] as Map;
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            n.course,
                            style: Theme.of(context).textTheme.labelMedium,
                          ),
                          Text(
                            st['title'] ?? c.title,
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          Text(
                            '${st['date'] ?? (c.date.isEmpty ? '날짜 확인 필요' : c.date)} ${st['start'] != null && st['allDay'] != true
                                ? formatDate(DateTime.parse(st['start']))
                                : st['allDay'] == true
                                ? '종일'
                                : c.time} · ${c.action == 'add'
                                ? '새 일정'
                                : c.action == 'change'
                                ? '변경 확인'
                                : '취소 확인'}',
                          ),
                          if (st['calendarSent'] == true)
                            const Chip(label: Text('캘린더 전송됨')),
                          if (c.uncertainty.isNotEmpty) Text(c.uncertainty),
                          ExpansionTile(
                            tilePadding: EdgeInsets.zero,
                            title: const Text('근거·공지 원문'),
                            children: [
                              SelectableText('근거: ${c.evidence}\n\n${n.body}'),
                            ],
                          ),
                          Wrap(
                            spacing: 6,
                            children: [
                              if (c.action == 'add')
                                TextButton(
                                  onPressed: () async {
                                    await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => CalendarDraftPage(
                                          itemKey: row['key'] as String,
                                          title:
                                              st['title'] ??
                                              '[${n.course}] ${c.title}',
                                          description:
                                              '공지: ${n.title}\n근거: ${c.evidence}\nhttps://dcs-learning.cnu.ac.kr/home',
                                          start:
                                              DateTime.tryParse(
                                                st['start'] ?? '',
                                              ) ??
                                              (c.date.isEmpty
                                                  ? null
                                                  : c.time.isEmpty
                                                  ? strictDate(c.date)
                                                  : DateTime.parse(
                                                      '${c.date}T${c.time}:00+09:00',
                                                    )),
                                          allDay:
                                              st['allDay'] as bool? ??
                                              c.time.isEmpty,
                                        ),
                                      ),
                                    );
                                    await load();
                                  },
                                  child: const Text('확정·수정'),
                                ),
                              if (c.action != 'add')
                                const Text('기존 캘린더 일정을 직접 확인해 변경·취소를 반영하세요.'),
                              TextButton(
                                onPressed: () =>
                                    state(row['key'] as String, 'hold'),
                                child: const Text('보류'),
                              ),
                              TextButton(
                                onPressed: () =>
                                    state(row['key'] as String, 'excluded'),
                                child: const Text('제외'),
                              ),
                              if (filter != 'review')
                                TextButton(
                                  onPressed: () =>
                                      state(row['key'] as String, 'review'),
                                  child: const Text('다시 검토'),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            const SizedBox(height: 20),
            Text('공지 처리 현황', style: Theme.of(context).textTheme.titleMedium),
            ...jobs.map(
              (j) => ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(j['title'] ?? '공지'),
                subtitle: Text(
                  '${{'pending': '분석 대기', 'running': '분석 중', 'done': '후보 있음', 'empty': '일정 없음', 'failed': '실패'}[j['status']] ?? j['status']} ${j['error'] ?? ''}',
                ),
                trailing: j['status'] == 'failed'
                    ? TextButton(
                        onPressed: () => retry(j['id'] as String),
                        child: const Text('재시도'),
                      )
                    : null,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class AiDailyCard extends StatefulWidget {
  const AiDailyCard({super.key});
  @override
  State<AiDailyCard> createState() => _AiDailyCardState();
}

class _AiDailyCardState extends State<AiDailyCard> {
  String? text;
  bool enabled = false, busy = false;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    Store? s;
    try {
      s = await Store.open();
      final on = await s.meta('aiSummary') == 'yes';
      final p = await SharedPreferences.getInstance();
      await p.reload();
      final last = await s.meta('lastSuccess');
      final now = DateTime.now().toUtc();
      final hour = p.getInt('aiSummaryHour') ?? -99;
      final valid =
          on &&
          p.getString('aiSummaryLast') == last &&
          p.getString('aiSummaryDay') == schoolDay(now) &&
          (p.getInt('aiSummaryExpires') ?? 0) > now.millisecondsSinceEpoch &&
          now.millisecondsSinceEpoch ~/ 3600000 - hour >= 0 &&
          now.millisecondsSinceEpoch ~/ 3600000 - hour <= 1;
      if (mounted) {
        setState(() {
          enabled = on;
          text = valid ? p.getString('aiSummaryText') : null;
        });
      }
    } catch (_) {
      if (mounted) setState(() => text = null);
    } finally {
      await s?.db.close();
    }
  }

  Future<void> generate() async {
    setState(() => busy = true);
    Store? s;
    try {
      s = await Store.open();
      await s.setMeta('aiSummaryFailHash', '');
      await prepareAiSummary(s);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('요약을 준비하지 못했습니다. 잠시 후 다시 확인해 주세요.')),
        );
      }
    } finally {
      await s?.db.close();
      if (mounted) setState(() => busy = false);
    }
    await load();
  }

  @override
  Widget build(BuildContext context) => Card(
    child: ExpansionTile(
      leading: const Icon(Icons.auto_awesome),
      title: const Text('AI 데일리 요약'),
      subtitle: Text(
        enabled
            ? (text == null
                  ? '기본 현황을 확인하세요 · AI 요약 준비 대기'
                  : '수집된 목록에서 우선 확인할 일')
            : '선택 기능 · AI 설정에서 켤 수 있어요',
      ),
      childrenPadding: const EdgeInsets.all(16),
      expandedCrossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (text != null) SelectableText(text!),
        if (enabled)
          TextButton(
            onPressed: busy ? null : generate,
            child: Text(busy ? '준비 중…' : '지금 요약 준비'),
          ),
        TextButton(
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AiSettingsPage()),
          ),
          child: const Text('AI 설정'),
        ),
      ],
    ),
  );
}

class SettingsHub extends StatelessWidget {
  final bool connected;
  final VoidCallback connect, logout, test;
  const SettingsHub({
    super.key,
    required this.connected,
    required this.connect,
    required this.logout,
    required this.test,
  });
  @override
  Widget build(BuildContext context) {
    void page(Widget w) =>
        Navigator.push(context, MaterialPageRoute(builder: (_) => w));
    return Scaffold(
      appBar: AppBar(title: const Text('설정')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: ListTile(
              leading: Icon(
                connected ? Icons.verified_user_outlined : Icons.person_outline,
              ),
              title: Text(connected ? '포털 연결됨' : '포털 연결 필요'),
              subtitle: const Text('계정은 이 기기의 보안 저장소에 보관합니다.'),
              trailing: connected ? null : const Icon(Icons.chevron_right),
              onTap: connected ? null : connect,
            ),
          ),
          _setting(
            context,
            Icons.auto_awesome,
            'AI 분석·자동화',
            '개인 키, 분석 범위, 데일리 요약',
            () => page(const AiSettingsPage()),
          ),
          _setting(
            context,
            Icons.calendar_month_outlined,
            '캘린더 전송',
            '저장할 캘린더와 자동 전송',
            () => page(const CalendarSettingsPage()),
          ),
          _setting(
            context,
            Icons.notifications_outlined,
            '데일리 알림',
            '매일 요약 시각·알림 테스트',
            () => page(const DailySummaryPage()),
          ),
          _setting(
            context,
            Icons.battery_charging_full,
            '배터리·백그라운드 상태',
            '앱 배터리 제한과 수집 예약',
            () => page(const BackgroundStatusPage()),
          ),
          _setting(
            context,
            Icons.history,
            '활동 로그',
            '수집·알림·AI·캘린더·업데이트',
            () => page(const HistoryPage(notificationsOnly: false)),
          ),
          _setting(
            context,
            Icons.change_circle_outlined,
            '변경 이력',
            '과제와 콘텐츠의 변경 사항',
            () => page(const ChangesPage()),
          ),
          _setting(
            context,
            Icons.system_update_alt,
            '앱 업데이트',
            '현재 0.2.0',
            () => page(const UpdatePage()),
          ),
          if (connected)
            _setting(
              context,
              Icons.notifications_active_outlined,
              '알림 표시 테스트',
              '기기에 테스트 알림 요청',
              test,
            ),
          const Divider(),
          if (connected)
            _setting(
              context,
              Icons.logout,
              '로그아웃',
              '계정·앱 데이터 삭제 범위를 확인합니다.',
              logout,
            ),
        ],
      ),
    );
  }

  Widget _setting(
    BuildContext c,
    IconData icon,
    String title,
    String subtitle,
    VoidCallback action,
  ) => ListTile(
    contentPadding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
    leading: Icon(icon),
    title: Text(title),
    subtitle: Text(subtitle),
    trailing: const Icon(Icons.chevron_right),
    onTap: action,
  );
}

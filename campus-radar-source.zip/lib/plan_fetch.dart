import 'dart:async';
import 'dart:io';
import 'package:flutter/services.dart';
import 'campus.dart';

String planFailure(Object error) {
  if (error is TimeoutException) return '강의계획서 응답 시간이 초과됐습니다. 잠시 후 다시 시도해 주세요.';
  if (error is SocketException) return '강의계획서 연결에 실패했습니다. 인터넷 연결을 확인해 주세요.';
  if (error is PlatformException) {
    if (error.code == 'syllabus_cancelled') return '강의계획서 불러오기를 취소했습니다.';
    return error.message ?? '강의계획서 화면을 읽지 못했습니다.';
  }
  if (error is CampusException) return error.message;
  return '강의계획서 응답을 처리하지 못했습니다. 기존 저장본은 유지합니다.';
}

/// Only retry connection failures; never turn malformed or rejected data into success.
Future<T> retryPlanConnection<T>(
  Future<T> Function() request, {
  Future<void> Function()? beforeRetry,
}) async {
  try {
    return await request();
  } on SocketException {
    await beforeRetry?.call();
  } on TimeoutException {
    await beforeRetry?.call();
  }
  await Future<void>.delayed(const Duration(milliseconds: 500));
  return request();
}

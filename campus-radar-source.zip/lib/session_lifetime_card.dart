import 'dart:io';
import 'package:flutter/material.dart';
import 'app_storage.dart';
import 'services.dart';
import 'session_lifetime.dart';
import 'session_lifetime_probe.dart';
import 'session_lifetime_repository.dart';
import 'task_presentation.dart';

class SessionLifetimeCard extends StatefulWidget {
  final Future<void> Function()? onTestChanged;
  const SessionLifetimeCard({super.key, this.onTestChanged});
  @override
  State<SessionLifetimeCard> createState() => _SessionLifetimeCardState();
}

class _SessionLifetimeCardState extends State<SessionLifetimeCard> {
  SessionLifetime? state;
  bool active = false, busy = false;
  String? error;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    Store? store;
    try {
      final enabled = await sessionLifetimeProbeEnabled();
      store = await Store.open();
      final epoch = await store.meta('sessionEpoch') ?? '';
      final snapshot = await SessionLifetimeRepository(store).read(epoch);
      if (mounted) {
        setState(() {
          state = snapshot;
          active = enabled;
          error = null;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() => error = '관측 기록을 읽지 못했어요. 학교 연결과 기존 기록은 유지해요.');
      }
    } finally {
      await store?.db.close();
    }
  }

  String duration(int ms) {
    if (ms < 60000) return '${ms ~/ 1000}초';
    final minutes = ms ~/ 60000;
    return minutes < 60 ? '$minutes분' : '${minutes ~/ 60}시간 ${minutes % 60}분';
  }

  String event(Map<String, dynamic> entry) => switch (entry['kind']) {
    'validated' =>
      entry['idleMs'] is int
          ? '${duration(entry['idleMs'] as int)} 무요청 뒤 인증 확인'
          : '인증 확인 · 유휴 시간은 측정 제외',
    'newSession' => '새 로그인 세션 관측 시작',
    'adoptedSession' => '기존 세션 관측 시작 · 생성 시각 미상',
    'authenticationLost' => '인증 종료 · 만료/다른 기기 접속 원인 미확정',
    'networkError' => '통신 실패 · 만료 시간 계산에서 제외',
    'responseError' => '응답 확인 실패 · 만료 시간 계산에서 제외',
    'observationInterrupted' => '작업 중단/시간 변경 · 유휴 관측 구간 초기화',
    _ => '관측 기록',
  };

  @override
  Widget build(BuildContext context) {
    final value = state;
    final next = value?.nextProbeAt(
      DateTime.now().toUtc().millisecondsSinceEpoch,
    );
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '세션 지속시간 탐색',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                IconButton(
                  onPressed: load,
                  icon: const Icon(Icons.refresh),
                  tooltip: '관측 새로고침',
                ),
              ],
            ),
            const Text(
              '학교 연결 시간을 이 기기에 기록해요. 가장 오래 재사용한 시간과 무요청 유지 시간을 구분하며, 인증 종료 원인을 단정하지 않아요.',
            ),
            if (error != null) Text(error!),
            if (value != null) ...[
              const SizedBox(height: 12),
              Text(
                value.maxIdleMs > 0
                    ? '앱 요청 없이 재사용: ${duration(value.maxIdleMs)} 확인'
                    : '무요청 유지 시간: 아직 관측 중',
              ),
              Text(
                value.maxAgeMs > 0
                    ? '재로그인 없이 인증 확인: 최소 ${duration(value.maxAgeMs)}'
                    : '전체 세션 유지 시간: 아직 관측 중',
              ),
              Text(
                '인증 확인 ${value.successes}회 · 인증 종료 ${value.losses}회 · 통신 실패 ${value.networkErrors}회',
              ),
              const Text(
                '인증 종료만으로 만료 시간의 상한을 정하지 않아요. 기록은 이 앱의 연결만 관측해요. 외부 브라우저 접속 여부는 알 수 없어요.',
              ),
            ],
            if (Platform.isAndroid)
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('전용 세션 탐색 테스트'),
                value: active,
                subtitle: const Text(
                  '테스트 중에는 평소 자동 수집·앱 시작/복귀 수집·AI 원문 자동 수집을 멈춰요. 기준 세션을 준비한 뒤 탐색 요청만 보내며, 끄면 원래 수집 설정으로 복원해요.',
                ),
                onChanged: busy
                    ? null
                    : (enabled) async {
                        setState(() => busy = true);
                        try {
                          await setExclusiveSessionLifetimeTest(enabled);
                          await load();
                          await widget.onTestChanged?.call();
                        } catch (_) {
                          await load();
                          await widget.onTestChanged?.call();
                          if (mounted) {
                            setState(
                              () => error =
                                  '탐색 설정 또는 작업 예약을 변경하지 못했어요. 다시 선택해 주세요.',
                            );
                          }
                        } finally {
                          if (mounted) setState(() => busy = false);
                        }
                      },
              ),
            if (active && Platform.isAndroid)
              Text(
                value?.lost == true
                    ? '세션이 끊겼어요. 설정한 재로그인 대기 후 다음 회차를 준비해요. 직접 재연결로 설정했다면 사용자가 연결할 때까지 기다려요.'
                    : next == null
                    ? '테스트 기준 연결을 준비하거나 진행 중인 요청이 끝나기를 기다리고 있어요.'
                    : '다음 목표: ${value!.targetMinutes}분 무요청 · ${formatDate(DateTime.fromMillisecondsSinceEpoch(next, isUtc: true))} 이후 실행 가능. 실제 실행은 Android 조건에 따라 늦어질 수 있어요.',
              ),
            const Text(
              '중간에 수동 조회를 하면 유휴 시간이 다시 시작돼요. 인증 종료가 만료 때문인지 다른 기기 접속 때문인지는 구분할 수 없어요. 종료 후에는 평소 수집 설정을 다시 적용해요.',
            ),
            if (value != null && value.history.isNotEmpty)
              ExpansionTile(
                tilePadding: EdgeInsets.zero,
                title: const Text('최근 관측 기록'),
                children: [
                  for (final entry in value.history.reversed.take(8))
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      dense: true,
                      title: Text(event(entry)),
                      subtitle: Text(
                        formatDate(
                          DateTime.fromMillisecondsSinceEpoch(
                            entry['at'] as int,
                            isUtc: true,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}

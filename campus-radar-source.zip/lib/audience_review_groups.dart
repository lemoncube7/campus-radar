import 'package:flutter/material.dart';
import 'app_storage.dart';
import 'audience_review_repository.dart';
import 'ai_protocol.dart';
import 'campus_models.dart';
import 'course_labels.dart';
import 'transient_message.dart';

Map<String, List<Map<String, dynamic>>> audienceReviewGroups(
  List<Map<String, dynamic>> rows,
) {
  final groups = <String, List<Map<String, dynamic>>>{};
  for (final row in rows) {
    final candidate = row['candidate'] as ScheduleCandidate;
    final state = row['state'] as Map;
    if ((state['status'] ?? 'review') != 'review' ||
        state['audienceConfirmed'] == true ||
        candidate.action != 'add' ||
        !['conditional', 'optional'].contains(candidate.condition)) {
      continue;
    }
    final notice = row['notice'] as CampusNotice;
    final id = '${notice.id}:${candidate.category}:${candidate.condition}';
    groups.putIfAbsent(id, () => []).add(row);
  }
  groups.removeWhere((_, rows) => rows.length < 2);
  return groups;
}

class AudienceReviewGroups extends StatelessWidget {
  final List<Map<String, dynamic>> rows;
  final Future<void> Function() onChanged;
  const AudienceReviewGroups({
    super.key,
    required this.rows,
    required this.onChanged,
  });

  Future<void> choose(
    BuildContext context,
    List<Map<String, dynamic>> group,
  ) async {
    final selected = <String>{};
    var applying = false;
    final keys = group.map((r) => r['key'] as String).toList();
    final receipt = await showModalBottomSheet<AudienceReviewReceipt>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheet) => StatefulBuilder(
        builder: (ctx, update) => SafeArea(
          child: SizedBox(
            height: MediaQuery.sizeOf(ctx).height * .75,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '나에게 해당하는 항목',
                        style: Theme.of(ctx).textTheme.titleLarge,
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        '해당하는 항목을 선택해 주세요. 선택하지 않은 항목은 제외하고, 선택한 항목은 날짜·시간 검토 목록에 남겨요. 일정을 자동 확정하지 않아요.',
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView(
                    children: [
                      for (final row in group)
                        Builder(
                          builder: (_) {
                            final c = row['candidate'] as ScheduleCandidate;
                            return CheckboxListTile(
                              value: selected.contains(row['key']),
                              title: Text(c.title),
                              subtitle: Text(
                                '${c.date} ${c.time}${c.uncertainty.isEmpty ? '' : '\n${c.uncertainty}'}',
                              ),
                              onChanged: (yes) => update(() {
                                if (yes == true) {
                                  selected.add(row['key'] as String);
                                } else {
                                  selected.remove(row['key']);
                                }
                              }),
                            );
                          },
                        ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: FilledButton(
                    onPressed: applying
                        ? null
                        : () async {
                            update(() => applying = true);
                            Store? store;
                            try {
                              store = await Store.open();
                              final result = await AudienceReviewRepository(
                                store,
                              ).apply(keys, selected);
                              if (ctx.mounted) Navigator.pop(ctx, result);
                            } catch (error) {
                              if (ctx.mounted) {
                                showTransientMessage(
                                  ctx,
                                  SnackBar(
                                    content: Text(
                                      error is FormatException
                                          ? error.message
                                          : '선택을 적용하지 못했어요.',
                                    ),
                                  ),
                                );
                              }
                            } finally {
                              await store?.db.close();
                              if (ctx.mounted) update(() => applying = false);
                            }
                          },
                    child: Text(
                      selected.isEmpty
                          ? '${keys.length}개 모두 해당 없음'
                          : '${selected.length}개 해당 · 나머지 제외',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
    if (receipt == null) return;
    await onChanged();
    if (!context.mounted) return;
    showTransientMessage(
      context,
      SnackBar(
        content: const Text('해당 여부를 정리했어요'),
        action: SnackBarAction(
          label: '실행 취소',
          onPressed: () async {
            Store? store;
            try {
              store = await Store.open();
              await AudienceReviewRepository(store).undo(receipt);
              await onChanged();
            } catch (error) {
              if (context.mounted) {
                showTransientMessage(
                  context,
                  SnackBar(
                    content: Text(
                      error is FormatException
                          ? error.message
                          : '실행 취소하지 못했어요.',
                    ),
                  ),
                );
              }
            } finally {
              await store?.db.close();
            }
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Column(
    children: [
      for (final group in audienceReviewGroups(rows).values)
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.person_search_outlined),
          title: Text(
            '${courseLabel((group.first['notice'] as CampusNotice).course)} · 해당 여부 한 번에 정리',
          ),
          subtitle: Text('${group.length}개 후보 중 나에게 해당하는 항목을 선택해요.'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => choose(context, group),
        ),
    ],
  );
}

/// School responses may use null/empty list for an unsubmitted report. Unknown
/// shapes must not turn into an assertion that an assignment is completed.
String submissionStatus(dynamic raw) {
  if (raw == null ||
      (raw is List && raw.isEmpty) ||
      (raw is Map && raw.isEmpty)) {
    return 'pending';
  }
  if (raw is List && raw.length == 1 && raw.single is Map) raw = raw.single;
  if (raw is! Map) return 'unknown';
  if (raw['temp_yn'] == 'Y' || raw['apply_yn'] == 'N') return 'pending';
  if (raw['report_apply_no'] != null && raw['apply_yn'] == 'Y') return 'done';
  // A report ID without explicit confirmation is not proof of completion.
  if (raw.containsKey('report_apply_no') && raw['report_apply_no'] == null) {
    return 'pending';
  }
  return 'unknown';
}

Map<String, dynamic>? taskDetail(dynamic raw) {
  if (raw is List && raw.length == 1 && raw.single is Map) raw = raw.single;
  if (raw is! Map) return null;
  if (!['report_no', 'report_nm', 'report_content'].any(raw.containsKey)) {
    return null;
  }
  return Map<String, dynamic>.from(raw);
}

String responseShape(dynamic raw) {
  if (raw == null) return 'null';
  if (raw is List) return 'List(${raw.length})';
  if (raw is Map) {
    final keys = raw.keys.map((k) => '$k').toList()..sort();
    return 'Map(${keys.take(16).join(",")})';
  }
  return raw.runtimeType.toString();
}

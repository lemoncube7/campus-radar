import 'session_exploration_page.dart';
import 'permissions_page.dart';
import 'timetable_page.dart';
import 'release_history_page.dart';
import 'app_help_page.dart';
import 'feature_recommendation.dart';
import 'ai_chat_page.dart';
import 'notice_pages.dart';
import 'home_navigation.dart';
import 'workspace_navigation.dart';
import 'ios_widget_settings.dart';
import 'task_cleanup_settings.dart';
import 'notification_settings_page.dart';
import 'widget_settings_page.dart';
import 'ai_settings_page.dart';
import 'calendar_settings_page.dart';
import 'changes_page.dart';
import 'history_page.dart';
import 'background_status_page.dart';
import 'update_page.dart';
import 'ui_refresh.dart';
import 'desktop.dart';
import 'radar_theme.dart';
import 'updates.dart';
import 'dart:io';
import 'package:flutter/material.dart';

class SettingsHub extends StatelessWidget {
  final bool connected;
  final VoidCallback connect, logout, test;
  const SettingsHub({
    super.key,
    required this.connected,
    required this.connect,
    required this.logout,
    required this.test,
  });
  @override
  Widget build(BuildContext context) {
    void page(Widget w) =>
        Navigator.push(context, MaterialPageRoute(builder: (_) => w));
    void group(String title, List<Widget> children) => page(
      Scaffold(
        appBar: AppBar(title: Text(title)),
        body: ListView(padding: const EdgeInsets.all(20), children: children),
      ),
    );
    return Scaffold(
      appBar: AppBar(title: const Text('더보기')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          ListTile(
            leading: const Icon(Icons.explore_outlined),
            title: const Text('기능 안내·빠른 설정'),
            subtitle: const Text('기능 검색 · 필요한 설정을 순서대로 안내'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => page(const AppHelpPage()),
          ),
          const FeatureRecommendation(),
          const SectionHeading('바로 열기', subtitle: '필요할 때 찾는 도구'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ActionChip(
                avatar: const Icon(Icons.fact_check_outlined, size: 18),
                label: const Text('확인할 항목'),
                onPressed: () =>
                    openWorkspaceTool(context, ScheduleView.review),
              ),
              ActionChip(
                avatar: const Icon(Icons.table_chart_outlined, size: 18),
                label: const Text('시간표'),
                onPressed: () =>
                    openWorkspaceTool(context, ScheduleView.timetable),
              ),
              ActionChip(
                avatar: const Icon(Icons.chat_bubble_outline, size: 18),
                label: const Text('AI 채팅'),
                onPressed: () => page(const AiChatPage()),
              ),
              ActionChip(
                avatar: const Icon(Icons.campaign_outlined, size: 18),
                label: const Text('모든 공지'),
                onPressed: () => page(const NoticesPage()),
              ),
              ActionChip(
                avatar: const Icon(Icons.calendar_month_outlined, size: 18),
                label: const Text('캘린더'),
                onPressed: () =>
                    openWorkspaceTool(context, ScheduleView.calendar),
              ),
            ],
          ),
          const SizedBox(height: 24),
          const SectionHeading('설정', subtitle: '연결과 표시를 내 방식대로'),
          _setting(
            context,
            Icons.account_circle_outlined,
            '학교 연결·수집',
            connected ? '포털 연결됨 · 수집 간격 · 재연결 대기' : '포털 계정 연결',
            () => group('학교 연결·수집', [
              ListTile(
                leading: Icon(
                  connected
                      ? Icons.verified_user_outlined
                      : Icons.person_outline,
                ),
                title: Text(connected ? '포털 연결됨' : '포털 연결 필요'),
                subtitle: const Text('계정은 이 기기의 보안 저장소에 보관합니다.'),
                onTap: connected
                    ? null
                    : () {
                        Navigator.pop(context);
                        connect();
                      },
              ),
              _setting(
                context,
                Icons.battery_charging_full,
                Platform.isWindows ? 'PC 자동 수집 상태' : '자동 수집·세션 설정',
                '최근 성공 · 수집 간격 · 재연결 대기',
                () => page(const BackgroundStatusPage()),
              ),
              if (!Platform.isWindows)
                _setting(
                  context,
                  Icons.verified_user_outlined,
                  '알림·백그라운드 권한',
                  '허용 상태 확인과 기기 설정',
                  () => page(const PermissionsPage()),
                ),
              if (Platform.isAndroid)
                _setting(
                  context,
                  Icons.science_outlined,
                  '세션 유지 시간 탐색',
                  '직접 시작 · 주말·요일 예약 · 무요청 관측',
                  () => page(const SessionExplorationPage()),
                ),
              if (Platform.isWindows)
                _setting(
                  context,
                  Icons.desktop_windows,
                  'PC 실행 설정',
                  '자동 수집 · 시작 프로그램 · 트레이',
                  () => page(const DesktopSettingsPage()),
                ),
              if (connected)
                _setting(
                  context,
                  Icons.login,
                  '로그인 다시 연결',
                  '현재 계정의 비밀번호를 다시 입력해요. 목록은 유지해요.',
                  () {
                    Navigator.pop(context);
                    connect();
                  },
                ),
              if (connected)
                _setting(
                  context,
                  Icons.logout,
                  '로그아웃',
                  '계정·앱 데이터 삭제 범위를 확인합니다.',
                  () {
                    Navigator.pop(context);
                    logout();
                  },
                ),
            ]),
          ),
          _setting(
            context,
            Icons.notifications_outlined,
            '알림',
            '마감 · 새 항목 · 수업 전 · 하루 요약',
            () => page(const NotificationSettingsPage()),
          ),
          _setting(
            context,
            Icons.palette_outlined,
            '화면·위젯',
            '테마 · 홈 화면 · 잠금화면',
            () => group('화면·위젯', [
              _setting(
                context,
                Icons.palette_outlined,
                '화면 테마',
                '컬러 1·컬러 2 · 시스템 설정 · 라이트 · 다크',
                () => page(const AppearancePage()),
              ),
              if (Platform.isAndroid)
                _setting(
                  context,
                  Icons.widgets_outlined,
                  '위젯·잠금화면',
                  '크기 · 위치 · 투명도 · 글씨 크기',
                  () => page(const WidgetSettingsPage()),
                ),
              if (Platform.isIOS)
                _setting(
                  context,
                  Icons.widgets_outlined,
                  'iPhone 위젯',
                  '공유 자료와 위젯 연결',
                  () => page(const IosWidgetSettings()),
                ),
              const DiscoverySettings(),
            ]),
          ),
          _setting(
            context,
            Icons.checklist,
            '할 일·시간표',
            '제출 대기 · 기한 지난 항목 · 수업·휴강',
            () => group('할 일·시간표', [
              _setting(
                context,
                Icons.checklist,
                '할 일 표시·정리',
                '제출 대기 표시 · 기한 지난 항목 · 출석 정보',
                () => page(const TaskCleanupSettings()),
              ),
              _setting(
                context,
                Icons.table_chart_outlined,
                '주간 시간표',
                '수업 시간 · 강의실 · 휴강',
                () => page(const TimetablePage()),
              ),
              _setting(
                context,
                Icons.notifications_outlined,
                '수업 전·자정 알림',
                '시간표 기준 알림 시각과 카운트다운',
                () => page(const TimetablePage(initialMode: 2)),
              ),
            ]),
          ),
          _setting(
            context,
            Icons.auto_awesome,
            'AI·캘린더',
            '공지 분석 → 일정 검토 → 캘린더 전송',
            () => group('AI·캘린더', [
              _setting(
                context,
                Icons.auto_awesome_outlined,
                'AI·자동 정리',
                '개인 키 · 공지 분석 · 자동 승인 · 요약',
                () => page(const AiSettingsPage()),
              ),
              _setting(
                context,
                Icons.calendar_month_outlined,
                Platform.isWindows ? '일정 파일 내보내기' : '캘린더 전송',
                '저장 위치와 자동 전송 설정',
                () => page(
                  Platform.isWindows
                      ? const DesktopCalendarPage()
                      : const CalendarSettingsPage(),
                ),
              ),
            ]),
          ),
          _setting(
            context,
            Icons.history,
            '기록·지원',
            '로그 저장·공유 · 변경 이력 · 업데이트',
            () => group('기록·지원', [
              _setting(
                context,
                Icons.receipt_long,
                '활동 로그',
                '수집·알림·AI·캘린더·업데이트',
                () => page(const HistoryPage(notificationsOnly: false)),
              ),
              _setting(
                context,
                Icons.track_changes,
                '변경 이력',
                '과제와 콘텐츠의 변경 사항',
                () => page(const ChangesPage()),
              ),
              _setting(
                context,
                Icons.system_update,
                '앱 업데이트',
                '현재 $installedAppVersion ($installedAppBuild) · ${channelLabel(appReleaseChannel)}',
                () => page(
                  Platform.isWindows
                      ? const DesktopUpdatePage()
                      : const UpdatePage(),
                ),
              ),
              _setting(
                context,
                Icons.history,
                '업데이트 내역',
                '버전별 변경 사항 · 정식/개발 모드',
                () => page(const ReleaseHistoryPage()),
              ),
              _setting(
                context,
                Icons.notification_add_outlined,
                '알림 표시 테스트',
                '기기에 테스트 알림 요청',
                test,
              ),
            ]),
          ),
          const SizedBox(height: 24),
          Text(
            '캠퍼스레이더 $installedAppVersion · ${channelLabel(appReleaseChannel)}',
            style: Theme.of(context).textTheme.labelSmall,
          ),
        ],
      ),
    );
  }

  Widget _setting(
    BuildContext c,
    IconData icon,
    String title,
    String subtitle,
    VoidCallback action,
  ) => Card(
    clipBehavior: Clip.antiAlias,
    child: ListTile(
      contentPadding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
      leading: Container(
        padding: const EdgeInsets.all(9),
        decoration: BoxDecoration(
          color: Theme.of(c).colorScheme.primaryContainer,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(icon, color: Theme.of(c).colorScheme.onPrimaryContainer),
      ),
      title: Text(
        title,
        style: Theme.of(
          c,
        ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
      ),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.chevron_right),
      onTap: action,
    ),
  );
}

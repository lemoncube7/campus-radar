import 'package:flutter/material.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'schedule_repository.dart';
import 'timetable_cancellations_page.dart';

Future<bool> deleteDetectedSchedule(
  BuildContext context,
  String key, {
  required SessionMark? mark,
  bool calendarSent = false,
}) async {
  final confirmed = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('감지 일정 삭제'),
      content: Text(
        calendarSent
            ? '앱 일정에서 삭제할까요? 이미 휴대폰 캘린더로 보낸 일정은 남아요. 캘린더에서도 없애려면 해당 앱에서 삭제해 주세요.'
            : '공지·AI에서 추가한 이 일정을 앱 일정에서 삭제할까요?',
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: const Text('취소'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: const Text('삭제'),
        ),
      ],
    ),
  );
  if (confirmed != true) return false;
  Store? store;
  try {
    store = await Store.open();
    return await ScheduleRepository(
      store,
    ).excludeDetectedEvent(key, mark: mark);
  } catch (e) {
    await systemLog(
      '감지 일정 삭제 실패',
      '일정을 삭제하지 못했어요. 목록을 다시 확인해 주세요.',
      kind: 'ai',
      error: e,
    );
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('삭제하지 못했어요. 목록을 새로 확인해 주세요.')),
      );
    }
    return false;
  } finally {
    await store?.db.close();
  }
}

class DetectedSchedulesPage extends StatefulWidget {
  const DetectedSchedulesPage({super.key});
  @override
  State<DetectedSchedulesPage> createState() => _DetectedSchedulesState();
}

class _DetectedSchedulesState extends State<DetectedSchedulesPage> {
  ScheduleSnapshot? data;
  SessionMark? mark;
  String? error;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    Store? store;
    try {
      store = await Store.open();
      final captured = await SessionMark.capture(store);
      final snapshot = await ScheduleRepository(store).read();
      await captured.verify(store);
      if (mounted) {
        setState(() {
          data = snapshot;
          mark = captured;
          error = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => error = '감지한 일정을 읽지 못했어요. 다시 확인해 주세요.');
      await systemLog('감지 일정 읽기 실패', '관리 목록을 불러오지 못했어요.', kind: 'ai', error: e);
    } finally {
      await store?.db.close();
    }
  }

  @override
  Widget build(BuildContext context) {
    final events =
        data?.events
            .where((r) => (r['state'] as Map)['status'] == 'confirmed')
            .toList() ??
        [];
    return Scaffold(
      appBar: AppBar(title: const Text('감지한 일정·휴강 관리')),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.event_busy),
              title: const Text('적용한 휴강 관리'),
              subtitle: Text(
                '휴강 ${data?.cancellations.length ?? 0}건 · 휴강 해제로 수업을 되돌릴 수 있어요.',
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => const TimetableCancellationsPage(),
                  ),
                );
                await load();
              },
            ),
            const Divider(),
            Text(
              '공지·AI에서 추가한 일정 ${events.length}건',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            if (error != null) ...[
              Text(error!),
              TextButton(onPressed: load, child: const Text('다시 확인')),
            ],
            if (data == null && error == null) const LinearProgressIndicator(),
            if (data != null && events.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Text('추가한 감지 일정이 없어요.'),
              ),
            for (final row in events)
              Builder(
                builder: (context) {
                  final state = row['state'] as Map;
                  final notice = row['notice'] as CampusNotice;
                  final candidate = row['candidate'] as ScheduleCandidate;
                  return Card(
                    child: ListTile(
                      title: Text(
                        courseEventTitle(
                          state['title'] as String? ?? candidate.title,
                          notice.course,
                          oldLabel: state['courseLabel'] as String?,
                        ),
                      ),
                      subtitle: Text(
                        '${state['date'] ?? candidate.date} · ${state['approvalMode'] == 'automatic' ? '자동 추가' : '추가한 일정'}',
                      ),
                      trailing: IconButton(
                        tooltip: '일정 삭제',
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          final deleted = await deleteDetectedSchedule(
                            context,
                            row['key'] as String,
                            mark: mark,
                            calendarSent: state['calendarSent'] == true,
                          );
                          if (deleted) await load();
                        },
                      ),
                      onTap: () async {
                        await navigateTo(
                          context,
                          AiInboxDestination(
                            initialFilter: 'all',
                            candidateId: row['key'] as String,
                          ),
                        );
                        await load();
                      },
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}

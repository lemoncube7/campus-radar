import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/timetable_exceptions.dart';

class NextClassOccurrence {
  final ClassSlot slot;
  final DateTime day;
  final ClassCancellation? cancellation;
  const NextClassOccurrence(this.slot, this.day, {this.cancellation});
  bool get isCancelled => cancellation != null;
  DateTime get start =>
      DateTime(day.year, day.month, day.day, slot.start ~/ 60, slot.start % 60);
  DateTime get end =>
      DateTime(day.year, day.month, day.day, slot.end ~/ 60, slot.end % 60);
}

/// [now] is the Korean wall clock, matching stored weekly timetable minutes.
NextClassOccurrence? nextClassOccurrence(
  List<ClassSlot> entries,
  List<ClassCancellation> cancellations,
  DateTime now, {
  DateTime? until,
}) {
  for (var offset = 0; offset <= 7; offset++) {
    final day = DateTime(now.year, now.month, now.day + offset);
    if (until != null &&
        day.isAfter(DateTime(until.year, until.month, until.day))) {
      break;
    }
    final dayStr = classDate(day);
    final rows = entries.where((s) => s.weekday == day.weekday).toList()
      ..sort((a, b) => a.start.compareTo(b.start));
    for (final slot in rows) {
      final cancel = cancellations
          .where((c) => c.slotId == slot.id && c.date == dayStr)
          .firstOrNull;
      final occurrence = NextClassOccurrence(slot, day, cancellation: cancel);
      final civilNow = DateTime(
        now.year,
        now.month,
        now.day,
        now.hour,
        now.minute,
        now.second,
      );
      if (occurrence.end.isAfter(civilNow)) return occurrence;
    }
  }
  return null;
}

/// "오늘 09:00 · 교404A" / "목 13:30" for a course's next class.
/// [nowKst] is the Korean wall clock.
String? nextCourseClassLabel(
  List<ClassSlot> entries,
  List<ClassCancellation> cancellations,
  String courseKey,
  DateTime nowKst,
) {
  final next = nextClassOccurrence(
    entries.where((s) => s.courseKey == courseKey).toList(),
    cancellations,
    nowKst,
  );
  if (next == null) return null;
  const days = ['월', '화', '수', '목', '금', '토', '일'];
  final today = DateTime(nowKst.year, nowKst.month, nowKst.day);
  final when = next.day == today
      ? '오늘'
      : next.day == DateTime(today.year, today.month, today.day + 1)
      ? '내일'
      : days[next.day.weekday - 1];
  final time =
      '${(next.slot.start ~/ 60).toString().padLeft(2, '0')}:${(next.slot.start % 60).toString().padLeft(2, '0')}';
  final cancelSuffix = next.isCancelled ? ' (휴강으로 인식됨)' : '';
  return [
    '$when $time$cancelSuffix',
    if (next.slot.room.isNotEmpty) next.slot.room,
  ].join(' · ');
}

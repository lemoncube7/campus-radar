import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';
import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/ai/ai_inbox_repository.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/ai/ai_state_repository.dart';
import 'package:campus_radar/ai/ai_state_models.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/schedule/timetable_model.dart';

class ScheduleSnapshot {
  final List<CampusItem> tasks;
  final List<Map<String, dynamic>> events;
  final List<ClassSlot> classes;
  final List<ClassCancellation> cancellations;
  const ScheduleSnapshot(
    this.tasks,
    this.events,
    this.classes, [
    this.cancellations = const [],
  ]);
}

String koreanDate(DateTime time) => time
    .toUtc()
    .add(const Duration(hours: 9))
    .toIso8601String()
    .substring(0, 10);
List<Map<String, dynamic>> confirmedOnDay(
  List<Map<String, dynamic>> rows,
  String day,
) => rows.where((r) {
  final st = r['state'] as Map;
  final c = r['candidate'] as ScheduleCandidate;
  if (st['status'] != 'confirmed') return false;
  final start = st['date'] as String? ?? c.date;
  final end = DateTime.tryParse(st['end'] as String? ?? '');
  var finish = end == null
      ? c.endDate
      : (st['allDay'] == true
            ? end
                  .subtract(const Duration(days: 1))
                  .toIso8601String()
                  .substring(0, 10)
            : koreanDate(end.subtract(const Duration(microseconds: 1))));
  if (finish.isEmpty) finish = start;
  return start.compareTo(day) <= 0 && finish.compareTo(day) >= 0;
}).toList();

class ScheduleRepository {
  final Store store;
  const ScheduleRepository(this.store);
  /// Same durable exclusion used by the AI inbox: keep the decision so an
  /// automatic analysis cannot immediately add the deleted event again.
  Future<bool> excludeDetectedEvent(String key, {SessionMark? mark}) async {
    await mark?.verify(store);
    final repo = AiStateRepository(store);
    final old = await repo.schedule(key);
    if (!old.isConfirmed) return false;
    await repo.saveSchedule(key, old.withDecision(ScheduleDecision.excluded));
    await store.log('ai', '감지 일정 삭제', '앱 일정 목록에서 제외했어요. 원문과 분석 기록은 유지해요.');
    return true;
  }
  Future<ScheduleSnapshot> read() async {
    final excluded = await store.excluded();
    final tasks = (await store.items())
        .where(
          (i) =>
              i.availableAt(DateTime.now().toUtc()) &&
              !excluded.contains(i.key) &&
              !i.done,
        )
        .toList();
    final inbox = await AiInboxRepository(store).read();
    return ScheduleSnapshot(
      tasks,
      inbox.candidates,
      decodeSlots(await store.meta(MetaKey.timetableEntries)),
      // Same reader as the today card and alerts: falls back to the backup.
      await readClassCancellations(store),
    );
  }
}

import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/platform/android_widget_snapshot.dart';
import 'package:campus_radar/schedule/timetable_save.dart';
import 'package:campus_radar/schedule/detected_schedules_page.dart';
import 'package:campus_radar/schedule/timetable_share_page.dart';
import 'package:campus_radar/schedule/personal_schedule_page.dart';
import 'package:campus_radar/courses/course_colors.dart';
import 'package:campus_radar/core/adaptive_content.dart';
import 'package:campus_radar/campus/campus_session.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';
import 'package:campus_radar/home/feature_discovery.dart';
import 'package:campus_radar/schedule/timetable_cancellations_page.dart';
import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'dart:io';
import 'package:campus_radar/campus/syllabus_loader.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/courses/course_catalog.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/notification_gateway.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/campus/plan_fetch.dart';
import 'dart:convert';
import 'package:campus_radar/ai/ai_automation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/timetable_grid.dart';
import 'package:campus_radar/core/ui_refresh.dart';

class TimetablePage extends StatefulWidget {
  final int initialMode;
  const TimetablePage({super.key, this.initialMode = 0});
  @override
  State<TimetablePage> createState() => _TimetableState();
}

class _TimetableState extends State<TimetablePage> {
  List<ClassSlot> entries = [], candidates = [];
  List<ClassCancellation> cancellations = [];
  List<Map<String, dynamic>> courses = [];
  bool loading = true, enabled = false, midnight = false, exactAllowed = true;
  int lead = 30, countdownAfter = 0;
  String? message;
  bool building = false;
  String progress = '';
  int mode = 0;

  List<ClassSlot> get weekEntries => classesThisWeek(
    entries,
    cancellations,
    DateTime.now().toUtc().add(const Duration(hours: 9)),
  );

  bool cancelBuild = false;
  Future<void> buildTimetable({bool refresh = false}) async {
    cancelBuild = false;
    if (building) return;
    setState(() {
      building = true;
      message = null;
    });
    final client = CampusClient();
    Store? store;
    final failures = <String>[];
    final missing = <String>[];
    try {
      store = await Store.open();
      final scope = await SessionScope.capture(store);
      final account = await credentials.read(key: 'id');
      final password = await credentials.read(key: 'pw');
      if (account == null || password == null) {
        throw CampusException('포털을 먼저 연결해 주세요.');
      }
      final list = await readCourses(store);
      if (list.isEmpty) throw CampusException('먼저 새로고침해서 수강 과목을 가져와 주세요.');
      var schoolConnected = false;
      final currentKeys = list.map(courseKey).toSet();
      var merged = retainCurrentTimetable(entries, currentKeys);
      Future<dynamic> readPlan(Map<String, dynamic> course) async {
        if (!schoolConnected) {
          await client.connectSchool(account, password);
          schoolConnected = true;
        }
        for (var attempt = 0; attempt < 2; attempt++) {
          try {
            final response = await client.api(
              '/course/addSessionCourseInfo',
              course,
            );
            final raw = response['data'];
            final session = Map<String, dynamic>.from(
              raw is String ? jsonDecode(raw) : raw,
            );
            return await client.api('/coursePlan/getInfo', session);
          } on CampusException catch (e) {
            if (attempt == 1 || !e.message.contains('로그인 만료')) rethrow;
            await client.connectSchool(account, password);
          }
        }
        throw CampusException('강의계획서 요청 실패');
      }

      for (var index = 0; index < list.length; index++) {
        if (!mounted || cancelBuild) {
          throw CampusException('시간표 만들기를 취소했어요. 기존 시간표는 유지해요.');
        }
        final course = list[index];
        final name = '${course['course_nm']}';
        final key = courseKey(course);
        setState(
          () => progress = '${index + 1}/${list.length} · ${courseLabel(name)}',
        );
        if (await credentials.read(key: 'id') != account) {
          throw CampusException('계정이 변경되어 중지했어요.');
        }
        try {
          final cached = await store.meta(MetaKey.coursePlan(key));
          if (!refresh && cached != null) {
            final plan = jsonDecode(cached);
            final text = plan['linkedText'];
            final savedAt = DateTime.tryParse('${plan['fetchedAt'] ?? ''}');
            if (text is String &&
                text.isNotEmpty &&
                savedAt != null &&
                DateTime.now().toUtc().difference(savedAt) <
                    const Duration(days: 7)) {
              final slots = parsePlanSlots(text, key, name);
              if (slots.isNotEmpty) {
                merged = replaceCourseSlots(merged, key, slots);
                continue;
              }
            }
          }
          final data = await retryPlanConnection(() => readPlan(course));
          final link = data is Map && data['link_course_info'] is Map
              ? data['link_course_info']['link_url']
              : null;
          if (link is! String || link.isEmpty) {
            throw CampusException('실제 계획서 주소 없음');
          }
          List<List<List<String>>> tables = [];
          final text = await loadLinkedSyllabus(
            link,
            name,
            onTables: (value) => tables = value,
          );
          if (cancelBuild) throw CampusException('시간표 만들기를 취소했어요.');
          if (await credentials.read(key: 'id') != account) {
            throw CampusException('계정 변경');
          }
          await scope.verify();
          await store.setMeta(
            MetaKey.coursePlan(key),
            jsonEncode({
              'linkedText': text,
              'linkedTables': tables,
              'linkedUrl': link,
              'fetchedAt': DateTime.now().toUtc().toIso8601String(),
              'data': data,
            }),
          );
          final slots = parsePlanSlots(text, key, name);
          merged = replaceCourseSlots(merged, key, slots);
          if (slots.isEmpty) missing.add(courseLabel(name));
        } on PlatformException catch (e) {
          if (e.code == 'syllabus_cancelled') {
            throw CampusException('시간표 만들기를 취소했어요. 기존 시간표는 유지해요.');
          }
          failures.add('${courseLabel(name)}: ${planFailure(e)}');
          await store.log('sync', '강의계획서 불러오기 실패', withCause('시간표 생성 · ${courseLabel(name)}', e));
        } catch (e) {
          failures.add('${courseLabel(name)}: ${planFailure(e)}');
          await store.log('sync', '강의계획서 불러오기 실패', withCause('시간표 생성 · ${courseLabel(name)}', e));
        }
      }
      if (await credentials.read(key: 'id') != account) {
        throw CampusException('계정이 변경되어 중지했어요.');
      }
      if (!mounted || cancelBuild) {
        throw CampusException('시간표 만들기를 취소했어요. 기존 시간표는 유지해요.');
      }
      await scope.verify();
      setState(() => entries = merged);
      await save();
      await load();
      await store.log(
        'sync',
        '전체 강의계획서 시간표 생성',
        '${list.length}과목 · 수업 ${merged.length}개 · 실패 ${failures.length}개',
      );
      if (mounted) {
        setState(
          () => message =
              '시간표 저장 완료 · 수업 ${merged.length}개${saveWarning.isEmpty ? '' : '\n$saveWarning'}${missing.isEmpty ? '' : '\n시간 미확인: ${missing.join(', ')}'}${failures.isEmpty ? '' : '\n불러오기 실패(기존 유지): ${failures.join(', ')}'}',
        );
      }
    } catch (e) {
      if (mounted) {
        setState(
          () => message = e is CampusException
              ? e.message
              : '시간표를 만들지 못했어요. 기존 시간표는 유지해요.',
        );
      }
      await systemLog('시간표 만들기 실패', '기존 시간표는 유지해요.', kind: 'sync', error: e);
    } finally {
      client.close();
      await store?.db.close();
      if (mounted) {
        setState(() {
          building = false;
          progress = '';
        });
      }
    }
  }

  DateTime until = DateTime(
    DateTime.now().year,
    DateTime.now().month <= 6 ? 6 : 12,
    DateTime.now().month <= 6 ? 30 : 31,
  );
  @override
  void initState() {
    super.initState();
    FeatureDiscovery.record(DiscoverFeature.timetable);
    mode = widget.initialMode;
    load();
  }

  Future<void> load() async {
    Store? s;
    try {
      s = await Store.open();
      await loadCourseColors();
      final list = await readCourses(s);
      final saved = decodeSlots(await s.meta(MetaKey.timetableEntries));
      final cancelled = await readClassCancellations(s);
      final proposed = <String, ClassSlot>{};
      for (final c in list) {
        final k = courseKey(c),
            raw = await s.meta(MetaKey.coursePlan(courseKey(c)));
        if (raw == null) continue;
        final plan = jsonDecode(raw);
        final text = plan['linkedText'] as String?;
        if (text == null) continue;
        for (final row in parsePlanSlots(text, k, '${c['course_nm']}')) {
          proposed[row.id] = row;
        }
      }
      final p =
          await bridge.invokeNativeMap<String, dynamic>(
            NativeMethod.timetableSettings,
          ) ??
          {};
      if (mounted) {
        setState(() {
          courses = list;
          entries = saved;
          cancellations = cancelled;
          candidates = proposed.values.toList();
          exactAllowed = p['exactAllowed'] == true;
          enabled = p['enabled'] == true;
          midnight = p['midnight'] == true;
          lead = p['lead'] ?? 30;
          countdownAfter = p['countdownAfter'] ?? 0;
          until = DateTime.tryParse(p['until'] ?? '') ?? until;
          loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          loading = false;
          message = '시간표를 읽지 못했어요. 다시 확인해 주세요.';
        });
      }
      await systemLog('시간표 읽기 실패', '시간표 화면을 열지 못했어요.', kind: 'app', error: e);
    } finally {
      await s?.db.close();
    }
  }

  String saveWarning = '';
  Future<void> save() async {
    final payload = jsonEncode(entries.map((e) => e.toJson()).toList());
    final outcome = await saveTimetableWithEffects(
      persist: () async {
        final s = await Store.open();
        try {
          await s.db.transaction((txn) async {
            for (final entry in {
              'timetableEntries': payload,
              'timetableSavedAt': DateTime.now().toUtc().toIso8601String(),
            }.entries) {
              await txn.rawInsert(
                'INSERT OR REPLACE INTO meta(id,value) VALUES(?,?)',
                [entry.key, entry.value],
              );
            }
          });
        } finally {
          await s.db.close();
        }
      },
      effects: {
        '저장 기록': () async {
          final s = await Store.open();
          try {
            await s.log(
              'system',
              '시간표 저장',
              '확인한 수업 ${entries.length}개 · 강의계획서 기준',
            );
          } finally {
            await s.db.close();
          }
        },
        'AI 재분석 예약': () async {
          final s = await Store.open();
          try {
            if (await s.meta(MetaKey.aiAuto) == 'yes') {
              await enqueueNotices(s);
              await scheduleAiWork();
            }
          } finally {
            await s.db.close();
          }
        },
        '위젯·알림 새로고침': () async {
          if (Platform.isAndroid) {
            final s = await Store.open();
            try {
              await publishAndroidWidgetSnapshot(s);
            } finally {
              await s.db.close();
            }
          }
          await bridge.invokeNative(NativeMethod.refreshWidget);
        },
        '알림 설정 적용': () async {
          await bridge.invokeNative(NativeMethod.setTimetableSettings, {
            'enabled': enabled,
            'midnight': midnight,
            'lead': lead,
            'countdownAfter': countdownAfter,
            'until':
                '${until.year}-${until.month.toString().padLeft(2, '0')}-${until.day.toString().padLeft(2, '0')}',
          });
        },
      },
      report: (stage, error) async {
        final s = await Store.open();
        try {
          final code = error is PlatformException
              ? error.code
              : error.runtimeType.toString();
          await s.log(
            'system',
            '시간표 저장 후 반영 실패',
            '$stage · $code · 시간표 저장본은 유지해요.',
          );
        } finally {
          await s.db.close();
        }
      },
    );
    saveWarning = outcome.warnings.isEmpty
        ? ''
        : '일정은 저장했어요. ${outcome.warnings.join('·')} 반영을 마치지 못했어요. 시간표 편집에서 다시 저장해 주세요.';
    if (mounted) {
      setState(
        () => message = saveWarning.isEmpty
            ? '저장했어요. 수업 시간·휴강·보강은 원문과 함께 확인하세요.'
            : saveWarning,
      );
    }
  }

  Future<void> editPersonal([ClassSlot? item]) async {
    final result = await Navigator.push<Object?>(
      context,
      MaterialPageRoute(builder: (_) => PersonalSchedulePage(item: item)),
    );
    if (result == null || !mounted) return;
    final before = List<ClassSlot>.from(entries);
    setState(() {
      if (item != null) {
        entries.removeWhere((e) => e.courseKey == item.courseKey);
      }
      if (result is ClassSlot) entries.add(result);
    });
    try {
      await save();
    } catch (e) {
      if (mounted) {
        setState(() {
          entries = before;
          message = '개인 일정 저장을 완료하지 못했어요.';
        });
      }
      await systemLog('개인 일정 저장 실패', '이전 시간표로 되돌렸어요.', kind: 'app', error: e);
    }
  }

  Future<void> importPlans() async {
    final selected = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            const ListTile(title: Text('시간표를 가져올 과목 선택')),
            ...courses.map(
              (c) => ListTile(
                title: Text(courseLabel('${c['course_nm']}')),
                subtitle: const Text('강의계획서 탭에서 불러온 뒤 돌아오세요'),
                onTap: () => Navigator.pop(ctx, c),
              ),
            ),
          ],
        ),
      ),
    );
    if (selected == null || !mounted) return;
    await navigateTo(context, CourseDestination(course: selected));
    await load();
  }

  Future<void> finishEditing() async {
    try {
      if (enabled || midnight) await requestNotificationPermission();
      await save();
      if (mounted) {
        if (widget.initialMode == 2) {
          Navigator.pop(context);
        } else {
          setState(() => mode = 0);
        }
      }
    } catch (e) {
      if (mounted) setState(() => message = '저장하지 못했어요. 다시 시도해 주세요.');
      await systemLog('시간표 저장 실패', '시간표 변경을 저장하지 못했어요.', kind: 'app', error: e);
    }
  }

  Future<void> backToGrid() async {
    await load();
    if (mounted) setState(() => mode = 0);
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: (mode == 0 || widget.initialMode == 2) && !building,
    onPopInvokedWithResult: (popped, result) {
      if (!popped && !building) backToGrid();
    },
    child: Scaffold(
      appBar: AppBar(
        title: Text(
          mode == 1
              ? '시간표 편집'
              : mode == 2
              ? '수업·자정 알림'
              : '시간표',
        ),
        leading: mode == 0
            ? null
            : IconButton(
                tooltip: widget.initialMode == 2 ? '이전 화면으로' : '시간표로 돌아가기',
                onPressed: widget.initialMode == 2
                    ? () => Navigator.pop(context)
                    : backToGrid,
                icon: const Icon(Icons.arrow_back),
              ),
        actions: [
          if (mode == 0) ...[
            IconButton(
              tooltip: '날짜별 휴강 관리',
              icon: const Icon(Icons.event_busy),
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const TimetableCancellationsPage(),
                  ),
                );
                await load();
              },
            ),
            IconButton(
              tooltip: '시간표 편집',
              onPressed: building ? null : () => setState(() => mode = 1),
              icon: const Icon(Icons.edit_outlined),
            ),
            IconButton(
              tooltip: '수업·자정 알림',
              onPressed: building ? null : () => setState(() => mode = 2),
              icon: const Icon(Icons.notifications_outlined),
            ),
            PopupMenuButton<String>(
              enabled: !building,
              onSelected: (v) {
                if (v == 'share') {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const TimetableSharePage(),
                    ),
                  );
                } else if (v == 'build') {
                  buildTimetable();
                } else if (v == 'buildFresh') {
                  buildTimetable(refresh: true);
                } else {
                  importPlans();
                }
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'share', child: Text('시간표 공유·친구 시간표')),
                PopupMenuItem(value: 'build', child: Text('강의계획서에서 다시 만들기')),
                PopupMenuItem(
                  value: 'buildFresh',
                  child: Text('학교에서 계획서 새로 불러오기'),
                ),
                PopupMenuItem(value: 'plans', child: Text('과목별 강의계획서 확인')),
              ],
            ),
          ],
        ],
      ),
      bottomNavigationBar: mode == 0 || loading || building
          ? null
          : PinnedAction(
              child: FilledButton(
                onPressed: finishEditing,
                child: Text(mode == 1 ? '시간표 저장' : '알림 설정 저장'),
              ),
            ),
      body: AdaptiveContent(
        child: loading || building
            ? Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const CircularProgressIndicator(),
                    const SizedBox(height: 16),
                    Text(building ? '강의계획서 불러오는 중\n$progress' : '불러오는 중'),
                    if (building) ...[
                      const Text('최근 7일 저장본은 재사용해요. 새로 받기는 상단 메뉴에서 선택할 수 있어요.'),
                      TextButton(
                        onPressed: () async {
                          cancelBuild = true;
                          if (Platform.isAndroid) {
                            try {
                              await bridge.invokeNative(
                                NativeMethod.cancelLinkedPlan,
                              );
                            } catch (_) {
                              // Nothing to cancel when no plan fetch is running.
                            }
                          }
                        },
                        child: const Text('수집 취소'),
                      ),
                    ],
                  ],
                ),
              )
            : ListView(
                key: ValueKey('timetable-mode-$mode'),
                padding: const EdgeInsets.all(20),
                children: [
                  if (message != null)
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Text(message!),
                      ),
                    ),
                  if (mode == 0) ...[
                    OutlinedButton.icon(
                      onPressed: () => editPersonal(),
                      icon: const Icon(Icons.add),
                      label: const Text('개인 반복 일정 추가'),
                    ),
                    for (final item in entries.where(
                      (e) => e.courseKey.startsWith('personal:'),
                    ))
                      ListTile(
                        leading: const Icon(Icons.repeat),
                        title: Text(item.course),
                        subtitle: Text(
                          '${weekNames[item.weekday - 1]} ${slotTime(item.start)}–${slotTime(item.end)} · ${item.room}',
                        ),
                        trailing: const Icon(Icons.edit_outlined),
                        onTap: () => editPersonal(item),
                      ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            '나의 주간 시간표',
                            style: Theme.of(context).textTheme.titleLarge,
                          ),
                        ),
                        Text('${entries.length}개 수업'),
                      ],
                    ),
                    const SizedBox(height: 8),
                    OutlinedButton.icon(
                      onPressed: building
                          ? null
                          : () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => const TimetableSharePage(),
                              ),
                            ),
                      icon: const Icon(Icons.people_outline),
                      label: const Text('시간표 공유·친구 시간표'),
                    ),
                    const SizedBox(height: 8),
                    const Text('수업을 누르면 상세와 과목 보기 버튼이 열려요.'),
                    const SizedBox(height: 8),
                    if (entries.isEmpty)
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(24),
                          child: Column(
                            children: [
                              const Icon(
                                Icons.calendar_month_outlined,
                                size: 44,
                              ),
                              const SizedBox(height: 16),
                              const Text('강의계획서로 시간표를 만들어 보세요.'),
                              const SizedBox(height: 8),
                              const Text(
                                '모든 수강 과목의 실제 계획서를 순서대로 가져와요. 시간 미확인·실패 과목은 결과에 알려드려요.',
                              ),
                              const SizedBox(height: 20),
                              FilledButton.icon(
                                onPressed: buildTimetable,
                                icon: const Icon(Icons.auto_awesome_outlined),
                                label: const Text('시간표 만들기'),
                              ),
                            ],
                          ),
                        ),
                      )
                    else
                      TimetableGrid(
                        entries: entries,
                        cancellations: cancellations,
                      ),
                    if (courses.any(
                      (c) => entries.any((e) => e.courseKey == courseKey(c)),
                    ))
                      ExpansionTile(
                        title: const Text('시간표 과목 바로가기'),
                        leading: const Icon(Icons.school_outlined),
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(12),
                            child: Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                for (final c in courses.where(
                                  (c) => entries.any(
                                    (e) => e.courseKey == courseKey(c),
                                  ),
                                ))
                                  ActionChip(
                                    avatar: const Icon(
                                      Icons.open_in_new,
                                      size: 16,
                                    ),
                                    label: Text(
                                      courseLabel('${c['course_nm']}'),
                                    ),
                                    onPressed: () => navigateTo(
                                      context,
                                      CourseDestination(course: c),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    if (Platform.isAndroid)
                      OutlinedButton.icon(
                        onPressed: () async {
                          final added = await bridge.invokeNative<bool>(
                            NativeMethod.pinTimetableWidget,
                          );
                          if (mounted && added != true) {
                            setState(
                              () => message =
                                  '홈 화면을 길게 누른 뒤 위젯 → 캠퍼스레이더 시간표를 추가하세요.',
                            );
                          }
                        },
                        icon: const Icon(Icons.widgets_outlined),
                        label: const Text('홈 화면에 시간표 추가'),
                      ),
                    const SizedBox(height: 12),
                    const Text('이번 주 시간표 · 휴강은 배지 표시 · 보강은 원문 확인'),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.event_note_outlined),
                      title: const Text('감지한 일정·휴강 관리'),
                      subtitle: const Text('공지·AI 일정 삭제 · 적용한 휴강 해제'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () async {
                        await Navigator.push(context, MaterialPageRoute<void>(
                            builder: (_) => const DetectedSchedulesPage()));
                        await load();
                      },
                    ),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.notifications_outlined),
                      title: const Text('수업·자정 알림'),
                      subtitle: Text(
                        '수업 전 ${enabled ? '$lead분' : '알림 꺼짐'} · 자정 요약 ${midnight ? '켜짐' : '꺼짐'}',
                      ),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => setState(() => mode = 2),
                    ),
                  ],
                  if (mode == 1) ...[
                    const Text('표에 표시할 수업을 선택하세요. 저장 전에는 위젯·알림에 반영되지 않아요.'),
                    TextButton.icon(
                      onPressed: importPlans,
                      icon: const Icon(Icons.description_outlined),
                      label: const Text('과목별 원문 확인'),
                    ),
                    if (entries.isEmpty && candidates.isEmpty)
                      const Padding(
                        padding: EdgeInsets.all(24),
                        child: Text('추출된 시간이 없어요. 시간표 화면에서 시간표 만들기를 실행해 주세요.'),
                      ),
                    ...{
                      for (final e in [...entries, ...candidates]) e.id: e,
                    }.values.map(
                      (e) => CheckboxListTile(
                        contentPadding: EdgeInsets.zero,
                        title: Text(courseLabel(e.course)),
                        subtitle: Text(
                          '${weekNames[e.weekday - 1]} ${slotTime(e.start)}–${slotTime(e.end)} ${e.room}\n원문: ${e.source}',
                        ),
                        value: entries.any((x) => x.id == e.id),
                        onChanged: (v) => setState(() {
                          entries.removeWhere((x) => x.id == e.id);
                          if (v == true) entries.add(e);
                        }),
                      ),
                    ),
                  ],
                  if (mode == 2) ...[
                    const SectionHeading(
                      '수업 전 알림',
                      subtitle: '저장한 시간표를 기준으로 알려드려요.',
                    ),
                    if (Platform.isWindows)
                      const Padding(
                        padding: EdgeInsets.only(bottom: 16),
                        child: Text(
                          'PC에서 앱이 실행 중일 때만 알려요. 절전·종료 중에는 알림이 오지 않으며, 실행 중 약 1분마다 확인해요.',
                        ),
                      ),
                    if (Platform.isIOS)
                      const Padding(
                        padding: EdgeInsets.only(bottom: 16),
                        child: Text(
                          'iPhone은 가까운 수업·자정 알림을 최대 24개 예약해요. 앱 실행·수집·시간표 변경 시 갱신하며, 백그라운드 실행 시각은 iOS가 결정해요.',
                        ),
                      ),
                    if (Platform.isAndroid && !exactAllowed)
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                '정확한 알림 권한이 꺼져 있어요. 수업 전·자정 알림이 늦어질 수 있어요.',
                              ),
                              TextButton(
                                onPressed: () async {
                                  await bridge.invokeNative(
                                    NativeMethod.openExactAlarmSettings,
                                  );
                                },
                                child: const Text('정확한 알림 설정 열기'),
                              ),
                              TextButton(
                                onPressed: load,
                                child: const Text('권한 상태 다시 확인'),
                              ),
                            ],
                          ),
                        ),
                      ),
                    SwitchListTile(
                      title: const Text('수업 시작 전 알림'),
                      subtitle: const Text('저장한 시간표 기준 · 확인해서 반영한 휴강은 제외해요.'),
                      value: enabled,
                      onChanged: (v) => setState(() => enabled = v),
                    ),
                    DropdownButtonFormField<int>(
                      initialValue: lead,
                      decoration: const InputDecoration(labelText: '알림 시점'),
                      items: [15, 30, 60]
                          .map(
                            (n) => DropdownMenuItem(
                              value: n,
                              child: Text('수업 $n분 전'),
                            ),
                          )
                          .toList(),
                      onChanged: (v) => setState(() => lead = v ?? 30),
                    ),
                    if (Platform.isAndroid) ...[
                      const SizedBox(height: 16),
                      Text('수업 시작 후 카운트다운 유지: $countdownAfter분'),
                      const Text('0분이면 시작할 때 종료해요. 늘리면 시작 후에도 "-3:20"처럼 지난 시간을 보여 줘요.'),
                      Slider(
                        value: countdownAfter.toDouble(),
                        min: 0,
                        max: 120,
                        divisions: 120,
                        label: '$countdownAfter분',
                        onChanged: (v) =>
                            setState(() => countdownAfter = v.round()),
                      ),
                    ],
                    ListTile(
                      title: const Text('시간표 알림 종료일'),
                      subtitle: Text(
                        '${until.year}/${until.month}/${until.day} · 방학 중 반복 방지',
                      ),
                      trailing: const Icon(Icons.calendar_today),
                      onTap: () async {
                        final d = await showDatePicker(
                          context: context,
                          initialDate: until,
                          firstDate: DateTime(2000),
                          lastDate: DateTime.now().add(
                            const Duration(days: 730),
                          ),
                        );
                        if (d != null) setState(() => until = d);
                      },
                    ),
                    const SectionHeading(
                      '자정 요약',
                      subtitle: '하루가 시작될 때 오늘의 수업과 마감을 확인해요.',
                    ),
                    SwitchListTile(
                      title: const Text('자정에 오늘 수업·과제 알림'),
                      subtitle: const Text(
                        '한국 시간 00:00에 막 시작한 날의 수업과 미완료 마감 항목을 알려줘요. 마지막 수집 기준이며 절전 시 늦어질 수 있어요.',
                      ),
                      value: midnight,
                      onChanged: (v) => setState(() => midnight = v),
                    ),

                    ExpansionTile(
                      title: const Text('알림 테스트'),
                      children: [
                        TextButton(
                          onPressed: () async {
                            await bridge.invokeNative(
                              NativeMethod.testMidnightSummary,
                            );
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('자정 요약 형식으로 알림을 요청했어요.'),
                                ),
                              );
                            }
                          },
                          child: const Text('자정 요약 알림 테스트'),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
      ),
    ),
  );
}

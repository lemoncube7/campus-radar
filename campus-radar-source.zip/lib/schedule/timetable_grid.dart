import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/courses/course_catalog.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/courses/course_colors.dart';
import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:campus_radar/schedule/timetable_model.dart';

class TimetableGrid extends StatelessWidget {
  final List<ClassSlot> entries;
  final List<ClassCancellation> cancellations;
  final bool readOnly;
  const TimetableGrid({
    super.key,
    required this.entries,
    this.cancellations = const [],
    this.readOnly = false,
  });
  @override
  Widget build(BuildContext context) {
    final days = math.max(
      5,
      entries.fold<int>(1, (a, e) => math.max(a, e.weekday)),
    );
    final first = entries.fold<int>(9, (a, e) => math.min(a, e.start ~/ 60));
    final last = entries.fold<int>(
      18,
      (a, e) => math.max(a, (e.end + 59) ~/ 60),
    );
    const hour = 58.0, left = 34.0, header = 32.0;
    final now = DateTime.now().toUtc().add(const Duration(hours: 9));
    final minute = now.hour * 60 + now.minute;
    final lanes = timetableLanes(entries);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final column = math.max(1.0, (constraints.maxWidth - left) / days);
          final compact = column < 85;
          return SizedBox(
            width: left + days * column,
            height: header + (last - first) * hour,
            child: Stack(
              children: [
                if (now.weekday <= days)
                  Positioned(
                    left: left + (now.weekday - 1) * column,
                    top: 0,
                    width: column,
                    height: header + (last - first) * hour,
                    child: ColoredBox(
                      color: Theme.of(
                        context,
                      ).colorScheme.primary.withValues(alpha: 0.05),
                    ),
                  ),
                for (var day = 1; day <= days; day++)
                  Positioned(
                    left: left + (day - 1) * column,
                    top: 0,
                    width: column,
                    child: Center(
                      child: Text(
                        weekNames[day - 1],
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                for (var h = first; h <= last; h++) ...[
                  Positioned(
                    left: 0,
                    top: header + (h - first) * hour - 7,
                    child: Text(
                      '${h.toString().padLeft(2, '0')}:00',
                      style: Theme.of(context).textTheme.labelSmall,
                    ),
                  ),
                  Positioned(
                    left: left,
                    right: 0,
                    top: header + (h - first) * hour,
                    child: Divider(
                      height: 1,
                      color: Theme.of(context).dividerColor,
                    ),
                  ),
                ],
                for (final e in entries) ...[
                  Builder(
                    builder: (context) {
                      final position = lanes[e.id]!;
                      final width = column / position.count;
                      final color = courseAccent(e.courseKey);
                      final monday = DateTime(now.year, now.month, now.day)
                          .subtract(Duration(days: now.weekday - 1));
                      final slotDate = monday.add(Duration(days: e.weekday - 1));
                      final slotDateStr = classDate(slotDate);
                      final cancel = cancellations
                          .where((c) => c.slotId == e.id && c.date == slotDateStr)
                          .firstOrNull;
                      return Positioned(
                        left:
                            left +
                            (e.weekday - 1) * column +
                            position.lane * width +
                            1,
                        top: header + (e.start - first * 60) / 60 * hour + 1,
                        width: width - 2,
                        height: math.max(12, (e.end - e.start) / 60 * hour - 2),
                        child: GestureDetector(
                          onTap: () => showClass(
                            context,
                            e,
                            cancellation: cancel,
                            date: slotDate,
                          ),
                          child: Tooltip(
                            message:
                                '${cancel != null ? "[휴강] " : ""}${courseLabel(e.course)}\n${slotTime(e.start)}–${slotTime(e.end)} ${e.room}',
                            child: Container(
                              padding: EdgeInsets.all(compact ? 3 : 5),
                              decoration: BoxDecoration(
                                color: cancel != null
                                    ? Colors.red.withValues(alpha: 0.18)
                                    : color.withValues(alpha: 0.32),
                                borderRadius: BorderRadius.circular(7),
                                border: Border(
                                  left: BorderSide(
                                    color: cancel != null ? Colors.red : color,
                                    width: 3,
                                  ),
                                ),
                              ),
                              child: ClipRect(
                                child: SingleChildScrollView(
                                  physics: const NeverScrollableScrollPhysics(),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                    if (cancel != null)
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 3,
                                          vertical: 1,
                                        ),
                                        margin: const EdgeInsets.only(bottom: 2),
                                        decoration: BoxDecoration(
                                          color: Colors.red.shade700,
                                          borderRadius: BorderRadius.circular(3),
                                        ),
                                        child: const Text(
                                          '휴강',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 9,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    Text(
                                      compact
                                          ? courseLabel(e.course)
                                          : '${courseLabel(e.course)}\n${slotTime(e.start)}–${slotTime(e.end)}\n${e.room}',
                                      style: Theme.of(context)
                                          .textTheme
                                          .labelSmall
                                          ?.copyWith(
                                            fontWeight: FontWeight.w600,
                                            fontSize: compact ? 11 : null,
                                            decoration: cancel != null
                                                ? TextDecoration.lineThrough
                                                : null,
                                          ),
                                      maxLines: compact ? 4 : null,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                    },
                  ),
                ],
                if (now.weekday <= days &&
                    minute >= first * 60 &&
                    minute <= last * 60)
                  Positioned(
                    left: left + (now.weekday - 1) * column,
                    top: header + (minute - first * 60) / 60 * hour,
                    width: column,
                    child: const Divider(
                      color: Colors.red,
                      height: 1,
                      thickness: 2,
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }

  Future<void> showClass(
    BuildContext context,
    ClassSlot e, {
    ClassCancellation? cancellation,
    DateTime? date,
  }) async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheet) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      courseLabel(e.course),
                      style: Theme.of(sheet).textTheme.titleLarge,
                    ),
                  ),
                  if (cancellation != null)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: Theme.of(sheet).colorScheme.error,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: const Text(
                        '휴강 (휴강으로 인식됨)',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                '${date != null ? "${date.month}월 ${date.day}일(" : ""}${weekNames[e.weekday - 1]}${date != null ? ") " : " "}${slotTime(e.start)}–${slotTime(e.end)}',
              ),
              Text(e.room.isEmpty ? '강의실 미확인' : e.room),
              const SizedBox(height: 12),
              Text(
                '${readOnly
                    ? '주간 시간표 사본'
                    : e.courseKey.startsWith('personal:')
                    ? '개인 반복 일정'
                    : '강의계획서 기준'} · ${e.source}',
              ),
              if (cancellation != null) ...[
                const SizedBox(height: 16),
                if (cancellation.noticeId.isNotEmpty)
                  FilledButton.tonalIcon(
                    icon: const Icon(Icons.description_outlined),
                    label: Text(
                      cancellation.noticeTitle.isNotEmpty
                          ? '근거 공지 보기: ${cancellation.noticeTitle}'
                          : '근거 공지 보기',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    onPressed: () async {
                      final store = await Store.open();
                      CampusNotice? notice;
                      try {
                        notice = (await store.notices())
                            .where((n) => n.id == cancellation.noticeId)
                            .firstOrNull;
                      } finally {
                        await store.db.close();
                      }
                      if (!sheet.mounted) return;
                      if (notice != null) {
                        Navigator.pop(sheet);
                        if (context.mounted) {
                          navigateTo(
                            context,
                            NoticeDestination(notice: notice),
                          );
                        }
                      } else {
                        ScaffoldMessenger.of(sheet).showSnackBar(
                          const SnackBar(
                            content: Text('원문 공지를 찾지 못했어요.'),
                          ),
                        );
                      }
                    },
                  )
                else
                  Text(
                    cancellation.source.isNotEmpty
                        ? '직접 추가된 휴강 (${cancellation.source})'
                        : '직접 추가된 휴강',
                    style: TextStyle(
                      color: Theme.of(sheet).colorScheme.error,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
              ],
              const SizedBox(height: 20),
              if (!readOnly && !e.courseKey.startsWith('personal:'))
                FilledButton(
                  onPressed: () async {
                    final store = await Store.open();
                    Map<String, dynamic>? course;
                    try {
                      course = (await readCourses(
                        store,
                      )).where((c) => courseKey(c) == e.courseKey).firstOrNull;
                    } finally {
                      await store.db.close();
                    }
                    if (!sheet.mounted) return;
                    if (course == null) {
                      ScaffoldMessenger.of(sheet).showSnackBar(
                        const SnackBar(
                          content: Text('과목 정보를 찾지 못했어요. 새로고침 후 확인해 주세요.'),
                        ),
                      );
                      return;
                    }
                    Navigator.pop(sheet);
                    if (context.mounted) {
                      navigateTo(context, CourseDestination(course: course));
                    }
                  },
                  child: const Text('과목 보기'),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

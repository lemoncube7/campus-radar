import 'dart:io';

final periodicTask = Platform.isIOS
    ? 'kr.campusradar.campusradar.sync'
    : 'campus-radar-sync';

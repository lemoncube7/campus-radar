import 'dart:convert';
import 'app_storage.dart';
import 'operation_token.dart';
import 'timetable_exceptions.dart';

class CancellationRead {
  final List<ClassCancellation> entries;
  final int invalidRows;
  final bool recovered;
  const CancellationRead(this.entries, this.invalidRows, this.recovered);
}

class CancellationReceipt {
  final String generation;
  final List<ClassCancellation> before;
  final int affected;
  const CancellationReceipt(this.generation, this.before, this.affected);
}

class CancellationRepository {
  final Store store;
  const CancellationRepository(this.store);
  static const key = 'timetableCancellations';
  static const backup = 'timetableCancellations:lastGood';
  static const generationKey = 'timetableCancellations:generation';
  Future<CancellationRead> read() async {
    final raw = await store.meta(key);
    try {
      final data = parseCancellationData(raw);
      return CancellationRead(data.entries, data.invalidRows, false);
    } on FormatException {
      final saved = await store.meta(backup);
      if (saved == null) {
        throw const FormatException('휴강 정보를 읽지 못했습니다. 기존 기록을 지우지 않았습니다.');
      }
      final data = parseCancellationData(saved);
      return CancellationRead(data.entries, data.invalidRows, true);
    }
  }

  Future<CancellationReceipt> change(
    List<ClassCancellation> Function(List<ClassCancellation>) edit, {
    String? expectedGeneration,
  }) => store.db.transaction((txn) async {
    Future<String?> get(String id) async {
      final rows = await txn.query('meta', where: 'id=?', whereArgs: [id]);
      return rows.isEmpty ? null : rows.single['value'] as String;
    }

    Future<void> put(String id, String value) => txn
        .rawInsert('INSERT OR REPLACE INTO meta(id,value) VALUES(?,?)', [
          id,
          value,
        ])
        .then((_) {});
    if (expectedGeneration != null &&
        await get(generationKey) != expectedGeneration) {
      throw const FormatException(
        '이후 휴강 정보가 변경되어 실행 취소하지 않았어요. 휴강 목록에서 확인해 주세요.',
      );
    }
    final raw = await get(key);
    CancellationData data;
    try {
      data = parseCancellationData(raw);
    } on FormatException {
      final old = await get(backup);
      if (old == null) {
        throw const FormatException('휴강 정보를 읽지 못해 저장을 중단했습니다. 원본은 유지합니다.');
      }
      data = parseCancellationData(old);
    }
    // Preserve damaged input separately before a deliberate edit replaces it.
    if (raw != null && (data.invalidRows > 0 || _unreadable(raw))) {
      await put('$key:unreadable', raw);
    }
    final before = List<ClassCancellation>.of(data.entries);
    final next = edit(List.of(before));
    final encoded = jsonEncode(next.map((e) => e.toJson()).toList());
    final validated = parseCancellationData(encoded);
    if (validated.invalidRows > 0) {
      throw const FormatException('적용할 휴강 정보가 올바르지 않습니다.');
    }
    final token = freshToken();
    await put(key, encoded);
    await put(backup, encoded);
    await put(generationKey, token);
    return CancellationReceipt(token, before, next.length);
  });

  Future<CancellationReceipt> apply(List<ClassCancellation> planned) =>
      change((rows) {
        final byId = {for (final row in rows) row.id: row};
        for (final row in planned) {
          byId[row.id] = row;
        }
        return byId.values.toList();
      });
  Future<void> undo(CancellationReceipt receipt) async {
    await change((_) => receipt.before, expectedGeneration: receipt.generation);
  }

  static bool _unreadable(String raw) {
    try {
      parseCancellationData(raw);
      return false;
    } on FormatException {
      return true;
    }
  }
}

Future<List<ClassCancellation>> readClassCancellations(Store store) async =>
    (await CancellationRepository(store).read()).entries;

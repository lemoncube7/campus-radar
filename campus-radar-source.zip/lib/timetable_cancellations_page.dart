import 'dart:convert';
import 'package:flutter/material.dart';
import 'app_storage.dart';
import 'native_bridge.dart';
import 'native_contract.dart';
import 'timetable_model.dart';
import 'timetable_exceptions.dart';
import 'campus_models.dart';
import 'ai_protocol.dart';
import 'session_scope.dart';

Future<bool> editCancellation(
  BuildContext context, {
  CampusNotice? notice,
  ScheduleCandidate? candidate,
}) async =>
    await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) =>
            CancellationEditor(notice: notice, candidate: candidate),
      ),
    ) ??
    false;

class TimetableCancellationsPage extends StatefulWidget {
  const TimetableCancellationsPage({super.key});
  @override
  State<TimetableCancellationsPage> createState() => _CancellationsState();
}

class _CancellationsState extends State<TimetableCancellationsPage> {
  List<ClassCancellation> rows = [];
  String? error;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final s = await Store.open();
    try {
      final data = decodeCancellations(await s.meta('timetableCancellations'));
      if (mounted) setState(() => rows = data);
    } catch (_) {
      if (mounted) setState(() => error = '휴강 목록을 읽지 못했어요.');
    } finally {
      await s.db.close();
    }
  }

  Future<void> remove(String id) async {
    final s = await Store.open();
    try {
      final data = decodeCancellations(await s.meta('timetableCancellations'))
        ..removeWhere((c) => c.id == id);
      await s.setMeta(
        'timetableCancellations',
        jsonEncode(data.map((c) => c.toJson()).toList()),
      );
      await bridge.invokeNative(NativeMethod.refreshWidget);
      await load();
    } catch (_) {
      if (mounted) setState(() => error = '휴강을 해제하지 못했어요. 다시 확인해 주세요.');
    } finally {
      await s.db.close();
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('날짜별 휴강 관리')),
    floatingActionButton: FloatingActionButton.extended(
      onPressed: () async {
        await editCancellation(context);
        await load();
      },
      icon: const Icon(Icons.add),
      label: const Text('휴강 추가'),
    ),
    body: ListView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
      children: [
        const Text(
          '정규 시간표는 유지하고 선택한 날짜의 수업만 제외합니다. 오늘 수업·수업 알림·이번 주 시간표 위젯에 함께 반영됩니다.',
        ),
        if (error != null) Text(error!),
        if (rows.isEmpty)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Text('적용한 휴강이 없어요.'),
          ),
        for (final c in rows)
          Card(
            child: ListTile(
              title: Text('${c.date} · ${c.course}'),
              subtitle: Text(c.source.isEmpty ? '직접 추가' : c.source),
              trailing: TextButton(
                onPressed: () => remove(c.id),
                child: const Text('휴강 해제'),
              ),
            ),
          ),
      ],
    ),
  );
}

class CancellationEditor extends StatefulWidget {
  final CampusNotice? notice;
  final ScheduleCandidate? candidate;
  const CancellationEditor({super.key, this.notice, this.candidate});
  @override
  State<CancellationEditor> createState() => _CancellationEditorState();
}

class _CancellationEditorState extends State<CancellationEditor> {
  List<ClassSlot> rows = [];
  final selected = <String>{};
  bool busy = true;
  String? error;
  SessionScope? scope;
  late DateTimeRange dates;
  @override
  void initState() {
    super.initState();
    final start =
        DateTime.tryParse(widget.candidate?.date ?? '') ?? DateTime.now();
    final end = DateTime.tryParse(widget.candidate?.endDate ?? '') ?? start;
    dates = DateTimeRange(start: start, end: end.isBefore(start) ? start : end);
    load();
  }

  Future<void> load() async {
    final s = await Store.open();
    try {
      scope = await SessionScope.capture(s);
      var data = decodeSlots(await s.meta('timetableEntries'));
      final n = widget.notice;
      if (n != null) {
        final key = '${n.context['course_id']}:${n.context['class_no']}';
        data = data
            .where((e) => e.courseKey == key || e.course == n.course)
            .toList();
      }
      if (mounted) {
        setState(() {
          rows = data;
          busy = false;
          selected.addAll(
            data
                .where((e) => e.weekday == dates.start.weekday)
                .map((e) => e.id),
          );
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          busy = false;
          error = '시간표를 읽지 못했어요. 다시 열어 주세요.';
        });
      }
    } finally {
      await s.db.close();
    }
  }

  Future<void> save() async {
    if (selected.isEmpty) return;
    setState(() => busy = true);
    final s = await Store.open();
    try {
      final currentScope = await SessionScope.capture(s);
      if (currentScope.account != scope?.account ||
          currentScope.epoch != scope?.epoch) {
        throw SessionChanged();
      }
      if (dates.duration.inDays > 366) {
        throw const FormatException('휴강 범위는 1년 이내로 선택해 주세요.');
      }
      final data = decodeCancellations(await s.meta('timetableCancellations'));
      var count = 0;
      for (
        var d = dates.start;
        !d.isAfter(dates.end);
        d = d.add(const Duration(days: 1))
      ) {
        for (final e in rows.where(
          (e) => selected.contains(e.id) && e.weekday == d.weekday,
        )) {
          final id = '${classDate(d)}:${e.id}';
          data.removeWhere((c) => c.id == id);
          data.add(
            ClassCancellation(
              id,
              e.id,
              classDate(d),
              e.course,
              widget.notice?.title ?? '',
            ),
          );
          count++;
        }
      }
      if (count == 0) throw const FormatException('선택한 날짜에 해당 요일의 수업이 없습니다.');
      await currentScope.verify();
      await s.setMeta(
        'timetableCancellations',
        jsonEncode(data.map((c) => c.toJson()).toList()),
      );
      await s.log('app', '날짜별 휴강 적용', '$count개 수업');
      await bridge.invokeNative(NativeMethod.refreshWidget);
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        setState(
          () => error = e is FormatException
              ? e.message
              : '휴강을 저장하지 못했어요. 다시 확인해 주세요.',
        );
      }
    } finally {
      await s.db.close();
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('시간표에 휴강 반영')),
    bottomNavigationBar: SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: FilledButton(
          onPressed: busy || selected.isEmpty ? null : save,
          child: const Text('선택한 날짜·수업에 휴강 적용'),
        ),
      ),
    ),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        if (widget.notice != null) ...[
          Text(
            widget.notice!.title,
            style: Theme.of(context).textTheme.titleLarge,
          ),
          Text(widget.candidate?.evidence ?? ''),
        ],
        const Text('공지의 날짜와 대상 수업을 확인해 주세요. 선택한 날짜의 수업 알림과 카운트다운이 제외됩니다.'),
        ListTile(
          title: const Text('휴강 날짜'),
          subtitle: Text('${classDate(dates.start)} ~ ${classDate(dates.end)}'),
          trailing: const Icon(Icons.date_range),
          onTap: busy
              ? null
              : () async {
                  final d = await showDateRangePicker(
                    context: context,
                    firstDate: DateTime(2020),
                    lastDate: DateTime(2100),
                    initialDateRange: dates,
                  );
                  if (d != null && mounted) {
                    if (d.duration.inDays > 366) {
                      setState(() => error = '휴강 범위는 1년 이내로 선택해 주세요.');
                      return;
                    }
                    setState(() => dates = d);
                  }
                },
        ),
        if (busy) const LinearProgressIndicator(),
        if (error != null) Text(error!),
        if (!busy && rows.isEmpty)
          const Text('연결할 수업이 없습니다. 먼저 시간표를 만들고 과목을 확인해 주세요.'),
        for (final e in rows)
          CheckboxListTile(
            title: Text(e.course),
            subtitle: Text(
              '${weekNames[e.weekday - 1]} ${slotTime(e.start)}–${slotTime(e.end)}',
            ),
            value: selected.contains(e.id),
            onChanged: busy
                ? null
                : (v) => setState(
                    () =>
                        v == true ? selected.add(e.id) : selected.remove(e.id),
                  ),
          ),
      ],
    ),
  );
}

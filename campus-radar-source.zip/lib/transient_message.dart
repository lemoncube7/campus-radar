import 'dart:async';
import 'package:flutter/material.dart';

/// Keep action messages finite even when accessibility navigation is enabled.
/// Close this controller only, so an old timer never dismisses a newer message.
void showTransientMessage(BuildContext context, SnackBar message) {
  final messenger = ScaffoldMessenger.of(context);
  messenger.clearSnackBars();
  final controller = messenger.showSnackBar(message);
  final timer = Timer(const Duration(seconds: 8), controller.close);
  controller.closed.whenComplete(timer.cancel);
}

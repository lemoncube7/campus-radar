import 'dart:convert';
import 'dart:io';
import 'package:cookie_jar/cookie_jar.dart';
import 'package:encrypt/encrypt.dart' as enc;
import 'package:html/parser.dart' as html;

String textOf(Object? value) =>
    html.parse(value?.toString() ?? '').body?.text.trim() ?? '';
String str(Map<String, dynamic> m, String key) => m[key]?.toString() ?? '';

enum DeadlineState { unknown, overdue, withinDay, remaining }

String koreanTime(DateTime date) {
  final d = date.toUtc().add(const Duration(hours: 9));
  return '${d.year}/${d.month}/${d.day} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')} (한국 시간)';
}

DeadlineState deadlineState(DateTime? due, {DateTime? now}) {
  if (due == null) return DeadlineState.unknown;
  final remaining = due.difference(now ?? DateTime.now());
  if (remaining <= Duration.zero) return DeadlineState.overdue;
  if (remaining <= const Duration(days: 1)) return DeadlineState.withinDay;
  return DeadlineState.remaining;
}

DateTime? campusDate(String value) {
  final match = RegExp(
    r'(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2})(?::(\d{2}))?',
  ).firstMatch(value);
  if (match == null) return null;
  return DateTime.tryParse(
    '${match[1]}T${match[2]}:${match[3] ?? '00'}+09:00',
  )?.toUtc();
}

class CampusItem {
  final String key,
      type,
      title,
      course,
      courseId,
      classNo,
      contentsId,
      status,
      body;
  final DateTime? due;
  final Map<String, dynamic> context;
  CampusItem({
    required this.key,
    required this.type,
    required this.title,
    required this.course,
    required this.courseId,
    required this.classNo,
    required this.contentsId,
    required this.status,
    this.body = '',
    this.due,
    required this.context,
  });
  bool get done => status == 'done';
  Map<String, dynamic> toJson() => {
    'key': key,
    'type': type,
    'title': title,
    'course': course,
    'courseId': courseId,
    'classNo': classNo,
    'contentsId': contentsId,
    'status': status,
    'body': body,
    'due': due?.toIso8601String(),
    'context': context,
  };
  factory CampusItem.fromJson(Map<String, dynamic> m) => CampusItem(
    key: m['key'],
    type: m['type'],
    title: m['title'],
    course: m['course'],
    courseId: m['courseId'],
    classNo: m['classNo'],
    contentsId: m['contentsId'],
    status: m['status'],
    body: m['body'] ?? '',
    due: m['due'] == null ? null : DateTime.parse(m['due']),
    context: Map<String, dynamic>.from(m['context']),
  );
}

class CampusException implements Exception {
  final String message;
  CampusException(this.message);
  @override
  String toString() => message;
}

class CampusNotice {
  final String id, title, course, body;
  final DateTime? published;
  final bool read, bodyFetched;
  final Map<String, dynamic> context;
  CampusNotice({
    required this.id,
    required this.title,
    required this.course,
    required this.context,
    this.published,
    this.read = false,
    this.body = '',
    this.bodyFetched = false,
  });
  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'course': course,
    'body': body,
    'published': published?.toIso8601String(),
    'read': read,
    'bodyFetched': bodyFetched,
    'context': context,
  };
  factory CampusNotice.fromJson(Map<String, dynamic> m) => CampusNotice(
    id: m['id'],
    title: m['title'],
    course: m['course'],
    body: m['body'] ?? '',
    published: DateTime.tryParse(m['published'] ?? ''),
    read: m['read'] == true,
    bodyFetched: m['bodyFetched'] == true,
    context: Map<String, dynamic>.from(m['context']),
  );
  CampusItem get item => CampusItem(
    key: 'NT:$id',
    type: 'NT',
    title: title,
    course: course,
    courseId: str(context, 'course_id'),
    classNo: str(context, 'class_no'),
    contentsId: id,
    status: read ? 'read' : 'unread',
    body: body,
    context: context,
  );
}

class CampusClient {
  final void Function(String)? diagnostic;
  CampusClient({this.diagnostic});
  static const learning = 'https://dcs-learning.cnu.ac.kr';
  static const loginHost = 'https://dcs-lcms.cnu.ac.kr';
  final HttpClient http = HttpClient()
    ..connectionTimeout = const Duration(seconds: 20);
  final CookieJar jar = CookieJar();
  String transportKey = '';
  Future<String> request(
    Uri url, {
    Map<String, String>? form,
    int redirects = 0,
  }) async {
    if (url.scheme != 'https' ||
        !{'dcs-learning.cnu.ac.kr', 'dcs-lcms.cnu.ac.kr'}.contains(url.host)) {
      throw CampusException('예상하지 못한 로그인 이동 주소입니다.');
    }
    if (redirects > 10) throw CampusException('로그인 이동이 반복됩니다.');
    final req = await http.openUrl(form == null ? 'GET' : 'POST', url);
    req.followRedirects = false;
    req.headers.set(
      HttpHeaders.userAgentHeader,
      'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/130.0.0.0 Mobile Safari/537.36',
    );
    req.cookies.addAll(await jar.loadForRequest(url));
    if (form != null) {
      req.headers.set(
        HttpHeaders.contentTypeHeader,
        'application/x-www-form-urlencoded; charset=UTF-8',
      );
      req.headers.set('Origin', '${url.scheme}://${url.host}');
      req.headers.set('Referer', '${url.scheme}://${url.host}/home');
      req.headers.set('X-Requested-With', 'XMLHttpRequest');
      final bytes = utf8.encode(
        form.entries
            .map(
              (e) =>
                  '${Uri.encodeQueryComponent(e.key)}=${Uri.encodeQueryComponent(e.value)}',
            )
            .join('&'),
      );
      req.contentLength = bytes.length;
      req.add(bytes);
    }
    final response = await req.close().timeout(const Duration(seconds: 30));
    await jar.saveFromResponse(url, response.cookies);
    final body = await utf8.decoder
        .bind(response)
        .join()
        .timeout(const Duration(seconds: 30));
    final location = response.headers.value(HttpHeaders.locationHeader);
    if (response.isRedirect && location != null) {
      return request(
        url.resolve(location),
        form: response.statusCode == 307 || response.statusCode == 308
            ? form
            : null,
        redirects: redirects + 1,
      );
    }
    if (response.statusCode != 200) {
      throw CampusException('서버 응답 오류 (${response.statusCode}, ${url.path})');
    }
    return body;
  }

  Future<dynamic> api(
    String route,
    Map<String, dynamic>? payload, {
    String host = learning,
  }) async {
    final cipher = enc.Encrypter(
      enc.AES(enc.Key.fromUtf8(transportKey), mode: enc.AESMode.cbc),
    );
    final form = payload == null
        ? <String, String>{}
        : {
            'e': cipher
                .encrypt(jsonEncode(payload), iv: enc.IV.allZerosOfLength(16))
                .base64,
          };
    final raw = await request(Uri.parse('$host/api/v1$route'), form: form);
    Map<String, dynamic> result;
    try {
      result = jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      throw CampusException('로그인 만료 또는 데이터 형식 변경으로 수집하지 못했습니다.');
    }
    if (result['header']?['code'] != 200) {
      throw CampusException('사이버캠퍼스 요청이 거절됐습니다. 계정 또는 사이트 상태를 확인해 주세요.');
    }
    return result['body'];
  }

  Future<void> login(String id, String password) async {
    final page = html.parse(await request(Uri.parse('$learning/home')));
    final aesPath = page
        .querySelectorAll('script[src]')
        .map((e) => e.attributes['src']!)
        .where((s) => s.contains('gibberish-aes'))
        .firstOrNull;
    if (aesPath == null) throw CampusException('로그인 페이지 구조가 변경됐습니다.');
    final js = await request(Uri.parse(loginHost).resolve(aesPath));
    transportKey =
        RegExp(
          r"function getSecKey\(\)\s*\{\s*return '([^']+)'",
        ).firstMatch(js)?.group(1) ??
        '';
    if (transportKey.length != 32) {
      throw CampusException('로그인 통신 형식을 확인하지 못했습니다.');
    }
    final payload = <String, dynamic>{
      'redirect_url': '$learning/home',
      'key': page.querySelector('input[name=key]')?.attributes['value'] ?? '',
      'univ_no': 'CNU',
      'org_password': '',
      'user_id': id,
      'user_password': password,
      'cnu_auth': 'Y',
      'user_ip':
          page.querySelector('input[name=user_ip]')?.attributes['value'] ?? '',
    };
    final data = await api(
      '/user/apiCnuAuthLogin?redirectUrl=${Uri.encodeComponent('$learning/home')}',
      payload,
      host: loginHost,
    );
    if (data is! Map || data['redirect_url'] == null) {
      throw CampusException('포털 로그인에 추가 확인이 필요합니다. 사이버캠퍼스에서 확인해 주세요.');
    }
    final home = await request(Uri.parse(data['redirect_url']));
    if (home.contains('name="loginForm"')) {
      throw CampusException('포털 로그인에 실패했습니다.');
    }
  }

  Future<List<CampusItem>> fetchItems() async {
    final terms = await api('/term/getYearTermList', null);
    final term = (terms['list'] as List)
        .cast<Map>()
        .where((m) => m['current_term_yn'] == 'Y')
        .firstOrNull;
    if (term == null) throw CampusException('현재 학기를 찾지 못했습니다.');
    final base = <String, dynamic>{
      'term_year': term['term_year'],
      'term_cd': term['term_cd'],
    };
    final courses = await api('/course/getStdMyCourseList', {
      ...base,
      'is_current': 'Y',
    });
    diagnostic?.call(
      'Course count: ${(courses['course_list'] as List).length}',
    );
    final result = <String, CampusItem>{};
    final reports = <String, Map<String, dynamic>>{};
    for (final tab in ['P', 'C', 'I']) {
      final data = await api('/week/getStdTodoList', {
        ...base,
        'to_do_type': tab,
      });
      if (data is! Map || data['todo_list'] is! List) {
        throw CampusException('과제 목록 형식이 변경됐습니다.');
      }
      for (final m in (data['todo_list'] as List).cast<Map>()) {
        if (m['module_type'] == 'LR') {
          final map = Map<String, dynamic>.from(m);
          reports['${m['course_id']}:${m['class_no']}:${m['contents_id']}'] =
              map;
        }
      }
    }
    for (final m in reports.values) {
      final context = <String, dynamic>{
        ...base,
        'course_id': m['course_id'],
        'class_no': m['class_no'],
        'report_no': m['contents_id'],
        'weekseq_no': m['weekseq_no'],
        'item_id': m['item_id'],
      };
      await api('/course/addSessionCourseInfo', context);
      final detail = await api('/task/detail', context);
      final submitted = await api('/task/stdDetail', context);
      if (detail is! Map ||
          !detail.containsKey('report_no') ||
          (submitted != null && submitted is! Map)) {
        throw CampusException('과제 상세 형식이 변경됐습니다.');
      }
      final status = submitted == null || submitted['report_apply_no'] == null
          ? 'pending'
          : submitted['apply_yn'] == 'Y' && submitted['temp_yn'] != 'Y'
          ? 'done'
          : submitted['temp_yn'] == 'Y' || submitted['apply_yn'] == 'N'
          ? 'pending'
          : 'unknown';
      final key = 'LR:${m['course_id']}:${m['class_no']}:${m['contents_id']}';
      result[key] = CampusItem(
        key: key,
        type: 'LR',
        title: textOf(detail['report_nm'] ?? m['item_title_temp']),
        course: textOf(m['course_nm']),
        courseId: str(m, 'course_id'),
        classNo: str(m, 'class_no'),
        contentsId: str(m, 'contents_id'),
        status: status,
        body: textOf(detail['report_content']),
        due:
            campusDate(
              '${detail['report_apply_end_dt']} ${detail['report_apply_end_tm']}',
            ) ??
            campusDate(str(m, 'info')),
        context: context,
      );
    }
    for (final raw in courses['course_list'] as List) {
      final c = Map<String, dynamic>.from(raw);
      await api('/course/addSessionCourseInfo', {
        'course_id': c['course_id'],
        'class_no': c['class_no'],
        ...base,
      });
      final weeks = await api('/week/getStdWeekList', {
        'course_id': c['course_id'],
        'class_no': c['class_no'],
        'is_current': 'N',
      });
      diagnostic?.call('Weeks: ${(weeks['week_list'] as List).length}');
      void visit(dynamic node) {
        if (node is List) {
          for (final child in node) {
            visit(child);
          }
        } else if (node is Map) {
          final m = Map<String, dynamic>.from(node);
          if (m['module_type'] != null) {
            diagnostic?.call('Module: ${m['module_type']}');
          }
          if (m['module_type'] == 'LV' && m['weekseq_no'] != null) {
            final contentId =
                m['contents_id']?.toString() ?? str(m, 'weekseq_no');
            final key =
                'LV:${c['course_id']}:${c['class_no']}:${m['contents_id']}:${m['weekseq_no']}';
            final context = <String, dynamic>{
              ...base,
              'course_id': c['course_id'],
              'class_no': c['class_no'],
              'weekseq_no': m['weekseq_no'],
              'contents_id': m['contents_id'],
              'module_type': 'LV',
            };
            result[key] = CampusItem(
              key: key,
              type: 'LV',
              title: textOf(m['weekseq_nm']),
              course: textOf(c['course_nm']),
              courseId: str(c, 'course_id'),
              classNo: str(c, 'class_no'),
              contentsId: contentId,
              status: m.containsKey('complete_yn')
                  ? m['complete_yn'] == 'Y'
                        ? 'done'
                        : 'pending'
                  : 'unknown',
              body: textOf(m['weekseq_content']),
              due: campusDate(
                '${m['weekseq_end_dt']} ${m['weekseq_end_dt_hour']}:${m['weekseq_end_dt_min']}:00',
              ),
              context: context,
            );
          }
          for (final value in m.values) {
            if (value is List || value is Map) visit(value);
          }
        }
      }

      if (weeks is! Map || weeks['week_list'] is! List) {
        throw CampusException('콘텐츠 목록 형식이 변경됐습니다.');
      }
      visit(weeks['week_list']);
    }
    return result.values.toList()..sort(
      (a, b) =>
          (a.due ?? DateTime.utc(2100)).compareTo(b.due ?? DateTime.utc(2100)),
    );
  }

  Future<Map<String, dynamic>> navigation(CampusItem item) async {
    final ctx = await api('/course/addSessionCourseInfo', item.context);
    final cookies = <Map<String, String>>[];
    for (final host in [learning, loginHost]) {
      for (final c in await jar.loadForRequest(Uri.parse('$host/'))) {
        cookies.add({'url': host, 'cookie': c.toString()});
      }
    }
    return {
      'context': ctx['data'],
      'cookies': cookies,
      'url': item.type == 'NT'
          ? '$learning/std/noticeDetail?no=${Uri.encodeQueryComponent(item.contentsId)}'
          : '$learning${item.type == 'LR' ? '/std/taskView' : '/std/course'}',
      'target': item.contentsId,
    };
  }

  Future<List<CampusNotice>> fetchNotices() async {
    final terms = await api('/term/getYearTermList', null);
    final term = (terms['list'] as List)
        .cast<Map>()
        .where((m) => m['current_term_yn'] == 'Y')
        .firstOrNull;
    if (term == null) throw CampusException('공지의 현재 학기를 찾지 못했습니다.');
    final notices = <String, CampusNotice>{};
    for (var offset = 0; offset < 10000; offset += 100) {
      final data = await api('/board/std/notice/list', {
        'type': 'notice',
        'term_year': term['term_year'],
        'term_cd': term['term_cd'],
        'limit': 100,
        'offset': offset,
      });
      if (data is! Map || data['list'] is! List) {
        throw CampusException('공지 목록 형식이 변경됐습니다.');
      }
      final rows = data['list'] as List;
      for (final raw in rows) {
        final row = Map<String, dynamic>.from(raw);
        final id = str(row, 'boarditem_no');
        if (id.isEmpty || notices.containsKey(id)) {
          throw CampusException('공지 페이지를 정확하게 확인하지 못했습니다.');
        }
        notices[id] = CampusNotice(
          id: id,
          title: textOf(row['boarditem_title']),
          course: textOf(row['course_nm']),
          published: campusDate(str(row, 'insert_dt')),
          read: row['read_yn'] == 'Y',
          context: {
            'term_year': term['term_year'],
            'term_cd': term['term_cd'],
            'course_id': row['course_id'],
            'class_no': row['class_no'],
          },
        );
      }
      final total = int.tryParse('${data['tot_cnt']}');
      if ((total != null && notices.length >= total) || rows.length < 100) {
        return notices.values.toList()..sort(
          (a, b) => (b.published ?? DateTime.utc(1970)).compareTo(
            a.published ?? DateTime.utc(1970),
          ),
        );
      }
    }
    throw CampusException('공지 수가 많아 전체 수집을 끝내지 못했습니다.');
  }

  Future<CampusNotice> fetchNoticeBody(CampusNotice notice) async {
    final context = await api('/course/addSessionCourseInfo', notice.context);
    final session = context is Map && context['data'] is Map
        ? Map<String, dynamic>.from(context['data'])
        : <String, dynamic>{};
    final info = await api('/board/notice/info', {
      ...notice.context,
      ...session,
      'no': notice.id,
    });
    if (info is! Map || !info.containsKey('boarditem_content')) {
      throw CampusException('공지 본문을 확인하지 못했습니다.');
    }
    return CampusNotice(
      id: notice.id,
      title: notice.title,
      course: notice.course,
      context: notice.context,
      published: notice.published,
      read: notice.read,
      body: textOf(info['boarditem_content']),
      bodyFetched: true,
    );
  }

  void close() => http.close(force: true);
}

import 'session_probe_policy.dart';
import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'app_credentials.dart';
import 'app_storage.dart';
import 'campus.dart';
import 'operation_token.dart';
import 'session_scope.dart';
import 'school_lifetime_observer.dart';
import 'session_lifetime_repository.dart';

const reconnectChoices = <int>[15, 30, 60, 120, 240, 360, 480, 720, 1440];

class CampusReconnectDeferred extends CampusException {
  CampusReconnectDeferred(super.message);
}

Future<int?> schoolReconnectMinutes() async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  if (prefs.getBool('schoolReconnectManual') == true) return null;
  final value = prefs.getInt('schoolReconnectMinutes');
  return reconnectChoices.contains(value) ? value : 120;
}

Future<void> saveSchoolReconnectMinutes(int? minutes) async {
  if (minutes != null && !reconnectChoices.contains(minutes)) {
    throw ArgumentError.value(minutes);
  }
  final prefs = await SharedPreferences.getInstance();
  if (minutes == null) {
    await prefs.setBool('schoolReconnectManual', true);
    await prefs.remove('schoolReconnectMinutes');
  } else {
    await prefs.setInt('schoolReconnectMinutes', minutes);
    await prefs.setBool('schoolReconnectManual', false);
  }
}

String _sessionKey(String account) =>
    'schoolSession:${sha256.convert(utf8.encode(account))}';

/// Only explicit authentication evidence starts a hold. Network and schema
/// errors leave the encrypted snapshot intact and never trigger a login retry.
Future<void> _markLost(Store store, SessionScope scope) async {
  await scope.verify();
  if (await store.meta('schoolSessionLostEpoch') == scope.epoch &&
      await store.meta('schoolSessionLostAt') != null) {
    return;
  }
  await store.setMeta('schoolSessionLostEpoch', scope.epoch);
  await store.setMeta(
    'schoolSessionLostAt',
    DateTime.now().toUtc().toIso8601String(),
  );
  await store.log(
    'sync',
    '학교 세션 재연결 보류',
    '학교 인증이 종료됐어요. 다른 기기에서 로그인했을 수 있어 설정한 시간만큼 재로그인을 미뤄요. 원인은 확정할 수 없으며 기존 목록은 유지해요.',
  );
}

Future<void> rememberSchoolSession(
  Map<String, dynamic> snapshot,
  String account,
) async {
  final store = await Store.open();
  try {
    final scope = await SessionScope.capture(store);
    if (scope.account != account) throw SessionChanged();
    final observationId = freshToken();
    await credentials.write(
      key: _sessionKey(account),
      value: jsonEncode({
        'epoch': scope.epoch,
        'snapshot': snapshot,
        'observationId': observationId,
      }),
    );
    await scope.verify();
    try {
      await SessionLifetimeRepository(store).change(scope.epoch, (state) {
        final now = DateTime.now().toUtc().millisecondsSinceEpoch;
        state.beginSession(observationId, now, freshlyLoggedIn: true);
        state.beginValidation('credential-verification', now);
        state.validated('credential-verification', now);
      });
    } catch (_) {
      // Unreadable optional diagnostics must not break credential saving.
    }
    await store.setMeta('schoolSessionLostAt', '');
    await store.setMeta('schoolSessionLostEpoch', '');
  } finally {
    await store.db.close();
  }
}

extension ReusableSchoolSession on CampusClient {
  Future<void> connectSchool(
    String account,
    String password, {
    bool reconnectNow = false,
    bool allowFreshLogin = true,
    bool forSessionTest = false,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.reload();
    if (forSessionTest &&
        !SessionProbePolicy.fromPreferences(prefs).activeAt(DateTime.now())) {
      throw CampusReconnectDeferred('전용 세션 테스트가 종료되어 연결을 시작하지 않았어요.');
    }
    if (SessionProbePolicy.fromPreferences(prefs).activeAt(DateTime.now()) &&
        !forSessionTest &&
        !reconnectNow) {
      // Manual reads may reuse the session and restart the idle clock, but a
      // stale automatic job must not replace the test's session by logging in.
      allowFreshLogin = false;
    }
    final store = await Store.open();
    final owner = freshToken();
    var locked = false;
    var observationId = freshToken();
    SchoolLifetimeObserver? observer;
    try {
      final scope = await SessionScope.capture(store);
      if (scope.account != account) throw SessionChanged();
      Future<void> persistUpdatedSession() async {
        final current = await Store.open();
        try {
          final active = await SessionScope.capture(current);
          if (active.account != account || active.epoch != scope.epoch) {
            throw SessionChanged();
          }
          await credentials.write(
            key: _sessionKey(account),
            value: jsonEncode({
              'epoch': scope.epoch,
              'snapshot': exportSession(),
              'observationId': observationId,
            }),
          );
          await active.verify();
        } finally {
          await current.db.close();
        }
      }

      // A separate auth lease avoids concurrent UI/worker fresh logins. Never
      // reuse the collection lease, which synchronize already owns.
      locked = await store.db.transaction((txn) async {
        final rows = await txn.query(
          'meta',
          where: 'id=?',
          whereArgs: ['schoolAuthLease'],
        );
        final until = rows.isEmpty
            ? 0
            : int.tryParse('${rows.first['value']}') ?? 0;
        final now = DateTime.now().millisecondsSinceEpoch;
        if (until > now) return false;
        await txn.rawInsert(
          'INSERT OR REPLACE INTO meta(id,value) VALUES(?,?)',
          [
            'schoolAuthLease',
            '${now + const Duration(minutes: 5).inMilliseconds}',
          ],
        );
        await txn.rawInsert(
          'INSERT OR REPLACE INTO meta(id,value) VALUES(?,?)',
          ['schoolAuthLeaseOwner', owner],
        );
        return true;
      });
      if (!locked) {
        throw CampusException('다른 학교 연결을 준비하고 있어요. 잠시 뒤 다시 확인해 주세요.');
      }
      await scope.verify();
      final lostAt = await store.meta('schoolSessionLostEpoch') == scope.epoch
          ? DateTime.tryParse(await store.meta('schoolSessionLostAt') ?? '')
          : null;
      if (lostAt != null && !reconnectNow) {
        final minutes = await schoolReconnectMinutes();
        if (minutes == null) {
          throw CampusReconnectDeferred(
            '학교 세션이 끊겨 자동 재로그인을 보류했어요. 백그라운드 상태에서 재연결 대기 시간을 선택하거나 포털을 다시 연결해 주세요.',
          );
        }
        final until = lostAt.add(Duration(minutes: minutes));
        if (DateTime.now().toUtc().isBefore(until)) {
          throw CampusReconnectDeferred(
            '다른 기기 접속을 보호하기 위해 재로그인을 기다리고 있어요. 약 ${until.difference(DateTime.now().toUtc()).inMinutes + 1}분 후 다음 수집에서 다시 연결해요.',
          );
        }
      }
      final saved = await credentials.read(key: _sessionKey(account));
      if (saved != null && lostAt == null && !reconnectNow) {
        Map<String, dynamic> envelope;
        try {
          envelope = Map<String, dynamic>.from(jsonDecode(saved) as Map);
          if (envelope['epoch'] == scope.epoch) {
            observationId =
                envelope['observationId'] as String? ?? observationId;
            restoreSession(
              Map<String, dynamic>.from(envelope['snapshot'] as Map),
            );
          }
        } catch (_) {
          // Do not silently replace an unreadable session by logging in.
          throw CampusException('저장한 학교 연결 정보를 읽지 못했어요. 포털을 다시 연결해 주세요.');
        }
        if (envelope['epoch'] == scope.epoch) {
          authenticationLost = () async {
            final current = await Store.open();
            try {
              final active = await SessionScope.capture(current);
              if (active.epoch != scope.epoch || active.account != account) {
                throw SessionChanged();
              }
              await _markLost(current, active);
              await observer?.failed(CampusAuthenticationLost());
            } finally {
              await current.db.close();
            }
          };
          observer = await SchoolLifetimeObserver.attach(
            this,
            scope.epoch,
            observationId,
            fresh: false,
          );
          await fetchCourses(); // Authenticated, read-only endpoint, not /home.
          await observer.validated();
          await scope.verify();
          await credentials.write(
            key: _sessionKey(account),
            value: jsonEncode({
              'epoch': scope.epoch,
              'snapshot': exportSession(),
              'observationId': observationId,
            }),
          );
          diagnostic?.call('School session reused');
          sessionUpdated = persistUpdatedSession;
          return;
        }
      }
      if (!allowFreshLogin) {
        throw CampusReconnectDeferred(
          '세션 탐색은 새로 로그인하지 않아요. 기존 세션이 없어 탐색을 보류했어요.',
        );
      }
      if (forSessionTest) {
        await prefs.reload();
        if (!SessionProbePolicy.fromPreferences(
          prefs,
        ).activeAt(DateTime.now())) {
          throw CampusReconnectDeferred('전용 세션 테스트가 종료되어 로그인하지 않았어요.');
        }
      }
      authenticationLost = null;
      sessionUpdated = null;
      if (lostAt != null) {
        // A failed reconnection attempt must not cause a rapid login loop.
        await store.setMeta(
          'schoolSessionLostAt',
          DateTime.now().toUtc().toIso8601String(),
        );
      }
      await login(account, password);
      await scope.verify();
      await credentials.write(
        key: _sessionKey(account),
        value: jsonEncode({
          'epoch': scope.epoch,
          'snapshot': exportSession(),
          'observationId': observationId,
        }),
      );
      await store.setMeta('schoolSessionLostAt', '');
      await store.setMeta('schoolSessionLostEpoch', '');
      authenticationLost = () async {
        final current = await Store.open();
        try {
          final active = await SessionScope.capture(current);
          if (active.epoch != scope.epoch || active.account != account) {
            throw SessionChanged();
          }
          await _markLost(current, active);
          await observer?.failed(CampusAuthenticationLost());
        } finally {
          await current.db.close();
        }
      };
      // Persist the login result before the first read: a network failure on
      // that read must not discard a valid new login and kick another device
      // again on the next attempt.
      sessionUpdated = persistUpdatedSession;
      observer = await SchoolLifetimeObserver.attach(
        this,
        scope.epoch,
        observationId,
        fresh: true,
      );
      await fetchCourses();
      await observer.validated();
      diagnostic?.call('School session newly connected');
    } catch (error) {
      if (error is! CampusReconnectDeferred) await observer?.failed(error);
      rethrow;
    } finally {
      if (locked) {
        await store.db.transaction((txn) async {
          final rows = await txn.query(
            'meta',
            where: 'id=?',
            whereArgs: ['schoolAuthLeaseOwner'],
          );
          if (rows.isNotEmpty && rows.single['value'] == owner) {
            await txn.delete(
              'meta',
              where: 'id IN (?,?)',
              whereArgs: ['schoolAuthLease', 'schoolAuthLeaseOwner'],
            );
          }
        });
      }
      await store.db.close();
    }
  }
}

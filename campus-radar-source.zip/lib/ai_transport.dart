import 'ai_protocol.dart';
import 'session_scope.dart';
import 'network_resilience.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';

Future<Map<String, dynamic>> guardedAiTransport(
  SessionScope scope,
  AiTransport transport,
  String key,
  Map<String, dynamic> body,
) async {
  await scope.verify();
  final response = transport == geminiTransport
      ? await geminiTransport(key, body, scope: scope)
      : await transport(key, body);
  await scope.verify();
  return response;
}

Future<Map<String, dynamic>> geminiTransport(
  String key,
  Map<String, dynamic> body, {
  SessionScope? scope,
}) async {
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 20);
  ActiveRequests.add(client);
  final watch = scope?.watch(() => client.close(force: true));
  final deadline = Timer(
    const Duration(seconds: 90),
    () => client.close(force: true),
  );
  try {
    await scope?.verify();
    final request = await client.postUrl(
      Uri.parse(
        'https://generativelanguage.googleapis.com/v1beta/models/$aiModel:generateContent',
      ),
    );
    request.followRedirects = false;
    request.headers.set('x-goog-api-key', key);
    request.headers.contentType = ContentType.json;
    request.write(jsonEncode(body));
    final response = await request.close().timeout(const Duration(seconds: 60));
    final bytes = <int>[];
    await for (final chunk in response.timeout(const Duration(seconds: 30))) {
      bytes.addAll(chunk);
      if (bytes.length > 1000000) throw const AiFailure('AI 응답이 너무 큽니다.');
    }
    if (response.statusCode == 429) {
      throw const AiFailure(
        'Gemini 사용량 한도에 도달했습니다. 잠시 후 또는 일일 한도 초기화 후 다시 시도해 주세요.',
        code: 'quota',
        detail: 'HTTP 429 · Google의 요청 빈도 또는 일일 사용량 한도에 도달했습니다.',
      );
    }
    if (response.statusCode == 400) {
      throw const AiFailure(
        'Gemini가 요청을 거절했어요.',
        code: 'request',
        detail:
            'HTTP 400 · 키 유효성, 모델 지원 또는 요청 형식 문제일 수 있어요. 추가 자료로 해결된다고 볼 수 없습니다.',
      );
    }
    if (response.statusCode == 401 || response.statusCode == 403) {
      throw AiFailure(
        'API 키·프로젝트 권한 또는 요청 지원 여부를 확인해 주세요.',
        code: 'credentials',
        detail: 'HTTP ${response.statusCode} · API 키 또는 프로젝트 접근 권한을 확인해 주세요.',
      );
    }
    if (response.statusCode != 200) {
      throw AiFailure(
        'Gemini 서버가 정상 응답하지 않았어요.',
        code: 'network',
        detail: 'HTTP ${response.statusCode} · 잠시 후 다시 시도해 주세요.',
      );
    }
    return jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
  } on AiFailure {
    rethrow;
  } on FormatException {
    throw const AiFailure(
      'AI 서버 응답 형식을 읽지 못했습니다.',
      code: 'response',
      detail: '완전한 응답인지 확인하지 못해 저장하지 않았습니다. 기존 일정은 유지합니다. 다시 시도할 수 있습니다.',
    );
  } on HandshakeException catch (e) {
    throw AiFailure(
      'AI 서버와 보안 연결에 실패했습니다.',
      code: 'network',
      detail: networkFailureMessage(e),
    );
  } catch (_) {
    throw const AiFailure(
      'AI 분석 통신을 완료하지 못했습니다. 연결을 확인해 주세요.',
      code: 'network',
      detail: '연결 시간 초과 또는 통신 중단입니다. 공지 내용의 문제로 확정할 수 없어요.',
    );
  } finally {
    deadline.cancel();
    watch?.cancel();
    ActiveRequests.remove(client);
    client.close(force: true);
  }
}

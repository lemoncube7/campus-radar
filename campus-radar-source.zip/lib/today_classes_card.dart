import 'cancellation_repository.dart';
import 'dart:async';
import 'timetable_exceptions.dart';
import 'timetable_grid.dart';
import 'today_class_model.dart';
import 'timetable_cancellations_page.dart';
import 'navigation_contract.dart';
import 'native_contract.dart';
import 'app_storage.dart';
import 'native_bridge.dart';
import 'course_labels.dart';
import 'package:flutter/material.dart';
import 'timetable_model.dart';

class TodayClassesCard extends StatefulWidget {
  final int refreshToken;
  final bool compact;
  const TodayClassesCard({
    super.key,
    this.refreshToken = 0,
    this.compact = false,
  });
  @override
  State<TodayClassesCard> createState() => _TodayClassesState();
}

class _TodayClassesState extends State<TodayClassesCard> {
  List<ClassSlot> entries = [];
  List<ClassCancellation> cancellations = [];
  bool loaded = false;
  bool reading = false;
  String? error;
  DateTime? until;
  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void didUpdateWidget(covariant TodayClassesCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.refreshToken != widget.refreshToken) unawaited(load());
  }

  Future<void> load() async {
    if (reading || !mounted) return;
    reading = true;
    Store? store;
    try {
      store = await Store.open();
      if (!mounted) return;
      final slots = decodeSlots(await store.meta('timetableEntries'));
      final cancelled = await readClassCancellations(store);
      Map<String, dynamic>? settings;
      try {
        settings = await bridge.invokeNativeMap<String, dynamic>(
          NativeMethod.timetableSettings,
        );
      } catch (_) {}
      if (mounted) {
        setState(() {
          entries = slots;
          cancellations = cancelled;
          until = DateTime.tryParse('${settings?['until'] ?? ''}');
          loaded = true;
          error = null;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          loaded = true;
          error = '저장된 수업 정보를 확인하지 못했어요.';
        });
      }
    } finally {
      await store?.db.close();
      reading = false;
    }
  }

  Future<void> open() async {
    await navigateTo(context, TimetableDestination());
    await load();
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now().toUtc().add(const Duration(hours: 9));
    final civilNow = DateTime(
      now.year,
      now.month,
      now.day,
      now.hour,
      now.minute,
      now.second,
    );
    final next = nextClassOccurrence(entries, cancellations, now, until: until);
    final cancelledToday = cancellations
        .where((c) => c.date == classDate(now))
        .length;
    final started = next != null && !civilNow.isBefore(next.start);
    final minutes = next?.start.difference(civilNow).inMinutes;
    final days = next?.day
        .difference(DateTime(now.year, now.month, now.day))
        .inDays;
    final when = started
        ? '수업 중'
        : days == 0
        ? (minutes! < 60
              ? '$minutes분 후 시작'
              : '${minutes ~/ 60}시간${minutes % 60 == 0 ? "" : " ${minutes % 60}분"} 후 시작')
        : days == 1
        ? '내일'
        : days == null
        ? ''
        : '${next!.day.month}/${next.day.day}';
    if (widget.compact) {
      return Card(
        color: Theme.of(
          context,
        ).colorScheme.secondaryContainer.withValues(alpha: .45),
        child: ListTile(
          leading: Icon(
            started ? Icons.school_outlined : Icons.schedule,
            color: Theme.of(context).colorScheme.secondary,
          ),
          title: Text(
            next == null
                ? '다음 수업'
                : '${started ? "지금" : "다음"} · ${courseLabel(next.slot.course)}',
            style: Theme.of(context).textTheme.titleSmall,
          ),
          subtitle: Text(
            !loaded
                ? '시간표 확인 중…'
                : error ??
                      (next == null
                          ? (entries.isEmpty
                                ? '시간표를 만들면 다음 수업을 알려드려요.'
                                : '예정된 다음 수업이 없어요.')
                          : '$when · ${slotTime(next.slot.start)}–${slotTime(next.slot.end)} · ${next.slot.room.isEmpty ? "강의실 미확인" : next.slot.room}${cancelledToday > 0 ? " · 오늘 휴강 $cancelledToday건" : ""}'),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: open,
        ),
      );
    }
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Icon(
                  started ? Icons.school_outlined : Icons.schedule,
                  size: 20,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    started ? '지금 수업' : '다음 수업',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                TextButton(onPressed: open, child: const Text('시간표')),
              ],
            ),
            if (!loaded)
              const LinearProgressIndicator()
            else if (error != null)
              Text(error!)
            else if (next == null)
              Text(
                entries.isEmpty
                    ? '시간표를 만들면 다음 수업을 알려드려요.'
                    : '저장된 시간표에 예정된 다음 수업이 없어요.',
              )
            else
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(
                  courseLabel(next.slot.course),
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                subtitle: Text(
                  '${weekNames[next.slot.weekday - 1]} ${slotTime(next.slot.start)}–${slotTime(next.slot.end)}\n${next.slot.room.isEmpty ? '강의실 미확인' : next.slot.room}',
                ),
                trailing: Text(
                  when,
                  style: Theme.of(context).textTheme.labelLarge?.copyWith(
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
                onTap: () => TimetableGrid(
                  entries: entries,
                ).showClass(context, next.slot),
              ),
            if (cancelledToday > 0)
              TextButton.icon(
                onPressed: () async {
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const TimetableCancellationsPage(),
                    ),
                  );
                  await load();
                },
                icon: const Icon(Icons.event_busy, size: 18),
                label: Text('오늘 휴강 처리 $cancelledToday건 · 근거 확인'),
              ),
            Text(
              '저장한 시간표와 반영한 휴강 기준',
              style: Theme.of(context).textTheme.labelSmall,
            ),
          ],
        ),
      ),
    );
  }
}

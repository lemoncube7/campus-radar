import 'ai_state_repository.dart';
import 'ai_state_models.dart';
import 'ai_protocol.dart';
import 'app_storage.dart';
import 'campus_models.dart';
import 'dart:convert';

String recoveryCode(Map job) {
  final code = job['errorCode'] as String?;
  if (code != null && code != 'failed') return code;
  final message = '${job['error'] ?? ''}';
  if (message.contains('근거 또는 일정 유형')) return 'legacy_validation';
  if (message.contains('근거')) return 'evidence';
  if (message.contains('날짜')) return 'date';
  if (message.contains('시간')) return 'time';
  if (message.contains('키') || message.contains('권한')) return 'credentials';
  if (message.contains('한도')) return 'quota';
  if (message.contains('길어')) return 'length';
  if (message.contains('본문') || message.contains('포털')) return 'source';
  if (message.contains('응답')) return 'format';
  return 'unknown';
}

String recoveryExplanation(String code) => switch (code) {
  'legacy_validation' =>
    '이전 버전이 원문 근거와 일정 유형 오류를 하나로 기록해서 어느 검증에서 실패했는지는 이 기록만으로 구분할 수 없어요. 새로 분석하면 구체적인 원인을 기록해요.',
  'evidence' =>
    'AI가 선택한 원문 문단이나 인용 근거를 확인하지 못했어요. 자동 수정 요청도 실패했다면 기기에 저장된 검증 기록에서 실제 응답을 확인할 수 있어요.',
  'dateEvidence' || 'timeEvidence' =>
    '선택한 원문에는 날짜·시각이 있지만 AI가 반환한 일정 값과 달라 저장을 중단했어요. 아래 상세 오류에서 반환 값과 원문을 비교할 수 있어요.',
  'coverage' =>
    '원문에 있는 일부 일정 날짜가 빠졌어요. 자동으로 한 번 보완하고도 누락이 남으면 후보에 원문 추가 확인 안내를 표시해요.',
  'timetable' =>
    '시간표가 없거나, 선택한 과목·요일·시각이 추정한 일정과 맞지 않아요. 시간표를 확인·수정한 후 다시 분석할 수 있어요.',
  'category' => 'AI가 새 일정·변경·취소 또는 일정 분류를 올바르게 구분하지 못했어요.',
  'date' ||
  'time' => 'AI가 반환한 날짜나 시각이 유효하지 않아 저장하지 않았어요. 관련 자료를 참고하거나 직접 입력할 수 있어요.',
  'request' =>
    'Gemini가 요청을 거절했어요. 키 유효성이나 모델·요청 형식 문제일 수 있어요. 추가 자료를 보내기 전에 AI 설정과 상세 오류를 확인해 주세요.',
  'credentials' =>
    'API 키나 프로젝트 권한 때문에 요청이 거절됐어요. 추가 자료로 해결할 수 없으니 AI 설정을 확인해 주세요.',
  'quota' =>
    'Gemini가 사용량 한도 초과를 반환했어요. 분당·일일 한도 중 어느 것인지는 이 오류만으로 확정할 수 없어요. 사용량을 확인하고 기다린 뒤 시도해 주세요.',
  'source' => '공지 본문 수집 또는 포털 연결에 문제가 있어요. 원문 확인에서 본문을 불러온 뒤 분석할 수 있어요.',
  'length' =>
    '대상 공지가 본문 길이 제한을 넘었어요. 추가 자료를 보내도 해결되지 않으므로 원문 확인 또는 직접 일정 추가를 사용해 주세요.',
  'format' || 'incomplete' =>
    'AI가 응답을 끝내지 못했거나 일정 형식에 맞지 않는 내용을 반환했어요. 이전 실패 이유를 포함해 다시 요청할 수 있어요.',
  'network' || 'busy' => '연결 또는 요청 처리 대기 문제예요. 연결 상태를 확인하고 잠시 후 다시 시도할 수 있어요.',
  _ =>
    '저장된 기록만으로 원인을 더 정확히 분류할 수 없어요. 아래 실제 오류를 확인하고 원문 확인·직접 추가·분석 제외를 선택할 수 있어요.',
};

bool sameRecoveryCourse(
  CampusNotice target,
  Map<String, dynamic> context,
  String name,
) {
  final id = target.context['course_id'], section = target.context['class_no'];
  if (id != null && section != null) {
    return '${context['course_id']}' == '$id' &&
        '${context['class_no']}' == '$section';
  }
  return name == target.course;
}

class RecoveryContext {
  final List<Map<String, dynamic>> notices, items;
  final String syllabus;
  final String? syllabusAt;
  const RecoveryContext({
    this.notices = const [],
    this.items = const [],
    this.syllabus = '',
    this.syllabusAt,
  });
  String selected({
    required bool includeNotices,
    required bool includeItems,
    required bool includePlan,
  }) => jsonEncode({
    'scope': '대상 공지와 같은 과목의 기기 저장 자료. 최신 상태와 전체 자료를 보장하지 않음.',
    if (includeNotices && notices.isNotEmpty) 'notices': notices,
    if (includeItems && items.isNotEmpty) 'items': items,
    if (includePlan && syllabus.isNotEmpty)
      'syllabus': {'text': syllabus, 'savedAt': syllabusAt},
  });
}

Future<RecoveryContext> recoveryContext(
  Store store,
  CampusNotice target,
) async {
  String clip(String value, int limit) =>
      value.length > limit ? '${value.substring(0, limit)}\n[이후 생략]' : value;
  final excluded = await store.excluded();
  final notices = (await store.notices())
      .where(
        (n) =>
            n.id != target.id &&
            sameRecoveryCourse(target, n.context, n.course),
      )
      .take(4)
      .map(
        (n) => <String, dynamic>{
          'title': n.title,
          'published': n.published?.toIso8601String(),
          'body': clip(n.body, 1800),
          'bodyLoaded': n.bodyFetched,
        },
      )
      .toList();
  final items = (await store.items())
      .where(
        (i) =>
            sameRecoveryCourse(target, i.context, i.course) &&
            i.availableAt(DateTime.now().toUtc()) &&
            !excluded.contains(i.key),
      )
      .take(6)
      .map(
        (i) => <String, dynamic>{
          'title': i.title,
          'type': i.type,
          'status': i.status,
          'due': i.due?.toIso8601String(),
          'body': clip(i.body, 700),
        },
      )
      .toList();
  final course = '${target.context['course_id']}:${target.context['class_no']}';
  final raw = await store.meta('coursePlan:$course');
  final plan = raw == null
      ? <String, dynamic>{}
      : Map<String, dynamic>.from(jsonDecode(raw));
  // The linked syllabus is the actual plan used by the course page. Never send the raw portal response.
  final text = plan['linkedText'] as String? ?? '';
  return RecoveryContext(
    notices: notices,
    items: items,
    syllabus: clip(text, 6000),
    syllabusAt: plan['fetchedAt'] as String?,
  );
}

Future<void> excludeNoticeAnalysis(Store store, CampusNotice notice) async {
  final old =
      jsonDecode(await store.meta('aiQueue:${notice.id}') ?? '{}') as Map;
  await AiStateRepository(store).saveJob(
    notice.id,
    AiJob.fromJson({
      ...old,
      'status': 'excluded',
      'fingerprint': noticeFingerprint(notice),
      'title': notice.title,
    }),
  );
  await store.log('ai', '공지 분석 제외', notice.title);
}

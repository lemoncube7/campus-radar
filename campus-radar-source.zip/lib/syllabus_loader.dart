import 'campus.dart';
import 'native_bridge.dart';
import 'native_contract.dart';

typedef LinkedPlanReader =
    Future<Map<String, dynamic>?> Function(String url, String course);

bool isAllowedSyllabusUrl(String value) {
  final uri = Uri.tryParse(value);
  return uri != null &&
      uri.scheme == 'https' &&
      {'cnuit.cnu.ac.kr', 'tlsn.cnu.ac.kr'}.contains(uri.host) &&
      uri.userInfo.isEmpty;
}

/// Shared native fetch policy for the course page and timetable builder.
/// Account/session verification and persistence remain with each operation.
Future<String> loadLinkedSyllabus(
  String url,
  String course, {
  LinkedPlanReader? reader,
}) async {
  if (!isAllowedSyllabusUrl(url)) {
    throw CampusException('계획서 바로가기 주소를 확인하지 못했습니다.');
  }
  final fetched =
      await (reader != null
              ? reader(url, course)
              : bridge.invokeNativeMap<String, dynamic>(
                  NativeMethod.fetchLinkedPlan,
                  {'url': url, 'course': course},
                ))
          .timeout(const Duration(seconds: 75));
  final text = fetched?['text'] as String?;
  if (text == null || text.trim().isEmpty) {
    throw CampusException('실제 계획서 본문을 가져오지 못했습니다.');
  }
  return text;
}

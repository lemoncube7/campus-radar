import 'package:flutter/material.dart';
import 'campus_models.dart';
import 'notice_ai_service.dart';
import 'ai_inbox_page.dart';
import 'navigation_contract.dart';
import 'ui_formatters.dart';
import 'ai_protocol.dart';
import 'ai_recovery_page.dart';

class NoticeAnalysisPage extends StatefulWidget {
  final CampusNotice notice;
  const NoticeAnalysisPage({super.key, required this.notice});
  @override
  State<NoticeAnalysisPage> createState() => _NoticeAnalysisState();
}

class _NoticeAnalysisState extends State<NoticeAnalysisPage> {
  bool busy = false;
  int revision = 0;
  String? error;
  AiFailure? failure;
  Future<void> analyze() async {
    setState(() {
      busy = true;
      error = null;
      failure = null;
    });
    try {
      await NoticeAi.analyze(widget.notice);
      if (mounted) setState(() => revision++);
    } catch (e) {
      if (mounted) {
        setState(() {
          error = userError(e);
          failure = e is AiFailure ? e : null;
        });
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('공지의 일정')),
    body: AiInboxPage(
      key: ValueKey(revision),
      embedded: true,
      noticeId: widget.notice.id,
      initialFilter: 'all',
      showTools: false,
      header: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              widget.notice.title,
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 8),
            const Text(
              '저장된 일정과 확정 상태를 바로 확인하세요. 새로 찾으면 공지 본문을 Gemini에 보내며, 자동 승인 설정을 따릅니다.',
            ),
            const SizedBox(height: 8),
            FilledButton.icon(
              onPressed: busy ? null : analyze,
              icon: const Icon(Icons.event_available),
              label: Text(busy ? '일정 찾는 중…' : '일정 찾기·저장 결과 확인'),
            ),
            TextButton(
              onPressed: () => navigateTo(context, AiSettingsDestination()),
              child: const Text('일정 자동 정리 설정'),
            ),
            ExpansionTile(
              title: const Text('공지 원문'),
              children: [SelectableText(widget.notice.body)],
            ),
            if (error != null) ...[
              Text(error!),
              TextButton(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => AiRecoveryPage(
                      notice: widget.notice,
                      job: {
                        'status': 'failed',
                        'error': error,
                        'errorCode': failure?.code,
                        'errorDetail': failure?.detail,
                      },
                    ),
                  ),
                ),
                child: const Text('원인과 해결 방법'),
              ),
            ],
          ],
        ),
      ),
    ),
  );
}

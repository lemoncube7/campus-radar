import 'package:flutter/material.dart';
import 'package:campus_radar/settings/app_help_catalog.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';

class AppHelpPage extends StatefulWidget {
  final bool autofocus;
  const AppHelpPage({super.key, this.autofocus = false});
  @override
  State<AppHelpPage> createState() => _AppHelpState();
}

class _AppHelpState extends State<AppHelpPage> {
  String query = '';
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('기능 안내·빠른 설정')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        TextField(
          autofocus: widget.autofocus,
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search),
            hintText: 'AI, 캘린더, 알림, 위젯…',
          ),
          onChanged: (v) => setState(() => query = v.trim().toLowerCase()),
        ),
        const SizedBox(height: 16),
        const Text('원하는 기능을 고르면 필요한 설정을 순서대로 열어드려요. AI 키 없이도 안내를 볼 수 있어요.'),
        for (final t in appHelpTopics.where(
          (t) =>
              '${t.title} ${t.description} ${t.steps.join(' ')} ${t.keywords.join(' ')}'
                  .toLowerCase()
                  .contains(query),
        ))
          ListTile(
            title: Text(t.title),
            subtitle: Text(t.description),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => openHelpGuide(context, t),
          ),
      ],
    ),
  );
}

Future<void> openHelpGuide(BuildContext context, AppHelpTopic topic) async {
  await Navigator.push(
    context,
    MaterialPageRoute<void>(builder: (_) => AppHelpGuide(topic: topic)),
  );
}

class AppHelpGuide extends StatefulWidget {
  final AppHelpTopic topic;
  const AppHelpGuide({super.key, required this.topic});
  @override
  State<AppHelpGuide> createState() => _GuideState();
}

class _GuideState extends State<AppHelpGuide> {
  int step = 0;
  List<(String, HelpTool)> get actions => switch (widget.topic.id) {
    'ai-calendar' => [
      ('AI 설정 열기', HelpTool.ai),
      ('캘린더 설정 열기', HelpTool.calendarSettings),
      ('검토함 열기', HelpTool.review),
      ('캘린더 열기', HelpTool.calendar),
    ],
    'ai' => [
      ('AI 설정 열기', HelpTool.ai),
      ('공지 모아보기 열기', HelpTool.notices),
      ('검토함 열기', HelpTool.review),
    ],
    'timetable' => [
      ('시간표 열기', HelpTool.timetable),
      ('수업 알림 설정 열기', HelpTool.classNotifications),
    ],
    'notifications' => [
      ('알림 설정 열기', HelpTool.notifications),
      ('알림·백그라운드 권한 열기', HelpTool.permissions),
    ],
    'widgets' => [('위젯 설정 열기', HelpTool.widgets)],
    'collection' => [
      ('학교 연결·수집 열기', HelpTool.background),
      ('활동 로그 열기', HelpTool.history),
    ],
    'appearance' => [('화면 설정 열기', HelpTool.appearance)],
    'drive' => [('Drive 연결 열기', HelpTool.drive)],
    'materials' => [('자료실 모아보기 열기', HelpTool.materials)],
    'app-notices' => [('공지 목록 열기', HelpTool.appNotices)],
    _ => [('할 일 표시 설정 열기', HelpTool.tasks)],
  };
  @override
  Widget build(BuildContext context) {
    final topic = widget.topic;
    // A topic may have more steps than buttons; reuse the last button.
    final action = actions[step.clamp(0, actions.length - 1)];
    return Scaffold(
      appBar: AppBar(title: Text(topic.title)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(topic.description),
          const SizedBox(height: 16),
          Text(
            '${step + 1} / ${topic.steps.length}',
            style: Theme.of(context).textTheme.labelLarge,
          ),
          LinearProgressIndicator(value: (step + 1) / topic.steps.length),
          const SizedBox(height: 24),
          Text(
            topic.steps[step],
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            icon: const Icon(Icons.open_in_new),
            label: Text(action.$1),
            onPressed: () =>
                navigateTo(context, HelpToolDestination(action.$2)),
          ),
          const SizedBox(height: 12),
          const Text(
            '설정 화면에서 선택한 뒤 뒤로 오면 안내를 이어갈 수 있어요. 안내를 넘기는 것만으로 설정이 변경되지는 않아요.',
          ),
          const SizedBox(height: 24),
          Wrap(
            spacing: 12,
            children: [
              if (step > 0)
                TextButton(
                  onPressed: () => setState(() => step--),
                  child: const Text('이전 단계'),
                ),
              FilledButton.tonal(
                onPressed: () {
                  if (step + 1 < topic.steps.length) {
                    setState(() => step++);
                  } else {
                    Navigator.pop(context);
                  }
                },
                child: Text(step + 1 < topic.steps.length ? '다음 단계' : '안내 닫기'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

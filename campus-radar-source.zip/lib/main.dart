import 'updates.dart';
import 'expansion_pages.dart';
import 'ux_pages.dart';
import 'ai_automation.dart';
import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:workmanager/workmanager.dart';
import 'campus.dart';
import 'services.dart';
import 'features.dart';
import 'ai_pages.dart';

final navKey = GlobalKey<NavigatorState>();
Future<void> openItem(String? key) async {
  if (key == null) return;
  if (key == '_summary') {
    navKey.currentState?.push(
      MaterialPageRoute(builder: (_) => const DailySummaryPage()),
    );
    return;
  }
  final store = await Store.open();
  final item = (await store.items()).where((i) => i.key == key).firstOrNull;
  final excluded = (await store.excluded()).contains(key);
  await store.log(
    'notification',
    '알림 클릭',
    item == null
        ? '현재 목록에 없는 항목의 알림입니다.'
        : '${courseLabel(item.course)} · ${item.title}',
  );
  await store.db.close();
  if (item != null) {
    navKey.currentState?.push(
      MaterialPageRoute(
        builder: (_) => DetailPage(item: item, excluded: excluded),
      ),
    );
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    MaterialApp(
      navigatorKey: navKey,
      debugShowCheckedModeBanner: false,
      title: '캠퍼스레이더',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff3448ae)),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xfff6f7fb),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xfff6f7fb),
          surfaceTintColor: Colors.transparent,
          centerTitle: false,
        ),
        cardTheme: CardThemeData(
          elevation: 0,
          color: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
      home: const StartupGate(),
    ),
  );
}

Future<String?> initializeServices() async {
  if (Platform.isAndroid) {
    bridge.setMethodCallHandler((call) async {
      if (call.method == 'openTarget') {
        await openItem(call.arguments as String?);
      }
    });
  }
  await loadCourseAliases();
  await recordInstalledVersion();
  await initNotifications(onTap: openItem).timeout(const Duration(seconds: 15));
  await Workmanager()
      .initialize(backgroundDispatcher)
      .timeout(const Duration(seconds: 15));
  if (await credentials.read(key: 'id').timeout(const Duration(seconds: 15)) !=
      null) {
    await registerBackground().timeout(const Duration(seconds: 15));
  }
  if (Platform.isAndroid) {
    try {
      final settings = await bridge.invokeMapMethod<String, dynamic>(
        'dailySettings',
      );
      await scheduleSummaryWarmup(
        settings?['hour'] ?? 18,
        settings?['minute'] ?? 0,
        settings?['enabled'] == true,
      );
    } catch (_) {}
  }
  final launch = await notifications.getNotificationAppLaunchDetails().timeout(
    const Duration(seconds: 15),
  );
  if (Platform.isAndroid) {
    final target = await bridge.invokeMethod<String>('takeLaunchTarget');
    if (target != null) return target;
  }
  return (launch?.didNotificationLaunchApp ?? false)
      ? launch?.notificationResponse?.payload
      : null;
}

class StartupGate extends StatefulWidget {
  final Future<String?> Function()? initializer;
  const StartupGate({super.key, this.initializer});
  @override
  State<StartupGate> createState() => _StartupGateState();
}

class _StartupGateState extends State<StartupGate> {
  bool ready = false;
  String? failure;
  @override
  void initState() {
    super.initState();
    start();
  }

  Future<void> start() async {
    setState(() {
      failure = null;
    });
    try {
      final target = await (widget.initializer ?? initializeServices)();
      if (!mounted) return;
      setState(() {
        ready = true;
      });
      if (target != null) {
        WidgetsBinding.instance.addPostFrameCallback((_) => openItem(target));
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        failure = e is PlatformException
            ? '기기 기능을 준비하지 못했습니다 (${e.code}).'
            : e is DatabaseException
            ? '로컬 저장소를 준비하지 못했습니다. 데이터를 지우지 않고 다시 시도해 주세요.'
            : '앱 초기화를 완료하지 못했습니다. 다시 시도해 주세요.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (ready) return const Dashboard();
    return Scaffold(
      appBar: AppBar(title: const Text('캠퍼스레이더')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.radar, size: 64),
              const SizedBox(height: 20),
              const Text(
                '캠퍼스레이더',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              if (failure == null) ...[
                const CircularProgressIndicator(),
                const SizedBox(height: 16),
                const Text('기기 설정을 준비하고 있어요.'),
              ] else ...[
                Text(failure!, textAlign: TextAlign.center),
                const SizedBox(height: 16),
                FilledButton(onPressed: start, child: const Text('다시 시도')),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});
  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> with WidgetsBindingObserver {
  Timer? clockRefresh;
  Map<String, dynamic>? availableUpdate;
  List<String> powerWarnings = [];
  bool checkingPower = false;
  Future<void> checkPower() async {
    if (!Platform.isAndroid || checkingPower) return;
    checkingPower = true;
    try {
      final status = await bridge
          .invokeMapMethod<String, dynamic>('batteryStatus')
          .timeout(const Duration(seconds: 5));
      final warnings = batteryWarnings(status ?? {});
      if (mounted) setState(() => powerWarnings = warnings);
      final fingerprint = jsonEncode({
        'batteryExempt': status?['batteryExempt'],
        'backgroundRestricted': status?['backgroundRestricted'],
      });
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getString('batteryStatusFingerprint') != fingerprint) {
        await systemLog(
          '배터리 설정 상태 변경',
          warnings.isEmpty ? '배터리 최적화 예외 · 백그라운드 제한 없음' : warnings.join('\n'),
        );
        await prefs.setString('batteryStatusFingerprint', fingerprint);
      }
    } catch (_) {
      if (mounted) {
        setState(() => powerWarnings = ['배터리 설정을 확인하지 못했습니다. 다시 확인해 주세요.']);
      }
    } finally {
      checkingPower = false;
    }
  }

  Future<void> openPowerSetting(String method) async {
    try {
      await bridge.invokeMethod(method);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('설정을 열지 못했습니다. 휴대전화 설정에서 직접 확인해 주세요.')),
        );
      }
    }
  }

  int section = 0;
  String taskType = '',
      taskCourse = '',
      taskDeadline = '',
      taskSort = 'due',
      taskQuery = '';
  List<CampusItem> items = [];
  bool loggedIn = false, busy = false, showDone = false, showExcluded = false;
  bool accountChecked = false, reloading = false;
  String? storageError;
  Set<String> excluded = {};
  String? error, last;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    checkPower();
    if (Platform.isIOS) setIosAiActive(true);
    clockRefresh = Timer.periodic(const Duration(minutes: 1), (_) {
      if (mounted) {
        setState(() {});
        checkPower();
      }
    });
    reload().then((_) {
      if (mounted && loggedIn && !busy) sync(source: '앱 시작');
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (Platform.isIOS) setIosAiActive(state == AppLifecycleState.resumed);
    if (state == AppLifecycleState.resumed) checkPower();
    if (state == AppLifecycleState.resumed && loggedIn && !busy) {
      sync(source: '앱 복귀');
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    clockRefresh?.cancel();
    super.dispose();
  }

  Future<void> reload() async {
    if (reloading) return;
    reloading = true;
    Store? store;
    try {
      // Authentication state must not depend on the optional local list query.
      if (Platform.isAndroid) {
        final candidate = await cachedUpdate();
        if (mounted) setState(() => availableUpdate = candidate);
      }
      final id = await credentials.read(key: 'id');
      final pw = await credentials.read(key: 'pw');
      if (mounted) {
        setState(() {
          loggedIn = id != null && pw != null;
          accountChecked = true;
          storageError = null;
        });
      }
      store = await Store.open();
      final list = await store.items();
      final excludedKeys = await store.excluded();
      final stamp = await store.meta('lastSuccess');
      final err = await store.meta('lastError');
      if (mounted) {
        setState(() {
          items = list;
          excluded = excludedKeys;
          last = stamp;
          error = err;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(
          () => storageError = accountChecked
              ? '저장된 목록을 읽지 못했습니다. 로그인 정보를 삭제하지 않았습니다. 잠시 후 다시 확인해 주세요.'
              : '저장된 계정에 접근하지 못했습니다. 로그인 정보 유실로 판단하지 않고 재확인을 기다립니다.',
        );
      }
    } finally {
      await store?.db.close();
      if (mounted) {
        setState(() => reloading = false);
      } else {
        reloading = false;
      }
    }
  }

  Future<void> sync({String source = '수동 확인'}) async {
    setState(() => busy = true);
    try {
      await synchronize(source: source);
    } catch (_) {
    } finally {
      await reload();
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> login() async {
    final id = TextEditingController(), pw = TextEditingController();
    final accepted = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('충남대 포털 연결'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('계정은 이 기기에 암호화해 저장합니다. 주기적으로 로그인해 과제를 확인합니다.'),
            TextField(
              controller: id,
              decoration: const InputDecoration(labelText: '학번 / 아이디'),
              autocorrect: false,
            ),
            TextField(
              controller: pw,
              obscureText: true,
              autocorrect: false,
              enableSuggestions: false,
              decoration: const InputDecoration(labelText: '포털 비밀번호'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('연결'),
          ),
        ],
      ),
    );
    if (accepted == true && id.text.trim().isNotEmpty && pw.text.isNotEmpty) {
      try {
        await credentials.write(key: 'id', value: id.text.trim());
        await credentials.write(key: 'pw', value: pw.text);
        if (await credentials.read(key: 'id') != id.text.trim() ||
            await credentials.read(key: 'pw') != pw.text) {
          throw const FormatException('계정 저장 확인 실패');
        }
        await reload();
        await requestNotificationPermission();
        await registerBackground();
        await sync();
      } catch (_) {
        await reload();
        if (mounted) {
          setState(
            () => storageError =
                '연결 준비를 완료하지 못했습니다. 저장된 정보를 지우지 않았습니다. 다시 확인해 주세요.',
          );
        }
      }
    }
    id.dispose();
    pw.dispose();
  }

  Future<void> logout() async {
    if (busy) return;
    final accepted = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('로그아웃할까요?'),
        content: const Text(
          '저장된 포털 계정과 AI 키, 수집 정보·로그를 삭제하고 캘린더 연결을 해제합니다. 캘린더에 저장한 일정은 남습니다.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('로그아웃'),
          ),
        ],
      ),
    );
    if (accepted != true) return;
    if (Platform.isAndroid) await Workmanager().cancelByTag('campus-ai');
    await Workmanager().cancelByUniqueName(periodicTask);
    if (Platform.isAndroid) {
      await Workmanager().cancelByUniqueName('campus-radar-probe');
    }
    if (Platform.isAndroid || Platform.isIOS) {
      await bridge.invokeMethod('calendarUnlink');
    }
    if (Platform.isAndroid) {
      await bridge.invokeMethod('lockConfigure', {
        'enabled': false,
        'mode': 'compact',
        'position': 'right',
        'details': false,
      });
    }
    await credentials.deleteAll();
    await notifications.cancelAll();
    await bridge.invokeMethod('clearWebSession');
    final store = await Store.open();
    await store.db.delete('items');
    await store.db.delete('events');
    await store.db.delete('meta');
    await store.db.delete('notices');
    await store.db.delete('logs');
    await store.db.close();
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('scheduled');
    await prefs.remove('courseAliases');
    courseAliases = {};
    await prefs.setBool('aiSummaryEnabled', false);
    await prefs.setBool('aiDailyEnabled', false);
    await prefs.remove('aiSummaryText');
    if (Platform.isAndroid || Platform.isIOS) {
      await bridge.invokeMethod('setDailySettings', {
        'enabled': false,
        'hour': 18,
        'minute': 0,
      });
      if (Platform.isAndroid) await bridge.invokeMethod('refreshWidget');
    }
    await reload();
  }

  Future<void> testNotification() async {
    await requestNotificationPermission();
    await notifications.show(
      notificationId('test'),
      '캠퍼스레이더 알림 테스트',
      items.isEmpty
          ? '알림이 정상적으로 표시됩니다.'
          : '${items.first.course} · ${items.first.title}',
      noticeStyle,
      payload: items.firstOrNull?.key,
    );
    await logNotification('테스트 알림 발송 요청', '기기에 알림 표시를 요청했습니다.');
  }

  Widget itemTile(CampusItem item) => Card(
    color: deadlineBackground(item),
    child: ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      leading: Icon(
        item.type == 'LR'
            ? Icons.assignment_outlined
            : Icons.play_circle_outline,
        color: deadlineColor(item),
      ),
      title: Text(
        item.title,
        style: const TextStyle(fontWeight: FontWeight.w600),
      ),
      subtitle: Padding(
        padding: const EdgeInsets.only(top: 6),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(courseLabel(item.course)),
            const SizedBox(height: 4),
            Text(item.due == null ? '마감 미확인' : formatDate(item.due!)),
            Text(
              '${remainingText(item)} · ${excluded.contains(item.key) ? '목록에서 제외됨' : statusText(item)}',
              style: TextStyle(
                color: deadlineColor(item),
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
      trailing: const Icon(Icons.chevron_right),
      onTap: () async {
        await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) =>
                DetailPage(item: item, excluded: excluded.contains(item.key)),
          ),
        );
        await reload();
      },
    ),
  );

  Widget metric(String number, String label, IconData icon) => Expanded(
    child: Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 8),
        child: Column(
          children: [
            Icon(icon, size: 22, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 8),
            Text(
              number,
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),
            Text(label, style: const TextStyle(fontSize: 12)),
          ],
        ),
      ),
    ),
  );

  Widget taskDropdown(
    String label,
    String value,
    Map<String, String> values,
    ValueChanged<String> change,
  ) => DropdownButtonFormField<String>(
    key: ValueKey('$label:$value'),
    isExpanded: true,
    initialValue: values.containsKey(value) ? value : '',
    decoration: InputDecoration(
      labelText: label,
      border: const OutlineInputBorder(),
      isDense: true,
    ),
    items: values.entries
        .map(
          (e) => DropdownMenuItem(
            value: e.key,
            child: Text(e.value, overflow: TextOverflow.ellipsis),
          ),
        )
        .toList(),
    onChanged: (v) => setState(() => change(v ?? '')),
  );

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now().toUtc();
    final available = items
        .where((i) => i.availableAt(now) && !excluded.contains(i.key))
        .toList();
    final pending = available.where((i) => i.status == 'pending').toList()
      ..sort(
        (a, b) => (a.due ?? DateTime.utc(2100)).compareTo(
          b.due ?? DateTime.utc(2100),
        ),
      );
    final urgent = pending
        .where((i) => deadlineState(i.due, now: now) == DeadlineState.withinDay)
        .toList();
    final today = pending
        .where(
          (i) =>
              i.due != null &&
              i.due!.isAfter(now) &&
              DateUtils.isSameDay(
                now.add(const Duration(hours: 9)),
                i.due!.toUtc().add(const Duration(hours: 9)),
              ),
        )
        .length;
    final visible = items
        .where(
          (i) =>
              i.availableAt(now) &&
              (excluded.contains(i.key) ? showExcluded : showDone || !i.done) &&
              (taskType.isEmpty || i.type == taskType) &&
              (taskCourse.isEmpty || i.course == taskCourse) &&
              (taskDeadline.isEmpty ||
                  deadlineState(i.due, now: now).name == taskDeadline) &&
              '${i.title} ${i.course} ${courseLabel(i.course)}'
                  .toLowerCase()
                  .contains(taskQuery.toLowerCase()),
        )
        .toList();
    visible.sort(
      (a, b) => taskSort == 'course'
          ? a.course.compareTo(b.course)
          : taskSort == 'title'
          ? a.title.compareTo(b.title)
          : (a.due ?? DateTime.utc(2100)).compareTo(
              b.due ?? DateTime.utc(2100),
            ),
    );
    final courses = items.map((i) => i.course).toSet().toList()..sort();
    final home = RefreshIndicator(
      onRefresh: loggedIn ? sync : reload,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
        children: [
          if (busy) const LinearProgressIndicator(),
          if (storageError != null)
            Card(
              color: Theme.of(context).colorScheme.errorContainer,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text(storageError!),
                    TextButton(
                      onPressed: reloading ? null : reload,
                      child: const Text('저장 정보 다시 확인'),
                    ),
                  ],
                ),
              ),
            ),
          if (!accountChecked)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('저장된 계정 확인 중…'),
            ),
          if (accountChecked && !loggedIn)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.radar, size: 44),
                    const SizedBox(height: 16),
                    const Text(
                      '놓치기 전에, 한눈에',
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text('포털을 연결하면 과제와 콘텐츠를 확인할 수 있어요.'),
                    const SizedBox(height: 16),
                    FilledButton(
                      onPressed: busy ? null : login,
                      child: const Text('포털 연결'),
                    ),
                  ],
                ),
              ),
            ),
          if (loggedIn) ...[
            if (section == 0) ...[
              const Text(
                '오늘의 캠퍼스',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text('마지막으로 수집한 내용을 기준으로 보여드려요.'),
              const SizedBox(height: 16),
              Row(
                children: [
                  metric('$today', '오늘 마감', Icons.today_outlined),
                  metric('${urgent.length}', '24시간 이내', Icons.timelapse),
                  metric('${pending.length}', '전체 미완료', Icons.checklist),
                ],
              ),
            ],
            const SizedBox(height: 12),
            Row(
              children: [
                const Icon(Icons.verified_user_outlined, size: 16),
                const SizedBox(width: 6),
                const Text('포털 연결됨'),
                const Spacer(),
                TextButton.icon(
                  onPressed: busy ? null : () => sync(),
                  icon: const Icon(Icons.sync, size: 18),
                  label: Text(busy ? '확인 중…' : '지금 확인'),
                ),
              ],
            ),
            Text(
              last == null
                  ? '아직 수집 기록이 없습니다.'
                  : '마지막 확인 ${formatDate(DateTime.parse(last!))}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            if (error?.isNotEmpty == true)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text(
                  error!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error),
                ),
              ),
            if (availableUpdate != null)
              Card(
                color: Theme.of(context).colorScheme.secondaryContainer,
                child: ListTile(
                  leading: const Icon(Icons.system_update_outlined),
                  title: const Text('업데이트 가능'),
                  subtitle: Text(
                    '${availableUpdate!['versionName']} · ${channelLabel(availableUpdate!['channel'])}',
                  ),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const UpdatePage()),
                    );
                    await reload();
                  },
                ),
              ),
            if (powerWarnings.isNotEmpty)
              Card(
                color: Theme.of(context).colorScheme.errorContainer,
                child: ListTile(
                  leading: const Icon(Icons.battery_alert_outlined),
                  title: const Text('앱 배터리 설정 확인'),
                  subtitle: Text(powerWarnings.join('\n')),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const BackgroundStatusPage(),
                    ),
                  ),
                  trailing: IconButton(
                    onPressed: () => openPowerSetting('openAppSettings'),
                    icon: const Icon(Icons.settings_outlined),
                    tooltip: '앱 배터리 설정',
                  ),
                ),
              ),
            if (section == 0) ...[
              const SizedBox(height: 16),
              const AiDailyCard(),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.notifications_outlined),
                title: const Text('데일리 요약과 알림 시각'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const DailySummaryPage()),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Text(
                    '먼저 확인할 일',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const Spacer(),
                  TextButton(
                    onPressed: () => setState(() => section = 1),
                    child: const Text('전체 보기'),
                  ),
                ],
              ),
              if (pending.isEmpty && !busy)
                const Padding(
                  padding: EdgeInsets.all(24),
                  child: Text('현재 수집된 목록에 미완료 항목이 없어요.'),
                ),
              ...pending.take(5).map(itemTile),
            ] else ...[
              const SizedBox(height: 20),
              TextField(
                decoration: const InputDecoration(
                  hintText: '과제·콘텐츠·과목 검색',
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(),
                ),
                onChanged: (v) => setState(() => taskQuery = v),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: taskDropdown('유형', taskType, {
                      '': '전체',
                      'LR': '과제',
                      'LV': '콘텐츠',
                    }, (v) => taskType = v),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: taskDropdown('마감 상태', taskDeadline, {
                      '': '전체',
                      'overdue': '기한 지남',
                      'withinDay': '24시간 이내',
                      'remaining': '아직 남음',
                      'unknown': '기한 미확인',
                    }, (v) => taskDeadline = v),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: taskDropdown('과목', taskCourse, {
                      '': '모든 과목',
                      for (final c in courses) c: courseLabel(c),
                    }, (v) => taskCourse = v),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: taskDropdown('정렬', taskSort, {
                      'due': '마감 빠른 순',
                      'course': '과목명 순',
                      'title': '제목 순',
                    }, (v) => taskSort = v),
                  ),
                ],
              ),
              Wrap(
                spacing: 8,
                children: [
                  FilterChip(
                    label: const Text('완료 포함'),
                    selected: showDone,
                    onSelected: (v) => setState(() => showDone = v),
                  ),
                  FilterChip(
                    label: const Text('제외 항목 포함'),
                    selected: showExcluded,
                    onSelected: (v) => setState(() => showExcluded = v),
                  ),
                ],
              ),
              Text(
                '${visible.length}개 · 공개·시작된 항목만 표시',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 12),
              if (visible.isEmpty && !busy)
                const Padding(
                  padding: EdgeInsets.all(24),
                  child: Text('조건에 맞는 과제·콘텐츠가 없습니다.'),
                ),
              ...visible.map(itemTile),
            ],
          ],
        ],
      ),
    );
    return Scaffold(
      appBar: section <= 1
          ? AppBar(
              title: Text(section == 0 ? '캠퍼스레이더' : '할 일'),
              actions: [
                IconButton(
                  onPressed: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const CoursesPage()),
                    );
                    if (mounted) setState(() {});
                  },
                  icon: const Icon(Icons.school_outlined),
                  tooltip: '내 과목',
                ),
                IconButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const AiChatPage()),
                  ),
                  icon: const Icon(Icons.chat_bubble_outline),
                  tooltip: 'AI 채팅',
                ),
                IconButton(
                  onPressed: () => setState(() => section = 4),
                  icon: const Icon(Icons.settings_outlined),
                  tooltip: '설정',
                ),
              ],
            )
          : null,
      body: section == 2
          ? const CoursesPage()
          : section == 3
          ? const AiInboxPage()
          : section == 4
          ? SettingsHub(
              connected: loggedIn,
              connect: login,
              logout: busy ? () {} : logout,
              test: testNotification,
            )
          : home,
      bottomNavigationBar: NavigationBar(
        selectedIndex: section,
        onDestinationSelected: (v) => setState(() => section = v),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.today_outlined),
            selectedIcon: Icon(Icons.today),
            label: '오늘',
          ),
          NavigationDestination(
            icon: Icon(Icons.checklist_outlined),
            selectedIcon: Icon(Icons.checklist),
            label: '할 일',
          ),
          NavigationDestination(
            icon: Icon(Icons.school_outlined),
            selectedIcon: Icon(Icons.school),
            label: '과목',
          ),
          NavigationDestination(
            icon: Icon(Icons.auto_awesome_outlined),
            selectedIcon: Icon(Icons.auto_awesome),
            label: 'AI 일정함',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings),
            label: '설정',
          ),
        ],
      ),
    );
  }
}

String formatDate(DateTime date) {
  final d = date.toUtc().add(const Duration(hours: 9));
  return '${d.month}/${d.day} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')} (한국 시간)';
}

String statusText(CampusItem i) => i.status == 'unknown'
    ? '상태 확인 불가'
    : i.done
    ? (i.type == 'LR' ? '제출 완료' : '완료')
    : (i.type == 'LR' ? '미제출' : '미완료');

String deadlineLabel(CampusItem item) {
  if (item.done) return '완료';
  return switch (deadlineState(item.due)) {
    DeadlineState.overdue => '기한 지남',
    DeadlineState.withinDay => '1일 이내 남음',
    DeadlineState.remaining => '아직 남음',
    DeadlineState.unknown => '기한 미확인',
  };
}

Color deadlineColor(CampusItem item) {
  if (item.done) return Colors.green.shade800;
  return switch (deadlineState(item.due)) {
    DeadlineState.overdue => Colors.red.shade800,
    DeadlineState.withinDay => Colors.orange.shade900,
    DeadlineState.remaining => Colors.blue.shade800,
    DeadlineState.unknown => Colors.grey.shade700,
  };
}

Color deadlineBackground(CampusItem item) {
  if (item.done) return Colors.green.shade50;
  return switch (deadlineState(item.due)) {
    DeadlineState.overdue => Colors.red.shade50,
    DeadlineState.withinDay => Colors.orange.shade50,
    DeadlineState.remaining => Colors.blue.shade50,
    DeadlineState.unknown => Colors.grey.shade100,
  };
}

class DetailPage extends StatefulWidget {
  final CampusItem item;
  final bool excluded;
  const DetailPage({super.key, required this.item, this.excluded = false});
  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  bool busy = false;
  late bool excluded;
  @override
  void initState() {
    super.initState();
    excluded = widget.excluded;
  }

  Future<void> toggleExcluded() async {
    if (!excluded) {
      final accepted = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('목록에서 제외할까요?'),
          content: const Text(
            '이 기기의 목록에서 숨기고 해당 항목의 알림을 취소합니다. 제외 항목 보기에서 다시 복구할 수 있습니다.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('취소'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('제외'),
            ),
          ],
        ),
      );
      if (accepted != true) return;
    }
    setState(() => busy = true);
    try {
      await excludeItem(widget.item, !excluded);
      if (mounted) {
        setState(() => excluded = !excluded);
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('변경하지 못했습니다. 다시 시도해 주세요.')),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> go() async {
    setState(() => busy = true);
    final client = CampusClient();
    try {
      final id = await credentials.read(key: 'id'),
          pw = await credentials.read(key: 'pw');
      if (id == null || pw == null) throw CampusException('포털을 다시 연결해 주세요.');
      await client.login(id, pw);
      final navigation = await client.navigation(widget.item);
      await bridge.invokeMethod('openCampus', navigation);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              e is CampusException ? e.message : '사이버캠퍼스를 열지 못했습니다.',
            ),
          ),
        );
      }
    } finally {
      client.close();
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final i = widget.item;
    final diff = i.due?.difference(DateTime.now().toUtc());
    return Scaffold(
      appBar: AppBar(title: Text(i.type == 'LR' ? '과제 상세' : '콘텐츠 상세')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Text(courseLabel(i.course)),
          const SizedBox(height: 8),
          Text(
            i.title,
            style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: deadlineBackground(i),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              deadlineLabel(i),
              style: TextStyle(
                color: deadlineColor(i),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Text(statusText(i)),
          if (Platform.isAndroid || Platform.isIOS)
            TextButton.icon(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => CalendarDraftPage(
                    itemKey: i.key,
                    title: i.title,
                    deadlineCourse: i.course,
                    description:
                        '마감 일정 · 한국 시간\n${i.body}\nhttps://dcs-learning.cnu.ac.kr/home',
                    start: i.due,
                    deadline: true,
                  ),
                ),
              ),
              icon: const Icon(Icons.event_available),
              label: const Text('캘린더에 전송'),
            ),
          Text(remainingText(i)),
          TextButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ChangesPage(itemKey: i.key)),
            ),
            icon: const Icon(Icons.history),
            label: const Text('이 항목의 변경 이력'),
          ),
          if (excluded) const Text('목록에서 제외됨 · 알림 꺼짐'),
          Text(i.due == null ? '마감 미확인' : '마감 ${formatDate(i.due!)}'),
          if (diff != null)
            Text(
              diff.isNegative
                  ? '마감이 지났습니다.'
                  : '${diff.inDays}일 ${diff.inHours % 24}시간 남음',
            ),
          const SizedBox(height: 20),
          Text(i.body.isEmpty ? '상세 내용은 사이버캠퍼스에서 확인하세요.' : i.body),
          const SizedBox(height: 28),
          FilledButton.icon(
            onPressed: busy ? null : go,
            icon: const Icon(Icons.open_in_new),
            label: Text(busy ? '연결 중…' : '사이버캠퍼스 바로가기'),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: busy ? null : toggleExcluded,
            icon: Icon(excluded ? Icons.undo : Icons.remove_circle_outline),
            label: Text(excluded ? '목록에 복구' : '목록에서 제외'),
          ),
          const Text(
            '제출·완료 상태는 마지막 수집 기준입니다. 콘텐츠는 해당 강의의 학습 항목으로 연결합니다.',
            style: TextStyle(fontSize: 12),
          ),
        ],
      ),
    );
  }
}

class HistoryPage extends StatefulWidget {
  final bool notificationsOnly;
  const HistoryPage({super.key, required this.notificationsOnly});
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  List<Map<String, Object?>> rows = [];
  bool loading = true;
  String? error;
  String query = '', category = 'all';
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final store = await Store.open();
      try {
        final data = await store.logs(
          widget.notificationsOnly ? 'notification' : 'all',
        );
        if (mounted) {
          setState(() {
            rows = data;
            error = null;
          });
        }
      } finally {
        await store.db.close();
      }
    } catch (_) {
      if (mounted) setState(() => error = '기록을 읽지 못했습니다. 다시 시도해 주세요.');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final visible = rows
        .where(
          (r) =>
              (category == 'all' || r['kind'] == category) &&
              '${r['title']} ${r['detail']}'.toLowerCase().contains(
                query.toLowerCase(),
              ),
        )
        .toList();
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.notificationsOnly ? '알림 로그' : '활동 로그'),
        actions: [
          if (!widget.notificationsOnly && Platform.isAndroid)
            IconButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const BackgroundStatusPage()),
              ),
              icon: const Icon(Icons.troubleshoot),
              tooltip: '백그라운드 상태',
            ),
          IconButton(
            onPressed: load,
            icon: const Icon(Icons.refresh),
            tooltip: '기록 새로고침',
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.notificationsOnly
                      ? '예약·취소·발송 요청·클릭 기록입니다. 발송 요청은 실제 화면 표시를 보장하지 않습니다.'
                      : '수집한 과제·콘텐츠·공지와 수집 성공·실패 기록입니다.',
                ),
                const Text(
                  '기기에 최근 2,000건을 보관합니다. 수집 로그에는 업데이트와 배터리 설정 변경도 기록됩니다.',
                  style: TextStyle(fontSize: 12),
                ),
                if (!widget.notificationsOnly)
                  Wrap(
                    spacing: 6,
                    children: [
                      for (final c in {
                        'all': '전체',
                        'sync': '수집',
                        'notification': '알림',
                        'ai': 'AI',
                        'calendar': '캘린더',
                        'system': '앱·업데이트',
                        'received': '수신',
                      }.entries)
                        ChoiceChip(
                          label: Text(c.value),
                          selected: category == c.key,
                          onSelected: (_) => setState(() => category = c.key),
                        ),
                    ],
                  ),
                const SizedBox(height: 8),
                TextField(
                  decoration: const InputDecoration(
                    labelText: '기록 검색',
                    prefixIcon: Icon(Icons.search),
                  ),
                  onChanged: (v) => setState(() => query = v),
                ),
              ],
            ),
          ),
          if (loading) const LinearProgressIndicator(),
          if (error != null)
            Padding(padding: const EdgeInsets.all(16), child: Text(error!)),
          Expanded(
            child: RefreshIndicator(
              onRefresh: load,
              child: ListView.builder(
                physics: const AlwaysScrollableScrollPhysics(),
                itemCount: visible.isEmpty ? 1 : visible.length,
                itemBuilder: (context, index) {
                  if (visible.isEmpty) {
                    return const Padding(
                      padding: EdgeInsets.all(24),
                      child: Text('표시할 기록이 없습니다.'),
                    );
                  }
                  final row = visible[index];
                  return ListTile(
                    isThreeLine: true,
                    leading: Icon(
                      row['kind'] == 'notification'
                          ? Icons.notifications_outlined
                          : row['kind'] == 'sync'
                          ? Icons.sync
                          : Icons.download_done,
                    ),
                    title: Text('${row['title']}'),
                    subtitle: Text(
                      '${formatDate(DateTime.parse(row['at'] as String))}\n${row['detail']}',
                    ),
                    onTap: () => showDialog<void>(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: Text('${row['title']}'),
                        content: SingleChildScrollView(
                          child: SelectableText(
                            '${formatDate(DateTime.parse(row['at'] as String))}\n\n${row['detail']}',
                          ),
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text('닫기'),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class BackgroundStatusPage extends StatefulWidget {
  const BackgroundStatusPage({super.key});
  @override
  State<BackgroundStatusPage> createState() => _BackgroundStatusPageState();
}

class _BackgroundStatusPageState extends State<BackgroundStatusPage> {
  Map<dynamic, dynamic>? data;
  String? started, success, error, successKind;
  bool scheduling = false;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final status = await bridge.invokeMapMethod<dynamic, dynamic>(
        'backgroundStatus',
      );
      final store = await Store.open();
      try {
        final lastStart = await store.meta('workerStarted');
        final lastSuccess = await store.meta('workerSuccess');
        final kind = await store.meta('workerSource');
        if (mounted) {
          setState(() {
            data = status;
            started = lastStart;
            success = lastSuccess;
            successKind = kind;
            error = null;
          });
        }
      } finally {
        await store.db.close();
      }
    } catch (_) {
      if (mounted) setState(() => error = '백그라운드 상태를 읽지 못했습니다.');
    }
  }

  String stamp(String? time) =>
      time == null ? '이 업데이트 이후 기록 없음' : formatDate(DateTime.parse(time));
  String stateName(String state) =>
      const {
        'ENQUEUED': '실행 대기',
        'RUNNING': '실행 중',
        'SUCCEEDED': '완료',
        'FAILED': '실패',
        'CANCELLED': '취소',
        'BLOCKED': '선행 작업 대기',
        'SCHEDULED': '예약',
        'STARTED': '실행 시작',
        'COMPLETED': '완료',
        'RESCHEDULED': '재시도 예약',
        'RETRYING': '재시도 시작',
      }[state] ??
      state;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('백그라운드 상태'),
      actions: [
        IconButton(
          onPressed: load,
          icon: const Icon(Icons.refresh),
          tooltip: '상태 새로고침',
        ),
      ],
    ),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text(
          '앱을 열어 수집한 기록과 자동 수집 기록을 구분합니다. 작업이 예약되어 있어도 운영체제가 실행을 늦출 수 있습니다.',
        ),
        const SizedBox(height: 16),
        Text('마지막 백그라운드 진입: ${stamp(started)}'),
        Text(
          '마지막 백그라운드 수집 성공${successKind == null ? '' : ' ($successKind)'}: ${stamp(success)}',
        ),
        const SizedBox(height: 12),
        if (Platform.isAndroid)
          FilledButton.tonal(
            onPressed: scheduling
                ? null
                : () async {
                    setState(() => scheduling = true);
                    try {
                      await scheduleBackgroundTrial();
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text(
                              '시험을 예약했습니다. 홈 화면으로 나가 기다린 뒤 수집 로그를 확인하세요.',
                            ),
                          ),
                        );
                      }
                    } catch (_) {
                      if (mounted) setState(() => error = '시험 작업을 예약하지 못했습니다.');
                    } finally {
                      if (mounted) setState(() => scheduling = false);
                    }
                  },
            child: const Text('백그라운드 수집 시험 예약'),
          ),
        const Text(
          '30초 이후 실행 가능한 시험입니다. 실행 시각은 운영체제가 결정하며 정기 자동 수집과 별도입니다.',
          style: TextStyle(fontSize: 12),
        ),
        if (error != null) Text(error!),
        if (data == null && error == null) const LinearProgressIndicator(),
        if (Platform.isIOS && data != null) ...[
          const Divider(),
          Text(
            '백그라운드 앱 새로 고침: ${data!['backgroundRefresh'] == true ? '허용됨' : '제한됨 또는 사용 불가'}',
          ),
          const Text(
            'iOS가 자동 수집 시각을 결정합니다. 설정 → 일반 → 백그라운드 앱 새로 고침에서 확인하세요. AI 순차 분석은 앱을 열어 둔 동안 이어집니다.',
          ),
          TextButton(
            onPressed: () => bridge.invokeMethod('openAppSettings'),
            child: const Text('앱 설정 열기'),
          ),
        ],
        if (Platform.isAndroid && data != null) ...[
          const Divider(),

          Text(
            '앱 배터리 최적화 예외: ${data!['batteryExempt'] == null
                ? '확인 불가'
                : data!['batteryExempt'] == true
                ? '허용됨'
                : '아님'}',
          ),
          Text(
            '앱 백그라운드 제한: ${data!['backgroundRestricted'] == true ? '제한됨' : '제한 표시 없음'}',
          ),
          Text(
            '데이터 절약 모드의 앱 제한: ${data!['dataSaver'] == 3 ? '제한됨' : '제한 표시 없음'}',
          ),
          OutlinedButton(
            onPressed: () async {
              await bridge.invokeMethod('openAppSettings');
            },
            child: const Text('앱 설정 열기'),
          ),
          const Divider(),
          const Text(
            '운영체제의 자동 수집 작업',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          if ((data!['jobs'] as List? ?? []).isEmpty)
            const Text('예약된 작업이 없습니다. 포털 연결 상태를 확인하세요.'),
          for (final job in data!['jobs'] as List? ?? [])
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(stateName(job['state'] as String)),
                    Text('현재 재시도 횟수: ${job['attempts']}'),
                    if (job['nextAt'] is int &&
                        job['nextAt'] > 0 &&
                        job['nextAt'] < 4102444800000)
                      Text(
                        '가장 빠른 실행 가능 시각: ${formatDate(DateTime.fromMillisecondsSinceEpoch(job['nextAt']))}',
                      ),
                    const Text(
                      '이 시각에 반드시 실행된다는 뜻은 아닙니다.',
                      style: TextStyle(fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
          const Divider(),
          const Text(
            '운영체제 작업 실행 기록',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const Text(
            '수집 코드에 진입하기 전의 실패도 확인하기 위한 최근 100건 기록입니다.',
            style: TextStyle(fontSize: 12),
          ),
          for (final event in (data!['events'] as List? ?? []).reversed)
            ListTile(
              title: Text(stateName(event['state'] as String)),
              subtitle: Text(
                '${formatDate(DateTime.fromMillisecondsSinceEpoch(event['at']))}\n처리 시간 ${event['durationMs']} ms',
              ),
            ),
        ],
      ],
    ),
  );
}

class NoticesPage extends StatefulWidget {
  const NoticesPage({super.key});
  @override
  State<NoticesPage> createState() => _NoticesPageState();
}

class _NoticesPageState extends State<NoticesPage> {
  List<CampusNotice> notices = [];
  Map<String, String> aiStates = {};
  String query = '', course = '', error = '';
  bool loading = true;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final store = await Store.open();
    try {
      final data = await store.notices();
      final failure = await store.meta('noticeError');
      final statuses = <String, String>{};
      for (final n in data) {
        final q =
            jsonDecode(await store.meta('aiQueue:${n.id}') ?? '{}') as Map;
        statuses[n.id] =
            {
              'pending': 'AI 대기',
              'running': 'AI 분석 중',
              'done': 'AI 후보 있음',
              'empty': '일정 없음',
              'failed': 'AI 실패',
            }[q['status']] ??
            '미분석';
      }
      if (mounted) {
        setState(() {
          notices = data;
          aiStates = statuses;
          error = failure ?? '';
          loading = false;
          if (!data.any((n) => n.course == course)) course = '';
        });
      }
    } finally {
      await store.db.close();
    }
  }

  @override
  Widget build(BuildContext context) {
    final courses = notices.map((n) => n.course).toSet().toList()..sort();
    final visible = notices
        .where(
          (n) =>
              (course.isEmpty || n.course == course) &&
              '${courseLabel(n.course)} ${n.title}'.toLowerCase().contains(
                query.toLowerCase(),
              ),
        )
        .toList();
    return Scaffold(
      appBar: AppBar(
        title: const Text('공지 모아보기'),
        actions: [
          IconButton(
            onPressed: load,
            icon: const Icon(Icons.refresh),
            tooltip: '저장된 목록 새로고침',
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                const Text('최근 수집한 현재 학기 공지입니다. 새 공지는 메인 화면의 지금 확인으로 수집합니다.'),
                TextField(
                  decoration: const InputDecoration(
                    labelText: '공지·과목 검색',
                    prefixIcon: Icon(Icons.search),
                  ),
                  onChanged: (v) => setState(() => query = v),
                ),
                DropdownButton<String>(
                  isExpanded: true,
                  value: course,
                  items: [
                    const DropdownMenuItem(value: '', child: Text('모든 과목')),
                    ...courses.map(
                      (c) => DropdownMenuItem(
                        value: c,
                        child: Text(
                          courseLabel(c),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ),
                  ],
                  onChanged: (v) => setState(() => course = v ?? ''),
                ),
                if (error.isNotEmpty)
                  Text(
                    error,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.error,
                    ),
                  ),
              ],
            ),
          ),
          if (loading) const LinearProgressIndicator(),
          Expanded(
            child: RefreshIndicator(
              onRefresh: load,
              child: ListView.builder(
                physics: const AlwaysScrollableScrollPhysics(),
                itemCount: visible.isEmpty ? 1 : visible.length,
                itemBuilder: (context, index) {
                  if (visible.isEmpty) {
                    return const Padding(
                      padding: EdgeInsets.all(24),
                      child: Text('표시할 공지가 없습니다. 메인 화면에서 지금 확인을 눌러 주세요.'),
                    );
                  }
                  final n = visible[index];
                  return Card(
                    margin: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 4,
                    ),
                    child: ListTile(
                      leading: Icon(
                        n.read
                            ? Icons.drafts_outlined
                            : Icons.mark_email_unread_outlined,
                      ),
                      title: Text(n.title),
                      subtitle: Text(
                        '${courseLabel(n.course)}\n${n.published == null ? '게시 시각 미확인' : formatDate(n.published!)} · ${n.read ? '학교 기준 확인함' : '학교 기준 미확인'}',
                      ),
                      isThreeLine: true,
                      trailing: Text(
                        aiStates[n.id] ?? '미분석',
                        style: Theme.of(context).textTheme.labelSmall,
                      ),
                      onTap: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => NoticeDetailPage(notice: n),
                          ),
                        );
                        await load();
                      },
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class NoticeDetailPage extends StatefulWidget {
  final CampusNotice notice;
  const NoticeDetailPage({super.key, required this.notice});
  @override
  State<NoticeDetailPage> createState() => _NoticeDetailPageState();
}

class _NoticeDetailPageState extends State<NoticeDetailPage> {
  late CampusNotice notice = widget.notice;
  bool loading = true, opening = false;
  String? error;
  @override
  void initState() {
    super.initState();
    loadBody();
  }

  Future<CampusClient> client() async {
    final id = await credentials.read(key: 'id'),
        pw = await credentials.read(key: 'pw');
    if (id == null || pw == null) throw CampusException('포털을 먼저 연결해 주세요.');
    final c = CampusClient();
    try {
      await c.login(id, pw);
      return c;
    } catch (_) {
      c.close();
      rethrow;
    }
  }

  Future<void> loadBody({bool force = false}) async {
    if (notice.bodyFetched && !force) {
      setState(() => loading = false);
      return;
    }
    setState(() {
      loading = true;
      error = null;
    });
    CampusClient? c;
    try {
      c = await client();
      final data = await c.fetchNoticeBody(notice);
      final store = await Store.open();
      try {
        await store.saveNotice(data);
        await store.log(
          'received',
          '공지 본문 수집',
          '${data.course} · ${data.title}',
        );
      } finally {
        await store.db.close();
      }
      if (mounted) setState(() => notice = data);
    } catch (e) {
      if (mounted) {
        setState(
          () => error = e is CampusException
              ? e.message
              : '공지 본문을 가져오지 못했습니다. 다시 시도해 주세요.',
        );
      }
    } finally {
      c?.close();
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> openCampus() async {
    setState(() => opening = true);
    CampusClient? c;
    try {
      c = await client();
      await bridge.invokeMethod('openCampus', await c.navigation(notice.item));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              e is CampusException ? e.message : '사이버캠퍼스를 열지 못했습니다.',
            ),
          ),
        );
      }
    } finally {
      c?.close();
      if (mounted) setState(() => opening = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('공지 상세')),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Text(courseLabel(notice.course)),
        const SizedBox(height: 8),
        Text(
          notice.title,
          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        if (notice.published != null) Text(formatDate(notice.published!)),
        const SizedBox(height: 20),
        if (loading) const LinearProgressIndicator(),
        if (error != null) ...[
          Text(error!),
          TextButton(onPressed: loadBody, child: const Text('본문 다시 불러오기')),
        ],
        SelectableText(
          notice.body.isEmpty
              ? (loading ? '본문을 불러오는 중입니다.' : '본문이 없거나 아직 가져오지 못했습니다.')
              : notice.body,
        ),
        const SizedBox(height: 24),
        if (Platform.isAndroid)
          FilledButton.tonalIcon(
            onPressed: loading || opening
                ? null
                : () async {
                    await loadBody(force: true);
                    if (!context.mounted ||
                        error != null ||
                        !notice.bodyFetched) {
                      return;
                    }
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => NoticeAnalysisPage(notice: notice),
                      ),
                    );
                  },
            icon: const Icon(Icons.auto_awesome),
            label: const Text('AI 일정 분석'),
          ),
        FilledButton.icon(
          onPressed: opening ? null : openCampus,
          icon: const Icon(Icons.open_in_new),
          label: Text(opening ? '연결 중…' : '사이버캠퍼스 바로가기'),
        ),
        const SizedBox(height: 12),
        const Text(
          '첨부파일·이미지·댓글은 사이버캠퍼스에서 확인하세요.',
          style: TextStyle(fontSize: 12),
        ),
      ],
    ),
  );
}

class UpdatePage extends StatefulWidget {
  const UpdatePage({super.key});
  @override
  State<UpdatePage> createState() => _UpdatePageState();
}

class _UpdatePageState extends State<UpdatePage> {
  final url = TextEditingController();
  bool busy = false;
  String message = '';
  Map<String, dynamic>? update;
  String channel = appReleaseChannel == 'development'
      ? 'development'
      : 'stable';
  @override
  void initState() {
    super.initState();
    if (Platform.isAndroid) {
      unawaited(loadChannel());
    }
    SharedPreferences.getInstance().then((p) {
      if (mounted) {
        setState(
          () => url.text =
              p.getString(Platform.isIOS ? 'iosUpdateUrl' : 'updateUrl') ??
              (Platform.isIOS
                  ? 'https://github.com/lemoncube7/campus-radar/releases/download/ios-preview/ios-latest.json'
                  : 'https://github.com/lemoncube7/campus-radar/releases/latest/download/latest.json'),
        );
      }
    });
  }

  Future<void> loadChannel() async {
    final c = await updateChannel();
    final candidate = await cachedUpdate();
    if (mounted) {
      setState(() {
        channel = c;
        update = candidate;
      });
    }
  }

  Future<void> checkAndroid() async {
    setState(() {
      busy = true;
      message = '업데이트 확인 중…';
    });
    Store? s;
    try {
      s = await Store.open();
      await checkForUpdates(s);
      final candidate = await cachedUpdate();
      final p = await SharedPreferences.getInstance();
      await p.reload();
      final raw = p.getString('updateInfo:$channel');
      final latest = raw == null ? null : jsonDecode(raw) as Map;
      if (mounted) {
        setState(() {
          update = candidate;
          message = p.getString('updateCheckError')?.isNotEmpty == true
              ? p.getString('updateCheckError')!
              : candidate != null
              ? '새 버전 ${candidate['versionName']} · ${channelLabel(candidate['channel'])}\n${candidate['notes'] ?? ''}'
              : latest == null
              ? '이 채널에 게시된 버전이 없습니다.'
              : '${channelLabel(channel)} 최신 게시: ${latest['versionName']}\n현재 설치 버전보다 새로운 업데이트가 없습니다.';
        });
      }
    } catch (_) {
      if (mounted) setState(() => message = '업데이트 정보를 가져오지 못했습니다.');
    } finally {
      await s?.db.close();
      if (mounted) setState(() => busy = false);
    }
  }

  Future<List<int>> download(
    Uri uri, {
    int limit = 100000000,
    int redirects = 0,
  }) async {
    if (redirects > 8) throw const FormatException('다운로드 주소가 반복됩니다.');
    if (uri.scheme != 'https') {
      throw const FormatException('HTTPS 주소를 사용해 주세요.');
    }
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 20);
    try {
      final req = await client.getUrl(uri);
      req.followRedirects = false;
      final response = await req.close().timeout(const Duration(seconds: 30));
      if (response.isRedirect) {
        final location = response.headers.value('location');
        if (location == null) throw const FormatException('다운로드 이동 실패');
        return download(
          uri.resolve(location),
          limit: limit,
          redirects: redirects + 1,
        );
      }
      if (response.statusCode != 200) throw const FormatException('다운로드 응답 오류');
      final bytes = <int>[];
      await for (final chunk in response.timeout(const Duration(seconds: 60))) {
        bytes.addAll(chunk);
        if (bytes.length > limit) {
          throw const FormatException('파일 크기 제한을 초과했습니다.');
        }
      }
      return bytes;
    } finally {
      client.close();
    }
  }

  Future<void> check() async {
    if (Platform.isAndroid) {
      await checkAndroid();
      return;
    }
    setState(() {
      busy = true;
      update = null;
    });
    try {
      await systemLog('업데이트 확인 시작', '업데이트 정보를 요청합니다.');
      final uri = Uri.parse(url.text.trim());
      final bytes = await download(uri, limit: 100000);
      final manifest = jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
      final current = await bridge.invokeMethod<int>('versionCode') ?? 1;
      final fileKey = Platform.isIOS ? 'ipaUrl' : 'apkUrl';
      if (manifest['versionCode'] is! int ||
          manifest[fileKey] is! String ||
          !RegExp(r'^[a-fA-F0-9]{64}$').hasMatch(manifest['sha256'] ?? '')) {
        throw const FormatException('업데이트 정보 형식이 잘못됐습니다.');
      }
      if (Uri.parse(manifest[fileKey]).scheme != 'https' ||
          (Platform.isIOS &&
              (manifest['sourceUrl'] is! String ||
                  Uri.parse(manifest['sourceUrl']).scheme != 'https'))) {
        throw const FormatException('업데이트 파일과 소스는 HTTPS로 제공해야 합니다.');
      }
      final p = await SharedPreferences.getInstance();
      await p.setString(
        Platform.isIOS ? 'iosUpdateUrl' : 'updateUrl',
        uri.toString(),
      );
      await systemLog(
        '업데이트 확인 결과',
        '현재 빌드 $current · 제공 버전 ${manifest['versionName']} (${manifest['versionCode']})',
      );
      if (!mounted) return;
      setState(() {
        if (manifest['versionCode'] > current) {
          update = manifest;
          message =
              '새 버전 ${manifest['versionName']}\n${manifest['notes'] ?? ''}';
        } else {
          message = '최신 버전입니다.';
        }
      });
    } catch (e) {
      await systemLog(
        '업데이트 확인 실패',
        e is FormatException ? e.message.toString() : '네트워크 또는 업데이트 정보 처리 오류',
      );
      if (mounted) {
        setState(
          () => message = e is FormatException
              ? e.message.toString()
              : '업데이트 정보를 가져오지 못했습니다.',
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> install() async {
    setState(() => busy = true);
    try {
      if (Platform.isIOS) {
        await bridge.invokeMethod('openAltStoreSource', {
          'url': update!['sourceUrl'],
        });
        if (mounted) {
          setState(() => message = 'AltStore Classic에서 캠퍼스레이더의 업데이트를 선택해 주세요.');
        }
        return;
      }
      await systemLog(
        '업데이트 다운로드 시작',
        '대상 ${update!["versionName"]} (${update!["versionCode"]})',
      );
      final bytes = await download(Uri.parse(update!['apkUrl']));
      if (sha256.convert(bytes).toString() !=
          update!['sha256'].toString().toLowerCase()) {
        throw const FormatException('APK 검증에 실패했습니다.');
      }
      await systemLog(
        '업데이트 다운로드 검증 완료',
        'SHA-256 일치 · ${bytes.length}바이트. 설치 완료는 아직 확인되지 않았습니다.',
      );
      final file = File(
        '${(await getTemporaryDirectory()).path}/campus-radar-update.apk',
      );
      await file.writeAsBytes(bytes, flush: true);
      final outcome = await bridge.invokeMethod<String>('installApk', {
        'path': file.path,
        'versionCode': update!['versionCode'],
      });
      await systemLog(
        outcome == 'permission' ? '업데이트 설치 권한 요청' : '업데이트 설치 화면 열림',
        '대상 ${update!["versionName"]} · ${outcome == "permission" ? "설치 권한을 허용한 후 업데이트를 다시 눌러 주세요." : "설치 완료 여부는 변경된 버전의 다음 실행 때 확인합니다."}',
      );
      if (mounted) {
        setState(
          () => message = '설치 화면에서 업데이트를 확인해 주세요. 설치 권한을 켰다면 업데이트 버튼을 다시 누르세요.',
        );
      }
    } catch (e) {
      await systemLog(
        '업데이트 설치 실패',
        e is FormatException
            ? e.message.toString()
            : e is PlatformException
            ? '기기 설치 요청 오류 (${e.code})'
            : '다운로드 또는 설치 처리 오류',
      );
      if (mounted) {
        setState(
          () => message = e is FormatException
              ? e.message.toString()
              : e is PlatformException
              ? e.message ?? '설치 실패'
              : '업데이트를 설치하지 못했습니다.',
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    url.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('앱 업데이트')),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Text('현재 $appVersion · ${channelLabel(appReleaseChannel)}'),
        if (Platform.isAndroid)
          DropdownButtonFormField<String>(
            initialValue: channel,
            key: ValueKey(channel),
            decoration: const InputDecoration(labelText: '업데이트 채널'),
            items: const [
              DropdownMenuItem(value: 'stable', child: Text('정식 릴리스만 받기')),
              DropdownMenuItem(value: 'development', child: Text('개발 버전도 받기')),
            ],
            onChanged: busy
                ? null
                : (value) async {
                    if (value == null) return;
                    final p = await SharedPreferences.getInstance();
                    await p.setString('updateChannel', value);
                    setState(() {
                      channel = value;
                      update = null;
                    });
                    await checkAndroid();
                  },
          ),
        if (Platform.isAndroid)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 12),
            child: Text(
              '개발 버전은 새 기능을 먼저 제공하며 검증이 진행 중일 수 있습니다. 정식 채널로 바꿔도 낮은 버전으로 자동 되돌리지 않습니다. 자동 수집 시에도 업데이트를 확인합니다.',
            ),
          ),
        const SizedBox(height: 16),
        if (Platform.isIOS)
          TextField(
            controller: url,
            decoration: const InputDecoration(
              labelText: '업데이트 정보 주소 (HTTPS)',
              hintText: 'https://…/latest.json',
            ),
          ),
        const SizedBox(height: 16),
        FilledButton.tonal(
          onPressed: busy ? null : check,
          child: const Text('업데이트 확인'),
        ),
        if (busy) const LinearProgressIndicator(),
        const SizedBox(height: 16),
        Text(message),
        if (update != null)
          FilledButton(
            onPressed: busy ? null : install,
            child: const Text('업데이트'),
          ),
        const SizedBox(height: 16),
        Text(
          Platform.isIOS
              ? '업데이트를 누르면 AltStore Classic의 소스를 엽니다. 설치는 AltStore에서 확인합니다.'
              : '업데이트 파일을 받은 뒤 안드로이드 설치 화면에서 최종 확인합니다.',
        ),
      ],
    ),
  );
}

import 'transient_message.dart';
import 'ios_features.dart';
import 'home_navigation.dart';
import 'schedule_workspace.dart';
import 'home_agenda_card.dart';
import 'dashboard_repository.dart';
import 'app_router.dart';
import 'navigation_contract.dart';
import 'native_contract.dart';
import 'courses_page.dart';
import 'ai_chat_page.dart';
import 'ai_daily_card.dart';
import 'settings_page.dart';
import 'account_service.dart';
import 'task_presentation.dart';
import 'background_status_page.dart';
import 'notice_pages.dart';
import 'update_page.dart';
import 'navigation_key.dart';
import 'app_navigation.dart';
import 'today_classes_card.dart';
import 'app_storage.dart';
import 'native_bridge.dart';
import 'app_credentials.dart';
import 'notification_gateway.dart';
import 'app_logging.dart';
import 'course_aliases.dart';
import 'course_labels.dart';
import 'campus_models.dart';
import 'session_scope.dart';
import 'portal_connect.dart';
import 'ui_refresh.dart';
import 'desktop.dart';
import 'radar_theme.dart';
import 'updates.dart';
import 'ai_automation.dart';
import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:workmanager/workmanager.dart';
import 'campus.dart';
import 'services.dart';

Future<void> main(List<String> args) async {
  WidgetsFlutterBinding.ensureInitialized();
  if (Platform.isWindows) await initializeDesktop(args);
  await loadInstalledVersion();
  await loadRadarTheme();
  runApp(const RadarApp());
}

class RadarApp extends StatelessWidget {
  final Widget? home;
  const RadarApp({super.key, this.home});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<ThemeMode>(
    valueListenable: radarThemeMode,
    builder: (context, mode, _) => MaterialApp(
      onGenerateRoute: buildAppRoute,
      navigatorKey: navKey,
      debugShowCheckedModeBanner: false,
      title: '캠퍼스레이더',
      theme: radarTheme(Brightness.light),
      darkTheme: radarTheme(Brightness.dark),
      themeMode: mode,
      home: home ?? const StartupGate(),
    ),
  );
}

Future<String?> initializeServices() async {
  if (Platform.isIOS) {
    iosRefreshHandler = updateIosFeatures;
    iosMidnightTestHandler = testIosMidnight;
  }
  if (Platform.isAndroid || Platform.isIOS) {
    bridge.setMethodCallHandler((call) async {
      if (call.method == 'openTarget') {
        await openItem(call.arguments as String?);
      }
    });
  }
  await loadCourseAliases();
  await recordInstalledVersion();
  await initNotifications(onTap: openItem).timeout(const Duration(seconds: 15));
  if (!Platform.isWindows) {
    await Workmanager()
        .initialize(backgroundDispatcher)
        .timeout(const Duration(seconds: 15));
  }
  if (await credentials.read(key: 'id').timeout(const Duration(seconds: 15)) !=
      null) {
    await registerBackground().timeout(const Duration(seconds: 15));
  }
  if (Platform.isAndroid) {
    try {
      final settings = await bridge.invokeNativeMap<String, dynamic>(
        NativeMethod.dailySettings,
      );
      await scheduleSummaryWarmup(
        settings?['hour'] ?? 18,
        settings?['minute'] ?? 0,
        settings?['enabled'] == true,
      );
    } catch (_) {}
  }
  final launch = await notifications.getNotificationAppLaunchDetails().timeout(
    const Duration(seconds: 15),
  );
  if (Platform.isAndroid || Platform.isIOS) {
    final target = await bridge.invokeNative<String>(
      NativeMethod.takeLaunchTarget,
    );
    if (target != null) return target;
  }
  return (launch?.didNotificationLaunchApp ?? false)
      ? launch?.notificationResponse?.payload
      : null;
}

class StartupGate extends StatefulWidget {
  final Future<String?> Function()? initializer;
  const StartupGate({super.key, this.initializer});
  @override
  State<StartupGate> createState() => _StartupGateState();
}

class _StartupGateState extends State<StartupGate> {
  bool ready = false;
  String? failure;
  @override
  void initState() {
    super.initState();
    start();
  }

  Future<void> start() async {
    setState(() {
      failure = null;
    });
    try {
      final target = await (widget.initializer ?? initializeServices)();
      if (!mounted) return;
      setState(() {
        ready = true;
      });
      if (target != null) {
        WidgetsBinding.instance.addPostFrameCallback((_) => openItem(target));
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        failure = e is PlatformException
            ? '기기 기능을 준비하지 못했습니다 (${e.code}).'
            : e is DatabaseException
            ? '로컬 저장소를 준비하지 못했습니다. 데이터를 지우지 않고 다시 시도해 주세요.'
            : '앱 초기화를 완료하지 못했습니다. 다시 시도해 주세요.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (ready) return const Dashboard();
    return Scaffold(
      appBar: AppBar(title: const Text('캠퍼스레이더')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.radar, size: 64),
              const SizedBox(height: 20),
              const Text(
                '캠퍼스레이더',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              if (failure == null) ...[
                const CircularProgressIndicator(),
                const SizedBox(height: 16),
                const Text('기기 설정을 준비하고 있어요.'),
              ] else ...[
                Text(failure!, textAlign: TextAlign.center),
                const SizedBox(height: 16),
                FilledButton(onPressed: start, child: const Text('다시 시도')),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class Dashboard extends StatefulWidget {
  final bool autoSync;
  const Dashboard({super.key, this.autoSync = true});
  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> with WidgetsBindingObserver {
  CampusItem? desktopSelected;
  Timer? clockRefresh;
  Map<String, dynamic>? availableUpdate;
  List<String> powerWarnings = [];
  bool checkingPower = false;
  Future<void> checkPower() async {
    if (!Platform.isAndroid || checkingPower) return;
    checkingPower = true;
    try {
      final status = await bridge
          .invokeNativeMap<String, dynamic>(NativeMethod.batteryStatus)
          .timeout(const Duration(seconds: 5));
      final warnings = batteryWarnings(status ?? {});
      if (mounted) setState(() => powerWarnings = warnings);
      final fingerprint = jsonEncode({
        'batteryExempt': status?['batteryExempt'],
        'backgroundRestricted': status?['backgroundRestricted'],
      });
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getString('batteryStatusFingerprint') != fingerprint) {
        await systemLog(
          '배터리 설정 상태 변경',
          warnings.isEmpty ? '배터리 최적화 예외 · 백그라운드 제한 없음' : warnings.join('\n'),
        );
        await prefs.setString('batteryStatusFingerprint', fingerprint);
      }
    } catch (_) {
      if (mounted) {
        setState(() => powerWarnings = ['배터리 설정을 확인하지 못했습니다. 다시 확인해 주세요.']);
      }
    } finally {
      checkingPower = false;
    }
  }

  Future<void> openPowerSetting(String method) async {
    try {
      await bridge.invokeMethod(method);
    } catch (_) {
      if (mounted) {
        showTransientMessage(
          context,
          const SnackBar(content: Text('설정을 열지 못했습니다. 휴대전화 설정에서 직접 확인해 주세요.')),
        );
      }
    }
  }

  int section = 0;
  ScheduleView scheduleView = ScheduleView.tasks;
  String taskType = '',
      taskCourse = '',
      taskDeadline = '',
      taskSort = 'due',
      taskQuery = '';
  List<CampusItem> items = [];
  bool loggedIn = false,
      busy = false,
      showDone = false,
      completedOnly = false,
      showExcluded = false,
      hiddenOnly = false;
  bool accountChecked = false, reloading = false;
  String? storageError;
  List<CampusNotice> homeNotices = [];
  Set<String> excluded = {};
  String? error, last;
  String syncPhase = '확인 준비';
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    homeNavigation.addListener(onHomeRequest);
    final request = homeNavigation.value;
    if (request != null) {
      section = request.today ? 0 : 1;
      scheduleView = request.view;
    }
    checkPower();
    if (Platform.isIOS) setIosAiActive(true);
    if (Platform.isWindows) desktopChanged.addListener(desktopReload);
    clockRefresh = Timer.periodic(const Duration(minutes: 1), (_) {
      if (mounted) {
        reload();
        checkPower();
      }
    });
    reload().then((_) {
      if (widget.autoSync && mounted && loggedIn && !busy) sync(source: '앱 시작');
    });
  }

  void onHomeRequest() {
    final request = homeNavigation.value;
    if (request == null || !mounted) return;
    setState(() {
      section = request.today ? 0 : 1;
      scheduleView = request.view;
    });
  }

  void desktopReload() {
    if (mounted) reload();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (Platform.isIOS) setIosAiActive(state == AppLifecycleState.resumed);
    if (state == AppLifecycleState.resumed) checkPower();
    if (widget.autoSync &&
        state == AppLifecycleState.resumed &&
        loggedIn &&
        !busy) {
      sync(source: '앱 복귀');
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    homeNavigation.removeListener(onHomeRequest);
    clockRefresh?.cancel();
    if (Platform.isWindows) desktopChanged.removeListener(desktopReload);
    super.dispose();
  }

  Future<void> reload() async {
    if (reloading) return;
    reloading = true;
    Store? store;
    try {
      // Authentication state must not depend on the optional local list query.
      final id = await credentials.read(key: 'id');
      final pw = await credentials.read(key: 'pw');
      if (mounted) {
        setState(() {
          loggedIn = id != null && pw != null;
          accountChecked = true;
          storageError = null;
        });
      }
      if (Platform.isAndroid || Platform.isWindows) {
        final candidate = Platform.isWindows
            ? await cachedDesktopUpdate()
            : await cachedUpdate();
        if (mounted) setState(() => availableUpdate = candidate);
      }
      store = await Store.open();
      final snapshot = await DashboardRepository(store).read();
      if (mounted) {
        setState(() {
          items = snapshot.items;
          homeNotices = snapshot.notices;
          excluded = snapshot.excluded;
          last = snapshot.lastSuccess;
          error = snapshot.lastError;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(
          () => storageError = accountChecked
              ? '저장된 목록을 읽지 못했습니다. 로그인 정보를 삭제하지 않았습니다. 잠시 후 다시 확인해 주세요.'
              : '저장된 계정에 접근하지 못했습니다. 로그인 정보 유실로 판단하지 않고 재확인을 기다립니다.',
        );
      }
    } finally {
      await store?.db.close();
      if (mounted) {
        setState(() => reloading = false);
      } else {
        reloading = false;
      }
    }
  }

  Future<void> sync({String source = '수동 확인'}) async {
    setState(() => busy = true);
    try {
      await synchronize(
        source: source,
        onPhase: (phase) {
          if (mounted) setState(() => syncPhase = phase);
        },
      );
    } catch (_) {
    } finally {
      await reload();
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> login() async {
    if (busy) return;
    final accepted = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      isDismissible: false,
      enableDrag: false,
      builder: (_) => PortalConnectSheet(
        connect: (id, pw) => verifyAndSavePortal(
          id: id,
          password: pw,
          authenticate: (id, pw) async {
            final client = CampusClient();
            try {
              await client.login(id, pw);
              final terms = await client.api('/term/getYearTermList', null);
              if (terms is! Map || terms['list'] is! List) {
                throw CampusException(
                  '로그인 확인을 완료하지 못했습니다. 학교 사이트 상태를 확인해 주세요.',
                );
              }
            } finally {
              client.close();
            }
          },
          read: (key) => credentials.read(key: key),
          write: (key, value) async {
            if (value == null) {
              await credentials.delete(key: key);
            } else {
              await credentials.write(key: key, value: value);
            }
          },
        ),
      ),
    );
    if (accepted != true || !mounted) return;
    final sessionStore = await Store.open();
    try {
      await SessionScope.rotate(sessionStore, blocked: false);
    } finally {
      await sessionStore.db.close();
    }
    try {
      await reload();
      await requestNotificationPermission();
      await registerBackground();
      await sync();
    } catch (_) {
      await reload();
      if (mounted) {
        setState(
          () => storageError =
              '로그인 정보는 저장했지만 알림·수집 준비를 완료하지 못했습니다. 연결 상태와 권한을 확인해 주세요.',
        );
      }
    }
  }

  Future<void> logout() async {
    if (busy) return;
    final accepted = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('로그아웃할까요?'),
        content: const Text(
          '저장된 포털 계정과 AI 키, 수집 정보·로그를 삭제하고 캘린더 연결을 해제합니다. 캘린더에 저장한 일정은 남습니다.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('로그아웃'),
          ),
        ],
      ),
    );
    if (accepted != true) return;
    setState(() => busy = true);
    final failures = await performAccountLogout();
    if (mounted) setState(() => busy = false);
    if (mounted && failures.isNotEmpty) {
      showTransientMessage(
        context,
        SnackBar(
          content: Text('로그아웃 일부 정리 실패: ${failures.join(', ')}. 다시 로그아웃해 주세요.'),
        ),
      );
    }
    await reload();
  }

  Future<void> testNotification() async {
    await requestNotificationPermission();
    await notifications.show(
      notificationId('test'),
      '캠퍼스레이더 알림 테스트',
      items.isEmpty
          ? '알림이 정상적으로 표시됩니다.'
          : '${items.first.course} · ${items.first.title}',
      noticeStyle,
      payload: items.firstOrNull?.key,
    );
    await logNotification('테스트 알림 발송 요청', '기기에 알림 표시를 요청했습니다.');
  }

  final Set<String> visibilityBusy = {};
  Future<void> toggleTaskVisibility(CampusItem item) async {
    if (visibilityBusy.contains(item.key)) return;
    final before = excluded.contains(item.key);
    final account = await credentials.read(key: 'id');
    setState(() => visibilityBusy.add(item.key));
    try {
      await excludeItem(item, !before);
      await reload();
      if (mounted) {
        showTransientMessage(
          context,
          SnackBar(
            content: Text(before ? '목록에 복구했어요' : '목록에서 숨겼어요 · 이 항목 알림도 꺼집니다'),
            action: SnackBarAction(
              label: '실행 취소',
              onPressed: () async {
                try {
                  if (await credentials.read(key: 'id') != account) return;
                  await excludeItem(item, before);
                  await reload();
                } catch (_) {
                  if (mounted) {
                    showTransientMessage(
                      context,
                      const SnackBar(content: Text('복구하지 못했습니다. 다시 시도해 주세요.')),
                    );
                  }
                }
              },
            ),
          ),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('목록을 변경하지 못했습니다.')));
      }
    } finally {
      if (mounted) setState(() => visibilityBusy.remove(item.key));
    }
  }

  Widget itemTile(CampusItem item) => RadarTaskCard(
    item: item,
    excluded: excluded.contains(item.key),
    onVisibilityToggle: visibilityBusy.contains(item.key)
        ? null
        : () => toggleTaskVisibility(item),
    onTap: () async {
      if (Platform.isWindows && MediaQuery.sizeOf(context).width >= 1180) {
        setState(() => desktopSelected = item);
        return;
      }
      await navigateTo(
        context,
        TaskDestination(item: item, excluded: excluded.contains(item.key)),
      );
      await reload();
    },
  );

  Widget metric(String number, String label, IconData icon) => Expanded(
    child: Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 8),
        child: Column(
          children: [
            Icon(icon, size: 22, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 8),
            Text(
              number,
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),
            Text(label, style: const TextStyle(fontSize: 12)),
          ],
        ),
      ),
    ),
  );

  String taskSection(CampusItem item) {
    if (item.due == null) return '기한 미확인';
    final now = DateTime.now().toUtc();
    if (!item.due!.isAfter(now)) return '기한 지남';
    if (DateUtils.isSameDay(
      now.add(const Duration(hours: 9)),
      item.due!.toUtc().add(const Duration(hours: 9)),
    )) {
      return '오늘 마감';
    }
    return '이후 마감';
  }

  Widget taskDropdown(
    String label,
    String value,
    Map<String, String> values,
    ValueChanged<String> change,
  ) => DropdownButtonFormField<String>(
    key: ValueKey('$label:$value'),
    isExpanded: true,
    initialValue: values.containsKey(value) ? value : '',
    decoration: InputDecoration(
      labelText: label,
      border: const OutlineInputBorder(),
      isDense: true,
    ),
    items: values.entries
        .map(
          (e) => DropdownMenuItem(
            value: e.key,
            child: Text(e.value, overflow: TextOverflow.ellipsis),
          ),
        )
        .toList(),
    onChanged: (v) => setState(() => change(v ?? '')),
  );

  Future<void> openTaskFilters() async {
    var type = taskType,
        course = taskCourse,
        deadline = taskDeadline,
        sort = taskSort;
    var done = showDone, hidden = showExcluded;
    final courses = items.map((e) => e.course).toSet().toList()..sort();
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheet) => StatefulBuilder(
        builder: (sheet, update) {
          Widget field(
            String label,
            String value,
            Map<String, String> values,
            ValueChanged<String> change,
          ) => Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: DropdownButtonFormField<String>(
              key: ValueKey('$label:$value'),
              initialValue: values.containsKey(value) ? value : '',
              isExpanded: true,
              decoration: InputDecoration(labelText: label),
              items: values.entries
                  .map(
                    (e) => DropdownMenuItem(
                      value: e.key,
                      child: Text(e.value, overflow: TextOverflow.ellipsis),
                    ),
                  )
                  .toList(),
              onChanged: (v) => update(() => change(v ?? '')),
            ),
          );
          final count = items
              .where(
                (i) =>
                    i.availableAt(DateTime.now().toUtc()) &&
                    (excluded.contains(i.key)
                        ? hidden
                        : completedOnly
                        ? i.type == 'LR' && i.done
                        : done || !i.done) &&
                    (!hiddenOnly || excluded.contains(i.key)) &&
                    (type.isEmpty || i.type == type) &&
                    (course.isEmpty || i.course == course) &&
                    (deadline.isEmpty ||
                        deadlineState(i.due).name == deadline ||
                        (deadline == 'today' &&
                            i.due != null &&
                            i.due!.isAfter(DateTime.now().toUtc()) &&
                            DateUtils.isSameDay(
                              DateTime.now().toUtc().add(
                                const Duration(hours: 9),
                              ),
                              i.due!.toUtc().add(const Duration(hours: 9)),
                            ))) &&
                    '${i.title} ${i.course} ${courseLabel(i.course)}'
                        .toLowerCase()
                        .contains(taskQuery.toLowerCase()),
              )
              .length;
          return SafeArea(
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(
                24,
                0,
                24,
                24 + MediaQuery.viewInsetsOf(sheet).bottom,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          '목록 필터',
                          style: Theme.of(sheet).textTheme.titleLarge,
                        ),
                      ),
                      TextButton(
                        onPressed: () => update(() {
                          type = '';
                          course = '';
                          deadline = '';
                          sort = 'due';
                          done = false;
                          hidden = false;
                        }),
                        child: const Text('초기화'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  field('유형', type, {
                    '': '전체',
                    'LR': '과제',
                    'LV': '콘텐츠',
                  }, (v) => type = v),
                  field('과목', course, {
                    '': '모든 과목',
                    for (final c in courses) c: courseLabel(c),
                  }, (v) => course = v),
                  field('마감 상태', deadline, {
                    '': '전체',
                    'overdue': '기한 지남',
                    'withinDay': '24시간 이내',
                    'today': '오늘 마감',
                    'remaining': '아직 남음',
                    'unknown': '기한 미확인',
                  }, (v) => deadline = v),
                  field('정렬', sort, {
                    'due': '마감 빠른 순',
                    'course': '과목명 순',
                    'title': '제목 순',
                  }, (v) => sort = v),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('완료 포함'),
                    value: done,
                    onChanged: (v) => update(() => done = v),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('제외 항목 포함'),
                    value: hidden,
                    onChanged: (v) => update(() => hidden = v),
                  ),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: () {
                      setState(() {
                        taskType = type;
                        taskCourse = course;
                        taskDeadline = deadline;
                        taskSort = sort;
                        showDone = done;
                        showExcluded = hidden;
                      });
                      Navigator.pop(sheet);
                    },
                    child: Text('결과 $count개 보기'),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now().toUtc();
    final available = items
        .where((i) => i.availableAt(now) && !excluded.contains(i.key))
        .toList();
    final pending = available.where((i) => i.status == 'pending').toList()
      ..sort(
        (a, b) => (a.due ?? DateTime.utc(2100)).compareTo(
          b.due ?? DateTime.utc(2100),
        ),
      );
    final urgent = pending
        .where((i) => deadlineState(i.due, now: now) == DeadlineState.withinDay)
        .toList();
    final today = pending
        .where(
          (i) =>
              i.due != null &&
              i.due!.isAfter(now) &&
              DateUtils.isSameDay(
                now.add(const Duration(hours: 9)),
                i.due!.toUtc().add(const Duration(hours: 9)),
              ),
        )
        .length;
    final visible = items
        .where(
          (i) =>
              i.availableAt(now) &&
              (!hiddenOnly || excluded.contains(i.key)) &&
              (excluded.contains(i.key)
                  ? showExcluded
                  : completedOnly
                  ? i.type == 'LR' && i.done
                  : showDone || !i.done) &&
              (taskType.isEmpty || i.type == taskType) &&
              (taskCourse.isEmpty || i.course == taskCourse) &&
              (taskDeadline.isEmpty ||
                  (taskDeadline == 'today' &&
                      i.due != null &&
                      i.due!.isAfter(now) &&
                      DateUtils.isSameDay(
                        now.add(const Duration(hours: 9)),
                        i.due!.toUtc().add(const Duration(hours: 9)),
                      )) ||
                  deadlineState(i.due, now: now).name == taskDeadline) &&
              '${i.title} ${i.course} ${courseLabel(i.course)}'
                  .toLowerCase()
                  .contains(taskQuery.toLowerCase()),
        )
        .toList();
    visible.sort(
      (a, b) => taskSort == 'course'
          ? a.course.compareTo(b.course)
          : taskSort == 'title'
          ? a.title.compareTo(b.title)
          : (a.due ?? DateTime.utc(2100)).compareTo(
              b.due ?? DateTime.utc(2100),
            ),
    );
    final home = RefreshIndicator(
      onRefresh: loggedIn ? sync : reload,
      child: ListView(
        key: PageStorageKey('home-section-$section'),
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
        children: [
          if (busy) ...[
            const LinearProgressIndicator(),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Text('$syncPhase 중…'),
            ),
          ],
          if (storageError != null)
            Card(
              color: Theme.of(context).colorScheme.errorContainer,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text(storageError!),
                    TextButton(
                      onPressed: reloading ? null : reload,
                      child: const Text('저장 정보 다시 확인'),
                    ),
                  ],
                ),
              ),
            ),
          if (!accountChecked)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('저장된 계정 확인 중…'),
            ),
          if (accountChecked && !loggedIn)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.radar, size: 44),
                    const SizedBox(height: 16),
                    const Text(
                      '놓치기 전에, 한눈에',
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text('포털을 연결하면 과제와 콘텐츠를 확인할 수 있어요.'),
                    const SizedBox(height: 16),
                    FilledButton(
                      onPressed: busy ? null : login,
                      child: const Text('포털 연결'),
                    ),
                  ],
                ),
              ),
            ),
          if (loggedIn) ...[
            if (section == 0) ...[
              Text(
                '${now.add(const Duration(hours: 9)).month}월 ${now.add(const Duration(hours: 9)).day}일 · 한국 시간',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: 16),
              Text('포털 연결됨', style: Theme.of(context).textTheme.labelSmall),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      '오늘도 놓치지 않게',
                      style: Theme.of(context).textTheme.headlineSmall
                          ?.copyWith(fontWeight: FontWeight.w700),
                    ),
                  ),
                  IconButton(
                    tooltip: '지금 확인',
                    onPressed: busy ? null : () => sync(),
                    icon: const Icon(Icons.sync),
                  ),
                ],
              ),
              Text(
                last == null
                    ? '아직 수집 전'
                    : '마지막 확인 ${formatDate(DateTime.parse(last!))}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  ActionChip(
                    label: Text('오늘 마감 $today개'),
                    onPressed: () => setState(() {
                      section = 1;
                      taskDeadline = 'today';
                    }),
                  ),
                  ActionChip(
                    label: Text('24시간 이내 ${urgent.length}개'),
                    onPressed: () => setState(() {
                      section = 1;
                      taskDeadline = 'withinDay';
                    }),
                  ),
                  ActionChip(
                    label: Text('미완료 ${pending.length}개'),
                    onPressed: () => setState(() => section = 1),
                  ),
                ],
              ),
              if (Platform.isAndroid)
                TodayClassesCard(key: ValueKey('classes:$last')),
            ],
            if (section == 0) ...[
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      '먼저 확인할 일',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                  ),

                  TextButton(
                    onPressed: () => setState(() => section = 1),
                    child: const Text('전체 보기'),
                  ),
                ],
              ),
              if (pending.isEmpty && !busy)
                const Padding(
                  padding: EdgeInsets.all(24),
                  child: Text('현재 수집된 목록에 미완료 항목이 없어요.'),
                ),
              ...pending.take(5).map(itemTile),
              HomeAgendaCard(key: ValueKey('agenda:$last')),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      '최근 공지',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                  ),

                  TextButton(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const NoticesPage()),
                    ),
                    child: const Text('전체 보기'),
                  ),
                ],
              ),
              if (homeNotices.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  child: Text('수집된 공지가 없어요.'),
                ),
              ...homeNotices
                  .take(2)
                  .map(
                    (n) => Card(
                      child: ListTile(
                        leading: Icon(
                          Icons.campaign_outlined,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                        title: Text(
                          n.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        subtitle: Text(courseLabel(n.course)),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () =>
                            navigateTo(context, NoticeDestination(notice: n)),
                      ),
                    ),
                  ),
              const SizedBox(height: 20),
              const AiDailyCard(),
              if (error?.isNotEmpty == true)
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.sync_problem),
                    title: const Text('최근 확인에 문제가 있어요'),
                    subtitle: Text(error!),
                    trailing: IconButton(
                      tooltip: '다시 확인',
                      onPressed: busy ? null : () => sync(),
                      icon: const Icon(Icons.refresh),
                    ),
                  ),
                ),
              if (availableUpdate != null)
                Card(
                  color: Theme.of(context).colorScheme.secondaryContainer,
                  child: ListTile(
                    leading: const Icon(Icons.system_update_outlined),
                    title: const Text('업데이트 가능'),
                    subtitle: Text(
                      '${availableUpdate!['versionName']} · ${channelLabel(availableUpdate!['channel'])}',
                    ),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => Platform.isWindows
                              ? const DesktopUpdatePage()
                              : const UpdatePage(),
                        ),
                      );
                      await reload();
                    },
                  ),
                ),
              if (powerWarnings.isNotEmpty)
                Card(
                  color: Theme.of(context).colorScheme.errorContainer,
                  child: ListTile(
                    leading: const Icon(Icons.battery_alert_outlined),
                    title: const Text('앱 배터리 설정 확인'),
                    subtitle: Text(powerWarnings.join('\n')),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const BackgroundStatusPage(),
                      ),
                    ),
                    trailing: IconButton(
                      onPressed: () => openPowerSetting('openAppSettings'),
                      icon: const Icon(Icons.settings_outlined),
                      tooltip: '앱 배터리 설정',
                    ),
                  ),
                ),

              TextButton.icon(
                onPressed: () =>
                    navigateTo(context, SummaryDestination(settings: true)),
                icon: const Icon(Icons.notifications_outlined, size: 18),
                label: const Text('하루 요약 알림 설정'),
              ),
            ] else ...[
              const SizedBox(height: 20),
              TextField(
                decoration: const InputDecoration(
                  hintText: '과제·콘텐츠·과목 검색',
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(),
                ),
                onChanged: (v) => setState(() => taskQuery = v),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          ChoiceChip(
                            label: const Text('진행 중'),
                            selected: !completedOnly && !hiddenOnly,
                            onSelected: (_) => setState(() {
                              completedOnly = false;
                              hiddenOnly = false;
                              showDone = false;
                              showExcluded = false;
                            }),
                          ),
                          const SizedBox(width: 8),
                          ChoiceChip(
                            label: const Text('제출 완료 과제'),
                            selected: completedOnly,
                            onSelected: (_) => setState(() {
                              completedOnly = true;
                              hiddenOnly = false;
                              showDone = true;
                              showExcluded = false;
                              taskType = 'LR';
                            }),
                          ),
                          const SizedBox(width: 8),
                          ChoiceChip(
                            label: const Text('숨김'),
                            selected: hiddenOnly,
                            onSelected: (_) => setState(() {
                              hiddenOnly = true;
                              completedOnly = false;
                              showExcluded = true;
                            }),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filledTonal(
                    tooltip: '필터',
                    onPressed: openTaskFilters,
                    icon: Badge(
                      isLabelVisible:
                          taskCourse.isNotEmpty ||
                          taskDeadline.isNotEmpty ||
                          taskSort != 'due' ||
                          showDone ||
                          showExcluded ||
                          taskType.isNotEmpty,
                      label: const Text('•'),
                      child: const Icon(Icons.tune),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: [
                  for (final e in {'': '전체', 'LR': '과제', 'LV': '콘텐츠'}.entries)
                    FilterChip(
                      label: Text(e.value),
                      selected: taskType == e.key,
                      onSelected: (_) => setState(() => taskType = e.key),
                    ),
                  if (taskCourse.isNotEmpty)
                    InputChip(
                      label: Text(courseLabel(taskCourse)),
                      onDeleted: () => setState(() => taskCourse = ''),
                    ),
                  if (taskDeadline.isNotEmpty)
                    InputChip(
                      label: Text(
                        {
                          'overdue': '기한 지남',
                          'withinDay': '24시간 이내',
                          'today': '오늘 마감',
                          'remaining': '아직 남음',
                          'unknown': '기한 미확인',
                        }[taskDeadline]!,
                      ),
                      onDeleted: () => setState(() => taskDeadline = ''),
                    ),
                ],
              ),
              Text(
                '${visible.length}개 · 공개·시작된 항목만 표시',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 12),
              if (visible.isEmpty && !busy)
                const Padding(
                  padding: EdgeInsets.all(24),
                  child: Text('조건에 맞는 과제·콘텐츠가 없습니다.'),
                ),
              for (var index = 0; index < visible.length; index++) ...[
                if (taskSort == 'due' &&
                    (index == 0 ||
                        taskSection(visible[index]) !=
                            taskSection(visible[index - 1])))
                  SectionHeading(taskSection(visible[index])),
                itemTile(visible[index]),
              ],
            ],
          ],
        ],
      ),
    );
    final scheduleBody = section == 1
        ? ScheduleWorkspace(
            tasks: home,
            view: scheduleView,
            onChanged: (value) => setState(() => scheduleView = value),
          )
        : home;
    if (Platform.isWindows && MediaQuery.sizeOf(context).width >= 850) {
      return Scaffold(
        body: Row(
          children: [
            NavigationRail(
              extended: MediaQuery.sizeOf(context).width >= 1180,
              selectedIndex: section == 4 ? 3 : section,
              onDestinationSelected: (v) =>
                  setState(() => section = v == 3 ? 4 : v),
              leading: const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Icon(Icons.radar, size: 32),
              ),
              destinations: const [
                NavigationRailDestination(
                  icon: Icon(Icons.today_outlined),
                  label: Text('오늘'),
                ),
                NavigationRailDestination(
                  icon: Icon(Icons.checklist),
                  label: Text('일정'),
                ),
                NavigationRailDestination(
                  icon: Icon(Icons.school_outlined),
                  label: Text('과목'),
                ),

                NavigationRailDestination(
                  icon: Icon(Icons.settings_outlined),
                  label: Text('설정'),
                ),
              ],
            ),
            const VerticalDivider(width: 1),
            Expanded(
              child: section == 2
                  ? const CoursesPage()
                  : section == 4
                  ? SettingsHub(
                      connected: loggedIn,
                      connect: login,
                      logout: busy ? () {} : logout,
                      test: testNotification,
                    )
                  : Scaffold(
                      appBar: AppBar(
                        title: Text(section == 0 ? '오늘' : '일정'),
                        actions: [
                          IconButton(
                            tooltip: 'PC 실행 설정',
                            onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => const DesktopSettingsPage(),
                              ),
                            ),
                            icon: const Icon(Icons.desktop_windows_outlined),
                          ),
                        ],
                      ),
                      body: Row(
                        children: [
                          Expanded(
                            child: Align(
                              alignment: Alignment.topCenter,
                              child: ConstrainedBox(
                                constraints: const BoxConstraints(
                                  maxWidth: 1040,
                                ),
                                child: scheduleBody,
                              ),
                            ),
                          ),
                          if (MediaQuery.sizeOf(context).width >= 1180 &&
                              desktopSelected != null)
                            SizedBox(
                              width: 360,
                              child: DesktopTaskPreview(
                                item: desktopSelected!,
                                close: () =>
                                    setState(() => desktopSelected = null),
                                open: () async {
                                  await navigateTo(
                                    context,
                                    TaskDestination(
                                      item: desktopSelected!,
                                      excluded: excluded.contains(
                                        desktopSelected!.key,
                                      ),
                                    ),
                                  );
                                  await reload();
                                },
                              ),
                            ),
                        ],
                      ),
                    ),
            ),
          ],
        ),
      );
    }
    return Scaffold(
      appBar: section <= 1
          ? AppBar(
              title: Text(section == 0 ? '오늘' : '일정'),
              actions: [
                IconButton(
                  onPressed: () => setState(() => section = 2),
                  icon: const Icon(Icons.school_outlined),
                  tooltip: '내 과목',
                ),
                IconButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const AiChatPage()),
                  ),
                  icon: const Icon(Icons.chat_bubble_outline),
                  tooltip: '질문하기',
                ),
                IconButton(
                  onPressed: () => setState(() => section = 4),
                  icon: const Icon(Icons.settings_outlined),
                  tooltip: '설정',
                ),
              ],
            )
          : null,
      body: section == 2
          ? const CoursesPage()
          : section == 4
          ? SettingsHub(
              connected: loggedIn,
              connect: login,
              logout: busy ? () {} : logout,
              test: testNotification,
            )
          : scheduleBody,
      bottomNavigationBar: NavigationBar(
        selectedIndex: section == 4 ? 3 : section,
        onDestinationSelected: (v) => setState(() => section = v == 3 ? 4 : v),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.today_outlined),
            selectedIcon: Icon(Icons.today),
            label: '오늘',
          ),
          NavigationDestination(
            icon: Icon(Icons.checklist_outlined),
            selectedIcon: Icon(Icons.checklist),
            label: '일정',
          ),
          NavigationDestination(
            icon: Icon(Icons.school_outlined),
            selectedIcon: Icon(Icons.school),
            label: '과목',
          ),

          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings),
            label: '설정',
          ),
        ],
      ),
    );
  }
}

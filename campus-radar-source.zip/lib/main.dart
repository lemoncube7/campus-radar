import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';
import 'campus.dart';
import 'services.dart';

final navKey = GlobalKey<NavigatorState>();
Future<void> openItem(String? key) async {
  if (key == null) return;
  final store = await Store.open();
  final item = (await store.items()).where((i) => i.key == key).firstOrNull;
  await store.db.close();
  if (item != null) {
    navKey.currentState?.push(
      MaterialPageRoute(builder: (_) => DetailPage(item: item)),
    );
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initNotifications(onTap: openItem);
  await Workmanager().initialize(backgroundDispatcher);
  if (await credentials.read(key: 'id') != null) await registerBackground();
  final launch = await notifications.getNotificationAppLaunchDetails();
  runApp(
    MaterialApp(
      navigatorKey: navKey,
      debugShowCheckedModeBanner: false,
      title: '캠퍼스레이더',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff3448ae)),
        useMaterial3: true,
      ),
      home: const Dashboard(),
    ),
  );
  if (launch?.didNotificationLaunchApp ?? false) {
    WidgetsBinding.instance.addPostFrameCallback(
      (_) => openItem(launch?.notificationResponse?.payload),
    );
  }
}

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});
  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> with WidgetsBindingObserver {
  List<CampusItem> items = [];
  bool loggedIn = false, busy = false, showDone = false;
  String? error, last;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    reload().then((_) {
      if (mounted && loggedIn && !busy) sync();
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && loggedIn && !busy) sync();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> reload() async {
    final store = await Store.open();
    final list = await store.items();
    final stamp = await store.meta('lastSuccess');
    final err = await store.meta('lastError');
    await store.db.close();
    final signed = await credentials.read(key: 'id') != null;
    if (mounted) {
      setState(() {
        items = list;
        last = stamp;
        error = err;
        loggedIn = signed;
      });
    }
  }

  Future<void> sync() async {
    setState(() => busy = true);
    try {
      await synchronize();
    } catch (_) {}
    await reload();
    if (mounted) setState(() => busy = false);
  }

  Future<void> login() async {
    final id = TextEditingController(), pw = TextEditingController();
    final accepted = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('충남대 포털 연결'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('계정은 이 기기에 암호화해 저장합니다. 주기적으로 로그인해 과제를 확인합니다.'),
            TextField(
              controller: id,
              decoration: const InputDecoration(labelText: '학번 / 아이디'),
              autocorrect: false,
            ),
            TextField(
              controller: pw,
              obscureText: true,
              autocorrect: false,
              enableSuggestions: false,
              decoration: const InputDecoration(labelText: '포털 비밀번호'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('연결'),
          ),
        ],
      ),
    );
    if (accepted == true && id.text.trim().isNotEmpty && pw.text.isNotEmpty) {
      await credentials.write(key: 'id', value: id.text.trim());
      await credentials.write(key: 'pw', value: pw.text);
      await notifications
          .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin
          >()
          ?.requestNotificationsPermission();
      await registerBackground();
      await sync();
    }
    id.dispose();
    pw.dispose();
  }

  Future<void> logout() async {
    if (busy) return;
    await Workmanager().cancelByUniqueName(periodicTask);
    await credentials.deleteAll();
    await notifications.cancelAll();
    await bridge.invokeMethod('clearWebSession');
    final store = await Store.open();
    await store.db.delete('items');
    await store.db.delete('events');
    await store.db.delete('meta');
    await store.db.close();
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('scheduled');
    await reload();
  }

  Future<void> testNotification() async {
    await notifications
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >()
        ?.requestNotificationsPermission();
    await notifications.show(
      notificationId('test'),
      '캠퍼스레이더 알림 테스트',
      items.isEmpty
          ? '알림이 정상적으로 표시됩니다.'
          : '${items.first.course} · ${items.first.title}',
      noticeStyle,
      payload: items.firstOrNull?.key,
    );
  }

  @override
  Widget build(BuildContext context) {
    final visible = items.where((i) => showDone || !i.done).toList();
    return Scaffold(
      appBar: AppBar(
        title: const Text('캠퍼스레이더'),
        actions: [
          IconButton(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const UpdatePage()),
            ),
            icon: const Icon(Icons.system_update_alt),
            tooltip: '업데이트',
          ),
          if (loggedIn)
            IconButton(
              onPressed: testNotification,
              icon: const Icon(Icons.notifications_active_outlined),
              tooltip: '알림 테스트',
            ),
          if (loggedIn)
            IconButton(
              onPressed: busy ? null : logout,
              icon: const Icon(Icons.logout),
              tooltip: '로그아웃',
            ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: loggedIn ? sync : reload,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text(
              '놓치기 전에, 한눈에',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            if (!loggedIn)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      const Text('포털을 연결하면 과제와 콘텐츠를 확인할 수 있어요.'),
                      const SizedBox(height: 16),
                      FilledButton(
                        onPressed: login,
                        child: const Text('포털 연결'),
                      ),
                    ],
                  ),
                ),
              )
            else ...[
              Text(
                last == null
                    ? '아직 확인한 정보가 없습니다.'
                    : '마지막 확인 ${formatDate(DateTime.parse(last!))}',
              ),
              const Text(
                '약 1시간마다 자동 확인 · 첫 연결은 기존 과제를 기준 목록으로 저장합니다.',
                style: TextStyle(fontSize: 12),
              ),
              const Text(
                '마감 하루 전 알림은 절전 상태에서 늦어질 수 있습니다.',
                style: TextStyle(fontSize: 12),
              ),
              if (error?.isNotEmpty ?? false)
                Card(
                  color: Theme.of(context).colorScheme.errorContainer,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text(error!),
                  ),
                ),
              Row(
                children: [
                  FilledButton.tonalIcon(
                    onPressed: busy ? null : sync,
                    icon: busy
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.refresh),
                    label: Text(busy ? '확인 중…' : '지금 확인'),
                  ),
                  const Spacer(),
                  const Text('완료 포함'),
                  Switch(
                    value: showDone,
                    onChanged: (v) => setState(() => showDone = v),
                  ),
                ],
              ),
              if (visible.isEmpty && !busy)
                const Padding(
                  padding: EdgeInsets.all(30),
                  child: Text('표시할 과제·콘텐츠가 없습니다.'),
                ),
              for (final item in visible)
                Card(
                  child: ListTile(
                    leading: Icon(
                      item.type == 'LR'
                          ? Icons.assignment_outlined
                          : Icons.play_circle_outline,
                    ),
                    title: Text(item.title),
                    subtitle: Text(
                      '${item.course}\n${item.due == null ? '마감 미확인' : formatDate(item.due!)} · ${statusText(item)}',
                    ),
                    isThreeLine: true,
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => DetailPage(item: item)),
                    ),
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }
}

String formatDate(DateTime date) {
  final d = date.toUtc().add(const Duration(hours: 9));
  return '${d.month}/${d.day} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')} (한국 시간)';
}

String statusText(CampusItem i) => i.status == 'unknown'
    ? '상태 확인 불가'
    : i.done
    ? (i.type == 'LR' ? '제출 완료' : '완료')
    : (i.type == 'LR' ? '미제출' : '미완료');

class DetailPage extends StatefulWidget {
  final CampusItem item;
  const DetailPage({super.key, required this.item});
  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  bool busy = false;
  Future<void> go() async {
    setState(() => busy = true);
    final client = CampusClient();
    try {
      final id = await credentials.read(key: 'id'),
          pw = await credentials.read(key: 'pw');
      if (id == null || pw == null) throw CampusException('포털을 다시 연결해 주세요.');
      await client.login(id, pw);
      final navigation = await client.navigation(widget.item);
      await bridge.invokeMethod('openCampus', navigation);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              e is CampusException ? e.message : '사이버캠퍼스를 열지 못했습니다.',
            ),
          ),
        );
      }
    } finally {
      client.close();
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final i = widget.item;
    final diff = i.due?.difference(DateTime.now().toUtc());
    return Scaffold(
      appBar: AppBar(title: Text(i.type == 'LR' ? '과제 상세' : '콘텐츠 상세')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Text(i.course),
          const SizedBox(height: 8),
          Text(
            i.title,
            style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          Text(statusText(i)),
          Text(i.due == null ? '마감 미확인' : '마감 ${formatDate(i.due!)}'),
          if (diff != null)
            Text(
              diff.isNegative
                  ? '마감이 지났습니다.'
                  : '${diff.inDays}일 ${diff.inHours % 24}시간 남음',
            ),
          const SizedBox(height: 20),
          Text(i.body.isEmpty ? '상세 내용은 사이버캠퍼스에서 확인하세요.' : i.body),
          const SizedBox(height: 28),
          FilledButton.icon(
            onPressed: busy ? null : go,
            icon: const Icon(Icons.open_in_new),
            label: Text(busy ? '연결 중…' : '사이버캠퍼스 바로가기'),
          ),
          const SizedBox(height: 12),
          const Text(
            '제출·완료 상태는 마지막 수집 기준입니다. 콘텐츠는 해당 강의의 학습 항목으로 연결합니다.',
            style: TextStyle(fontSize: 12),
          ),
        ],
      ),
    );
  }
}

class UpdatePage extends StatefulWidget {
  const UpdatePage({super.key});
  @override
  State<UpdatePage> createState() => _UpdatePageState();
}

class _UpdatePageState extends State<UpdatePage> {
  final url = TextEditingController();
  bool busy = false;
  String message = '';
  Map<String, dynamic>? update;
  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (mounted) {
        setState(
          () => url.text =
              p.getString('updateUrl') ??
              'https://github.com/lemoncube7/campus-radar/releases/latest/download/latest.json',
        );
      }
    });
  }

  Future<List<int>> download(
    Uri uri, {
    int limit = 100000000,
    int redirects = 0,
  }) async {
    if (redirects > 8) throw const FormatException('다운로드 주소가 반복됩니다.');
    if (uri.scheme != 'https') {
      throw const FormatException('HTTPS 주소를 사용해 주세요.');
    }
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 20);
    try {
      final req = await client.getUrl(uri);
      req.followRedirects = false;
      final response = await req.close().timeout(const Duration(seconds: 30));
      if (response.isRedirect) {
        final location = response.headers.value('location');
        if (location == null) throw const FormatException('다운로드 이동 실패');
        return download(
          uri.resolve(location),
          limit: limit,
          redirects: redirects + 1,
        );
      }
      if (response.statusCode != 200) throw const FormatException('다운로드 응답 오류');
      final bytes = <int>[];
      await for (final chunk in response.timeout(const Duration(seconds: 60))) {
        bytes.addAll(chunk);
        if (bytes.length > limit) {
          throw const FormatException('파일 크기 제한을 초과했습니다.');
        }
      }
      return bytes;
    } finally {
      client.close();
    }
  }

  Future<void> check() async {
    setState(() {
      busy = true;
      update = null;
    });
    try {
      final uri = Uri.parse(url.text.trim());
      final bytes = await download(uri, limit: 100000);
      final manifest = jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
      final current = await bridge.invokeMethod<int>('versionCode') ?? 1;
      if (manifest['versionCode'] is! int ||
          manifest['apkUrl'] is! String ||
          !RegExp(r'^[a-fA-F0-9]{64}$').hasMatch(manifest['sha256'] ?? '')) {
        throw const FormatException('업데이트 정보 형식이 잘못됐습니다.');
      }
      if (Uri.parse(manifest['apkUrl']).scheme != 'https') {
        throw const FormatException('APK는 HTTPS로 제공해야 합니다.');
      }
      final p = await SharedPreferences.getInstance();
      await p.setString('updateUrl', uri.toString());
      setState(() {
        if (manifest['versionCode'] > current) {
          update = manifest;
          message =
              '새 버전 ${manifest['versionName']}\n${manifest['notes'] ?? ''}';
        } else {
          message = '최신 버전입니다.';
        }
      });
    } catch (e) {
      if (mounted) {
        setState(
          () => message = e is FormatException
              ? e.message.toString()
              : '업데이트 정보를 가져오지 못했습니다.',
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> install() async {
    setState(() => busy = true);
    try {
      final bytes = await download(Uri.parse(update!['apkUrl']));
      if (sha256.convert(bytes).toString() !=
          update!['sha256'].toString().toLowerCase()) {
        throw const FormatException('APK 검증에 실패했습니다.');
      }
      final file = File(
        '${(await getTemporaryDirectory()).path}/campus-radar-update.apk',
      );
      await file.writeAsBytes(bytes, flush: true);
      await bridge.invokeMethod('installApk', {
        'path': file.path,
        'versionCode': update!['versionCode'],
      });
      if (mounted) {
        setState(
          () => message = '설치 화면에서 업데이트를 확인해 주세요. 설치 권한을 켰다면 업데이트 버튼을 다시 누르세요.',
        );
      }
    } catch (e) {
      if (mounted) {
        setState(
          () => message = e is FormatException
              ? e.message.toString()
              : e is PlatformException
              ? e.message ?? '설치 실패'
              : '업데이트를 설치하지 못했습니다.',
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    url.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('앱 업데이트')),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        const Text('현재 버전 0.1.0'),
        const SizedBox(height: 16),
        TextField(
          controller: url,
          decoration: const InputDecoration(
            labelText: '업데이트 정보 주소 (HTTPS)',
            hintText: 'https://…/latest.json',
          ),
        ),
        const SizedBox(height: 16),
        FilledButton.tonal(
          onPressed: busy ? null : check,
          child: const Text('업데이트 확인'),
        ),
        if (busy) const LinearProgressIndicator(),
        const SizedBox(height: 16),
        Text(message),
        if (update != null)
          FilledButton(
            onPressed: busy ? null : install,
            child: const Text('업데이트'),
          ),
        const SizedBox(height: 16),
        const Text('업데이트 파일을 받은 뒤 안드로이드 설치 화면에서 최종 확인합니다.'),
      ],
    ),
  );
}

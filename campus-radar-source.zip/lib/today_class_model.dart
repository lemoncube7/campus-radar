import 'timetable_model.dart';
import 'timetable_exceptions.dart';

class NextClassOccurrence {
  final ClassSlot slot;
  final DateTime day;
  const NextClassOccurrence(this.slot, this.day);
  DateTime get start =>
      DateTime(day.year, day.month, day.day, slot.start ~/ 60, slot.start % 60);
  DateTime get end =>
      DateTime(day.year, day.month, day.day, slot.end ~/ 60, slot.end % 60);
}

/// [now] is the Korean wall clock, matching stored weekly timetable minutes.
NextClassOccurrence? nextClassOccurrence(
  List<ClassSlot> entries,
  List<ClassCancellation> cancellations,
  DateTime now, {
  DateTime? until,
}) {
  for (var offset = 0; offset <= 7; offset++) {
    final day = DateTime(now.year, now.month, now.day + offset);
    if (until != null &&
        day.isAfter(DateTime(until.year, until.month, until.day))) {
      break;
    }
    final rows = classesOnDate(entries, cancellations, day)
      ..sort((a, b) => a.start.compareTo(b.start));
    for (final slot in rows) {
      final occurrence = NextClassOccurrence(slot, day);
      final civilNow = DateTime(
        now.year,
        now.month,
        now.day,
        now.hour,
        now.minute,
        now.second,
      );
      if (occurrence.end.isAfter(civilNow)) return occurrence;
    }
  }
  return null;
}

import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';
import 'ux_pages.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'ai.dart';
import 'campus.dart';
import 'services.dart';

String dateText(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
String userError(Object e) => e is AiFailure
    ? e.message
    : e is PlatformException
    ? e.message ?? '기기 작업을 완료하지 못했습니다.'
    : '처리하지 못했습니다. 다시 시도해 주세요.';

class AiSettingsPage extends StatefulWidget {
  const AiSettingsPage({super.key});
  @override
  State<AiSettingsPage> createState() => _AiSettingsState();
}

class _AiSettingsState extends State<AiSettingsPage> {
  final keyInput = TextEditingController();
  bool saved = false, consent = false, busy = true;
  int requests = 0;
  String? message;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final key = await credentials.read(key: 'geminiApiKey');
      final store = await Store.open();
      try {
        final agreed = await store.meta('aiConsent') == aiConsentVersion;
        final day = DateTime.now()
            .toUtc()
            .add(const Duration(hours: 9))
            .toIso8601String()
            .substring(0, 10);
        final count =
            int.tryParse(await store.meta('aiRequests:$day') ?? '0') ?? 0;
        if (mounted) {
          setState(() {
            saved = key?.isNotEmpty == true;
            consent = agreed;
            requests = count;
            busy = false;
          });
        }
      } finally {
        await store.db.close();
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          busy = false;
          message = '설정을 읽지 못했습니다.';
        });
      }
    }
  }

  Future<void> save({bool remove = false}) async {
    if (!remove && (!consent || (!saved && keyInput.text.trim().isEmpty))) {
      setState(() => message = '개인 키 입력과 외부 전송 동의를 확인해 주세요.');
      return;
    }
    setState(() => busy = true);
    try {
      if (remove) {
        await credentials.delete(key: 'geminiApiKey');
      } else if (keyInput.text.trim().isNotEmpty) {
        final key = keyInput.text.trim();
        if (key.length < 20 || key.contains(RegExp(r'\s'))) {
          throw const AiFailure('API 키 형식을 확인해 주세요.');
        }
        await credentials.write(key: 'geminiApiKey', value: key);
      }
      final store = await Store.open();
      try {
        await store.setMeta('aiConsent', remove ? '' : aiConsentVersion);
        if (remove) {
          await store.setMeta('aiAuto', 'no');
          await store.setMeta('aiSummary', 'no');
          final p = await SharedPreferences.getInstance();
          await p.setBool('aiSummaryEnabled', false);
          await p.remove('aiSummaryText');
          await Workmanager().cancelByTag('campus-ai');
        }
        await store.log(
          'ai',
          remove ? 'AI 키 삭제' : 'AI 설정 저장',
          remove
              ? 'AI 새 분석을 비활성화했습니다. 기존 분석 결과는 남습니다.'
              : '개인 키를 기기 보안 저장소에 저장했습니다.',
        );
      } finally {
        await store.db.close();
      }
      keyInput.clear();
      if (mounted) {
        setState(() {
          saved = !remove;
          consent = !remove;
          message = remove ? '키를 삭제했습니다.' : '저장했습니다. 아래에서 자동 분석과 요약을 켤 수 있어요.';
        });
      }
    } catch (e) {
      if (mounted) setState(() => message = userError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    keyInput.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('AI 공지 분석 설정')),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        const Text(
          'Gemini 3.5 Flash Lite',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        const Text(
          '개인 API 키를 입력한 사람만 사용하는 선택 기능입니다. 키가 없어도 과제 알림과 캘린더는 사용할 수 있습니다.',
        ),
        const SizedBox(height: 12),
        Text(saved ? 'API 키 저장됨 · 값을 다시 표시하지 않습니다.' : 'API 키 미등록'),
        TextField(
          controller: keyInput,
          obscureText: true,
          enableSuggestions: false,
          autocorrect: false,
          decoration: InputDecoration(
            labelText: saved ? '키 변경 (변경할 때만 입력)' : 'Gemini API 키',
          ),
        ),
        const SizedBox(height: 12),
        const Text(
          'AI Studio에서 결제가 연결되지 않은 무료 등급 프로젝트의 키를 사용하세요. 유료 프로젝트의 키는 과금될 수 있습니다. 앱은 Google의 프로젝트 등급이나 전체 잔여량을 확인할 수 없습니다.',
        ),
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          value: consent,
          onChanged: busy ? null : (v) => setState(() => consent = v ?? false),
          title: const Text('공지 외부 전송에 동의'),
          subtitle: const Text(
            '수동 분석 또는 자동 분석을 켜면 제목·과목명·게시 시각·본문을 Google Gemini에 보냅니다. 포털 계정·쿠키는 보내지 않습니다. 무료 API 입력·출력은 Google 제품 개선에 사용될 수 있습니다.',
          ),
        ),
        const Text(
          '이미지·첨부파일은 분석하지 않습니다. AI가 만든 날짜와 할 일은 원문을 확인한 뒤 캘린더에 저장하세요.',
        ),
        const SizedBox(height: 12),
        Text(
          '오늘 이 앱에서 보낸 분석 요청: $requests회 (한국 날짜 기준, 실패 포함)\nGoogle 프로젝트 전체 사용량·잔여량과는 다릅니다.',
        ),
        if (message != null)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(message!),
          ),
        FilledButton(onPressed: busy ? null : save, child: const Text('저장')),
        if (saved)
          TextButton(
            onPressed: busy ? null : () => save(remove: true),
            child: const Text('키 삭제·AI 사용 중지'),
          ),
        if (!busy) AutomationControls(key: ValueKey(saved)),
        const SizedBox(height: 12),
        const SelectableText(
          '키 발급·무료 등급 확인: https://aistudio.google.com/api-keys\n사용량 한도 확인: https://aistudio.google.com/rate-limit',
        ),
      ],
    ),
  );
}

class CalendarSettingsPage extends StatefulWidget {
  const CalendarSettingsPage({super.key});
  @override
  State<CalendarSettingsPage> createState() => _CalendarSettingsState();
}

class _CalendarSettingsState extends State<CalendarSettingsPage> {
  List<Map<String, dynamic>> calendars = [];
  int? selected;
  bool auto = false, busy = true;
  String? message;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load({bool request = false}) async {
    setState(() => busy = true);
    try {
      if (request &&
          await bridge.invokeMethod<bool>('calendarPermission') != true) {
        throw const AiFailure('캘린더 권한을 허용해야 전송할 수 있습니다.');
      }
      final settings =
          await bridge.invokeMapMethod<String, dynamic>('calendarSettings') ??
          {};
      final allowed = settings['allowed'] == true;
      final data = allowed
          ? await bridge.invokeListMethod<dynamic>('calendarList') ?? []
          : [];
      if (mounted) {
        setState(() {
          calendars = data
              .map((c) => Map<String, dynamic>.from(c as Map))
              .toList();
          final id = settings['calendarId'] as int?;
          selected = calendars.any((c) => c['id'] == id) ? id : null;
          auto = settings['auto'] == true;
          message = allowed
              ? (calendars.isEmpty
                    ? '저장할 수 있는 캘린더가 없습니다. 캘린더 앱에서 계정을 먼저 연결해 주세요.'
                    : null)
              : '캘린더 권한을 허용하고 저장할 캘린더를 선택하세요.';
        });
      }
    } catch (e) {
      if (mounted) setState(() => message = userError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> save() async {
    if (selected == null) {
      setState(() => message = '저장할 캘린더를 선택해 주세요.');
      return;
    }
    setState(() => busy = true);
    try {
      await bridge.invokeMethod('calendarConfigure', {
        'calendarId': selected,
        'auto': auto,
      });
      await systemLog(
        '캘린더 설정 저장',
        auto ? '미완료·공개·시작된 항목의 앞으로 남은 마감 자동 전송 켜짐' : '자동 전송 꺼짐 · 개별 전송 가능',
      );
      await bridge.invokeMethod('calendarSync');
      if (mounted) setState(() => message = '저장했습니다. 결과는 캘린더와 수집 로그에서 확인하세요.');
    } catch (e) {
      if (mounted) setState(() => message = userError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> unlink() async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('캘린더 연결을 해제할까요?'),
        content: const Text(
          '자동 전송과 기존 일정 갱신을 중지합니다. 캘린더에 저장한 일정은 삭제하지 않습니다. 다시 연결해 자동 전송하면 기존 일정과 중복될 수 있습니다.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('연결 해제'),
          ),
        ],
      ),
    );
    if (yes != true) return;
    await bridge.invokeMethod('calendarUnlink');
    await load();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('캘린더 전송 설정')),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        const Text(
          '삼성·Google 캘린더 등 기기에 연결된 캘린더에 저장합니다. 계정 캘린더를 선택하면 해당 계정의 동기화 설정에 따라 일정이 서버로 동기화될 수 있습니다.',
        ),
        const SizedBox(height: 12),
        FilledButton.tonal(
          onPressed: busy ? null : () => load(request: true),
          child: const Text('캘린더 권한 허용·목록 새로고침'),
        ),
        RadioGroup<int>(
          groupValue: selected,
          onChanged: (v) {
            if (!busy) setState(() => selected = v);
          },
          child: Column(
            children: calendars
                .map(
                  (c) => RadioListTile<int>(
                    value: c['id'] as int,
                    title: Text(c['name'] as String),
                    subtitle: Text(c['account'] as String),
                    enabled: !busy,
                  ),
                )
                .toList(),
          ),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('과제·콘텐츠 마감 자동 전송'),
          subtitle: const Text(
            '새로 수집한 미완료 항목 중 공개·시작된 미래 마감만 추가합니다. 연결된 항목은 이후 수집 시 기한·제목·완료 상태를 갱신합니다.',
          ),
          value: auto,
          onChanged: busy ? null : (v) => setState(() => auto = v),
        ),
        const Text(
          'AI 일정은 원문 확인 후 개별 저장합니다. 목록 제외·로그아웃·연결 해제는 이미 저장한 캘린더 일정을 삭제하지 않습니다. 캘린더에서 직접 지운 연결 일정은 자동으로 다시 만들지 않습니다. 캘린더 알림은 추가하지 않으며 기존 앱 알림을 유지합니다.',
        ),
        if (message != null)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(message!),
          ),
        FilledButton(
          onPressed: busy ? null : save,
          child: const Text('설정 저장·지금 동기화'),
        ),
        TextButton(
          onPressed: busy ? null : unlink,
          child: const Text('기존 연결 해제'),
        ),
      ],
    ),
  );
}

class CalendarDraftPage extends StatefulWidget {
  final String itemKey, title, description;
  final DateTime? start;
  final bool allDay, deadline;
  const CalendarDraftPage({
    super.key,
    required this.itemKey,
    required this.title,
    required this.description,
    this.start,
    this.allDay = false,
    this.deadline = false,
  });
  @override
  State<CalendarDraftPage> createState() => _CalendarDraftState();
}

class _CalendarDraftState extends State<CalendarDraftPage> {
  late final TextEditingController title = TextEditingController(
    text: widget.title,
  );
  late DateTime? day = widget.start == null
      ? null
      : widget.allDay
      ? widget.start!.toUtc()
      : widget.start!.toUtc().add(const Duration(hours: 9));
  late TimeOfDay time = day == null
      ? const TimeOfDay(hour: 9, minute: 0)
      : TimeOfDay(hour: day!.hour, minute: day!.minute);
  late bool allDay = widget.allDay;
  bool busy = false;
  String? message;
  Future<void> save({bool calendar = true}) async {
    if (day == null || title.text.trim().isEmpty) {
      setState(() => message = '제목과 날짜를 확인해 주세요.');
      return;
    }
    setState(() => busy = true);
    try {
      if (calendar) {
        final granted = await bridge.invokeMethod<bool>('calendarPermission');
        if (granted != true) throw const AiFailure('캘린더 권한이 필요합니다.');
      }
      final start = allDay
          ? DateTime.utc(day!.year, day!.month, day!.day)
          : DateTime.utc(
              day!.year,
              day!.month,
              day!.day,
              time.hour,
              time.minute,
            ).subtract(const Duration(hours: 9));
      final window = calendarWindow(
        start,
        allDay: allDay,
        deadline: widget.deadline,
      );
      if (calendar) {
        await bridge.invokeMethod('calendarWrite', {
          'key': widget.itemKey,
          'title': title.text.trim(),
          'start': window.$1.millisecondsSinceEpoch,
          'end': window.$2.millisecondsSinceEpoch,
          'allDay': allDay,
          'description': widget.description,
        });
      }
      if (widget.itemKey.startsWith('AI:')) {
        final s = await Store.open();
        try {
          final old =
              jsonDecode(await s.meta('aiState:${widget.itemKey}') ?? '{}')
                  as Map;
          final unchanged =
              old['start'] == start.toIso8601String() &&
              old['title'] == title.text.trim() &&
              old['allDay'] == allDay;
          await s.setMeta(
            'aiState:${widget.itemKey}',
            jsonEncode({
              ...old,
              'status': 'confirmed',
              'title': title.text.trim(),
              'start': start.toIso8601String(),
              'date': dateText(day!),
              'allDay': allDay,
              'calendarSent':
                  calendar || unchanged && old['calendarSent'] == true,
            }),
          );
          await s.log(
            'ai',
            'AI 일정 확정',
            calendar ? '확인한 일정을 캘린더에 전송했습니다.' : '앱 일정함에 확정했습니다.',
          );
        } finally {
          await s.db.close();
        }
      }
      if (mounted) {
        setState(
          () => message = calendar
              ? '캘린더에 저장했습니다. 같은 항목을 다시 저장하면 연결 일정을 갱신합니다.'
              : '일정함에 확정했습니다. 캘린더에는 전송하지 않았습니다.',
        );
      }
    } catch (e) {
      if (mounted) setState(() => message = userError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    title.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('캘린더 일정 확인')),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        TextField(
          controller: title,
          decoration: const InputDecoration(labelText: '일정 제목'),
        ),
        const SizedBox(height: 16),
        Text(day == null ? '날짜를 선택해 주세요.' : dateText(day!)),
        TextButton(
          onPressed: busy
              ? null
              : () async {
                  final d = await showDatePicker(
                    context: context,
                    initialDate: day ?? DateTime.now(),
                    firstDate: DateTime(2000),
                    lastDate: DateTime(2100),
                  );
                  if (d != null && mounted) setState(() => day = d);
                },
          child: const Text('날짜 선택'),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          value: allDay,
          onChanged: busy ? null : (v) => setState(() => allDay = v),
          title: const Text('종일 일정'),
        ),
        if (!allDay)
          TextButton(
            onPressed: busy
                ? null
                : () async {
                    final t = await showTimePicker(
                      context: context,
                      initialTime: time,
                    );
                    if (t != null && mounted) setState(() => time = t);
                  },
            child: Text(
              '한국 시간 ${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')} · 변경',
            ),
          ),
        Text(
          widget.deadline
              ? '선택 시각을 마감으로 하여 당일 최대 10분 전부터 표시합니다. 23:59 마감은 23:49–23:59입니다. 정각 00:00 마감은 전날 마지막 10분으로 표시합니다.'
              : '시각이 있는 일정은 10분 길이로 표시합니다. 제목·날짜·한국 시간을 확인하세요. 과제·콘텐츠로 연결한 일정은 이후 수집한 원래 마감·제목으로 갱신됩니다. AI 일정은 수동 확인한 값을 유지합니다.',
        ),
        const SizedBox(height: 16),
        SelectableText(widget.description),
        if (message != null)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(message!),
          ),
        FilledButton(
          onPressed: busy ? null : () => save(),
          child: const Text('확인·캘린더 저장'),
        ),
        if (widget.itemKey.startsWith('AI:'))
          FilledButton.tonal(
            onPressed: busy ? null : () => save(calendar: false),
            child: const Text('일정함에만 확정'),
          ),
        TextButton(
          onPressed: busy
              ? null
              : () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const CalendarSettingsPage(),
                  ),
                ),
          child: const Text('저장할 캘린더 설정'),
        ),
      ],
    ),
  );
}

class NoticeAnalysisPage extends StatefulWidget {
  final CampusNotice notice;
  const NoticeAnalysisPage({super.key, required this.notice});
  @override
  State<NoticeAnalysisPage> createState() => _NoticeAnalysisState();
}

class _NoticeAnalysisState extends State<NoticeAnalysisPage> {
  List<ScheduleCandidate>? events;
  bool busy = false;
  String? error;
  Future<void> analyze() async {
    setState(() {
      busy = true;
      error = null;
      events = null;
    });
    try {
      final result = await NoticeAi.analyze(widget.notice);
      if (mounted) setState(() => events = result);
    } catch (e) {
      if (mounted) setState(() => error = userError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('AI 일정 후보')),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Text(
          widget.notice.title,
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        const Text(
          '분석하면 이 공지의 텍스트를 Gemini에 보냅니다. 결과는 후보이며 원문을 확인해야 합니다. 같은 본문은 저장한 결과를 사용합니다.',
        ),
        FilledButton(
          onPressed: busy ? null : analyze,
          child: Text(busy ? '분석 중…' : '공지 분석·저장 결과 보기'),
        ),
        TextButton(
          onPressed: busy
              ? null
              : () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AiSettingsPage()),
                ),
          child: const Text('개인 키·외부 전송 설정'),
        ),
        if (busy) const LinearProgressIndicator(),
        if (error != null) Text(error!),
        if (events?.isEmpty == true)
          const Text('추출된 일정이 없습니다. 이미지·첨부와 원문을 확인하세요.'),
        ...?events?.map(
          (c) => Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    c.title,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text(
                    '${c.action == "cancel"
                        ? "취소"
                        : c.action == "change"
                        ? "변경 — 기존 일정 확인 필요"
                        : "새 일정"} · ${c.date.isEmpty ? "날짜 확인 필요" : c.date} ${c.time.isEmpty ? "시각 미지정" : c.time}',
                  ),
                  const SizedBox(height: 8),
                  SelectableText('근거: ${c.evidence}'),
                  if (c.uncertainty.isNotEmpty) Text('확인할 점: ${c.uncertainty}'),
                  if (c.action != 'add')
                    const Text(
                      '변경·취소는 이전에 저장한 일정과 연결을 확인한 후 캘린더에서 직접 반영하세요. 새 일정으로 자동 추가하지 않습니다.',
                    ),
                  if (c.action == 'add')
                    TextButton(
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => CalendarDraftPage(
                            itemKey: candidateKey(widget.notice, c),
                            title: '[${widget.notice.course}] ${c.title}',
                            description:
                                'AI 후보를 사용자가 확인한 일정\n근거: ${c.evidence}\n${c.uncertainty}\n공지: ${widget.notice.title}\nhttps://dcs-learning.cnu.ac.kr/home',
                            start: c.date.isEmpty
                                ? null
                                : c.time.isEmpty
                                ? strictDate(c.date)
                                : DateTime.parse(
                                    '${c.date}T${c.time}:00+09:00',
                                  ),
                            allDay: c.time.isEmpty,
                          ),
                        ),
                      ),
                      child: const Text('날짜 확인·캘린더 추가'),
                    ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 24),
        const Text('공지 원문', style: TextStyle(fontWeight: FontWeight.bold)),
        SelectableText(widget.notice.body),
      ],
    ),
  );
}

(DateTime, DateTime) calendarWindow(
  DateTime anchor, {
  bool allDay = false,
  bool deadline = false,
}) {
  if (allDay) return (anchor, anchor.add(const Duration(days: 1)));
  if (!deadline) return (anchor, anchor.add(const Duration(minutes: 10)));
  final k = anchor.toUtc().add(const Duration(hours: 9));
  final midnight = DateTime.utc(
    k.year,
    k.month,
    k.day,
  ).subtract(const Duration(hours: 9));
  final before = anchor.subtract(const Duration(minutes: 10));
  return (
    anchor.isAtSameMomentAs(midnight)
        ? before
        : (before.isBefore(midnight) ? midnight : before),
    anchor,
  );
}

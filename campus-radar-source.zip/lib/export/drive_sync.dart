import 'package:campus_radar/core/size_limits.dart';
import 'package:flutter/foundation.dart' show debugPrint, visibleForTesting;
import 'dart:async';
import 'package:campus_radar/export/drive_preparation_queue.dart';
import 'dart:convert';
import 'dart:io';
import 'package:sqflite/sqflite.dart';
import 'package:flutter/services.dart';
import 'package:campus_radar/campus/academic_attachment.dart';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/campus/campus_session.dart';
import 'package:campus_radar/campus/freeboard_service.dart';
import 'package:campus_radar/campus/freeboard_models.dart';
import 'package:campus_radar/campus/campus_media.dart';
import 'package:campus_radar/campus/material_catalog.dart';
import 'package:campus_radar/campus/media_cache.dart';
import 'package:crypto/crypto.dart';
import 'package:path_provider/path_provider.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/demo_state.dart';
import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/export/academic_export.dart';
import 'package:campus_radar/export/drive_uploader.dart';
import 'package:campus_radar/courses/course_catalog.dart';
import 'package:campus_radar/export/app_snapshot.dart';
import 'package:campus_radar/schedule/timetable_share.dart';

String driveAccountHash(String account) =>
    sha256.convert(utf8.encode(account)).toString();

/// Verify persisted scope before preparing an export, rather than treating a
/// successful platform call as proof that the chosen scope was saved.
Future<void> saveDriveTargetOptions({required String id, required bool enabled,
    required String accountHash, required Map<String, dynamic> options}) async {
  final freeboard = options['freeboard'] == true;
  await systemLog('Drive 전송 범위 저장 요청',
      '자동 전송: $enabled · 자유게시판 포함: $freeboard', kind: 'app');
  await bridge.invokeNative(NativeMethod.driveConfigure, {
    'id': id, 'enabled': enabled, 'accountHash': accountHash, 'options': options,
  });
  final rows = await bridge.invokeNativeList<dynamic>(NativeMethod.driveAccounts);
  Map? saved;
  for (final row in rows ?? const []) {
    if (row is Map && '${row['id']}' == id) saved = row;
  }
  final raw = saved?['options'];
  final persisted = raw is String ? jsonDecode(raw) : raw;
  if (saved?['enabled'] != enabled || persisted is! Map ||
      !persisted.containsKey('freeboard') || persisted['freeboard'] != freeboard) {
    await systemLog('Drive 전송 범위 저장 확인 실패',
        '자유게시판 포함 요청: $freeboard · 저장된 옵션이 일치하지 않아 새 자료 준비를 중단해요.', kind: 'app');
    throw const FormatException('전송 범위가 저장된 것을 확인하지 못했어요. 설정을 다시 열어 확인해 주세요.');
  }
  await systemLog('Drive 전송 범위 저장 완료',
      '자동 전송: $enabled · 자유게시판 포함: $freeboard · 저장값 재조회 확인', kind: 'app');
}

Map<String, dynamic> driveEnqueueArguments({required bool manual}) => {
  'manual': manual,
};

/// Stable fingerprint excludes export time so opening a screen cannot reupload
/// otherwise identical academic data. Collection time stays visible and current.
String driveDocumentRevision(Map<String, String> documents) {
  final sorted = documents.keys.toList()..sort();
  final normalized = <String, String>{};
  for (final k in sorted) {
    var text = documents[k]!;
    if (k == '캠퍼스레이더 시작.txt') {
      final n = text.indexOf('\n');
      if (n >= 0) {
        final index = jsonDecode(text.substring(n + 1)) as Map;
        index.remove('exportedAt');
        text = jsonEncode(index);
      }
    } else if (k == '학업 현황.txt') {
      text = text.replaceAll(RegExp(r'내보냄: [^\n]*'), '내보냄: [갱신 시각]');
    }
    normalized[k] = text;
  }
  return sha256.convert(utf8.encode(jsonEncode(normalized))).toString();
}

Map<String, String> automaticDriveDocuments(
  Map<String, String> source, {
  String? appSnapshot,
}) {
  final documents = Map<String, String>.of(source);
  const path = '캠퍼스레이더 시작.txt';
  final text = documents[path]!;
  final index = Map<String, dynamic>.from(
    jsonDecode(text.substring(text.indexOf('\n') + 1)) as Map,
  );
  index['refresh'] = '앱의 자동 내보내기 · 수집/내보낸 시각을 확인하세요';
  index['warnings'] = [
    for (final warning in (index['warnings'] as List? ?? const []))
      if (warning != '실시간 연결이 아니에요. 새로 내보내고 저장소 파일을 교체해야 갱신돼요.') warning,
    '자동 갱신은 기기 실행·네트워크 상태에 따라 늦어질 수 있어요. 수집 시각을 확인하세요.',
  ];
  if (appSnapshot != null) {
    // Written before the start file (uploaders keep it last), so a reader that
    // sees this digest can tell a finished upload from one still in progress.
    documents[appSnapshotPath] = appSnapshot;
    index['appSnapshot'] = {
      'path': appSnapshotPath,
      'schema': appSnapshotSchema,
      'sha256': appSnapshotDigest(appSnapshot),
    };
  }
  documents[path] =
      'CAMPUS_RADAR_START_V1\n${const JsonEncoder.withIndent('  ').convert(index)}';
  return documents;
}

bool driveTargetMatches(Map target, String accountHash) =>
    target['enabled'] == true &&
    target['accountHash'] == accountHash &&
    target['binding'] is String &&
    (target['binding'] as String).isNotEmpty;

Future<int> downloadDriveOriginals({
  required Store store,
  required MediaCache cache,
  Set<String>? selectedCourses,
  CampusClient? client,
  Future<File> Function(CampusClient client, CampusMedia media)? fetcher,
  int maxNewDownloads = 1 << 30,
  int? maxTotalBytes,
  int? maxSingleFileBytes,
}) async {
  // Default: download every missing original (no size limit unless the user set one).
  final totalCapBytes = maxTotalBytes ?? await SizeLimits.driveTotalBytes() ?? (1 << 52);
  final fileCapBytes = maxSingleFileBytes ?? await SizeLimits.driveFileBytes() ?? MediaCache.hardDownloadCeiling;
  final effectiveClient = client ?? CampusClient();
  var downloadedCount = 0;
  var totalBytes = 0;
  try {
    final materials = await studyMaterials(store);
    for (final material in materials) {
      if (downloadedCount >= maxNewDownloads || totalBytes >= totalCapBytes) {
        break;
      }
      final media = material.media;
      if (media == null) continue;
      if (selectedCourses != null &&
          selectedCourses.isNotEmpty &&
          !selectedCourses.contains(material.course)) {
        continue;
      }
      if (media.form.isNotEmpty ||
          !media.url.startsWith('https://dcs-learning.cnu.ac.kr/file/')) {
        continue;
      }
      final existing = await cache.local(media);
      if (existing != null) continue;
      final remainingBytes = totalCapBytes - totalBytes;
      if (remainingBytes <= 0) break;
      final fileLimit = remainingBytes < fileCapBytes
          ? remainingBytes
          : fileCapBytes;
      if (media.size != null && media.size! > fileCapBytes) continue;
      if (media.size != null && totalBytes + media.size! > totalCapBytes) {
        continue;
      }
      try {
        final file = await (fetcher != null
            ? fetcher(effectiveClient, media)
            : cache.fetch(effectiveClient, media, maxBytes: fileLimit));
        final len = await file.length();
        if (len > fileCapBytes || totalBytes + len > totalCapBytes) {
          debugPrint(
            'Drive prepare: file ${media.name} ($len bytes) exceeded download budget',
          );
          continue;
        }
        totalBytes += len;
        downloadedCount++;
      } catch (e) {
        debugPrint(
          'Drive prepare: download original failed for ${media.name}: $e',
        );
      }
    }
  } finally {
    if (client == null) {
      effectiveClient.close();
    }
  }
  return downloadedCount;
}

Future<Map<String, Map<String, dynamic>>> buildDriveFilesPayload({
  required Store store,
  required MediaCache cache,
  Set<String>? selectedCourses,
  Map<String, DriveAttachmentPath>? attachmentPaths,
  int? maxSingleFileBytes,
  int? maxTotalBytes,
  bool includeMaterials = true,
  bool includeFreeboard = false,
  Map<String, String>? freeboardStatuses,
}) async {
  // Default: no limit; users can set one in the Drive scope settings.
  final fileCap = maxSingleFileBytes ?? await SizeLimits.driveFileBytes() ?? (1 << 52);
  final totalCap = maxTotalBytes ?? await SizeLimits.driveTotalBytes() ?? (1 << 52);
  final result = <String, Map<String, dynamic>>{};
  var totalBytes = 0;
  final materials = await studyMaterials(store);
  final paths = attachmentPaths ?? resolveDriveAttachmentPaths(materials);
  for (final material in materials) {
    if (!includeMaterials) break;
    final media = material.media;
    if (media == null) continue;
    if (selectedCourses != null &&
        selectedCourses.isNotEmpty &&
        !selectedCourses.contains(material.course)) {
      continue;
    }
    final local = await cache.local(media);
    if (local == null || !await local.exists()) continue;
    final stat = await local.stat();
    if (stat.size > fileCap) continue;
    if (totalBytes + stat.size > totalCap) continue;
    final pathInfo = paths[material.id];
    final driveKey = pathInfo?.driveKey ??
        '자료/${safeCourseFolderName(material.course)}/${safeAttachmentFileName(media.name)}';
    if (result.containsKey(driveKey)) continue;
    final digest = (await sha256.bind(local.openRead()).first).toString();
    final mime = await cache.mime(media);
    final crKey = DriveSyncLogic.attachmentKey(
      course: material.course,
      fileName: media.name,
      attachmentId: material.id,
    );
    result[driveKey] = {
      'path': local.path,
      'sha256': digest,
      'bytes': stat.size,
      'mime': mime,
      'attachmentId': material.id,
      'crKey': crKey,
    };
    totalBytes += stat.size;
  }
  if (includeFreeboard) {
    final byCrKey = <String, String>{};
    final courses = <String, String>{
      for (final material in materials)
        if (paths[material.id] != null) material.course: paths[material.id]!.safeCourse,
    };
    final usedCourses = courses.values.toSet();
    for (final post in await store.freeboardPosts()) {
      if (selectedCourses != null && selectedCourses.isNotEmpty &&
          !selectedCourses.contains(post.course)) {
        continue;
      }
      final safeCourse = courses.putIfAbsent(post.course,
          () => safeCourseFolderName(post.course, usedCourses));
      for (final media in post.media) {
        final id = freeboardAttachmentId(post.courseKey, media);
        final local = await cache.local(media);
        if (local == null || !await local.exists()) {
          freeboardStatuses?[id] = 'Drive 원본 없음 (기기에 받은 첨부가 없어요)';
          continue;
        }
        final size = await local.length();
        if (size > fileCap) {
          freeboardStatuses?[id] = 'Drive 원본 없음 (파일당 ${SizeLimits.label(fileCap)} 한도 초과)';
          continue;
        }
        final digest = (await sha256.bind(local.openRead()).first).toString();
        final crKey = 'att:freeboard:${sha256.convert(utf8.encode('${post.courseKey}|$digest'))}';
        final existing = byCrKey[crKey];
        if (existing != null) {
          freeboardStatuses?[id] = 'Drive 원본 전송 대상: $existing';
          continue;
        }
        if (totalBytes + size > totalCap) {
          freeboardStatuses?[id] = 'Drive 원본 없음 (일반 첨부와 합산한 총 ${SizeLimits.label(totalCap)} 한도 초과)';
          continue;
        }
        var name = safeAttachmentFileName(media.name);
        var key = '자료/$safeCourse/자유게시판/$name';
        var duplicate = 0;
        while (result.containsKey(key)) {
          name = safeAttachmentFileName('${digest.substring(0, 12)}_${++duplicate}_${media.name}');
          key = '자료/$safeCourse/자유게시판/$name';
        }
        result[key] = {
          'path': local.path, 'sha256': digest, 'bytes': size,
          'mime': await cache.mime(media), 'attachmentId': id,
          'crKey': crKey, 'section': 'freeboard',
        };
        byCrKey[crKey] = key;
        totalBytes += size;
        freeboardStatuses?[id] = 'Drive 원본 전송 대상: $key';
      }
    }
  }
  return result;
}

final _preparationQueue = DrivePreparationQueue();
Future<void> prepareDriveSnapshot({bool manual = false}) async {
  if (isDemoActive || (!Platform.isAndroid && !Platform.isIOS)) return;
  await _preparationQueue.run(
    manual: manual,
    prepare: () async {
      await _prepare(manual: manual);
      _lastLoggedFailure = null;
    },
  );
}

@visibleForTesting
Future<void> prepareDriveSnapshotForTesting({bool manual = false}) =>
    _prepare(manual: manual);

@visibleForTesting
Set<String> collectReferencedZipNames(dynamic root) {
  final names = <String>{};
  if (root is! Map) return names;
  final accounts = root['accounts'];
  if (accounts is Map) {
    for (final a in accounts.values) {
      if (a is Map) {
        final docs = a['documents'];
        if (docs is Map) {
          final ref = docs['캠퍼스레이더 첨부원본.zip'];
          if (ref is String && ref.startsWith('file://')) {
            final seg = ref.split(RegExp(r'[/\\]')).last;
            if (seg.isNotEmpty) names.add(seg);
          }
        }
      }
    }
  }
  return names;
}

@visibleForTesting
void cleanupOldDriveZipFiles({
  required Directory folder,
  required String hash,
  required Set<String> activeZipNames,
  Duration maxAge = const Duration(minutes: 15),
  DateTime? now,
}) {
  final currentTime = now ?? DateTime.now();
  for (final entity in folder.listSync()) {
    if (entity is File) {
      final name = entity.uri.pathSegments.last;
      if (name.startsWith('drive-zip-$hash-') &&
          name.endsWith('.zip') &&
          !activeZipNames.contains(name)) {
        try {
          final stat = entity.statSync();
          if (currentTime.difference(stat.modified) > maxAge) {
            entity.deleteSync();
          }
        } catch (_) {}
      }
    }
  }
}

String driveLeaseMessage(Map held, {DateTime? now}) {
  final remaining =
      (((held['until'] as num? ?? 0).toInt() -
                  (now ?? DateTime.now()).millisecondsSinceEpoch) /
              1000)
          .ceil()
          .clamp(0, 600);
  return '${held['label'] ?? '이전 전송 자료 준비'} 작업이 진행 중이에요. 잠금은 최대 $remaining초 후 풀려요. 앱 프로세스가 다시 시작되면 남은 잠금을 정리해요.';
}

String? _lastLoggedFailure;

/// Background preparation runs on every list reload, so each distinct cause
/// is logged once until a preparation succeeds again.
Future<void> logDrivePrepareFailure(Object e) async {
  final cause = failureCause(e);
  if (cause == _lastLoggedFailure) return;
  _lastLoggedFailure = cause;
  await systemLog(
    'Drive 내보내기 준비 실패',
    '앱은 그대로 쓸 수 있어요. Drive 연결 화면에서 다시 전송해 보세요.',
    kind: 'app',
    error: e,
  );
}

Future<void> _prepare({required bool manual}) async {
  final folder = await getApplicationSupportDirectory();
  final targetsFile = File('${folder.path}/drive-targets-v1.json');
  if (!await targetsFile.exists()) {
    if (manual) {
      throw const FormatException('Google 계정 연결 정보를 찾지 못했어요. 계정을 다시 연결해 주세요.');
    }
    return;
  }
  final targets = jsonDecode(await targetsFile.readAsString()) as Map;
  final account = await credentials.read(key: 'id');
  if (account == null) {
    if (manual) throw const FormatException('학교 계정을 먼저 연결해 주세요.');
    return;
  }
  final hash = driveAccountHash(account);
  if (!targets.values.any((r) => r is Map && driveTargetMatches(r, hash))) {
    if (manual) {
      throw const FormatException(
        '현재 학교 계정에 자동 전송이 켜진 Google 계정이 없어요. 전송 범위·설정에서 켜 주세요.',
      );
    }
    return;
  }
  final store = await Store.open();
  // The app reloads every minute and on every resume; each reload used to
  // rebuild the whole export (build 79: 12 s). Without a new collection or a
  // settings change, an automatic preparation within 30 minutes is skipped.
  final inputs = drivePreparationInputs(
    lastSuccess: await store.meta(MetaKey.lastSuccess),
    accountHash: hash,
    targets: targets,
  );
  if (!manual) {
    try {
      final prepared =
          jsonDecode(await store.meta(MetaKey.drivePreparedInput) ?? '{}')
              as Map;
      final at = DateTime.tryParse('${prepared['at']}');
      if (prepared['inputs'] == inputs &&
          at != null &&
          DateTime.now().toUtc().difference(at) < const Duration(minutes: 30) &&
          await File('${folder.path}/drive-export-v1.json').exists()) {
        debugPrint('CampusRadar Drive prepare: reused');
        await store.db.close();
        return;
      }
    } catch (_) {
      // An unreadable marker only means preparing again.
    }
  }
  final owner = newShareId();
  Map? heldLease;
  // A manual request waits briefly for an automatic preparation to finish
  // instead of failing at once (device test build 75, 13:19).
  final waitUntil = DateTime.now().add(
    manual ? const Duration(seconds: 45) : Duration.zero,
  );
  Future<bool> tryAcquire() => store.db.transaction((txn) async {
    final rows = await txn.query(
      'meta',
      where: 'id=?',
      whereArgs: [MetaKey.drivePrepareLease],
    );
    if (rows.isNotEmpty) {
      final held = jsonDecode(rows.single['value'] as String) as Map;
      if ((held['until'] as int) > DateTime.now().millisecondsSinceEpoch) {
        heldLease = held;
        return false;
      }
    }
    await txn.insert('meta', {
      'id': MetaKey.drivePrepareLease,
      'value': jsonEncode({
        'owner': owner,
        'label': manual ? '수동 전송 자료 준비' : '자동 전송 자료 준비',
        'until': DateTime.now().millisecondsSinceEpoch + 600000,
      }),
    }, conflictAlgorithm: ConflictAlgorithm.replace);
    return true;
  });
  var acquired = await tryAcquire();
  while (!acquired && DateTime.now().isBefore(waitUntil)) {
    await Future<void>.delayed(const Duration(seconds: 3));
    heldLease = null;
    acquired = await tryAcquire();
  }
  if (!acquired) {
    await store.db.close();
    if (manual) throw FormatException(driveLeaseMessage(heldLease ?? const {}));
    return;
  }
  try {
    final scope = await SessionScope.capture(store);
    await scope.verify();
    final collectedAt = await store.meta(MetaKey.lastSuccess);
    if ((collectedAt ?? '').isEmpty) {
      if (manual) throw const FormatException('학교 자료를 한 번 수집한 뒤 전송해 주세요.');
      return;
    }
    final courses = await readCourses(store);
    final course = courses.firstOrNull;
    final year = course?['term_year']?.toString();
    final code = course?['term_cd']?.toString();
    if (year == null || year.isEmpty || code == null || code.isEmpty) {
      if (manual) throw const FormatException('수강 학기를 확인한 뒤 전송해 주세요.');
      return;
    }
    final term = '$year-$code';
    var profile = await store.meta(MetaKey.academicExportProfile);
    if (profile == null) {
      profile = newShareId();
      await store.setMeta(MetaKey.academicExportProfile, profile);
    }
    final payloads = <String, dynamic>{};
    final textCacheFile = File('${folder.path}/drive-texts-$hash.json');
    Map<String, dynamic> cachedTexts = {};
    try {
      if (await textCacheFile.exists()) {
        cachedTexts = Map<String, dynamic>.from(
          jsonDecode(await textCacheFile.readAsString()) as Map,
        );
      }
    } catch (_) {
      /* Rebuild damaged optional text cache. */
    }
    final retainedTexts = <String, dynamic>{};
    final allMaterials = await studyMaterials(store);
    // The same form posted under several assignments has different download
    // URLs, so media identity alone gave it "name (2)", "(3)"... Identify cached
    // originals by content so one file keeps one name.
    final contentHashes = <String, String>{};
    if (scope.account != null) {
      try {
        final cache = await MediaCache.open(scope.account!);
        for (final m in allMaterials) {
          final media = m.media;
          if (media == null) continue;
          final local = await cache.local(media);
          if (local == null || !await local.exists()) continue;
          contentHashes[m.id] =
              (await sha256.bind(local.openRead()).first).toString();
        }
      } catch (_) {
        /* Fall back to media identity. */
      }
    }
    final paths = resolveDriveAttachmentPaths(allMaterials, contentHashes: contentHashes);
    final zipCache = <String, ({String ref, Set<String> entries})>{};
    final previousFile = File('${folder.path}/drive-export-v1.json');
    Map? previous;
    try {
      if (await previousFile.exists()) {
        previous = jsonDecode(await previousFile.readAsString()) as Map;
      }
    } catch (_) {
      /* Replace corrupt local snapshot; don't upload it. */
    }
    final preparedFreeboardCourses = <String>{};
    for (final entry in targets.entries) {
      final target = entry.value as Map;
      if (!driveTargetMatches(target, hash)) continue;
      final options = (target['options'] as Map?) ?? const {};
      final selected = (options['courses'] as List?)?.cast<String>();
      if (manual || options['freeboard'] == true) {
        final savedPosts = await store.freeboardPosts();
        final matched = savedPosts.where((p) => selected == null ||
            selected.isEmpty || selected.contains(p.course)).length;
        await store.log('app', '자유게시판 Drive 준비 범위',
            '옵션 키: ${options.containsKey('freeboard') ? '있음' : '없음(기본 제외)'} · 포함: ${options['freeboard'] == true}\n저장 글: ${savedPosts.length}개 · 선택 과목과 일치: $matched개\n본문 미수집 글도 안내 문서에 포함해요.');
      }
      if (options['freeboard'] == true && scope.account != null) {
        final courses = (await readCourses(store)).where((c) =>
            (selected == null || selected.isEmpty || selected.contains('${c['course_nm']}')) &&
            !preparedFreeboardCourses.contains(courseKey(c))).toList();
        if (courses.isNotEmpty) {
          final client = CampusClient();
          try {
            // Export must never displace another device with a new school login.
            await client.connectSchool(scope.account!, '', allowFreshLogin: false);
            final completed = await FreeboardService.prepareExportBodies(store, client, courses,
                verifyScope: scope.verify, cache: await MediaCache.open(scope.account!));
            preparedFreeboardCourses.addAll(completed);
          } catch (e) {
            await store.log('sync', '자유게시판 Drive 준비 일부 실패',
                withCause('기존 저장 글을 보내며, 받지 못한 본문은 미수집으로 표시해요. 새 로그인은 하지 않아요.', e));
          } finally {
            client.close();
          }
        }
      }
      if (options['materials'] != false && scope.account != null) {
        final cache = await MediaCache.open(scope.account!);
        final client = CampusClient();
        try {
          await downloadDriveOriginals(
            store: store,
            cache: cache,
            selectedCourses: selected == null || selected.isEmpty
                ? null
                : selected.toSet(),
            client: client,
          );
        } catch (e) {
          debugPrint('Drive prepare: download originals step error: $e');
        } finally {
          client.close();
        }
      }
      final texts = <String, AttachmentText>{};
      if (options['texts'] == true &&
          options['materials'] != false &&
          scope.account != null) {
        final cache = await MediaCache.open(scope.account!);
        final extracted = <String, AttachmentText>{};
        var extractedNow = false;
        for (final material in await studyMaterials(store)) {
          if (material.media == null ||
              selected != null &&
                  selected.isNotEmpty &&
                  !selected.contains(material.course)) {
            continue;
          }
          final local = await cache.local(material.media!);
          if (local == null) continue;
          var text = extracted[local.path];
          final stat = await local.stat();
          final textKey = sha256
              .convert(
                utf8.encode(
                  '${local.path}|${stat.size}|${stat.modified.toUtc().toIso8601String()}|${material.name.split('.').last.toLowerCase()}',
                ),
              )
              .toString();
          final cached = cachedTexts[textKey];
          if (text == null && cached is Map && extracted.length < 10) {
            text = AttachmentText(
              '${cached['text']}',
              '${cached['note']}',
              partial: cached['partial'] == true,
            );
            extracted[local.path] = text;
          }
          var failedNow = false;
          if (text == null && extracted.length < 10) {
            await scope.verify();
            extractedNow = true;
            try {
              text = await extractAttachmentText(local, material.name);
            } catch (_) {
              failedNow = true;
              text = const AttachmentText(
                '',
                '현재 작업에서 추출하지 못했어요. 앱에서 다시 전송해 주세요.',
              );
            }
            extracted[local.path] = text;
          }
          if (text != null) {
            texts[material.id] = text;
            // Files with no extractable text (scans, unsupported formats) are
            // remembered too; only a thrown error is retried next time.
            if (!failedNow) {
              retainedTexts[textKey] = {
                'text': text.text,
                'note': text.note,
                'partial': text.partial,
              };
            }
          }
        }
        // One session check after the loop instead of one per material:
        // each check opened a separate database connection (extra busy risk)
        // even when every text came from the local cache.
        if (extractedNow) await cache.verifySession();
      }
      Map<String, Map<String, dynamic>> filesPayload = const {};
      final freeboardStatuses = <String, String>{};
      const zipAddedEntries = <String>{};
      if ((options['materials'] != false || options['freeboard'] == true) && scope.account != null) {
        final cache = await MediaCache.open(scope.account!);
        filesPayload = await buildDriveFilesPayload(
          store: store,
          cache: cache,
          selectedCourses: selected == null || selected.isEmpty ? null : selected.toSet(),
          attachmentPaths: paths,
          includeMaterials: options['materials'] != false,
          includeFreeboard: options['freeboard'] == true,
          freeboardStatuses: freeboardStatuses,
        );
        // 0.6.6: no attachment ZIP. Every cached original (session-only ones too) is
        // uploaded on its own under 자료/<과목>/; the ZIP only duplicated them (10MB re-upload
        // whenever any material changed). Old ZIPs are trashed by the Drive cleanup.
      }
      final bundle = await buildAcademicExport(
        store,
        profile,
        includeLinks: options['links'] == true,
        attachmentTexts: texts,
        selectedCourses: selected == null || selected.isEmpty
            ? null
            : selected.toSet(),
        exportTasks: options['tasks'] != false,
        exportNotices: options['notices'] != false,
        exportMaterials: options['materials'] != false,
        exportTimetable: options['timetable'] != false,
        exportPlans: options['plans'] != false,
        exportFreeboard: options['freeboard'] == true,
        freeboardOriginals: freeboardStatuses,
        uploadedOriginals: filesPayload.keys.toSet(),
        zipOriginals: zipAddedEntries,
        attachmentPaths: paths,
      );
      if (manual || options['freeboard'] == true) {
        await store.log('app', '자유게시판 Drive 문서 준비 결과',
            '포함: ${options['freeboard'] == true} · 생성 문서: ${bundle.documents.keys.where((p) => p.contains('_자유게시판')).length}개\n'
            '0개라면 저장된 글·선택 과목·옵션을 확인해 주세요.');
      }
      // Machine-readable copy for the Windows Drive viewer (restored after
      // a9d1468 rewrote this file without it).
      final snapshot = jsonEncode(
        await buildAppSnapshot(
          store,
          profileId: profile,
          selectedCourses: selected == null || selected.isEmpty
              ? null
              : selected.toSet(),
          tasks: options['tasks'] != false,
          notices: options['notices'] != false,
          materials: options['materials'] != false,
          timetable: options['timetable'] != false,
          plans: options['plans'] != false,
        ),
      );
      final documents = automaticDriveDocuments(
        bundle.documents,
        appSnapshot: snapshot,
      );
      final revision = driveDocumentRevision(documents);
      // Reuse an unchanged payload, including its exportedAt timestamp.
      final old = (previous?['accounts'] as Map?)?[entry.key];
      final filesMatch =
          old is Map && jsonEncode(old['files']) == jsonEncode(filesPayload);
      payloads['${entry.key}'] =
          old is Map &&
              old['revision'] == revision &&
              old['binding'] == target['binding'] &&
              old['term'] == term &&
              filesMatch
          ? old
          : {
              'binding': target['binding'],
              'term': term,
              'revision': revision,
              'documents': documents,
              'files': filesPayload,
            };
    }
    await scope.verify();
    // Keep successful local extraction across workers that cannot invoke a PDF view.
    final textTemp = File('${textCacheFile.path}.${newShareId()}.tmp');
    try {
      await textTemp.writeAsString(jsonEncode(retainedTexts), flush: true);
      await scope.verify();
      await textTemp.rename(textCacheFile.path);
    } finally {
      if (await textTemp.exists()) await textTemp.delete();
    }
    final temp = File('${folder.path}/drive-export-v1.${newShareId()}.tmp');
    try {
      final encoded = jsonEncode({
        'epoch': scope.epoch,
        'accountHash': hash,
        'accounts': payloads,
      });
      if (utf8.encode(encoded).length > 32 * 1024 * 1024) {
        throw const FormatException(
          '자동 전송 자료가 32MB를 넘었어요. 계정별 과목·자료 범위를 줄여 주세요.',
        );
      }
      await temp.writeAsString(encoded, flush: true);
      await scope.verify();
      if (await store.meta(MetaKey.lastSuccess) != collectedAt) {
        if (manual) throw const FormatException('수집 결과가 바뀌었어요. 다시 전송해 주세요.');
        return;
      }
      await temp.rename('${folder.path}/drive-export-v1.json');
      debugPrint('CampusRadar Drive prepare: rebuilt');
      await store.setMeta(
        MetaKey.drivePreparedInput,
        jsonEncode({
          'inputs': inputs,
          'at': DateTime.now().toUtc().toIso8601String(),
        }),
      );
      try {
        final activeZipNames = <String>{
          ...collectReferencedZipNames({'accounts': payloads}),
          ...collectReferencedZipNames(previous),
          for (final v in zipCache.values)
            if (v.ref.startsWith('file://'))
              v.ref.split(RegExp(r'[/\\]')).last,
        };
        cleanupOldDriveZipFiles(
          folder: folder,
          hash: hash,
          activeZipNames: activeZipNames,
        );
      } catch (_) {}
    } finally {
      if (await temp.exists()) await temp.delete();
    }
    try {
      await bridge.invokeNative(
        NativeMethod.driveEnqueue,
        driveEnqueueArguments(manual: manual),
      );
    } on MissingPluginException {
      // Background isolates have no Activity channel; periodic work still sends.
      if (manual) rethrow;
    } catch (e) {
      // Native periodic worker reads snapshots even without an Activity.
      await store.log(
        'app',
        'Drive 즉시 전송 예약 실패',
        withCause('자료는 준비했어요. 15분 주기 작업에서 전송해요.', e),
      );
    }
  } finally {
    // Releasing must survive a busy database: a failed release used to leave
    // the lease for up to 10 minutes and block manual sends, and its error
    // replaced the original one.
    for (var attempt = 0; attempt < 4; attempt++) {
      try {
        await store.db.transaction((txn) async {
          final rows = await txn.query(
            'meta',
            where: 'id=?',
            whereArgs: [MetaKey.drivePrepareLease],
          );
          if (rows.isNotEmpty &&
              (jsonDecode(rows.single['value'] as String) as Map)['owner'] ==
                  owner) {
            await txn.delete(
              'meta',
              where: 'id=?',
              whereArgs: [MetaKey.drivePrepareLease],
            );
          }
        });
        break;
      } catch (e) {
        if (attempt == 3) {
          await systemLog(
            'Drive 준비 잠금 해제 지연',
            '잠금은 최대 10분 뒤 자동으로 풀리거나 앱을 다시 시작하면 정리돼요.',
            kind: 'app',
            error: e,
          );
        } else {
          await Future<void>.delayed(Duration(seconds: 1 + attempt * 2));
        }
      }
    }
    await store.db.close();
  }
}

/// What decides the prepared documents: the collection, the school account
/// and each Google account's export settings. Upload progress the native
/// worker writes into the same targets file (lastSuccess, file ids, hashes,
/// errors) is left out; including it rebuilt the export every minute after
/// each upload (build 81 device test, 15:16-15:18).
String drivePreparationInputs({
  required String? lastSuccess,
  required String accountHash,
  required Map targets,
}) {
  final ids = targets.keys.map((k) => '$k').toList()..sort();
  final settings = [
    for (final id in ids)
      if (targets[id] is Map)
        {
          'id': id,
          'enabled': (targets[id] as Map)['enabled'],
          'accountHash': (targets[id] as Map)['accountHash'],
          'binding': (targets[id] as Map)['binding'],
          'options': (targets[id] as Map)['options'],
        },
  ];
  return sha256
      .convert(
        utf8.encode(
          jsonEncode(['term-v1', lastSuccess, accountHash, settings]),
        ),
      )
      .toString();
}

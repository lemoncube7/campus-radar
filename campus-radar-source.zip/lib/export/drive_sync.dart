import 'package:flutter/foundation.dart' show debugPrint;
import 'dart:async';
import 'package:campus_radar/export/drive_preparation_queue.dart';
import 'package:campus_radar/export/drive_ios.dart';
import 'dart:convert';
import 'dart:io';
import 'package:sqflite/sqflite.dart';
import 'package:flutter/services.dart';
import 'package:campus_radar/campus/academic_attachment.dart';
import 'package:campus_radar/campus/material_catalog.dart';
import 'package:campus_radar/campus/media_cache.dart';
import 'package:crypto/crypto.dart';
import 'package:path_provider/path_provider.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/export/academic_export.dart';
import 'package:campus_radar/schedule/timetable_share.dart';

String driveAccountHash(String account) =>
    sha256.convert(utf8.encode(account)).toString();

/// Stable fingerprint excludes export time so opening a screen cannot reupload
/// otherwise identical academic data. Collection time stays visible and current.
String driveDocumentRevision(Map<String, String> documents) {
  final sorted = documents.keys.toList()..sort();
  final normalized = <String, String>{};
  for (final k in sorted) {
    var text = documents[k]!;
    if (k == '캠퍼스레이더 시작.txt') {
      final n = text.indexOf('\n');
      if (n >= 0) {
        final index = jsonDecode(text.substring(n + 1)) as Map;
        index.remove('exportedAt');
        text = jsonEncode(index);
      }
    } else if (k == '학업 현황.txt') {
      text = text.replaceAll(RegExp(r'내보냄: [^\n]*'), '내보냄: [갱신 시각]');
    }
    normalized[k] = text;
  }
  return sha256.convert(utf8.encode(jsonEncode(normalized))).toString();
}

Map<String, String> automaticDriveDocuments(Map<String, String> source) {
  final documents = Map<String, String>.of(source);
  const path = '캠퍼스레이더 시작.txt';
  final text = documents[path]!;
  final index = Map<String, dynamic>.from(
    jsonDecode(text.substring(text.indexOf('\n') + 1)) as Map,
  );
  index['refresh'] = '앱의 자동 내보내기 · 수집/내보낸 시각을 확인하세요';
  index['warnings'] = [
    for (final warning in (index['warnings'] as List? ?? const []))
      if (warning != '실시간 연결이 아니에요. 새로 내보내고 저장소 파일을 교체해야 갱신돼요.') warning,
    '자동 갱신은 기기 실행·네트워크 상태에 따라 늦어질 수 있어요. 수집 시각을 확인하세요.',
  ];
  documents[path] =
      'CAMPUS_RADAR_START_V1\n${const JsonEncoder.withIndent('  ').convert(index)}';
  return documents;
}

bool driveTargetMatches(Map target, String accountHash) =>
    target['enabled'] == true &&
    target['accountHash'] == accountHash &&
    target['binding'] is String &&
    (target['binding'] as String).isNotEmpty;

final _preparationQueue = DrivePreparationQueue();
Future<void> prepareDriveSnapshot({bool manual = false}) async {
  if (!Platform.isAndroid && !driveIosAvailable) return;
  await _preparationQueue.run(
    manual: manual,
    prepare: () async {
      await _prepare(manual: manual);
      _lastLoggedFailure = null;
    },
  );
}

String driveLeaseMessage(Map held, {DateTime? now}) {
  final remaining =
      (((held['until'] as num? ?? 0).toInt() -
                  (now ?? DateTime.now()).millisecondsSinceEpoch) /
              1000)
          .ceil()
          .clamp(0, 600);
  return '${held['label'] ?? '이전 전송 자료 준비'} 작업이 진행 중이에요. 잠금은 최대 $remaining초 후 풀려요. 앱 프로세스가 다시 시작되면 남은 잠금을 정리해요.';
}

String? _lastLoggedFailure;

/// Background preparation runs on every list reload, so each distinct cause
/// is logged once until a preparation succeeds again.
Future<void> logDrivePrepareFailure(Object e) async {
  final cause = failureCause(e);
  if (cause == _lastLoggedFailure) return;
  _lastLoggedFailure = cause;
  await systemLog(
    'Drive 내보내기 준비 실패',
    '앱은 그대로 쓸 수 있어요. Drive 연결 화면에서 다시 전송해 보세요.',
    kind: 'app',
    error: e,
  );
}

Future<void> _prepare({required bool manual}) async {
  final folder = await getApplicationSupportDirectory();
  final targetsFile = File('${folder.path}/drive-targets-v1.json');
  if (!await targetsFile.exists()) {
    if (manual) {
      throw const FormatException('Google 계정 연결 정보를 찾지 못했어요. 계정을 다시 연결해 주세요.');
    }
    return;
  }
  final targets = jsonDecode(await targetsFile.readAsString()) as Map;
  final account = await credentials.read(key: 'id');
  if (account == null) {
    if (manual) throw const FormatException('학교 계정을 먼저 연결해 주세요.');
    return;
  }
  final hash = driveAccountHash(account);
  if (!targets.values.any((r) => r is Map && driveTargetMatches(r, hash))) {
    if (manual) {
      throw const FormatException(
        '현재 학교 계정에 자동 전송이 켜진 Google 계정이 없어요. 전송 범위·설정에서 켜 주세요.',
      );
    }
    return;
  }
  final store = await Store.open();
  // The app reloads every minute and on every resume; each reload used to
  // rebuild the whole export (build 79: 12 s). Without a new collection or a
  // settings change, an automatic preparation within 30 minutes is skipped.
  final inputs = drivePreparationInputs(
    lastSuccess: await store.meta(MetaKey.lastSuccess),
    accountHash: hash,
    targets: targets,
  );
  if (!manual) {
    try {
      final prepared =
          jsonDecode(await store.meta(MetaKey.drivePreparedInput) ?? '{}')
              as Map;
      final at = DateTime.tryParse('${prepared['at']}');
      if (prepared['inputs'] == inputs &&
          at != null &&
          DateTime.now().toUtc().difference(at) < const Duration(minutes: 30) &&
          await File('${folder.path}/drive-export-v1.json').exists()) {
        debugPrint('CampusRadar Drive prepare: reused');
        await store.db.close();
        return;
      }
    } catch (_) {
      // An unreadable marker only means preparing again.
    }
  }
  final owner = newShareId();
  Map? heldLease;
  // A manual request waits briefly for an automatic preparation to finish
  // instead of failing at once (device test build 75, 13:19).
  final waitUntil = DateTime.now().add(
    manual ? const Duration(seconds: 45) : Duration.zero,
  );
  Future<bool> tryAcquire() => store.db.transaction((txn) async {
    final rows = await txn.query(
      'meta',
      where: 'id=?',
      whereArgs: [MetaKey.drivePrepareLease],
    );
    if (rows.isNotEmpty) {
      final held = jsonDecode(rows.single['value'] as String) as Map;
      if ((held['until'] as int) > DateTime.now().millisecondsSinceEpoch) {
        heldLease = held;
        return false;
      }
    }
    await txn.insert('meta', {
      'id': MetaKey.drivePrepareLease,
      'value': jsonEncode({
        'owner': owner,
        'label': manual ? '수동 전송 자료 준비' : '자동 전송 자료 준비',
        'until': DateTime.now().millisecondsSinceEpoch + 600000,
      }),
    }, conflictAlgorithm: ConflictAlgorithm.replace);
    return true;
  });
  var acquired = await tryAcquire();
  while (!acquired && DateTime.now().isBefore(waitUntil)) {
    await Future<void>.delayed(const Duration(seconds: 3));
    heldLease = null;
    acquired = await tryAcquire();
  }
  if (!acquired) {
    await store.db.close();
    if (manual) throw FormatException(driveLeaseMessage(heldLease ?? const {}));
    return;
  }
  try {
    final scope = await SessionScope.capture(store);
    await scope.verify();
    if ((await store.meta(MetaKey.lastSuccess) ?? '').isEmpty) {
      if (manual) throw const FormatException('학교 자료를 한 번 수집한 뒤 전송해 주세요.');
      return;
    }
    var profile = await store.meta(MetaKey.academicExportProfile);
    if (profile == null) {
      profile = newShareId();
      await store.setMeta(MetaKey.academicExportProfile, profile);
    }
    final payloads = <String, dynamic>{};
    final textCacheFile = File('${folder.path}/drive-texts-$hash.json');
    Map<String, dynamic> cachedTexts = {};
    try {
      if (await textCacheFile.exists()) {
        cachedTexts = Map<String, dynamic>.from(
          jsonDecode(await textCacheFile.readAsString()) as Map,
        );
      }
    } catch (_) {
      /* Rebuild damaged optional text cache. */
    }
    final retainedTexts = <String, dynamic>{};
    for (final entry in targets.entries) {
      final target = entry.value as Map;
      if (!driveTargetMatches(target, hash)) continue;
      final options = (target['options'] as Map?) ?? const {};
      final selected = (options['courses'] as List?)?.cast<String>();
      final texts = <String, AttachmentText>{};
      if (options['texts'] == true &&
          options['materials'] != false &&
          scope.account != null) {
        final cache = await MediaCache.open(scope.account!);
        final extracted = <String, AttachmentText>{};
        var extractedNow = false;
        for (final material in await studyMaterials(store)) {
          if (material.media == null ||
              selected != null &&
                  selected.isNotEmpty &&
                  !selected.contains(material.course)) {
            continue;
          }
          final local = await cache.local(material.media!);
          if (local == null) continue;
          var text = extracted[local.path];
          final stat = await local.stat();
          final textKey = sha256
              .convert(
                utf8.encode(
                  '${local.path}|${stat.size}|${stat.modified.toUtc().toIso8601String()}|${material.name.split('.').last.toLowerCase()}',
                ),
              )
              .toString();
          final cached = cachedTexts[textKey];
          if (text == null && cached is Map && extracted.length < 10) {
            text = AttachmentText(
              '${cached['text']}',
              '${cached['note']}',
              partial: cached['partial'] == true,
            );
            extracted[local.path] = text;
          }
          var failedNow = false;
          if (text == null && extracted.length < 10) {
            await scope.verify();
            extractedNow = true;
            try {
              text = await extractAttachmentText(local, material.name);
            } catch (_) {
              failedNow = true;
              text = const AttachmentText(
                '',
                '현재 작업에서 추출하지 못했어요. 앱에서 다시 전송해 주세요.',
              );
            }
            extracted[local.path] = text;
          }
          if (text != null) {
            texts[material.id] = text;
            // Files with no extractable text (scans, unsupported formats) are
            // remembered too; only a thrown error is retried next time.
            if (!failedNow) {
              retainedTexts[textKey] = {
                'text': text.text,
                'note': text.note,
                'partial': text.partial,
              };
            }
          }
        }
        // One session check after the loop instead of one per material:
        // each check opened a separate database connection (extra busy risk)
        // even when every text came from the local cache.
        if (extractedNow) await cache.verifySession();
      }
      final bundle = await buildAcademicExport(
        store,
        profile,
        includeLinks: options['links'] == true,
        attachmentTexts: texts,
        selectedCourses: selected == null || selected.isEmpty
            ? null
            : selected.toSet(),
        exportTasks: options['tasks'] != false,
        exportNotices: options['notices'] != false,
        exportMaterials: options['materials'] != false,
        exportTimetable: options['timetable'] != false,
        exportPlans: options['plans'] != false,
      );
      final documents = automaticDriveDocuments(bundle.documents);
      final revision = driveDocumentRevision(documents);
      // Reuse an unchanged payload, including its exportedAt timestamp.
      final previousFile = File('${folder.path}/drive-export-v1.json');
      Map? previous;
      try {
        if (await previousFile.exists()) {
          previous = jsonDecode(await previousFile.readAsString()) as Map;
        }
      } catch (_) {
        /* Replace corrupt local snapshot; don't upload it. */
      }
      final old = (previous?['accounts'] as Map?)?[entry.key];
      payloads['${entry.key}'] =
          old is Map &&
              old['revision'] == revision &&
              old['binding'] == target['binding']
          ? old
          : {
              'binding': target['binding'],
              'revision': revision,
              'documents': documents,
            };
    }
    await scope.verify();
    // Keep successful local extraction across workers that cannot invoke a PDF view.
    final textTemp = File('${textCacheFile.path}.${newShareId()}.tmp');
    try {
      await textTemp.writeAsString(jsonEncode(retainedTexts), flush: true);
      await scope.verify();
      await textTemp.rename(textCacheFile.path);
    } finally {
      if (await textTemp.exists()) await textTemp.delete();
    }
    final temp = File('${folder.path}/drive-export-v1.${newShareId()}.tmp');
    try {
      final encoded = jsonEncode({
        'epoch': scope.epoch,
        'accountHash': hash,
        'accounts': payloads,
      });
      if (utf8.encode(encoded).length > 32 * 1024 * 1024) {
        throw const FormatException(
          '자동 전송 자료가 32MB를 넘었어요. 계정별 과목·자료 범위를 줄여 주세요.',
        );
      }
      await temp.writeAsString(encoded, flush: true);
      await scope.verify();
      await temp.rename('${folder.path}/drive-export-v1.json');
      debugPrint('CampusRadar Drive prepare: rebuilt');
      await store.setMeta(
        MetaKey.drivePreparedInput,
        jsonEncode({
          'inputs': inputs,
          'at': DateTime.now().toUtc().toIso8601String(),
        }),
      );
    } finally {
      if (await temp.exists()) await temp.delete();
    }
    try {
      await bridge.invokeNative(NativeMethod.driveEnqueue);
    } on MissingPluginException {
      // Background isolates have no Activity channel; periodic work still sends.
      if (manual) rethrow;
    } catch (e) {
      // Native periodic worker reads snapshots even without an Activity.
      await store.log(
        'app',
        'Drive 즉시 전송 예약 실패',
        withCause('자료는 준비했어요. 15분 주기 작업에서 전송해요.', e),
      );
    }
  } finally {
    // Releasing must survive a busy database: a failed release used to leave
    // the lease for up to 10 minutes and block manual sends, and its error
    // replaced the original one.
    for (var attempt = 0; attempt < 4; attempt++) {
      try {
        await store.db.transaction((txn) async {
          final rows = await txn.query(
            'meta',
            where: 'id=?',
            whereArgs: [MetaKey.drivePrepareLease],
          );
          if (rows.isNotEmpty &&
              (jsonDecode(rows.single['value'] as String) as Map)['owner'] ==
                  owner) {
            await txn.delete(
              'meta',
              where: 'id=?',
              whereArgs: [MetaKey.drivePrepareLease],
            );
          }
        });
        break;
      } catch (e) {
        if (attempt == 3) {
          await systemLog(
            'Drive 준비 잠금 해제 지연',
            '잠금은 최대 10분 뒤 자동으로 풀리거나 앱을 다시 시작하면 정리돼요.',
            kind: 'app',
            error: e,
          );
        } else {
          await Future<void>.delayed(Duration(seconds: 1 + attempt * 2));
        }
      }
    }
    await store.db.close();
  }
}

/// What decides the prepared documents: the collection, the school account
/// and each Google account's export settings. Upload progress the native
/// worker writes into the same targets file (lastSuccess, file ids, hashes,
/// errors) is left out; including it rebuilt the export every minute after
/// each upload (build 81 device test, 15:16-15:18).
String drivePreparationInputs({
  required String? lastSuccess,
  required String accountHash,
  required Map targets,
}) {
  final ids = targets.keys.map((k) => '$k').toList()..sort();
  final settings = [
    for (final id in ids)
      if (targets[id] is Map)
        {
          'id': id,
          'enabled': (targets[id] as Map)['enabled'],
          'accountHash': (targets[id] as Map)['accountHash'],
          'binding': (targets[id] as Map)['binding'],
          'options': (targets[id] as Map)['options'],
        },
  ];
  return sha256
      .convert(utf8.encode(jsonEncode([lastSuccess, accountHash, settings])))
      .toString();
}

import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';

/// Dart port of the Android Drive uploader (DriveApi.kt + the per-account
/// loop in DriveSyncWorker.kt) for platforms without the Kotlin worker
/// (iPhone). Same rules: only app-created files (drive.file), a fixed
/// "캠퍼스레이더/과목" layout, unchanged documents are not rewritten, trashed
/// or deleted files get a new id, removed documents are trashed.
class DriveHttpFailure implements Exception {
  final int status;
  const DriveHttpFailure(this.status);
  @override
  String toString() => 'Drive HTTP $status';
}

typedef DriveTransport =
    Future<({int status, String body})> Function(
      String method,
      Uri url,
      String token, {
      List<int>? body,
      String? contentType,
    });

Future<({int status, String body})> httpDriveTransport(
  String method,
  Uri url,
  String token, {
  List<int>? body,
  String? contentType,
}) async {
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 15);
  try {
    final request = await client.openUrl(method, url);
    request.followRedirects = false;
    request.headers.set(HttpHeaders.authorizationHeader, 'Bearer $token');
    if (body != null) {
      request.headers.contentType = ContentType.parse(contentType!);
      request.contentLength = body.length;
      request.add(body);
    }
    final response = await request.close().timeout(const Duration(seconds: 25));
    final bytes = <int>[];
    await for (final chunk in response) {
      bytes.addAll(chunk);
      if (bytes.length > 1048576) throw const DriveHttpFailure(-1);
    }
    return (status: response.statusCode, body: utf8.decode(bytes));
  } finally {
    client.close(force: true);
  }
}

class DriveApi {
  static const scope = 'https://www.googleapis.com/auth/drive.file';
  final String token;
  final DriveTransport transport;
  const DriveApi(this.token, {this.transport = httpDriveTransport});

  static String digest(String value) =>
      sha256.convert(utf8.encode(value)).toString();

  Future<Map<String, dynamic>> _json(
    String method,
    String url, [
    Map<String, dynamic>? body,
  ]) async {
    final text = await _request(
      method,
      url,
      body == null ? null : utf8.encode(jsonEncode(body)),
      'application/json; charset=UTF-8',
    );
    return text.trim().isEmpty
        ? {}
        : Map<String, dynamic>.from(jsonDecode(text) as Map);
  }

  Future<String> _request(
    String method,
    String url,
    List<int>? body,
    String mime,
  ) async {
    if (!url.startsWith('https://www.googleapis.com/drive/v3/') &&
        !url.startsWith('https://www.googleapis.com/upload/drive/v3/')) {
      throw ArgumentError('Unexpected Drive URL');
    }
    final r = await transport(
      method,
      Uri.parse(url),
      token,
      body: body,
      contentType: body == null ? null : mime,
    );
    if (r.status < 200 || r.status > 299) throw DriveHttpFailure(r.status);
    return r.body;
  }

  Future<String> id() async =>
      ((await _json(
                    'GET',
                    'https://www.googleapis.com/drive/v3/files/generateIds?count=1&space=drive&type=files',
                  ))['ids']
                  as List)
              .first
          as String;

  Future<void> createFolder(String id, String name, {String? parent}) =>
      _create(id, {
        'id': id,
        'name': name,
        'mimeType': 'application/vnd.google-apps.folder',
        if (parent != null) 'parents': [parent],
      });

  Future<void> createText(String id, String name, String parent) =>
      _create(id, {
        'id': id,
        'name': name,
        'mimeType': 'text/plain',
        'parents': [parent],
      });

  Future<void> write(String id, String text) => _request(
    'PATCH',
    'https://www.googleapis.com/upload/drive/v3/files/$id?uploadType=media',
    utf8.encode(text),
    'text/plain; charset=UTF-8',
  );

  Future<void> trash(String id) => _json(
    'PATCH',
    'https://www.googleapis.com/drive/v3/files/$id',
    {'trashed': true},
  );

  Future<void> _create(String id, Map<String, dynamic> metadata) async {
    try {
      await _json(
        'POST',
        'https://www.googleapis.com/drive/v3/files?fields=id',
        metadata,
      );
    } on DriveHttpFailure catch (e) {
      if (e.status != 409 || !await exists(id)) rethrow;
    }
  }

  /// False for a missing (404) or trashed file.
  Future<bool> exists(String id) async {
    try {
      final m = await _json(
        'GET',
        'https://www.googleapis.com/drive/v3/files/$id?fields=id,trashed',
      );
      return m['trashed'] != true;
    } on DriveHttpFailure catch (e) {
      if (e.status == 404) return false;
      rethrow;
    }
  }
}

const startDocument = '캠퍼스레이더 시작.txt';

/// Uploads [documents] for one account. [state] holds folder, courseFolder,
/// files (name → id) and hashes (name → sha256) and is updated in place;
/// [checkpoint] persists it after every step so an interrupted run resumes.
/// Returns the number of documents written, or throws [DriveHttpFailure].
Future<({int writes, bool complete})> uploadDriveDocuments({
  required DriveApi api,
  required Map<String, dynamic> state,
  required Map<String, String> documents,
  required Future<void> Function() checkpoint,
  bool Function()? cancelled,
  int maxWrites = 25,
}) async {
  void check() {
    if (cancelled?.call() == true) throw StateError('Drive upload cancelled');
  }

  var folder = '${state['folder'] ?? ''}';
  if (folder.isEmpty || !await api.exists(folder)) {
    check();
    folder = await api.id();
    state
      ..['folder'] = folder
      ..remove('courseFolder')
      ..remove('files')
      ..remove('hashes');
    await checkpoint();
    await api.createFolder(folder, '캠퍼스레이더');
  }
  var course = '${state['courseFolder'] ?? ''}';
  if (course.isEmpty || !await api.exists(course)) {
    check();
    course = await api.id();
    state['courseFolder'] = course;
    final oldFiles = state['files'] as Map?;
    final oldHashes = state['hashes'] as Map?;
    for (final name in [
      ...?oldFiles?.keys.where((k) => '$k'.startsWith('과목/')),
    ]) {
      oldFiles!.remove(name);
      oldHashes?.remove(name);
    }
    await checkpoint();
    await api.createFolder(course, '과목', parent: folder);
  }
  final files = state['files'] = Map<String, dynamic>.from(
    state['files'] as Map? ?? {},
  );
  final hashes = state['hashes'] = Map<String, dynamic>.from(
    state['hashes'] as Map? ?? {},
  );
  // Only app-owned tracked files removed from the export are trashed.
  for (final old in files.keys.toList()) {
    if (documents.containsKey(old)) continue;
    check();
    try {
      await api.trash('${files[old]}');
    } on DriveHttpFailure catch (e) {
      if (e.status != 404) rethrow;
    }
    files.remove(old);
    hashes.remove(old);
    await checkpoint();
  }
  // The start file goes last so it never points at documents not yet sent.
  final names = [
    ...documents.keys.where((n) => n != startDocument),
    if (documents.containsKey(startDocument)) startDocument,
  ];
  var writes = 0;
  for (final name in names) {
    check();
    final text = documents[name]!;
    final hash = DriveApi.digest(text);
    var id = '${files[name] ?? ''}';
    final present = id.isNotEmpty && await api.exists(id);
    if (present && hashes[name] == hash) continue;
    if (writes >= maxWrites) return (writes: writes, complete: false);
    if (!present) {
      id = await api.id();
      files[name] = id;
      hashes.remove(name);
      await checkpoint();
      await api.createText(
        id,
        name.split('/').last,
        name.startsWith('과목/') ? course : folder,
      );
    }
    await api.write(id, text);
    hashes[name] = hash;
    await checkpoint();
    writes++;
  }
  return (writes: writes, complete: true);
}

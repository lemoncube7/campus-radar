import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';

/// Dart port of the Android Drive uploader (DriveApi.kt + the per-account
/// loop in DriveSyncWorker.kt) for platforms without the Kotlin worker
/// (iPhone). Same rules: only app-created files (drive.file), a fixed
/// "캠퍼스레이더/과목" layout, unchanged documents are not rewritten, trashed
/// or deleted files get a new id, removed documents are trashed.
/// Recover only the app's exact, unlabelled-semester archive names.
/// Destructive actions are trash-only; nonmatching/sized-differently files survive.
Future<({int folders, int files})> cleanupUnknownSemesterArchives({
  required DriveApi api,
  required String root,
  required String courseRoot,
  required Future<String> Function(String) courseMaterialsFolder,
  required void Function() check,
}) async {
  var folders = 0;
  var files = 0;
  Future<void> trash(DriveItem item) async {
    check();
    await api.trash(item.id);
    if (item.isFolder) { folders++; } else { files++; }
  }

  Future<void> merge(String source, String target, bool documents) async {
    final current = await api.listChildren(target);
    for (final item in await api.listChildren(source)) {
      check();
      if (item.isFolder) {
        // Unexpected nested folders are preserved intact, never recursively deleted.
        await api.updateMetadata(item.id, addParents: [target], removeParents: [source]);
        continue;
      }
      final normalized = DriveSyncLogic.normalizeAttachmentFileName(item.name);
      final duplicate = current.any((other) => !other.isFolder &&
          DriveSyncLogic.normalizeAttachmentFileName(other.name) == normalized &&
          (documents && item.name.endsWith('.txt') || other.size == item.size));
      if (duplicate) {
        await trash(item);
      } else {
        await api.updateMetadata(item.id,
          appProperties: DriveSyncLogic.buildAppProperties(
            kind: DriveSyncLogic.kindFile,
            key: item.crKey.isNotEmpty ? item.crKey : 'legacy:${item.id}',
          ), addParents: [target], removeParents: [source]);
        current.add(item);
      }
    }
    if ((await api.listChildren(source)).isEmpty) {
      check();
      await api.trash(source);
      folders++;
    }
  }

  for (final archive in await api.listChildren(root)) {
    check();
    if (!archive.isFolder &&
        (RegExp(r'^지난 내보내기 \([^\r\n]+\) - 첨부원본\.zip$').hasMatch(archive.name) ||
            // 0.6.6 no longer uploads the ZIP; untracked copies remain otherwise.
            archive.name == '캠퍼스레이더 첨부원본.zip')) {
      await trash(archive);
    } else if (archive.isFolder && archive.name == '지난 내보내기 (학기 미확인) - 과목') {
      await merge(archive.id, courseRoot, true);
    } else if (archive.isFolder && archive.name == '지난 내보내기 (학기 미확인) - 자료') {
      for (final child in await api.listChildren(archive.id)) {
        if (!child.isFolder) continue; // Unknown loose files stay in the archive.
        await merge(child.id, await courseMaterialsFolder(child.name), false);
      }
      if ((await api.listChildren(archive.id)).isEmpty) await trash(archive);
    }
  }
  return (folders: folders, files: files);
}

class DriveHttpFailure implements Exception {
  final int status;
  const DriveHttpFailure(this.status);
  @override
  String toString() => 'Drive HTTP $status';
}

class DriveItem {
  final String id;
  final String name;
  final String createdTime;
  final String mimeType;
  final int size;
  final List<String> parents;
  final Map<String, String> appProperties;

  const DriveItem({
    required this.id,
    required this.name,
    required this.createdTime,
    required this.mimeType,
    this.size = 0,
    this.parents = const [],
    this.appProperties = const {},
  });
  bool get isFolder => mimeType == 'application/vnd.google-apps.folder';
  String get crKind => appProperties['crKind'] ?? '';
  String get crKey => appProperties['crKey'] ?? '';
  String get crHash => appProperties['crHash'] ?? '';
  String get crVer => appProperties['crVer'] ?? '';
}

/// Pure decision logic shared with Android DriveSyncWorker & DriveSyncLogic.
class DriveSyncLogic {
  DriveSyncLogic._();

  static const String crVer = '0.6.6';

  static const String kindRoot = 'root';
  static const String kindTerm = 'term';
  static const String kindCourse = 'course';
  static const String kindMaterials = 'materials';
  static const String kindFile = 'file';

  static Map<String, String> buildAppProperties({
    required String kind,
    required String key,
    String hash = '',
    String ver = crVer,
  }) {
    var safeKey = key;
    if (safeKey.length > 100) {
      safeKey = 'sha256:${sha256.convert(utf8.encode(key))}';
    }
    return {
      'crKind': kind,
      'crKey': safeKey,
      'crHash': hash,
      'crVer': ver,
    };
  }

  // Keys over 100 chars are stored hashed (appProperties limit); lookups use the same form.
  static String storedKey(String key) =>
      key.length > 100 ? 'sha256:${sha256.convert(utf8.encode(key))}' : key;
  static String documentKey(String docName) => storedKey(_rawDocumentKey(docName));
  static String attachmentKey({
    required String course,
    required String fileName,
    String? attachmentId,
  }) =>
      storedKey(_rawAttachmentKey(course: course, fileName: fileName, attachmentId: attachmentId));
  static String _rawDocumentKey(String docName) {
    if (docName == '캠퍼스레이더 시작.txt') return 'doc:start';
    if (docName == '학업 현황.txt') return 'doc:overview';
    if (docName == '시간표.txt') return 'doc:timetable';
    if (docName == '첨부 자료 인덱스.txt') return 'doc:index';
    if (docName == '캠퍼스레이더 첨부원본.zip') return 'doc:zip';
    if (docName.startsWith('과목/첨부_')) {
      final id = docName.substring('과목/첨부_'.length).replaceAll(RegExp(r'\.(txt|md)$'), '');
      return 'doc:text:$id';
    }
    if (docName.startsWith('과목/')) {
      final course = docName.substring('과목/'.length).replaceAll(RegExp(r'\.(txt|md)$'), '');
      return 'doc:course:${safeCourseFolderName(course)}';
    }
    return 'doc:$docName';
  }

  static String _rawAttachmentKey({
    required String course,
    required String fileName,
    String? attachmentId,
  }) {
    if (attachmentId != null && attachmentId.isNotEmpty) {
      return 'att:$attachmentId';
    }
    final safeCourse = safeCourseFolderName(course);
    final safeFile = safeAttachmentFileName(normalizeAttachmentFileName(fileName));
    return 'att:$safeCourse/$safeFile';
  }

  /// Removes trailing duplicate counter suffix ' (n)' from filename.
  /// e.g. "foo (2).hwp" -> "foo.hwp", "bar (10)" -> "bar"
  static String normalizeAttachmentFileName(String name) {
    final dot = name.lastIndexOf('.');
    if (dot > 0) {
      final base = name.substring(0, dot);
      final ext = name.substring(dot);
      final cleanBase = base.replaceAll(RegExp(r' \(\d+\)$'), '');
      return '$cleanBase$ext';
    } else {
      return name.replaceAll(RegExp(r' \(\d+\)$'), '');
    }
  }

  /// Determines whether previous semester folders should be archived.
  /// Only true when a non-blank previous term differs from the new current term.
  /// When upgrading from legacy versions where term was blank, archiving is skipped.
  static bool shouldArchiveSemester(String previousTerm, String currentTerm) {
    return previousTerm.trim().isNotEmpty &&
        currentTerm.trim().isNotEmpty &&
        previousTerm != currentTerm;
  }

  /// File tracking entries should only be pruned when a brand new folder is created on Drive.
  /// When reusing an existing folder, tracking must be retained to avoid redundant re-uploads.
  static bool shouldPruneTrackedFiles(bool isNewFolderCreated) {
    return isNewFolderCreated;
  }

  /// Checks if session epoch is valid. A transient SQLite lock (isBusy) must not abort the sync.
  static bool isEpochValid(
    String? currentEpoch,
    String expectedEpoch, [
    bool isBusy = false,
  ]) {
    if (isBusy) return true;
    return currentEpoch != null && currentEpoch == expectedEpoch;
  }

  /// Archive names for semester rollover:
  /// - Course folder: "지난 내보내기 ($previousTerm) - 과목"
  /// - Materials folder: "지난 내보내기 ($previousTerm) - 자료"
  /// - Attachment zip: "지난 내보내기 ($previousTerm) - 첨부원본.zip"
  static String archivedCourseFolderName(String term) => '지난 내보내기 ($term) - 과목';
  static String archivedMaterialsFolderName(String term) =>
      '지난 내보내기 ($term) - 자료';
  static String archivedZipName(String term) =>
      '지난 내보내기 ($term) - 첨부원본.zip';

  /// Whether a tracked file key should be pruned on semester archiving.
  static bool isSemesterScopedKey(String key) {
    return key.startsWith('과목/') ||
        key.startsWith('자료/') ||
        key == '캠퍼스레이더 첨부원본.zip';
  }

  static String safeCourseFolderName(String name) {
    var safe = name.replaceAll(RegExp(r'[^가-힣A-Za-z0-9 _-]'), '_').trim();
    if (safe.isEmpty) safe = '과목';
    safe = safe.substring(0, safe.length.clamp(0, 50));
    return safe;
  }

  static String safeAttachmentFileName(String name) {
    var safe = name.replaceAll(RegExp(r'[/\\:*?"<>|\x00-\x1f]'), '_').trim();
    if (safe.isEmpty) safe = '첨부파일';
    return safe;
  }

  static bool isLegacyMatchingKey(
    String oldKey,
    String newKey,
    String oldHash,
    String newHash,
  ) {
    if (!oldKey.startsWith('자료/') || !newKey.startsWith('자료/')) return false;
    if (oldHash.isNotEmpty && newHash.isNotEmpty && oldHash == newHash) return true;
    final oldCourse = oldKey.substring('자료/'.length).split('/').first;
    final oldFile = oldKey.split('/').last;
    final newCourse = newKey.substring('자료/'.length).split('/').first;
    final newFile = newKey.split('/').last;
    return safeCourseFolderName(oldCourse) == newCourse &&
        safeAttachmentFileName(normalizeAttachmentFileName(oldFile)) == newFile;
  }
}

typedef DriveTransport =
    Future<({int status, String body})> Function(
      String method,
      Uri url,
      String token, {
      List<int>? body,
      String? contentType,
    });

Future<({int status, String body})> httpDriveTransport(
  String method,
  Uri url,
  String token, {
  List<int>? body,
  String? contentType,
}) async {
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 15);
  try {
    final request = await client.openUrl(method, url);
    request.followRedirects = false;
    request.headers.set(HttpHeaders.authorizationHeader, 'Bearer $token');
    if (body != null) {
      request.headers.contentType = ContentType.parse(contentType!);
      request.contentLength = body.length;
      request.add(body);
    }
    final response = await request.close().timeout(const Duration(seconds: 25));
    final bytes = <int>[];
    await for (final chunk in response) {
      bytes.addAll(chunk);
      if (bytes.length > 1048576) throw const DriveHttpFailure(-1);
    }
    return (status: response.statusCode, body: utf8.decode(bytes));
  } finally {
    client.close(force: true);
  }
}

class DriveApi {
  static const scope = 'https://www.googleapis.com/auth/drive.file';
  final String token;
  final DriveTransport transport;
  const DriveApi(this.token, {this.transport = httpDriveTransport});

  static String digest(String value) =>
      sha256.convert(utf8.encode(value)).toString();

  Future<Map<String, dynamic>> _json(
    String method,
    String url, [
    Map<String, dynamic>? body,
  ]) async {
    final text = await _request(
      method,
      url,
      body == null ? null : utf8.encode(jsonEncode(body)),
      'application/json; charset=UTF-8',
    );
    return text.trim().isEmpty
        ? {}
        : Map<String, dynamic>.from(jsonDecode(text) as Map);
  }

  Future<String> _request(
    String method,
    String url,
    List<int>? body,
    String mime,
  ) async {
    if (!url.startsWith('https://www.googleapis.com/drive/v3/') &&
        !url.startsWith('https://www.googleapis.com/upload/drive/v3/')) {
      throw ArgumentError('Unexpected Drive URL');
    }
    final r = await transport(
      method,
      Uri.parse(url),
      token,
      body: body,
      contentType: body == null ? null : mime,
    );
    if (r.status < 200 || r.status > 299) throw DriveHttpFailure(r.status);
    return r.body;
  }

  Future<String> id() async =>
      ((await _json(
                    'GET',
                    'https://www.googleapis.com/drive/v3/files/generateIds?count=1&space=drive&type=files',
                  ))['ids']
                  as List)
              .first
          as String;

  Future<void> createFolder(
    String id,
    String name, {
    String? parent,
    Map<String, String>? appProperties,
  }) =>
      _create(id, {
        'id': id,
        'name': name,
        'mimeType': 'application/vnd.google-apps.folder',
        if (parent != null) 'parents': [parent],
        if (appProperties != null && appProperties.isNotEmpty)
          'appProperties': appProperties,
      });

  Future<void> createText(
    String id,
    String name,
    String parent, {
    Map<String, String>? appProperties,
  }) =>
      _create(id, {
        'id': id,
        'name': name,
        'mimeType': 'text/plain',
        'parents': [parent],
        if (appProperties != null && appProperties.isNotEmpty)
          'appProperties': {...appProperties, 'crHash': ''}, // hash set after the write
      });

  Future<void> write(String id, String text) => _request(
    'PATCH',
    'https://www.googleapis.com/upload/drive/v3/files/$id?uploadType=media',
    utf8.encode(text),
    'text/plain; charset=UTF-8',
  );

  /// Binary documents (the attachment ZIP) travel base64-encoded in the
  /// documents map, the same as for the Android uploader.
  Future<void> createFile(
    String id,
    String name,
    String parent,
    String mime, {
    Map<String, String>? appProperties,
  }) =>
      _create(id, {
        'id': id,
        'name': name,
        'mimeType': mime,
        'parents': [parent],
        if (appProperties != null && appProperties.isNotEmpty)
          'appProperties': {...appProperties, 'crHash': ''}, // hash set after the write
      });

  Future<void> writeBytes(String id, List<int> bytes, String mime) => _request(
    'PATCH',
    'https://www.googleapis.com/upload/drive/v3/files/$id?uploadType=media',
    bytes,
    mime,
  );

  Future<void> trash(String id) => _json(
    'PATCH',
    'https://www.googleapis.com/drive/v3/files/$id',
    {'trashed': true},
  );

  Future<void> updateMetadata(
    String id, {
    String? name,
    Map<String, String>? appProperties,
    List<String>? addParents,
    List<String>? removeParents,
  }) async {
    final queryParams = <String, String>{};
    if (addParents != null && addParents.isNotEmpty) {
      queryParams['addParents'] = addParents.join(',');
    }
    if (removeParents != null && removeParents.isNotEmpty) {
      queryParams['removeParents'] = removeParents.join(',');
    }
    var url = 'https://www.googleapis.com/drive/v3/files/$id';
    if (queryParams.isNotEmpty) {
      final qs = queryParams.entries
          .map((e) => '${e.key}=${Uri.encodeQueryComponent(e.value)}')
          .join('&');
      url += '?$qs';
    }
    final body = <String, dynamic>{};
    if (name != null) {
      body['name'] = name;
    }
    if (appProperties != null && appProperties.isNotEmpty) {
      body['appProperties'] = appProperties;
    }
    await _json('PATCH', url, body);
  }

  Future<void> _create(String id, Map<String, dynamic> metadata) async {
    try {
      await _json(
        'POST',
        'https://www.googleapis.com/drive/v3/files?fields=id',
        metadata,
      );
    } on DriveHttpFailure catch (e) {
      if (e.status != 409 || !await exists(id)) rethrow;
    }
  }

  /// False for a missing (404) or trashed file.
  Future<bool> exists(String id) async {
    try {
      final m = await _json(
        'GET',
        'https://www.googleapis.com/drive/v3/files/$id?fields=id,trashed',
      );
      return m['trashed'] != true;
    } on DriveHttpFailure catch (e) {
      if (e.status == 404) return false;
      rethrow;
    }
  }

  Future<List<DriveItem>> listChildren(
    String parent, {
    String? name,
    bool folderOnly = false,
  }) async {
    final q = StringBuffer("'$parent' in parents and trashed=false");
    if (name != null) {
      final escaped = name.replaceAll(r'\', r'\\').replaceAll("'", r"\'");
      q.write(" and name='$escaped'");
    }
    if (folderOnly) {
      q.write(" and mimeType='application/vnd.google-apps.folder'");
    }
    return listByQuery(q.toString());
  }

  Future<List<DriveItem>> listByQuery(String query) async {
    final items = <DriveItem>[];
    final encodedFields = Uri.encodeQueryComponent(
      'files(id,name,createdTime,mimeType,size,parents,appProperties),nextPageToken',
    );
    final encodedQ = Uri.encodeQueryComponent(
      query,
    ).replaceAll('+', '%20');
    String? pageToken;
    do {
      var url =
          'https://www.googleapis.com/drive/v3/files?pageSize=200&fields=$encodedFields&q=$encodedQ';
      if (pageToken != null && pageToken.isNotEmpty) {
        url += '&pageToken=${Uri.encodeQueryComponent(pageToken)}';
      }
      final res = await _json('GET', url);
      final files = res['files'] as List?;
      if (files != null) {
        for (final f in files) {
          if (f is Map) {
            final parentsList = <String>[];
            if (f['parents'] is List) {
              parentsList.addAll((f['parents'] as List).map((p) => '$p'));
            }
            final propsMap = <String, String>{};
            if (f['appProperties'] is Map) {
              for (final e in (f['appProperties'] as Map).entries) {
                propsMap['${e.key}'] = '${e.value}';
              }
            }
            items.add(
              DriveItem(
                id: '${f['id'] ?? ''}',
                name: '${f['name'] ?? ''}',
                createdTime: '${f['createdTime'] ?? ''}',
                mimeType: '${f['mimeType'] ?? ''}',
                size: int.tryParse('${f['size'] ?? 0}') ?? 0,
                parents: parentsList,
                appProperties: propsMap,
              ),
            );
          }
        }
      }
      final next = res['nextPageToken'] as String?;
      pageToken = (next != null && next.trim().isNotEmpty) ? next.trim() : null;
    } while (pageToken != null);
    return items;
  }

  Future<void> rename(String id, String name) => _json(
    'PATCH',
    'https://www.googleapis.com/drive/v3/files/$id',
    {'name': name},
  );
}

DriveItem? _oldestItem(List<DriveItem> items) {
  if (items.isEmpty) return null;
  return items.reduce((a, b) {
    final timeA = a.createdTime.isEmpty ? '9999' : a.createdTime;
    final timeB = b.createdTime.isEmpty ? '9999' : b.createdTime;
    return timeA.compareTo(timeB) <= 0 ? a : b;
  });
}

const startDocument = '캠퍼스레이더 시작.txt';

/// Uploads [documents] and [fileEntries] for one account. [state] holds folder,
/// courseFolder, materialsFolder, materialsCourses, files (name → id) and
/// hashes (name → sha256) and is updated in place; [checkpoint] persists it
/// after every step so an interrupted run resumes.
/// Returns the number of documents/files written and whether the upload completed.
Future<({int writes, bool complete})> uploadDriveDocuments({
  required DriveApi api,
  required Map<String, dynamic> state,
  required Map<String, String> documents,
  Map<String, dynamic> fileEntries = const {},
  String term = '',
  required Future<void> Function() checkpoint,
  bool Function()? cancelled,
  int maxWrites = 25,
}) async {
  void check() {
    if (cancelled?.call() == true) throw StateError('Drive upload cancelled');
  }

  // 1. Root folder: find existing or create new
  final existingRoots = await api.listChildren(
    'root',
    name: '캠퍼스레이더',
    folderOnly: true,
  );
  var folder = '${state['folder'] ?? ''}';
  DriveItem? adoptedRoot;
  if (folder.isNotEmpty && existingRoots.any((r) => r.id == folder)) {
    adoptedRoot = existingRoots.firstWhere((r) => r.id == folder);
  } else {
    adoptedRoot = _oldestItem(existingRoots);
  }

  var isNewFolder = false;
  if (adoptedRoot != null) {
    folder = adoptedRoot.id;
    state['folder'] = folder;
    if (adoptedRoot.crKind != DriveSyncLogic.kindRoot) {
      try {
        await api.updateMetadata(
          folder,
          appProperties: DriveSyncLogic.buildAppProperties(
            kind: DriveSyncLogic.kindRoot,
            key: 'root',
          ),
        );
      } catch (_) {}
    }
  } else {
    isNewFolder = true;
    folder = await api.id();
    state['folder'] = folder;
    await checkpoint();
    await api.createFolder(
      folder,
      '캠퍼스레이더',
      appProperties: DriveSyncLogic.buildAppProperties(
        kind: DriveSyncLogic.kindRoot,
        key: 'root',
      ),
    );
  }

  if (DriveSyncLogic.shouldPruneTrackedFiles(isNewFolder)) {
    state
      ..remove('courseFolder')
      ..remove('materialsFolder')
      ..remove('materialsCourses')
      ..remove('files')
      ..remove('hashes');
  }
  await checkpoint();

  // The attachment ZIP is retired: trash any root copy on every run.
  for (final z in await api.listChildren(folder, name: '캠퍼스레이더 첨부원본.zip', folderOnly: false)) {
    if (z.isFolder) continue;
    check();
    try {
      await api.trash(z.id);
    } on DriveHttpFailure catch (e) {
      if (e.status != 404) rethrow;
    }
  }
  (state['files'] as Map?)?.remove('캠퍼스레이더 첨부원본.zip');

  // 2. Query remote list by crKind
  final remoteItems = await api.listByQuery(
    driveRemoteQuery,
  );
  final remoteByCrKey = <String, DriveItem>{};
  for (final item in remoteItems) {
    if (item.crKey.isNotEmpty) {
      remoteByCrKey[item.crKey] = item;
    }
  }

  // 3. cleanup066 (one-time deduplication)
  if (state['cleanup066'] != true) {
    try {
      var trashedFolders = 0;
      var trashedFiles = 0;
      Future<void> safeTrash(String tid) async {
        check();
        try {
          await api.trash(tid);
        } on DriveHttpFailure catch (e) {
          if (e.status != 404) rethrow;
        }
      }

      // Root duplicates cleanup: keep 1, trash others
      if (existingRoots.length > 1) {
        for (final dupRoot in existingRoots) {
          if (dupRoot.id != folder) {
            check();
            final dupChildren = await api.listChildren(dupRoot.id);
            for (final child in dupChildren) {
              check();
              if (child.isFolder) {
                final targetFolder = (await api.listChildren(
                  folder,
                  name: child.name,
                  folderOnly: true,
                )).firstOrNull;
                if (targetFolder != null) {
                  final grandChildren = await api.listChildren(child.id);
                  for (final grand in grandChildren) {
                    check();
                    if (!grand.isFolder) {
                      final dupFile = (await api.listChildren(
                        targetFolder.id,
                        name: grand.name,
                      )).firstOrNull;
                      if (dupFile != null && dupFile.size == grand.size) {
                        await safeTrash(grand.id);
                        trashedFiles++;
                      } else {
                        await api.updateMetadata(
                          grand.id,
                          addParents: [targetFolder.id],
                          removeParents: [child.id],
                        );
                      }
                    } else {
                      final subTarget = (await api.listChildren(
                        targetFolder.id,
                        name: grand.name,
                        folderOnly: true,
                      )).firstOrNull;
                      if (subTarget != null) {
                        final grandFiles = await api.listChildren(grand.id);
                        for (final gf in grandFiles) {
                          check();
                          final dupFile = (await api.listChildren(
                            subTarget.id,
                            name: gf.name,
                          )).firstOrNull;
                          if (dupFile != null && dupFile.size == gf.size) {
                            await safeTrash(gf.id);
                            trashedFiles++;
                          } else {
                            await api.updateMetadata(
                              gf.id,
                              addParents: [subTarget.id],
                              removeParents: [grand.id],
                            );
                          }
                        }
                        await safeTrash(grand.id);
                        trashedFolders++;
                      } else {
                        await api.updateMetadata(
                          grand.id,
                          addParents: [targetFolder.id],
                          removeParents: [child.id],
                        );
                      }
                    }
                  }
                  await safeTrash(child.id);
                  trashedFolders++;
                } else {
                  await api.updateMetadata(
                    child.id,
                    addParents: [folder],
                    removeParents: [dupRoot.id],
                  );
                }
              } else {
                final dupFile = (await api.listChildren(
                  folder,
                  name: child.name,
                )).firstOrNull;
                if (dupFile != null && dupFile.size == child.size) {
                  await safeTrash(child.id);
                  trashedFiles++;
                } else {
                  await api.updateMetadata(
                    child.id,
                    addParents: [folder],
                    removeParents: [dupRoot.id],
                  );
                }
              }
            }
            await safeTrash(dupRoot.id);
            trashedFolders++;
          }
        }
      }

      // Materials folder duplicate cleanup
      final matFolders = await api.listChildren(
        folder,
        name: '자료',
        folderOnly: true,
      );
      String? targetMat;
      if (matFolders.isNotEmpty) {
        final curMat = '${state['materialsFolder'] ?? ''}';
        final keptMat =
            (curMat.isNotEmpty && matFolders.any((m) => m.id == curMat))
                ? matFolders.firstWhere((m) => m.id == curMat)
                : _oldestItem(matFolders)!;
        state['materialsFolder'] = keptMat.id;
        targetMat = keptMat.id;
        for (final m in matFolders) {
          if (m.id != keptMat.id) {
            check();
            final cFolders = await api.listChildren(m.id, folderOnly: false) /* files too */;
            for (final cf in cFolders) {
              await api.updateMetadata(
                cf.id,
                addParents: [keptMat.id],
                removeParents: [m.id],
              );
            }
            await safeTrash(m.id);
            trashedFolders++;
          }
        }
      } else if ('${state['materialsFolder'] ?? ''}'.isNotEmpty &&
          await api.exists('${state['materialsFolder']}')) {
        targetMat = '${state['materialsFolder']}';
      }

      // Course folder deduplication & duplicate files cleanup (c: (2)~(9) duplicates)
      if (targetMat != null) {
        check();
        final courseFolders = await api.listChildren(
          targetMat,
          folderOnly: true,
        );
        final byCourse = <String, List<DriveItem>>{};
        for (final cf in courseFolders) {
          final normalized = DriveSyncLogic.safeCourseFolderName(cf.name);
          byCourse.putIfAbsent(normalized, () => []).add(cf);
        }
        for (final entry in byCourse.entries) {
          final cList = entry.value;
          final keptCourse = _oldestItem(cList)!;
          if (cList.length > 1) {
            for (final cf in cList) {
              if (cf.id != keptCourse.id) {
                check();
                final filesInDup = await api.listChildren(cf.id);
                for (final f in filesInDup) {
                  await api.updateMetadata(
                    f.id,
                    addParents: [keptCourse.id],
                    removeParents: [cf.id],
                  );
                }
                await safeTrash(cf.id);
                trashedFolders++;
              }
            }
          }
          check();
          final filesInCourse = (await api.listChildren(
            keptCourse.id,
            folderOnly: false,
          )).where((f) => !f.isFolder).toList();
          final byNormalizedName = <String, List<DriveItem>>{};
          for (final f in filesInCourse) {
            final norm = DriveSyncLogic.normalizeAttachmentFileName(f.name);
            byNormalizedName.putIfAbsent(norm, () => []).add(f);
          }
          for (final fGroup in byNormalizedName.values) {
            if (fGroup.length > 1) {
              final bySize = <int, List<DriveItem>>{};
              for (final f in fGroup) {
                bySize.putIfAbsent(f.size, () => []).add(f);
              }
              for (final subGroup in bySize.values) {
                if (subGroup.length > 1) {
                  final cleanName = DriveSyncLogic.normalizeAttachmentFileName(
                    subGroup.first.name,
                  );
                  final keptFile = subGroup.firstWhere(
                    (f) => f.name == cleanName,
                    orElse: () => _oldestItem(subGroup)!,
                  );
                  for (final f in subGroup) {
                    if (f.id != keptFile.id) {
                      await safeTrash(f.id);
                      trashedFiles++;
                    }
                  }
                }
              }
            }
          }
        }
      }

      state['cleanup066'] = true;
      state['cleanupCount'] = trashedFolders + trashedFiles;
      state['cleanedFolders'] = trashedFolders;
      state['cleanedFiles'] = trashedFiles;
      await checkpoint();
    } catch (_) {
      // Deduplication error does not abort main upload
    }
  }

  // 4. Term archiving & rollover
  final previousTerm = '${state['term'] ?? ''}';
  if (DriveSyncLogic.shouldArchiveSemester(previousTerm, term)) {
    final label = previousTerm;
    final tracked = state['files'] as Map<String, dynamic>?;
    const archivedZip = '캠퍼스레이더 첨부원본.zip';
    final archives = <String, String>{
      '${state['courseFolder'] ?? ''}':
          DriveSyncLogic.archivedCourseFolderName(label),
      '${state['materialsFolder'] ?? ''}':
          DriveSyncLogic.archivedMaterialsFolderName(label),
      '${tracked?[archivedZip] ?? ''}':
          DriveSyncLogic.archivedZipName(label),
    };
    for (final entry in archives.entries) {
      check();
      final resource = entry.key;
      final name = entry.value;
      if (resource.trim().isNotEmpty && await api.exists(resource)) {
        await api.rename(resource, name);
      }
    }
    final hashes = state['hashes'] as Map<String, dynamic>?;
    if (tracked != null) {
      for (final key in tracked.keys.toList()) {
        if (DriveSyncLogic.isSemesterScopedKey(key)) {
          tracked.remove(key);
          hashes?.remove(key);
        }
      }
    }
    state
      ..remove('courseFolder')
      ..remove('materialsFolder')
      ..remove('materialsCourses')
      ..['term'] = term;
    await checkpoint();
  } else if (previousTerm.trim().isEmpty && term.trim().isNotEmpty) {
    state['term'] = term;
    await checkpoint();
  }

  // Archived semesters keep their files' crKeys; drop everything inside an archive
  // folder (or its course subfolders) so the new semester never writes into it.
  {
    final archived = <String>{
      for (final f in await api.listChildren(folder, folderOnly: true))
        if (f.name.startsWith('지난 내보내기 (')) f.id,
    };
    for (final a in archived.toList()) {
      check();
      archived.addAll((await api.listChildren(a, folderOnly: true)).map((f) => f.id));
    }
    if (archived.isNotEmpty) {
      remoteByCrKey.removeWhere(
        (_, v) => archived.contains(v.id) || v.parents.any(archived.contains),
      );
    }
  }

  // 5. Course folder: reuse remoteByCrKey, find legacy or create
  var course =remoteByCrKey['course']?.id ?? '${state['courseFolder'] ?? ''}';
  if (course.isEmpty || !await api.exists(course)) {
    check();
    final existingCourses = await api.listChildren(
      folder,
      name: '과목',
      folderOnly: true,
    );
    final oldest = _oldestItem(existingCourses);
    if (oldest != null) {
      course = oldest.id;
      state['courseFolder'] = course;
      await api.updateMetadata(
        course,
        appProperties: DriveSyncLogic.buildAppProperties(
          kind: DriveSyncLogic.kindCourse,
          key: 'course',
        ),
      );
    } else {
      course = await api.id();
      state['courseFolder'] = course;
      await checkpoint();
      await api.createFolder(
        course,
        '과목',
        parent: folder,
        appProperties: DriveSyncLogic.buildAppProperties(
          kind: DriveSyncLogic.kindCourse,
          key: 'course',
        ),
      );
    }
    remoteByCrKey['course'] = DriveItem(
      id: course,
      name: '과목',
      createdTime: '',
      mimeType: 'application/vnd.google-apps.folder',
      appProperties: {'crKind': 'course', 'crKey': 'course'},
    );
    await checkpoint();
  }

  // 6. Materials folder & per-course materials folders
  var materials = remoteByCrKey['materials']?.id ?? '${state['materialsFolder'] ?? ''}';
  final materialsCourses = state['materialsCourses'] = Map<String, dynamic>.from(
    state['materialsCourses'] as Map? ?? {},
  );

  Future<String> ensureMaterialsFolder() async {
    if (materials.isEmpty || !await api.exists(materials)) {
      check();
      final existingMat = await api.listChildren(
        folder,
        name: '자료',
        folderOnly: true,
      );
      final oldest = _oldestItem(existingMat);
      if (oldest != null) {
        materials = oldest.id;
        state['materialsFolder'] = materials;
        await api.updateMetadata(
          materials,
          appProperties: DriveSyncLogic.buildAppProperties(
            kind: DriveSyncLogic.kindMaterials,
            key: 'materials',
          ),
        );
      } else {
        materials = await api.id();
        state['materialsFolder'] = materials;
        await checkpoint();
        await api.createFolder(
          materials,
          '자료',
          parent: folder,
          appProperties: DriveSyncLogic.buildAppProperties(
            kind: DriveSyncLogic.kindMaterials,
            key: 'materials',
          ),
        );
      }
      remoteByCrKey['materials'] = DriveItem(
        id: materials,
        name: '자료',
        createdTime: '',
        mimeType: 'application/vnd.google-apps.folder',
        appProperties: {'crKind': 'materials', 'crKey': 'materials'},
      );
      await checkpoint();
    }
    return materials;
  }

  Future<String> courseMaterialsFolder(String cName) async {
    final mat = await ensureMaterialsFolder();
    final safeC = DriveSyncLogic.safeCourseFolderName(cName);
    final courseMatKey = 'materials:$safeC';
    var cf = remoteByCrKey[courseMatKey]?.id ?? '${materialsCourses[cName] ?? ''}';
    if (cf.isEmpty || !await api.exists(cf)) {
      check();
      final existingCourseMat = await api.listChildren(
        mat,
        folderOnly: true,
      );
      var oldest = _oldestItem(
        existingCourseMat.where(
          (c) =>
              DriveSyncLogic.safeCourseFolderName(c.name) == safeC ||
              c.name.trim() == cName.trim(),
        ).toList(),
      );
      if (oldest != null) {
        cf = oldest.id;
        if (oldest.name != cName && oldest.name != safeC) {
          try {
            await api.rename(cf, cName);
          } catch (_) {}
        }
        await api.updateMetadata(
          cf,
          appProperties: DriveSyncLogic.buildAppProperties(
            kind: DriveSyncLogic.kindMaterials,
            key: courseMatKey,
          ),
        );
      } else {
        cf = await api.id();
        await checkpoint();
        await api.createFolder(
          cf,
          cName,
          parent: mat,
          appProperties: DriveSyncLogic.buildAppProperties(
            kind: DriveSyncLogic.kindMaterials,
            key: courseMatKey,
          ),
        );
      }
      materialsCourses[cName] = cf;
      remoteByCrKey[courseMatKey] = DriveItem(
        id: cf,
        name: cName,
        createdTime: '',
        mimeType: 'application/vnd.google-apps.folder',
        appProperties: {'crKind': 'materials', 'crKey': courseMatKey},
      );
      await checkpoint();
    }
    return cf;
  }

  Future<String> attachmentFolder(String courseName, Map entry) async {
    final parent = await courseMaterialsFolder(courseName);
    if (entry['section'] != 'freeboard') return parent;
    final key = 'materials:${DriveSyncLogic.safeCourseFolderName(courseName)}:freeboard';
    final cached = remoteByCrKey[key];
    if (cached != null && await api.exists(cached.id)) return cached.id;
    check();
    final existing = _oldestItem(await api.listChildren(parent, name: '자유게시판', folderOnly: true));
    final id = existing?.id ?? await api.id();
    final props = DriveSyncLogic.buildAppProperties(kind: DriveSyncLogic.kindMaterials, key: key);
    if (existing == null) {
      await api.createFolder(id, '자유게시판', parent: parent, appProperties: props);
    } else {
      await api.updateMetadata(id, appProperties: props);
    }
    remoteByCrKey[key] = DriveItem(id: id, name: '자유게시판', createdTime: '',
        mimeType: 'application/vnd.google-apps.folder', appProperties: props);
    return id;
  }

  if (state['cleanup066c'] != true) {
    final cleaned = await cleanupUnknownSemesterArchives(
      api: api, root: folder, courseRoot: course,
      courseMaterialsFolder: courseMaterialsFolder, check: check,
    );
    state['cleanupCount'] = (state['cleanupCount'] as int? ?? 0) + cleaned.folders + cleaned.files;
    state['cleanedFolders'] = (state['cleanedFolders'] as int? ?? 0) + cleaned.folders;
    state['cleanedFiles'] = (state['cleanedFiles'] as int? ?? 0) + cleaned.files;
    state['cleanup066c'] = true;
    await checkpoint();
  }

  final files = state['files'] = Map<String, dynamic>.from(
    state['files'] as Map? ?? {},
  );
  final hashes = state['hashes'] = Map<String, dynamic>.from(
    state['hashes'] as Map? ?? {},
  );

  final docNames = documents.keys.where((n) => n != startDocument).toList();

  // Key migration: if an old 0.6.5 key exists in files/hashes, migrate it to the new 0.6.6 key
  // so existing files are reused instead of being trashed and recreated.
  for (final name in fileEntries.keys) {
    if (!files.containsKey(name)) {
      final entry = fileEntries[name];
      if (entry is Map) {
        final newHash = '${entry['sha256'] ?? ''}';
        String? matchingOldKey;
        for (final oldKey in files.keys) {
          if (oldKey.startsWith('자료/') && !fileEntries.containsKey(oldKey)) {
            final oldHash = '${hashes[oldKey] ?? ''}';
            if (DriveSyncLogic.isLegacyMatchingKey(oldKey, name, oldHash, newHash)) {
              matchingOldKey = oldKey;
              break;
            }
          }
        }
        if (matchingOldKey != null) {
          final oldFid = files[matchingOldKey];
          final oldHash = hashes[matchingOldKey];
          files[name] = oldFid;
          if (oldHash != null && '$oldHash'.isNotEmpty) hashes[name] = oldHash;
          files.remove(matchingOldKey);
          hashes.remove(matchingOldKey);
          await checkpoint();
        }
      }
    }
  }
  for (final name in docNames) {
    if (!files.containsKey(name) && name.startsWith('과목/')) {
      final fName = name.split('/').last;
      String? matchingOldKey;
      for (final oldKey in files.keys) {
        if (oldKey.startsWith('과목/') && !documents.containsKey(oldKey)) {
          final oldFName = oldKey.split('/').last;
          if (DriveSyncLogic.safeCourseFolderName(oldFName.replaceAll('.txt', '')) ==
              fName.replaceAll('.txt', '')) {
            matchingOldKey = oldKey;
            break;
          }
        }
      }
      if (matchingOldKey != null) {
        final oldFid = files[matchingOldKey];
        final oldHash = hashes[matchingOldKey];
        files[name] = oldFid;
        if (oldHash != null && '$oldHash'.isNotEmpty) hashes[name] = oldHash;
        files.remove(matchingOldKey);
        hashes.remove(matchingOldKey);
        await checkpoint();
      }
    }
  }

  var writes = 0;
  var complete = true;

  // 7. Upload documents (except start document)
  for (final name in docNames) {
    check();
    final text = documents[name]!;
    final hash = DriveApi.digest(text);
    final docKey = DriveSyncLogic.documentKey(name);
    var remote = remoteByCrKey[docKey];

    if (remote == null) {
      final parent = name.startsWith('과목/') ? course : folder;
      final fileName = name.split('/').last;
      final existingDocs = (await api.listChildren(
        parent,
        name: fileName,
        folderOnly: false,
      )).where((d) => !d.isFolder).toList();
      final oldest = _oldestItem(existingDocs);
      if (oldest != null) {
        final isSameSize = oldest.size == utf8.encode(text).length;
        final adoptedHash = isSameSize ? hash : (oldest.crHash.isNotEmpty ? oldest.crHash : '');
        final adoptedProps = DriveSyncLogic.buildAppProperties(
          kind: DriveSyncLogic.kindFile,
          key: docKey,
          hash: adoptedHash,
        );
        await api.updateMetadata(oldest.id, appProperties: adoptedProps);
        remote = DriveItem(
          id: oldest.id,
          name: fileName,
          createdTime: oldest.createdTime,
          mimeType: oldest.mimeType,
          size: oldest.size,
          appProperties: adoptedProps,
        );
        remoteByCrKey[docKey] = remote;
      }
    }

    if (remote != null) {
      if (remote.crHash == hash) {
        files[name] = remote.id;
        hashes[name] = hash;
        continue;
      }
      if (writes >= maxWrites) {
        complete = false;
        break;
      }
      check();
      if (name.endsWith('.zip')) {
        await api.writeBytes(remote.id, base64Decode(text), 'application/zip');
      } else {
        await api.write(remote.id, text);
      }
      final newProps = DriveSyncLogic.buildAppProperties(
        kind: DriveSyncLogic.kindFile,
        key: docKey,
        hash: hash,
      );
      await api.updateMetadata(remote.id, appProperties: newProps);
      files[name] = remote.id;
      hashes[name] = hash;
      remoteByCrKey[docKey] = DriveItem(
        id: remote.id,
        name: remote.name,
        createdTime: remote.createdTime,
        mimeType: remote.mimeType,
        size: utf8.encode(text).length,
        appProperties: newProps,
      );
      await checkpoint();
      writes++;
    } else {
      if (writes >= maxWrites) {
        complete = false;
        break;
      }
      check();
      final parent = name.startsWith('과목/') ? course : folder;
      final fileName = name.split('/').last;
      final id = await api.id();
      final appProps = DriveSyncLogic.buildAppProperties(
        kind: DriveSyncLogic.kindFile,
        key: docKey,
        hash: hash,
      );
      if (name.endsWith('.zip')) {
        await api.createFile(
          id,
          fileName,
          parent,
          'application/zip',
          appProperties: appProps,
        );
        await api.writeBytes(id, base64Decode(text), 'application/zip');
        await api.updateMetadata(id, appProperties: appProps);
      } else {
        await api.createText(
          id,
          fileName,
          parent,
          appProperties: appProps,
        );
        await api.write(id, text);
        await api.updateMetadata(id, appProperties: appProps);
      }
      files[name] = id;
      hashes[name] = hash;
      remoteByCrKey[docKey] = DriveItem(
        id: id,
        name: fileName,
        createdTime: '',
        mimeType: 'text/plain',
        size: utf8.encode(text).length,
        appProperties: appProps,
      );
      await checkpoint();
      writes++;
    }
  }

  // 8. Upload material originals (fileEntries)
  if (complete && writes < maxWrites) {
    final fileNames = fileEntries.keys.toList()..sort();
    for (final name in fileNames) {
      check();
      final entry = fileEntries[name];
      if (entry is! Map) continue;
      List<int>? bytes;
      if (entry['bytes'] is List<int>) {
        bytes = entry['bytes'] as List<int>;
      } else {
        final localPath = '${entry['path'] ?? ''}';
        if (localPath.isNotEmpty) {
          final localFile = File(localPath);
          if (localFile.existsSync()) {
            bytes = await localFile.readAsBytes();
          }
        }
      }
      if (bytes == null) continue;
      final hash = '${entry['sha256'] ?? ''}';
      final mime = '${entry['mime'] ?? 'application/octet-stream'}';
      final courseName = name.substring('자료/'.length).split('/').first;
      final fileName = name.split('/').last;
      final attKey = '${entry['crKey'] ?? ''}'.isNotEmpty
          ? '${entry['crKey']}'
          : DriveSyncLogic.attachmentKey(
              course: courseName,
              fileName: fileName,
              attachmentId: entry['attachmentId']?.toString(),
            );
      var remote = remoteByCrKey[attKey];

      if (remote == null && files.containsKey(name)) {
        final trackedId = '${files[name]}';
        if (trackedId.isNotEmpty && await api.exists(trackedId)) {
          final adoptedProps = DriveSyncLogic.buildAppProperties(
            kind: DriveSyncLogic.kindFile,
            key: attKey,
            hash: hash,
          );
          await api.updateMetadata(trackedId, appProperties: adoptedProps);
          remote = DriveItem(
            id: trackedId,
            name: fileName,
            createdTime: '',
            mimeType: mime,
            size: bytes.length,
            appProperties: adoptedProps,
          );
          remoteByCrKey[attKey] = remote;
        }
      }

      if (remote == null) {
        final parent = await attachmentFolder(courseName, entry);
        final allFilesInParent = (await api.listChildren(
          parent,
          folderOnly: false,
        )).where((f) => !f.isFolder).toList();
        final cleanTarget = DriveSyncLogic.safeAttachmentFileName(
          DriveSyncLogic.normalizeAttachmentFileName(fileName),
        );
        // A name with " (n)" is a distinct attachment: exact match only. Never take a
        // file another key owns, so same-size different attachments are not renamed/trashed.
        final hasSuffix = DriveSyncLogic.normalizeAttachmentFileName(fileName) != fileName;
        final matchingLegacy = allFilesInParent.where((f) =>
          (f.crKey.isEmpty || f.crKey == attKey) &&
          f.size == bytes!.length &&
          (f.name == fileName ||
           (!hasSuffix &&
            DriveSyncLogic.safeAttachmentFileName(DriveSyncLogic.normalizeAttachmentFileName(f.name)) == cleanTarget))
        ).toList();
        if (matchingLegacy.isNotEmpty) {
          final adopted = matchingLegacy.firstWhere(
            (f) => f.name == fileName,
            orElse: () => _oldestItem(matchingLegacy)!,
          );
          if (adopted.name != fileName) {
            try { await api.rename(adopted.id, fileName); } catch (_) {}
          }
          final adoptedProps = DriveSyncLogic.buildAppProperties(
            kind: DriveSyncLogic.kindFile,
            key: attKey,
            hash: hash,
          );
          await api.updateMetadata(adopted.id, appProperties: adoptedProps);
          for (final dup in matchingLegacy) {
            if (dup.id != adopted.id) {
              try { await api.trash(dup.id); } catch (_) {}
            }
          }
          remote = DriveItem(
            id: adopted.id,
            name: fileName,
            createdTime: adopted.createdTime,
            mimeType: mime,
            size: adopted.size,
            appProperties: adoptedProps,
          );
          remoteByCrKey[attKey] = remote;
        }
      }

      if (remote != null) {
        if (remote.crHash == hash) {
          files[name] = remote.id;
          hashes[name] = hash;
          continue;
        }
        if (writes >= maxWrites) {
          complete = false;
          break;
        }
        check();
        await api.writeBytes(remote.id, bytes, mime);
        final newProps = DriveSyncLogic.buildAppProperties(
          kind: DriveSyncLogic.kindFile,
          key: attKey,
          hash: hash,
        );
        await api.updateMetadata(remote.id, appProperties: newProps);
        files[name] = remote.id;
        hashes[name] = hash;
        remoteByCrKey[attKey] = DriveItem(
          id: remote.id,
          name: remote.name,
          createdTime: remote.createdTime,
          mimeType: mime,
          size: bytes.length,
          appProperties: newProps,
        );
        await checkpoint();
        writes++;
      } else {
        if (writes >= maxWrites) {
          complete = false;
          break;
        }
        check();
        final parent = await attachmentFolder(courseName, entry);
        final fid = await api.id();
        final appProps = DriveSyncLogic.buildAppProperties(
          kind: DriveSyncLogic.kindFile,
          key: attKey,
          hash: hash,
        );
        await api.createFile(
          fid,
          fileName,
          parent,
          mime,
          appProperties: appProps,
        );
        await api.writeBytes(fid, bytes, mime);
        await api.updateMetadata(fid, appProperties: appProps);
        files[name] = fid;
        hashes[name] = hash;
        remoteByCrKey[attKey] = DriveItem(
          id: fid,
          name: fileName,
          createdTime: '',
          mimeType: mime,
          size: bytes.length,
          appProperties: appProps,
        );
        await checkpoint();
        writes++;
      }
    }
  }

  // 9. Start document
  if (complete && writes < maxWrites && documents.containsKey(startDocument)) {
    final name = startDocument;
    check();
    final text = documents[name]!;
    final hash = DriveApi.digest(text);
    final docKey = DriveSyncLogic.documentKey(name);
    var remote = remoteByCrKey[docKey];

    if (remote == null) {
      final existingStart = (await api.listChildren(
        folder,
        name: name,
        folderOnly: false,
      )).where((s) => !s.isFolder).toList();
      final oldest = _oldestItem(existingStart);
      if (oldest != null) {
        final isSameSize = oldest.size == utf8.encode(text).length;
        final adoptedHash = isSameSize ? hash : (oldest.crHash.isNotEmpty ? oldest.crHash : '');
        final adoptedProps = DriveSyncLogic.buildAppProperties(
          kind: DriveSyncLogic.kindFile,
          key: docKey,
          hash: adoptedHash,
        );
        await api.updateMetadata(oldest.id, appProperties: adoptedProps);
        remote = DriveItem(
          id: oldest.id,
          name: name,
          createdTime: oldest.createdTime,
          mimeType: oldest.mimeType,
          size: oldest.size,
          appProperties: adoptedProps,
        );
        remoteByCrKey[docKey] = remote;
      }
    }

    if (remote != null) {
      if (remote.crHash != hash) {
        check();
        await api.write(remote.id, text);
        final newProps = DriveSyncLogic.buildAppProperties(
          kind: DriveSyncLogic.kindFile,
          key: docKey,
          hash: hash,
        );
        await api.updateMetadata(remote.id, appProperties: newProps);
        files[name] = remote.id;
        hashes[name] = hash;
        remoteByCrKey[docKey] = DriveItem(
          id: remote.id,
          name: remote.name,
          createdTime: remote.createdTime,
          mimeType: remote.mimeType,
          size: utf8.encode(text).length,
          appProperties: newProps,
        );
        await checkpoint();
        writes++;
      } else {
        files[name] = remote.id;
        hashes[name] = hash;
      }
    } else {
      check();
      final fid = await api.id();
      final appProps = DriveSyncLogic.buildAppProperties(
        kind: DriveSyncLogic.kindFile,
        key: docKey,
        hash: hash,
      );
      await api.createText(fid, name, folder, appProperties: appProps);
      await api.write(fid, text);
      await api.updateMetadata(fid, appProperties: appProps);
      files[name] = fid;
      hashes[name] = hash;
      remoteByCrKey[docKey] = DriveItem(
        id: fid,
        name: name,
        createdTime: '',
        mimeType: 'text/plain',
        size: utf8.encode(text).length,
        appProperties: appProps,
      );
      await checkpoint();
      writes++;
    }
  } else if (documents.containsKey(startDocument) &&
      (!complete || writes >= maxWrites)) {
    complete = false;
  }

  // 10. Only app-owned tracked files removed from the export are trashed.
  // A renamed key can share its Drive file with a live key; never trash that file.
  final liveIds = {
    for (final k in files.keys)
      if (documents.containsKey(k) || fileEntries.containsKey(k)) '${files[k]}',
  };
  for (final old in files.keys.toList()) {
    if (documents.containsKey(old) || fileEntries.containsKey(old)) continue;
    // Attachment originals come only from the evictable device cache: a missing
    // entry is not a deletion. Keep the Drive copy and its tracking.
    if (old.startsWith('자료/')) continue;
    check();
    if (liveIds.contains('${files[old]}')) {
      files.remove(old);
      hashes.remove(old);
      await checkpoint();
      continue;
    }
    try {
      await api.trash('${files[old]}');
    } on DriveHttpFailure catch (e) {
      if (e.status != 404) rethrow;
    }
    files.remove(old);
    hashes.remove(old);
    await checkpoint();
  }

  return (writes: writes, complete: complete);
}

// Drive's 'has' needs both key and value; a key-only query is HTTP 400.
const driveRemoteQuery = "trashed=false and (appProperties has { key='crKind' and value='root' } or appProperties has { key='crKind' and value='term' } or appProperties has { key='crKind' and value='course' } or appProperties has { key='crKind' and value='materials' } or appProperties has { key='crKind' and value='file' })";

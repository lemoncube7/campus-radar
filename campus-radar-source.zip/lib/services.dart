import 'native_contract.dart';
import 'background_contract.dart';
import 'app_storage.dart';
import 'native_bridge.dart';
import 'app_credentials.dart';
import 'notification_gateway.dart';
import 'course_aliases.dart';
import 'course_labels.dart';
import 'campus_models.dart';
import 'session_scope.dart';
import 'updates.dart';
import 'network_resilience.dart';
import 'ios_features.dart';
import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:workmanager/workmanager.dart';
import 'campus.dart';
import 'media_cache.dart';
import 'campus_media.dart';
import 'ai_automation.dart';

Future<void> collectCampusMedia(
  Store store,
  CampusClient client,
  String account,
) async {
  final scope = await SessionScope.capture(store);
  final cache = await MediaCache.open(account);
  final clock = Stopwatch()..start();
  var bytes = 0, saved = 0, failed = 0;
  Future<void> collect(List<CampusMedia> media) async {
    for (final m in media) {
      if (clock.elapsed.inSeconds >= 60 || bytes >= 100 * 1024 * 1024) break;
      if (await credentials.read(key: 'id') != account) return;
      if (!m.supported || await cache.local(m) != null) continue;
      if ((m.size ?? 0) > 50 * 1024 * 1024) continue;
      try {
        final f = await cache.fetch(client, m);
        bytes += await f.length();
        saved++;
      } catch (_) {
        failed++;
      }
    }
  }

  for (final item in await store.items()) {
    if (item.type == 'LR' && item.availableAt(DateTime.now())) {
      await collect(item.media);
    }
  }
  // Oldest checked first: a bounded batch eventually covers all notices, not just the newest.
  final notices = await store.notices();
  final checked = <String, String>{};
  for (final n in notices) {
    checked[n.id] = await store.meta('mediaChecked:${n.id}') ?? '';
  }
  notices.sort((a, b) => checked[a.id]!.compareTo(checked[b.id]!));
  var fetched = 0;
  for (var n in notices) {
    if (clock.elapsed.inSeconds >= 60 || fetched >= 12) break;
    if (await credentials.read(key: 'id') != account) return;
    final stamp = DateTime.tryParse(checked[n.id]!);
    if (!n.bodyFetched ||
        n.bodyHtml.isEmpty ||
        stamp == null ||
        DateTime.now().toUtc().difference(stamp) > const Duration(hours: 6)) {
      fetched++;
      try {
        n = await client.fetchNoticeBody(n);
        await scope.verify();
        await store.saveNotice(n);
        await store.setMeta(
          'mediaChecked:${n.id}',
          DateTime.now().toUtc().toIso8601String(),
        );
      } catch (_) {
        failed++;
        await store.setMeta(
          'mediaChecked:${n.id}',
          DateTime.now().toUtc().toIso8601String(),
        );
        continue;
      }
    }
    await collect(n.media);
  }
  await store.log(
    'received',
    '이미지·첨부파일 수집',
    '새 저장 $saved개 · 실패 $failed개 · 공지 본문 확인 $fetched개 · ${(bytes / 1024 / 1024).toStringAsFixed(1)}MB\n파일당 50MB, 회차당 약 100MB·60초, 계정별 캐시 300MB. 남은 항목은 다음 수집 또는 상세 화면에서 이어받습니다.',
  );
}

Future<void> reconcile(Store store) async {
  final items = await store.items();
  final excluded = await store.excluded();
  final prefs = await SharedPreferences.getInstance();
  final old = prefs.getStringList('scheduled') ?? [];
  final desired = <String>[];
  var iosFutureCount = 0;
  final android = notifications
      .resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin
      >();
  final desktop = Platform.isWindows && android == null;
  final permitted = desktop
      ? (prefs.getBool('desktopNotifications') ?? true)
      : Platform.isIOS
      ? (await notifications
                    .resolvePlatformSpecificImplementation<
                      IOSFlutterLocalNotificationsPlugin
                    >()
                    ?.checkPermissions())
                ?.isEnabled ??
            false
      : await android?.areNotificationsEnabled() ?? false;
  final now = DateTime.now().toUtc();
  final permissionState = permitted ? 'yes' : 'no';
  if (await store.meta('notificationPermission') != permissionState) {
    await store.log(
      'notification',
      permitted ? '알림 권한 허용' : '알림 권한 꺼짐',
      permitted ? '알림 발송·예약을 진행합니다.' : '권한을 허용하기 전에는 알림을 표시하지 못합니다.',
    );
    await store.setMeta('notificationPermission', permissionState);
  }
  for (final item in items) {
    if ((item.attendanceRequired == false &&
            await store.meta('notifyNonAttendance') == 'no') ||
        !item.availableAt(now) ||
        excluded.contains(item.key) ||
        item.status != 'pending' ||
        item.due == null ||
        !item.due!.isAfter(now)) {
      continue;
    }
    final token = 'due:${item.key}:${item.due!.toIso8601String()}';
    final at = item.due!.subtract(const Duration(days: 1));
    // A passed trigger is still valid until the task is completed or expires.
    // Cancelling here also removes an already displayed Android notification.
    if (Platform.isIOS && at.isAfter(now)) {
      if (iosFutureCount >= 32) continue;
      iosFutureCount++;
    }
    desired.add(token);
    if (at.isAfter(now)) {
      if (desktop) continue;
      // iOS retains at most 64 pending notifications; reserve 24 class/midnight and seven daily notifications; keep the nearest 32.
      if (permitted) {
        final wasScheduled = await store.meta(token) == 'scheduled';
        await notifications.zonedSchedule(
          notificationId(token),
          '${item.type == 'LR' ? '과제' : '콘텐츠'} 마감 하루 전',
          '${courseLabel(item.course)} · ${item.title}',
          tz.TZDateTime.from(at, tz.UTC),
          noticeStyle,
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          payload: item.key,
        );
        await store.setMeta(token, 'scheduled');
        if (!wasScheduled) {
          await store.log(
            'notification',
            '마감 알림 예약',
            '${courseLabel(item.course)} · ${item.title}\n예정: ${koreanTime(at)}',
          );
        }
      }
    } else if (permitted &&
        await store.meta(token) != 'sent' &&
        (await store.meta(token) != 'scheduled' || !old.contains(token))) {
      // Older versions discarded passed reservations from `scheduled` and
      // cancelled them. Recover those once; retained reservations must not
      // cause another notification on every collection.
      await notifications.show(
        notificationId(token),
        '마감까지 하루 이내입니다',
        '${courseLabel(item.course)} · ${item.title}',
        noticeStyle,
        payload: item.key,
      );
      await store.setMeta(token, 'sent');
      await store.log(
        'notification',
        '마감 임박 알림 발송 요청',
        '${courseLabel(item.course)} · ${item.title}',
      );
    }
  }
  for (final token in old.where((t) => !desired.contains(t))) {
    await notifications.cancel(notificationId(token));
    await store.log(
      'notification',
      '마감 알림 예약 취소',
      '완료·마감 변경·제외 등의 이유로 기존 예약을 취소했습니다.',
    );
  }
  await prefs.setStringList('scheduled', desired);
  if (permitted) {
    for (final event in await store.db.query('events', where: 'delivered=0')) {
      final data =
          jsonDecode(event['payload'] as String) as Map<String, dynamic>;
      if (data['kind'] == 'notice') {
        final notice = CampusNotice.fromJson(
          Map<String, dynamic>.from(data['notice']),
        );
        if ((await store.notices()).any((n) => n.id == notice.id)) {
          await notifications.show(
            notificationId(event['id'] as String),
            '새 공지가 등록됐어요',
            '${courseLabel(notice.course)} · ${notice.title}',
            noticeStyle,
            payload: 'NOTICE:${notice.id}',
          );
          await store.log(
            'notification',
            '새 공지 알림 발송 요청',
            '${courseLabel(notice.course)} · ${notice.title}',
          );
        }
        await store.db.update(
          'events',
          {'delivered': 1},
          where: 'id=?',
          whereArgs: [event['id']],
        );
        continue;
      }
      final changed = data['kind'] == 'change';
      final original = CampusItem.fromJson(
        Map<String, dynamic>.from(changed ? data['item'] : data),
      );
      final item = items.where((i) => i.key == original.key).firstOrNull;
      if (item == null ||
          !item.availableAt(now) ||
          excluded.contains(item.key)) {
        await store.db.update(
          'events',
          {'delivered': 1},
          where: 'id=?',
          whereArgs: [event['id']],
        );
        continue;
      }
      await notifications.show(
        notificationId(event['id'] as String),
        changed ? '과제·콘텐츠 정보가 변경됐어요' : '새 과제가 등록됐어요',
        changed
            ? '${courseLabel(item.course)} · ${item.title}\n${(data['detail'] as String).split('\n').first}'
            : '${courseLabel(item.course)} · ${item.title}',
        noticeStyle,
        payload: item.key,
      );
      await store.log(
        'notification',
        changed ? '변경 알림 발송 요청' : '새 과제 알림 발송 요청',
        changed
            ? '${courseLabel(item.course)} · ${item.title}\n${data['detail']}'
            : '${courseLabel(item.course)} · ${item.title}',
      );
      await store.db.update(
        'events',
        {'delivered': 1},
        where: 'id=?',
        whereArgs: [event['id']],
      );
    }
  }
  if (Platform.isIOS) await refreshIosFeatures(store);
  if (Platform.isAndroid) {
    try {
      await bridge.invokeNative(NativeMethod.refreshWidget);
    } on MissingPluginException {
      /* Worker completion refreshes native widgets. */
    }
  }
}

Future<void> excludeItem(CampusItem item, bool exclude) async {
  final store = await Store.open();
  try {
    await store.setTaskExcluded(item.key, exclude);
    await store.log(
      'received',
      exclude ? '목록에서 제외' : '목록에 복구',
      '${courseLabel(item.course)} · ${item.title}',
    );
    if (exclude) {
      await notifications.cancel(notificationId('new:${item.key}'));
      if (item.due != null) {
        await notifications.cancel(
          notificationId('due:${item.key}:${item.due!.toIso8601String()}'),
        );
        await store.setMeta(
          'due:${item.key}:${item.due!.toIso8601String()}',
          '',
        );
      }
    }
    await reconcile(store);
  } finally {
    await store.db.close();
  }
}

enum SyncOutcome { completed, busy, noCredentials, accountChanged }

String diagnosticFailure(Object e) {
  if (e is HttpStatusError) return networkFailureMessage(e);
  if (e is CampusException) return e.message;
  if (e is PlatformException) return '기기 기능 오류 (${e.code})';
  if (e is SocketException) {
    return '네트워크 연결 오류 (${e.osError?.errorCode ?? '미확인'})';
  }
  if (e is HandshakeException) return 'HTTPS 연결을 확인하지 못했습니다.';
  if (e is TimeoutException) return '요청 시간이 초과됐습니다.';
  if (e is FormatException) return '응답 데이터 형식이 예상과 다릅니다.';
  return '처리 오류 (${e.runtimeType})';
}

Future<SyncOutcome> synchronize({
  String source = '앱에서 확인',
  void Function(String)? onPhase,
}) async {
  final store = await Store.open();
  final locked = await store.acquire();
  if (!locked) {
    await store.log(
      'sync',
      '[$source] 수집 대기',
      '다른 수집이 진행 중입니다. 백그라운드 작업이면 재시도합니다.',
    );
    await store.db.close();
    return SyncOutcome.busy;
  }
  var route = '연결 준비';
  var networkRetries = 0;
  final client = CampusClient(
    diagnostic: (line) {
      if (line.startsWith('API ')) route = line.substring(4);
      if (line.startsWith('Retry ')) networkRetries++;
    },
  );
  var phase = '계정 읽기';
  SessionScope? scope;
  Timer? sessionWatch;
  final budget = Timer(const Duration(minutes: 7), client.close);
  try {
    scope = await SessionScope.capture(store);
    sessionWatch = scope.watch(client.close);
    await loadCourseAliases();
    final id = await credentials.read(key: 'id');
    final pw = await credentials.read(key: 'pw');
    if (id == null || pw == null) {
      await store.log('sync', '[$source] 수집 건너뜀', '저장된 계정이 없습니다.');
      return SyncOutcome.noCredentials;
    }
    await store.log('sync', '[$source] 수집 시작', '포털에 새로 로그인해 과제·콘텐츠·공지를 확인합니다.');
    phase = '포털 로그인';
    onPhase?.call('포털 로그인');
    await client.login(id, pw);
    await store.log('sync', '[$source] 로그인 성공', '과제·콘텐츠를 수집합니다.');
    phase = '과제·콘텐츠 수집';
    onPhase?.call('과제·콘텐츠 수집');
    final items = await client.fetchItems(
      onCourses: (courses) async {
        if (await credentials.read(key: 'id') != id) {
          throw CampusException('계정이 변경되어 과목 저장을 중지했습니다.');
        }
        await scope!.verify();
        await store.setMeta('courses', jsonEncode(courses));
        await store.log(
          'sync',
          '수강 과목 목록 저장',
          '${courses.length}과목 · 과제 수집과 별도 저장',
        );
      },
    );
    if (await credentials.read(key: 'id') != id) {
      return SyncOutcome.accountChanged;
    }
    phase = '목록 저장';
    onPhase?.call('목록 저장');
    await scope.verify();
    await store.replace(items);
    await store.setMeta('courses', jsonEncode(client.courseList));
    for (final item in items) {
      await store.log(
        'received',
        item.type == 'LR' ? '과제 수집' : '콘텐츠 수집',
        '${courseLabel(item.course)} · ${item.title}\n상태: ${item.done
            ? '완료'
            : item.status == 'pending'
            ? '미완료'
            : '확인 불가'} · 마감: ${item.due == null ? '미확인' : koreanTime(item.due!)}',
      );
    }
    try {
      onPhase?.call('공지 수집');
      final notices = await client.fetchNotices();
      if (await credentials.read(key: 'id') != id) {
        return SyncOutcome.accountChanged;
      }
      await scope.verify();
      await store.replaceNotices(notices);
      await store.setMeta('noticeError', '');
      for (final notice in notices) {
        await store.log(
          'received',
          '공지 수집',
          '${courseLabel(notice.course)} · ${notice.title}',
        );
      }
      await store.log(
        'sync',
        '[$source] 목록 수집 완료',
        '과제 ${items.where((i) => i.type == 'LR').length}개 · 콘텐츠 ${items.where((i) => i.type == 'LV').length}개 · 공지 ${notices.length}개',
      );
    } catch (e) {
      final message = '${diagnosticFailure(e)} 마지막 공지 목록을 유지합니다.';
      await store.setMeta('noticeError', message);
      await store.log('sync', '공지 수집 실패', '$message\n과제·콘텐츠 결과는 저장했습니다.');
    }
    await scope.verify();
    phase = '알림 처리';
    onPhase?.call('알림 처리');
    await reconcile(store);
    if (Platform.isAndroid) {
      onPhase?.call('이미지·첨부파일 수집');
      try {
        await collectCampusMedia(store, client, id);
      } catch (_) {
        await store.log(
          'sync',
          '이미지·첨부 수집 대기',
          '과제·공지 목록과 알림은 저장했습니다. 상세 화면에서 다시 시도할 수 있습니다.',
        );
      }
    }
    await store.log(
      'sync',
      '[$source] 처리 완료',
      '수집 결과 저장과 알림 처리를 마쳤습니다. 통신 재시도 $networkRetries회.',
    );
    try {
      await aiAfterSync(store);
    } catch (_) {
      await store.log('ai', 'AI 작업 예약 대기', '다음 수집 또는 AI 일정함에서 다시 시도합니다.');
    }
    return SyncOutcome.completed;
  } catch (e) {
    await store.log(
      'sync',
      '[$source] 수집 또는 알림 처리 실패',
      '$phase 단계: ${diagnosticFailure(e)}\n실패 종류: ${e.runtimeType}\n마지막 요청: $route · 통신 재시도 $networkRetries회',
    );
    await store.setMeta('lastError', '$phase: ${diagnosticFailure(e)}');
    rethrow;
  } finally {
    if (Platform.isAndroid) {
      try {
        await checkForUpdates(store);
      } catch (_) {
        /* Update checks never fail collection. */
      }
    }
    budget.cancel();
    sessionWatch?.cancel();
    client.close();
    try {
      await store.releaseLease();
    } finally {
      await store.db.close();
    }
  }
}

Future<void> logNotification(String title, String detail) async {
  final store = await Store.open();
  try {
    await store.log('notification', title, detail);
  } finally {
    await store.db.close();
  }
}

@pragma('vm:entry-point')
void backgroundDispatcher() {
  Workmanager().executeTask((task, data) async {
    if (Platform.isIOS) setIosAiActive(false);
    if (task == aiWorkTask) {
      await processAiWork();
      if (data?['summaryWarmup'] == true) {
        final p = await SharedPreferences.getInstance();
        await p.reload();
        await scheduleSummaryWarmup(
          p.getInt('aiDailyHour') ?? 18,
          p.getInt('aiDailyMinute') ?? 0,
          p.getBool('aiDailyEnabled') ?? false,
        );
      }
      return true;
    }
    Store? trace;
    try {
      trace = await Store.open();
      await trace.setMeta(
        'workerStarted',
        DateTime.now().toUtc().toIso8601String(),
      );
      await trace.log('sync', '백그라운드 작업 진입', '운영체제가 자동 수집 코드를 실행했습니다.');
      await initNotifications().timeout(const Duration(seconds: 20));
      await trace.log('sync', '백그라운드 알림 초기화 완료', '계정 확인과 수집을 시작합니다.');
      final outcome = await synchronize(
        source: data?['source'] == 'trial' ? '백그라운드 시험' : '백그라운드 자동',
      );
      if (outcome == SyncOutcome.busy) {
        await trace.log('sync', '백그라운드 재시도 요청', '다른 수집과 겹쳐 운영체제에 재시도를 요청했습니다.');
        return false;
      }
      if (outcome == SyncOutcome.completed) {
        await trace.setMeta(
          'workerSource',
          data?['source'] == 'trial' ? '시험' : '정기 자동',
        );
        await trace.setMeta(
          'workerSuccess',
          DateTime.now().toUtc().toIso8601String(),
        );
      }
      return true;
    } catch (e) {
      final retry = e is! CampusLoginRejected;
      if (trace != null) {
        await trace.log(
          'sync',
          '백그라운드 작업 실패',
          !retry
              ? '학교 로그인이 거절됐습니다. 앱에서 계정을 확인해 주세요. 즉시 자동 재시도하지 않습니다.'
              : e is PlatformException
              ? '기기 기능 오류: ${e.code}. 운영체제에 재시도를 요청합니다.'
              : '실패 종류: ${e.runtimeType}. 운영체제에 재시도를 요청합니다.',
        );
      }
      return !retry;
    } finally {
      await trace?.db.close();
    }
  });
}

Future<void> registerBackground() async {
  if (Platform.isWindows) return;
  await Workmanager().registerPeriodicTask(
    periodicTask,
    periodicTask,
    frequency: const Duration(hours: 1),
    existingWorkPolicy: ExistingPeriodicWorkPolicy.keep,
    constraints: Constraints(networkType: NetworkType.connected),
  );
  final store = await Store.open();
  try {
    await store.log(
      'sync',
      '자동 수집 예약 확인',
      '1시간 주기 작업을 유지합니다. 실제 실행 시각은 운영체제와 네트워크 조건에 따라 지연될 수 있습니다.',
    );
  } finally {
    await store.db.close();
  }
}

Future<void> scheduleBackgroundTrial() async {
  await Workmanager().registerOneOffTask(
    'campus-radar-probe',
    periodicTask,
    initialDelay: const Duration(seconds: 30),
    existingWorkPolicy: ExistingWorkPolicy.replace,
    constraints: Constraints(networkType: NetworkType.connected),
    inputData: {'source': 'trial'},
  );
  final store = await Store.open();
  try {
    await store.log(
      'sync',
      '백그라운드 시험 예약',
      '30초 이후 실행 가능한 시험을 예약했습니다. 홈 화면으로 나가 기다려 주세요. 운영체제에 따라 지연될 수 있습니다.',
    );
  } finally {
    await store.db.close();
  }
}

/// Diagnostics must never prevent startup or the operation being diagnosed.
List<String> batteryWarnings(Map<Object?, Object?> status) {
  final warnings = <String>[];
  if (status['batteryExempt'] == false) {
    warnings.add('배터리 최적화 예외가 아닙니다. 앱 배터리를 제한 없음으로 설정해 주세요.');
  }
  if (status['backgroundRestricted'] == true) {
    warnings.add('앱의 백그라운드 실행이 제한되어 있어요.');
  }
  if ([
    'batteryExempt',
    'backgroundRestricted',
  ].any((key) => status[key] is! bool)) {
    warnings.add('일부 배터리 설정 상태를 확인하지 못했습니다. 설정에서 직접 확인해 주세요.');
  }
  return warnings;
}

Future<void> recordInstalledVersion() async {
  if (!Platform.isAndroid && !Platform.isIOS && !Platform.isWindows) return;
  Store? store;
  try {
    final info = await bridge.invokeNativeMap<String, dynamic>(
      NativeMethod.versionInfo,
    );
    if (info == null) {
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    final current = "${info['name']} (${info['code']})";
    final previous = prefs.getString('observedInstalledVersion');
    store = await Store.open();
    if (previous == current &&
        await store.meta('installedVersionLogged') == current) {
      return;
    }
    await store.log(
      'system',
      previous == null
          ? '설치 버전 최초 기록'
          : previous == current
          ? '업데이트 후 저장소 확인'
          : '앱 버전 변경 확인',
      previous == null
          ? '현재 $current · 이전 버전 기록 없음'
          : previous == current
          ? '현재 $current · 저장소 읽기 및 버전 기록 저장 확인'
          : '$previous → $current · 변경된 버전으로 실행됨',
    );
    await store.setMeta('installedVersionLogged', current);
    await prefs.setString('observedInstalledVersion', current);
  } catch (_) {
  } finally {
    await store?.db.close();
  }
}

import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'package:workmanager/workmanager.dart';
import 'campus.dart';

const bridge = MethodChannel('campus_radar/native');
const credentials = FlutterSecureStorage(
  aOptions: AndroidOptions(encryptedSharedPreferences: true),
);
const periodicTask = 'campus-radar-sync';
final notifications = FlutterLocalNotificationsPlugin();
int notificationId(String key) {
  final b = sha256.convert(utf8.encode(key)).bytes;
  return ((b[0] << 24) | (b[1] << 16) | (b[2] << 8) | b[3]) & 0x7fffffff;
}

const noticeStyle = NotificationDetails(
  android: AndroidNotificationDetails(
    'assignments',
    '과제·콘텐츠 알림',
    channelDescription: '새 과제와 마감 하루 전 알림',
    importance: Importance.high,
    priority: Priority.high,
  ),
);
Future<void> initNotifications({void Function(String?)? onTap}) async {
  tzdata.initializeTimeZones();
  await notifications.initialize(
    const InitializationSettings(
      android: AndroidInitializationSettings('ic_stat_radar'),
    ),
    onDidReceiveNotificationResponse: (r) => onTap?.call(r.payload),
  );
}

class Store {
  final Database db;
  Store(this.db);
  static Future<Store> open() async => Store(
    await openDatabase(
      '${await getDatabasesPath()}/campus.db',
      version: 1,
      singleInstance: false,
      onCreate: (db, _) async {
        await db.execute(
          'CREATE TABLE items (id TEXT PRIMARY KEY, payload TEXT NOT NULL)',
        );
        await db.execute(
          'CREATE TABLE meta (id TEXT PRIMARY KEY, value TEXT NOT NULL)',
        );
        await db.execute(
          'CREATE TABLE events (id TEXT PRIMARY KEY, payload TEXT NOT NULL, delivered INTEGER NOT NULL DEFAULT 0)',
        );
      },
    ),
  );
  Future<String?> meta(String key) async {
    final r = await db.query('meta', where: 'id=?', whereArgs: [key]);
    return r.isEmpty ? null : r.first['value'] as String;
  }

  Future<void> setMeta(String k, String v) async {
    await db.insert('meta', {
      'id': k,
      'value': v,
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<CampusItem>> items() async =>
      (await db.query('items'))
          .map((r) => CampusItem.fromJson(jsonDecode(r['payload'] as String)))
          .toList()
        ..sort(
          (a, b) => (a.due ?? DateTime.utc(2100)).compareTo(
            b.due ?? DateTime.utc(2100),
          ),
        );
  Future<bool> acquire() => db.transaction((txn) async {
    final row = await txn.query('meta', where: 'id=?', whereArgs: ['lease']);
    final lease = row.isEmpty
        ? 0
        : int.tryParse(row.first['value'] as String) ?? 0;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (lease > now) return false;
    await txn.insert('meta', {
      'id': 'lease',
      'value': '${now + 600000}',
    }, conflictAlgorithm: ConflictAlgorithm.replace);
    return true;
  });
  Future<void> replace(List<CampusItem> incoming) async {
    await db.transaction((txn) async {
      final old = (await txn.query(
        'items',
      )).map((r) => r['id'] as String).toSet();
      final initialized = (await txn.query(
        'meta',
        where: 'id=?',
        whereArgs: ['initialized'],
      )).isNotEmpty;
      for (final item in incoming) {
        if (initialized && item.type == 'LR' && !old.contains(item.key)) {
          await txn.insert('events', {
            'id': 'new:${item.key}',
            'payload': jsonEncode(item.toJson()),
          }, conflictAlgorithm: ConflictAlgorithm.ignore);
        }
      }
      await txn.delete('items');
      for (final item in incoming) {
        await txn.insert('items', {
          'id': item.key,
          'payload': jsonEncode(item.toJson()),
        });
      }
      for (final entry in {
        'initialized': 'yes',
        'lastSuccess': DateTime.now().toIso8601String(),
        'lastError': '',
      }.entries) {
        await txn.insert('meta', {
          'id': entry.key,
          'value': entry.value,
        }, conflictAlgorithm: ConflictAlgorithm.replace);
      }
    });
  }
}

Future<void> reconcile(Store store) async {
  final items = await store.items();
  final prefs = await SharedPreferences.getInstance();
  final old = prefs.getStringList('scheduled') ?? [];
  final desired = <String>[];
  final android = notifications
      .resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin
      >();
  final permitted = await android?.areNotificationsEnabled() ?? false;
  final now = DateTime.now().toUtc();
  for (final item in items) {
    if (item.status != 'pending' ||
        item.due == null ||
        !item.due!.isAfter(now)) {
      continue;
    }
    final token = 'due:${item.key}:${item.due!.toIso8601String()}';
    final at = item.due!.subtract(const Duration(days: 1));
    if (at.isAfter(now)) {
      desired.add(token);
      if (permitted) {
        await notifications.zonedSchedule(
          notificationId(token),
          '${item.type == 'LR' ? '과제' : '콘텐츠'} 마감 하루 전',
          '${item.course} · ${item.title}',
          tz.TZDateTime.from(at, tz.UTC),
          noticeStyle,
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          payload: item.key,
        );
        await store.setMeta(token, 'scheduled');
      }
    } else if (permitted &&
        !['sent', 'scheduled'].contains(await store.meta(token))) {
      await notifications.show(
        notificationId(token),
        '마감까지 하루 이내입니다',
        '${item.course} · ${item.title}',
        noticeStyle,
        payload: item.key,
      );
      await store.setMeta(token, 'sent');
    }
  }
  for (final token in old.where((t) => !desired.contains(t))) {
    await notifications.cancel(notificationId(token));
  }
  await prefs.setStringList('scheduled', desired);
  if (permitted) {
    for (final event in await store.db.query('events', where: 'delivered=0')) {
      final item = CampusItem.fromJson(jsonDecode(event['payload'] as String));
      await notifications.show(
        notificationId(event['id'] as String),
        '새 과제가 등록됐어요',
        '${item.course} · ${item.title}',
        noticeStyle,
        payload: item.key,
      );
      await store.db.update(
        'events',
        {'delivered': 1},
        where: 'id=?',
        whereArgs: [event['id']],
      );
    }
  }
}

Future<void> synchronize() async {
  final store = await Store.open();
  final locked = await store.acquire();
  if (!locked) {
    await store.db.close();
    return;
  }
  final client = CampusClient();
  try {
    final id = await credentials.read(key: 'id');
    final pw = await credentials.read(key: 'pw');
    if (id == null || pw == null) return;
    await client.login(id, pw);
    final items = await client.fetchItems();
    if (await credentials.read(key: 'id') != id) return;
    await store.replace(items);
    await reconcile(store);
  } catch (e) {
    await store.setMeta(
      'lastError',
      e is CampusException ? e.message : '연결하지 못했습니다. 네트워크를 확인하고 다시 시도해 주세요.',
    );
    rethrow;
  } finally {
    client.close();
    await store.setMeta('lease', '0');
    await store.db.close();
  }
}

@pragma('vm:entry-point')
void backgroundDispatcher() {
  Workmanager().executeTask((task, data) async {
    await initNotifications();
    try {
      await synchronize();
      return true;
    } catch (_) {
      return true;
    }
  });
}

Future<void> registerBackground() => Workmanager().registerPeriodicTask(
  periodicTask,
  periodicTask,
  frequency: const Duration(hours: 1),
  existingWorkPolicy: ExistingPeriodicWorkPolicy.keep,
  constraints: Constraints(networkType: NetworkType.connected),
);

import 'updates.dart';
import 'ios_features.dart';
import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'package:workmanager/workmanager.dart';
import 'campus.dart';
import 'ai_automation.dart';

Future<void> loadCourseAliases() async {
  final prefs = await SharedPreferences.getInstance();
  final raw = prefs.getString('courseAliases');
  try {
    courseAliases = raw == null
        ? {}
        : Map<String, String>.from(jsonDecode(raw));
  } catch (_) {
    courseAliases = {};
  }
  // Repair already-linked calendar titles even when an alias is not edited again.
  final migration = jsonEncode(courseAliases);
  if (Platform.isAndroid &&
      prefs.getString('calendarAliasMigration032') != migration) {
    try {
      for (final entry in courseAliases.entries) {
        await bridge.invokeMethod('calendarRenameCourse', {
          'original': entry.key,
          'previous': entry.key,
          'label': entry.value,
        });
      }
      await prefs.setString('calendarAliasMigration032', migration);
    } catch (_) {
      // Retry next launch; the native queue survives missing calendar permission.
    }
  }
}

Future<void> setCourseAlias(String name, String alias) async {
  final value = alias.trim();
  if (value.length > 30) throw const FormatException('과목 약자는 30자 이내로 입력해 주세요.');
  final previous = courseLabel(name);
  final next = {...courseAliases};
  if (value.isEmpty || value == name) {
    next.remove(name);
  } else {
    next[name] = value;
  }
  final prefs = await SharedPreferences.getInstance();
  if (!await prefs.setString('courseAliases', jsonEncode(next))) {
    throw const FormatException('과목 약자를 저장하지 못했습니다.');
  }
  courseAliases = next;
  final store = await Store.open();
  try {
    final records = await store.db.query(
      'meta',
      where: 'id LIKE ?',
      whereArgs: ['aiCandidate:%'],
    );
    for (final row in records) {
      try {
        final record = jsonDecode(row['value'] as String) as Map;
        final n = CampusNotice.fromJson(
          Map<String, dynamic>.from(record['notice']),
        );
        if (n.course.replaceAll(RegExp(r'\s+'), '') !=
            name.replaceAll(RegExp(r'\s+'), '')) {
          continue;
        }
        final key = record['key'] as String;
        final raw = await store.meta('aiState:$key');
        if (raw == null) continue;
        final state = Map<String, dynamic>.from(jsonDecode(raw));
        if (state['title'] is String) {
          state['title'] = courseEventTitle(
            state['title'],
            n.course,
            oldLabel: state['courseLabel'] as String? ?? previous,
          );
        }
        state['courseName'] = n.course;
        state['courseLabel'] = courseLabel(n.course);
        await store.setMeta('aiState:$key', jsonEncode(state));
      } catch (_) {}
    }
    await store.setMeta('aiSummaryHash', '');
    await store.setMeta('aiSummaryFailHash', '');
    await store.setMeta(
      'aiSummaryRevision',
      '${DateTime.now().microsecondsSinceEpoch}',
    );
    await prefs.remove('aiSummaryText');
    await prefs.remove('aiSummaryLast');
  } finally {
    await store.db.close();
  }
  if (Platform.isAndroid) {
    try {
      await bridge.invokeMethod('calendarRenameCourse', {
        'original': name,
        'previous': previous,
        'label': courseLabel(name),
      });
    } catch (_) {}
  }
}

const bridge = MethodChannel('campus_radar/native');
const credentials = FlutterSecureStorage(
  aOptions: AndroidOptions(encryptedSharedPreferences: true),
  iOptions: IOSOptions(
    accessibility: KeychainAccessibility.first_unlock_this_device,
  ),
);
final periodicTask = Platform.isIOS
    ? 'kr.campusradar.campusradar.sync'
    : 'campus-radar-sync';
final notifications = FlutterLocalNotificationsPlugin();
int notificationId(String key) {
  final b = sha256.convert(utf8.encode(key)).bytes;
  return ((b[0] << 24) | (b[1] << 16) | (b[2] << 8) | b[3]) & 0x7fffffff;
}

const noticeStyle = NotificationDetails(
  iOS: DarwinNotificationDetails(),
  android: AndroidNotificationDetails(
    'assignments',
    '과제·콘텐츠 알림',
    channelDescription: '새 과제와 마감 하루 전 알림',
    importance: Importance.high,
    priority: Priority.high,
  ),
);
Future<void> initNotifications({void Function(String?)? onTap}) async {
  tzdata.initializeTimeZones();
  await notifications.initialize(
    const InitializationSettings(
      android: AndroidInitializationSettings('ic_stat_radar'),
      iOS: DarwinInitializationSettings(
        requestAlertPermission: false,
        requestBadgePermission: false,
        requestSoundPermission: false,
      ),
    ),
    onDidReceiveNotificationResponse: (r) => onTap?.call(r.payload),
  );
}

Future<void> requestNotificationPermission() async {
  if (Platform.isIOS) {
    await notifications
        .resolvePlatformSpecificImplementation<
          IOSFlutterLocalNotificationsPlugin
        >()
        ?.requestPermissions(alert: true, badge: true, sound: true);
  } else {
    await notifications
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >()
        ?.requestNotificationsPermission();
  }
}

class Store {
  final Database db;
  Store(this.db);
  static Future<Store> open() async => Store(
    await openDatabase(
      '${await getDatabasesPath()}/campus.db',
      version: 2,
      singleInstance: false,
      onConfigure: (db) async {
        await db.rawQuery('PRAGMA busy_timeout = 5000');
      },
      onCreate: (db, _) async {
        await db.execute(
          'CREATE TABLE items (id TEXT PRIMARY KEY, payload TEXT NOT NULL)',
        );
        await db.execute(
          'CREATE TABLE meta (id TEXT PRIMARY KEY, value TEXT NOT NULL)',
        );
        await db.execute(
          'CREATE TABLE events (id TEXT PRIMARY KEY, payload TEXT NOT NULL, delivered INTEGER NOT NULL DEFAULT 0)',
        );
        await createHistoryTables(db);
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) await createHistoryTables(db);
      },
    ),
  );
  static Future<void> createHistoryTables(Database db) async {
    await db.execute(
      'CREATE TABLE notices (id TEXT PRIMARY KEY, payload TEXT NOT NULL)',
    );
    await db.execute(
      'CREATE TABLE logs (id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL, detail TEXT NOT NULL)',
    );
  }

  Future<void> log(String kind, String title, String detail) async {
    await db.transaction((txn) async {
      await txn.insert('logs', {
        'at': DateTime.now().toUtc().toIso8601String(),
        'kind': kind,
        'title': title,
        'detail': detail,
      });
      await txn.rawDelete(
        'DELETE FROM logs WHERE id NOT IN (SELECT id FROM logs ORDER BY id DESC LIMIT 2000)',
      );
    });
  }

  Future<List<Map<String, Object?>>> logs(String kind) => db.query(
    'logs',
    where: kind == 'all'
        ? null
        : kind == 'notification'
        ? 'kind=?'
        : 'kind!=?',
    whereArgs: kind == 'all' ? null : ['notification'],
    orderBy: 'id DESC',
    limit: 2000,
  );
  Future<List<CampusNotice>> notices() async =>
      (await db.query('notices'))
          .map(
            (row) =>
                CampusNotice.fromJson(jsonDecode(row['payload'] as String)),
          )
          .toList()
        ..sort(
          (a, b) => (b.published ?? DateTime.utc(1970)).compareTo(
            a.published ?? DateTime.utc(1970),
          ),
        );
  Future<void> saveNotice(CampusNotice notice) => db.insert('notices', {
    'id': notice.id,
    'payload': jsonEncode(notice.toJson()),
  }, conflictAlgorithm: ConflictAlgorithm.replace);
  Future<void> replaceNotices(List<CampusNotice> list) async {
    await db.transaction((txn) async {
      final old = {
        for (final row in await txn.query('notices'))
          row['id'] as String: CampusNotice.fromJson(
            jsonDecode(row['payload'] as String),
          ),
      };
      await txn.delete('notices');
      for (final notice in list) {
        final cached = CampusNotice(
          id: notice.id,
          title: notice.title,
          course: notice.course,
          context: notice.context,
          published: notice.published,
          read: notice.read,
          body: old[notice.id]?.body ?? '',
        );
        await txn.insert('notices', {
          'id': notice.id,
          'payload': jsonEncode(cached.toJson()),
        });
      }
    });
  }

  Future<String?> meta(String key) async {
    final r = await db.query('meta', where: 'id=?', whereArgs: [key]);
    return r.isEmpty ? null : r.first['value'] as String;
  }

  Future<void> setMeta(String k, String v) async {
    await db.insert('meta', {
      'id': k,
      'value': v,
    }, conflictAlgorithm: ConflictAlgorithm.replace);
    if (k.startsWith('excluded:')) {
      await setMeta(
        'aiSummaryRevision',
        '${DateTime.now().microsecondsSinceEpoch}',
      );
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('aiSummaryText');
    }
  }

  Future<List<CampusItem>> items() async =>
      (await db.query('items'))
          .map((r) => CampusItem.fromJson(jsonDecode(r['payload'] as String)))
          .toList()
        ..sort(
          (a, b) => (a.due ?? DateTime.utc(2100)).compareTo(
            b.due ?? DateTime.utc(2100),
          ),
        );
  Future<Set<String>> excluded() async => (await db.query(
    'meta',
    where: "id LIKE 'excluded:%' AND value='yes'",
  )).map((row) => (row['id'] as String).substring('excluded:'.length)).toSet();
  Future<bool> acquire() => db.transaction((txn) async {
    final row = await txn.query('meta', where: 'id=?', whereArgs: ['lease']);
    final lease = row.isEmpty
        ? 0
        : int.tryParse(row.first['value'] as String) ?? 0;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (lease > now) return false;
    await txn.insert('meta', {
      'id': 'lease',
      'value': '${now + 600000}',
    }, conflictAlgorithm: ConflictAlgorithm.replace);
    return true;
  });
  Future<void> replace(List<CampusItem> incoming) async {
    await db.transaction((txn) async {
      final now = DateTime.now().toUtc();
      final old = {
        for (final r in await txn.query('items'))
          r['id'] as String: CampusItem.fromJson(
            jsonDecode(r['payload'] as String),
          ),
      };
      final initialized = (await txn.query(
        'meta',
        where: 'id=?',
        whereArgs: ['initialized'],
      )).isNotEmpty;
      final row = await txn.query(
        'meta',
        where: 'id=?',
        whereArgs: ['visibleIds'],
      );
      final previousVisible = row.isEmpty
          ? old.values
                .where((i) => i.availableAt(now))
                .map((i) => i.key)
                .toSet()
          : (jsonDecode(row.first['value'] as String) as List)
                .cast<String>()
                .toSet();
      for (final item in incoming) {
        if (!item.availableAt(now)) continue;
        if (initialized &&
            item.type == 'LR' &&
            !previousVisible.contains(item.key)) {
          await txn.insert('events', {
            'id': 'new:${item.key}',
            'payload': jsonEncode(item.toJson()),
            'delivered': 0,
          }, conflictAlgorithm: ConflictAlgorithm.replace);
          await txn.insert('meta', {
            'id': 'discovered:${item.key}',
            'value': now.toIso8601String(),
          }, conflictAlgorithm: ConflictAlgorithm.replace);
        }
        final before = old[item.key];
        if (initialized &&
            before != null &&
            previousVisible.contains(item.key)) {
          final changes = itemChanges(before, item);
          if (changes.isNotEmpty) {
            final detail = changes.join('\n');
            await txn.insert('events', {
              'id': 'change:${item.key}:${now.microsecondsSinceEpoch}',
              'payload': jsonEncode({
                'item': item.toJson(),
                'kind': 'change',
                'detail': detail,
                'at': now.toIso8601String(),
              }),
              'delivered': 0,
            });
          }
        }
      }
      await txn.insert('meta', {
        'id': 'visibleIds',
        'value': jsonEncode(
          incoming.where((i) => i.availableAt(now)).map((i) => i.key).toList(),
        ),
      }, conflictAlgorithm: ConflictAlgorithm.replace);
      await txn.delete('items');
      for (final item in incoming) {
        await txn.insert('items', {
          'id': item.key,
          'payload': jsonEncode(item.toJson()),
        });
      }
      for (final entry in {
        'initialized': 'yes',
        'lastSuccess': DateTime.now().toIso8601String(),
        'lastError': '',
      }.entries) {
        await txn.insert('meta', {
          'id': entry.key,
          'value': entry.value,
        }, conflictAlgorithm: ConflictAlgorithm.replace);
      }
    });
  }
}

Future<void> reconcile(Store store) async {
  final items = await store.items();
  final excluded = await store.excluded();
  final prefs = await SharedPreferences.getInstance();
  final old = prefs.getStringList('scheduled') ?? [];
  final desired = <String>[];
  final android = notifications
      .resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin
      >();
  final permitted = Platform.isIOS
      ? (await notifications
                    .resolvePlatformSpecificImplementation<
                      IOSFlutterLocalNotificationsPlugin
                    >()
                    ?.checkPermissions())
                ?.isEnabled ??
            false
      : await android?.areNotificationsEnabled() ?? false;
  final now = DateTime.now().toUtc();
  final permissionState = permitted ? 'yes' : 'no';
  if (await store.meta('notificationPermission') != permissionState) {
    await store.log(
      'notification',
      permitted ? '알림 권한 허용' : '알림 권한 꺼짐',
      permitted ? '알림 발송·예약을 진행합니다.' : '권한을 허용하기 전에는 알림을 표시하지 못합니다.',
    );
    await store.setMeta('notificationPermission', permissionState);
  }
  for (final item in items) {
    if (!item.availableAt(now) ||
        excluded.contains(item.key) ||
        item.status != 'pending' ||
        item.due == null ||
        !item.due!.isAfter(now)) {
      continue;
    }
    final token = 'due:${item.key}:${item.due!.toIso8601String()}';
    final at = item.due!.subtract(const Duration(days: 1));
    // A passed trigger is still valid until the task is completed or expires.
    // Cancelling here also removes an already displayed Android notification.
    if (Platform.isIOS && at.isAfter(now) && desired.length >= 56) continue;
    desired.add(token);
    if (at.isAfter(now)) {
      // iOS retains at most 64 pending notifications; reserve seven daily notifications; keep the nearest 56.
      if (permitted) {
        final wasScheduled = await store.meta(token) == 'scheduled';
        await notifications.zonedSchedule(
          notificationId(token),
          '${item.type == 'LR' ? '과제' : '콘텐츠'} 마감 하루 전',
          '${courseLabel(item.course)} · ${item.title}',
          tz.TZDateTime.from(at, tz.UTC),
          noticeStyle,
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          payload: item.key,
        );
        await store.setMeta(token, 'scheduled');
        if (!wasScheduled) {
          await store.log(
            'notification',
            '마감 알림 예약',
            '${courseLabel(item.course)} · ${item.title}\n예정: ${koreanTime(at)}',
          );
        }
      }
    } else if (permitted &&
        await store.meta(token) != 'sent' &&
        (await store.meta(token) != 'scheduled' || !old.contains(token))) {
      // Older versions discarded passed reservations from `scheduled` and
      // cancelled them. Recover those once; retained reservations must not
      // cause another notification on every collection.
      await notifications.show(
        notificationId(token),
        '마감까지 하루 이내입니다',
        '${courseLabel(item.course)} · ${item.title}',
        noticeStyle,
        payload: item.key,
      );
      await store.setMeta(token, 'sent');
      await store.log(
        'notification',
        '마감 임박 알림 발송 요청',
        '${courseLabel(item.course)} · ${item.title}',
      );
    }
  }
  for (final token in old.where((t) => !desired.contains(t))) {
    await notifications.cancel(notificationId(token));
    await store.log(
      'notification',
      '마감 알림 예약 취소',
      '완료·마감 변경·제외 등의 이유로 기존 예약을 취소했습니다.',
    );
  }
  await prefs.setStringList('scheduled', desired);
  if (permitted) {
    for (final event in await store.db.query('events', where: 'delivered=0')) {
      final data =
          jsonDecode(event['payload'] as String) as Map<String, dynamic>;
      final changed = data['kind'] == 'change';
      final original = CampusItem.fromJson(
        Map<String, dynamic>.from(changed ? data['item'] : data),
      );
      final item = items.where((i) => i.key == original.key).firstOrNull;
      if (item == null ||
          !item.availableAt(now) ||
          excluded.contains(item.key)) {
        await store.db.update(
          'events',
          {'delivered': 1},
          where: 'id=?',
          whereArgs: [event['id']],
        );
        continue;
      }
      await notifications.show(
        notificationId(event['id'] as String),
        changed ? '과제·콘텐츠 정보가 변경됐어요' : '새 과제가 등록됐어요',
        changed
            ? '${courseLabel(item.course)} · ${item.title}\n${(data['detail'] as String).split('\n').first}'
            : '${courseLabel(item.course)} · ${item.title}',
        noticeStyle,
        payload: item.key,
      );
      await store.log(
        'notification',
        changed ? '변경 알림 발송 요청' : '새 과제 알림 발송 요청',
        changed
            ? '${courseLabel(item.course)} · ${item.title}\n${data['detail']}'
            : '${courseLabel(item.course)} · ${item.title}',
      );
      await store.db.update(
        'events',
        {'delivered': 1},
        where: 'id=?',
        whereArgs: [event['id']],
      );
    }
  }
  if (Platform.isIOS) await refreshIosFeatures(store);
  if (Platform.isAndroid) {
    try {
      await bridge.invokeMethod('refreshWidget');
    } on MissingPluginException {
      /* Worker completion refreshes native widgets. */
    }
  }
}

Future<void> excludeItem(CampusItem item, bool exclude) async {
  final store = await Store.open();
  try {
    await store.setMeta('excluded:${item.key}', exclude ? 'yes' : 'no');
    await store.log(
      'received',
      exclude ? '목록에서 제외' : '목록에 복구',
      '${courseLabel(item.course)} · ${item.title}',
    );
    if (exclude) {
      await notifications.cancel(notificationId('new:${item.key}'));
      if (item.due != null) {
        await notifications.cancel(
          notificationId('due:${item.key}:${item.due!.toIso8601String()}'),
        );
        await store.setMeta(
          'due:${item.key}:${item.due!.toIso8601String()}',
          '',
        );
      }
    }
    await reconcile(store);
  } finally {
    await store.db.close();
  }
}

enum SyncOutcome { completed, busy, noCredentials, accountChanged }

String diagnosticFailure(Object e) {
  if (e is CampusException) return e.message;
  if (e is PlatformException) return '기기 기능 오류 (${e.code})';
  if (e is SocketException) {
    return '네트워크 연결 오류 (${e.osError?.errorCode ?? '미확인'})';
  }
  if (e is HandshakeException) return 'HTTPS 연결을 확인하지 못했습니다.';
  if (e is TimeoutException) return '요청 시간이 초과됐습니다.';
  if (e is FormatException) return '응답 데이터 형식이 예상과 다릅니다.';
  return '처리 오류 (${e.runtimeType})';
}

Future<SyncOutcome> synchronize({String source = '앱에서 확인'}) async {
  final store = await Store.open();
  final locked = await store.acquire();
  if (!locked) {
    await store.log(
      'sync',
      '[$source] 수집 대기',
      '다른 수집이 진행 중입니다. 백그라운드 작업이면 재시도합니다.',
    );
    await store.db.close();
    return SyncOutcome.busy;
  }
  var route = '연결 준비';
  final client = CampusClient(
    diagnostic: (line) {
      if (line.startsWith('API ')) route = line.substring(4);
    },
  );
  var phase = '계정 읽기';
  try {
    await loadCourseAliases();
    final id = await credentials.read(key: 'id');
    final pw = await credentials.read(key: 'pw');
    if (id == null || pw == null) {
      await store.log('sync', '[$source] 수집 건너뜀', '저장된 계정이 없습니다.');
      return SyncOutcome.noCredentials;
    }
    await store.log('sync', '[$source] 수집 시작', '포털에 새로 로그인해 과제·콘텐츠·공지를 확인합니다.');
    phase = '포털 로그인';
    await client.login(id, pw);
    await store.log('sync', '[$source] 로그인 성공', '과제·콘텐츠를 수집합니다.');
    phase = '과제·콘텐츠 수집';
    final items = await client.fetchItems();
    if (await credentials.read(key: 'id') != id) {
      return SyncOutcome.accountChanged;
    }
    phase = '목록 저장';
    await store.replace(items);
    await store.setMeta('courses', jsonEncode(client.courseList));
    for (final item in items) {
      await store.log(
        'received',
        item.type == 'LR' ? '과제 수집' : '콘텐츠 수집',
        '${courseLabel(item.course)} · ${item.title}\n상태: ${item.done
            ? '완료'
            : item.status == 'pending'
            ? '미완료'
            : '확인 불가'} · 마감: ${item.due == null ? '미확인' : koreanTime(item.due!)}',
      );
    }
    try {
      final notices = await client.fetchNotices();
      if (await credentials.read(key: 'id') != id) {
        return SyncOutcome.accountChanged;
      }
      await store.replaceNotices(notices);
      await store.setMeta('noticeError', '');
      for (final notice in notices) {
        await store.log(
          'received',
          '공지 수집',
          '${courseLabel(notice.course)} · ${notice.title}',
        );
      }
      await store.log(
        'sync',
        '[$source] 목록 수집 완료',
        '과제 ${items.where((i) => i.type == 'LR').length}개 · 콘텐츠 ${items.where((i) => i.type == 'LV').length}개 · 공지 ${notices.length}개',
      );
    } catch (e) {
      final message = e is CampusException
          ? e.message
          : '공지 수집에 실패했습니다. 마지막 공지 목록을 유지합니다.';
      await store.setMeta('noticeError', message);
      await store.log('sync', '공지 수집 실패', '$message\n과제·콘텐츠 결과는 저장했습니다.');
    }
    phase = '알림 처리';
    await reconcile(store);
    await store.log('sync', '[$source] 처리 완료', '수집 결과 저장과 알림 처리를 마쳤습니다.');
    try {
      await aiAfterSync(store);
    } catch (_) {
      await store.log('ai', 'AI 작업 예약 대기', '다음 수집 또는 AI 일정함에서 다시 시도합니다.');
    }
    return SyncOutcome.completed;
  } catch (e) {
    await store.log(
      'sync',
      '[$source] 수집 또는 알림 처리 실패',
      '$phase 단계: ${diagnosticFailure(e)}\n실패 종류: ${e.runtimeType}\n마지막 요청: $route',
    );
    await store.setMeta('lastError', '$phase: ${diagnosticFailure(e)}');
    rethrow;
  } finally {
    if (Platform.isAndroid) {
      try {
        await checkForUpdates(store);
      } catch (_) {
        /* Update checks never fail collection. */
      }
    }
    client.close();
    await store.setMeta('lease', '0');
    await store.db.close();
  }
}

Future<void> logNotification(String title, String detail) async {
  final store = await Store.open();
  try {
    await store.log('notification', title, detail);
  } finally {
    await store.db.close();
  }
}

@pragma('vm:entry-point')
void backgroundDispatcher() {
  Workmanager().executeTask((task, data) async {
    if (Platform.isIOS) setIosAiActive(false);
    if (task == aiWorkTask) {
      await processAiWork();
      if (data?['summaryWarmup'] == true) {
        final p = await SharedPreferences.getInstance();
        await p.reload();
        await scheduleSummaryWarmup(
          p.getInt('aiDailyHour') ?? 18,
          p.getInt('aiDailyMinute') ?? 0,
          p.getBool('aiDailyEnabled') ?? false,
        );
      }
      return true;
    }
    Store? trace;
    try {
      trace = await Store.open();
      await trace.setMeta(
        'workerStarted',
        DateTime.now().toUtc().toIso8601String(),
      );
      await trace.log('sync', '백그라운드 작업 진입', '운영체제가 자동 수집 코드를 실행했습니다.');
      await initNotifications().timeout(const Duration(seconds: 20));
      await trace.log('sync', '백그라운드 알림 초기화 완료', '계정 확인과 수집을 시작합니다.');
      final outcome = await synchronize(
        source: data?['source'] == 'trial' ? '백그라운드 시험' : '백그라운드 자동',
      );
      if (outcome == SyncOutcome.busy) {
        await trace.log('sync', '백그라운드 재시도 요청', '다른 수집과 겹쳐 운영체제에 재시도를 요청했습니다.');
        return false;
      }
      if (outcome == SyncOutcome.completed) {
        await trace.setMeta(
          'workerSource',
          data?['source'] == 'trial' ? '시험' : '정기 자동',
        );
        await trace.setMeta(
          'workerSuccess',
          DateTime.now().toUtc().toIso8601String(),
        );
      }
      return true;
    } catch (e) {
      if (trace != null) {
        await trace.log(
          'sync',
          '백그라운드 작업 실패',
          e is PlatformException
              ? '기기 기능 오류: ${e.code}. 운영체제에 재시도를 요청합니다.'
              : '실패 종류: ${e.runtimeType}. 운영체제에 재시도를 요청합니다.',
        );
      }
      return false;
    } finally {
      await trace?.db.close();
    }
  });
}

Future<void> registerBackground() async {
  await Workmanager().registerPeriodicTask(
    periodicTask,
    periodicTask,
    frequency: const Duration(hours: 1),
    existingWorkPolicy: ExistingPeriodicWorkPolicy.keep,
    constraints: Constraints(networkType: NetworkType.connected),
  );
  final store = await Store.open();
  try {
    await store.log(
      'sync',
      '자동 수집 예약 확인',
      '1시간 주기 작업을 유지합니다. 실제 실행 시각은 운영체제와 네트워크 조건에 따라 지연될 수 있습니다.',
    );
  } finally {
    await store.db.close();
  }
}

Future<void> scheduleBackgroundTrial() async {
  await Workmanager().registerOneOffTask(
    'campus-radar-probe',
    periodicTask,
    initialDelay: const Duration(seconds: 30),
    existingWorkPolicy: ExistingWorkPolicy.replace,
    constraints: Constraints(networkType: NetworkType.connected),
    inputData: {'source': 'trial'},
  );
  final store = await Store.open();
  try {
    await store.log(
      'sync',
      '백그라운드 시험 예약',
      '30초 이후 실행 가능한 시험을 예약했습니다. 홈 화면으로 나가 기다려 주세요. 운영체제에 따라 지연될 수 있습니다.',
    );
  } finally {
    await store.db.close();
  }
}

/// Diagnostics must never prevent startup or the operation being diagnosed.
Future<void> systemLog(String title, String detail) async {
  Store? store;
  try {
    store = await Store.open();
    await store.log('system', title, detail);
  } catch (_) {
    // The main operation remains available if local logging fails.
  } finally {
    await store?.db.close();
  }
}

List<String> batteryWarnings(Map<Object?, Object?> status) {
  final warnings = <String>[];
  if (status['batteryExempt'] == false) {
    warnings.add('배터리 최적화 예외가 아닙니다. 앱 배터리를 제한 없음으로 설정해 주세요.');
  }
  if (status['backgroundRestricted'] == true) {
    warnings.add('앱의 백그라운드 실행이 제한되어 있어요.');
  }
  if ([
    'batteryExempt',
    'backgroundRestricted',
  ].any((key) => status[key] is! bool)) {
    warnings.add('일부 배터리 설정 상태를 확인하지 못했습니다. 설정에서 직접 확인해 주세요.');
  }
  return warnings;
}

Future<void> recordInstalledVersion() async {
  if (!Platform.isAndroid && !Platform.isIOS) return;
  Store? store;
  try {
    final info = await bridge.invokeMapMethod<String, dynamic>('versionInfo');
    if (info == null) {
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    final current = "${info['name']} (${info['code']})";
    final previous = prefs.getString('observedInstalledVersion');
    store = await Store.open();
    if (previous == current &&
        await store.meta('installedVersionLogged') == current) {
      return;
    }
    await store.log(
      'system',
      previous == null
          ? '설치 버전 최초 기록'
          : previous == current
          ? '업데이트 후 저장소 확인'
          : '앱 버전 변경 확인',
      previous == null
          ? '현재 $current · 이전 버전 기록 없음'
          : previous == current
          ? '현재 $current · 저장소 읽기 및 버전 기록 저장 확인'
          : '$previous → $current · 변경된 버전으로 실행됨',
    );
    await store.setMeta('installedVersionLogged', current);
    await prefs.setString('observedInstalledVersion', current);
  } catch (_) {
  } finally {
    await store?.db.close();
  }
}

import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'package:workmanager/workmanager.dart';
import 'campus.dart';

const bridge = MethodChannel('campus_radar/native');
const credentials = FlutterSecureStorage(
  aOptions: AndroidOptions(encryptedSharedPreferences: true),
  iOptions: IOSOptions(
    accessibility: KeychainAccessibility.first_unlock_this_device,
  ),
);
final periodicTask = Platform.isIOS
    ? 'kr.campusradar.campusradar.sync'
    : 'campus-radar-sync';
final notifications = FlutterLocalNotificationsPlugin();
int notificationId(String key) {
  final b = sha256.convert(utf8.encode(key)).bytes;
  return ((b[0] << 24) | (b[1] << 16) | (b[2] << 8) | b[3]) & 0x7fffffff;
}

const noticeStyle = NotificationDetails(
  iOS: DarwinNotificationDetails(),
  android: AndroidNotificationDetails(
    'assignments',
    '과제·콘텐츠 알림',
    channelDescription: '새 과제와 마감 하루 전 알림',
    importance: Importance.high,
    priority: Priority.high,
  ),
);
Future<void> initNotifications({void Function(String?)? onTap}) async {
  tzdata.initializeTimeZones();
  await notifications.initialize(
    const InitializationSettings(
      android: AndroidInitializationSettings('ic_stat_radar'),
      iOS: DarwinInitializationSettings(
        requestAlertPermission: false,
        requestBadgePermission: false,
        requestSoundPermission: false,
      ),
    ),
    onDidReceiveNotificationResponse: (r) => onTap?.call(r.payload),
  );
}

Future<void> requestNotificationPermission() async {
  if (Platform.isIOS) {
    await notifications
        .resolvePlatformSpecificImplementation<
          IOSFlutterLocalNotificationsPlugin
        >()
        ?.requestPermissions(alert: true, badge: true, sound: true);
  } else {
    await notifications
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >()
        ?.requestNotificationsPermission();
  }
}

class Store {
  final Database db;
  Store(this.db);
  static Future<Store> open() async => Store(
    await openDatabase(
      '${await getDatabasesPath()}/campus.db',
      version: 2,
      singleInstance: false,
      onCreate: (db, _) async {
        await db.execute(
          'CREATE TABLE items (id TEXT PRIMARY KEY, payload TEXT NOT NULL)',
        );
        await db.execute(
          'CREATE TABLE meta (id TEXT PRIMARY KEY, value TEXT NOT NULL)',
        );
        await db.execute(
          'CREATE TABLE events (id TEXT PRIMARY KEY, payload TEXT NOT NULL, delivered INTEGER NOT NULL DEFAULT 0)',
        );
        await createHistoryTables(db);
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) await createHistoryTables(db);
      },
    ),
  );
  static Future<void> createHistoryTables(Database db) async {
    await db.execute(
      'CREATE TABLE notices (id TEXT PRIMARY KEY, payload TEXT NOT NULL)',
    );
    await db.execute(
      'CREATE TABLE logs (id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL, detail TEXT NOT NULL)',
    );
  }

  Future<void> log(String kind, String title, String detail) async {
    await db.transaction((txn) async {
      await txn.insert('logs', {
        'at': DateTime.now().toUtc().toIso8601String(),
        'kind': kind,
        'title': title,
        'detail': detail,
      });
      await txn.rawDelete(
        'DELETE FROM logs WHERE id NOT IN (SELECT id FROM logs ORDER BY id DESC LIMIT 2000)',
      );
    });
  }

  Future<List<Map<String, Object?>>> logs(String kind) => db.query(
    'logs',
    where: kind == 'notification' ? 'kind=?' : 'kind!=?',
    whereArgs: ['notification'],
    orderBy: 'id DESC',
    limit: 2000,
  );
  Future<List<CampusNotice>> notices() async =>
      (await db.query('notices'))
          .map(
            (row) =>
                CampusNotice.fromJson(jsonDecode(row['payload'] as String)),
          )
          .toList()
        ..sort(
          (a, b) => (b.published ?? DateTime.utc(1970)).compareTo(
            a.published ?? DateTime.utc(1970),
          ),
        );
  Future<void> saveNotice(CampusNotice notice) => db.insert('notices', {
    'id': notice.id,
    'payload': jsonEncode(notice.toJson()),
  }, conflictAlgorithm: ConflictAlgorithm.replace);
  Future<void> replaceNotices(List<CampusNotice> list) async {
    await db.transaction((txn) async {
      final old = {
        for (final row in await txn.query('notices'))
          row['id'] as String: CampusNotice.fromJson(
            jsonDecode(row['payload'] as String),
          ),
      };
      await txn.delete('notices');
      for (final notice in list) {
        final cached = CampusNotice(
          id: notice.id,
          title: notice.title,
          course: notice.course,
          context: notice.context,
          published: notice.published,
          read: notice.read,
          body: old[notice.id]?.body ?? '',
        );
        await txn.insert('notices', {
          'id': notice.id,
          'payload': jsonEncode(cached.toJson()),
        });
      }
    });
  }

  Future<String?> meta(String key) async {
    final r = await db.query('meta', where: 'id=?', whereArgs: [key]);
    return r.isEmpty ? null : r.first['value'] as String;
  }

  Future<void> setMeta(String k, String v) async {
    await db.insert('meta', {
      'id': k,
      'value': v,
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<CampusItem>> items() async =>
      (await db.query('items'))
          .map((r) => CampusItem.fromJson(jsonDecode(r['payload'] as String)))
          .toList()
        ..sort(
          (a, b) => (a.due ?? DateTime.utc(2100)).compareTo(
            b.due ?? DateTime.utc(2100),
          ),
        );
  Future<Set<String>> excluded() async => (await db.query(
    'meta',
    where: "id LIKE 'excluded:%' AND value='yes'",
  )).map((row) => (row['id'] as String).substring('excluded:'.length)).toSet();
  Future<bool> acquire() => db.transaction((txn) async {
    final row = await txn.query('meta', where: 'id=?', whereArgs: ['lease']);
    final lease = row.isEmpty
        ? 0
        : int.tryParse(row.first['value'] as String) ?? 0;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (lease > now) return false;
    await txn.insert('meta', {
      'id': 'lease',
      'value': '${now + 600000}',
    }, conflictAlgorithm: ConflictAlgorithm.replace);
    return true;
  });
  Future<void> replace(List<CampusItem> incoming) async {
    await db.transaction((txn) async {
      final old = (await txn.query(
        'items',
      )).map((r) => r['id'] as String).toSet();
      final initialized = (await txn.query(
        'meta',
        where: 'id=?',
        whereArgs: ['initialized'],
      )).isNotEmpty;
      for (final item in incoming) {
        if (initialized && item.type == 'LR' && !old.contains(item.key)) {
          await txn.insert('events', {
            'id': 'new:${item.key}',
            'payload': jsonEncode(item.toJson()),
          }, conflictAlgorithm: ConflictAlgorithm.ignore);
        }
      }
      await txn.delete('items');
      for (final item in incoming) {
        await txn.insert('items', {
          'id': item.key,
          'payload': jsonEncode(item.toJson()),
        });
      }
      for (final entry in {
        'initialized': 'yes',
        'lastSuccess': DateTime.now().toIso8601String(),
        'lastError': '',
      }.entries) {
        await txn.insert('meta', {
          'id': entry.key,
          'value': entry.value,
        }, conflictAlgorithm: ConflictAlgorithm.replace);
      }
    });
  }
}

Future<void> reconcile(Store store) async {
  final items = await store.items();
  final excluded = await store.excluded();
  final prefs = await SharedPreferences.getInstance();
  final old = prefs.getStringList('scheduled') ?? [];
  final desired = <String>[];
  final android = notifications
      .resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin
      >();
  final permitted = Platform.isIOS
      ? (await notifications
                    .resolvePlatformSpecificImplementation<
                      IOSFlutterLocalNotificationsPlugin
                    >()
                    ?.checkPermissions())
                ?.isEnabled ??
            false
      : await android?.areNotificationsEnabled() ?? false;
  final now = DateTime.now().toUtc();
  final permissionState = permitted ? 'yes' : 'no';
  if (await store.meta('notificationPermission') != permissionState) {
    await store.log(
      'notification',
      permitted ? '알림 권한 허용' : '알림 권한 꺼짐',
      permitted ? '알림 발송·예약을 진행합니다.' : '권한을 허용하기 전에는 알림을 표시하지 못합니다.',
    );
    await store.setMeta('notificationPermission', permissionState);
  }
  for (final item in items) {
    if (excluded.contains(item.key) ||
        item.status != 'pending' ||
        item.due == null ||
        !item.due!.isAfter(now)) {
      continue;
    }
    final token = 'due:${item.key}:${item.due!.toIso8601String()}';
    final at = item.due!.subtract(const Duration(days: 1));
    if (at.isAfter(now)) {
      // iOS retains at most 64 pending notifications; keep the nearest 60.
      if (Platform.isIOS && desired.length >= 60) continue;
      desired.add(token);
      if (permitted) {
        final wasScheduled = await store.meta(token) == 'scheduled';
        await notifications.zonedSchedule(
          notificationId(token),
          '${item.type == 'LR' ? '과제' : '콘텐츠'} 마감 하루 전',
          '${item.course} · ${item.title}',
          tz.TZDateTime.from(at, tz.UTC),
          noticeStyle,
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          payload: item.key,
        );
        await store.setMeta(token, 'scheduled');
        if (!wasScheduled) {
          await store.log(
            'notification',
            '마감 알림 예약',
            '${item.course} · ${item.title}\n예정: ${koreanTime(at)}',
          );
        }
      }
    } else if (permitted &&
        !['sent', 'scheduled'].contains(await store.meta(token))) {
      await notifications.show(
        notificationId(token),
        '마감까지 하루 이내입니다',
        '${item.course} · ${item.title}',
        noticeStyle,
        payload: item.key,
      );
      await store.setMeta(token, 'sent');
      await store.log(
        'notification',
        '마감 임박 알림 발송 요청',
        '${item.course} · ${item.title}',
      );
    }
  }
  for (final token in old.where((t) => !desired.contains(t))) {
    await notifications.cancel(notificationId(token));
    await store.log(
      'notification',
      '마감 알림 예약 취소',
      '완료·마감 변경·제외 등의 이유로 기존 예약을 취소했습니다.',
    );
  }
  await prefs.setStringList('scheduled', desired);
  if (permitted) {
    for (final event in await store.db.query('events', where: 'delivered=0')) {
      final item = CampusItem.fromJson(jsonDecode(event['payload'] as String));
      if (excluded.contains(item.key)) {
        await store.db.update(
          'events',
          {'delivered': 1},
          where: 'id=?',
          whereArgs: [event['id']],
        );
        continue;
      }
      await notifications.show(
        notificationId(event['id'] as String),
        '새 과제가 등록됐어요',
        '${item.course} · ${item.title}',
        noticeStyle,
        payload: item.key,
      );
      await store.log(
        'notification',
        '새 과제 알림 발송 요청',
        '${item.course} · ${item.title}',
      );
      await store.db.update(
        'events',
        {'delivered': 1},
        where: 'id=?',
        whereArgs: [event['id']],
      );
    }
  }
}

Future<void> excludeItem(CampusItem item, bool exclude) async {
  final store = await Store.open();
  try {
    await store.setMeta('excluded:${item.key}', exclude ? 'yes' : 'no');
    await store.log(
      'received',
      exclude ? '목록에서 제외' : '목록에 복구',
      '${item.course} · ${item.title}',
    );
    if (exclude) {
      await notifications.cancel(notificationId('new:${item.key}'));
      if (item.due != null) {
        await notifications.cancel(
          notificationId('due:${item.key}:${item.due!.toIso8601String()}'),
        );
        await store.setMeta(
          'due:${item.key}:${item.due!.toIso8601String()}',
          '',
        );
      }
    }
    await reconcile(store);
  } finally {
    await store.db.close();
  }
}

Future<void> synchronize() async {
  final store = await Store.open();
  final locked = await store.acquire();
  if (!locked) {
    await store.db.close();
    return;
  }
  final client = CampusClient();
  try {
    final id = await credentials.read(key: 'id');
    final pw = await credentials.read(key: 'pw');
    if (id == null || pw == null) return;
    await store.log('sync', '수집 시작', '포털에 새로 로그인해 과제·콘텐츠·공지를 확인합니다.');
    await client.login(id, pw);
    final items = await client.fetchItems();
    if (await credentials.read(key: 'id') != id) return;
    await store.replace(items);
    for (final item in items) {
      await store.log(
        'received',
        item.type == 'LR' ? '과제 수집' : '콘텐츠 수집',
        '${item.course} · ${item.title}\n상태: ${item.done
            ? '완료'
            : item.status == 'pending'
            ? '미완료'
            : '확인 불가'} · 마감: ${item.due == null ? '미확인' : koreanTime(item.due!)}',
      );
    }
    try {
      final notices = await client.fetchNotices();
      if (await credentials.read(key: 'id') != id) return;
      await store.replaceNotices(notices);
      await store.setMeta('noticeError', '');
      for (final notice in notices) {
        await store.log(
          'received',
          '공지 수집',
          '${notice.course} · ${notice.title}',
        );
      }
      await store.log(
        'sync',
        '수집 완료',
        '과제 ${items.where((i) => i.type == 'LR').length}개 · 콘텐츠 ${items.where((i) => i.type == 'LV').length}개 · 공지 ${notices.length}개',
      );
    } catch (e) {
      final message = e is CampusException
          ? e.message
          : '공지 수집에 실패했습니다. 마지막 공지 목록을 유지합니다.';
      await store.setMeta('noticeError', message);
      await store.log('sync', '공지 수집 실패', '$message\n과제·콘텐츠 결과는 저장했습니다.');
    }
    await reconcile(store);
  } catch (e) {
    await store.log(
      'sync',
      '수집 또는 알림 처리 실패',
      e is CampusException
          ? e.message
          : '네트워크·기기 처리 중 오류가 발생했습니다. 마지막 성공 데이터는 유지합니다.',
    );
    await store.setMeta(
      'lastError',
      e is CampusException ? e.message : '연결하지 못했습니다. 네트워크를 확인하고 다시 시도해 주세요.',
    );
    rethrow;
  } finally {
    client.close();
    await store.setMeta('lease', '0');
    await store.db.close();
  }
}

Future<void> logNotification(String title, String detail) async {
  final store = await Store.open();
  try {
    await store.log('notification', title, detail);
  } finally {
    await store.db.close();
  }
}

@pragma('vm:entry-point')
void backgroundDispatcher() {
  Workmanager().executeTask((task, data) async {
    await initNotifications();
    try {
      await synchronize();
      return true;
    } catch (_) {
      return false;
    }
  });
}

Future<void> registerBackground() => Workmanager().registerPeriodicTask(
  periodicTask,
  periodicTask,
  frequency: const Duration(hours: 1),
  existingWorkPolicy: ExistingPeriodicWorkPolicy.keep,
  constraints: Constraints(networkType: NetworkType.connected),
);

import 'navigation_contract.dart';
import 'ai_chat_page.dart';
import 'notice_pages.dart';
import 'course_catalog.dart';
import 'app_storage.dart';
import 'app_credentials.dart';
import 'course_aliases.dart';
import 'course_labels.dart';
import 'campus_models.dart';
import 'session_scope.dart';
import 'plan_fetch.dart';
import 'course_colors.dart';
import 'dart:io';
import 'ui_refresh.dart';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'campus.dart';

class CoursesPage extends StatefulWidget {
  const CoursesPage({super.key});
  @override
  State<CoursesPage> createState() => _CoursesPageState();
}

class _CoursesPageState extends State<CoursesPage> {
  List<Map<String, dynamic>> courses = [];
  String? error;
  List<CampusItem> pending = [];
  bool loading = true;
  bool refreshing = false;
  @override
  void initState() {
    super.initState();
    unawaited(load());
  }

  Future<void> load() async {
    Store? store;
    try {
      await loadCourseAliases();
      store = await Store.open();
      final data = await readCourses(store);
      final excluded = await store.excluded();
      final tasks =
          (await store.items())
              .where(
                (i) =>
                    i.status == 'pending' &&
                    i.availableAt(DateTime.now().toUtc()) &&
                    !excluded.contains(i.key),
              )
              .toList()
            ..sort(
              (a, b) => (a.due ?? DateTime.utc(2100)).compareTo(
                b.due ?? DateTime.utc(2100),
              ),
            );
      if (mounted) {
        setState(() {
          courses = data;
          pending = tasks;
          error = null;
          loading = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          error = '과목 목록을 읽지 못했습니다.';
          loading = false;
        });
      }
    } finally {
      await store?.db.close();
    }
  }

  Future<void> refreshCourses() async {
    if (refreshing) return;
    setState(() {
      refreshing = true;
      error = null;
    });
    CampusClient? client;
    Store? store;
    final account = await credentials.read(key: 'id');
    try {
      store = await Store.open();
      final scope = await SessionScope.capture(store);
      final password = await credentials.read(key: 'pw');
      if (account == null || password == null) {
        throw CampusException('포털을 먼저 연결해 주세요.');
      }
      client = CampusClient();
      await client.login(account, password);
      final rows = await client.fetchCourses();
      if (await credentials.read(key: 'id') != account) {
        throw CampusException('계정이 변경되어 과목 갱신을 중지했습니다.');
      }
      await scope.verify();
      await store.setMeta('courses', jsonEncode(rows));
      await store.log(
        'sync',
        '수강 과목 목록 새로고침',
        '${rows.length}과목 · 학교 수강 목록에서 조회',
      );
      await load();
    } catch (e) {
      if (mounted) setState(() => error = '과목 새로고침: ${planFailure(e)}');
    } finally {
      client?.close();
      await store?.db.close();
      if (mounted) setState(() => refreshing = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('내 과목'),
      actions: [
        IconButton(
          tooltip: '학교에서 과목 다시 받기',
          onPressed: refreshing ? null : refreshCourses,
          icon: const Icon(Icons.refresh),
        ),
        if (Platform.isAndroid || Platform.isIOS)
          IconButton(
            tooltip: '시간표·수업 알림',
            icon: const Icon(Icons.schedule),
            onPressed: () => navigateTo(context, TimetableDestination()),
          ),
        IconButton(
          tooltip: '전체 공지',
          icon: const Icon(Icons.campaign_outlined),
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const NoticesPage()),
          ),
        ),
        IconButton(
          tooltip: 'AI 채팅',
          icon: const Icon(Icons.chat_bubble_outline),
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AiChatPage()),
          ),
        ),
      ],
    ),
    body: loading
        ? const Center(child: CircularProgressIndicator())
        : RefreshIndicator(
            onRefresh: refreshCourses,
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                SectionHeading(
                  '이번 학기 ${courses.length}과목',
                  subtitle: '과목별 미완료와 가까운 마감을 확인하세요.',
                ),
                if (refreshing) const LinearProgressIndicator(),
                if (Platform.isAndroid || Platform.isIOS)
                  Card(
                    child: ListTile(
                      leading: const Icon(Icons.calendar_month_outlined),
                      title: const Text('나의 시간표'),
                      subtitle: const Text('주간 수업 · 시간표 편집 · 알림'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => navigateTo(context, TimetableDestination()),
                    ),
                  ),
                const SizedBox(height: 16),
                if (error != null) Text(error!),
                if (courses.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(24),
                    child: Text('수집된 과목이 없습니다. 포털 연결 후 지금 확인을 눌러 주세요.'),
                  ),
                ...courses.map((c) {
                  final original = '${c['course_nm']}';
                  final label = courseLabel(original);
                  final tasks = pending
                      .where((i) => courseKey(i.context) == courseKey(c))
                      .toList();
                  return Card(
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: courseAccent(
                          courseKey(c),
                        ).withValues(alpha: .15),
                        foregroundColor:
                            Theme.of(context).brightness == Brightness.dark
                            ? Color.lerp(
                                courseAccent(courseKey(c)),
                                Colors.white,
                                .45,
                              )
                            : courseAccent(courseKey(c)),
                        child: Text(
                          label.isEmpty ? '?' : label.substring(0, 1),
                        ),
                      ),
                      title: Text(label),
                      subtitle: Text(
                        '${label == original ? '' : '$original\n'}${tasks.isEmpty ? '현재 미완료 항목 없음' : '미완료 ${tasks.length}개 · ${tasks.first.due == null ? '기한 미확인' : remainingText(tasks.first)}'}',
                      ),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () async {
                        await navigateTo(context, CourseDestination(course: c));
                        await load();
                      },
                    ),
                  );
                }),
              ],
            ),
          ),
  );
}

import 'dart:convert';
import 'app_storage.dart';

class ChatThread {
  final String id, title;
  final List<Map<String, String>> messages;
  ChatThread(this.id, this.title, this.messages);
  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'messages': messages,
  };
  static ChatThread fromJson(Map<String, dynamic> data) => ChatThread(
    data['id'] as String,
    data['title'] as String,
    (data['messages'] as List).map((m) => Map<String, String>.from(m)).toList(),
  );
}

Future<List<ChatThread>> loadChatThreads(Store store, String key) async {
  final raw = await store.meta('$key:threads');
  if (raw != null) {
    return (jsonDecode(raw) as List)
        .map((e) => ChatThread.fromJson(Map<String, dynamic>.from(e)))
        .toList();
  }
  final legacy = await store.meta(key);
  if (legacy == null) return [];
  final messages = (jsonDecode(legacy) as List)
      .map((e) => Map<String, String>.from(e))
      .toList();
  if (messages.isEmpty) return [];
  return [ChatThread('legacy', '이전 버전의 대화', messages)];
}

Future<void> saveChatThread(Store store, String key, ChatThread thread) async {
  final threads = await loadChatThreads(store, key);
  threads.removeWhere((t) => t.id == thread.id);
  threads.insert(0, thread);
  await store.setMeta(
    '$key:threads',
    jsonEncode(threads.map((t) => t.toJson()).toList()),
  );
}

import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum DiscoverFeature { timetable, chat, ai, calendar, theme, tasks, history }

/// Local-only discovery history. No account, analytics server or network calls.
class FeatureDiscovery {
  static final changed = ValueNotifier<int>(0);
  static final enabled = ValueNotifier<bool>(true);
  static Future<void> _serial = Future.value();
  static Future<void> _write(Future<void> Function(SharedPreferences) action) {
    final next = _serial.then((_) async {
      await action(await SharedPreferences.getInstance());
      changed.value++;
    });
    _serial = next.catchError((_) {});
    return next;
  }

  static Future<void> visit(DiscoverFeature feature) => _write((p) async {
    final seen = (p.getStringList('discoveryVisited') ?? []).toSet();
    if (seen.add(feature.name)) {
      await p.setStringList('discoveryVisited', seen.toList());
    }
  });
  static void record(DiscoverFeature feature) {
    visit(feature).catchError((_) {});
  }

  static Future<void> setEnabled(bool value) => _write((p) async {
    if (!await p.setBool('discoveryEnabled', value)) {
      throw StateError('추천 설정 저장 실패');
    }
    enabled.value = value;
  });
  static Future<void> adopt(Set<DiscoverFeature> known) => _write((p) async {
    if (p.getBool('discoverySeeded053') == true) return;
    final seen = (p.getStringList('discoveryVisited') ?? []).toSet();
    seen.addAll(known.map((f) => f.name));
    if (p.containsKey('radarTheme') || p.containsKey('radarAccent')) {
      seen.add(DiscoverFeature.theme.name);
    }
    await p.setStringList('discoveryVisited', seen.toList());
    await p.setBool('discoverySeeded053', true);
  });
  static Future<DiscoverFeature?> choose({
    bool another = false,
    Random? random,
    DateTime? now,
  }) async {
    await _serial;
    final p = await SharedPreferences.getInstance();
    enabled.value = p.getBool('discoveryEnabled') ?? true;
    if (!enabled.value) return null;
    final seen = (p.getStringList('discoveryVisited') ?? []).toSet();
    final choices = DiscoverFeature.values
        .where((f) => !seen.contains(f.name))
        .toList();
    if (choices.isEmpty) return null;
    final previous = p.getString('discoveryCurrent');
    final day = (now ?? DateTime.now()).toIso8601String().substring(0, 10);
    final sameDay = p.getString('discoveryDay') == day;
    if (!another && sameDay && choices.any((f) => f.name == previous)) {
      return choices.firstWhere((f) => f.name == previous);
    }
    if ((another || !sameDay) && choices.length > 1) {
      choices.removeWhere((f) => f.name == previous);
    }
    final selected = choices[(random ?? Random()).nextInt(choices.length)];
    await p.setString('discoveryCurrent', selected.name);
    await p.setString('discoveryDay', day);
    return selected;
  }
}

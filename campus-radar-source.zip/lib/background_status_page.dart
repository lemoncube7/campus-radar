import 'native_contract.dart';
import 'task_presentation.dart';
import 'app_storage.dart';
import 'native_bridge.dart';
import 'ui_refresh.dart';
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'services.dart';

class BackgroundStatusPage extends StatefulWidget {
  const BackgroundStatusPage({super.key});
  @override
  State<BackgroundStatusPage> createState() => _BackgroundStatusPageState();
}

class _BackgroundStatusPageState extends State<BackgroundStatusPage> {
  Map<dynamic, dynamic>? data;
  String? started, success, error, successKind;
  bool scheduling = false;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final status = await bridge.invokeNativeMap<dynamic, dynamic>(
        NativeMethod.backgroundStatus,
      );
      final store = await Store.open();
      try {
        final lastStart = await store.meta('workerStarted');
        final lastSuccess = await store.meta('workerSuccess');
        final kind = await store.meta('workerSource');
        if (mounted) {
          setState(() {
            data = status;
            started = lastStart;
            success = lastSuccess;
            successKind = kind;
            error = null;
          });
        }
      } finally {
        await store.db.close();
      }
    } catch (_) {
      if (mounted) setState(() => error = '백그라운드 상태를 읽지 못했습니다.');
    }
  }

  String stamp(String? time) =>
      time == null ? '이 업데이트 이후 기록 없음' : formatDate(DateTime.parse(time));
  String stateName(String state) =>
      const {
        'ENQUEUED': '실행 대기',
        'RUNNING': '실행 중',
        'SUCCEEDED': '완료',
        'FAILED': '실패',
        'CANCELLED': '취소',
        'BLOCKED': '선행 작업 대기',
        'SCHEDULED': '예약',
        'STARTED': '실행 시작',
        'COMPLETED': '완료',
        'RESCHEDULED': '재시도 예약',
        'RETRYING': '재시도 시작',
      }[state] ??
      state;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('백그라운드 상태'),
      actions: [
        IconButton(
          onPressed: load,
          icon: const Icon(Icons.refresh),
          tooltip: '상태 새로고침',
        ),
      ],
    ),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        if (Platform.isAndroid && data != null)
          Card(
            child: ListTile(
              leading: Icon(
                data!['batteryExempt'] == true &&
                        data!['backgroundRestricted'] != true
                    ? Icons.check_circle_outline
                    : Icons.battery_alert_outlined,
              ),
              title: Text(
                data!['batteryExempt'] == true &&
                        data!['backgroundRestricted'] != true
                    ? '배터리 설정 확인됨'
                    : '배터리 설정 확인 필요',
              ),
              subtitle: const Text('자동 수집은 운영체제의 실행 정책을 따릅니다.'),
              trailing: TextButton(
                onPressed: () =>
                    bridge.invokeNative(NativeMethod.openAppSettings),
                child: const Text('설정 열기'),
              ),
            ),
          ),
        const SectionHeading('최근 자동 수집'),
        const Text(
          '앱을 열어 수집한 기록과 자동 수집 기록을 구분합니다. 작업이 예약되어 있어도 운영체제가 실행을 늦출 수 있습니다.',
        ),
        const SizedBox(height: 16),
        Text('마지막 백그라운드 진입: ${stamp(started)}'),
        Text(
          '마지막 백그라운드 수집 성공${successKind == null ? '' : ' ($successKind)'}: ${stamp(success)}',
        ),
        const SizedBox(height: 12),
        if (Platform.isAndroid)
          FilledButton.tonal(
            onPressed: scheduling
                ? null
                : () async {
                    setState(() => scheduling = true);
                    try {
                      await scheduleBackgroundTrial();
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text(
                              '시험을 예약했습니다. 홈 화면으로 나가 기다린 뒤 수집 로그를 확인하세요.',
                            ),
                          ),
                        );
                      }
                    } catch (_) {
                      if (mounted) setState(() => error = '시험 작업을 예약하지 못했습니다.');
                    } finally {
                      if (mounted) setState(() => scheduling = false);
                    }
                  },
            child: const Text('백그라운드 수집 시험 예약'),
          ),
        const Text(
          '30초 이후 실행 가능한 시험입니다. 실행 시각은 운영체제가 결정하며 정기 자동 수집과 별도입니다.',
          style: TextStyle(fontSize: 12),
        ),
        if (error != null) Text(error!),
        if (data == null && error == null) const LinearProgressIndicator(),
        if (Platform.isIOS && data != null) ...[
          const Divider(),
          Text(
            '백그라운드 앱 새로 고침: ${data!['backgroundRefresh'] == true ? '허용됨' : '제한됨 또는 사용 불가'}',
          ),
          const Text(
            'iOS가 자동 수집 시각을 결정합니다. 설정 → 일반 → 백그라운드 앱 새로 고침에서 확인하세요. AI 순차 분석은 앱을 열어 둔 동안 이어집니다.',
          ),
          TextButton(
            onPressed: () => bridge.invokeNative(NativeMethod.openAppSettings),
            child: const Text('앱 설정 열기'),
          ),
        ],
        if (Platform.isAndroid && data != null) ...[
          const Divider(),

          Text(
            '앱 배터리 최적화 예외: ${data!['batteryExempt'] == null
                ? '확인 불가'
                : data!['batteryExempt'] == true
                ? '허용됨'
                : '아님'}',
          ),
          Text(
            '앱 백그라운드 제한: ${data!['backgroundRestricted'] == true ? '제한됨' : '제한 표시 없음'}',
          ),
          Text(
            '데이터 절약 모드의 앱 제한: ${data!['dataSaver'] == 3 ? '제한됨' : '제한 표시 없음'}',
          ),
          OutlinedButton(
            onPressed: () async {
              await bridge.invokeNative(NativeMethod.openAppSettings);
            },
            child: const Text('앱 설정 열기'),
          ),
          const Divider(),
          const Text(
            '운영체제의 자동 수집 작업',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          if ((data!['jobs'] as List? ?? []).isEmpty)
            const Text('예약된 작업이 없습니다. 포털 연결 상태를 확인하세요.'),
          for (final job in data!['jobs'] as List? ?? [])
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(stateName(job['state'] as String)),
                    Text('현재 재시도 횟수: ${job['attempts']}'),
                    if (job['nextAt'] is int &&
                        job['nextAt'] > 0 &&
                        job['nextAt'] < 4102444800000)
                      Text(
                        '가장 빠른 실행 가능 시각: ${formatDate(DateTime.fromMillisecondsSinceEpoch(job['nextAt']))}',
                      ),
                    const Text(
                      '이 시각에 반드시 실행된다는 뜻은 아닙니다.',
                      style: TextStyle(fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
          const Divider(),
          const Text(
            '운영체제 작업 실행 기록',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const Text(
            '수집 코드에 진입하기 전의 실패도 확인하기 위한 최근 100건 기록입니다.',
            style: TextStyle(fontSize: 12),
          ),
          for (final event in (data!['events'] as List? ?? []).reversed)
            ListTile(
              title: Text(stateName(event['state'] as String)),
              subtitle: Text(
                '${formatDate(DateTime.fromMillisecondsSinceEpoch(event['at']))}\n처리 시간 ${event['durationMs']} ms',
              ),
            ),
        ],
      ],
    ),
  );
}

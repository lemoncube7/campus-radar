import 'session_probe_policy.dart';
import 'collection_control.dart';
import 'campus_session.dart';
import 'campus.dart';
import 'app_credentials.dart';
import 'native_contract.dart';
import 'task_presentation.dart';
import 'app_storage.dart';
import 'native_bridge.dart';
import 'ui_refresh.dart';
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'services.dart';

class BackgroundStatusPage extends StatefulWidget {
  const BackgroundStatusPage({super.key});
  @override
  State<BackgroundStatusPage> createState() => _BackgroundStatusPageState();
}

class _BackgroundStatusPageState extends State<BackgroundStatusPage> {
  bool? automaticConnection;
  bool sessionTestActive = false;
  int? reconnectMinutes;
  String? sessionLostAt;
  bool reconnectLoaded = false;
  int? collectionMinutes;
  Map<dynamic, dynamic>? data;
  String? started, success, error, successKind;
  bool scheduling = false;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final automatic = await automaticSchoolConnectionPreference();
      final testing = await sessionProbeActive();
      final reconnect = await schoolReconnectMinutes();
      final interval = await schoolCollectionMinutes();
      Map<dynamic, dynamic>? status;
      String? platformWarning;
      if (Platform.isAndroid) {
        try {
          status = await bridge.invokeNativeMap<dynamic, dynamic>(
            NativeMethod.backgroundStatus,
          );
        } catch (_) {
          platformWarning = '기기 작업 상태를 읽지 못했지만 학교 연결 설정은 변경할 수 있어요.';
        }
      }
      final store = await Store.open();
      try {
        final epoch = await store.meta('sessionEpoch');
        final lostEpoch = await store.meta('schoolSessionLostEpoch');
        final rawLost = await store.meta('schoolSessionLostAt');
        final lost = epoch != null && lostEpoch == epoch
            ? DateTime.tryParse(rawLost ?? '')?.toUtc().toIso8601String()
            : null;
        final lastStart = await store.meta('workerStarted');
        final lastSuccess = await store.meta('workerSuccess');
        final kind = await store.meta('workerSource');
        if (mounted) {
          setState(() {
            data = status;
            automaticConnection = automatic;
            sessionTestActive = testing;
            reconnectMinutes = reconnect;
            collectionMinutes = interval;
            reconnectLoaded = true;
            sessionLostAt = lost;
            started = lastStart;
            success = lastSuccess;
            successKind = kind;
            error = platformWarning;
          });
        }
      } finally {
        await store.db.close();
      }
    } catch (_) {
      if (mounted) setState(() => error = '백그라운드 상태를 읽지 못했습니다.');
    }
  }

  String stamp(String? time) {
    final date = DateTime.tryParse(time ?? '');
    return date == null ? '확인된 기록 없음' : formatDate(date);
  }

  String stateName(String state) =>
      const {
        'ENQUEUED': '실행 대기',
        'RUNNING': '실행 중',
        'SUCCEEDED': '완료',
        'FAILED': '실패',
        'CANCELLED': '취소',
        'BLOCKED': '선행 작업 대기',
        'SCHEDULED': '예약',
        'STARTED': '실행 시작',
        'COMPLETED': '완료',
        'RESCHEDULED': '재시도 예약',
        'RETRYING': '재시도 시작',
      }[state] ??
      state;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('학교 연결·수집'),
      actions: [
        IconButton(
          onPressed: load,
          icon: const Icon(Icons.refresh),
          tooltip: '상태 새로고침',
        ),
      ],
    ),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        if (automaticConnection == null && error == null)
          const LinearProgressIndicator(),
        if (error != null)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                error!,
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            ),
          ),
        if (sessionLostAt != null && automaticConnection == true)
          Card(
            child: ListTile(
              leading: const Icon(Icons.pause_circle_outline),
              title: const Text('학교 재연결 대기 중'),
              subtitle: Text(
                reconnectMinutes == null
                    ? '자동 재로그인하지 않아요. 수집 설정에서 직접 연결할 수 있어요.'
                    : '인증 종료 ${stamp(sessionLostAt)} · $reconnectMinutes분 대기 후 다음 수집에서 재연결해요.',
              ),
            ),
          ),
        Card(
          child: ListTile(
            leading: Icon(
              success == null ? Icons.sync : Icons.check_circle_outline,
            ),
            title: Text(
              sessionTestActive
                  ? '세션 탐색 중 · 평소 수집 중지'
                  : automaticConnection == null
                  ? '수집 상태 확인 중'
                  : automaticConnection == true
                  ? '자동 수집 켜짐'
                  : '자동 수집 꺼짐',
            ),
            subtitle: Text('최근 자동 수집 성공: ${stamp(success)}'),
          ),
        ),
        ExpansionTile(
          title: const Text('자동 수집 설정'),
          subtitle: Text(
            '${collectionMinutes ?? 60}분 간격 · 재연결 ${!reconnectLoaded
                ? "확인 중"
                : reconnectMinutes == null
                ? "직접"
                : "$reconnectMinutes분 대기"}',
          ),
          children: [
            SwitchListTile(
              title: const Text('학교 자동 연결'),
              subtitle: Text(
                sessionTestActive
                    ? '전용 세션 테스트 중에는 평소 자동 수집이 일시 중지돼요. 이 설정은 테스트를 끝낸 뒤 다시 적용돼요.'
                    : '끄면 앱 시작·복귀와 백그라운드에서 새 수집을 시작하지 않아요. 수동 확인은 가능하고 저장된 내용·예약 알림은 유지해요. 이미 진행 중인 연결은 끝날 수 있어요.',
              ),
              value: automaticConnection ?? false,
              onChanged: automaticConnection == null || scheduling
                  ? null
                  : (value) async {
                      setState(() => scheduling = true);
                      try {
                        await setAutomaticSchoolConnection(value);
                      } catch (_) {
                        if (mounted) {
                          setState(
                            () => error = '설정은 저장했지만 작업 예약 변경을 확인하지 못했어요.',
                          );
                        }
                      } finally {
                        if (mounted) {
                          setState(() => scheduling = false);
                          await load();
                        }
                      }
                    },
            ),

            if (Platform.isAndroid)
              ListTile(
                title: const Text('자동 수집 간격'),
                subtitle: const Text(
                  '기존 세션으로 확인해요. Android 실행 조건에 따라 늦어질 수 있어요. 세션이 끊기면 아래 재로그인 대기가 우선해요.',
                ),
                trailing: DropdownButton<int>(
                  value: collectionMinutes ?? 60,
                  items: [
                    for (final minutes in schoolCollectionIntervals)
                      DropdownMenuItem(
                        value: minutes,
                        child: Text(
                          minutes < 60 ? '$minutes분' : '${minutes ~/ 60}시간',
                        ),
                      ),
                  ],
                  onChanged: collectionMinutes == null || scheduling
                      ? null
                      : (value) async {
                          if (value == null) return;
                          setState(() => scheduling = true);
                          try {
                            await saveSchoolCollectionMinutes(value);
                            await registerBackground(updateInterval: true);
                            await load();
                          } catch (_) {
                            if (mounted) {
                              setState(
                                () => error =
                                    '간격은 저장했지만 작업 예약을 갱신하지 못했어요. 다시 선택해 주세요.',
                              );
                            }
                          } finally {
                            if (mounted) setState(() => scheduling = false);
                          }
                        },
                ),
              ),
            ListTile(
              title: const Text('다른 기기 로그인 시 재연결 대기'),
              subtitle: Text(
                '기존 세션을 먼저 재사용해요. 인증이 끊기면 다른 기기에서 로그인했을 가능성을 고려해 대기해요. 기본 2시간이며 원인을 확정하는 기능은 아니에요. '
                '${sessionLostAt != null && sessionLostAt!.isNotEmpty ? '인증 종료 확인: ${stamp(sessionLostAt)}. ${reconnectMinutes == null ? '직접 재연결을 기다려요.' : '재연결 가능 시각: ${stamp(DateTime.tryParse(sessionLostAt!)?.add(Duration(minutes: reconnectMinutes!)).toIso8601String())} 이후 다음 수집.'} ' : ''}'
                '대기 시간이 지나도 시험 중인지는 알 수 없으니, 시험 중에는 학교 자동 연결을 꺼 주세요.',
              ),
              trailing: DropdownButton<int>(
                value: reconnectMinutes ?? -1,
                items: [
                  const DropdownMenuItem(value: -1, child: Text('직접 재연결')),
                  for (final minutes in reconnectChoices)
                    DropdownMenuItem(
                      value: minutes,
                      child: Text(
                        minutes < 60 ? '$minutes분' : '${minutes ~/ 60}시간',
                      ),
                    ),
                ],
                onChanged: !reconnectLoaded
                    ? null
                    : (value) async {
                        await saveSchoolReconnectMinutes(
                          value == -1 ? null : value,
                        );
                        if (mounted) {
                          setState(
                            () => reconnectMinutes = value == -1 ? null : value,
                          );
                        }
                      },
              ),
            ),
            if (sessionLostAt != null && sessionLostAt!.isNotEmpty)
              OutlinedButton.icon(
                onPressed: scheduling
                    ? null
                    : () async {
                        final accepted = await showDialog<bool>(
                          context: context,
                          builder: (ctx) => AlertDialog(
                            title: const Text('지금 학교에 다시 로그인할까요?'),
                            content: const Text(
                              '다른 기기에서 시험이나 제출 중이면 연결이 끊길 수 있어요. 진행 중인 작업이 없을 때 다시 연결해 주세요.',
                            ),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(ctx, false),
                                child: const Text('취소'),
                              ),
                              FilledButton(
                                onPressed: () => Navigator.pop(ctx, true),
                                child: const Text('다시 연결'),
                              ),
                            ],
                          ),
                        );
                        if (accepted != true || !mounted) return;
                        setState(() => scheduling = true);
                        final client = CampusClient();
                        try {
                          final id = await credentials.read(key: 'id');
                          final pw = await credentials.read(key: 'pw');
                          if (id == null || pw == null) {
                            throw CampusException('포털 계정을 먼저 연결해 주세요.');
                          }
                          await client.connectSchool(
                            id,
                            pw,
                            reconnectNow: true,
                          );
                          await load();
                        } catch (e) {
                          if (mounted) {
                            setState(
                              () => error = e is CampusException
                                  ? e.message
                                  : '학교에 다시 연결하지 못했어요. 기존 목록은 유지돼요.',
                            );
                          }
                        } finally {
                          client.close();
                          if (mounted) setState(() => scheduling = false);
                        }
                      },
                icon: const Icon(Icons.link),
                label: const Text('지금 다시 연결'),
              ),
          ],
        ),
        if (Platform.isAndroid &&
            data != null &&
            (data!['batteryExempt'] != true ||
                data!['backgroundRestricted'] == true))
          Card(
            child: ListTile(
              leading: Icon(
                data!['batteryExempt'] == true &&
                        data!['backgroundRestricted'] != true
                    ? Icons.check_circle_outline
                    : Icons.battery_alert_outlined,
              ),
              title: Text(
                data!['batteryExempt'] == true &&
                        data!['backgroundRestricted'] != true
                    ? '배터리 설정 확인됨'
                    : '배터리 설정 확인 필요',
              ),
              subtitle: const Text('자동 수집은 운영체제의 실행 정책을 따릅니다.'),
              trailing: TextButton(
                onPressed: () =>
                    bridge.invokeNative(NativeMethod.openAppSettings),
                child: const Text('설정 열기'),
              ),
            ),
          ),
        ExpansionTile(
          title: const Text('상세 진단·수집 시험'),
          subtitle: const Text('작업 예약 · 재시도 · 운영체제 실행 기록'),
          children: [
            const SectionHeading('최근 자동 수집'),
            const Text(
              '앱을 열어 수집한 기록과 자동 수집 기록을 구분합니다. 작업이 예약되어 있어도 운영체제가 실행을 늦출 수 있습니다.',
            ),
            const SizedBox(height: 16),
            Text('마지막 백그라운드 진입: ${stamp(started)}'),
            Text(
              '마지막 백그라운드 수집 성공${successKind == null ? '' : ' ($successKind)'}: ${stamp(success)}',
            ),
            const SizedBox(height: 12),
            if (Platform.isAndroid)
              FilledButton.tonal(
                onPressed:
                    scheduling ||
                        automaticConnection == false ||
                        sessionTestActive
                    ? null
                    : () async {
                        setState(() => scheduling = true);
                        try {
                          await scheduleBackgroundTrial();
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                  '시험을 예약했습니다. 홈 화면으로 나가 기다린 뒤 수집 로그를 확인하세요.',
                                ),
                              ),
                            );
                          }
                        } catch (_) {
                          if (mounted) {
                            setState(() => error = '시험 작업을 예약하지 못했습니다.');
                          }
                        } finally {
                          if (mounted) setState(() => scheduling = false);
                        }
                      },
                child: const Text('백그라운드 수집 시험 예약'),
              ),
            const Text(
              '30초 이후 실행 가능한 시험입니다. 실행 시각은 운영체제가 결정하며 정기 자동 수집과 별도입니다.',
              style: TextStyle(fontSize: 12),
            ),
            if (Platform.isIOS && data != null) ...[
              const Divider(),
              Text(
                '백그라운드 앱 새로 고침: ${data!['backgroundRefresh'] == true ? '허용됨' : '제한됨 또는 사용 불가'}',
              ),
              const Text(
                'iOS가 자동 수집 시각을 결정합니다. 설정 → 일반 → 백그라운드 앱 새로 고침에서 확인하세요. AI 순차 분석은 앱을 열어 둔 동안 이어집니다.',
              ),
              TextButton(
                onPressed: () =>
                    bridge.invokeNative(NativeMethod.openAppSettings),
                child: const Text('앱 설정 열기'),
              ),
            ],
            if (Platform.isAndroid && data != null) ...[
              const Divider(),

              Text(
                '앱 배터리 최적화 예외: ${data!['batteryExempt'] == null
                    ? '확인 불가'
                    : data!['batteryExempt'] == true
                    ? '허용됨'
                    : '아님'}',
              ),
              Text(
                '앱 백그라운드 제한: ${data!['backgroundRestricted'] == true ? '제한됨' : '제한 표시 없음'}',
              ),
              Text(
                '데이터 절약 모드의 앱 제한: ${data!['dataSaver'] == 3 ? '제한됨' : '제한 표시 없음'}',
              ),
              OutlinedButton(
                onPressed: () async {
                  await bridge.invokeNative(NativeMethod.openAppSettings);
                },
                child: const Text('앱 설정 열기'),
              ),
              const Divider(),
              const Text(
                '운영체제의 자동 수집 작업',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              if ((data!['jobs'] as List? ?? []).isEmpty)
                const Text('예약된 작업이 없습니다. 포털 연결 상태를 확인하세요.'),
              for (final job in data!['jobs'] as List? ?? [])
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(stateName(job['state'] as String)),
                        Text('현재 재시도 횟수: ${job['attempts']}'),
                        if (job['nextAt'] is int &&
                            job['nextAt'] > 0 &&
                            job['nextAt'] < 4102444800000)
                          Text(
                            '가장 빠른 실행 가능 시각: ${formatDate(DateTime.fromMillisecondsSinceEpoch(job['nextAt']))}',
                          ),
                        const Text(
                          '이 시각에 반드시 실행된다는 뜻은 아닙니다.',
                          style: TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                ),
              const Divider(),
              const Text(
                '운영체제 작업 실행 기록',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const Text(
                '수집 코드에 진입하기 전의 실패도 확인하기 위한 최근 100건 기록입니다.',
                style: TextStyle(fontSize: 12),
              ),
              for (final event in (data!['events'] as List? ?? []).reversed)
                ListTile(
                  title: Text(stateName(event['state'] as String)),
                  subtitle: Text(
                    '${formatDate(DateTime.fromMillisecondsSinceEpoch(event['at']))}\n처리 시간 ${event['durationMs']} ms',
                  ),
                ),
            ],
          ],
        ),
      ],
    ),
  );
}

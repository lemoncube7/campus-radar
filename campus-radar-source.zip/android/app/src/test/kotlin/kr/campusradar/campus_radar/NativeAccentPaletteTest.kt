package kr.campusradar.campus_radar
import org.junit.Assert.*
import org.junit.Test
class NativeAccentPaletteTest {
 @Test fun defaultCompanionMatchesAppMigration(){val p=NativeAccentPalette.pairing("purple",null);assertEquals(0xff8852b3.toInt(),p.primary);assertEquals(0xff197e7b.toInt(),p.secondary)}
 @Test fun independentSelectionAndInvalidFallback(){val p=NativeAccentPalette.pairing("blue","rose");assertEquals(0xff2864bd.toInt(),p.primary);assertEquals(0xffb34670.toInt(),p.secondary);assertEquals(NativeAccentPalette.pairing(null,null),NativeAccentPalette.pairing("bad","bad"))}
 @Test fun darkAccentHasReadableLightChannels(){val c=NativeAccentPalette.onDark(0xff197e7b.toInt());assertEquals(255,c ushr 24);assertTrue(((c ushr 16) and 255)>=150);assertTrue(((c ushr 8) and 255)>=150);assertTrue((c and 255)>=150)}
}

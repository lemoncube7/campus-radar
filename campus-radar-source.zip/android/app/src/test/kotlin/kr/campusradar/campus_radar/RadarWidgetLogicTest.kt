package kr.campusradar.campus_radar

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

class RadarWidgetLogicTest {
    private val zone = ZoneId.of("Asia/Seoul")

    @Test
    fun radarWidgetAppendsCancelledSuffixWhenClassIsCancelled() {
        val today = LocalDate.of(2026, 11, 11)
        val start = ZonedDateTime.of(2026, 11, 11, 14, 0, 0, 0, zone)

        val text = RadarWidgetLogic.formatNextClass(
            courseName = "알고리즘",
            start = start,
            today = today,
            isCancelled = true
        )

        assertEquals("다음 · 14:00 · 알고리즘 (휴강으로 인식됨)", text)
    }

    @Test
    fun radarWidgetDoesNotAppendCancelledSuffixWhenClassIsNotCancelled() {
        val today = LocalDate.of(2026, 11, 11)
        val start = ZonedDateTime.of(2026, 11, 12, 10, 0, 0, 0, zone)

        val text = RadarWidgetLogic.formatNextClass(
            courseName = "자료구조",
            start = start,
            today = today,
            isCancelled = false
        )

        assertEquals("다음 · 내일 10:00 · 자료구조", text)
    }
}

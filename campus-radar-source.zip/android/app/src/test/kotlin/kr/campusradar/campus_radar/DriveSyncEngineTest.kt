package kr.campusradar.campus_radar

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import java.util.Base64

class FakeDriveApi : DriveApi("fake-token") {
    data class Record(
        var id: String,
        var name: String,
        var mimeType: String,
        var parents: MutableList<String>,
        var content: ByteArray,
        var createdTime: String,
        var trashed: Boolean = false,
        var appProperties: MutableMap<String, String> = mutableMapOf()
    )

    val records = mutableMapOf<String, Record>()
    private var nextId = 1
    var writeCount = 0

    override fun id(): String = "id-${nextId++}"

    override fun exists(id: String): Boolean {
        val r = records[id] ?: return false
        return !r.trashed
    }

    override fun createFolder(id: String, name: String, parent: String?, appProperties: Map<String, String>?) {
        records[id] = Record(
            id = id,
            name = name,
            mimeType = "application/vnd.google-apps.folder",
            parents = if (parent != null) mutableListOf(parent) else mutableListOf(),
            content = ByteArray(0),
            createdTime = "2026-11-01T00:00:00Z",
            appProperties = appProperties?.toMutableMap() ?: mutableMapOf()
        )
    }

    override fun createText(id: String, name: String, parent: String, appProperties: Map<String, String>?) {
        records[id] = Record(
            id = id,
            name = name,
            mimeType = "text/plain",
            parents = mutableListOf(parent),
            content = ByteArray(0),
            createdTime = "2026-11-01T00:00:00Z",
            appProperties = appProperties?.toMutableMap() ?: mutableMapOf()
        )
    }

    override fun createFile(id: String, name: String, mime: String, parent: String, appProperties: Map<String, String>?) {
        records[id] = Record(
            id = id,
            name = name,
            mimeType = mime,
            parents = mutableListOf(parent),
            content = ByteArray(0),
            createdTime = "2026-11-01T00:00:00Z",
            appProperties = appProperties?.toMutableMap() ?: mutableMapOf()
        )
    }

    override fun write(id: String, text: String) {
        val r = records[id] ?: throw DriveHttpFailure(404)
        r.content = text.toByteArray(Charsets.UTF_8)
        writeCount++
    }

    override fun writeBytes(id: String, bytes: ByteArray, mime: String) {
        val r = records[id] ?: throw DriveHttpFailure(404)
        r.content = bytes
        r.mimeType = mime
        writeCount++
    }

    override fun trash(id: String) {
        val r = records[id] ?: throw DriveHttpFailure(404)
        r.trashed = true
    }

    override fun updateMetadata(
        id: String,
        name: String?,
        appProperties: Map<String, String>?,
        addParents: List<String>?,
        removeParents: List<String>?
    ) {
        val r = records[id] ?: throw DriveHttpFailure(404)
        if (name != null) r.name = name
        if (appProperties != null) r.appProperties.putAll(appProperties)
        if (addParents != null) r.parents.addAll(addParents)
        if (removeParents != null) r.parents.removeAll(removeParents.toSet())
    }

    override fun listByQuery(query: String): List<DriveItem> {
        val result = mutableListOf<DriveItem>()
        for (r in records.values) {
            if (r.trashed) continue
            if (query.contains("key='crKind'") && !r.appProperties.containsKey("crKind")) {
                continue
            }
            result.add(
                DriveItem(
                    id = r.id,
                    name = r.name,
                    createdTime = r.createdTime,
                    mimeType = r.mimeType,
                    size = r.content.size.toLong(),
                    parents = r.parents,
                    appProperties = r.appProperties
                )
            )
        }
        return result
    }

    override fun listChildren(parent: String, name: String?, folderOnly: Boolean): List<DriveItem> {
        val result = mutableListOf<DriveItem>()
        for (r in records.values) {
            if (r.trashed) continue
            if (parent == "root") {
                if (r.parents.isNotEmpty() && !r.parents.contains("root")) continue
            } else {
                if (!r.parents.contains(parent)) continue
            }
            if (folderOnly && r.mimeType != "application/vnd.google-apps.folder") continue
            if (name != null && r.name != name) continue
            result.add(
                DriveItem(
                    id = r.id,
                    name = r.name,
                    createdTime = r.createdTime,
                    mimeType = r.mimeType,
                    size = r.content.size.toLong(),
                    parents = r.parents,
                    appProperties = r.appProperties
                )
            )
        }
        return result
    }

    override fun rename(id: String, newName: String) {
        val r = records[id] ?: throw DriveHttpFailure(404)
        r.name = newName
    }
}

class DriveSyncEngineTest {

    @Test
    fun testA_065StateUpgradeMigratesLegacyKeysAndSkipsRedundantUpload() {
        val api = FakeDriveApi()

        api.records["rootFolder"] = FakeDriveApi.Record(
            id = "rootFolder",
            name = "캠퍼스레이더",
            mimeType = "application/vnd.google-apps.folder",
            parents = mutableListOf(),
            content = ByteArray(0),
            createdTime = "2026-11-01T00:00:00Z"
        )
        api.records["courseFolder"] = FakeDriveApi.Record(
            id = "courseFolder",
            name = "과목",
            mimeType = "application/vnd.google-apps.folder",
            parents = mutableListOf("rootFolder"),
            content = ByteArray(0),
            createdTime = "2026-11-01T00:00:01Z"
        )
        api.records["matFolder"] = FakeDriveApi.Record(
            id = "matFolder",
            name = "자료",
            mimeType = "application/vnd.google-apps.folder",
            parents = mutableListOf("rootFolder"),
            content = ByteArray(0),
            createdTime = "2026-11-01T00:00:02Z"
        )
        api.records["cMatFolder"] = FakeDriveApi.Record(
            id = "cMatFolder",
            name = "어드벤처디자인",
            mimeType = "application/vnd.google-apps.folder",
            parents = mutableListOf("matFolder"),
            content = ByteArray(0),
            createdTime = "2026-11-01T00:00:03Z"
        )
        val fileBytes = ByteArray(47616) { 0 }
        api.records["legacyFile"] = FakeDriveApi.Record(
            id = "legacyFile",
            name = "(양식) 어드벤처디자인_팀활동보고서.hwp",
            mimeType = "application/octet-stream",
            parents = mutableListOf("cMatFolder"),
            content = fileBytes,
            createdTime = "2026-11-01T00:00:04Z"
        )
        val docContent = "course_doc_content"
        api.records["legacyDoc"] = FakeDriveApi.Record(
            id = "legacyDoc",
            name = "어드벤처디자인.txt",
            mimeType = "text/plain",
            parents = mutableListOf("courseFolder"),
            content = docContent.toByteArray(Charsets.UTF_8),
            createdTime = "2026-11-01T00:00:05Z"
        )

        val initialCount = api.records.size

        val row = JSONObject().apply {
            put("folder", "rootFolder")
            put("courseFolder", "courseFolder")
            put("materialsFolder", "matFolder")
            put("materialsCourses", JSONObject().put("어드벤처디자인", "cMatFolder"))
            put("files", JSONObject().apply {
                put("자료/어드벤처디자인 /(양식) 어드벤처디자인_팀활동보고서.hwp", "legacyFile")
                put("과목/어드벤처디자인 .txt", "legacyDoc")
            })
            put("hashes", JSONObject().apply {
                put("자료/어드벤처디자인 /(양식) 어드벤처디자인_팀활동보고서.hwp", "hash_47616")
                put("과목/어드벤처디자인 .txt", DriveApi.digest(docContent))
            })
        }

        val payload = JSONObject().apply {
            put("documents", JSONObject().put("과목/어드벤처디자인.txt", docContent))
            put("files", JSONObject().put(
                "자료/어드벤처디자인/(양식) 어드벤처디자인_팀활동보고서.hwp",
                JSONObject().apply {
                    put("sha256", "hash_47616")
                    put("mime", "application/octet-stream")
                    put("bytesBase64", Base64.getEncoder().encodeToString(fileBytes))
                    put("crKey", "att:report_123")
                }
            ))
        }

        val res = DriveSyncEngine.syncAccount(
            api = api,
            row = row,
            payload = payload,
            term = "2026-2"
        )

        assertEquals("First sync from 0.6.5 state must write 0", 0, res.writes)
        assertEquals("Must not create new files", initialCount, api.records.size)
        assertEquals("file", api.records["legacyFile"]!!.appProperties["crKind"])
        assertEquals("att:report_123", api.records["legacyFile"]!!.appProperties["crKey"])
        assertEquals("file", api.records["legacyDoc"]!!.appProperties["crKind"])
    }

    @Test
    fun testB_deletedLocalRecordsCreatesZeroNewFilesAndRestoresCache() {
        val api = FakeDriveApi()

        api.records["rootFolder"] = FakeDriveApi.Record(
            id = "rootFolder",
            name = "캠퍼스레이더",
            mimeType = "application/vnd.google-apps.folder",
            parents = mutableListOf(),
            content = ByteArray(0),
            createdTime = "2026-11-01T00:00:00Z",
            appProperties = mutableMapOf("crKind" to "root", "crKey" to "root")
        )
        api.records["courseFolder"] = FakeDriveApi.Record(
            id = "courseFolder",
            name = "과목",
            mimeType = "application/vnd.google-apps.folder",
            parents = mutableListOf("rootFolder"),
            content = ByteArray(0),
            createdTime = "2026-11-01T00:00:01Z",
            appProperties = mutableMapOf("crKind" to "course", "crKey" to "course")
        )
        api.records["matFolder"] = FakeDriveApi.Record(
            id = "matFolder",
            name = "자료",
            mimeType = "application/vnd.google-apps.folder",
            parents = mutableListOf("rootFolder"),
            content = ByteArray(0),
            createdTime = "2026-11-01T00:00:02Z",
            appProperties = mutableMapOf("crKind" to "materials", "crKey" to "materials")
        )
        api.records["cMatFolder"] = FakeDriveApi.Record(
            id = "cMatFolder",
            name = "어드벤처디자인",
            mimeType = "application/vnd.google-apps.folder",
            parents = mutableListOf("matFolder"),
            content = ByteArray(0),
            createdTime = "2026-11-01T00:00:03Z",
            appProperties = mutableMapOf("crKind" to "materials", "crKey" to "materials:어드벤처디자인")
        )
        val fileBytes = ByteArray(47616) { 0 }
        api.records["existingFile"] = FakeDriveApi.Record(
            id = "existingFile",
            name = "(양식) 어드벤처디자인_팀활동보고서.hwp",
            mimeType = "application/octet-stream",
            parents = mutableListOf("cMatFolder"),
            content = fileBytes,
            createdTime = "2026-11-01T00:00:04Z",
            appProperties = mutableMapOf("crKind" to "file", "crKey" to "att:report_123", "crHash" to "hash_47616")
        )
        val docContent = "course_doc_content"
        api.records["existingDoc"] = FakeDriveApi.Record(
            id = "existingDoc",
            name = "어드벤처디자인.txt",
            mimeType = "text/plain",
            parents = mutableListOf("courseFolder"),
            content = docContent.toByteArray(Charsets.UTF_8),
            createdTime = "2026-11-01T00:00:05Z",
            appProperties = mutableMapOf("crKind" to "file", "crKey" to "doc:course:어드벤처디자인", "crHash" to DriveApi.digest(docContent))
        )

        val initialCount = api.records.size

        // Fresh reinstall: completely empty state
        val row = JSONObject()

        val payload = JSONObject().apply {
            put("documents", JSONObject().put("과목/어드벤처디자인.txt", docContent))
            put("files", JSONObject().put(
                "자료/어드벤처디자인/(양식) 어드벤처디자인_팀활동보고서.hwp",
                JSONObject().apply {
                    put("sha256", "hash_47616")
                    put("mime", "application/octet-stream")
                    put("bytesBase64", Base64.getEncoder().encodeToString(fileBytes))
                    put("crKey", "att:report_123")
                }
            ))
        }

        val res = DriveSyncEngine.syncAccount(
            api = api,
            row = row,
            payload = payload,
            term = "2026-2"
        )

        assertEquals("Fresh reinstall sync must write 0", 0, res.writes)
        assertEquals("Must not create new files", initialCount, api.records.size)
        assertEquals("existingFile", row.getJSONObject("files").getString("자료/어드벤처디자인/(양식) 어드벤처디자인_팀활동보고서.hwp"))
        assertEquals("existingDoc", row.getJSONObject("files").getString("과목/어드벤처디자인.txt"))
    }

    @Test
    fun testC_2to9Duplicates9Items1RemainsAnd8MovedToTrash() {
        val api = FakeDriveApi()

        api.records["rootFolder"] = FakeDriveApi.Record(
            id = "rootFolder",
            name = "캠퍼스레이더",
            mimeType = "application/vnd.google-apps.folder",
            parents = mutableListOf(),
            content = ByteArray(0),
            createdTime = "2026-11-01T00:00:00Z"
        )
        api.records["matFolder"] = FakeDriveApi.Record(
            id = "matFolder",
            name = "자료",
            mimeType = "application/vnd.google-apps.folder",
            parents = mutableListOf("rootFolder"),
            content = ByteArray(0),
            createdTime = "2026-11-01T00:00:01Z"
        )
        api.records["cMatFolder"] = FakeDriveApi.Record(
            id = "cMatFolder",
            name = "어드벤처디자인",
            mimeType = "application/vnd.google-apps.folder",
            parents = mutableListOf("matFolder"),
            content = ByteArray(0),
            createdTime = "2026-11-01T00:00:02Z"
        )

        val fileBytes = ByteArray(47616) { 0 }
        api.records["report_base"] = FakeDriveApi.Record(
            id = "report_base",
            name = "(양식) 어드벤처디자인_팀활동보고서.hwp",
            mimeType = "application/octet-stream",
            parents = mutableListOf("cMatFolder"),
            content = fileBytes,
            createdTime = "2026-11-01T00:00:03Z"
        )
        for (i in 2..9) {
            api.records["report_dup_$i"] = FakeDriveApi.Record(
                id = "report_dup_$i",
                name = "(양식) 어드벤처디자인_팀활동보고서 ($i).hwp",
                mimeType = "application/octet-stream",
                parents = mutableListOf("cMatFolder"),
                content = fileBytes,
                createdTime = "2026-11-01T00:00:0${i + 3}Z"
            )
        }

        val row = JSONObject().put("folder", "rootFolder")
        val payload = JSONObject().apply {
            put("documents", JSONObject())
            put("files", JSONObject().put(
                "자료/어드벤처디자인/(양식) 어드벤처디자인_팀활동보고서.hwp",
                JSONObject().apply {
                    put("sha256", "hash_47616")
                    put("mime", "application/octet-stream")
                    put("bytesBase64", Base64.getEncoder().encodeToString(fileBytes))
                    put("crKey", "att:report_123")
                }
            ))
        }

        val res = DriveSyncEngine.syncAccount(
            api = api,
            row = row,
            payload = payload,
            term = "2026-2"
        )

        assertTrue(res.complete)
        assertFalse(api.records["report_base"]!!.trashed)
        for (i in 2..9) {
            assertTrue("Duplicate ($i) must be trashed", api.records["report_dup_$i"]!!.trashed)
        }
        assertEquals(8, row.getInt("cleanedFiles"))
    }

    @Test
    fun testD_2Roots1RootRemainsAndDuplicateRootTrashed() {
        val api = FakeDriveApi()

        api.records["root1"] = FakeDriveApi.Record(
            id = "root1",
            name = "캠퍼스레이더",
            mimeType = "application/vnd.google-apps.folder",
            parents = mutableListOf(),
            content = ByteArray(0),
            createdTime = "2026-11-01T00:00:00Z"
        )
        api.records["root2"] = FakeDriveApi.Record(
            id = "root2",
            name = "캠퍼스레이더",
            mimeType = "application/vnd.google-apps.folder",
            parents = mutableListOf(),
            content = ByteArray(0),
            createdTime = "2026-11-05T00:00:00Z"
        )

        val row = JSONObject()
        val payload = JSONObject().apply {
            put("documents", JSONObject())
            put("files", JSONObject())
        }

        val res = DriveSyncEngine.syncAccount(
            api = api,
            row = row,
            payload = payload,
            term = "2026-2"
        )

        assertTrue(res.complete)
        assertFalse(api.records["root1"]!!.trashed)
        assertTrue("Second root folder must be moved to trash", api.records["root2"]!!.trashed)
        assertEquals("root1", row.getString("folder"))
        assertEquals(1, row.getInt("cleanedFolders"))
    }

    @Test
    fun testE_twoConsecutiveSyncsSecondSyncWritesZero() {
        val api = FakeDriveApi()
        val row = JSONObject()

        val doc1 = "data structures"
        val doc2 = "overview content"
        val fileBytes = ByteArray(1024) { 1 }

        val payload = JSONObject().apply {
            put("documents", JSONObject().apply {
                put("과목/자료구조.txt", doc1)
                put("학업 현황.txt", doc2)
            })
            put("files", JSONObject().put(
                "자료/자료구조/실습1.pdf",
                JSONObject().apply {
                    put("sha256", "hash_lab1")
                    put("mime", "application/pdf")
                    put("bytesBase64", Base64.getEncoder().encodeToString(fileBytes))
                }
            ))
        }

        // First sync
        val first = DriveSyncEngine.syncAccount(
            api = api,
            row = row,
            payload = payload,
            term = "2026-2"
        )
        assertEquals(3, first.writes)
        assertTrue(first.complete)

        // Second sync immediately after
        val second = DriveSyncEngine.syncAccount(
            api = api,
            row = row,
            payload = payload,
            term = "2026-2"
        )
        assertEquals("Second sync writes must be 0", 0, second.writes)
        assertTrue(second.complete)
    }
}

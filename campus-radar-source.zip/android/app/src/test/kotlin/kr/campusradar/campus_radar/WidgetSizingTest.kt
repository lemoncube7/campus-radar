package kr.campusradar.campus_radar
import org.junit.Assert.*
import org.junit.Test
class WidgetSizingTest {
 @Test fun tinyWidgetKeepsAtLeastOneReadableRow(){val p=WidgetSizing.tasks(110,90,1.6f);assertEquals(1,p.rows);assertFalse(p.title);assertFalse(p.stamp);assertEquals(8,p.padding)}
 @Test fun threeByThreeDoesNotRequireFourColumns(){val p=WidgetSizing.tasks(210,230);assertTrue(p.rows in 1..4);assertTrue(p.stamp)}
 @Test fun biggerAreaCanShowFourRows(){val p=WidgetSizing.tasks(320,350);assertEquals(4,p.rows);assertTrue(p.title);assertTrue(p.stamp)}
 @Test fun largeFontReducesRowsBeforeClipping(){assertTrue(WidgetSizing.tasks(200,220,1.6f).rows<WidgetSizing.tasks(200,220,1f).rows)}
}

package kr.campusradar.campus_radar

import org.junit.Assert.*
import org.junit.Test

class DriveSyncLogicTest {
    @Test
    fun legacyUpgradeWithoutTermMustNotArchiveCurrentSemester() {
        // Issue 1: Pre-0.6.5 accounts have blank term. Old code: ("" != "2026-2") -> archived with "학기 미확인"!
        val previousTerm = ""
        val currentTerm = "2026-2"
        assertFalse(
            "Legacy upgrade with blank term should not archive current semester",
            DriveSyncLogic.shouldArchiveSemester(previousTerm, currentTerm)
        )
    }

    @Test
    fun semesterTransitionArchivesPreviousTerm() {
        assertTrue(DriveSyncLogic.shouldArchiveSemester("2026-1", "2026-2"))
        assertFalse(DriveSyncLogic.shouldArchiveSemester("2026-2", "2026-2"))
    }

    @Test
    fun existingFolderReuseMustRetainTrackedFiles() {
        // Issue 4: Reusing an existing folder must NOT prune tracked files. Only newly created folders prune.
        assertFalse(
            "Reused existing folder must retain tracked files",
            DriveSyncLogic.shouldPruneTrackedFiles(isNewFolderCreated = false)
        )
        assertTrue(DriveSyncLogic.shouldPruneTrackedFiles(isNewFolderCreated = true))
    }

    @Test
    fun transientDatabaseLockMustNotInvalidateActiveEpoch() {
        // Issue 2: When SQLite is locked by concurrent Flutter write, sync must not abort.
        assertTrue(
            "Transient SQLite lock should not abort active session",
            DriveSyncLogic.isEpochValid(currentEpoch = null, expectedEpoch = "epoch-123", isBusy = true)
        )
        assertTrue(DriveSyncLogic.isEpochValid(currentEpoch = "epoch-123", expectedEpoch = "epoch-123", isBusy = false))
        assertFalse(DriveSyncLogic.isEpochValid(currentEpoch = "epoch-456", expectedEpoch = "epoch-123", isBusy = false))
        assertFalse(DriveSyncLogic.isEpochValid(currentEpoch = null, expectedEpoch = "epoch-123", isBusy = false))
    }

    @Test
    fun safeFolderNameAndFileNameSanitization() {
        assertEquals("어드벤처디자인", DriveSyncLogic.safeCourseFolderName("어드벤처디자인 "))
        assertEquals("어드벤처디자인_1_", DriveSyncLogic.safeCourseFolderName("어드벤처디자인(1)"))
        assertEquals("첨부파일", DriveSyncLogic.safeAttachmentFileName("   "))
        assertEquals("foo_bar.pdf", DriveSyncLogic.safeAttachmentFileName("foo:bar.pdf"))
        assertEquals("(양식) 어드벤처디자인_팀활동보고서.hwp", DriveSyncLogic.safeAttachmentFileName("(양식) 어드벤처디자인_팀활동보고서.hwp"))
    }

    @Test
    fun legacyKeyMigrationMatching() {
        // Matches by exact sha256 hash even if key changed
        assertTrue(
            DriveSyncLogic.isLegacyMatchingKey(
                oldKey = "자료/어드벤처디자인 /(양식) 어드벤처디자인_팀활동보고서.hwp",
                newKey = "자료/어드벤처디자인/(양식) 어드벤처디자인_팀활동보고서.hwp",
                oldHash = "hash123",
                newHash = "hash123"
            )
        )
        // Matches by sanitized course and filename if hash is absent
        assertTrue(
            DriveSyncLogic.isLegacyMatchingKey(
                oldKey = "자료/어드벤처디자인 /보고서:양식.hwp",
                newKey = "자료/어드벤처디자인/보고서_양식.hwp",
                oldHash = "",
                newHash = "hash456"
            )
        )
        // Does not match unrelated files
        assertFalse(
            DriveSyncLogic.isLegacyMatchingKey(
                oldKey = "자료/다른과목/보고서.hwp",
                newKey = "자료/어드벤처디자인/보고서.hwp",
                oldHash = "hash1",
                newHash = "hash2"
            )
        )
    }

    @Test
    fun rootFolderReuseMustRetainTrackedFiles() {
        // When an existing root folder "캠퍼스레이더" is found (isNewFolderCreated = false),
        // tracked files and hashes must not be pruned.
        assertFalse(DriveSyncLogic.shouldPruneTrackedFiles(isNewFolderCreated = false))
        assertTrue(DriveSyncLogic.shouldPruneTrackedFiles(isNewFolderCreated = true))
    }
}

package kr.campusradar.campus_radar

import org.junit.Assert.*
import org.junit.Test

class DriveLegacyCleanupTest {
    @Test fun preservesUniqueAndRealSemesterFilesAndIsIdempotent() {
        val api = FakeDriveApi()
        for ((id, name, parent) in listOf(
            Triple("old", "지난 내보내기 (학기 미확인) - 자료", "root"),
            Triple("oldcourse", "선형대수", "old"),
            Triple("target", "선형대수", "root"),
            Triple("real", "지난 내보내기 (2026-1) - 자료", "root"))) {
            api.createFolder(id, name, parent, null)
        }
        fun file(id: String, name: String, parent: String, size: Int) {
            api.createFile(id, name, "application/pdf", parent, null)
            api.records[id]!!.content = ByteArray(size)
        }
        file("current", "강의.pdf", "target", 100)
        file("dup", "강의 (2).pdf", "oldcourse", 100)
        file("unique", "강의.pdf", "oldcourse", 200)
        file("realfile", "보관.pdf", "real", 30)
        file("zip", "지난 내보내기 (2026-1) - 첨부원본.zip", "root", 50)
        val counts = DriveLegacyCleanup.run(api, "root", "course", { "target" }, {})
        assertEquals(2, counts.folders)
        assertEquals(2, counts.files)
        assertTrue(api.records["dup"]!!.trashed)
        assertTrue(api.records["zip"]!!.trashed)
        assertEquals(listOf("target"), api.records["unique"]!!.parents)
        assertEquals("file", api.records["unique"]!!.appProperties["crKind"])
        assertFalse(api.records["real"]!!.trashed)
        assertEquals(listOf("real"), api.records["realfile"]!!.parents)
        assertEquals(DriveLegacyCleanup.Counts(0, 0),
            DriveLegacyCleanup.run(api, "root", "course", { "target" }, {}))
    }

    @Test fun cancellationPreservesArchive() {
        val api = FakeDriveApi()
        api.createFolder("old", "지난 내보내기 (학기 미확인) - 과목", "root", null)
        try {
            DriveLegacyCleanup.run(api, "root", "course", { "target" }, { error("cancel") })
            fail("must throw")
        } catch (_: IllegalStateException) { }
        assertFalse(api.records["old"]!!.trashed)
    }
}

package kr.campusradar.campus_radar

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class FreeboardDriveFolderTest {
    @Test fun freeboardOriginalsUseNestedFolderAndReuseRemoteCrKey() {
        val api = FakeDriveApi()
        val row = JSONObject().put("cleanup066", true).put("cleanup066c", true)
        val key = "자료/과목/자유게시판/file.pdf"
        val entry = JSONObject().put("bytesBase64", "YWJj").put("sha256", "hash")
            .put("mime", "application/pdf").put("crKey", "att:freeboard:test").put("section", "freeboard")
        val payload = JSONObject().put("documents", JSONObject().put("캠퍼스레이더 시작.txt", "start"))
            .put("files", JSONObject().put(key, entry))
        DriveSyncEngine.syncAccount(api = api, row = row, payload = payload, term = "2026-2")
        val folder = api.records.values.single { it.name == "자유게시판" }
        val file = api.records.values.single { it.appProperties["crKey"] == "att:freeboard:test" }
        assertEquals(listOf(folder.id), file.parents)
        val courseFolder = api.records[folder.parents.single()]!!
        assertEquals("과목", courseFolder.name)
        val count = api.records.size
        DriveSyncEngine.syncAccount(api = api, row = row, payload = payload, term = "2026-2")
        assertEquals(count, api.records.size)
        assertFalse(file.trashed)
    }
}

package kr.campusradar.campus_radar

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

class TimetableWidgetLogicTest {
    private val zone = ZoneId.of("Asia/Seoul")

    @Test
    fun smallWidgetPicksTomorrowClassWhenTodayClassesEnded() {
        // Wednesday (dayOfWeek=3) at 18:00
        val now = ZonedDateTime.of(2026, 11, 11, 18, 0, 0, 0, zone)
        val wedMorningClass = TimetableWidgetLogic.Entry(id = "c1", weekday = 3, start = 540, end = 600, courseKey = "수요아침수업")
        val thuClass = TimetableWidgetLogic.Entry(id = "c2", weekday = 4, start = 600, end = 660, courseKey = "목요수업")
        val entries = listOf(wedMorningClass, thuClass)

        val upcoming = TimetableWidgetLogic.pickUpcoming(entries, now)
        val first = upcoming.first()

        assertEquals("목요수업", first.entry.courseKey)
        assertEquals(LocalDate.of(2026, 11, 12), first.date)
    }

    @Test
    fun smallWidgetPicksTodayMorningClassBeforeStart() {
        // Wednesday (dayOfWeek=3) at 08:00
        val now = ZonedDateTime.of(2026, 11, 11, 8, 0, 0, 0, zone)
        val wedMorningClass = TimetableWidgetLogic.Entry(id = "c1", weekday = 3, start = 540, end = 600, courseKey = "수요아침수업")
        val thuClass = TimetableWidgetLogic.Entry(id = "c2", weekday = 4, start = 600, end = 660, courseKey = "목요수업")
        val entries = listOf(wedMorningClass, thuClass)

        val upcoming = TimetableWidgetLogic.pickUpcoming(entries, now)
        val first = upcoming.first()

        assertEquals("수요아침수업", first.entry.courseKey)
        assertEquals(LocalDate.of(2026, 11, 11), first.date)
    }

    @Test
    fun smallWidgetPicksNextWeekSameDayClassWhenOnlyThatDayExists() {
        // Wednesday (dayOfWeek=3) at 18:00
        val now = ZonedDateTime.of(2026, 11, 11, 18, 0, 0, 0, zone)
        val wedMorningClass = TimetableWidgetLogic.Entry(id = "c1", weekday = 3, start = 540, end = 600, courseKey = "수요아침수업")
        val entries = listOf(wedMorningClass)

        val upcoming = TimetableWidgetLogic.pickUpcoming(entries, now)
        val first = upcoming.first()

        assertEquals("수요아침수업", first.entry.courseKey)
        assertEquals(LocalDate.of(2026, 11, 18), first.date)
    }
}

package kr.campusradar.campus_radar
import org.junit.Test
import org.junit.Assert.*
import java.time.*
class ClassTimeLogicTest {
 private val zone=ZoneId.of("Asia/Seoul")
 @Test fun classLeadAndWeeklyRollover(){
  val now=ZonedDateTime.of(2026,10,19,8,0,0,0,zone)
  assertEquals("2026-10-19T08:30+09:00[Asia/Seoul]",ClassTimeLogic.next(1,540,30,now,LocalDate.of(2026,12,31)).toString())
  assertEquals(LocalDate.of(2026,10,26),ClassTimeLogic.next(1,540,30,now.plusHours(1),LocalDate.of(2026,12,31))!!.toLocalDate())
 }
 @Test fun semesterEndStopsRecurrence(){assertNull(ClassTimeLogic.next(1,540,15,ZonedDateTime.of(2026,12,31,12,0,0,0,zone),LocalDate.of(2026,12,31)))}
 @Test fun midnightMeansBeginningOfNewDay(){val next=ClassTimeLogic.nextMidnight(ZonedDateTime.of(2026,10,18,23,59,0,0,zone));assertEquals(LocalDate.of(2026,10,19),next.toLocalDate());assertEquals(0,next.hour)}
 @Test fun leadMayFallOnPreviousDay(){assertEquals(23,ClassTimeLogic.next(1,15,60,ZonedDateTime.of(2026,10,18,22,0,0,0,zone),LocalDate.of(2026,12,31))!!.hour)}
 @Test fun countdownOnlyAfterActualReminderAndBeforeStart(){
  val now=ZonedDateTime.of(2026,10,19,8,45,0,0,zone);val until=LocalDate.of(2026,12,31)
  assertNotNull(ClassTimeLogic.countdownStart(1,540,30,now,until,"2026-10-19"))
  assertNull(ClassTimeLogic.countdownStart(1,540,30,now.minusMinutes(16),until,"2026-10-19"))
  assertNull(ClassTimeLogic.countdownStart(1,540,30,now.plusMinutes(15),until,"2026-10-19"))
  assertNull(ClassTimeLogic.countdownStart(1,540,30,now,until,"2026-10-12"))
  assertNull(ClassTimeLogic.countdownStart(1,540,30,now,until,""))
 }
 @Test fun countdownHandlesMidnightAndSemesterEnd(){
  val now=ZonedDateTime.of(2026,10,18,23,45,0,0,zone)
  assertNotNull(ClassTimeLogic.countdownStart(1,15,60,now,LocalDate.of(2026,12,31),"2026-10-19"))
  assertNull(ClassTimeLogic.countdownStart(1,15,60,now,LocalDate.of(2026,10,18),"2026-10-19"))
 }
 @Test fun countdownTextKeepsSignedElapsedTime(){
  val now=Instant.parse("2026-10-19T00:00:00Z")
  assertEquals("15분 00초",ClassTimeLogic.countdownText(now.plusSeconds(900),now))
  assertEquals("0분 01초",ClassTimeLogic.countdownText(now.plusMillis(1),now))
  assertEquals("-0분 01초",ClassTimeLogic.countdownText(now.minusSeconds(1),now))
 }

 @Test fun countdownMayRemainForConfiguredMinutes(){
  val now=ZonedDateTime.of(2026,10,19,9,5,0,0,zone);val until=LocalDate.of(2026,12,31)
  assertNotNull(ClassTimeLogic.countdownStart(1,540,30,now,until,"2026-10-19",10))
  assertNull(ClassTimeLogic.countdownStart(1,540,30,now,until,"2026-10-19",0))
  assertNull(ClassTimeLogic.countdownStart(1,540,30,now.plusMinutes(6),until,"2026-10-19",10))
  assertEquals("-5분 00초",ClassTimeLogic.countdownText(now.minusMinutes(5).toInstant(),now.toInstant()))
 }
 @Test fun cancelledClassRollsToNextUncancelledWeek(){
  val now=ZonedDateTime.of(2026,10,19,8,0,0,0,zone)
  assertEquals(LocalDate.of(2026,10,26),ClassTimeLogic.next(1,540,30,now,LocalDate.of(2026,12,31),setOf("2026-10-19"))!!.toLocalDate())
 }
 @Test fun parseUntilHandlesEmptyAndMalformedDatesSafely(){
  assertNull(ClassTimeLogic.parseUntil(""))
  assertNull(ClassTimeLogic.parseUntil(null))
  assertNull(ClassTimeLogic.parseUntil("invalid-date"))
  assertEquals(LocalDate.of(2026,12,31),ClassTimeLogic.parseUntil("2026-12-31"))
 }
}

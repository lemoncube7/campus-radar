package kr.campusradar.campus_radar
import org.junit.Assert.*
import org.junit.Test

class LockWindowPolicyTest {
    private val own = "kr.campusradar.campus_radar"
    @Test fun systemControlsDoNotDismiss() {
        for (name in listOf("VolumeDialogImpl", "android.app.Dialog", "GlobalActionsDialogLite", ""))
            assertFalse(LockWindowPolicy.suppress("com.android.systemui", name, own))
    }
    @Test fun securityAndCameraSuppress() {
        assertTrue(LockWindowPolicy.suppress("com.android.systemui", "KeyguardBouncer", own))
        assertTrue(LockWindowPolicy.suppress("com.android.systemui", "KeyguardPatternView", own))
        assertTrue(LockWindowPolicy.suppress("com.sec.android.app.camera", "Camera", own))
        assertFalse(LockWindowPolicy.suppress(own, "Card", own))
        assertFalse(LockWindowPolicy.suppress(null, null, own))
    }
}

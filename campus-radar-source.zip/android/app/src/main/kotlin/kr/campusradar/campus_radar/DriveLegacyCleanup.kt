package kr.campusradar.campus_radar

/** Exact app archive names only. Failures propagate so the migration is retried. */
object DriveLegacyCleanup {
    data class Counts(val folders: Int, val files: Int)

    fun run(api: DriveApi, root: String, courseRoot: String,
            courseMaterialsFolder: (String) -> String, check: () -> Unit): Counts {
        var folders = 0
        var files = 0
        fun trash(item: DriveItem) {
            check()
            api.trash(item.id)
            if (item.isFolder) folders++ else files++
        }
        fun merge(source: String, target: String, documents: Boolean) {
            val current = api.listChildren(target).toMutableList()
            for (item in api.listChildren(source)) {
                check()
                if (item.isFolder) {
                    // Preserve unexpected nested folders rather than deleting their contents.
                    api.updateMetadata(item.id, addParents = listOf(target), removeParents = listOf(source))
                    continue
                }
                val name = DriveSyncLogic.normalizeAttachmentFileName(item.name)
                val duplicate = current.any { other -> !other.isFolder &&
                    DriveSyncLogic.normalizeAttachmentFileName(other.name) == name &&
                    ((documents && item.name.endsWith(".txt")) || other.size == item.size) }
                if (duplicate) trash(item) else {
                    api.updateMetadata(item.id,
                        appProperties = DriveSyncLogic.buildAppProperties(
                            kind = DriveSyncLogic.KIND_FILE,
                            key = item.crKey.ifBlank { "legacy:${item.id}" }),
                        addParents = listOf(target), removeParents = listOf(source))
                    current.add(item)
                }
            }
            if (api.listChildren(source).isEmpty()) {
                check()
                api.trash(source)
                folders++
            }
        }
        for (archive in api.listChildren(root)) {
            check()
            when {
                !archive.isFolder && Regex("^지난 내보내기 \\([^\\r\\n]+\\) - 첨부원본\\.zip$").matches(archive.name) -> trash(archive)
                // 0.6.6 no longer uploads the ZIP; untracked copies (several 0.6.x roots merged) remain otherwise.
                !archive.isFolder && archive.name == "캠퍼스레이더 첨부원본.zip" -> trash(archive)
                archive.isFolder && archive.name == "지난 내보내기 (학기 미확인) - 과목" -> merge(archive.id, courseRoot, true)
                archive.isFolder && archive.name == "지난 내보내기 (학기 미확인) - 자료" -> {
                    for (child in api.listChildren(archive.id)) {
                        if (child.isFolder) merge(child.id, courseMaterialsFolder(child.name), false)
                    }
                    if (api.listChildren(archive.id).isEmpty()) trash(archive)
                }
            }
        }
        return Counts(folders, files)
    }
}

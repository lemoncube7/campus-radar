package kr.campusradar.campus_radar

import java.security.MessageDigest

object DriveSyncLogic {
  // Drive's 'has' needs both key and value; a key-only query is HTTP 400.
  const val REMOTE_QUERY = "trashed=false and (appProperties has { key='crKind' and value='root' } or appProperties has { key='crKind' and value='term' } or appProperties has { key='crKind' and value='course' } or appProperties has { key='crKind' and value='materials' } or appProperties has { key='crKind' and value='file' })"

    const val CR_VER = "0.6.6"

    const val KIND_ROOT = "root"
    const val KIND_TERM = "term"
    const val KIND_COURSE = "course"
    const val KIND_MATERIALS = "materials"
    const val KIND_FILE = "file"

    fun buildAppProperties(
        kind: String,
        key: String,
        hash: String = "",
        ver: String = CR_VER
    ): Map<String, String> {
        val safeKey = if (key.length > 100) {
            val d = MessageDigest.getInstance("SHA-256").digest(key.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
            "sha256:$d"
        } else {
            key
        }
        return mapOf(
            "crKind" to kind,
            "crKey" to safeKey,
            "crHash" to hash,
            "crVer" to ver
        )
    }

    fun normalizeAttachmentFileName(name: String): String {
        val dot = name.lastIndexOf('.')
        return if (dot > 0) {
            val base = name.substring(0, dot)
            val ext = name.substring(dot)
            val cleanBase = base.replace(Regex(""" \(\d+\)$"""), "")
            "$cleanBase$ext"
        } else {
            name.replace(Regex(""" \(\d+\)$"""), "")
        }
    }

    // Keys over 100 chars are stored hashed (appProperties limit); lookups must use the same form.
    fun storedKey(key: String): String = if (key.length > 100) "sha256:" + MessageDigest.getInstance("SHA-256").digest(key.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) } else key
    fun documentKey(docName: String): String = storedKey(rawDocumentKey(docName))
    fun attachmentKey(course: String, fileName: String, attachmentId: String? = null): String = storedKey(rawAttachmentKey(course, fileName, attachmentId))
    private fun rawDocumentKey(docName: String): String {
        return when {
            docName == "캠퍼스레이더 시작.txt" -> "doc:start"
            docName == "학업 현황.txt" -> "doc:overview"
            docName == "시간표.txt" -> "doc:timetable"
            docName == "첨부 자료 인덱스.txt" -> "doc:index"
            docName == "캠퍼스레이더 첨부원본.zip" -> "doc:zip"
            docName.startsWith("과목/첨부_") -> {
                val id = docName.removePrefix("과목/첨부_").replace(Regex("""\.(txt|md)$"""), "")
                "doc:text:$id"
            }
            docName.startsWith("과목/") -> {
                val course = docName.removePrefix("과목/").replace(Regex("""\.(txt|md)$"""), "")
                "doc:course:${safeCourseFolderName(course)}"
            }
            else -> "doc:$docName"
        }
    }

    private fun rawAttachmentKey(course: String, fileName: String, attachmentId: String? = null): String {
        if (!attachmentId.isNullOrEmpty()) {
            return "att:$attachmentId"
        }
        val safeCourse = safeCourseFolderName(course)
        val safeFile = safeAttachmentFileName(normalizeAttachmentFileName(fileName))
        return "att:$safeCourse/$safeFile"
    }

    /**
     * Determines whether previous semester folders should be archived.
     * Only true when a non-blank previous term differs from the new current term.
     * When upgrading from legacy versions where term was blank, archiving is skipped.
     */
    fun shouldArchiveSemester(previousTerm: String, currentTerm: String): Boolean {
        return previousTerm.isNotBlank() && currentTerm.isNotBlank() && previousTerm != currentTerm
    }

    /**
     * File tracking entries should only be pruned when a brand new folder is created on Drive.
     * When reusing an existing folder, tracking must be retained to avoid redundant re-uploads.
     */
    fun shouldPruneTrackedFiles(isNewFolderCreated: Boolean): Boolean {
        return isNewFolderCreated
    }

    /**
     * Checks if session epoch is valid. A transient SQLite lock (isBusy) must not abort the sync.
     */
    fun isEpochValid(currentEpoch: String?, expectedEpoch: String, isBusy: Boolean): Boolean {
        if (isBusy) return true
        return currentEpoch != null && currentEpoch == expectedEpoch
    }

    fun safeCourseFolderName(name: String): String {
        var safe = name.replace(Regex("""[^가-힣A-Za-z0-9 _-]"""), "_").trim()
        if (safe.isEmpty()) safe = "과목"
        safe = if (safe.length > 50) safe.substring(0, 50) else safe
        return safe
    }

    fun safeAttachmentFileName(name: String): String {
        var safe = name.replace(Regex("""[/\\:*?"<>|\x00-\x1f]"""), "_").trim()
        if (safe.isEmpty()) safe = "첨부파일"
        return safe
    }

    /**
     * Determines whether an old untracked key from 0.6.5 corresponds to a new 0.6.6 key.
     */
    fun isLegacyMatchingKey(
        oldKey: String,
        newKey: String,
        oldHash: String,
        newHash: String
    ): Boolean {
        if (!oldKey.startsWith("자료/") || !newKey.startsWith("자료/")) return false
        if (oldHash.isNotBlank() && newHash.isNotBlank() && oldHash == newHash) return true
        val oldCourse = oldKey.removePrefix("자료/").substringBefore('/')
        val oldFile = oldKey.substringAfterLast('/')
        val newCourse = newKey.removePrefix("자료/").substringBefore('/')
        val newFile = newKey.substringAfterLast('/')
        return safeCourseFolderName(oldCourse) == newCourse &&
            safeAttachmentFileName(normalizeAttachmentFileName(oldFile)) == newFile
    }
}

package kr.campusradar.campus_radar

import java.time.*

object ClassTimeLogic {
 fun next(weekday:Int,minute:Int,lead:Int,now:ZonedDateTime,until:LocalDate,skipped:Set<String> = emptySet()):ZonedDateTime? {
  require(weekday in 1..7 && minute in 0..1439 && lead in listOf(15,30,60))
  for(offset in 0L..370L){val date=now.toLocalDate().plusDays(offset);if(date.isAfter(until))return null
   if(date.dayOfWeek.value==weekday&&!skipped.contains(date.toString())){val alarm=date.atStartOfDay(now.zone).plusMinutes(minute.toLong()).minusMinutes(lead.toLong());if(alarm.isAfter(now))return alarm}
  };return null
 }
 fun nextMidnight(now:ZonedDateTime):ZonedDateTime=now.toLocalDate().plusDays(1).atStartOfDay(now.zone)
 fun countdownStart(weekday:Int,minute:Int,lead:Int,now:ZonedDateTime,until:LocalDate,sentDate:String,afterMinutes:Int=0):ZonedDateTime? {
  if(weekday !in 1..7 || minute !in 0..1439 || lead !in listOf(15,30,60))return null
  for(offset in -1L..1L){
   val date=now.toLocalDate().plusDays(offset)
   if(date.isAfter(until)||date.dayOfWeek.value!=weekday||date.toString()!=sentDate)continue
   val start=date.atStartOfDay(now.zone).plusMinutes(minute.toLong())
   if(!now.isAfter(start.plusMinutes(afterMinutes.coerceIn(0,120).toLong())) && (start.isAfter(now)||afterMinutes>0) && !now.isBefore(start.minusMinutes(lead.toLong())))return start
  }
  return null
 }
 fun countdownText(start:Instant,now:Instant):String {
  val millis=Duration.between(now,start).toMillis()
  val seconds=(kotlin.math.abs(millis)+999)/1000
  return "${if(millis<0) "-" else ""}${seconds/60}분 %02d초".format(seconds%60)
 }
 fun parseUntil(raw:String?):LocalDate? = try {
  if(raw.isNullOrBlank()) null else LocalDate.parse(raw)
 }catch(_:Exception){
  null
 }
}

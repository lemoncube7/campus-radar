package kr.campusradar.campus_radar

/** Window metadata only. System UI controls do not dismiss the user's card. */
object LockWindowPolicy {
    fun suppress(packageName: String?, className: String?, ownPackage: String): Boolean {
        if (packageName.isNullOrEmpty() || packageName == ownPackage) return false
        val name = className.orEmpty().lowercase()
        if (packageName == "com.android.systemui") {
            // SystemUI also owns authentication. Hide only positively identified
            // keyguard/bouncer screens; a generic dialog may be the volume panel.
            return listOf("bouncer", "keyguardpassword", "keyguardpin", "keyguardpattern",
                "credential", "biometric").any { name.contains(it) }
        }
        return true // camera or another app above the still-locked device
    }
}

package kr.campusradar.campus_radar

import org.json.JSONObject
import java.time.LocalDate
import java.time.ZonedDateTime

object TimetableWidgetLogic {
    data class Entry(
        val id: String,
        val weekday: Int,
        val start: Int,
        val end: Int,
        val room: String = "",
        val courseKey: String = ""
    ) {
        companion object {
            fun from(json: JSONObject) = Entry(
                id = json.optString("id"),
                weekday = json.optInt("weekday"),
                start = json.optInt("start"),
                end = json.optInt("end"),
                room = json.optString("room"),
                courseKey = json.optString("courseKey")
            )
        }
    }

    data class UpcomingItem(val entry: Entry, val date: LocalDate)
    data class UpcomingJsonItem(val row: JSONObject, val date: LocalDate)

    /** Small timetable widget upcoming class selection. */
    fun pickUpcoming(entries: List<Entry>, now: ZonedDateTime): List<UpcomingItem> {
        val today = now.dayOfWeek.value
        val minute = now.hour * 60 + now.minute
        val todayRows = entries.filter { it.weekday == today && it.end > minute }
            .sortedBy { it.start }
        if (todayRows.isNotEmpty()) {
            val todayDate = now.toLocalDate()
            return todayRows.map { UpcomingItem(it, todayDate) }
        }
        val sorted = entries.sortedWith(
            compareBy<Entry> {
                val diff = (it.weekday - today + 7) % 7
                if (diff == 0) 7 else diff
            }.thenBy { it.start }
        )
        return sorted.map { row ->
            val diff = (row.weekday - today + 7) % 7
            val daysAhead = if (diff == 0) 7 else diff
            val rowDate = now.toLocalDate().plusDays(daysAhead.toLong())
            UpcomingItem(row, rowDate)
        }
    }

    fun pickUpcomingJson(entries: List<JSONObject>, now: ZonedDateTime): List<UpcomingJsonItem> {
        val paired = entries.map { Pair(it, Entry.from(it)) }
        val upcomingEntries = pickUpcoming(paired.map { it.second }, now)
        return upcomingEntries.map { up ->
            val orig = paired.first { it.second == up.entry }.first
            UpcomingJsonItem(orig, up.date)
        }
    }
}

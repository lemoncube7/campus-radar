package kr.campusradar.campus_radar

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest

class DriveHttpFailure(val status:Int):Exception("Drive HTTP $status")
internal fun driveResourceExists(lookup:()->Boolean):Boolean=try{lookup()}catch(e:DriveHttpFailure){if(e.status==404)false else throw e}
data class DriveItem(
    val id: String,
    val name: String,
    val createdTime: String = "",
    val mimeType: String,
    val size: Long = 0L,
    val parents: List<String> = emptyList(),
    val appProperties: Map<String, String> = emptyMap()
) {
    val isFolder: Boolean get() = mimeType == "application/vnd.google-apps.folder"
    val crKind: String get() = appProperties["crKind"] ?: ""
    val crKey: String get() = appProperties["crKey"] ?: ""
    val crHash: String get() = appProperties["crHash"] ?: ""
    val crVer: String get() = appProperties["crVer"] ?: ""
}
/** Fixed HTTPS Google endpoints, bounded responses, no logged tokens/content. */
open class DriveApi(private val token:String,private val unauthorized:()->Unit={}){
 companion object{
  const val scope="https://www.googleapis.com/auth/drive.file"
  fun digest(value:String)=MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8)).joinToString(""){"%02x".format(it)}
 }
 open fun json(method:String,url:String,body:JSONObject?=null)=JSONObject(request(method,url,body?.toString()?.toByteArray(Charsets.UTF_8),"application/json; charset=UTF-8").ifBlank{"{}"})
 private fun request(method:String,url:String,body:ByteArray?,mime:String):String{
  require(url.startsWith("https://www.googleapis.com/drive/v3/")||url.startsWith("https://www.googleapis.com/upload/drive/v3/"))
  val c=URL(url).openConnection()as HttpURLConnection
  try{
   c.instanceFollowRedirects=false;c.connectTimeout=15000;c.readTimeout=60000;c.requestMethod=method;c.setRequestProperty("Authorization","Bearer $token")
   if(body!=null){c.doOutput=true;c.setRequestProperty("Content-Type",mime);c.setFixedLengthStreamingMode(body.size);c.outputStream.use{it.write(body)}}
   val status=c.responseCode
   if(status==401)unauthorized()
   if(status !in 200..299)throw DriveHttpFailure(status)
   return c.inputStream.use{input->val out=java.io.ByteArrayOutputStream();val buf=ByteArray(8192);while(true){val n=input.read(buf);if(n<0)break;require(out.size()+n<=1048576);out.write(buf,0,n)};out.toString("UTF-8")}
  }finally{c.disconnect()}
 }
 open fun id():String=json("GET","https://www.googleapis.com/drive/v3/files/generateIds?count=1&space=drive&type=files").getJSONArray("ids").getString(0)
 open fun createFolder(id:String,name:String,parent:String?=null,appProperties:Map<String,String>?=null){
  val m=JSONObject().put("id",id).put("name",name).put("mimeType","application/vnd.google-apps.folder")
  if(parent!=null)m.put("parents",org.json.JSONArray().put(parent))
  if(!appProperties.isNullOrEmpty())m.put("appProperties",JSONObject(appProperties))
  create(id,m)
 }
 open fun createText(id:String,name:String,parent:String,appProperties:Map<String,String>?=null){
  val m=JSONObject().put("id",id).put("name",name).put("mimeType","text/plain").put("parents",org.json.JSONArray().put(parent))
  // Created without a content hash; the engine sets it after the content write succeeds.
  if(!appProperties.isNullOrEmpty())m.put("appProperties",JSONObject(appProperties+("crHash" to "")))
  create(id,m)
 }
 open fun createFile(id:String,name:String,mime:String,parent:String,appProperties:Map<String,String>?=null){
  val m=JSONObject().put("id",id).put("name",name).put("mimeType",mime).put("parents",org.json.JSONArray().put(parent))
  // Created without a content hash; the engine sets it after the content write succeeds.
  if(!appProperties.isNullOrEmpty())m.put("appProperties",JSONObject(appProperties+("crHash" to "")))
  create(id,m)
 }
 open fun write(id:String,text:String){request("PATCH","https://www.googleapis.com/upload/drive/v3/files/$id?uploadType=media",text.toByteArray(Charsets.UTF_8),"text/plain; charset=UTF-8")}
 open fun writeBytes(id:String,bytes:ByteArray,mime:String){request("PATCH","https://www.googleapis.com/upload/drive/v3/files/$id?uploadType=media",bytes,mime)}
 open fun trash(id:String){json("PATCH","https://www.googleapis.com/drive/v3/files/$id",JSONObject().put("trashed",true))}
 open fun updateMetadata(id:String,name:String?=null,appProperties:Map<String,String>?=null,addParents:List<String>?=null,removeParents:List<String>?=null){
  var url="https://www.googleapis.com/drive/v3/files/$id"
  val qp=mutableListOf<String>()
  if(!addParents.isNullOrEmpty())qp.add("addParents="+URLEncoder.encode(addParents.joinToString(","),"UTF-8"))
  if(!removeParents.isNullOrEmpty())qp.add("removeParents="+URLEncoder.encode(removeParents.joinToString(","),"UTF-8"))
  if(qp.isNotEmpty())url+="?"+qp.joinToString("&")
  val body=JSONObject()
  if(name!=null)body.put("name",name)
  if(!appProperties.isNullOrEmpty())body.put("appProperties",JSONObject(appProperties))
  json("PATCH",url,body)
 }
 open fun listByQuery(query:String):List<DriveItem>{
  val items=mutableListOf<DriveItem>()
  val encodedFields=URLEncoder.encode("files(id,name,createdTime,mimeType,size,parents,appProperties),nextPageToken","UTF-8")
  val encodedQ=URLEncoder.encode(query,"UTF-8").replace("+","%20")
  var pageToken:String?=null
  do{
   var url="https://www.googleapis.com/drive/v3/files?pageSize=200&fields=$encodedFields&q=$encodedQ"
   if(pageToken!=null){
    url+="&pageToken="+URLEncoder.encode(pageToken,"UTF-8")
   }
   val res=json("GET",url)
   val files=res.optJSONArray("files")
   if(files!=null){
    for(i in 0 until files.length()){
     val f=files.getJSONObject(i)
     val pList=mutableListOf<String>()
     val pArr=f.optJSONArray("parents")
     if(pArr!=null){
      for(j in 0 until pArr.length())pList.add(pArr.getString(j))
     }
     val props=mutableMapOf<String,String>()
     val pObj=f.optJSONObject("appProperties")
     if(pObj!=null){
      for(k in pObj.keys())props[k]=pObj.optString(k,"")
     }
     items.add(DriveItem(
      id=f.getString("id"),
      name=f.optString("name",""),
      createdTime=f.optString("createdTime",""),
      mimeType=f.optString("mimeType",""),
      size=f.optString("size","0").toLongOrNull()?:0L,
      parents=pList,
      appProperties=props
     ))
    }
   }
   pageToken=res.optString("nextPageToken").ifBlank{null}
  }while(pageToken!=null)
  return items
 }
 open fun listChildren(parent:String,name:String?=null,folderOnly:Boolean=false):List<DriveItem>{
  val q=StringBuilder("'$parent' in parents and trashed=false")
  if(name!=null){
   val escaped=name.replace("\\","\\\\").replace("'","\\'")
   q.append(" and name='$escaped'")
  }
  if(folderOnly){
   q.append(" and mimeType='application/vnd.google-apps.folder'")
  }
  return listByQuery(q.toString())
 }
 open fun rename(id: String, name: String) {
  json("PATCH", "https://www.googleapis.com/drive/v3/files/$id", JSONObject().put("name", name))
 }

 private fun create(id:String,metadata:JSONObject){
  try{json("POST","https://www.googleapis.com/drive/v3/files?fields=id",metadata)}
  catch(e:DriveHttpFailure){if(e.status!=409||!exists(id))throw e}
 }
 open fun exists(id:String)=driveResourceExists{
  !json("GET","https://www.googleapis.com/drive/v3/files/$id?fields=id,trashed").getBoolean("trashed")
 }
}

package kr.campusradar.campus_radar

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.os.Bundle
import android.database.sqlite.SQLiteDatabase
import android.widget.RemoteViews
import org.json.JSONArray
import org.json.JSONObject
import java.time.*

/** Standard AppWidget for compatible keyguard hosts/LockStar. Never draws an overlay. */
class CompactStudyWidget: AppWidgetProvider() {
 override fun onUpdate(c:Context,m:AppWidgetManager,ids:IntArray){WidgetWork.run{ids.forEach{update(c,m,it)}}}
 override fun onAppWidgetOptionsChanged(c:Context,m:AppWidgetManager,id:Int,options:Bundle){WidgetWork.run{update(c,m,id)}}
 companion object {
  fun updateAll(c:Context){WidgetWork.run{val m=AppWidgetManager.getInstance(c);m.getAppWidgetIds(ComponentName(c,CompactStudyWidget::class.java)).forEach{update(c,m,it)}}}
  fun next(c:Context):Pair<JSONObject,ZonedDateTime>? {
   val rows=RadarData.timetableEntries(c)
   val now=ZonedDateTime.now(RadarData.schoolZone);val cancellations=TimetableCancellations.read(c)
   val found=mutableListOf<Pair<JSONObject,ZonedDateTime>>()
   for(day in 0L..7L){val date=now.toLocalDate().plusDays(day)
    for(row in rows){val start=row.optInt("start",-1);val end=row.optInt("end",-1)
     if(row.optString("courseKey").startsWith("personal:")||row.optInt("weekday")!=date.dayOfWeek.value||start !in 0..1439||end<=start||end>1440)continue
     /* cancellations kept */
     val at=date.atTime(start/60,start%60).atZone(RadarData.schoolZone)
     if(at.isAfter(now))found.add(Pair(row,at))
    }
   }
   return found.minByOrNull{it.second}
  }
  private fun update(c:Context,m:AppWidgetManager,id:Int){
   val v=RemoteViews(c.packageName,R.layout.compact_study_widget)
   val accent=NativeAccentPalette.read(c)
   val foreground=android.graphics.Color.WHITE;val muted=android.graphics.Color.rgb(185,203,205)
   for(viewId in listOf(R.id.compact_heading,R.id.compact_day,R.id.compact_deadline))v.setTextColor(viewId,muted)
   v.setTextColor(R.id.compact_summary,NativeAccentPalette.onDark(accent.secondary));v.setTextColor(R.id.compact_course,foreground);v.setTextColor(R.id.compact_tasks,foreground)
   val options=m.getAppWidgetOptions(id)
   val width=options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,180)
   val height=options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT,160)
   val pad=(CompactCardLayout.padding(width)*c.resources.displayMetrics.density).toInt()
   val horizontal=pad+(10*c.resources.displayMetrics.density).toInt()
   v.setViewPadding(R.id.compact_root,0,0,0,0);v.setViewPadding(R.id.compact_content,horizontal,pad,horizontal,pad)
   v.setViewVisibility(R.id.compact_heading,if(CompactCardLayout.showHeading(height))android.view.View.VISIBLE else android.view.View.GONE)
   v.setViewVisibility(R.id.compact_deadline,if(CompactCardLayout.showDeadline(height))android.view.View.VISIBLE else android.view.View.GONE)
   if(height<150)v.setViewPadding(R.id.compact_class,0,0,0,0)
   val scale=WidgetText.scale(c,"lock").coerceIn(.8f,1.3f)
   val details=c.getSharedPreferences("radar_compact_widget",0).getBoolean("details",true)
   v.setTextViewTextSize(R.id.compact_summary,android.util.TypedValue.COMPLEX_UNIT_SP,CompactCardLayout.clockSize(width,height,details)*scale)
   v.setTextViewTextSize(R.id.compact_course,android.util.TypedValue.COMPLEX_UNIT_SP,15f*scale)
   v.setViewVisibility(R.id.compact_tasks,android.view.View.GONE)
   v.setOnClickPendingIntent(R.id.compact_root,RadarData.launch(c,"_tasks",8600))
   v.setOnClickPendingIntent(R.id.compact_class,RadarData.launch(c,"_timetable",8601))
   try {
    val snapshot=RadarData.read(c);val now=Instant.now();val pending=RadarData.pending(snapshot)
    val urgent=pending.count{RadarData.instant(it.optString("due"))?.let{due->due.isAfter(now)&&!due.isAfter(now.plusSeconds(86400))}?:false}
    val active=if(snapshot.connected)TimetableReceiver.activeCountdown(c)else null
    val next=if(snapshot.connected&&active==null)next(c)else null
    // The larger size suits a clock or countdown only; words like "미완료 4개" keep the normal size.
    if(active==null&&next==null)v.setTextViewTextSize(R.id.compact_summary,android.util.TypedValue.COMPLEX_UNIT_SP,CompactCardLayout.clockSize(width,height)*scale)
    v.setChronometerCountDown(R.id.compact_summary,true)
    v.setChronometer(R.id.compact_summary,android.os.SystemClock.elapsedRealtime()+(active?.start?.toEpochMilli()?.minus(System.currentTimeMillis())?:0),null,active!=null)
    if(active!=null){
     val after=c.getSharedPreferences("radar_timetable",0).getInt("countdownAfter",0).coerceIn(0,120)
     val intent=android.content.Intent(c,TimetableReceiver::class.java).setAction("kr.campusradar.WIDGET_COUNTDOWN_END")
     val pi=android.app.PendingIntent.getBroadcast(c,8699,intent,android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
     val at=active.start.plusSeconds(after*60L+1).toEpochMilli()
     c.getSystemService(android.app.AlarmManager::class.java).setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,at,pi)
    }

    val today=ZonedDateTime.now(RadarData.schoolZone).toLocalDate()
    val date=next?.second?.toLocalDate()
    val day=when(date){null->"";today->"오늘";today.plusDays(1)->"내일";else->"${date.monthValue}/${date.dayOfMonth}"}
    val room=active?.room?:next?.first?.optString("room").orEmpty()
    val nextCancelled=next?.let{p->TimetableCancellations.cancelled(c,p.first,p.second.toLocalDate())}?:false
    val course=active?.course?:next?.first?.let{RadarData.courseName(c,it)+(if(nextCancelled)" (휴강으로 인식됨)" else "")}.orEmpty()
    v.setTextViewText(R.id.compact_heading,if(active!=null){if(active.start.isAfter(now))"수업 시작까지" else "수업 시작 후"}else if(next!=null)"다음 수업 · $day"else "마감 요약")
    v.setTextViewText(R.id.compact_summary,if(active!=null)ClassTimeLogic.countdownText(active.start,now)else next?.second?.let{"%02d:%02d".format(it.hour,it.minute)}?:if(snapshot.connected)"미완료 ${pending.size}개"else "포털 연결")
    // A running Chronometer is read aloud as "0초"; describe it instead.
    v.setContentDescription(R.id.compact_summary,if(active!=null)"${if(active.start.isAfter(now))"수업 시작까지" else "수업 시작 후"} ${ClassTimeLogic.countdownText(active.start,now)}" else next?.second?.let{"다음 수업 ${day} %d시 %d분".format(it.hour,it.minute)}?:if(snapshot.connected)"미완료 ${pending.size}개" else "포털 연결")
    val separateRoom=CompactCardLayout.showRoom(height)
    val classLabel=if(separateRoom)course else listOf(course,room).filter{it.isNotBlank()}.joinToString(" · ")
    v.setTextViewText(R.id.compact_course,classLabel)
    v.setViewVisibility(R.id.compact_course,if(details&&classLabel.isNotBlank()&&CompactCardLayout.showCourse(height))android.view.View.VISIBLE else android.view.View.GONE)
    val roomLabel=if(details&&separateRoom)room else ""
    val timeLabel=active?.let{"${it.start.atZone(RadarData.schoolZone).toLocalTime()} 시작"}.orEmpty()
    val dayLabel=listOf(timeLabel,roomLabel).filter{it.isNotBlank()}.joinToString(" · ")
    v.setTextViewText(R.id.compact_day,dayLabel)
    v.setViewVisibility(R.id.compact_day,if(separateRoom&&dayLabel.isNotBlank())android.view.View.VISIBLE else android.view.View.GONE)
    if(details&&classLabel.isNotBlank()&&height<140)v.setViewVisibility(R.id.compact_deadline,android.view.View.GONE)
    v.setTextViewText(R.id.compact_deadline,if(!snapshot.connected)"앱에서 연결해 주세요"else (if(urgent==0)"급한 마감 없음"else "24시간 내 마감 ${urgent}개")+" · 미완료 ${pending.size}개")
    if(details&&CompactCardLayout.showTasks(height)&&pending.isNotEmpty()){
     v.setViewVisibility(R.id.compact_tasks,android.view.View.VISIBLE)
     v.setTextViewText(R.id.compact_tasks,pending.take(2).joinToString("\n"){"${RadarData.courseName(c,it)} · ${it.optString("title")}\n${RadarData.remaining(it)}"})
    }
   }catch(e:Exception){v.setTextViewText(R.id.compact_summary,"다시 확인");v.setTextViewText(R.id.compact_deadline,"앱에서 저장 상태를 확인해 주세요");RadarData.logOnce(c,"compact-widget","LockStar 카드 표시 실패","카드에 '다시 확인'을 표시했어요.",e)}

   m.updateAppWidget(id,v)
  }
 }
}

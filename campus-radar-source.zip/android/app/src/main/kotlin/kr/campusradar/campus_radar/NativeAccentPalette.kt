package kr.campusradar.campus_radar
import android.content.Context
object NativeAccentPalette {
 private val seeds=mapOf("teal" to 0xff197e7b.toInt(),"blue" to 0xff2864bd.toInt(),"indigo" to 0xff4c50ad.toInt(),"purple" to 0xff8852b3.toInt(),"rose" to 0xffb34670.toInt(),"orange" to 0xffa95a1c.toInt(),"green" to 0xff3d7950.toInt(),"slate" to 0xff546678.toInt())
 data class Pairing(val primary:Int,val secondary:Int)
 fun pairing(primary:String?,secondary:String?):Pairing {
  val first=if(primary!=null&&seeds.containsKey(primary))primary else "teal"
  val companion=when(first){"teal","blue"->"orange";"indigo"->"rose";"purple","slate"->"teal";"rose","orange"->"blue";else->"purple"}
  return Pairing(seeds[first]!!,secondary?.let{seeds[it]}?:seeds[companion]!!)
 }
 fun onDark(color:Int):Int {
  fun channel(shift:Int)=((((color ushr shift) and 255)*.4+255*.6).toInt()).coerceIn(0,255)
  return (255 shl 24) or (channel(16) shl 16) or (channel(8) shl 8) or channel(0)
 }
 fun read(context:Context):Pairing {
  val p=context.getSharedPreferences("FlutterSharedPreferences",0)
  return pairing(p.getString("flutter.radarAccent",null),p.getString("flutter.radarSecondaryAccent",null))
 }
}

package kr.campusradar.campus_radar

import android.app.Application
import android.content.Context
import dev.fluttercommunity.workmanager.TaskDebugInfo
import dev.fluttercommunity.workmanager.TaskResult
import dev.fluttercommunity.workmanager.WorkmanagerDebug
import dev.fluttercommunity.workmanager.pigeon.TaskStatus
import org.json.JSONArray
import org.json.JSONObject

class CampusApplication : Application() {
 override fun onCreate() {
  super.onCreate()
  WorkmanagerDebug.setCurrent(object : WorkmanagerDebug() {
   override fun onTaskStatusUpdate(context: Context, taskInfo: TaskDebugInfo, status: TaskStatus, result: TaskResult?) {
    record(context, status.name, result?.duration)
    if(status == TaskStatus.COMPLETED) RadarWidget.updateAll(context)
   }
   override fun onExceptionEncountered(context: Context, taskInfo: TaskDebugInfo?, exception: Throwable) {
    record(context, "NATIVE_ERROR:" + exception.javaClass.simpleName, null)
   }
  })
 }
 companion object {
  @Synchronized private fun record(context: Context, state: String, duration: Long?) {
   val prefs = context.getSharedPreferences("campus_background", Context.MODE_PRIVATE)
   val events = JSONArray(prefs.getString("events", "[]"))
   events.put(JSONObject().put("at", System.currentTimeMillis()).put("state", state).put("durationMs", duration))
   while (events.length() > 100) events.remove(0)
   prefs.edit().putString("events", events.toString()).apply()
  }
 }
}

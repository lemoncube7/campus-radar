package kr.campusradar.campus_radar

import android.app.*
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.*
import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.os.Build
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject
import java.time.*
import java.time.format.DateTimeFormatter

/** Reads the same local database as Flutter; no credentials or network access. */
object RadarData {
 val schoolZone: ZoneId = ZoneId.of("Asia/Seoul")
 fun instant(value: String?): Instant? = try { if(value.isNullOrEmpty() || value == "null") null else OffsetDateTime.parse(value).toInstant() } catch(_:Exception) { null }
 fun available(item:JSONObject, now:Instant) = item.optBoolean("published",true) && (instant(item.optString("startsAt"))?.let{!it.isAfter(now)} ?: true)
 data class Snapshot(val items:List<JSONObject>, val last:String, val discovered:Map<String,String>, val connected:Boolean)
 fun read(context:Context):Snapshot {
  val path=context.getDatabasePath("campus.db")
  if(!path.exists())return Snapshot(emptyList(),"",emptyMap(),false)
  SQLiteDatabase.openDatabase(path.path,null,SQLiteDatabase.OPEN_READWRITE or SQLiteDatabase.ENABLE_WRITE_AHEAD_LOGGING).use {db->
   db.rawQuery("PRAGMA busy_timeout=5000",null).use{it.moveToFirst()}
   db.beginTransactionNonExclusive()
   try {
    val meta=mutableMapOf<String,String>()
    db.rawQuery("SELECT id,value FROM meta",null).use {c->while(c.moveToNext())meta[c.getString(0)]=c.getString(1)}
    val items=mutableListOf<JSONObject>(); val now=Instant.now()
    db.rawQuery("SELECT payload FROM items",null).use{c->while(c.moveToNext()){
     val item=JSONObject(c.getString(0)); if(meta["excluded:"+item.optString("key")]!="yes" && !autoHidden(item,meta,now) && available(item,now))items.add(item)
    }}
    db.setTransactionSuccessful()
    return Snapshot(items,meta["lastSuccess"]?:"",meta.filterKeys{it.startsWith("discovered:")},meta["initialized"]=="yes")
   } finally {db.endTransaction()}
  }
 }
 fun courseName(context:Context,item:JSONObject):String {
  val original=item.optString("course")
  return try{val raw=context.getSharedPreferences("FlutterSharedPreferences",0).getString("flutter.courseAliases","{}");JSONObject(raw?:"{}").let{a->val normalized=original.replace(Regex("\\s+"),"");val key=a.keys().asSequence().firstOrNull{it.replace(Regex("\\s+"),"")==normalized};a.optString(key?:original,original)}}catch(_:Exception){original}
 }
 fun autoHidden(item:JSONObject,meta:Map<String,String>,now:Instant):Boolean{
  val mode=meta["overduePolicy"]?:"confirm";if(mode!="immediate"&&mode!="day")return false
  if(item.optString("status")=="done")return false
  val due=instant(item.optString("due"))?:return false
  if(meta["overdueRestored:"+item.optString("key")]==item.optString("due"))return false
  return !now.isBefore(due.plusSeconds(if(mode=="day")86400 else 0))
 }
 fun pending(s:Snapshot)=s.items.filter{it.optString("status")=="pending"}.sortedBy{instant(it.optString("due"))?:Instant.MAX}
 fun summary(s:Snapshot):String {
  val now=Instant.now();val today=now.atZone(schoolZone).toLocalDate();val p=pending(s)
  val todayCount=p.count{instant(it.optString("due"))?.let{d->d.isAfter(now) && d.atZone(schoolZone).toLocalDate()==today}?:false}
  val within=p.count{instant(it.optString("due"))?.let{d->d.isAfter(now)&&!d.isAfter(now.plusSeconds(86400))}?:false}
  val fresh=s.items.count{it.optString("type")=="LR" && instant(s.discovered["discovered:"+it.optString("key")])?.atZone(schoolZone)?.toLocalDate()==today}
  return "오늘 마감 ${todayCount}개 · 24시간 이내 ${within}개\n미완료 ${p.size}개 · 오늘 새 과제 ${fresh}개"
 }
 fun stamp(s:Snapshot)=instant(s.last)?.atZone(schoolZone)?.format(DateTimeFormatter.ofPattern("M/d HH:mm"))?:"아직 수집 전"
 fun remaining(item:JSONObject):String {
  val due=instant(item.optString("due"))?:return "마감 미확인"
  val minutes=Duration.between(Instant.now(),due).toMinutes()
  return when {minutes<=0->"기한 지남";minutes>=1440->"${minutes/1440}일 ${(minutes%1440)/60}시간 남음";minutes>=60->"${minutes/60}시간 ${minutes%60}분 남음";else->"${minutes}분 남음"}
 }
 fun launch(context:Context,target:String,request:Int):PendingIntent = PendingIntent.getActivity(context,request,Intent(context,MainActivity::class.java).putExtra("radarTarget",target).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
 fun log(context:Context,title:String,detail:String,kind:String="notification") {
  try {SQLiteDatabase.openDatabase(context.getDatabasePath("campus.db").path,null,SQLiteDatabase.OPEN_READWRITE or SQLiteDatabase.ENABLE_WRITE_AHEAD_LOGGING).use { db->
   db.execSQL("INSERT INTO logs(at,kind,title,detail) VALUES(?,?,?,?)",arrayOf(Instant.now().toString(),kind,title,detail))
   db.execSQL("DELETE FROM logs WHERE id NOT IN (SELECT id FROM logs ORDER BY id DESC LIMIT 2000)")
  }}catch(_:Exception){}
 }
}

class RadarWidget:AppWidgetProvider() {
 override fun onAppWidgetOptionsChanged(context:Context,manager:AppWidgetManager,id:Int,options:android.os.Bundle){update(context,manager,id)}
 override fun onUpdate(context:Context,manager:AppWidgetManager,ids:IntArray){ids.forEach{update(context,manager,it)}}
 companion object {
  fun updateAll(context:Context){val m=AppWidgetManager.getInstance(context);m.getAppWidgetIds(ComponentName(context,RadarWidget::class.java)).forEach{update(context,m,it)}}
  private fun update(context:Context,manager:AppWidgetManager,id:Int){
   val views=RemoteViews(context.packageName,R.layout.radar_widget)
   val accent=NativeAccentPalette.read(context)
   views.setTextColor(R.id.radar_title,accent.primary)
   views.setTextColor(R.id.radar_count,accent.secondary)
   val options=manager.getAppWidgetOptions(id)
   val width=options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,250)
   val height=options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT,250)
   val sizing=WidgetSizing.tasks(width,height,WidgetText.scale(context,"tasks"))
   val scale=WidgetText.scale(context,"tasks")*sizing.factor
   val dp=context.resources.displayMetrics.density
   val pad=(sizing.padding*dp).toInt()
   views.setViewPadding(R.id.radar_root,pad,pad,pad,pad)
   views.setViewVisibility(R.id.radar_title,if(sizing.title)android.view.View.VISIBLE else android.view.View.GONE)
   views.setViewVisibility(R.id.radar_stamp,if(sizing.stamp)android.view.View.VISIBLE else android.view.View.GONE)
   for((view,size) in listOf(R.id.radar_title to 18f,R.id.radar_count to 14f,R.id.radar_stamp to 10f,R.id.radar_row1 to 13f,R.id.radar_row2 to 13f,R.id.radar_row3 to 13f,R.id.radar_row4 to 13f))views.setTextViewTextSize(view,android.util.TypedValue.COMPLEX_UNIT_SP,size*scale)
   try {
    val s=RadarData.read(context);val pending=RadarData.pending(s)
    views.setTextViewText(R.id.radar_count,if(s.connected)"미완료 ${pending.size}개" else "앱에서 포털을 연결하세요")
    views.setTextViewText(R.id.radar_stamp,"마지막 확인 ${RadarData.stamp(s)} · 한국 시간")
    views.setOnClickPendingIntent(R.id.radar_root,RadarData.launch(context,"_tasks",500))
    val rows=intArrayOf(R.id.radar_row1,R.id.radar_row2,R.id.radar_row3,R.id.radar_row4)
    val count=sizing.rows
    rows.forEachIndexed{index,row->
     views.setViewVisibility(row,if(index<count)android.view.View.VISIBLE else android.view.View.GONE)
     val item=pending.getOrNull(index)
     views.setTextViewText(row,if(item==null){if(index==0)"현재 표시할 과제·콘텐츠가 없어요" else ""}else "${item.optString("title")}\n${RadarData.courseName(context,item)} · ${RadarData.remaining(item)}")
     if(item!=null){
      val due=RadarData.instant(item.optString("due"));val now=Instant.now()
      views.setTextColor(row,when{due==null->Color.DKGRAY;!due.isAfter(now)->Color.rgb(180,35,35);!due.isAfter(now.plusSeconds(86400))->Color.rgb(165,85,0);else->Color.rgb(35,70,165)})
      views.setOnClickPendingIntent(row,RadarData.launch(context,item.optString("key"),501+index))
     }else views.setOnClickPendingIntent(row,RadarData.launch(context,"_tasks",500))
    }
   }catch(_:Exception){views.setTextViewText(R.id.radar_count,"목록을 불러오지 못했어요");views.setTextViewText(R.id.radar_stamp,"앱에서 다시 확인해 주세요")}
   manager.updateAppWidget(id,views)
  }
 }
}

class DailySummaryReceiver:BroadcastReceiver(){
 override fun onReceive(context:Context,intent:Intent){
  if(intent.action=="kr.campusradar.DAILY"){
   try {send(context)}catch(_:Exception){RadarData.log(context,"데일리 요약 실패","기기 내 목록을 읽지 못했습니다.")}
  }
  schedule(context);RadarWidget.updateAll(context)
 }
 companion object {
  fun settings(context:Context):Map<String,Any>{val p=context.getSharedPreferences("radar_daily",0);return mapOf("enabled" to p.getBoolean("enabled",false),"hour" to p.getInt("hour",18),"minute" to p.getInt("minute",0))}
  fun configure(context:Context,enabled:Boolean,hour:Int,minute:Int){require(hour in 0..23 && minute in 0..59);context.getSharedPreferences("radar_daily",0).edit().putBoolean("enabled",enabled).putInt("hour",hour).putInt("minute",minute).apply();schedule(context)}
  fun schedule(context:Context){
   val alarm=context.getSystemService(AlarmManager::class.java)
   val pi=PendingIntent.getBroadcast(context,700,Intent(context,DailySummaryReceiver::class.java).setAction("kr.campusradar.DAILY"),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
   alarm.cancel(pi);val p=context.getSharedPreferences("radar_daily",0);if(!p.getBoolean("enabled",false))return
   val now=ZonedDateTime.now();var next=now.withHour(p.getInt("hour",18)).withMinute(p.getInt("minute",0)).withSecond(0).withNano(0)
   if(!next.isAfter(now))next=next.plusDays(1)
   alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next.toInstant().toEpochMilli(),pi)
  }
  fun send(context:Context){
   val s=RadarData.read(context);if(!s.connected){RadarData.log(context,"데일리 요약 건너뜀","연결된 계정의 수집 기록이 없습니다.");return}
   val manager=NotificationManagerCompat.from(context)
   if(!manager.areNotificationsEnabled()){RadarData.log(context,"데일리 요약 건너뜀","알림 권한이 꺼져 있습니다.");return}
   val nm=context.getSystemService(NotificationManager::class.java)
   nm.createNotificationChannel(NotificationChannel("daily_summary","데일리 과제 요약",NotificationManager.IMPORTANCE_DEFAULT))
   val p=context.getSharedPreferences("FlutterSharedPreferences",0)
   val utcHour=Instant.now().toEpochMilli()/3600000
   val cachedHour=p.getLong("flutter.aiSummaryHour",-100)
   val today=ZonedDateTime.now(ZoneId.of("Asia/Seoul")).toLocalDate().toString()
   val valid=p.getLong("flutter.aiSummaryExpires",0)>Instant.now().toEpochMilli() && p.getBoolean("flutter.aiSummaryEnabled",false) && p.getString("flutter.aiSummaryLast",null)==s.last && p.getString("flutter.aiSummaryDay",null)==today && utcHour-cachedHour in 0L..1L
   val extra=if(valid)p.getString("flutter.aiSummaryText","").orEmpty() else ""
   val body=RadarData.summary(s)+(if(extra.isNotBlank())"\nAI 우선 확인\n$extra" else "")+"\n마지막 확인 ${RadarData.stamp(s)} (한국 시간)"
   val notification=NotificationCompat.Builder(context,"daily_summary").setSmallIcon(R.drawable.ic_stat_radar).setContentTitle("오늘의 캠퍼스레이더").setContentText(body.lines().first()).setStyle(NotificationCompat.BigTextStyle().bigText(body)).setContentIntent(RadarData.launch(context,"_summary",700)).setAutoCancel(true).build()
   try{manager.notify(700,notification);RadarData.log(context,"데일리 요약 발송 요청",body)}catch(_:SecurityException){RadarData.log(context,"데일리 요약 건너뜀","알림 권한을 확인해 주세요.")}
  }
 }
}

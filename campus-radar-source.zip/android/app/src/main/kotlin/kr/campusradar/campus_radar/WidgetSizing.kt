package kr.campusradar.campus_radar

/** Pure layout policy, in dp, independent of a launcher's cell dimensions. */
object WidgetSizing {
 data class Tasks(val rows:Int,val padding:Int,val title:Boolean,val stamp:Boolean,val factor:Float)
 fun tasks(width:Int,height:Int,fontScale:Float=1f):Tasks {
  val scale=fontScale.coerceIn(.7f,1.6f)
  val compact=width<210||height<180
  val title=!compact&&height>=220
  val stamp=height>=180
  val fixed=24+(if(title)26 else 0)+(if(stamp)18 else 0)
  val rows=((height-fixed)/(40*scale)).toInt().coerceIn(1,4)
  return Tasks(rows,if(compact)8 else 12,title,stamp,if(width<160).85f else 1f)
 }
}

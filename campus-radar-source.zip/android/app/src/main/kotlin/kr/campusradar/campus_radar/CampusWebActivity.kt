package kr.campusradar.campus_radar
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.widget.Button
import android.widget.LinearLayout
import org.json.JSONObject
class CampusWebActivity:Activity(){
 private lateinit var web:WebView
 override fun onCreate(state:Bundle?){
  super.onCreate(state)
  val column=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  column.addView(Button(this).apply{text="앱으로 돌아가기";setOnClickListener{finish()}})
  web=WebView(this);column.addView(web,LinearLayout.LayoutParams(-1,0,1f));setContentView(column)
  web.settings.javaScriptEnabled=true;web.settings.domStorageEnabled=true
  web.settings.allowFileAccess=false;web.settings.allowContentAccess=false
  val destination=intent.getStringExtra("url")!!;val context=intent.getStringExtra("context")!!
  web.webViewClient=object:WebViewClient(){
   override fun shouldOverrideUrlLoading(view:WebView,request:WebResourceRequest):Boolean{
    val uri=request.url
    if(uri.scheme=="https" && uri.host in listOf("dcs-learning.cnu.ac.kr","dcs-lcms.cnu.ac.kr"))return false
    if(uri.scheme=="https")startActivity(Intent(Intent.ACTION_VIEW,uri));return true
   }
   override fun onPageFinished(view:WebView,url:String){
    val target=intent.getStringExtra("target")?:return
    if(Uri.parse(url).path=="/std/course")view.evaluateJavascript("(function(){var id=${JSONObject.quote(target)};var attempts=0;function jump(){var e=Array.from(document.querySelectorAll('[data-contentsid]')).find(e=>e.dataset.moduletype==='LV'&&(e.dataset.contentsid===id||e.dataset.weekseqno===id));if(e){var box=e.closest('.collapse');if(box)box.classList.add('show');e.scrollIntoView({block:'center'});if(window.courseAttend)courseAttend.detailContents(window.jQuery(e));}else if(attempts++<20)setTimeout(jump,500);}jump();})();",null)
   }
  }
  val javascript="sessionStorage.setItem('currentCourseData',${JSONObject.quote(context)});location.replace(${JSONObject.quote(destination)});"
  web.loadDataWithBaseURL("https://dcs-learning.cnu.ac.kr/home","<!doctype html><meta charset=utf-8><p>강의실 연결 중…</p><script>$javascript</script>","text/html","UTF-8",null)
 }
 @Deprecated("Deprecated in Java")override fun onBackPressed(){if(web.canGoBack())web.goBack()else super.onBackPressed()}
 override fun onDestroy(){web.destroy();super.onDestroy()}
}


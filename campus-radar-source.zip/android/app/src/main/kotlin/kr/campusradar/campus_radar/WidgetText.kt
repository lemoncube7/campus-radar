package kr.campusradar.campus_radar

import android.content.Context

object WidgetText {
 private val keys=listOf("tasks","timetable","lock")
 fun settings(c:Context):Map<String,Int> = keys.associateWith { c.getSharedPreferences("radar_widget_text",0).getInt(it,100).coerceIn(80,150) }
 fun scale(c:Context,key:String):Float = (settings(c)[key]?:100)/100f
 fun configure(c:Context,tasks:Int,timetable:Int,lock:Int) {
  val edit=c.getSharedPreferences("radar_widget_text",0).edit()
  for((key,value) in keys.zip(listOf(tasks,timetable,lock)))edit.putInt(key,value.coerceIn(80,150))
  edit.apply()
  RadarWidget.updateAll(c);TimetableWidget.updateAll(c);RadarLockAccessibilityService.instance?.reset()
  RadarData.log(c,"위젯 글씨 크기 변경","과제 ${tasks.coerceIn(80,150)}% · 시간표 ${timetable.coerceIn(80,150)}% · 잠금화면 ${lock.coerceIn(80,150)}%","app")
 }
}

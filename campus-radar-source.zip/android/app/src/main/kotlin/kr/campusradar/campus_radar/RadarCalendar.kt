package kr.campusradar.campus_radar

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.provider.CalendarContract as C
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.time.Instant

/** Touches only events explicitly linked by this app, never other appointments. */
object RadarCalendar {
 private fun prefs(c:Context)=c.getSharedPreferences("campus_calendar",Context.MODE_PRIVATE)
 fun allowed(c:Context)=ContextCompat.checkSelfPermission(c,Manifest.permission.READ_CALENDAR)==PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(c,Manifest.permission.WRITE_CALENDAR)==PackageManager.PERMISSION_GRANTED
 fun calendars(c:Context):List<Map<String,Any>> {
  check(allowed(c)){"캘린더 권한을 허용해 주세요."}
  val list=mutableListOf<Map<String,Any>>()
  c.contentResolver.query(C.Calendars.CONTENT_URI,arrayOf(C.Calendars._ID,C.Calendars.CALENDAR_DISPLAY_NAME,C.Calendars.ACCOUNT_NAME),"${C.Calendars.CALENDAR_ACCESS_LEVEL}>=? AND ${C.Calendars.VISIBLE}=1",arrayOf(C.Calendars.CAL_ACCESS_CONTRIBUTOR.toString()),null)?.use{cursor->while(cursor.moveToNext())list.add(mapOf("id" to cursor.getLong(0),"name" to (cursor.getString(1)?:"캘린더"),"account" to (cursor.getString(2)?:"")))}
  return list
 }
 fun settings(c:Context)=mapOf("calendarId" to prefs(c).getLong("calendarId",-1),"auto" to prefs(c).getBoolean("auto",false),"allowed" to allowed(c))
 @Synchronized fun configure(c:Context,id:Long,auto:Boolean) {
  if(id>=0)require(calendars(c).any{(it["id"] as Long)==id}){"쓸 수 있는 캘린더를 선택해 주세요."}
  val old=prefs(c).getLong("calendarId",-1)
  require(old<0 || old==id || prefs(c).all.keys.none{it.startsWith("event:")}){"이미 연결된 일정이 있습니다. 기존 연결을 해제한 후 캘린더를 변경해 주세요."}
  prefs(c).edit().putLong("calendarId",id).putBoolean("auto",auto && id>=0).apply()
 }
 @Synchronized fun write(c:Context,key:String,title:String,start:Long,end:Long,allDay:Boolean,description:String,automatic:Boolean=false):Long {
  check(allowed(c)){"캘린더 권한을 허용해 주세요."}
  val p=prefs(c);val calendarId=p.getLong("calendarId",-1)
  require(calendars(c).any{it["id"]==calendarId}){"캘린더 설정에서 저장할 캘린더를 선택해 주세요."}
  require(title.isNotBlank() && end>start && end-start<=366L*86400000){"일정 제목과 시간을 확인해 주세요."}
  val token="[CampusRadar:$key]"
  val v=ContentValues().apply{
   put(C.Events.CALENDAR_ID,calendarId);put(C.Events.TITLE,title);put(C.Events.DTSTART,start);put(C.Events.DTEND,end)
   put(C.Events.EVENT_TIMEZONE,if(allDay)"UTC" else "Asia/Seoul");put(C.Events.ALL_DAY,if(allDay)1 else 0)
   put(C.Events.DESCRIPTION,description.take(8000)+"\n"+token);put(C.Events.AVAILABILITY,C.Events.AVAILABILITY_FREE)
  }
  val signature=JSONObject().apply{put("title",title);put("start",start);put("end",end);put("allDay",allDay);put("description",description.take(8000))}.toString()
  var id=p.getLong("event:$key",-1)
  if(id>=0) {
   val uri=ContentUris.withAppendedId(C.Events.CONTENT_URI,id)
   var owned=false
   c.contentResolver.query(uri,arrayOf(C.Events.DESCRIPTION,C.Events.DELETED,C.Events.CALENDAR_ID),null,null,null)?.use{q->owned=q.moveToFirst() && q.getInt(1)==0 && q.getLong(2)==calendarId && (q.getString(0)?:"").contains(token)}
   if(owned) {
    if(p.getString("sig:$key",null)!=signature) {
     check(c.contentResolver.update(uri,v,null,null)==1){"캘린더 일정을 갱신하지 못했습니다."}
     p.edit().putString("sig:$key",signature).apply()
     RadarData.log(c,"캘린더 일정 갱신",title,"calendar")
    }
    return id
   }
   // User deletion or unlinking is respected during automatic synchronization.
   if(automatic)return -1
  }
  val uri=c.contentResolver.insert(C.Events.CONTENT_URI,v)?:error("일정을 저장하지 못했습니다.")
  id=ContentUris.parseId(uri)
  p.edit().putLong("event:$key",id).putString("sig:$key",signature).apply()
  RadarData.log(c,"캘린더 일정 추가",title,"calendar")
  return id
 }
 @Synchronized fun sync(c:Context) {
  val p=prefs(c)
  if(!allowed(c) || p.getLong("calendarId",-1)<0)return
  try {
   val now=Instant.now()
   for(item in RadarData.read(c).items) {
    val key=item.optString("key");val due=RadarData.instant(item.optString("due"))?:continue
    val linked=p.contains("event:$key")
    if(!linked && (!p.getBoolean("auto",false) || item.optString("status")!="pending" || !due.isAfter(now)))continue
    val done=item.optString("status")=="done"
    val schoolDue=due.atZone(RadarData.schoolZone)
    val midnight=schoolDue.toLocalDate().atStartOfDay(RadarData.schoolZone).toInstant()
    val end=due
    val start=if(due==midnight)due.minusSeconds(600) else maxOf(due.minusSeconds(600),midnight)
    val deadlineLabel=schoolDue.format(java.time.format.DateTimeFormatter.ofPattern("MM/dd HH:mm"))
    write(c,key,(if(done)"[완료] " else "")+"[마감 $deadlineLabel] [${item.optString("course")}] ${item.optString("title")}",start.toEpochMilli(),end.toEpochMilli(),false,"마감 일정 · 한국 시간\n${item.optString("body")}\nhttps://dcs-learning.cnu.ac.kr/home",true)
   }
  }catch(_:Exception){RadarData.log(c,"캘린더 동기화 실패","캘린더 권한·연결 상태를 설정에서 확인해 주세요.","calendar")}
 }
 @Synchronized fun unlink(c:Context){prefs(c).edit().clear().apply()}
}

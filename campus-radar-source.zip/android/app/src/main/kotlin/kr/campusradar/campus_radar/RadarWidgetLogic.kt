package kr.campusradar.campus_radar

import java.time.LocalDate
import java.time.ZonedDateTime

object RadarWidgetLogic {
    /** Formats next class text for RadarWidget including cancellation notice. */
    fun formatNextClass(courseName: String, start: ZonedDateTime, today: LocalDate, isCancelled: Boolean): String {
        val time = "%02d:%02d".format(start.hour, start.minute)
        val day = if (start.toLocalDate() == today) "" else "내일 "
        val cancelSuffix = if (isCancelled) " (휴강으로 인식됨)" else ""
        return "다음 · $day$time · $courseName$cancelSuffix"
    }
}

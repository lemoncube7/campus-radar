package kr.campusradar.campus_radar

import android.content.Context
import java.io.File
import org.json.JSONObject

data class SyncResult(val writes: Int, val complete: Boolean, val retry: Boolean)

object DriveSyncEngine {
    private fun decodeBase64(s: String): ByteArray = try {
        java.util.Base64.getDecoder().decode(s)
    } catch (_: Throwable) {
        android.util.Base64.decode(s, android.util.Base64.DEFAULT)
    }

    fun syncAccount(
        c: Context? = null,
        api: DriveApi,
        row: JSONObject,
        payload: JSONObject,
        term: String,
        deadline: Long = Long.MAX_VALUE,
        maxWrites: Int = 25,
        // Must use the same clock as `deadline`. The worker passes elapsedRealtime for both;
        // mixing them made every run look past the deadline (0 writes, re-queued every few seconds).
        nowProvider: () -> Long = { System.currentTimeMillis() },
        checkActive: () -> Unit = {},
        checkpoint: () -> Unit = {},
        logInfo: ((String, String) -> Unit)? = null,
        logError: ((String, String, Throwable?) -> Unit)? = null,
    ): SyncResult {
        fun oldestItem(items: List<DriveItem>): DriveItem? {
            if (items.isEmpty()) return null
            return items.minWithOrNull(compareBy({ it.createdTime.ifBlank { "9999" } }, { it.id }))
        }

        // 1. Root folder
        var folder = row.optString("folder")
        var isNewFolder = false
        val existingRoots = api.listChildren("root", "캠퍼스레이더", folderOnly = true)
        if (folder.isBlank() || !api.exists(folder)) {
            checkActive()
            if (existingRoots.isNotEmpty()) {
                val kept = oldestItem(existingRoots)!!
                folder = kept.id
                row.put("folder", folder)
                api.updateMetadata(
                    folder,
                    appProperties = DriveSyncLogic.buildAppProperties(
                        kind = DriveSyncLogic.KIND_ROOT,
                        key = "root"
                    )
                )
            } else {
                isNewFolder = true
                folder = api.id()
                row.put("folder", folder)
                checkpoint()
                api.createFolder(
                    folder,
                    "캠퍼스레이더",
                    appProperties = DriveSyncLogic.buildAppProperties(
                        kind = DriveSyncLogic.KIND_ROOT,
                        key = "root"
                    )
                )
            }
            row.remove("courseFolder")
            row.remove("materialsFolder")
            row.remove("materialsCourses")
            if (DriveSyncLogic.shouldPruneTrackedFiles(isNewFolder)) {
                row.remove("files")
                row.remove("hashes")
            }
            checkpoint()
        } else {
            api.updateMetadata(
                folder,
                appProperties = DriveSyncLogic.buildAppProperties(
                    kind = DriveSyncLogic.KIND_ROOT,
                    key = "root"
                )
            )
        }

        // The attachment ZIP is retired: trash any copy in the root on every run (one list call),
        // so untracked copies and ones re-created from older payloads cannot linger.
        for (z in api.listChildren(folder, "캠퍼스레이더 첨부원본.zip", folderOnly = false)) {
            if (!z.isFolder) { checkActive(); try { api.trash(z.id) } catch (e: DriveHttpFailure) { if (e.status != 404) throw e } }
        }
        (row.optJSONObject("files"))?.remove("캠퍼스레이더 첨부원본.zip")

        // 2. Query remote list by crKind
        val remoteItems = api.listByQuery(DriveSyncLogic.REMOTE_QUERY)
        val remoteByCrKey = mutableMapOf<String, DriveItem>()
        for (item in remoteItems) {
            if (item.crKey.isNotBlank()) {
                remoteByCrKey[item.crKey] = item
            }
        }

        // 3. cleanup066 (one-time deduplication)
        if (!row.optBoolean("cleanup066", false)) {
            try {
                var trashedFolders = 0
                var trashedFiles = 0
                fun safeTrash(tid: String) {
                    checkActive()
                    try {
                        api.trash(tid)
                    } catch (e: DriveHttpFailure) {
                        if (e.status != 404) throw e
                    }
                }

                // Root duplicates cleanup: keep 1, trash others
                if (existingRoots.size > 1) {
                    for (dupRoot in existingRoots) {
                        if (dupRoot.id != folder) {
                            checkActive()
                            val dupChildren = api.listChildren(dupRoot.id)
                            for (child in dupChildren) {
                                checkActive()
                                if (child.isFolder) {
                                    val targetFolder = api.listChildren(folder, child.name, folderOnly = true).firstOrNull()
                                    if (targetFolder != null) {
                                        val grandChildren = api.listChildren(child.id)
                                        for (grand in grandChildren) {
                                            checkActive()
                                            if (!grand.isFolder) {
                                                val dupFile = api.listChildren(targetFolder.id, grand.name, folderOnly = false).firstOrNull { !it.isFolder }
                                                if (dupFile != null && dupFile.size == grand.size) {
                                                    safeTrash(grand.id)
                                                    trashedFiles++
                                                } else {
                                                    api.updateMetadata(
                                                        grand.id,
                                                        addParents = listOf(targetFolder.id),
                                                        removeParents = listOf(child.id)
                                                    )
                                                }
                                            } else {
                                                val subTarget = api.listChildren(targetFolder.id, grand.name, folderOnly = true).firstOrNull()
                                                if (subTarget != null) {
                                                    val grandFiles = api.listChildren(grand.id)
                                                    for (gf in grandFiles) {
                                                        checkActive()
                                                        val dupFile = api.listChildren(subTarget.id, gf.name, folderOnly = false).firstOrNull { !it.isFolder }
                                                        if (dupFile != null && dupFile.size == gf.size) {
                                                            safeTrash(gf.id)
                                                            trashedFiles++
                                                        } else {
                                                            api.updateMetadata(
                                                                gf.id,
                                                                addParents = listOf(subTarget.id),
                                                                removeParents = listOf(grand.id)
                                                            )
                                                        }
                                                    }
                                                    safeTrash(grand.id)
                                                    trashedFolders++
                                                } else {
                                                    api.updateMetadata(
                                                        grand.id,
                                                        addParents = listOf(targetFolder.id),
                                                        removeParents = listOf(child.id)
                                                    )
                                                }
                                            }
                                        }
                                        safeTrash(child.id)
                                        trashedFolders++
                                    } else {
                                        api.updateMetadata(
                                            child.id,
                                            addParents = listOf(folder),
                                            removeParents = listOf(dupRoot.id)
                                        )
                                    }
                                } else {
                                    val dupFile = api.listChildren(folder, child.name, folderOnly = false).firstOrNull { !it.isFolder }
                                    if (dupFile != null && dupFile.size == child.size) {
                                        safeTrash(child.id)
                                        trashedFiles++
                                    } else {
                                        api.updateMetadata(
                                            child.id,
                                            addParents = listOf(folder),
                                            removeParents = listOf(dupRoot.id)
                                        )
                                    }
                                }
                            }
                            safeTrash(dupRoot.id)
                            trashedFolders++
                        }
                    }
                }

                // Materials folder duplicate cleanup
                val matFolders = api.listChildren(folder, "자료", folderOnly = true)
                var targetMat: String? = null
                if (matFolders.isNotEmpty()) {
                    val curMat = row.optString("materialsFolder")
                    val keptMat = if (curMat.isNotBlank() && matFolders.any { it.id == curMat }) {
                        matFolders.first { it.id == curMat }
                    } else {
                        oldestItem(matFolders)!!
                    }
                    row.put("materialsFolder", keptMat.id)
                    targetMat = keptMat.id
                    for (m in matFolders) {
                        if (m.id != keptMat.id) {
                            checkActive()
                            val cFolders = api.listChildren(m.id, folderOnly = false) // files too, or they are trashed with m
                            for (cf in cFolders) {
                                api.updateMetadata(
                                    cf.id,
                                    addParents = listOf(keptMat.id),
                                    removeParents = listOf(m.id)
                                )
                            }
                            safeTrash(m.id)
                            trashedFolders++
                        }
                    }
                } else if (row.optString("materialsFolder").isNotBlank() && api.exists(row.optString("materialsFolder"))) {
                    targetMat = row.optString("materialsFolder")
                }

                // Course folder deduplication & duplicate files cleanup ((c): (2)~(9) duplicates)
                if (targetMat != null) {
                    checkActive()
                    val courseFolders = api.listChildren(targetMat, folderOnly = true)
                    val byCourse = courseFolders.groupBy { DriveSyncLogic.safeCourseFolderName(it.name) }
                    for ((_, cList) in byCourse) {
                        val keptCourse = oldestItem(cList)!!
                        if (cList.size > 1) {
                            for (cf in cList) {
                                if (cf.id != keptCourse.id) {
                                    checkActive()
                                    val filesInDup = api.listChildren(cf.id)
                                    for (f in filesInDup) {
                                        api.updateMetadata(
                                            f.id,
                                            addParents = listOf(keptCourse.id),
                                            removeParents = listOf(cf.id)
                                        )
                                    }
                                    safeTrash(cf.id)
                                    trashedFolders++
                                }
                            }
                        }
                        checkActive()
                        val filesInCourse = api.listChildren(keptCourse.id, folderOnly = false).filter { !it.isFolder }
                        val byNormalizedName = filesInCourse.groupBy { DriveSyncLogic.normalizeAttachmentFileName(it.name) }
                        for ((_, fGroup) in byNormalizedName) {
                            if (fGroup.size > 1) {
                                val bySize = fGroup.groupBy { it.size }
                                for ((_, subGroup) in bySize) {
                                    if (subGroup.size > 1) {
                                        val cleanName = DriveSyncLogic.normalizeAttachmentFileName(subGroup.first().name)
                                        val keptFile = subGroup.firstOrNull { it.name == cleanName }
                                            ?: oldestItem(subGroup)!!
                                        for (f in subGroup) {
                                            if (f.id != keptFile.id) {
                                                safeTrash(f.id)
                                                trashedFiles++
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                row.put("cleanup066", true)
                row.put("cleanupCount", trashedFolders + trashedFiles)
                row.put("cleanedFolders", trashedFolders)
                row.put("cleanedFiles", trashedFiles)
                checkpoint()
                logInfo?.invoke("Drive 중복 정리 완료", "${row.optString("email")}: 중복 항목 ${trashedFolders + trashedFiles}개(폴더 ${trashedFolders}개, 파일 ${trashedFiles}개)를 휴지통으로 옮겼어요.")
            } catch (e: Exception) {
                logError?.invoke("Drive 중복 정리 실패", "${row.optString("email")}: 중복 정리 중 오류가 발생했어요. 전송은 계속 진행해요.", e)
            }
        }

        // 4. Term archiving & rollover
        val previousTerm = row.optString("term")
        if (DriveSyncLogic.shouldArchiveSemester(previousTerm, term)) {
            val label = previousTerm
            val tracked = row.optJSONObject("files")
            val archivedZip = "캠퍼스레이더 첨부원본.zip"
            val archives = mapOf(
                row.optString("courseFolder") to "지난 내보내기 ($label) - 과목",
                row.optString("materialsFolder") to "지난 내보내기 ($label) - 자료",
                (tracked?.optString(archivedZip) ?: "") to "지난 내보내기 ($label) - 첨부원본.zip",
            )
            for ((resource, name) in archives) {
                checkActive()
                if (resource.isNotBlank() && api.exists(resource)) {
                    api.rename(resource, name)
                }
            }
            val hashes = row.optJSONObject("hashes")
            tracked?.keys()?.asSequence()?.toList()?.filter {
                it.startsWith("과목/") || it.startsWith("자료/") || it == archivedZip
            }?.forEach {
                tracked.remove(it)
                hashes?.remove(it)
            }
            row.remove("courseFolder")
            row.remove("materialsFolder")
            row.remove("materialsCourses")
            row.put("term", term)
            checkpoint()
        } else if (previousTerm.isBlank() && term.isNotBlank()) {
            row.put("term", term)
            checkpoint()
        }

        // Archived semesters keep their files' crKeys, so the remote index would point the new
        // semester at "지난 내보내기 (...)" folders and overwrite the archive. Drop everything
        // that lives in an archive folder or one of its course subfolders.
        run {
            val archived = api.listChildren(folder, folderOnly = true)
                .filter { it.name.startsWith("지난 내보내기 (") }.map { it.id }.toMutableSet()
            for (a in archived.toList()) {
                checkActive()
                archived += api.listChildren(a, folderOnly = true).map { it.id }
            }
            if (archived.isNotEmpty()) {
                remoteByCrKey.entries.removeIf { e -> e.value.id in archived || e.value.parents.any { it in archived } }
            }
        }

        // 5. Course folder
        var course = remoteByCrKey["course"]?.id ?: row.optString("courseFolder")
        if (course.isBlank() || !api.exists(course)) {
            checkActive()
            val existingCourses = api.listChildren(folder, "과목", folderOnly = true)
            val oldest = oldestItem(existingCourses)
            if (oldest != null) {
                course = oldest.id
                row.put("courseFolder", course)
                api.updateMetadata(
                    course,
                    appProperties = DriveSyncLogic.buildAppProperties(
                        kind = DriveSyncLogic.KIND_COURSE,
                        key = "course"
                    )
                )
            } else {
                course = api.id()
                row.put("courseFolder", course)
                checkpoint()
                api.createFolder(
                    course,
                    "과목",
                    parent = folder,
                    appProperties = DriveSyncLogic.buildAppProperties(
                        kind = DriveSyncLogic.KIND_COURSE,
                        key = "course"
                    )
                )
            }
            remoteByCrKey["course"] = DriveItem(
                id = course,
                name = "과목",
                mimeType = "application/vnd.google-apps.folder",
                appProperties = mapOf("crKind" to "course", "crKey" to "course")
            )
            checkpoint()
        }

        // 6. Materials folder & per-course materials folders
        var materials = remoteByCrKey["materials"]?.id ?: row.optString("materialsFolder")
        val materialsCourses = row.optJSONObject("materialsCourses") ?: JSONObject().also { row.put("materialsCourses", it) }

        fun ensureMaterialsFolder(): String {
            if (materials.isBlank() || !api.exists(materials)) {
                checkActive()
                val existingMat = api.listChildren(folder, "자료", folderOnly = true)
                val oldest = oldestItem(existingMat)
                if (oldest != null) {
                    materials = oldest.id
                    row.put("materialsFolder", materials)
                    api.updateMetadata(
                        materials,
                        appProperties = DriveSyncLogic.buildAppProperties(
                            kind = DriveSyncLogic.KIND_MATERIALS,
                            key = "materials"
                        )
                    )
                } else {
                    materials = api.id()
                    row.put("materialsFolder", materials)
                    checkpoint()
                    api.createFolder(
                        materials,
                        "자료",
                        parent = folder,
                        appProperties = DriveSyncLogic.buildAppProperties(
                            kind = DriveSyncLogic.KIND_MATERIALS,
                            key = "materials"
                        )
                    )
                }
                remoteByCrKey["materials"] = DriveItem(
                    id = materials,
                    name = "자료",
                    mimeType = "application/vnd.google-apps.folder",
                    appProperties = mapOf("crKind" to "materials", "crKey" to "materials")
                )
                checkpoint()
            }
            return materials
        }

        fun courseMaterialsFolder(cName: String): String {
            val mat = ensureMaterialsFolder()
            val safeC = DriveSyncLogic.safeCourseFolderName(cName)
            val courseMatKey = "materials:$safeC"
            var cf = remoteByCrKey[courseMatKey]?.id ?: materialsCourses.optString(cName)
            if (cf.isBlank() || !api.exists(cf)) {
                checkActive()
                val existingCourseMat = api.listChildren(mat, folderOnly = true)
                val oldest = oldestItem(
                    existingCourseMat.filter {
                        DriveSyncLogic.safeCourseFolderName(it.name) == safeC || it.name.trim() == cName.trim()
                    }
                )
                if (oldest != null) {
                    cf = oldest.id
                    if (oldest.name != cName && oldest.name != safeC) {
                        try { api.rename(cf, cName) } catch (_: Exception) {}
                    }
                    api.updateMetadata(
                        cf,
                        appProperties = DriveSyncLogic.buildAppProperties(
                            kind = DriveSyncLogic.KIND_MATERIALS,
                            key = courseMatKey
                        )
                    )
                } else {
                    cf = api.id()
                    checkpoint()
                    api.createFolder(
                        cf,
                        cName,
                        parent = mat,
                        appProperties = DriveSyncLogic.buildAppProperties(
                            kind = DriveSyncLogic.KIND_MATERIALS,
                            key = courseMatKey
                        )
                    )
                }
                materialsCourses.put(cName, cf)
                remoteByCrKey[courseMatKey] = DriveItem(
                    id = cf,
                    name = cName,
                    mimeType = "application/vnd.google-apps.folder",
                    appProperties = mapOf("crKind" to "materials", "crKey" to courseMatKey)
                )
                checkpoint()
            }
            return cf
        }

        val files = row.optJSONObject("files") ?: JSONObject().also { row.put("files", it) }
        val hashes = row.optJSONObject("hashes") ?: JSONObject().also { row.put("hashes", it) }
        val docs = payload.optJSONObject("documents") ?: JSONObject()
        // 0.6.6 retired the attachment ZIP. A payload prepared by an older version (reused
        // while its revision is unchanged) may still list it: drop it so it is not re-uploaded
        // and the tracked copy is trashed in step 10.
        docs.remove("캠퍼스레이더 첨부원본.zip")
        fun attachmentFolder(courseName: String, entry: JSONObject): String {
            val parent = courseMaterialsFolder(courseName)
            if (entry.optString("section") != "freeboard") return parent
            val key = "materials:${DriveSyncLogic.safeCourseFolderName(courseName)}:freeboard"
            val cached = remoteByCrKey[key]
            if (cached != null && api.exists(cached.id)) return cached.id
            checkActive()
            val existing = oldestItem(api.listChildren(parent, "자유게시판", folderOnly = true))
            val id = existing?.id ?: api.id()
            val props = DriveSyncLogic.buildAppProperties(kind = DriveSyncLogic.KIND_MATERIALS, key = key)
            if (existing == null) api.createFolder(id, "자유게시판", parent, props)
            else api.updateMetadata(id, appProperties = props)
            remoteByCrKey[key] = DriveItem(id = id, name = "자유게시판",
                mimeType = "application/vnd.google-apps.folder", appProperties = props)
            return id
        }
        val fileEntries = payload.optJSONObject("files") ?: JSONObject()
        if (!row.optBoolean("cleanup066c", false)) {
            val cleaned = DriveLegacyCleanup.run(api, folder, course, ::courseMaterialsFolder, checkActive)
            row.put("cleanupCount", row.optInt("cleanupCount") + cleaned.folders + cleaned.files)
            row.put("cleanedFolders", row.optInt("cleanedFolders") + cleaned.folders)
            row.put("cleanedFiles", row.optInt("cleanedFiles") + cleaned.files)
            row.put("cleanup066c", true)
            checkpoint()
            logInfo?.invoke("Drive 보관 자료 정리 완료", "학기 미확인 보관본과 이전 ZIP ${cleaned.folders + cleaned.files}개를 휴지통으로 옮겼어요.")
        }
        val docNames = docs.keys().asSequence().filter { it != "캠퍼스레이더 시작.txt" }.toList()

        // Key migration: if an old 0.6.5 key exists in files/hashes, migrate it to the new 0.6.6 key
        for (name in fileEntries.keys()) {
            if (!files.has(name)) {
                val entry = fileEntries.getJSONObject(name)
                val newHash = entry.optString("sha256")
                var matchingOldKey: String? = null
                for (oldKey in files.keys()) {
                    if (oldKey.startsWith("자료/") && !fileEntries.has(oldKey)) {
                        val oldHash = hashes.optString(oldKey)
                        if (DriveSyncLogic.isLegacyMatchingKey(oldKey, name, oldHash, newHash)) {
                            matchingOldKey = oldKey
                            break
                        }
                    }
                }
                if (matchingOldKey != null) {
                    val oldFid = files.getString(matchingOldKey)
                    val oldHash = hashes.optString(matchingOldKey)
                    files.put(name, oldFid)
                    if (oldHash.isNotBlank()) hashes.put(name, oldHash)
                    files.remove(matchingOldKey)
                    hashes.remove(matchingOldKey)
                    checkpoint()
                }
            }
        }
        for (name in docNames) {
            if (!files.has(name) && name.startsWith("과목/")) {
                val fName = name.substringAfterLast('/')
                var matchingOldKey: String? = null
                for (oldKey in files.keys()) {
                    if (oldKey.startsWith("과목/") && !docs.has(oldKey)) {
                        val oldFName = oldKey.substringAfterLast('/')
                        if (DriveSyncLogic.safeCourseFolderName(oldFName.removeSuffix(".txt")) == fName.removeSuffix(".txt")) {
                            matchingOldKey = oldKey
                            break
                        }
                    }
                }
                if (matchingOldKey != null) {
                    val oldFid = files.getString(matchingOldKey)
                    val oldHash = hashes.optString(matchingOldKey)
                    files.put(name, oldFid)
                    if (oldHash.isNotBlank()) hashes.put(name, oldHash)
                    files.remove(matchingOldKey)
                    hashes.remove(matchingOldKey)
                    checkpoint()
                }
            }
        }

        var writes = 0
        var complete = true

        // 7. Upload documents (except start document)
        for (name in docNames) {
            checkActive()
            if (nowProvider() >= deadline) { complete = false; break }
            val text = docs.getString(name)
            val hash = DriveApi.digest(text)
            val docKey = DriveSyncLogic.documentKey(name)
            var remote = remoteByCrKey[docKey]

            if (remote == null) {
                val parent = if (name.startsWith("과목/")) course else folder
                val fileName = name.substringAfterLast('/')
                val existingDocs = api.listChildren(parent, fileName, folderOnly = false).filter { !it.isFolder }
                val oldest = oldestItem(existingDocs)
                if (oldest != null) {
                    val isSameSize = oldest.size == text.toByteArray(Charsets.UTF_8).size.toLong()
                    val adoptedHash = if (isSameSize) hash else (if (oldest.crHash.isNotBlank()) oldest.crHash else "")
                    val adoptedProps = DriveSyncLogic.buildAppProperties(
                        kind = DriveSyncLogic.KIND_FILE,
                        key = docKey,
                        hash = adoptedHash
                    )
                    api.updateMetadata(oldest.id, appProperties = adoptedProps)
                    remote = DriveItem(
                        id = oldest.id,
                        name = fileName,
                        createdTime = oldest.createdTime,
                        mimeType = oldest.mimeType,
                        size = oldest.size,
                        appProperties = adoptedProps
                    )
                    remoteByCrKey[docKey] = remote
                }
            }

            if (remote != null) {
                if (remote.crHash == hash) {
                    files.put(name, remote.id)
                    hashes.put(name, hash)
                    continue
                }
                if (writes >= maxWrites) { complete = false; break }
                checkActive()
                if (name.endsWith(".zip")) {
                    val bytes = if (text.startsWith("file://")) {
                        val zf = File(text.removePrefix("file://")).canonicalFile
                        if (!zf.isFile || zf.length() > 25L * 1024 * 1024) throw IllegalStateException("ZIP invalid or >25MB")
                        zf.readBytes()
                    } else {
                        decodeBase64(text)
                    }
                    api.writeBytes(remote.id, bytes, "application/zip")
                } else {
                    api.write(remote.id, text)
                }
                val newProps = DriveSyncLogic.buildAppProperties(
                    kind = DriveSyncLogic.KIND_FILE,
                    key = docKey,
                    hash = hash
                )
                api.updateMetadata(remote.id, appProperties = newProps)
                files.put(name, remote.id)
                hashes.put(name, hash)
                remoteByCrKey[docKey] = DriveItem(
                    id = remote.id,
                    name = remote.name,
                    mimeType = remote.mimeType,
                    size = text.toByteArray(Charsets.UTF_8).size.toLong(),
                    appProperties = newProps
                )
                checkpoint()
                writes++
            } else {
                if (writes >= maxWrites) { complete = false; break }
                checkActive()
                val parent = if (name.startsWith("과목/")) course else folder
                val fileName = name.substringAfterLast('/')
                val id = api.id()
                val appProps = DriveSyncLogic.buildAppProperties(
                    kind = DriveSyncLogic.KIND_FILE,
                    key = docKey,
                    hash = hash
                )
                if (name.endsWith(".zip")) {
                    api.createFile(id, fileName, "application/zip", parent, appProperties = appProps)
                    val bytes = if (text.startsWith("file://")) {
                        val zf = File(text.removePrefix("file://")).canonicalFile
                        if (!zf.isFile || zf.length() > 25L * 1024 * 1024) throw IllegalStateException("ZIP invalid or >25MB")
                        zf.readBytes()
                    } else {
                        decodeBase64(text)
                    }
                    api.writeBytes(id, bytes, "application/zip")
                    api.updateMetadata(id, appProperties = appProps)
                } else {
                    api.createText(id, fileName, parent, appProperties = appProps)
                    api.write(id, text)
                    api.updateMetadata(id, appProperties = appProps)
                }
                files.put(name, id)
                hashes.put(name, hash)
                remoteByCrKey[docKey] = DriveItem(
                    id = id,
                    name = fileName,
                    mimeType = "text/plain",
                    size = text.toByteArray(Charsets.UTF_8).size.toLong(),
                    appProperties = appProps
                )
                checkpoint()
                writes++
            }
        }

        // 8. Upload material originals (fileEntries)
        if (complete && writes < maxWrites) {
            val fileNames = fileEntries.keys().asSequence().toList().sorted()
            for (name in fileNames) {
                checkActive()
                if (nowProvider() >= deadline) { complete = false; break }
                val entry = fileEntries.getJSONObject(name)
                val localPath = entry.optString("path")
                val bytes = if (entry.has("bytesBase64")) {
                    decodeBase64(entry.getString("bytesBase64"))
                } else if (localPath.isNotBlank()) {
                    val f = File(localPath)
                    if (f.isFile) f.readBytes() else null
                } else null
                if (bytes == null) continue

                val hash = entry.getString("sha256")
                val mime = entry.optString("mime", "application/octet-stream")
                val courseName = name.removePrefix("자료/").substringBefore('/')
                val fileName = name.substringAfterLast('/')
                val attKey = if (entry.optString("crKey").isNotBlank()) {
                    entry.getString("crKey")
                } else {
                    DriveSyncLogic.attachmentKey(
                        course = courseName,
                        fileName = fileName,
                        attachmentId = entry.optString("attachmentId").takeIf { it.isNotBlank() }
                    )
                }
                var remote = remoteByCrKey[attKey]

                if (remote == null && files.has(name)) {
                    val trackedId = files.optString(name)
                    if (trackedId.isNotBlank() && api.exists(trackedId)) {
                        val adoptedProps = DriveSyncLogic.buildAppProperties(
                            kind = DriveSyncLogic.KIND_FILE,
                            key = attKey,
                            hash = hash
                        )
                        api.updateMetadata(trackedId, appProperties = adoptedProps)
                        remote = DriveItem(
                            id = trackedId,
                            name = fileName,
                            mimeType = mime,
                            size = bytes.size.toLong(),
                            appProperties = adoptedProps
                        )
                        remoteByCrKey[attKey] = remote
                    }
                }

                if (remote == null) {
                    val parent = attachmentFolder(courseName, entry)
                    val allFilesInParent = api.listChildren(parent, folderOnly = false).filter { !it.isFolder }
                    val cleanTarget = DriveSyncLogic.safeAttachmentFileName(
                        DriveSyncLogic.normalizeAttachmentFileName(fileName)
                    )
                    // A file whose own name carries " (n)" is a distinct attachment: match it exactly only.
                    // Never take a file another key already owns (its crKey), so two different
                    // same-size attachments cannot be renamed into or trashed as each other.
                    val hasSuffix = DriveSyncLogic.normalizeAttachmentFileName(fileName) != fileName
                    val matchingLegacy = allFilesInParent.filter {
                        (it.crKey.isBlank() || it.crKey == attKey) &&
                            it.size == bytes.size.toLong() && (it.name == fileName ||
                            (!hasSuffix && DriveSyncLogic.safeAttachmentFileName(DriveSyncLogic.normalizeAttachmentFileName(it.name)) == cleanTarget))
                    }
                    if (matchingLegacy.isNotEmpty()) {
                        val adopted = matchingLegacy.firstOrNull { it.name == fileName }
                            ?: oldestItem(matchingLegacy)!!
                        if (adopted.name != fileName) {
                            try { api.rename(adopted.id, fileName) } catch (_: Exception) {}
                        }
                        val adoptedProps = DriveSyncLogic.buildAppProperties(
                            kind = DriveSyncLogic.KIND_FILE,
                            key = attKey,
                            hash = hash
                        )
                        api.updateMetadata(adopted.id, appProperties = adoptedProps)
                        for (dup in matchingLegacy) {
                            if (dup.id != adopted.id) {
                                try { api.trash(dup.id) } catch (_: Exception) {}
                            }
                        }
                        remote = DriveItem(
                            id = adopted.id,
                            name = fileName,
                            createdTime = adopted.createdTime,
                            mimeType = mime,
                            size = adopted.size,
                            appProperties = adoptedProps
                        )
                        remoteByCrKey[attKey] = remote
                    }
                }

                if (remote != null) {
                    if (remote.crHash == hash) {
                        files.put(name, remote.id)
                        hashes.put(name, hash)
                        continue
                    }
                    if (writes >= maxWrites) { complete = false; break }
                    checkActive()
                    api.writeBytes(remote.id, bytes, mime)
                    val newProps = DriveSyncLogic.buildAppProperties(
                        kind = DriveSyncLogic.KIND_FILE,
                        key = attKey,
                        hash = hash
                    )
                    api.updateMetadata(remote.id, appProperties = newProps)
                    files.put(name, remote.id)
                    hashes.put(name, hash)
                    remoteByCrKey[attKey] = DriveItem(
                        id = remote.id,
                        name = remote.name,
                        mimeType = mime,
                        size = bytes.size.toLong(),
                        appProperties = newProps
                    )
                    checkpoint()
                    writes++
                } else {
                    if (writes >= maxWrites) { complete = false; break }
                    checkActive()
                    val parent = attachmentFolder(courseName, entry)
                    val fid = api.id()
                    val appProps = DriveSyncLogic.buildAppProperties(
                        kind = DriveSyncLogic.KIND_FILE,
                        key = attKey,
                        hash = hash
                    )
                    api.createFile(fid, fileName, mime, parent, appProperties = appProps)
                    api.writeBytes(fid, bytes, mime)
                    api.updateMetadata(fid, appProperties = appProps)
                    files.put(name, fid)
                    hashes.put(name, hash)
                    remoteByCrKey[attKey] = DriveItem(
                        id = fid,
                        name = fileName,
                        mimeType = mime,
                        size = bytes.size.toLong(),
                        appProperties = appProps
                    )
                    checkpoint()
                    writes++
                }
            }
        }

        // 9. Start document
        if (complete && writes < maxWrites && docs.has("캠퍼스레이더 시작.txt")) {
            val name = "캠퍼스레이더 시작.txt"
            checkActive()
            val text = docs.getString(name)
            val hash = DriveApi.digest(text)
            val docKey = DriveSyncLogic.documentKey(name)
            var remote = remoteByCrKey[docKey]

            if (remote == null) {
                val existingStart = api.listChildren(folder, name, folderOnly = false).filter { !it.isFolder }
                val oldest = oldestItem(existingStart)
                if (oldest != null) {
                    val isSameSize = oldest.size == text.toByteArray(Charsets.UTF_8).size.toLong()
                    val adoptedHash = if (isSameSize) hash else (if (oldest.crHash.isNotBlank()) oldest.crHash else "")
                    val adoptedProps = DriveSyncLogic.buildAppProperties(
                        kind = DriveSyncLogic.KIND_FILE,
                        key = docKey,
                        hash = adoptedHash
                    )
                    api.updateMetadata(oldest.id, appProperties = adoptedProps)
                    remote = DriveItem(
                        id = oldest.id,
                        name = name,
                        createdTime = oldest.createdTime,
                        mimeType = oldest.mimeType,
                        size = oldest.size,
                        appProperties = adoptedProps
                    )
                    remoteByCrKey[docKey] = remote
                }
            }

            if (remote != null) {
                if (remote.crHash != hash) {
                    checkActive()
                    api.write(remote.id, text)
                    val newProps = DriveSyncLogic.buildAppProperties(
                        kind = DriveSyncLogic.KIND_FILE,
                        key = docKey,
                        hash = hash
                    )
                    api.updateMetadata(remote.id, appProperties = newProps)
                    files.put(name, remote.id)
                    hashes.put(name, hash)
                    remoteByCrKey[docKey] = DriveItem(
                        id = remote.id,
                        name = remote.name,
                        mimeType = remote.mimeType,
                        size = text.toByteArray(Charsets.UTF_8).size.toLong(),
                        appProperties = newProps
                    )
                    checkpoint()
                    writes++
                } else {
                    files.put(name, remote.id)
                    hashes.put(name, hash)
                }
            } else {
                checkActive()
                val fid = api.id()
                val appProps = DriveSyncLogic.buildAppProperties(
                    kind = DriveSyncLogic.KIND_FILE,
                    key = docKey,
                    hash = hash
                )
                api.createText(fid, name, folder, appProperties = appProps)
                api.write(fid, text)
                api.updateMetadata(fid, appProperties = appProps)
                files.put(name, fid)
                hashes.put(name, hash)
                remoteByCrKey[docKey] = DriveItem(
                    id = fid,
                    name = name,
                    mimeType = "text/plain",
                    size = text.toByteArray(Charsets.UTF_8).size.toLong(),
                    appProperties = appProps
                )
                checkpoint()
                writes++
            }
        } else if (docs.has("캠퍼스레이더 시작.txt") && (!complete || writes >= maxWrites)) {
            complete = false
        }

        // 10. Only app-owned tracked files removed from export are trashed
        // A key can be renamed (e.g. "x (2).hwp" -> "x.hwp") while both point to the same
        // Drive file. Never trash an id that a live key still uses: that deleted adopted files.
        val liveIds = files.keys().asSequence()
            .filter { docs.has(it) || fileEntries.has(it) }
            .map { files.optString(it) }.toSet()
        for (old in files.keys().asSequence().toList()) {
            if (!docs.has(old) && !fileEntries.has(old)) {
                // Attachment originals come only from the device cache, which evicts files
                // (300MB) and is empty after a reinstall. A missing entry is not a deletion:
                // keep the Drive copy and its tracking so it is not re-uploaded later.
                if (old.startsWith("자료/")) continue
                checkActive()
                if (files.optString(old) in liveIds) {
                    files.remove(old); hashes.remove(old); checkpoint(); continue
                }
                try {
                    api.trash(files.getString(old))
                } catch (e: DriveHttpFailure) {
                    if (e.status != 404) throw e
                }
                files.remove(old)
                hashes.remove(old)
                checkpoint()
            }
        }

        val retry = !complete || writes >= maxWrites
        return SyncResult(writes = writes, complete = complete, retry = retry)
    }
}

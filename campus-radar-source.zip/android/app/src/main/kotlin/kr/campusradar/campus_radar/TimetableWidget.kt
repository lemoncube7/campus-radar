package kr.campusradar.campus_radar

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.os.Bundle
import android.database.sqlite.SQLiteDatabase
import android.graphics.*
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.widget.RemoteViews
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.*

class TimetableWidget: AppWidgetProvider() {
 override fun onUpdate(context:Context, manager:AppWidgetManager, ids:IntArray) { WidgetWork.run { ids.forEach { update(context,manager,it) } } }
 override fun onAppWidgetOptionsChanged(context:Context, manager:AppWidgetManager, id:Int, options:Bundle) { WidgetWork.run { update(context,manager,id) } }
 companion object {
  fun updateAll(context:Context) {
   CompactStudyWidget.updateAll(context)
   val manager=AppWidgetManager.getInstance(context)
   WidgetWork.run { manager.getAppWidgetIds(android.content.ComponentName(context,TimetableWidget::class.java)).forEach {update(context,manager,it)} }
  }
  private fun rows(context:Context):List<JSONObject> = RadarData.timetableEntries(context)
  private fun update(context:Context, manager:AppWidgetManager, id:Int) {
   try {
    val options=manager.getAppWidgetOptions(id)
    val w=(options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,320)*2).coerceIn(220,1200)
    val h=(options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT,350)*2).coerceIn(220,1400)
    val customColors=try{JSONObject(context.getSharedPreferences("FlutterSharedPreferences",Context.MODE_PRIVATE).getString("flutter.courseColorOverrides","{}")?:"{}")}catch(_:Exception){JSONObject()}
    val bitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888)
    val canvas=Canvas(bitmap);val palette=WidgetStyle.read(context);canvas.drawColor(palette.surface)
    val p=Paint(Paint.ANTI_ALIAS_FLAG)
    val accent=NativeAccentPalette.read(context)
    val compact=w<550||h<450
    val scale=WidgetText.scale(context,"timetable")*(if(compact).8f else 1f)
    fun text(value:String,x:Float,y:Float,size:Float=22f,color:Int=palette.text) {p.color=color;p.textSize=size*scale;p.typeface=Typeface.create("sans-serif",Typeface.NORMAL);canvas.drawText(value,x,y,p)}
    val now=java.time.ZonedDateTime.now(RadarData.schoolZone)
    val entries=rows(context)
    if(!compact)text("이번 주 시간표",20f,35f,26f,palette.primary)
    if(entries.isEmpty()) text("앱에서 시간표 만들기를 눌러 주세요",20f,90f,22f)
    else if(h<340||w<300){
     val upcoming=TimetableWidgetLogic.pickUpcomingJson(entries,now)
     val today=now.dayOfWeek.value;val minute=now.hour*60+now.minute
     val isToday=entries.any{it.optInt("weekday")==today&&it.optInt("end")>minute}
     text(if(isToday)"오늘 수업"else "수업 시간",20f,32f,24f,palette.primary)
     val count=((h-55)/68).coerceIn(1,3)
     for((index,item)in upcoming.take(count).withIndex()){
      val row=item.row;val rowDate=item.date
      val y=68f+index*68f
      val isCancelled=TimetableCancellations.cancelled(context,row,rowDate)
      val label=RadarData.courseName(context,row)+(if(isCancelled)" (휴강으로 인식됨)" else "")
      val paint=TextPaint(Paint.ANTI_ALIAS_FLAG).apply{color=palette.text;textSize=25f*scale;typeface=Typeface.create("sans-serif",Typeface.BOLD)}
      canvas.drawText(TextUtils.ellipsize(label,paint,(w-40).toFloat(),TextUtils.TruncateAt.END).toString(),20f,y,paint)
      val meta="${listOf("월","화","수","목","금","토","일")[row.optInt("weekday")-1]} %02d:%02d".format(row.optInt("start")/60,row.optInt("start")%60)+(if(row.optString("room").isBlank())""else " · ${row.optString("room")}")
      paint.textSize=20f*scale;paint.color=palette.muted
      canvas.drawText(TextUtils.ellipsize(meta,paint,(w-40).toFloat(),TextUtils.TruncateAt.END).toString(),20f,y+28,paint)
     }
    }
    else {
     val days=max(5,entries.maxOf{it.optInt("weekday")})
     val first=min(9,entries.minOf{it.optInt("start")/60})
     val last=max(18,entries.maxOf{(it.optInt("end")+59)/60})
     val left=58f;val top=if(compact)45f else 85f;val col=(w-left-10)/days;val hour=(h-top-15)/(last-first)
     val names=listOf("월","화","수","목","금","토","일")
     val today=now.dayOfWeek.value
     if(today<=days){p.color=WidgetStyle.blend(palette.primary,palette.surface,.08f);canvas.drawRect(left+(today-1)*col,top-28,left+today*col,h-15f,p)}
     for(d in 0 until days)text(names[d],left+d*col+col/2-10,top-17,22f,palette.secondary)
     for(t in first..last){val y=top+(t-first)*hour;p.color=palette.line;p.strokeWidth=1f;canvas.drawLine(left,y,w-10f,y,p);text("%02d".format(t),12f,y+7,18f)}
     val colors=listOf(0xffdce5ff.toInt(),0xffd2eee7.toInt(),0xffffe0cd.toInt(),0xffeadbfa.toInt(),0xffd6eaff.toInt(),0xffffdbea.toInt())
     val positions=mutableMapOf<String,Pair<Int,Int>>()
     for(day in 1..7){
      val rows=entries.filter{it.optInt("weekday")==day}.sortedWith(compareBy<JSONObject>{it.optInt("start")}.thenBy{it.optString("id")})
      var index=0
      while(index<rows.size){
       val group=mutableListOf(rows[index++]);var end=group.first().optInt("end")
       while(index<rows.size && rows[index].optInt("start")<end){val row=rows[index++];group.add(row);end=max(end,row.optInt("end"))}
       val ends=mutableListOf<Int>();val lanes=mutableMapOf<String,Int>()
       for(row in group){var lane=ends.indexOfFirst{it<=row.optInt("start")};if(lane<0){lane=ends.size;ends.add(row.optInt("end"))}else ends[lane]=row.optInt("end");lanes[row.optString("id")]=lane}
       for(row in group)positions[row.optString("id")]=Pair(lanes[row.optString("id")]!!,ends.size)
      }
     }
     for(e in entries){
      val position=positions[e.optString("id")]!!
      val cw=col/position.second
      val x=left+(e.optInt("weekday")-1)*col+position.first*cw+1
      val y=top+(e.optInt("start")-first*60)/60f*hour+1
      val bottom=top+(e.optInt("end")-first*60)/60f*hour-1
      val seed=if(customColors.has(e.optString("courseKey")))customColors.optLong(e.optString("courseKey")).toInt()else colors[(e.optString("courseKey").hashCode() and 0x7fffffff)%colors.size]
      p.color=WidgetStyle.blend(seed,palette.surface,if(palette.dark).25f else .55f)
      canvas.drawRoundRect(x,y,x+cw-2,bottom,7f,7f,p)
      canvas.save();canvas.clipRect(x+4,y+3,x+cw-5,bottom-3);canvas.translate(x+6,y+5)
      val available=(bottom-y-10).coerceAtLeast(12f)
      val paint=TextPaint(Paint.ANTI_ALIAS_FLAG).apply{color=palette.text;textSize=22f*scale;typeface=Typeface.create("sans-serif",Typeface.BOLD)}
      paint.textSize=min(paint.textSize,(available*.8f).coerceAtLeast(12f))
      val room=e.optString("room").trim()
      val roomPaint=TextPaint(Paint.ANTI_ALIAS_FLAG).apply{color=palette.text;textSize=min(18f*scale,(available*.36f).coerceAtLeast(10f))}
      val roomHeight=if(room.isNotEmpty())roomPaint.fontSpacing+3f else 0f
      val titleHeight=(available-roomHeight).coerceAtLeast(10f)
      paint.textSize=min(paint.textSize,titleHeight*.85f).coerceAtLeast(10f)
      val isCanc=TimetableCancellations.cancelled(context,e,now.toLocalDate().minusDays((now.dayOfWeek.value-1).toLong()).plusDays((e.optInt("weekday")-1).toLong()));val cName=RadarData.courseName(context,e)+(if(isCanc)" (휴강으로 인식됨)" else "");val maxLines=(titleHeight/paint.fontSpacing).toInt().coerceIn(1,3)
      val layout=StaticLayout.Builder.obtain(cName,0,cName.length,paint,(cw-14).toInt().coerceAtLeast(1)).setMaxLines(maxLines).setEllipsize(TextUtils.TruncateAt.END).setIncludePad(false).build()
      layout.draw(canvas)
      if(room.isNotEmpty()){
       val roomY=max(layout.height.toFloat()+roomPaint.textSize,available-roomPaint.descent())
       canvas.drawText(TextUtils.ellipsize(room,roomPaint,(cw-14).coerceAtLeast(1f),TextUtils.TruncateAt.END).toString(),0f,roomY,roomPaint)
      }
      canvas.restore()
     }
     val minute=now.hour*60+now.minute
     if(today<=days&&minute in first*60..last*60){
      val x=left+(today-1)*col
      val y=top+(minute-first*60)/60f*hour
      p.color=palette.danger
      p.strokeWidth=3f
      canvas.drawLine(x+3,y,x+col-3,y,p)
      canvas.drawCircle(x+4,y,4f,p)
     }
    }
    val views=RemoteViews(context.packageName,R.layout.timetable_widget)
    WidgetStyle.background(views,R.id.timetable_root,palette)
    views.setImageViewBitmap(R.id.timetable_image,bitmap)
    views.setViewVisibility(R.id.timetable_placeholder,android.view.View.GONE)
    views.setOnClickPendingIntent(R.id.timetable_image,RadarData.launch(context,"_timetable",8250))
    manager.updateAppWidget(id,views)
   }catch(e:Exception){RadarData.logOnce(context,"timetable-widget","시간표 위젯 오류","시간표 위젯을 그리지 못했어요.",e,"system")}
  }
 }
}

package kr.campusradar.campus_radar

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.core.app.NotificationCompat
import org.json.JSONObject

/** Explicitly enabled, on-device display only. Never wakes or unlocks the device. */
class RadarLockService: Service() {
 private val handler=Handler(Looper.getMainLooper())
 private var overlay:View?=null
 private var registered=false
 private val window by lazy{getSystemService(WindowManager::class.java)}
 private val receiver=object:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){
  when(i.action){Intent.ACTION_SCREEN_ON->handler.postDelayed({render()},400);Intent.ACTION_SCREEN_OFF,Intent.ACTION_USER_PRESENT->hide()}
 }}
 private val tick=object:Runnable{override fun run(){if(overlay!=null)render();handler.postDelayed(this,60000)}}
 override fun onCreate(){super.onCreate()
  val filter=IntentFilter().apply{addAction(Intent.ACTION_SCREEN_ON);addAction(Intent.ACTION_SCREEN_OFF);addAction(Intent.ACTION_USER_PRESENT)}
  if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,filter,Context.RECEIVER_NOT_EXPORTED) else registerReceiver(receiver,filter)
  registered=true;handler.postDelayed(tick,60000)
 }
 override fun onBind(intent:Intent?)=null
 override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
  if(intent?.action=="STOP") {prefs(this).edit().putBoolean("enabled",false).apply();stopSelf();return START_NOT_STICKY}
  if(!prefs(this).getBoolean("enabled",false)||!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY}
  val nm=getSystemService(NotificationManager::class.java)
  nm.createNotificationChannel(NotificationChannel("lock_status","잠금화면 정보 실행",NotificationManager.IMPORTANCE_LOW))
  val stop=PendingIntent.getService(this,931,Intent(this,RadarLockService::class.java).setAction("STOP"),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  val notification=NotificationCompat.Builder(this,"lock_status").setSmallIcon(R.drawable.ic_stat_radar).setContentTitle("잠금화면 과제 정보 사용 중").setContentText("기기 잠금 시 마지막 수집 내용을 표시합니다.").setContentIntent(RadarData.launch(this,"_summary",930)).setOngoing(true).setVisibility(NotificationCompat.VISIBILITY_PUBLIC).addAction(0,"기능 끄기",stop).build()
  if(Build.VERSION.SDK_INT>=34)startForeground(930,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(930,notification)
  render();return START_STICKY
 }
 private fun hide(){overlay?.let{try{window.removeView(it)}catch(_:Exception){}};overlay=null}
 private fun render(){
  hide()
  if(!getSystemService(KeyguardManager::class.java).isKeyguardLocked || !getSystemService(PowerManager::class.java).isInteractive || !Settings.canDrawOverlays(this))return
  try{
   val p=prefs(this);val full=p.getString("mode","compact")=="full";val details=p.getBoolean("details",false)
   val s=RadarData.read(this);val pending=RadarData.pending(s);val now=java.time.Instant.now()
   val urgent=pending.count{RadarData.instant(it.optString("due"))?.let{d->d.isAfter(now)&&!d.isAfter(now.plusSeconds(86400))}?:false}
   val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(20),dp(20),dp(20));setBackgroundColor(Color.rgb(22,30,55));elevation=dp(8).toFloat()}
   fun line(text:String,size:Float,bold:Boolean=false){root.addView(TextView(this).apply{this.text=text;textSize=size;setTextColor(Color.WHITE);setPadding(0,dp(7),0,dp(7));if(bold)setTypeface(null,Typeface.BOLD)})}
   if(full){root.gravity=Gravity.CENTER_VERTICAL;line(java.time.ZonedDateTime.now(RadarData.schoolZone).format(java.time.format.DateTimeFormatter.ofPattern("HH:mm")),42f,true)}
   line("캠퍼스레이더",if(full)24f else 16f,true)
   line(if(s.connected)"24시간 이내 ${urgent}개 · 미완료 ${pending.size}개" else "앱에서 포털을 연결해 주세요",if(full)22f else 16f,true)
   if(details){for(i in pending.take(if(full)6 else 2)){line("${RadarData.courseName(this,i)} · ${i.optString("title")}\n${RadarData.remaining(i)}",if(full)17f else 13f)}}
   line("마지막 확인 ${RadarData.stamp(s)}",12f)
   root.addView(Button(this).apply{text="이번 화면에서 닫기";setOnClickListener{hide()}})
   val width=if(full)WindowManager.LayoutParams.MATCH_PARENT else minOf(dp(270),resources.displayMetrics.widthPixels-dp(32))
   val params=WindowManager.LayoutParams(width,if(full)WindowManager.LayoutParams.MATCH_PARENT else WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_SECURE,PixelFormat.TRANSLUCENT)
   params.gravity=if(full)Gravity.CENTER else Gravity.CENTER_VERTICAL or (if(p.getString("position","right")=="left")Gravity.LEFT else Gravity.RIGHT)
   if(!full)params.x=dp(12)
   window.addView(root,params);overlay=root
  }catch(_:Exception){RadarData.log(this,"잠금화면 표시 실패","표시 권한 또는 기기 정책을 확인해 주세요.","app")}
 }
 private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
 override fun onDestroy(){handler.removeCallbacksAndMessages(null);hide();if(registered)unregisterReceiver(receiver);super.onDestroy()}
 companion object{
  fun prefs(c:Context)=c.getSharedPreferences("radar_lock",0)
  fun settings(c:Context):Map<String,Any>{val p=prefs(c);return mapOf("enabled" to p.getBoolean("enabled",false),"allowed" to Settings.canDrawOverlays(c),"mode" to (p.getString("mode","compact")?:"compact"),"position" to (p.getString("position","right")?:"right"),"details" to p.getBoolean("details",false))}
  fun start(c:Context){if(prefs(c).getBoolean("enabled",false)&&Settings.canDrawOverlays(c)){val i=Intent(c,RadarLockService::class.java);c.startForegroundService(i)}}
  fun configure(c:Context,enabled:Boolean,mode:String,position:String,details:Boolean){require(mode in listOf("compact","full"));require(position in listOf("left","right"));if(enabled)require(Settings.canDrawOverlays(c)){"overlay_permission"};prefs(c).edit().putBoolean("enabled",enabled).putString("mode",mode).putString("position",position).putBoolean("details",details).apply();if(enabled)start(c) else c.stopService(Intent(c,RadarLockService::class.java));RadarData.log(c,"잠금화면 설정 변경",if(enabled)"$mode · 과목명 표시 $details" else "사용 안 함","app")}
 }
}

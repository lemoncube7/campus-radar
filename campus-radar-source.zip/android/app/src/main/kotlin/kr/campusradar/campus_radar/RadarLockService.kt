package kr.campusradar.campus_radar

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.*

/** Only lock state and local task data. No node retrieval, gestures or input injection. */
class RadarLockAccessibilityService:AccessibilityService(){
 private val handler=Handler(Looper.getMainLooper())
 private var overlay:View?=null
 private var registered=false
 private var dismissed=false
 private var raisedAt=0L
 private var shown=false
 private var countdownText:TextView?=null
 private var displayKey=""
 private var countdown:TimetableReceiver.Companion.Countdown?=null
 private var countdownChecked=0L
 private val wm by lazy{getSystemService(WindowManager::class.java)}
 private val receiver=object:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){when(i.action){
  Intent.ACTION_SCREEN_ON->{dismissed=false;handler.postDelayed({refresh()},150);handler.postDelayed({refresh()},900)}
  Intent.ACTION_SCREEN_OFF,Intent.ACTION_USER_PRESENT->{dismissed=false;hide()}
 }}}
 private val tick=object:Runnable{override fun run(){refresh();handler.postDelayed(this,1000)}}
 override fun onServiceConnected(){super.onServiceConnected();instance=this
  val f=IntentFilter().apply{addAction(Intent.ACTION_SCREEN_ON);addAction(Intent.ACTION_SCREEN_OFF);addAction(Intent.ACTION_USER_PRESENT)}
  if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED)else registerReceiver(receiver,f)
  registered=true;handler.post(tick);RadarData.log(this,"잠금화면 접근성 연결","화면 내용 조회와 입력 조작을 사용하지 않아요.","app")
 }
 override fun onAccessibilityEvent(event:AccessibilityEvent?){
  // Only window metadata, never text, nodes or input contents.
  if(!getSystemService(KeyguardManager::class.java).isKeyguardLocked){hide();return}
  if(shown && event?.eventType==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && LockWindowPolicy.suppress(event.packageName?.toString(),event.className?.toString(),packageName,RadarLockService.prefs(this).getBoolean("hideOtherWindows",false))){dismissed=true;hide()}
 }
 override fun onInterrupt(){hide()}
 fun refresh(){
  val pref=RadarLockService.prefs(this)
  val locked=getSystemService(KeyguardManager::class.java).isKeyguardLocked
  val awake=getSystemService(PowerManager::class.java).isInteractive
  if(!pref.getBoolean("enabled",false)||!locked||!awake||dismissed){hide();return}
  val nowMillis=SystemClock.elapsedRealtime()
  if(overlay==null||nowMillis-countdownChecked>=10000L){
   countdown=try{TimetableReceiver.activeCountdown(this)}catch(_:Exception){null};countdownChecked=nowMillis
  }
  val after=getSharedPreferences("radar_timetable",0).getInt("countdownAfter",0).coerceIn(0,120)
  val active=countdown?.takeIf{!java.time.Instant.now().isAfter(it.start.plusSeconds(after*60L))}
  val palette=NativeAccentPalette.read(this)
  val nextKey=(active?.let{"${it.id}:${it.start}:${it.start.isAfter(java.time.Instant.now())}"}?:"tasks")+":${palette.primary}:${palette.secondary}"
  if(overlay!=null&&displayKey==nextKey){countdownText?.text=active?.let{ClassTimeLogic.countdownText(it.start,java.time.Instant.now())};return}
  if(overlay!=null)hide()
  displayKey=nextKey
  try{
   val full=pref.getString("mode","compact")=="full";val detail=pref.getBoolean("details",false)
   val snap=RadarData.read(this);val pending=RadarData.pending(snap);val now=java.time.Instant.now()
   val urgent=pending.count{RadarData.instant(it.optString("due"))?.let{d->d.isAfter(now)&&!d.isAfter(now.plusSeconds(86400))}?:false}
   val root=object:LinearLayout(this){
    private var downX=0f;private var downY=0f;private var scrollable=false
    override fun dispatchTouchEvent(e:MotionEvent):Boolean{
     if(e.actionMasked==MotionEvent.ACTION_OUTSIDE){if(pref.getBoolean("dismissOutside",false)){dismissed=true;hide()}else if(pref.getBoolean("preferTop",true)){handler.post{raiseOverlay()}};return false}
     if(e.actionMasked==MotionEvent.ACTION_DOWN){downX=e.rawX;downY=e.rawY;scrollable=(getChildAt(0) as? ScrollView)?.let{it.canScrollVertically(1)||it.canScrollVertically(-1)}?:false}
     val dx=kotlin.math.abs(e.rawX-downX);val dy=kotlin.math.abs(e.rawY-downY)
     // Full mode also dismisses on a vertical swipe, but not when the list can scroll: that drag is a scroll.
     val swiped=dx>dp(80)&&dx>dy*1.3f||full&&!scrollable&&maxOf(dx,dy)>dp(80)
     if(pref.getBoolean("dismissSwipe",true) && e.actionMasked==MotionEvent.ACTION_UP && swiped){
      val cancel=MotionEvent.obtain(e);cancel.action=MotionEvent.ACTION_CANCEL;super.dispatchTouchEvent(cancel);cancel.recycle();dismissed=true;hide();return true
     }
     return super.dispatchTouchEvent(e)
    }
   }.apply{orientation=LinearLayout.VERTICAL;isClickable=true;setPadding(dp(20),dp(18),dp(20),dp(18));background=android.graphics.drawable.GradientDrawable().apply{setColor(Color.argb(if(full)255 else pref.getInt("opacity",80).coerceIn(0,100)*255/100,20,34,37));cornerRadius=if(full)0f else dp(20).toFloat()}}
   val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;if(full)gravity=Gravity.CENTER_VERTICAL}
   val scroll=ScrollView(this).apply{addView(content)};root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
   val accent=palette
   fun line(text:String,size:Float,bold:Boolean=false):TextView{val view=TextView(this).apply{this.text=text;textSize=size*WidgetText.scale(this@RadarLockAccessibilityService,"lock");setTextColor(if(bold)NativeAccentPalette.onDark(accent.secondary) else Color.WHITE);setPadding(0,dp(6),0,dp(6));if(bold)setTypeface(null,Typeface.BOLD)};content.addView(view);return view}
   if(full){line(java.time.ZonedDateTime.now(RadarData.schoolZone).format(java.time.format.DateTimeFormatter.ofPattern("HH:mm")),40f,true);line("스와이프해서 닫기",14f)}
   if(full)line("캠퍼스레이더",24f,true)
   if(active!=null){
    line(if(active.start.isAfter(java.time.Instant.now()))"수업 시작까지" else "수업 시작 후",if(full)22f else 15f,true)
    countdownText=line(ClassTimeLogic.countdownText(active.start,java.time.Instant.now()),if(full)40f else 28f,true)
    line("${active.start.atZone(RadarData.schoolZone).toLocalTime()} 시작",if(full)20f else 14f)
    if(detail){line(active.course,if(full)24f else 17f,true);if(active.room.isNotBlank())line(active.room,if(full)18f else 14f)}
   }else{
    val next=if(snap.connected)CompactStudyWidget.next(this)else null
    if(!full&&next!=null){
     val date=next.second.toLocalDate();val today=java.time.ZonedDateTime.now(RadarData.schoolZone).toLocalDate()
     val isCanc=TimetableCancellations.cancelled(this,next.first,date);val cSuffix=if(isCanc)" (휴강으로 인식됨)" else "";line(if(date==today)"다음 수업 · 오늘$cSuffix"else if(date==today.plusDays(1))"다음 수업 · 내일$cSuffix"else "다음 수업 · ${date.monthValue}/${date.dayOfMonth}$cSuffix",12f)
     line("%02d:%02d".format(next.second.hour,next.second.minute),32f,true)
     if(detail){line(RadarData.courseName(this,next.first)+cSuffix,17f,true);if(next.first.optString("room").isNotBlank())line(next.first.optString("room"),12f)}
    }
    line(if(snap.connected)(if(urgent==0)"급한 마감 없음"else "24시간 내 마감 ${urgent}개")+" · 미완료 ${pending.size}개"else "앱에서 포털을 연결해 주세요",if(full)22f else 12f,full)
    if(detail)for(i in pending.take(if(full)5 else 2))line("${RadarData.courseName(this,i)} · ${i.optString("title")}\n${RadarData.remaining(i)}",if(full)17f else 13f)
   }
   if(full)line("마지막 확인 ${RadarData.stamp(snap)}",12f)
   if(full)root.addView(Button(this).apply{text="닫고 잠금화면 보기";setOnClickListener{dismissed=true;hide()}})
   val screen=resources.displayMetrics
   val width=minOf(dp(pref.getInt("width",270).coerceIn(180,360)),screen.widthPixels-dp(24))
   val height=minOf(dp(pref.getInt("height",380).coerceIn(180,640)),screen.heightPixels-dp(96))
   val params=WindowManager.LayoutParams(if(full)-1 else width,if(full)-1 else height,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or (if(full)0 else WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH) or (if(detail)WindowManager.LayoutParams.FLAG_SECURE else 0),PixelFormat.TRANSLUCENT)
   params.setTitle("CampusRadarLockCard")
   params.gravity=if(full)Gravity.CENTER else Gravity.TOP or Gravity.LEFT
   if(!full){params.x=dp(12)+(maxOf(0,screen.widthPixels-width-dp(24))*pref.getInt("x",if(pref.getString("position","right")=="left")0 else 100)/100);params.y=dp(24)+(maxOf(0,screen.heightPixels-height-dp(96))*pref.getInt("y",50)/100)}
   wm.addView(root,params);overlay=root
   if(!shown){shown=true;RadarData.log(this,"잠금화면 카드 표시",if(full)"전체 카드" else "작은 카드","app")}
  }catch(e:Exception){RadarData.logOnce(this,"lock-card","잠금화면 카드 표시 실패","카드를 표시하지 못했어요.",e)}
 }
 // Re-add only in response to an outside user touch, not a window-event loop.
 // Android still decides ordering between independent accessibility services.
 private fun raiseOverlay(){
  val view=overlay?:return
  if(SystemClock.elapsedRealtime()-raisedAt<1500L)return
  raisedAt=SystemClock.elapsedRealtime()
  try{val params=view.layoutParams as WindowManager.LayoutParams;wm.removeViewImmediate(view);wm.addView(view,params)}catch(_:Exception){hide()}
 }
 fun requestRefresh(){handler.post{countdownChecked=0;refresh()}}
 fun reset(){dismissed=false;countdownChecked=0;hide();refresh()}
 private fun hide(){overlay?.let{try{wm.removeView(it)}catch(_:Exception){}};overlay=null;countdownText=null;displayKey="";shown=false}
 private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
 override fun onDestroy(){handler.removeCallbacksAndMessages(null);hide();if(registered)unregisterReceiver(receiver);instance=null;super.onDestroy()}
 companion object{@Volatile var instance:RadarLockAccessibilityService?=null}
}
object RadarLockService{
 fun prefs(c:Context)=c.getSharedPreferences("radar_lock",0)
 fun allowed(c:Context):Boolean{val target=ComponentName(c,RadarLockAccessibilityService::class.java).flattenToString();return Settings.Secure.getString(c.contentResolver,Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)?.split(':')?.any{ComponentName.unflattenFromString(it)?.flattenToString()==target}==true}
 fun settings(c:Context):Map<String,Any>{val p=prefs(c);return mapOf("enabled" to p.getBoolean("enabled",false),"allowed" to allowed(c),"connected" to (RadarLockAccessibilityService.instance!=null),"mode" to(p.getString("mode","compact")?:"compact"),"position" to(p.getString("position","right")?:"right"),"details" to p.getBoolean("details",false),"dismissOutside" to p.getBoolean("dismissOutside",false),"dismissSwipe" to p.getBoolean("dismissSwipe",true),"hideOtherWindows" to p.getBoolean("hideOtherWindows",false),"preferTop" to p.getBoolean("preferTop",true),"opacity" to p.getInt("opacity",80),"width" to p.getInt("width",270),"height" to p.getInt("height",380),"x" to p.getInt("x",if(p.getString("position","right")=="left")0 else 100),"y" to p.getInt("y",50))}
 fun start(c:Context){RadarLockAccessibilityService.instance?.reset()}
 fun configure(c:Context,enabled:Boolean,mode:String,position:String,details:Boolean,width:Int=270,height:Int=380,x:Int=100,y:Int=50,opacity:Int=80,dismissOutside:Boolean=false,dismissSwipe:Boolean=true,hideOtherWindows:Boolean=false,preferTop:Boolean=true){require(mode in listOf("compact","full"));require(position in listOf("left","right"));if(enabled)require(allowed(c)){"접근성 설정에서 캠퍼스레이더 잠금화면을 켜 주세요."};prefs(c).edit().putBoolean("dismissOutside",dismissOutside).putBoolean("dismissSwipe",dismissSwipe).putBoolean("hideOtherWindows",hideOtherWindows).putBoolean("preferTop",preferTop).putBoolean("enabled",enabled).putString("mode",mode).putString("position",position).putBoolean("details",details).putInt("opacity",opacity.coerceIn(0,100)).putInt("width",width.coerceIn(180,360)).putInt("height",height.coerceIn(180,640)).putInt("x",x.coerceIn(0,100)).putInt("y",y.coerceIn(0,100)).apply();RadarLockAccessibilityService.instance?.reset();RadarData.log(c,"잠금화면 설정 변경",if(enabled)"$mode · 접근성 오버레이" else "사용 안 함","app")}
}

package kr.campusradar.campus_radar

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.*

/** Only lock state and local task data. No node retrieval, gestures or input injection. */
class RadarLockAccessibilityService:AccessibilityService(){
 private val handler=Handler(Looper.getMainLooper())
 private var overlay:View?=null
 private var registered=false
 private var dismissed=false
 private var shown=false
 private val wm by lazy{getSystemService(WindowManager::class.java)}
 private val receiver=object:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){when(i.action){
  Intent.ACTION_SCREEN_ON->{dismissed=false;handler.postDelayed({refresh()},150);handler.postDelayed({refresh()},900)}
  Intent.ACTION_SCREEN_OFF,Intent.ACTION_USER_PRESENT->{dismissed=false;hide()}
 }}}
 private val tick=object:Runnable{override fun run(){refresh();handler.postDelayed(this,1500)}}
 override fun onServiceConnected(){super.onServiceConnected();instance=this
  val f=IntentFilter().apply{addAction(Intent.ACTION_SCREEN_ON);addAction(Intent.ACTION_SCREEN_OFF);addAction(Intent.ACTION_USER_PRESENT)}
  if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED)else registerReceiver(receiver,f)
  registered=true;handler.post(tick);RadarData.log(this,"잠금화면 접근성 연결","화면 내용 조회와 입력 조작을 사용하지 않습니다.","app")
 }
 override fun onAccessibilityEvent(event:AccessibilityEvent?){
  // Event contents are deliberately not inspected or retained.
  if(!getSystemService(KeyguardManager::class.java).isKeyguardLocked)hide()
 }
 override fun onInterrupt(){hide()}
 fun refresh(){
  val pref=RadarLockService.prefs(this)
  val locked=getSystemService(KeyguardManager::class.java).isKeyguardLocked
  val awake=getSystemService(PowerManager::class.java).isInteractive
  if(!pref.getBoolean("enabled",false)||!locked||!awake||dismissed){hide();return}
  if(overlay!=null)return
  try{
   val full=pref.getString("mode","compact")=="full";val detail=pref.getBoolean("details",false)
   val snap=RadarData.read(this);val pending=RadarData.pending(snap);val now=java.time.Instant.now()
   val urgent=pending.count{RadarData.instant(it.optString("due"))?.let{d->d.isAfter(now)&&!d.isAfter(now.plusSeconds(86400))}?:false}
   val root=object:LinearLayout(this){
    private var downX=0f;private var downY=0f
    override fun dispatchTouchEvent(e:MotionEvent):Boolean{
     if(full&&e.actionMasked==MotionEvent.ACTION_DOWN){downX=e.rawX;downY=e.rawY}
     if(full&&e.actionMasked==MotionEvent.ACTION_UP&&maxOf(kotlin.math.abs(e.rawX-downX),kotlin.math.abs(e.rawY-downY))>dp(80)){
      val cancel=MotionEvent.obtain(e);cancel.action=MotionEvent.ACTION_CANCEL;super.dispatchTouchEvent(cancel);cancel.recycle();dismissed=true;hide();return true
     }
     return super.dispatchTouchEvent(e)
    }
   }.apply{orientation=LinearLayout.VERTICAL;isClickable=true;setPadding(dp(18),dp(18),dp(18),dp(18));setBackgroundColor(Color.rgb(22,30,55))}
   val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;if(full)gravity=Gravity.CENTER_VERTICAL}
   val scroll=ScrollView(this).apply{addView(content)};root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
   fun line(text:String,size:Float,bold:Boolean=false){content.addView(TextView(this).apply{this.text=text;textSize=size;setTextColor(Color.WHITE);setPadding(0,dp(6),0,dp(6));if(bold)setTypeface(null,Typeface.BOLD)})}
   if(full){line(java.time.ZonedDateTime.now(RadarData.schoolZone).format(java.time.format.DateTimeFormatter.ofPattern("HH:mm")),40f,true);line("스와이프해서 닫기",14f)}
   line("캠퍼스레이더",if(full)24f else 16f,true)
   line(if(snap.connected)"24시간 이내 ${urgent}개 · 미완료 ${pending.size}개" else "앱에서 포털을 연결해 주세요",if(full)22f else 15f,true)
   if(detail)for(i in pending.take(if(full)5 else 2))line("${RadarData.courseName(this,i)} · ${i.optString("title")}\n${RadarData.remaining(i)}",if(full)17f else 13f)
   line("마지막 확인 ${RadarData.stamp(snap)}",12f)
   root.addView(Button(this).apply{text="닫고 잠금화면 보기";setOnClickListener{dismissed=true;hide()}})
   val screen=resources.displayMetrics
   val width=minOf(dp(pref.getInt("width",270).coerceIn(180,360)),screen.widthPixels-dp(24))
   val height=minOf(dp(pref.getInt("height",380).coerceIn(180,640)),screen.heightPixels-dp(96))
   val params=WindowManager.LayoutParams(if(full)-1 else width,if(full)-1 else height,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or (if(detail)WindowManager.LayoutParams.FLAG_SECURE else 0),PixelFormat.TRANSLUCENT)
   params.setTitle("CampusRadarLockCard")
   params.gravity=if(full)Gravity.CENTER else Gravity.TOP or Gravity.LEFT
   if(!full){params.x=dp(12)+(maxOf(0,screen.widthPixels-width-dp(24))*pref.getInt("x",if(pref.getString("position","right")=="left")0 else 100)/100);params.y=dp(24)+(maxOf(0,screen.heightPixels-height-dp(96))*pref.getInt("y",50)/100)}
   wm.addView(root,params);overlay=root
   if(!shown){shown=true;RadarData.log(this,"잠금화면 카드 표시",if(full)"전체 카드" else "작은 카드","app")}
  }catch(e:Exception){RadarData.log(this,"잠금화면 카드 표시 실패",e.javaClass.simpleName,"app")}
 }
 fun reset(){dismissed=false;hide();refresh()}
 private fun hide(){overlay?.let{try{wm.removeView(it)}catch(_:Exception){}};overlay=null;shown=false}
 private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
 override fun onDestroy(){handler.removeCallbacksAndMessages(null);hide();if(registered)unregisterReceiver(receiver);instance=null;super.onDestroy()}
 companion object{@Volatile var instance:RadarLockAccessibilityService?=null}
}
object RadarLockService{
 fun prefs(c:Context)=c.getSharedPreferences("radar_lock",0)
 fun allowed(c:Context):Boolean{val target=ComponentName(c,RadarLockAccessibilityService::class.java).flattenToString();return Settings.Secure.getString(c.contentResolver,Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)?.split(':')?.any{ComponentName.unflattenFromString(it)?.flattenToString()==target}==true}
 fun settings(c:Context):Map<String,Any>{val p=prefs(c);return mapOf("enabled" to p.getBoolean("enabled",false),"allowed" to allowed(c),"connected" to (RadarLockAccessibilityService.instance!=null),"mode" to(p.getString("mode","compact")?:"compact"),"position" to(p.getString("position","right")?:"right"),"details" to p.getBoolean("details",false),"width" to p.getInt("width",270),"height" to p.getInt("height",380),"x" to p.getInt("x",if(p.getString("position","right")=="left")0 else 100),"y" to p.getInt("y",50))}
 fun start(c:Context){RadarLockAccessibilityService.instance?.reset()}
 fun configure(c:Context,enabled:Boolean,mode:String,position:String,details:Boolean,width:Int=270,height:Int=380,x:Int=100,y:Int=50){require(mode in listOf("compact","full"));require(position in listOf("left","right"));if(enabled)require(allowed(c)){"접근성 설정에서 캠퍼스레이더 잠금화면을 켜 주세요."};prefs(c).edit().putBoolean("enabled",enabled).putString("mode",mode).putString("position",position).putBoolean("details",details).putInt("width",width.coerceIn(180,360)).putInt("height",height.coerceIn(180,640)).putInt("x",x.coerceIn(0,100)).putInt("y",y.coerceIn(0,100)).apply();RadarLockAccessibilityService.instance?.reset();RadarData.log(c,"잠금화면 설정 변경",if(enabled)"$mode · 접근성 오버레이" else "사용 안 함","app")}
}

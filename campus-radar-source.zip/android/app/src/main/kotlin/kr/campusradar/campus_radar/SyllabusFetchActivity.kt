package kr.campusradar.campus_radar

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.*
import android.widget.*
import org.json.JSONObject
import org.json.JSONTokener

/** Renders the exact CNU plan link. No portal credentials are given to this page. */
class SyllabusFetchActivity:Activity(){
 private lateinit var web:WebView
 private val handler=Handler(Looper.getMainLooper())
 private var finished=false
 private var previous=""
 private var stable=0
 private var capture=true
 private var retryCount=0
 private var samples=0
 private var lastFields=0
 private var lastLength=0
 private var courseMatched=false
 private val started=android.os.SystemClock.elapsedRealtime()
 private fun record(message:String){RadarData.log(this,"강의계획서 로딩",message,"sync")}
 private fun transientFailure(message:String){
  if(!capture){Toast.makeText(this,message,Toast.LENGTH_LONG).show();return}
  if(retryCount++==0){previous="";stable=0;handler.removeCallbacks(poll);record("일시 오류 · 1회 재시도");handler.postDelayed({if(!finished&&!isFinishing)web.reload()},1000)}else fail(message)
 }
 private fun trusted(url:String):Boolean{val u=Uri.parse(url);return u.scheme=="https" && u.host in setOf("cnuit.cnu.ac.kr","tlsn.cnu.ac.kr") && u.userInfo==null}
 override fun onCreate(state:Bundle?){super.onCreate(state)
  val url=intent.getStringExtra("url")?:"";capture=intent.getBooleanExtra("capture",true)
  if(!trusted(url)){finish();return}
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  root.addView(Button(this).apply{text=if(capture)"계획서 가져오는 중 · 취소" else "앱으로 돌아가기";setOnClickListener{finish()}})
  web=WebView(this);root.addView(web,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
  web.settings.javaScriptEnabled=true;web.settings.domStorageEnabled=true
  web.settings.allowFileAccess=false;web.settings.allowContentAccess=false;web.settings.mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW
  web.webViewClient=object:WebViewClient(){
   override fun shouldOverrideUrlLoading(view:WebView,request:WebResourceRequest)=!trusted(request.url.toString())
   override fun shouldInterceptRequest(view:WebView,request:WebResourceRequest):WebResourceResponse?{return if(trusted(request.url.toString()))null else WebResourceResponse("text/plain","UTF-8",java.io.ByteArrayInputStream(byteArrayOf()))}
   override fun onPageFinished(view:WebView,url:String){if(capture&&trusted(url)){handler.removeCallbacks(poll);handler.postDelayed(poll,1200)}}
   override fun onReceivedError(view:WebView,request:WebResourceRequest,error:WebResourceError){if(request.isForMainFrame)transientFailure("계획서 페이지 연결 실패 (오류 ${error.errorCode}). 인터넷 연결 또는 학교 서버 상태를 확인해 주세요.")}
   override fun onReceivedHttpError(view:WebView,request:WebResourceRequest,response:WebResourceResponse){if(request.isForMainFrame){if(response.statusCode>=500||response.statusCode==408||response.statusCode==429)transientFailure("계획서 서버 응답 오류 (${response.statusCode})")else fail("계획서 서버가 요청을 거절했습니다 (${response.statusCode}).")}}
  }
  record("페이지 열기 시작")
  web.loadUrl(url)
  if(capture)handler.postDelayed({fail(if(samples==0)"계획서 페이지 로딩 시간이 초과됐습니다." else if(lastLength<400||lastFields<8)"페이지는 열렸지만 계획서 본문이 준비되지 않았습니다. 잠시 후 다시 시도해 주세요." else if(!courseMatched)"불러온 계획서의 과목명이 일치하지 않습니다. 원문을 확인해 주세요." else "계획서 본문이 계속 변경되어 저장하지 않았습니다. 잠시 후 다시 시도해 주세요.")},60000)
 }
 private val poll=object:Runnable{override fun run(){if(finished||isFinishing)return
  web.evaluateJavascript(EXTRACT){raw->try{
   val decoded=JSONTokener(raw).nextValue();val value=if(decoded is String)JSONObject(decoded)else JSONObject()
   val text=value.optString("text").take(120000);val fields=value.optInt("fields")
   val normalized=text.replace(Regex("\\s+"),"");val expected=(intent.getStringExtra("course")?:"").replace(Regex("\\s+"),"")
   samples++;lastFields=fields;lastLength=text.length;courseMatched=expected.isEmpty()||normalized.contains(expected)
   val valid=fields>=8 && text.length>=400 && normalized.contains("교과목") && (expected.isEmpty() || normalized.contains(expected))
   stable=if(valid&&text==previous)stable+1 else 0;previous=text
   if(valid&&stable>=2){record("본문 저장 준비 완료 · ${(android.os.SystemClock.elapsedRealtime()-started)/1000}초 · 재시도 ${retryCount}회");finished=true;handler.removeCallbacksAndMessages(null);setResult(RESULT_OK,Intent().putExtra("text",text).putExtra("structure",value.optJSONArray("tables")?.toString()?:"[]").putExtra("sourceUrl",intent.getStringExtra("url")));finish()}else handler.postDelayed(this,1000)
  }catch(_:Exception){handler.postDelayed(this,1000)}}
 }}
 private fun fail(message:String){if(finished||isFinishing)return;finished=true;record("실패 · $message · ${(android.os.SystemClock.elapsedRealtime()-started)/1000}초 · 필드 $lastFields · 본문 ${lastLength}자");setResult(RESULT_CANCELED,Intent().putExtra("error",message));finish()}
 override fun onDestroy(){handler.removeCallbacksAndMessages(null);if(::web.isInitialized){web.stopLoading();web.destroy()};super.onDestroy()}
 companion object{
  private val EXTRACT="""(function(){var lines=[],fields=0;function walk(n){if(n.nodeType===3){var t=n.textContent.trim();if(t)lines.push(t);return;}if(n.nodeType!==1)return;var tag=n.tagName;if(['SCRIPT','STYLE','NOSCRIPT'].indexOf(tag)>=0)return;var s=getComputedStyle(n);if(s.display==='none'||s.visibility==='hidden')return;if(n.getAttribute('role')==='textbox'&&!n.querySelector('input,textarea')){var rv=n.getAttribute('aria-valuetext')||n.innerText||'';if(rv.trim()){lines.push(rv.trim());fields++;}return;}if(tag==='INPUT'||tag==='TEXTAREA'){if(['password','hidden','checkbox','radio','button','submit'].indexOf(n.type)>=0)return;var v=n.value||'';if(v.trim()){lines.push(v.trim());fields++;}return;}for(var c=n.firstChild;c;c=c.nextSibling)walk(c);}walk(document.body);var total=0;var tables=Array.from(document.querySelectorAll('table')).filter(function(t){return !t.parentElement.closest('table')&&getComputedStyle(t).display!=='none';}).slice(0,50).map(function(t){return Array.from(t.rows).slice(0,100).map(function(r){return Array.from(r.cells).slice(0,20).map(function(c){var clone=c.cloneNode(true);var from=c.querySelectorAll('input,textarea,select'),to=clone.querySelectorAll('input,textarea,select');for(var i=0;i<from.length;i++){var el=from[i];var v=['password','hidden','checkbox','radio','button','submit'].indexOf(el.type)>=0?'':el.value;to[i].replaceWith(document.createTextNode(v||''));}clone.querySelectorAll('script,style,noscript').forEach(function(x){x.remove();});var v=(clone.textContent||'').trim().slice(0,6000);total+=v.length;return total<=120000?v:'';});}).filter(function(r){return r.some(function(c){return c.length>0;});});}).filter(function(t){return t.length>0;});if(!tables.length){var fragments=[],budget=0;document.querySelectorAll('body *').forEach(function(el){if(fragments.length>=1200||['SCRIPT','STYLE','NOSCRIPT','OPTION'].indexOf(el.tagName)>=0)return;var input=['INPUT','TEXTAREA','SELECT'].indexOf(el.tagName)>=0||el.getAttribute('role')==='textbox';if(!input&&el.children.length)return;if(input&&['password','hidden','checkbox','radio','button','submit'].indexOf(el.type)>=0)return;var r=el.getBoundingClientRect(),cs=getComputedStyle(el);if(r.width<1||r.height<1||cs.visibility==='hidden'||cs.display==='none')return;var value=input?(el.value||el.getAttribute('aria-valuetext')||el.innerText||''):(el.innerText||el.textContent||'');value=value.trim().slice(0,6000);if(value&&budget<120000){value=value.slice(0,120000-budget);budget+=value.length;fragments.push({y:r.top,x:r.left,value:value});}});fragments.sort(function(a,b){return a.y-b.y||a.x-b.x;});var rows=[],group=[],top=null;function flush(){if(!group.length)return;group.sort(function(a,b){return a.x-b.x;});rows.push(group.slice(0,20).map(function(v){return v.value;}));group=[];}fragments.forEach(function(f){if(top===null||Math.abs(f.y-top)>12){flush();top=f.y;}group.push(f);});flush();for(var i=0;i<rows.length;i+=100)tables.push(rows.slice(i,i+100));tables=tables.slice(0,12);}return JSON.stringify({text:lines.join('\n'),fields:fields,tables:tables});})();"""
 }
}

package kr.campusradar.campus_radar

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.*
import android.widget.*
import org.json.JSONObject
import org.json.JSONTokener

/** Renders the exact CNU plan link. No portal credentials are given to this page. */
class SyllabusFetchActivity:Activity(){
 private lateinit var web:WebView
 private val handler=Handler(Looper.getMainLooper())
 private var finished=false
 private var previous=""
 private var stable=0
 private var capture=true
 private var retryCount=0
 private var samples=0
 private var lastFields=0
 private var lastLength=0
 private var courseMatched=false
 private val started=android.os.SystemClock.elapsedRealtime()
 private fun record(message:String){RadarData.log(this,"강의계획서 로딩",message,"sync")}
 private fun transientFailure(message:String){
  if(!capture){Toast.makeText(this,message,Toast.LENGTH_LONG).show();return}
  if(retryCount++==0){previous="";stable=0;handler.removeCallbacks(poll);record("일시 오류 · 1회 재시도");handler.postDelayed({if(!finished&&!isFinishing)web.reload()},1000)}else fail(message)
 }
 private fun trusted(url:String):Boolean{val u=Uri.parse(url);return u.scheme=="https" && u.host in setOf("cnuit.cnu.ac.kr","tlsn.cnu.ac.kr") && u.userInfo==null}
 override fun onCreate(state:Bundle?){super.onCreate(state)
  val url=intent.getStringExtra("url")?:"";capture=intent.getBooleanExtra("capture",true)
  if(!trusted(url)){finish();return}
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  root.addView(Button(this).apply{text=if(capture)"계획서 가져오는 중 · 취소" else "앱으로 돌아가기";setOnClickListener{finish()}})
  web=WebView(this);root.addView(web,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
  web.settings.javaScriptEnabled=true;web.settings.domStorageEnabled=true
  web.settings.allowFileAccess=false;web.settings.allowContentAccess=false;web.settings.mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW
  web.webViewClient=object:WebViewClient(){
   override fun shouldOverrideUrlLoading(view:WebView,request:WebResourceRequest)=!trusted(request.url.toString())
   override fun shouldInterceptRequest(view:WebView,request:WebResourceRequest):WebResourceResponse?{return if(trusted(request.url.toString()))null else WebResourceResponse("text/plain","UTF-8",java.io.ByteArrayInputStream(byteArrayOf()))}
   override fun onPageFinished(view:WebView,url:String){if(capture&&trusted(url)){handler.removeCallbacks(poll);handler.postDelayed(poll,1200)}}
   override fun onReceivedError(view:WebView,request:WebResourceRequest,error:WebResourceError){if(request.isForMainFrame)transientFailure("계획서 페이지 연결 실패 (오류 ${error.errorCode}). 인터넷 연결 또는 학교 서버 상태를 확인해 주세요.")}
   override fun onReceivedHttpError(view:WebView,request:WebResourceRequest,response:WebResourceResponse){if(request.isForMainFrame){if(response.statusCode>=500||response.statusCode==408||response.statusCode==429)transientFailure("계획서 서버 응답 오류 (${response.statusCode})")else fail("계획서 서버가 요청을 거절했습니다 (${response.statusCode}).")}}
  }
  record("페이지 열기 시작")
  web.loadUrl(url)
  if(capture)handler.postDelayed({fail(if(samples==0)"계획서 페이지 로딩 시간이 초과됐습니다." else if(lastLength<400||lastFields<8)"페이지는 열렸지만 계획서 본문이 준비되지 않았습니다. 잠시 후 다시 시도해 주세요." else if(!courseMatched)"불러온 계획서의 과목명이 일치하지 않습니다. 원문을 확인해 주세요." else "계획서 본문이 계속 변경되어 저장하지 않았습니다. 잠시 후 다시 시도해 주세요.")},60000)
 }
 private val poll=object:Runnable{override fun run(){if(finished||isFinishing)return
  web.evaluateJavascript(EXTRACT){raw->try{
   val decoded=JSONTokener(raw).nextValue();val value=if(decoded is String)JSONObject(decoded)else JSONObject()
   val text=value.optString("text").take(120000);val fields=value.optInt("fields")
   val normalized=text.replace(Regex("\\s+"),"");val expected=(intent.getStringExtra("course")?:"").replace(Regex("\\s+"),"")
   samples++;lastFields=fields;lastLength=text.length;courseMatched=expected.isEmpty()||normalized.contains(expected)
   val valid=fields>=8 && text.length>=400 && normalized.contains("교과목") && (expected.isEmpty() || normalized.contains(expected))
   stable=if(valid&&text==previous)stable+1 else 0;previous=text
   if(valid&&stable>=2){record("본문 저장 준비 완료 · ${(android.os.SystemClock.elapsedRealtime()-started)/1000}초 · 재시도 ${retryCount}회");finished=true;handler.removeCallbacksAndMessages(null);setResult(RESULT_OK,Intent().putExtra("text",text).putExtra("sourceUrl",intent.getStringExtra("url")));finish()}else handler.postDelayed(this,1000)
  }catch(_:Exception){handler.postDelayed(this,1000)}}
 }}
 private fun fail(message:String){if(finished||isFinishing)return;finished=true;record("실패 · $message · ${(android.os.SystemClock.elapsedRealtime()-started)/1000}초 · 필드 $lastFields · 본문 ${lastLength}자");setResult(RESULT_CANCELED,Intent().putExtra("error",message));finish()}
 override fun onDestroy(){handler.removeCallbacksAndMessages(null);if(::web.isInitialized){web.stopLoading();web.destroy()};super.onDestroy()}
 companion object{
  private val EXTRACT="""(function(){var lines=[],fields=0;function walk(n){if(n.nodeType===3){var t=n.textContent.trim();if(t)lines.push(t);return;}if(n.nodeType!==1)return;var tag=n.tagName;if(['SCRIPT','STYLE','NOSCRIPT'].indexOf(tag)>=0)return;var s=getComputedStyle(n);if(s.display==='none'||s.visibility==='hidden')return;if(n.getAttribute('role')==='textbox'&&!n.querySelector('input,textarea')){var rv=n.getAttribute('aria-valuetext')||n.innerText||'';if(rv.trim()){lines.push(rv.trim());fields++;}return;}if(tag==='INPUT'||tag==='TEXTAREA'){if(['password','hidden','checkbox','radio','button','submit'].indexOf(n.type)>=0)return;var v=n.value||'';if(v.trim()){lines.push(v.trim());fields++;}return;}for(var c=n.firstChild;c;c=c.nextSibling)walk(c);}walk(document.body);return JSON.stringify({text:lines.join('\n'),fields:fields});})();"""
 }
}

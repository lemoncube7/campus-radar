package kr.campusradar.campus_radar
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

object TimetableCancellations {
 fun read(c:Context):List<JSONObject>{
  val file=c.getDatabasePath("campus.db");if(!file.exists())return emptyList()
  return SQLiteDatabase.openDatabase(file.path,null,SQLiteDatabase.OPEN_READONLY).use{db->
   db.rawQuery("SELECT value FROM meta WHERE id='timetableCancellations'",null).use{cursor->
    if(!cursor.moveToFirst())emptyList() else try{val a=JSONArray(cursor.getString(0));(0 until a.length()).map{a.getJSONObject(it)}}catch(_:Exception){emptyList()}
   }
  }
 }
 fun dates(c:Context,row:JSONObject):Set<String> = read(c).filter{it.optString("slotId")==row.optString("id")}.map{it.optString("date")}.toSet()
 fun cancelled(c:Context,row:JSONObject,date:LocalDate)=dates(c,row).contains(date.toString())
 fun week(c:Context,rows:List<JSONObject>,today:LocalDate):List<JSONObject>{
  val monday=today.minusDays((today.dayOfWeek.value-1).toLong());val cancellations=read(c)
  return rows.filter{row->val date=monday.plusDays((row.optInt("weekday")-1).toLong()).toString()
   cancellations.none{it.optString("slotId")==row.optString("id")&&it.optString("date")==date}}
 }
}

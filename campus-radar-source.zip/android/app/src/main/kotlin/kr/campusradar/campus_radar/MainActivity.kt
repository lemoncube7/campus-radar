package kr.campusradar.campus_radar
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.webkit.CookieManager
import androidx.core.content.FileProvider
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import org.json.JSONObject
import java.io.File
import android.app.ActivityManager
import android.net.ConnectivityManager
import android.os.PowerManager
import androidx.work.WorkManager
import androidx.core.content.ContextCompat
class MainActivity : FlutterActivity() {
 private var calendarPermissionResult:MethodChannel.Result? = null
 override fun onRequestPermissionsResult(code:Int,permissions:Array<out String>,results:IntArray){
  super.onRequestPermissionsResult(code,permissions,results)
  if(code==804){calendarPermissionResult?.success(RadarCalendar.allowed(this));calendarPermissionResult=null}
 }
 private var nativeChannel:MethodChannel? = null
 override fun onNewIntent(intent:Intent){super.onNewIntent(intent);setIntent(intent);intent.getStringExtra("radarTarget")?.let{target->nativeChannel?.invokeMethod("openTarget",target);intent.removeExtra("radarTarget")}}

 override fun configureFlutterEngine(engine: FlutterEngine) {
  super.configureFlutterEngine(engine)
  nativeChannel=MethodChannel(engine.dartExecutor.binaryMessenger,"campus_radar/native")
  nativeChannel!!.setMethodCallHandler { call,result ->
   try { when(call.method) {
    "openExternalUrl" -> {
     val url=call.argument<String>("url")?:""
     require(url in setOf("https://aistudio.google.com/api-keys","https://aistudio.google.com/rate-limit"))
     startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)));result.success(null)
    }
    "calendarPermission" -> {
     if(RadarCalendar.allowed(this))result.success(true)
     else if(calendarPermissionResult!=null)result.error("calendar_busy","권한 요청 중입니다.",null)
     else {calendarPermissionResult=result;requestPermissions(arrayOf(android.Manifest.permission.READ_CALENDAR,android.Manifest.permission.WRITE_CALENDAR),804)}
    }
    "calendarSettings" -> result.success(RadarCalendar.settings(this))
    "calendarUnlink" -> {RadarCalendar.unlink(this);result.success(null)}
    "calendarList", "calendarConfigure", "calendarWrite", "calendarSync" -> {
     Thread {
      try {
       val answer:Any?=when(call.method){
        "calendarList" -> RadarCalendar.calendars(this)
        "calendarConfigure" -> {RadarCalendar.configure(this,call.argument<Number>("calendarId")!!.toLong(),call.argument<Boolean>("auto")?:false);null}
        "calendarSync" -> {RadarCalendar.sync(this);null}
        else -> RadarCalendar.write(this,call.argument<String>("key")!!,call.argument<String>("title")!!,call.argument<Number>("start")!!.toLong(),call.argument<Number>("end")!!.toLong(),call.argument<Boolean>("allDay")?:false,call.argument<String>("description")?:"")
       }
       runOnUiThread{result.success(answer)}
      }catch(e:Exception){runOnUiThread{result.error("calendar",e.message?:"캘린더 처리 실패",null)}}
     }.start()
    }
    "takeLaunchTarget" -> {val target=intent.getStringExtra("radarTarget");intent.removeExtra("radarTarget");result.success(target)}
    "refreshWidget" -> {RadarWidget.updateAll(applicationContext);Thread{RadarCalendar.sync(applicationContext)}.start();result.success(null)}
    "dailySettings" -> result.success(DailySummaryReceiver.settings(applicationContext))
    "setDailySettings" -> {DailySummaryReceiver.configure(applicationContext,call.argument<Boolean>("enabled")?:false,call.argument<Int>("hour")?:18,call.argument<Int>("minute")?:0);result.success(null)}
    "testDailySummary" -> {DailySummaryReceiver.send(applicationContext);result.success(null)}

    "openAppSettings" -> {startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:$packageName")));result.success(null)}
    "openPowerSettings" -> {startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS));result.success(null)}
    "openBatterySettings" -> {startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));result.success(null)}
    "batteryStatus" -> {
     val power=getSystemService(PowerManager::class.java)
     val activity=getSystemService(ActivityManager::class.java)
     result.success(mapOf("powerSave" to power.isPowerSaveMode,"batteryExempt" to power.isIgnoringBatteryOptimizations(packageName),"backgroundRestricted" to (if(Build.VERSION.SDK_INT>=28)activity.isBackgroundRestricted else false)))
    }
    "versionInfo" -> {
     val p=packageManager.getPackageInfo(packageName,0)
     result.success(mapOf("name" to p.versionName,"code" to (if(Build.VERSION.SDK_INT>=28)p.longVersionCode else p.versionCode.toLong()),"firstInstallTime" to p.firstInstallTime,"lastUpdateTime" to p.lastUpdateTime))
    }
    "backgroundStatus" -> {
     val future=WorkManager.getInstance(applicationContext).getWorkInfosForUniqueWork("campus-radar-sync")
     future.addListener({
      try {
       val jobs=future.get().map {info -> mapOf("state" to info.state.name,"attempts" to info.runAttemptCount,"nextAt" to info.nextScheduleTimeMillis)}
       val power=getSystemService(PowerManager::class.java)
       val activity=getSystemService(ActivityManager::class.java)
       val connectivity=getSystemService(ConnectivityManager::class.java)
       val array=org.json.JSONArray(getSharedPreferences("campus_background",MODE_PRIVATE).getString("events","[]"))
       val events=(0 until array.length()).map {i-> val e=array.getJSONObject(i);mapOf("at" to e.getLong("at"),"state" to e.getString("state"),"durationMs" to e.optLong("durationMs",0))}
       result.success(mapOf("jobs" to jobs,"events" to events,"powerSave" to power.isPowerSaveMode,"batteryExempt" to power.isIgnoringBatteryOptimizations(packageName),"backgroundRestricted" to (if(Build.VERSION.SDK_INT>=28)activity.isBackgroundRestricted else false),"dataSaver" to connectivity.restrictBackgroundStatus))
      }catch(e:Exception){result.error("background_status","백그라운드 상태를 읽지 못했습니다.",null)}
     },ContextCompat.getMainExecutor(this))
    }
    "versionCode" -> {val p=packageManager.getPackageInfo(packageName,0);result.success(if(Build.VERSION.SDK_INT>=28)p.longVersionCode.toInt() else p.versionCode)}
    "clearWebSession" -> CookieManager.getInstance().removeAllCookies {result.success(null)}
    "openCampus" -> {
     val args=call.arguments as Map<*,*>
     val url=args["url"] as String
     require(Uri.parse(url).host=="dcs-learning.cnu.ac.kr" && url.startsWith("https://"))
     val cm=CookieManager.getInstance();cm.setAcceptCookie(true)
     val cookies=args["cookies"] as List<Map<String,String>>
     fun open(){cm.flush();startActivity(Intent(this,CampusWebActivity::class.java).putExtra("url",url).putExtra("context",JSONObject(args["context"] as Map<*,*>).toString()).putExtra("target",args["target"] as String));result.success(null)}
     var pending=cookies.size
     if(pending==0)open() else cookies.forEach {c->cm.setCookie(c["url"],c["cookie"]){pending--;if(pending==0)open()}}
    }
    "installApk" -> {
     val file=File(call.argument<String>("path")!!).canonicalFile
     require(file.parentFile==cacheDir.canonicalFile && file.name=="campus-radar-update.apk")
     val flags=if(Build.VERSION.SDK_INT>=28)PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
     val archive=packageManager.getPackageArchiveInfo(file.path,flags)?:error("APK 파일을 읽지 못했습니다.")
     val installed=packageManager.getPackageInfo(packageName,flags)
     require(archive.packageName==packageName){"다른 앱의 설치 파일입니다."}
     val expected=call.argument<Number>("versionCode")!!.toLong()
     val nextVersion=if(Build.VERSION.SDK_INT>=28)archive.longVersionCode else archive.versionCode.toLong()
     val currentVersion=if(Build.VERSION.SDK_INT>=28)installed.longVersionCode else installed.versionCode.toLong()
     require(nextVersion==expected && nextVersion>currentVersion){"업데이트 버전이 맞지 않습니다."}
     val previous=if(Build.VERSION.SDK_INT>=28)installed.signingInfo!!.apkContentsSigners else installed.signatures
     val next=if(Build.VERSION.SDK_INT>=28)archive.signingInfo!!.apkContentsSigners else archive.signatures
     require(previous!!.map{it.toCharsString()}.toSet()==next!!.map{it.toCharsString()}.toSet()){"앱 서명이 일치하지 않습니다."}
     if(!packageManager.canRequestPackageInstalls()){
      startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:$packageName")));result.success("permission")
     }else{
      val uri=FileProvider.getUriForFile(this,"$packageName.updates",file)
      startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));result.success("installer")
     }
    }
    else->result.notImplemented()
   }}catch(e:Exception){result.error("native",e.message?:"작업을 완료하지 못했습니다.",null)}
  }
 }
}



# google_sign_in is used only on iPhone. Its Android half references the legacy
# GoogleSignIn API that play-services-auth 22 (used by the Drive Kotlin code)
# removed; Android never calls it, so R8 may drop the references.
-dontwarn com.google.android.gms.auth.api.signin.**

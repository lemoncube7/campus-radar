# 에이전트 공용 작업 지침 (캠퍼스레이더)

Claude, Codex, Gemini(Antigravity) 등 이 저장소에서 일하는 모든 에이전트는 **작업 전에 이 파일을 읽어요.** 규칙과 사용자 지시가 충돌하면 사용자에게 물어요.

## 0. 시작 전
- **인계함 먼저 확인:** `powershell -NoProfile -ExecutionPolicy Bypass -File E:\Codex\2026-09-28\1-1-id-pw-2-n\work\handoff\handoff.ps1 inbox -Agent <claude|codex>`
  - 작업 하나에 기록 하나를 둬요. 상태는 코드·자동 테스트·실기기·게시로 나눠 적어요.
  - 이어받을 때는 `start`, 넘길 때는 "다음 행동"을 쓰고 `pass`해요. 질문과 부탁은 `ping`으로 보내요.
  - 설명은 `work/handoff/README.md`에 있어요.
- **빌드·테스트는 대기열로:** `work/build-queue/bq.ps1 -Repo <worktree> -Kind test|test-one|analyze|check|build-apk -Who <이름>`
  - 메모리를 보고 순서대로 실행해요. 같은 worktree에서는 한 번에 하나만 돌아요.
- **Antigravity:** `work/agy-tools/new-task.ps1`로 번호를 받고 `agy-run.ps1`로 실행해요. 시간 제한은 두지 않아요.
- **잠금 파일**
  - 대기열 밖에서 수동으로 빌드할 때는 `work/build-lock.txt`를 만들어요. 기기를 쓰기 전에는 `work/device-lock.txt`를 만들어요(이미 있으면 기다려요).
  - 끝나면 내가 만든 것만 지워요. **남의 잠금 파일은 지우지 않아요.**
- **작업 폴더(worktree)와 브랜치**
  - 내 브랜치에서만 커밋해요.
  - 다른 에이전트의 브랜치나 작업 폴더에는 커밋하거나 파일을 고치지 않아요. 필요하면 사용자에게 요청해요.
- **환경**
  - Flutter는 `work/tools/env.ps1`을 먼저 불러온 뒤 `work/tools/flutter/bin/flutter.bat`로 실행해요.
  - 의존성은 `flutter pub get`으로 받아요. 인터넷이 돼요. `--no-pub`만 쓰지 않아요.
  - PC 메모리가 작아요. Gradle은 2.5G, 데몬 없이 써요. 빌드 후 `gradlew --stop`을 실행하고, java 프로세스를 강제로 모두 종료하지 않아요.

## 1. 파일 수정
- **모든 소스 파일은 UTF-8이에요.**
  - PowerShell의 `Set-Content`, `Out-File`, `WriteAllText`로 소스 파일을 쓰지 않아요.
  - 편집 도구나 UTF-8을 명시한 방법만 써요.
- **파일 전체를 다시 쓰지 말고, 바꿀 부분만 고쳐요.**
- **새 화면을 만들 때는 기존 계산을 재사용해요.**
  - 개수·필터·정렬: `DashboardCounts`, `openTask`, `availableAt`, `excluded`
  - 마감: `effectiveDue`, `extraDeadline`
- **기존 기능을 빼는 변경은 사용자 확인을 받은 뒤에 해요.**

## 2. 커밋 전 필수 검사 (하나라도 실패하면 커밋하지 않아요)
1. **인코딩 검사:** BAD가 하나라도 나오면 안 돼요.
   ```bash
   git ls-files lib test | while read f; do python -c "import sys;open(sys.argv[1],encoding='utf-8').read()" "$f" || echo BAD $f; done
   ```
2. `flutter analyze`에서 새 경고나 오류가 없어야 해요.
3. 바꾼 파일의 테스트를 돌려요.
4. 화면, 수집, 알림, 설정을 바꿨다면 `flutter test` 전체를 돌려요.
5. 수집 코드(`lib/campus/`)를 바꿨다면 `collection_request_budget_test`와 `campus_cli_test`가 통과해야 해요. 학교 요청 수가 늘면 안 돼요.

테스트가 실패하면 고치거나, 기능을 바꾼 게 맞다면 테스트를 고치고 그 이유를 커밋 메시지에 적어요. **실패한 채 다음 작업으로 넘어가지 않아요.**

## 3. 브랜치 동기화(lockstep)
- **모바일 브랜치 ↔ Windows 브랜치는 diff로만 옮겨요.** `git cherry-pick`을 쓰거나 해당 부분만 고쳐요.
- **파일 통째 복사는 금지예요.** Windows 브랜치에만 있는 코드가 있어요: Drive 보기 모드, `pcDriveMode`, `ensurePcEditable`, `app_snapshot`.
- 충돌이 나면 양쪽 내용을 모두 살려요. 옮긴 뒤 그 브랜치에서 2장의 검사를 다시 해요.

## 4. 빌드와 배포
- **Android:** `flutter build apk`로 빌드해요.
- **Windows:** 정식 빌드는 CI 전체 빌드로 해요. `app.so`만 바꾸는 방식은 실험용이고, Google 클라이언트 dart-define을 꼭 넣어요.
- **릴리스, 스토어 업로드, 공개 게시는 사용자 승인 없이 하지 않아요.**

## 5. 보안
- `login.txt`, `gemini-key.txt`는 열지 않아요.
- `work/windows-oauth-client.json`, `work/*token*.json`은 출력하거나 커밋하지 않아요.
- 학교 로그인은 사용자가 직접 해요. 에이전트가 비밀번호를 입력하지 않아요.
- 데이터를 영구 삭제하지 않아요.

## 6. 보고서
- **사실만 적어요.**
  - "완벽", "100%", "배포 완료" 같은 표현은 쓰지 않아요.
  - 로컬 파일을 바꾼 것을 "배포"라고 부르지 않아요.
- **커밋마다 근거를 남겨요:** 무엇을 바꿨는지, 어떻게 확인했는지(테스트 이름과 통과 수, 실기기·에뮬레이터 빌드, 화면 캡처).
- 확인하지 않은 것은 "미확인"이라고 적어요. 남은 문제와 실패한 테스트도 숨기지 않고 적어요.
- **작업은 작게 나눠요.** 화면 하나나 기능 하나 단위로 끝내고 검사한 뒤 다음으로 넘어가요.

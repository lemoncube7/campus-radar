import Foundation

enum RadarShared {
    // AltStore may remap the group identifier while re-signing. Read the signed
    // provisioning profile, and share only a bounded display snapshot, never keys.
    static var group: String {
        if let url = Bundle.main.url(forResource: "embedded", withExtension: "mobileprovision"),
           let data = try? Data(contentsOf: url),
           let start = data.range(of: Data("<?xml".utf8)),
           let end = data.range(of: Data("</plist>".utf8), in: start.lowerBound..<data.endIndex),
           let plist = try? PropertyListSerialization.propertyList(from: data.subdata(in: start.lowerBound..<end.upperBound), format: nil) as? [String: Any],
           let entitlements = plist["Entitlements"] as? [String: Any],
           let groups = entitlements["com.apple.security.application-groups"] as? [String],
           let group = groups.first(where: { $0.contains("campusradar") }) {
            return group
        }
        return "group.kr.campusradar.campusradar"
    }
    static var snapshotURL: URL? {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group)?
            .appendingPathComponent("radar-widget.json")
    }
}

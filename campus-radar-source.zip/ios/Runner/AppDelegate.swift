import Flutter
import UIKit
import UserNotifications
import WebKit
import workmanager_apple
import flutter_local_notifications

@main
@objc class AppDelegate: FlutterAppDelegate {
  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    GeneratedPluginRegistrant.register(with: self)
    UNUserNotificationCenter.current().delegate = self
    WorkmanagerPlugin.setPluginRegistrantCallback { registry in
      GeneratedPluginRegistrant.register(with: registry)
    }
    WorkmanagerPlugin.registerPeriodicTask(
      withIdentifier: "kr.campusradar.campusradar.sync", frequency: NSNumber(value: 3600)
    )
    FlutterLocalNotificationsPlugin.setPluginRegistrantCallback { registry in
      GeneratedPluginRegistrant.register(with: registry)
    }
    if let controller = window?.rootViewController as? FlutterViewController {
      let channel = FlutterMethodChannel(name: "campus_radar/native", binaryMessenger: controller.binaryMessenger)
      channel.setMethodCallHandler { [weak controller] call, result in
        switch call.method {
        case "versionCode":
          result(Int(Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "1"))
        case "clearWebSession":
          let data = WKWebsiteDataStore.default()
          data.removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: .distantPast) { result(nil) }
        case "openReleasePage":
          UIApplication.shared.open(URL(string: "https://github.com/lemoncube7/campus-radar/releases")!) { opened in
            result(opened ? nil : FlutterError(code: "open_failed", message: "배포 페이지를 열지 못했습니다.", details: nil))
          }
        case "openCampus":
          guard let args = call.arguments as? [String: Any], let controller = controller,
                let destination = args["url"] as? String, let url = URL(string: destination),
                url.scheme == "https", ["dcs-learning.cnu.ac.kr", "dcs-lcms.cnu.ac.kr"].contains(url.host ?? "") else {
            result(FlutterError(code: "invalid_url", message: "강의실 주소가 올바르지 않습니다.", details: nil)); return
          }
          let page = CampusWebController(args: args, destination: url)
          controller.present(UINavigationController(rootViewController: page), animated: true)
          result(nil)
        default: result(FlutterMethodNotImplemented)
        }
      }
    }
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }
}

// Cookies stay in the app's WebKit store. Portal credentials never enter JavaScript.
private final class CampusWebController: UIViewController, WKNavigationDelegate, WKUIDelegate {
  let args: [String: Any]
  let destination: URL
  var web: WKWebView!
  init(args: [String: Any], destination: URL) {
    self.args = args; self.destination = destination
    super.init(nibName: nil, bundle: nil)
  }
  required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }
  private func literal(_ value: Any) -> String {
    guard let data = try? JSONSerialization.data(withJSONObject: value, options: [.fragmentsAllowed]),
          let text = String(data: data, encoding: .utf8) else { return "null" }
    return text
  }
  override func viewDidLoad() {
    super.viewDidLoad()
    title = "사이버캠퍼스"
    navigationItem.leftBarButtonItem = UIBarButtonItem(title: "앱으로 돌아가기", style: .done, target: self, action: #selector(closePage))
    let config = WKWebViewConfiguration()
    let context = args["context"] as? String ?? literal(args["context"] ?? [:])
    let script = "if(location.origin==='https://dcs-learning.cnu.ac.kr'){sessionStorage.setItem('currentCourseData',\(literal(context)));}"
    config.userContentController.addUserScript(WKUserScript(source: script, injectionTime: .atDocumentStart, forMainFrameOnly: true))
    web = WKWebView(frame: .zero, configuration: config)
    web.navigationDelegate = self; web.uiDelegate = self
    web.translatesAutoresizingMaskIntoConstraints = false
    view.addSubview(web)
    NSLayoutConstraint.activate([web.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor), web.bottomAnchor.constraint(equalTo: view.bottomAnchor), web.leadingAnchor.constraint(equalTo: view.leadingAnchor), web.trailingAnchor.constraint(equalTo: view.trailingAnchor)])
    let group = DispatchGroup()
    for row in args["cookies"] as? [[String: String]] ?? [] {
      guard let origin = row["url"], let url = URL(string: origin), url.scheme == "https",
            ["dcs-learning.cnu.ac.kr", "dcs-lcms.cnu.ac.kr"].contains(url.host ?? ""),
            let header = row["cookie"] else { continue }
      for cookie in HTTPCookie.cookies(withResponseHeaderFields: ["Set-Cookie": header], for: url) {
        group.enter(); web.configuration.websiteDataStore.httpCookieStore.setCookie(cookie) { group.leave() }
      }
    }
    group.notify(queue: .main) { [weak self] in
      guard let self = self else { return }; self.web.load(URLRequest(url: self.destination))
    }
  }
  @objc private func closePage() { dismiss(animated: true) }
  func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
    guard let url = action.request.url, url.scheme == "https" else { decisionHandler(.cancel); return }
    if ["dcs-learning.cnu.ac.kr", "dcs-lcms.cnu.ac.kr"].contains(url.host ?? "") { decisionHandler(.allow) }
    else { decisionHandler(.cancel); if action.navigationType == .linkActivated { UIApplication.shared.open(url) } }
  }
  func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
    if action.targetFrame == nil { webView.load(action.request) }; return nil
  }
  func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
    guard webView.url?.host == "dcs-learning.cnu.ac.kr", webView.url?.path == "/std/course", let target = args["target"] as? String else { return }
    webView.evaluateJavaScript("(function(){var id=\(literal(target));var n=0;function jump(){var e=Array.from(document.querySelectorAll('[data-contentsid]')).find(e=>e.dataset.moduletype==='LV'&&(e.dataset.contentsid===id||e.dataset.weekseqno===id));if(e){var box=e.closest('.collapse');if(box)box.classList.add('show');e.scrollIntoView({block:'center'});if(window.courseAttend&&window.jQuery)courseAttend.detailContents(window.jQuery(e));}else if(n++<20)setTimeout(jump,500);}jump();})();", completionHandler: nil)
  }
}

import Flutter
import UIKit
import EventKit
import UserNotifications
import WebKit
import workmanager_apple
import flutter_local_notifications

@main
@objc class AppDelegate: FlutterAppDelegate {
  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    GeneratedPluginRegistrant.register(with: self)
    UNUserNotificationCenter.current().delegate = self
    WorkmanagerPlugin.setPluginRegistrantCallback { registry in
      GeneratedPluginRegistrant.register(with: registry)
      registerRadarBridge(registry: registry, controller: nil)
    }
    WorkmanagerPlugin.registerPeriodicTask(
      withIdentifier: "kr.campusradar.campusradar.sync", frequency: NSNumber(value: 3600)
    )
    FlutterLocalNotificationsPlugin.setPluginRegistrantCallback { registry in
      GeneratedPluginRegistrant.register(with: registry)
      registerRadarBridge(registry: registry, controller: nil)
    }
    registerRadarBridge(registry: self, controller: window?.rootViewController as? FlutterViewController)

    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }
}

private func registerRadarBridge(registry: FlutterPluginRegistry, controller: FlutterViewController?) {
  guard !registry.hasPlugin("CampusRadarNative"), let registrar = registry.registrar(forPlugin: "CampusRadarNative") else { return }
  let channel = FlutterMethodChannel(name:"campus_radar/native", binaryMessenger:registrar.messenger())
      channel.setMethodCallHandler { [weak controller] call, result in
        switch call.method {
        case "versionInfo":
          result(["name": Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "", "code": Int(Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "1") ?? 1])
        case "calendarPermission":
          RadarCalendarIOS.request(result)
        case "calendarSettings": result(RadarCalendarIOS.settings())
        case "calendarList": result(RadarCalendarIOS.calendars())
        case "calendarConfigure", "calendarWrite", "calendarSync":
          do {
            let args = call.arguments as? [String: Any] ?? [:]
            if call.method == "calendarConfigure" { try RadarCalendarIOS.configure(args); result(nil) }
            else if call.method == "calendarWrite" { result(try RadarCalendarIOS.write(args)) }
            else { try RadarCalendarIOS.sync(args); result(nil) }
          } catch { result(FlutterError(code: "calendar_error", message: error.localizedDescription, details: nil)) }
        case "calendarUnlink": RadarCalendarIOS.unlink(); result(nil)
        case "drainNativeLogs": result(RadarCalendarIOS.drainLogs())
        case "dailySettings": result(RadarCalendarIOS.dailySettings())
        case "setDailySettings":
          let a = call.arguments as? [String: Any] ?? [:]
          UserDefaults.standard.set(a, forKey: "radarDailySettings"); result(nil)
        case "openAppSettings":
          UIApplication.shared.open(URL(string:UIApplication.openSettingsURLString)!) { _ in result(nil) }
        case "backgroundStatus":
          result(["backgroundRefresh": UIApplication.shared.backgroundRefreshStatus == .available,
            "powerSave": ProcessInfo.processInfo.isLowPowerModeEnabled, "jobs": [], "events": []])
        case "versionCode":
          result(Int(Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "1"))
        case "clearWebSession":
          let data = WKWebsiteDataStore.default()
          data.removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: .distantPast) { result(nil) }
        case "openReleasePage":
          UIApplication.shared.open(URL(string: "https://github.com/lemoncube7/campus-radar/releases")!) { opened in
            result(opened ? nil : FlutterError(code: "open_failed", message: "배포 페이지를 열지 못했습니다.", details: nil))
          }
        case "openAltStoreSource":
          guard let args = call.arguments as? [String: Any], let source = args["url"] as? String,
                let sourceURL = URL(string: source), sourceURL.scheme == "https" else {
            result(FlutterError(code: "invalid_source", message: "AltStore 소스 주소가 올바르지 않습니다.", details: nil)); return
          }
          var components = URLComponents()
          components.scheme = "altstore-classic"; components.host = "source"
          components.queryItems = [URLQueryItem(name: "url", value: source)]
          guard let url = components.url else { result(FlutterError(code: "invalid_source", message: "소스 주소 오류", details: nil)); return }
          UIApplication.shared.open(url) { opened in
            result(opened ? nil : FlutterError(code: "altstore_missing", message: "AltStore Classic을 설치하고 다시 시도해 주세요.", details: nil))
          }
        case "openCampus":
          guard let args = call.arguments as? [String: Any], let controller = controller,
                let destination = args["url"] as? String, let url = URL(string: destination),
                url.scheme == "https", ["dcs-learning.cnu.ac.kr", "dcs-lcms.cnu.ac.kr"].contains(url.host ?? "") else {
            result(FlutterError(code: "invalid_url", message: "강의실 주소가 올바르지 않습니다.", details: nil)); return
          }
          let page = CampusWebController(args: args, destination: url)
          controller.present(UINavigationController(rootViewController: page), animated: true)
          result(nil)
        default: result(FlutterMethodNotImplemented)
        }
      }
}

private enum RadarCalendarIOS {
  static let store = EKEventStore()
  static let prefs = UserDefaults.standard
  static var allowed: Bool {
    if #available(iOS 17.0, *) { return EKEventStore.authorizationStatus(for: .event) == .fullAccess }
    return EKEventStore.authorizationStatus(for: .event) == .authorized
  }
  static func request(_ result: @escaping FlutterResult) {
    let done: (Bool, Error?) -> Void = { ok, error in DispatchQueue.main.async {
      if let error = error { result(FlutterError(code:"calendar_permission", message:error.localizedDescription, details:nil)) }
      else { result(ok) }
    }}
    if #available(iOS 17.0, *) { store.requestFullAccessToEvents(completion: done) }
    else { store.requestAccess(to: .event, completion: done) }
  }
  static func error(_ message:String) -> NSError { NSError(domain:"CampusRadar",code:1,userInfo:[NSLocalizedDescriptionKey:message]) }
  static func settings() -> [String:Any] {
    ["calendarId":prefs.string(forKey:"radarCalendarID") ?? "", "auto":prefs.bool(forKey:"radarCalendarAuto"), "allowed":allowed]
  }
  static func calendars() -> [[String:Any]] {
    guard allowed else { return [] }
    return store.calendars(for:.event).filter{$0.allowsContentModifications}.map{["id":$0.calendarIdentifier,"name":$0.title,"account":$0.source.title]}
  }
  static func configure(_ args:[String:Any]) throws {
    let id=args["calendarId"] as? String ?? ""
    guard allowed, let calendar=store.calendar(withIdentifier:id), calendar.allowsContentModifications else { throw error("쓸 수 있는 캘린더를 선택해 주세요.") }
    let old=prefs.string(forKey:"radarCalendarID") ?? ""
    guard old.isEmpty || old==id || !prefs.dictionaryRepresentation().keys.contains(where:{$0.hasPrefix("radarEvent:")}) else { throw error("기존 연결을 해제한 뒤 캘린더를 변경해 주세요.") }
    prefs.set(id,forKey:"radarCalendarID");prefs.set(args["auto"] as? Bool ?? false,forKey:"radarCalendarAuto")
  }
  static func log(_ title:String,_ detail:String) {
    var logs=prefs.array(forKey:"radarNativeLogs") as? [[String:String]] ?? []
    logs.append(["kind":"calendar","title":title,"detail":detail]);prefs.set(Array(logs.suffix(100)),forKey:"radarNativeLogs")
  }
  static func drainLogs() -> [[String:String]] { let rows=prefs.array(forKey:"radarNativeLogs") as? [[String:String]] ?? [];prefs.removeObject(forKey:"radarNativeLogs");return rows }
  static func dailySettings() -> [String:Any] { prefs.dictionary(forKey:"radarDailySettings") ?? ["enabled":false,"hour":18,"minute":0] }
  static func write(_ args:[String:Any], automatic:Bool=false) throws -> String {
    guard allowed, let calendar=store.calendar(withIdentifier:prefs.string(forKey:"radarCalendarID") ?? ""),calendar.allowsContentModifications else { throw error("캘린더 권한과 저장할 캘린더를 확인해 주세요.") }
    guard let key=args["key"] as? String, let title=args["title"] as? String, !title.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty,
      let start=args["start"] as? NSNumber, let end=args["end"] as? NSNumber, end.doubleValue>start.doubleValue else { throw error("일정 제목과 시간을 확인해 주세요.") }
    let token="[CampusRadar:\(key)]"
    let linked=prefs.string(forKey:"radarEvent:\(key)")
    var event=linked.flatMap{store.event(withIdentifier:$0)}
    let owned=event?.calendar.calendarIdentifier==calendar.calendarIdentifier && (event?.notes ?? "").contains(token)
    if !owned {
      if automatic && linked != nil { return "" }
      event=EKEvent(eventStore:store)
    }
    guard let event=event else { throw error("캘린더 일정을 준비하지 못했습니다.") }
    let description=String((args["description"] as? String ?? "").prefix(8000))
    let signatureData=try JSONSerialization.data(withJSONObject:args,options:[.sortedKeys])
    let signature=signatureData.base64EncodedString()
    if owned && prefs.string(forKey:"radarEventSig:\(key)")==signature { return event.eventIdentifier }
    event.calendar=calendar;event.title=title;event.startDate=Date(timeIntervalSince1970:start.doubleValue/1000);event.endDate=Date(timeIntervalSince1970:end.doubleValue/1000)
    event.isAllDay=args["allDay"] as? Bool ?? false;event.timeZone=TimeZone(identifier:event.isAllDay ? "UTC":"Asia/Seoul")
    event.notes=description+"\n"+token;event.availability = .free
    try store.save(event,span:.thisEvent,commit:true)
    prefs.set(event.eventIdentifier,forKey:"radarEvent:\(key)");prefs.set(signature,forKey:"radarEventSig:\(key)")
    log(owned ? "캘린더 일정 갱신":"캘린더 일정 추가", title)
    return event.eventIdentifier
  }
  static func date(_ text:String?) -> Date? {
    guard let text=text else { return nil }
    let f=ISO8601DateFormatter();f.formatOptions=[.withInternetDateTime,.withFractionalSeconds]
    if let d=f.date(from:text) { return d };f.formatOptions=[.withInternetDateTime];return f.date(from:text)
  }
  static func sync(_ args:[String:Any]) throws {
    if let rows=args["items"] as? [[String:Any]] { prefs.set(try JSONSerialization.data(withJSONObject:rows),forKey:"radarCalendarItems") }
    guard allowed, !(prefs.string(forKey:"radarCalendarID") ?? "").isEmpty else { return }
    let rows=(prefs.data(forKey:"radarCalendarItems").flatMap{try? JSONSerialization.jsonObject(with:$0)}) as? [[String:Any]] ?? []
    var cal=Calendar(identifier:.gregorian);cal.timeZone=TimeZone(identifier:"Asia/Seoul")!
    let f=DateFormatter();f.locale=Locale(identifier:"en_US_POSIX");f.timeZone=cal.timeZone;f.dateFormat="HH:mm"
    for row in rows {
      guard let key=row["key"] as? String,let due=date(row["due"] as? String) else { continue }
      let linked=prefs.string(forKey:"radarEvent:\(key)") != nil
      if !linked && (!prefs.bool(forKey:"radarCalendarAuto") || row["status"] as? String != "pending" || due<=Date()) { continue }
      let midnight=cal.startOfDay(for:due),before=due.addingTimeInterval(-600)
      let start=due==midnight ? before:max(before,midnight)
      let title="[\(row["course"] as? String ?? "") \(f.string(from:due))] \(row["title"] as? String ?? "")"+(row["status"] as? String == "done" ? " · 완료":"")
      _=try write(["key":key,"title":title,"start":start.timeIntervalSince1970*1000,"end":due.timeIntervalSince1970*1000,"allDay":false,"description":"마감 일정 · 한국 시간\n\(row["body"] as? String ?? "")\nhttps://dcs-learning.cnu.ac.kr/home"],automatic:true)
    }
  }
  static func unlink() { for key in prefs.dictionaryRepresentation().keys where key.hasPrefix("radarEvent:") || key.hasPrefix("radarEventSig:") || key.hasPrefix("radarCalendar") { prefs.removeObject(forKey:key) } }
}

// Cookies stay in the app's WebKit store. Portal credentials never enter JavaScript.
private final class CampusWebController: UIViewController, WKNavigationDelegate, WKUIDelegate {
  let args: [String: Any]
  let destination: URL
  var web: WKWebView!
  init(args: [String: Any], destination: URL) {
    self.args = args; self.destination = destination
    super.init(nibName: nil, bundle: nil)
  }
  required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }
  private func literal(_ value: Any) -> String {
    guard let data = try? JSONSerialization.data(withJSONObject: value, options: [.fragmentsAllowed]),
          let text = String(data: data, encoding: .utf8) else { return "null" }
    return text
  }
  override func viewDidLoad() {
    super.viewDidLoad()
    title = "사이버캠퍼스"
    navigationItem.leftBarButtonItem = UIBarButtonItem(title: "앱으로 돌아가기", style: .done, target: self, action: #selector(closePage))
    let config = WKWebViewConfiguration()
    let context = args["context"] as? String ?? literal(args["context"] ?? [:])
    let script = "if(location.origin==='https://dcs-learning.cnu.ac.kr'){sessionStorage.setItem('currentCourseData',\(literal(context)));}"
    config.userContentController.addUserScript(WKUserScript(source: script, injectionTime: .atDocumentStart, forMainFrameOnly: true))
    web = WKWebView(frame: .zero, configuration: config)
    web.navigationDelegate = self; web.uiDelegate = self
    web.translatesAutoresizingMaskIntoConstraints = false
    view.addSubview(web)
    NSLayoutConstraint.activate([web.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor), web.bottomAnchor.constraint(equalTo: view.bottomAnchor), web.leadingAnchor.constraint(equalTo: view.leadingAnchor), web.trailingAnchor.constraint(equalTo: view.trailingAnchor)])
    let group = DispatchGroup()
    for row in args["cookies"] as? [[String: String]] ?? [] {
      guard let origin = row["url"], let url = URL(string: origin), url.scheme == "https",
            ["dcs-learning.cnu.ac.kr", "dcs-lcms.cnu.ac.kr"].contains(url.host ?? ""),
            let header = row["cookie"] else { continue }
      for cookie in HTTPCookie.cookies(withResponseHeaderFields: ["Set-Cookie": header], for: url) {
        group.enter(); web.configuration.websiteDataStore.httpCookieStore.setCookie(cookie) { group.leave() }
      }
    }
    group.notify(queue: .main) { [weak self] in
      guard let self = self else { return }; self.web.load(URLRequest(url: self.destination))
    }
  }
  @objc private func closePage() { dismiss(animated: true) }
  func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
    guard let url = action.request.url, url.scheme == "https" else { decisionHandler(.cancel); return }
    if ["dcs-learning.cnu.ac.kr", "dcs-lcms.cnu.ac.kr"].contains(url.host ?? "") { decisionHandler(.allow) }
    else { decisionHandler(.cancel); if action.navigationType == .linkActivated { UIApplication.shared.open(url) } }
  }
  func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
    if action.targetFrame == nil { webView.load(action.request) }; return nil
  }
  func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
    guard webView.url?.host == "dcs-learning.cnu.ac.kr", webView.url?.path == "/std/course", let target = args["target"] as? String else { return }
    webView.evaluateJavaScript("(function(){var id=\(literal(target));var n=0;function jump(){var e=Array.from(document.querySelectorAll('[data-contentsid]')).find(e=>e.dataset.moduletype==='LV'&&(e.dataset.contentsid===id||e.dataset.weekseqno===id));if(e){var box=e.closest('.collapse');if(box)box.classList.add('show');e.scrollIntoView({block:'center'});if(window.courseAttend&&window.jQuery)courseAttend.detailContents(window.jQuery(e));}else if(n++<20)setTimeout(jump,500);}jump();})();", completionHandler: nil)
  }
}

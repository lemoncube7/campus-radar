import WidgetKit
import SwiftUI
import ActivityKit

struct RadarTask: Decodable { let key: String; let course: String; let title: String; let due: Double? }
struct RadarClass: Decodable { let course: String; let room: String; let start: Double; let end: Double }
struct RadarSnapshot: Decodable {
    let updated: Double; let connected: Bool; let tasks: [RadarTask]; let classes: [RadarClass]
    let pendingCount: Int?
    var taskCount: Int { pendingCount ?? tasks.count }
    static let empty = RadarSnapshot(updated: 0, connected: false, tasks: [], classes: [], pendingCount: 0)
}
struct RadarEntry: TimelineEntry { let date: Date; let snapshot: RadarSnapshot }
struct RadarProvider: TimelineProvider {
    func placeholder(in context: Context) -> RadarEntry { RadarEntry(date: Date(), snapshot: .empty) }
    func getSnapshot(in context: Context, completion: @escaping (RadarEntry) -> Void) { completion(read()) }
    func getTimeline(in context: Context, completion: @escaping (Timeline<RadarEntry>) -> Void) {
        let entry = read()
        // Include class boundaries; the system retains final scheduling control.
        let dates = entry.snapshot.classes.flatMap { [Date(timeIntervalSince1970: $0.start), Date(timeIntervalSince1970: $0.end)] }
            .filter { $0 > entry.date && $0 < entry.date.addingTimeInterval(86400) }.sorted()
        let entries = [entry] + dates.map { RadarEntry(date: $0, snapshot: entry.snapshot) }
        completion(Timeline(entries: entries, policy: .after(entry.date.addingTimeInterval(1800))))
    }
    private func read() -> RadarEntry {
        let snapshot = RadarShared.snapshotURL.flatMap { try? Data(contentsOf: $0) }
            .flatMap { try? JSONDecoder().decode(RadarSnapshot.self, from: $0) } ?? .empty
        return RadarEntry(date: Date(), snapshot: snapshot)
    }
}
struct RadarWidgetView: View {
    let entry: RadarEntry
    let timetable: Bool
    @Environment(\.widgetFamily) var family
    private var upcoming: [RadarClass] { entry.snapshot.classes.filter { Date(timeIntervalSince1970: $0.end) > entry.date } }
    var body: some View {
        if #available(iOSApplicationExtension 17.0, *) {
            content.containerBackground(.fill.tertiary, for: .widget)
        } else { content.padding(10) }
    }
    @ViewBuilder var content: some View {
        if family == .accessoryInline {
            if let next = upcoming.first {
                Text("\(next.course) \(clock(next.start))")
            } else { Text("미완료 \(entry.snapshot.taskCount)개 · 앱에서 확인") }
        } else if family == .accessoryRectangular {
            // Lock screen card (LockStar on Android): next class, time left, open work.
            VStack(alignment: .leading, spacing: 1) {
                if let next = upcoming.first {
                    let start = Date(timeIntervalSince1970: next.start)
                    Text(start > entry.date ? "다음 수업 · \(clock(next.start))" : "수업 중").font(.caption2).foregroundStyle(.secondary)
                    Text(next.course).font(.headline).lineLimit(1)
                    if start > entry.date {
                        Text(start, style: .relative).font(.caption).monospacedDigit()
                    } else {
                        Text("미완료 \(entry.snapshot.taskCount)개").font(.caption)
                    }
                } else {
                    Text("예정된 수업 없음").font(.caption2).foregroundStyle(.secondary)
                    Text("미완료 \(entry.snapshot.taskCount)개").font(.headline)
                }
            }
            .widgetURL(URL(string: "campusradar://tasks"))
            .privacySensitive()
        } else if family == .accessoryCircular {
            VStack { Image(systemName: "checklist"); Text("\(entry.snapshot.taskCount)") }
        } else {
            VStack(alignment: .leading, spacing: 5) {
                if !entry.snapshot.connected { Text("앱을 열어 수집해 주세요").font(.caption) }
                else if timetable || family == .accessoryRectangular {
                    Text(timetable ? "다가오는 수업" : "다음 수업").font(.caption).foregroundStyle(.secondary)
                    ForEach(Array(upcoming.prefix(family == .accessoryRectangular ? 1 : 4).enumerated()), id: \.offset) { _, row in
                        HStack { Text(clock(row.start)).monospacedDigit(); Text(row.course).lineLimit(1) }.font(.caption)
                        if family != .accessoryRectangular && !row.room.isEmpty { Text(row.room).font(.caption2).foregroundStyle(.secondary) }
                    }
                    if upcoming.isEmpty { Text("예정된 수업 없음").font(.caption) }
                } else {
                    Text("캠퍼스레이더").font(.headline)
                    ForEach(Array(entry.snapshot.tasks.prefix(family == .systemSmall ? 2 : 4).enumerated()), id: \.offset) { _, task in
                        Text("\(task.course) · \(task.title)").font(.caption).lineLimit(2)
                        if let due = task.due { Text(Date(timeIntervalSince1970: due), style: .relative).font(.caption2).foregroundStyle(.secondary) }
                    }
                    if entry.snapshot.tasks.isEmpty { Text("표시할 미완료 항목 없음").font(.caption) }
                }
                if family == .systemSmall || family == .systemMedium || family == .systemLarge {
                    Spacer(minLength: 0)
                    Text("마지막 수집 \(clock(entry.snapshot.updated))").font(.caption2).foregroundStyle(.secondary)
                }
            }
            .widgetURL(URL(string: timetable ? "campusradar://timetable" : "campusradar://tasks"))
            .privacySensitive()
        }
    }
    private func clock(_ seconds: Double) -> String {
        // 0 means nothing collected yet (would otherwise show 09:00 KST).
        if seconds <= 0 { return "기록 없음" }
        let formatter = DateFormatter(); formatter.timeZone = TimeZone(identifier: "Asia/Seoul"); formatter.dateFormat = "HH:mm"
        return formatter.string(from: Date(timeIntervalSince1970: seconds))
    }
}
@main struct CampusRadarWidgets: WidgetBundle {
    var body: some Widget {
        RadarTasksWidget()
        RadarTimetableWidget()
        ClassLiveActivity()
    }
}
struct RadarTasksWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "RadarTasks", provider: RadarProvider()) { RadarWidgetView(entry: $0, timetable: false) }
            .configurationDisplayName("할 일·다음 수업").description("마지막 수집 기준 할 일과 다음 수업을 확인해요.")
            .supportedFamilies([.systemSmall, .systemMedium, .accessoryInline, .accessoryCircular, .accessoryRectangular])
    }
}
struct RadarTimetableWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "RadarTimetable", provider: RadarProvider()) { RadarWidgetView(entry: $0, timetable: true) }
            .configurationDisplayName("시간표").description("휴강을 제외한 다가오는 수업을 확인해요.")
            .supportedFamilies([.systemMedium, .systemLarge])
    }
}

/// Next-class countdown on the lock screen and in the Dynamic Island.
struct ClassLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: ClassActivityAttributes.self) { context in
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(context.attributes.course).font(.headline).lineLimit(1)
                    if !context.state.room.isEmpty { Text(context.state.room).font(.caption).foregroundStyle(.secondary) }
                }
                Spacer()
                ClassCountdown(state: context.state).font(.title3.weight(.semibold))
            }
            .padding()
            .widgetURL(URL(string: "campusradar://timetable"))
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) { Text(context.attributes.course).font(.headline).lineLimit(1) }
                DynamicIslandExpandedRegion(.trailing) { ClassCountdown(state: context.state) }
                DynamicIslandExpandedRegion(.bottom) {
                    if !context.state.room.isEmpty { Text(context.state.room).font(.caption).foregroundStyle(.secondary) }
                }
            } compactLeading: {
                Image(systemName: "graduationcap")
            } compactTrailing: {
                ClassCountdown(state: context.state).frame(maxWidth: 52)
            } minimal: {
                Image(systemName: "graduationcap")
            }
        }
    }
}

struct ClassCountdown: View {
    let state: ClassActivityAttributes.ContentState
    var body: some View {
        let now = Date()
        if state.start > now {
            Text(timerInterval: now...state.start, countsDown: true).monospacedDigit().multilineTextAlignment(.trailing)
        } else if state.end > now {
            Text("수업 중")
        } else {
            Text("종료")
        }
    }
}

# 캠퍼스레이더

충남대학교 사이버캠퍼스 과제·콘텐츠·공지를 기기에서 수집하고 마감과 새 항목을 알려 주는 앱입니다.

## Android 0.4.13 (34)

수업 알림 발송 이후 잠금화면 카드에 수업 시작까지 남은 시간을 표시합니다. 전체 카드와 작은 카드 모두 지원하며, 시작 시 기존 과제 표시로 돌아갑니다.

개인 계정과 Gemini 키는 소스에 포함하지 않습니다. Android 서명 파일도 별도로 구성해야 합니다.

```sh
flutter pub get
flutter test
flutter analyze
flutter build apk --release --dart-define=RELEASE_CHANNEL=stable
```

[Android 릴리스](https://github.com/lemoncube7/campus-radar/releases/tag/v0.4.13)

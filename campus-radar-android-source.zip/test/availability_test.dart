import 'package:campus_radar/campus.dart';
import 'package:flutter_test/flutter_test.dart';

CampusItem item({
  DateTime? startsAt,
  bool published = true,
  String body = '안내',
  DateTime? due,
  String status = 'pending',
}) => CampusItem(
  key: 'LR:c:1:a',
  type: 'LR',
  title: '과제',
  course: '수업',
  courseId: 'c',
  classNo: '1',
  contentsId: 'a',
  status: status,
  startsAt: startsAt,
  published: published,
  body: body,
  due: due,
  context: {},
);
void main() {
  test(
    'Future and unpublished items are excluded, exact start boundary is included',
    () {
      final now = DateTime.utc(2026, 10, 15);
      expect(
        item(startsAt: now.add(const Duration(seconds: 1))).availableAt(now),
        false,
      );
      expect(item(startsAt: now).availableAt(now), true);
      expect(
        item(
          published: false,
          startsAt: now.subtract(const Duration(days: 1)),
        ).availableAt(now),
        false,
      );
      expect(
        CampusItem.fromJson(
          item(startsAt: now, published: false).toJson(),
        ).availableAt(now),
        false,
      );
    },
  );
  test(
    'Module opening uses later of weekly and assignment start, date-only values are KST',
    () {
      expect(
        moduleStart({
          'apply_str_dt': '2026-10-16',
          'weekseq_str_dt': '2026-10-15',
          'weekseq_str_dt_hour': '09',
          'weekseq_str_dt_min': '30',
        }),
        DateTime.utc(2026, 10, 15, 15),
      );
    },
  );
  test(
    'Report changes ignore completion and whitespace but retain actual instructions and due changes',
    () {
      final before = item(body: '파일 제출\n 안내', due: DateTime.utc(2026, 10, 21));
      expect(
        itemChanges(
          before,
          item(body: '파일   제출 안내', due: before.due, status: 'done'),
        ),
        isEmpty,
      );
      final changes = itemChanges(
        before,
        item(body: 'PDF로 제출', due: DateTime.utc(2026, 10, 22)),
      );
      expect(changes.length, 2);
      expect(changes.first, contains('마감:'));
      expect(changes.last, contains('이전:'));
    },
  );
}

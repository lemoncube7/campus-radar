import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/campus_media.dart';
import 'package:campus_radar/media_cache.dart';
import 'package:campus_radar/media_widgets.dart';
import 'package:campus_radar/services.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  testWidgets(
    'cached image and attachment render offline, file opens through native viewer',
    (tester) async {
      final temp = (await tester.runAsync(
        () => Directory.systemTemp.createTemp('media-ui-'),
      ))!;
      final messenger =
          TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
      messenger.setMockMethodCallHandler(
        const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
        (call) async => 'synthetic',
      );
      messenger.setMockMethodCallHandler(
        const MethodChannel('plugins.flutter.io/path_provider'),
        (call) async => temp.path,
      );
      final opened = <MethodCall>[];
      messenger.setMockMethodCallHandler(bridge, (call) async {
        opened.add(call);
        return null;
      });
      const picture = CampusMedia(
        name: '안내 이미지',
        url: 'https://dcs-learning.cnu.ac.kr/file/a.png',
        image: true,
      );
      const document = CampusMedia(
        name: '과제 안내.pdf',
        url: 'https://dcs-learning.cnu.ac.kr/file/b.pdf',
      );
      await tester.runAsync(() async {
        final cache = await MediaCache.open('synthetic');
        await cache
            .data(picture)
            .writeAsBytes(
              base64Decode(
                'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=',
              ),
            );
        await cache.record(picture).writeAsString('{"mime":"image/png"}');
        await cache.data(document).writeAsString('%PDF-1.4');
        await cache
            .record(document)
            .writeAsString('{"mime":"application/pdf"}');
      });
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: ListView(
              children: [
                CampusBodyView(
                  body: '앞 뒤',
                  bodyHtml: '<p>앞</p><img src="/file/a.png"><p>뒤</p>',
                  media: [picture, document],
                ),
              ],
            ),
          ),
        ),
      );
      for (var i = 0; i < 12; i++) {
        await tester.runAsync(
          () => Future<void>.delayed(const Duration(milliseconds: 30)),
        );
        await tester.pump();
      }
      expect(find.text('앞'), findsOneWidget);
      expect(find.text('뒤'), findsOneWidget);
      expect(find.text('첨부파일 1개'), findsOneWidget);
      expect(find.byType(Image), findsOneWidget);
      expect(find.textContaining('기기에 저장됨'), findsOneWidget);
      await tester.ensureVisible(find.text('과제 안내.pdf'));
      await tester.tap(find.text('과제 안내.pdf'));
      for (var i = 0; i < 8; i++) {
        await tester.runAsync(
          () => Future<void>.delayed(const Duration(milliseconds: 20)),
        );
        await tester.pump();
      }
      expect(opened.single.method, 'openCampusFile');
      expect(opened.single.arguments['mime'], 'application/pdf');
      await tester.pumpWidget(const SizedBox());
      messenger.setMockMethodCallHandler(
        const MethodChannel('plugins.flutter.io/path_provider'),
        null,
      );
      messenger.setMockMethodCallHandler(
        const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
        null,
      );
      messenger.setMockMethodCallHandler(bridge, null);
      await tester.runAsync(() => temp.delete(recursive: true));
    },
  );
}

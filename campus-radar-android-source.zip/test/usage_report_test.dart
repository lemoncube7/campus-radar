import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/home/usage_report.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  test('monthly usage counts this month only', () async {
    SharedPreferences.setMockInitialValues({});
    final dir = await Directory.systemTemp.createTemp('radar-usage-');
    await databaseFactory.setDatabasesPath(dir.path);
    final store = await Store.open();
    await store.log('notification', '마감 임박 알림 발송 요청', '');
    await store.log('notification', '알림 권한 허용', '');
    await store.log('sync', '[자동] 수집 소요 시간', '');
    await store.db.insert('logs', {
      'at': '2000-01-01T00:00:00Z',
      'kind': 'notification',
      'title': '새 과제 알림 발송 요청',
      'detail': '',
    });
    await store.setMeta(
      'discovered:x',
      DateTime.now().toUtc().toIso8601String(),
    );
    final c = await monthlyUsage(store);
    expect([c.alerts, c.checks, c.discovered], [1, 1, 1]);
    await store.db.close();
    await dir.delete(recursive: true);
  });
}

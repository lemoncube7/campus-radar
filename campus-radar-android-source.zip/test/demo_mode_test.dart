import 'dart:async';
import 'dart:io';

import 'package:campus_radar/ai/ai_cancellation_notification.dart';
import 'package:campus_radar/ai/ai_chat_page.dart';
import 'package:campus_radar/ai/ai_inbox_page.dart';
import 'package:campus_radar/ai/ai_inbox_repository.dart';
import 'package:campus_radar/ai/ai_automation.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/ai/chat.dart';
import 'package:campus_radar/ai/chat_threads.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/material_catalog.dart';
import 'package:campus_radar/campus/portal_connect.dart';
import 'package:campus_radar/campus/services.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/demo_mode.dart';
import 'package:campus_radar/core/demo_state.dart';
import 'package:campus_radar/core/navigation_key.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/core/school_time.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/export/drive_sync.dart';
import 'package:campus_radar/home/onboarding_page.dart';
import 'package:campus_radar/main.dart';
import 'package:campus_radar/navigation/app_router.dart';
import 'package:campus_radar/courses/course_page.dart';
import 'package:campus_radar/platform/android_widget_snapshot.dart';
import 'package:campus_radar/platform/desktop.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';
import 'package:campus_radar/schedule/timetable_cancellations_page.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/settings/settings_page.dart';
import 'package:campus_radar/tasks/task_presentation.dart'
    show extraDeadline;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;

  late Directory tempDir;
  final secureStorageCalls = <MethodCall>[];
  final workmanagerCalls = <MethodCall>[];
  final nativeCalls = <MethodCall>[];
  final notificationCalls = <MethodCall>[];

  const secureChannel = MethodChannel(
    'plugins.it_nomads.com/flutter_secure_storage',
  );
  const wmChannel1 = MethodChannel(
    'be.tramckrijte.workmanager/foreground_channel_work_manager',
  );
  const wmChannel2 = MethodChannel(
    'dev.fluttercommunity.workmanager/foreground_channel_work_manager',
  );
  const nativeChannel = MethodChannel('campus_radar/native');
  const notificationsChannel = MethodChannel(
    'dexterous.com/flutter/local_notifications',
  );
  const pathProviderChannel = MethodChannel('plugins.flutter.io/path_provider');

  Future<void> settleAsync(WidgetTester tester) async {
    for (var i = 0; i < 16; i++) {
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 40)),
      );
      await tester.pump(const Duration(milliseconds: 80));
    }
  }

  setUp(() async {
    tempDir = Directory.systemTemp.createTempSync('campus_demo_test_');
    await databaseFactory.setDatabasesPath(tempDir.path);
    demoModeNotifier.value = false;
    desktopMethodHandler = null;
    SharedPreferences.setMockInitialValues({});

    secureStorageCalls.clear();
    workmanagerCalls.clear();
    nativeCalls.clear();
    notificationCalls.clear();

    final messenger =
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;

    messenger.setMockMethodCallHandler(secureChannel, (call) async {
      secureStorageCalls.add(call);
      if (call.method == 'read') return null;
      if (call.method == 'readAll') return <String, String>{};
      return null;
    });
    for (final ch in [wmChannel1, wmChannel2]) {
      messenger.setMockMethodCallHandler(ch, (call) async {
        workmanagerCalls.add(call);
        return true;
      });
    }
    messenger.setMockMethodCallHandler(nativeChannel, (call) async {
      nativeCalls.add(call);
      return null;
    });
    messenger.setMockMethodCallHandler(notificationsChannel, (call) async {
      notificationCalls.add(call);
      if (call.method == 'initialize') return true;
      if (call.method == 'areNotificationsEnabled') return true;
      if (call.method == 'getNotificationAppLaunchDetails') {
        return {'notificationLaunchedApp': false};
      }
      return null;
    });
    messenger.setMockMethodCallHandler(pathProviderChannel, (call) async {
      return tempDir.path;
    });
  });

  tearDown(() async {
    demoModeNotifier.value = false;
    final messenger =
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    for (final ch in [
      secureChannel,
      wmChannel1,
      wmChannel2,
      nativeChannel,
      notificationsChannel,
      pathProviderChannel,
    ]) {
      messenger.setMockMethodCallHandler(ch, null);
    }
    try {
      if (tempDir.existsSync()) {
        tempDir.deleteSync(recursive: true);
      }
    } catch (_) {}
  });

  test(
    'DB isolation, zero credentials access, rich seed data, and restart persistence',
    () async {
      final realPath = await realDatabasePath();
      final demoPath = await demoDatabasePath();
      expect(File(realPath).existsSync(), isFalse);
      expect(File(demoPath).existsSync(), isFalse);

      // Enter demo mode: 0 secure storage calls, real DB untouched, demo DB seeded.
      secureStorageCalls.clear();
      await enterDemoMode(entrySource: 'dashboard');

      expect(isDemoActive, isTrue);
      expect(isRuntimeDemoActive, isTrue);
      expect(secureStorageCalls, isEmpty);
      expect(File(realPath).existsSync(), isFalse);
      expect(File(demoPath).existsSync(), isTrue);

      final store = await Store.open();
      try {
        final now = DateTime.now().toUtc();
        final items = await store.items();
        final notices = await store.notices();
        final materials = await studyMaterials(store, now: now);
        final slots = decodeSlots(await store.meta(MetaKey.timetableEntries));
        final inbox = await AiInboxRepository(store).read();
        final threads = await loadChatThreads(store, 'aiChat:all');

        // 오늘 마감 과제
        expect(
          items.any(
            (i) =>
                i.type == 'LR' &&
                i.openTask &&
                i.due != null &&
                i.due!.isAfter(now) &&
                schoolDay(i.due!) == schoolDay(now),
          ),
          isTrue,
        );
        // 마감 지남 과제
        expect(
          items.any(
            (i) =>
                i.type == 'LR' &&
                i.openTask &&
                extraDeadline(i, now: now) == null &&
                deadlineState(i.due, now: now) == DeadlineState.overdue,
          ),
          isTrue,
        );
        // 추가 제출 과제
        expect(items.any((i) => extraDeadline(i, now: now) != null), isTrue);
        // 출석 영상
        expect(
          items.any((i) => i.type == 'LV' && i.attendanceRequired == true),
          isTrue,
        );
        // 공지 여러 개(본문 포함) 및 자료 여러 개, 시간표
        expect(notices.length, greaterThanOrEqualTo(4));
        expect(notices.every((n) => n.bodyFetched && n.body.isNotEmpty), isTrue);
        expect(materials.length, greaterThanOrEqualTo(3));
        expect(slots.length, greaterThanOrEqualTo(5));

        // 검토함 미처리 휴강 후보 1개 + 시험 후보 1개
        final reviewCandidates = inbox.candidates.where(
          (r) => ((r['state'] as Map)['status'] ?? 'review') == 'review',
        );
        expect(
          reviewCandidates.where((r) {
            final c = r['candidate'] as ScheduleCandidate;
            return c.category == 'class' && c.action == 'cancel';
          }).length,
          1,
        );
        expect(
          reviewCandidates.where((r) {
            final c = r['candidate'] as ScheduleCandidate;
            return c.category == 'exam' && c.action == 'add';
          }).length,
          1,
        );

        // 미리 준비된 AI 채팅 스레드 1개
        expect(threads.length, 1);
        expect(threads.first.messages.length, 2);
      } finally {
        await store.db.close();
      }

      // Simulate app restart: reset in-memory flag and call initDemoState().
      demoModeNotifier.value = false;
      expect(isDemoActive, isFalse);
      final resumed = await initDemoState();
      expect(resumed, isTrue);
      expect(isDemoActive, isTrue);
      await seedDemo(); // Idempotent when lastSuccess already exists.
      expect(secureStorageCalls, isEmpty);

      // Exit demo mode: demo DB deleted, real DB still absent, 0 secure storage calls.
      final entrySource = await exitDemoMode();
      expect(entrySource, 'dashboard');
      expect(isDemoActive, isFalse);
      expect(File(demoPath).existsSync(), isFalse);
      expect(File(realPath).existsSync(), isFalse);
      expect(secureStorageCalls, isEmpty);
    },
  );

  test(
    'Existing real campus.db and SharedPreferences (including widget snapshots) remain untouched',
    () async {
      // 1. Seed a real campus.db before entering demo mode.
      final preStore = await Store.open();
      await preStore.replace([
        CampusItem(
          key: 'LR:real:1:hw1',
          type: 'LR',
          title: '실제 사용자 과제',
          course: '실제 과목',
          courseId: 'real',
          classNo: '1',
          contentsId: 'hw1',
          status: 'pending',
          due: DateTime.now().toUtc().add(const Duration(days: 2)),
          context: {'course_id': 'real', 'class_no': '1'},
        ),
      ]);
      await preStore.db.close();

      final realFile = File(await realDatabasePath());
      expect(realFile.existsSync(), isTrue);
      final realBytesBefore = await realFile.readAsBytes();

      // 2. Set pre-demo SharedPreferences including Android widget snapshots.
      SharedPreferences.setMockInitialValues({
        onboardingDoneKey: false,
        'radarTheme': 'light',
        'automaticSchoolConnection': true,
        PrefKey.widgetSnapshotJson: '{"realWidget":true}',
        PrefKey.widgetTimetableJson: '[{"course":"실제 과목"}]',
      });
      final prefs = await SharedPreferences.getInstance();

      // 3. Enter demo mode and mutate settings + demo DB.
      secureStorageCalls.clear();
      await enterDemoMode(entrySource: 'onboarding');
      expect(secureStorageCalls, isEmpty);

      await prefs.setBool(onboardingDoneKey, true);
      await prefs.setString('radarTheme', 'dark');
      await prefs.setBool('automaticSchoolConnection', false);
      await prefs.setString('materialsSortMode', 'date');
      await prefs.setStringList(PrefKey.scheduled, ['demo:alarm:1']);

      final demoStore = await Store.open();
      final demoItems = await demoStore.items();
      expect(demoItems.any((i) => i.title == '실제 사용자 과제'), isFalse);
      await publishAndroidWidgetSnapshot(demoStore, prefs: prefs);
      await clearAndroidWidgetSnapshot(prefs: prefs);
      await demoStore.db.close();

      // Real widget snapshots were never overwritten or cleared during demo.
      expect(
        prefs.getString(PrefKey.widgetSnapshotJson),
        '{"realWidget":true}',
      );
      expect(
        prefs.getString(PrefKey.widgetTimetableJson),
        '[{"course":"실제 과목"}]',
      );
      // Real DB bytes did not change at all during demo.
      expect(await realFile.readAsBytes(), realBytesBefore);

      // 4. Exit demo mode -> all preferences and real DB restored cleanly.
      final source = await exitDemoMode();
      expect(source, 'onboarding');
      expect(prefs.getBool(onboardingDoneKey), isFalse);
      expect(prefs.getString('radarTheme'), 'light');
      expect(prefs.getBool('automaticSchoolConnection'), isTrue);
      expect(prefs.getString('materialsSortMode'), isNull);
      expect(prefs.getStringList(PrefKey.scheduled), isNull);
      expect(prefs.getBool(demoActivePrefKey), isNull);
      expect(
        prefs.getString(PrefKey.widgetSnapshotJson),
        '{"realWidget":true}',
      );
      expect(
        prefs.getString(PrefKey.widgetTimetableJson),
        '[{"course":"실제 과목"}]',
      );

      final reopenedReal = await Store.open();
      final realItemsAfter = await reopenedReal.items();
      await reopenedReal.db.close();
      expect(realItemsAfter.map((i) => i.title).toList(), ['실제 사용자 과제']);
    },
  );

  test(
    'Zero external/device side effects during demo (sync, Workmanager, Drive, AI, widgets, calendar, alarms)',
    () async {
      await enterDemoMode();
      secureStorageCalls.clear();
      workmanagerCalls.clear();
      nativeCalls.clear();
      notificationCalls.clear();

      var aiTransportCalled = false;
      final store = await Store.open();
      try {
        expect(await synchronize(source: '테스트'), SyncOutcome.completed);
        await registerBackground();
        await scheduleBackgroundTrial();
        await prepareDriveSnapshot(manual: true);
        await scheduleAiWork();
        await processAiWork();
        await scheduleSummaryWarmup(18, 0, true);
        await prepareAiSummary(
          store,
          transport: (_, _) async {
            aiTransportCalled = true;
            return {};
          },
        );
        await reconcile(store);

        final chatReply = await askCampusAi(
          store,
          const [],
          '이번 주 마감 알려줘',
          transport: (_, _) async {
            aiTransportCalled = true;
            return {};
          },
        );
        expect(chatReply, contains('체험 모드에서는 미리 준비된 답만 보여요'));

        // Native write/side-effect calls are blocked at RadarMethodChannel.
        await bridge.invokeNative(NativeMethod.refreshWidget);
        await bridge.invokeNative(NativeMethod.calendarWrite, {'key': 'x'});
        await bridge.invokeNative(NativeMethod.calendarSync, {'items': []});
        await bridge.invokeNative(NativeMethod.driveConnect);
        await bridge.invokeNative(NativeMethod.driveEnqueue, {});
        expect(await bridge.invokeNativeList(NativeMethod.driveAccounts), isEmpty);
      } finally {
        await store.db.close();
      }

      expect(aiTransportCalled, isFalse);
      expect(secureStorageCalls, isEmpty);
      expect(workmanagerCalls, isEmpty);
      expect(nativeCalls, isEmpty);
      expect(
        notificationCalls.where((c) => c.method == 'zonedSchedule'),
        isEmpty,
      );

      await exitDemoMode();
    },
  );

  testWidgets(
    'Cancellation candidate apply & undo via real AiInboxPage/CancellationEditor, plus example notification target resolution',
    (tester) async {
      await tester.runAsync(() => enterDemoMode());
      secureStorageCalls.clear();

      // 1. Example notification helper reuses production cancellation functions.
      String? capturedPayload;
      String? capturedTitle;
      final sentResult = await tester.runAsync(
        () => sendDemoCancellationExampleNotification(
          notifier: ({
            required String key,
            required String title,
            required String body,
            required String payload,
          }) async {
            capturedTitle = title;
            capturedPayload = payload;
            return true;
          },
        ),
      );
      expect(sentResult!.sent, isTrue);
      expect(capturedTitle, contains('휴강 감지'));
      expect(capturedPayload, isNotNull);

      // Permission denied path returns sent: false without throwing.
      final deniedResult = await tester.runAsync(
        () => sendDemoCancellationExampleNotification(
          notifier: ({
            required String key,
            required String title,
            required String body,
            required String payload,
          }) async => false,
        ),
      );
      expect(deniedResult!.sent, isFalse);

      // Tapping notification payload resolves directly to the demo cancellation candidate.
      final resolved = await tester.runAsync(
        () => resolveCancellationNotificationTarget(capturedPayload),
      );
      expect(resolved, isNotNull);
      expect(resolved!.candidate.category, 'class');
      expect(resolved.candidate.action, 'cancel');
      expect(resolved.notice.course, '논리와비판적사고');

      // 2. Real AiInboxPage -> tap cancellation candidate -> CancellationEditor -> apply -> undo.
      await tester.pumpWidget(
        MaterialApp(
          navigatorKey: navKey,
          onGenerateRoute: buildAppRoute,
          home: const AiInboxPage(),
        ),
      );
      await settleAsync(tester);

      expect(find.textContaining('논리와비판적사고 휴강'), findsOneWidget);
      expect(find.textContaining('기말 지필 시험'), findsOneWidget);
      expect(find.text('시간표에 휴강 반영'), findsOneWidget);

      await tester.ensureVisible(find.text('시간표에 휴강 반영'));
      await tester.tap(find.text('시간표에 휴강 반영'));
      await settleAsync(tester);

      // Real CancellationEditor opened.
      expect(find.byType(CancellationEditor), findsOneWidget);
      expect(find.text('선택한 날짜·수업에 휴강 적용'), findsOneWidget);

      await tester.tap(find.text('선택한 날짜·수업에 휴강 적용'));
      await settleAsync(tester);

      // Verify cancellation was written to campus_demo.db.
      final cancellations = await tester.runAsync(() async {
        final checkStore = await Store.open();
        try {
          return await readClassCancellations(checkStore);
        } finally {
          await checkStore.db.close();
        }
      });
      expect(cancellations!.length, 1);
      expect(cancellations.single.course, '논리와비판적사고');

      // SnackBar with '실행 취소' is visible; tap it to undo via real undoCandidateCancellation.
      expect(find.text('선택한 수업에 휴강을 반영했어요'), findsOneWidget);
      expect(find.text('실행 취소'), findsOneWidget);
      await tester.tap(find.text('실행 취소'));
      await settleAsync(tester);

      final afterUndo = await tester.runAsync(() async {
        final checkStore = await Store.open();
        try {
          return (
            await readClassCancellations(checkStore),
            await AiInboxRepository(checkStore).read(),
          );
        } finally {
          await checkStore.db.close();
        }
      });
      expect(afterUndo!.$1, isEmpty);
      final cancelRow = afterUndo.$2.candidates.firstWhere(
        (r) => (r['candidate'] as ScheduleCandidate).action == 'cancel',
      );
      expect((cancelRow['state'] as Map)['status'], 'review');
      expect(secureStorageCalls, isEmpty);

      await tester.runAsync(() => exitDemoMode());
    },
  );

  testWidgets(
    'AI Chat shows pre-prepared Q&A thread and answers new questions offline without network',
    (tester) async {
      await tester.runAsync(() => enterDemoMode());
      secureStorageCalls.clear();

      await tester.pumpWidget(
        MaterialApp(
          onGenerateRoute: buildAppRoute,
          home: const AiChatPage(),
        ),
      );
      await settleAsync(tester);

      // Pre-populated Q&A is immediately visible.
      expect(
        find.text('이번 주 먼저 챙길 마감과 휴강 공지 요약해 줘'),
        findsOneWidget,
      );
      expect(find.textContaining('10주차 개념 확인 퀴즈 정리 제출'), findsOneWidget);

      // Ask a new question in demo mode -> offline guidance without consent dialogs or network.
      await tester.enterText(find.byType(TextField), '내일 수업 있어?');
      await tester.tap(find.byTooltip('질문 보내기'));
      await settleAsync(tester);

      expect(find.text('내일 수업 있어?'), findsOneWidget);
      expect(
        find.textContaining('체험 모드에서는 미리 준비된 답만 보여요'),
        findsOneWidget,
      );
      expect(secureStorageCalls, isEmpty);

      await tester.runAsync(() => exitDemoMode());
    },
  );

  testWidgets(
    'UI entry from Dashboard card, PortalConnectSheet, and OnboardingPage step 0, and exit via banner',
    (tester) async {
      // 1. Dashboard unauthenticated card entry & banner exit.
      await tester.pumpWidget(
        MaterialApp(
          navigatorKey: navKey,
          onGenerateRoute: buildAppRoute,
          home: const Dashboard(autoSync: false),
        ),
      );
      await settleAsync(tester);

      expect(find.text('놓치기 전에, 한눈에'), findsOneWidget);
      expect(find.text('로그인 없이 둘러보기'), findsOneWidget);

      secureStorageCalls.clear();
      await tester.tap(find.text('로그인 없이 둘러보기'));
      await settleAsync(tester);

      expect(isDemoActive, isTrue);
      expect(find.text('체험 중 · 예시 데이터'), findsOneWidget);
      expect(find.text('휴강 알림 예시'), findsOneWidget);
      expect(find.text('체험 끝내기'), findsOneWidget);
      expect(secureStorageCalls, isEmpty);

      await tester.tap(find.text('체험 끝내기'));
      await settleAsync(tester);

      expect(isDemoActive, isFalse);
      expect(find.text('체험 중 · 예시 데이터'), findsNothing);
      expect(find.text('놓치기 전에, 한눈에'), findsOneWidget);

      // 2. PortalConnectSheet entry when unauthenticated.
      await tester.tap(find.text('포털 연결'));
      await settleAsync(tester);
      expect(find.byType(PortalConnectSheet), findsOneWidget);
      expect(find.text('로그인 없이 둘러보기'), findsWidgets);

      await tester.tap(find.descendant(
        of: find.byType(PortalConnectSheet),
        matching: find.text('로그인 없이 둘러보기'),
      ));
      await settleAsync(tester);

      expect(isDemoActive, isTrue);
      expect(find.text('체험 중 · 예시 데이터'), findsOneWidget);

      await tester.tap(find.text('체험 끝내기'));
      await settleAsync(tester);
      expect(isDemoActive, isFalse);

      // 3. OnboardingPage step 0 entry (and hidden when allowDemo: false),
      //    plus exit returning to OnboardingPage.
      await tester.pumpWidget(
        const MaterialApp(
          home: OnboardingPage(key: ValueKey('no-demo'), allowDemo: false),
        ),
      );
      await settleAsync(tester);
      expect(find.text('로그인 없이 둘러보기'), findsNothing);

      await tester.pumpWidget(
        MaterialApp(
          navigatorKey: navKey,
          onGenerateRoute: buildAppRoute,
          home: const Dashboard(autoSync: false),
        ),
      );
      await settleAsync(tester);
      unawaited(
        navKey.currentState!.push(
          MaterialPageRoute<void>(
            fullscreenDialog: true,
            builder: (_) => const OnboardingPage(allowDemo: true),
          ),
        ),
      );
      await settleAsync(tester);
      expect(find.text('어떻게 쓸지 골라 주세요'), findsOneWidget);
      expect(find.text('로그인 없이 둘러보기'), findsOneWidget);

      secureStorageCalls.clear();
      await tester.tap(find.text('로그인 없이 둘러보기'));
      await settleAsync(tester);
      expect(isDemoActive, isTrue);
      expect(find.text('체험 중 · 예시 데이터'), findsOneWidget);
      expect(secureStorageCalls, isEmpty);

      await tester.tap(find.text('체험 끝내기'));
      await settleAsync(tester);
      expect(isDemoActive, isFalse);
      expect(find.text('어떻게 쓸지 골라 주세요'), findsOneWidget);
    },
  );

  test(
    'seed 실패 시 진입 취소 → demoModeActive 없음, prefs 원복, isDemoActive false',
    () async {
      SharedPreferences.setMockInitialValues({
        'user_pref_foo': 'bar',
        'user_pref_count': 123,
      });
      final prefs = await SharedPreferences.getInstance();

      await expectLater(
        () => enterDemoMode(
          seedAction: () async {
            throw Exception('seed failure injection');
          },
        ),
        throwsA(isA<Exception>()),
      );

      expect(prefs.getBool(demoActivePrefKey), isNull);
      expect(prefs.getString(demoEntrySourcePrefKey), isNull);
      expect(prefs.getString(demoPrefsBackupPrefKey), isNull);
      expect(prefs.getString('user_pref_foo'), 'bar');
      expect(prefs.getInt('user_pref_count'), 123);
      expect(isDemoActive, isFalse);
      expect(isRuntimeDemoActive, isFalse);
      expect(File(await demoDatabasePath()).existsSync(), isFalse);
    },
  );

  test(
    '체험 활성 상태에서 backgroundDispatcher 콜백 및 desktopRuntime.tick 즉시 반환 (secure storage·학교 요청·DB 접근 0)',
    () async {
      await enterDemoMode();
      secureStorageCalls.clear();
      final realPath = await realDatabasePath();

      // backgroundDispatcher 의 작업 콜백이 즉시 true 반환, secure storage / 학교 요청 / DB 쓰기 0
      final callbackResult = await backgroundTaskCallback('periodicTask', null);
      expect(callbackResult, isTrue);
      expect(secureStorageCalls, isEmpty);
      expect(File(realPath).existsSync(), isFalse);

      final store = await Store.open();
      try {
        expect(await store.meta(MetaKey.workerStarted), isNull);
        expect(await store.meta(MetaKey.workerSuccess), isNull);
      } finally {
        await store.db.close();
      }

      // Windows desktopRuntime.tick() 이 체험 중 아무 것도 안 하고 반환
      expect(desktopRuntime.running, isFalse);
      await desktopRuntime.tick(force: true);
      expect(desktopRuntime.running, isFalse);
      expect(secureStorageCalls, isEmpty);
      expect(File(realPath).existsSync(), isFalse);

      final storeAfterTick = await Store.open();
      try {
        expect(await storeAfterTick.meta(MetaKey.desktopHeartbeat), isNull);
      } finally {
        await storeAfterTick.db.close();
      }

      await exitDemoMode();
    },
  );

  testWidgets(
    'CoursePage: 체험 중 [강의실 열기]/[강의계획서] 클릭 시 학교 요청 없이 안내 메시지만 표시',
    (tester) async {
      await tester.runAsync(() => enterDemoMode());
      secureStorageCalls.clear();

      await tester.pumpWidget(
        const MaterialApp(
          home: CoursePage(
            course: {
              'course_id': 'd1',
              'class_no': '1',
              'course_nm': '인공지능과 미래사회',
            },
          ),
        ),
      );
      await settleAsync(tester);

      // [강의실 열기] 버튼 탭 -> 안내 스낵바 확인
      expect(find.text('강의실 열기'), findsOneWidget);
      await tester.tap(find.text('강의실 열기'));
      await settleAsync(tester);

      expect(find.text('체험 모드에서는 학교 사이트를 열 수 없어요.'), findsOneWidget);
      expect(find.text('포털을 먼저 연결해 주세요.'), findsNothing);
      expect(secureStorageCalls, isEmpty);

      // 수업 정보 탭 이동 -> [강의계획서 원문 보기] 탭 -> 안내 스낵바 확인
      await tester.tap(find.text('수업 정보'));
      await settleAsync(tester);

      expect(find.text('강의계획서 원문 보기'), findsOneWidget);
      await tester.tap(find.text('강의계획서 원문 보기'));
      await settleAsync(tester);

      expect(find.text('체험 모드에서는 학교 사이트를 열 수 없어요.'), findsOneWidget);
      expect(find.text('포털을 먼저 연결해 주세요.'), findsNothing);
      expect(secureStorageCalls, isEmpty);

      await tester.runAsync(() => exitDemoMode());
    },
  );

  test(
    '로그인 상태(자격증명·실제 prefs 있음)에서 진입 → 체험 중 자격증명 읽기 null → 종료 후 자격증명·prefs·실제 DB 파일 그대로',
    () async {
      // 1. 실제 campus.db 파일 시드
      final preStore = await Store.open();
      await preStore.replace([
        CampusItem(
          key: 'LR:real:1:hw1',
          type: 'LR',
          title: '실제 사용자 과제',
          course: '실제 과목',
          courseId: 'real',
          classNo: '1',
          contentsId: 'hw1',
          status: 'pending',
          due: DateTime.now().toUtc().add(const Duration(days: 2)),
          context: {'course_id': 'real', 'class_no': '1'},
        ),
      ]);
      await preStore.db.close();

      final realPath = await realDatabasePath();
      final demoPath = await demoDatabasePath();
      final realFile = File(realPath);
      expect(realFile.existsSync(), isTrue);
      final realBytesBefore = await realFile.readAsBytes();

      // 2. 실제 자격증명 및 prefs 준비
      final secureValues = <String, String>{
        'id': 'real_student_id',
        'pw': 'real_password',
        'gemini_api_key': 'real_api_key',
      };
      final messenger =
          TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
      messenger.setMockMethodCallHandler(secureChannel, (call) async {
        secureStorageCalls.add(call);
        if (call.method == 'read') {
          final key = (call.arguments as Map)['key'] as String;
          return secureValues[key];
        }
        if (call.method == 'write') {
          final args = call.arguments as Map;
          secureValues[args['key'] as String] = args['value'] as String;
          return null;
        }
        if (call.method == 'delete') {
          final key = (call.arguments as Map)['key'] as String;
          secureValues.remove(key);
          return null;
        }
        if (call.method == 'deleteAll') {
          secureValues.clear();
          return null;
        }
        if (call.method == 'readAll') {
          return Map<String, String>.from(secureValues);
        }
        return null;
      });

      SharedPreferences.setMockInitialValues({
        'user_custom_pref': 'real_value',
        'radarTheme': 'dark',
        PrefKey.widgetSnapshotJson: '{"realWidget":true}',
      });
      final prefs = await SharedPreferences.getInstance();

      expect(await credentials.read(key: 'id'), 'real_student_id');
      expect(await credentials.read(key: 'pw'), 'real_password');
      expect(prefs.getString('user_custom_pref'), 'real_value');

      // 3. settings 진입소스로 체험 모드 진입
      secureStorageCalls.clear();
      await enterDemoMode(entrySource: 'settings');
      expect(isDemoActive, isTrue);
      expect(isRuntimeDemoActive, isTrue);

      // 체험 중 자격증명 읽기 null & 쓰기 무시
      expect(await credentials.read(key: 'id'), isNull);
      expect(await credentials.read(key: 'pw'), isNull);
      expect(await credentials.read(key: 'gemini_api_key'), isNull);
      expect(await credentials.readAll(), isEmpty);
      await credentials.write(key: 'id', value: 'fake_id');
      await credentials.write(key: 'other', value: 'fake_val');
      expect(secureValues['id'], 'real_student_id');
      expect(secureValues.containsKey('other'), isFalse);

      // 체험 DB 분리 확인 및 prefs 변경
      final demoStore = await Store.open();
      final demoItems = await demoStore.items();
      await demoStore.db.close();
      expect(demoItems.any((i) => i.title == '실제 사용자 과제'), isFalse);
      expect(File(demoPath).existsSync(), isTrue);

      await prefs.setString('user_custom_pref', 'mutated_in_demo');
      await prefs.setString('radarTheme', 'light');

      // 4. 체험 모드 종료
      final exitSource = await exitDemoMode();
      expect(exitSource, 'settings');
      expect(isDemoActive, isFalse);
      expect(File(demoPath).existsSync(), isFalse);

      // 종료 후 자격증명·prefs·실제 DB 파일 그대로
      expect(await credentials.read(key: 'id'), 'real_student_id');
      expect(await credentials.read(key: 'pw'), 'real_password');
      expect(await credentials.read(key: 'gemini_api_key'), 'real_api_key');

      expect(prefs.getString('user_custom_pref'), 'real_value');
      expect(prefs.getString('radarTheme'), 'dark');
      expect(
        prefs.getString(PrefKey.widgetSnapshotJson),
        '{"realWidget":true}',
      );

      expect(realFile.existsSync(), isTrue);
      expect(await realFile.readAsBytes(), realBytesBefore);

      final reopenedReal = await Store.open();
      final realItemsAfter = await reopenedReal.items();
      await reopenedReal.db.close();
      expect(realItemsAfter.map((i) => i.title).toList(), ['실제 사용자 과제']);
    },
  );

  testWidgets(
    'SettingsHub 에 체험 항목이 체험 아닐 때만 보임',
    (tester) async {
      var demoCallbackFired = false;
      demoModeNotifier.value = false;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SettingsHub(
              connected: true,
              connect: () {},
              logout: () {},
              test: () {},
              onStartDemo: () => demoCallbackFired = true,
            ),
          ),
        ),
      );
      await settleAsync(tester);

      // 체험 아닐 때는 "체험 모드 보기" (부제 "예시 데이터로 기능 둘러보기") 표시
      expect(find.text('체험 모드 보기'), findsOneWidget);
      expect(find.text('예시 데이터로 기능 둘러보기'), findsOneWidget);

      await tester.ensureVisible(find.text('체험 모드 보기'));
      await tester.tap(find.text('체험 모드 보기'));
      await settleAsync(tester);
      expect(demoCallbackFired, isTrue);

      // 체험 중일 때는 숨김
      demoModeNotifier.value = true;
      await tester.pump();
      await settleAsync(tester);

      expect(find.text('체험 모드 보기'), findsNothing);
      expect(find.text('예시 데이터로 기능 둘러보기'), findsNothing);

      demoModeNotifier.value = false;
    },
  );

  testWidgets(
    'Dashboard: 로그인 상태에서 체험 모드 진입 시 확인 대화상자 표시 및 취소/시작 동작 확인',
    (tester) async {
      final messenger =
          TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
      messenger.setMockMethodCallHandler(secureChannel, (call) async {
        if (call.method == 'read') return 'test_user';
        if (call.method == 'readAll') return {'id': 'test_user', 'pw': 'pass'};
        return null;
      });

      await tester.pumpWidget(
        MaterialApp(
          navigatorKey: navKey,
          onGenerateRoute: buildAppRoute,
          home: const Dashboard(autoSync: false),
        ),
      );
      await settleAsync(tester);

      // Settings 탭(더보기)으로 이동
      await tester.tap(find.byIcon(Icons.settings_outlined));
      await settleAsync(tester);

      expect(find.text('체험 모드 보기'), findsOneWidget);
      await tester.ensureVisible(find.text('체험 모드 보기'));
      await tester.tap(find.text('체험 모드 보기'));
      await settleAsync(tester);

      // 확인 대화상자 확인
      expect(find.text('체험 모드로 볼까요?'), findsOneWidget);
      expect(
        find.text(
          '예시 데이터로 앱을 둘러봐요. 내 계정 데이터는 그대로 두고, [체험 끝내기]를 누르면 원래 화면으로 돌아와요.',
        ),
        findsOneWidget,
      );
      expect(find.text('취소'), findsOneWidget);
      expect(find.text('체험 시작'), findsOneWidget);

      // [취소] 누르면 대화상자 닫히고 체험 모드에 들어가지 않음
      await tester.tap(find.text('취소'));
      await settleAsync(tester);
      expect(isDemoActive, isFalse);
      expect(find.text('체험 모드로 볼까요?'), findsNothing);

      // 다시 탭하고 [체험 시작] 누르면 체험 모드 진입
      await tester.ensureVisible(find.text('체험 모드 보기'));
      await tester.tap(find.text('체험 모드 보기'));
      await settleAsync(tester);

      await tester.tap(find.text('체험 시작'));
      await settleAsync(tester);

      expect(isDemoActive, isTrue);
      expect(find.text('체험 중 · 예시 데이터'), findsOneWidget);

      // [체험 끝내기]로 종료 시 대시보드로 복귀
      await tester.tap(find.text('체험 끝내기'));
      await settleAsync(tester);
      expect(isDemoActive, isFalse);
    },
  );
}

import 'package:campus_radar/navigation/app_router.dart';
import 'package:campus_radar/ai/ai_chat_page.dart';
import 'package:campus_radar/ai/ai_hub_page.dart';
import 'package:campus_radar/settings/settings_page.dart';
import 'package:campus_radar/tasks/task_detail_page.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/main.dart';
import 'package:campus_radar/schedule/timetable_page.dart';
import 'package:campus_radar/schedule/timetable_grid.dart';
import 'package:campus_radar/schedule/timetable_model.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  setUp(() async {
    temp = await Directory.systemTemp.createTemp('radar044-');
    await databaseFactory.setDatabasesPath(temp.path);
    SharedPreferences.setMockInitialValues({});
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          (call) async => call.method == 'read' ? 'synthetic' : null,
        );
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          bridge,
          (call) async => call.method == 'timetableSettings'
              ? {
                  'enabled': false,
                  'midnight': false,
                  'lead': 30,
                  'exactAllowed': true,
                  'until': '2099-12-31',
                }
              : null,
        );
    final store = await Store.open();
    await store.setMeta(
      'courses',
      jsonEncode([
        {'course_id': 'a', 'class_no': '1', 'course_nm': '과목 A'},
        {'course_id': 'b', 'class_no': '1', 'course_nm': '과목 B'},
      ]),
    );
    await store.replace([
      for (var i = 0; i < 2; i++)
        CampusItem(
          key: 'ui$i',
          type: 'LR',
          title: '확인할 과제 ${i + 1}',
          course: i == 0 ? '과목 A' : '과목 B',
          courseId: i == 0 ? 'a' : 'b',
          classNo: '1',
          contentsId: '$i',
          status: 'pending',
          context: {'course_id': i == 0 ? 'a' : 'b', 'class_no': '1'},
          due: DateTime.now().toUtc().add(Duration(hours: i + 3)),
        ),
    ]);
    await store.setMeta(
      'timetableEntries',
      jsonEncode([
        const ClassSlot(
          courseKey: 'a:1',
          course: '과목 A',
          weekday: 2,
          start: 540,
          end: 630,
          room: '101',
          source: '화 09:00–10:30',
        ).toJson(),
      ]),
    );
    await store.db.close();
  });
  tearDown(() async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(bridge, null);
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          null,
        );
    await temp.delete(recursive: true);
  });
  Future<void> ready(WidgetTester tester, Widget page) async {
    addTearDown(() async {
      await tester.pumpWidget(const SizedBox.shrink());
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 100)),
      );
      await tester.pump();
    });
    await tester.pumpWidget(
      MaterialApp(onGenerateRoute: buildAppRoute, home: page),
    );
    await tester.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 350)),
    );
    await tester.pumpAndSettle();
  }

  Future<void> close(WidgetTester tester) async {
    await tester.pumpWidget(const SizedBox.shrink());
    await tester.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 600)),
    );
  }

  testWidgets(
    'Task filters start collapsed, cancel keeps results, apply narrows courses',
    (tester) async {
      tester.view.physicalSize = const Size(800, 960);  // ≥760: PC/tablet task list (phones use MobileTasksView)
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);

      tester.view.physicalSize = const Size(800, 1200);  // ≥760: PC/tablet task list (phones use MobileTasksView)
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await ready(tester, const Dashboard(autoSync: false));
      await tester.tap(find.byIcon(Icons.checklist).first); // side rail at ≥760
      await tester.pumpAndSettle();
      expect(find.byType(DropdownButtonFormField<String>), findsNothing);
      expect(find.text('확인할 과제 1'), findsOneWidget);
      expect(find.text('확인할 과제 2'), findsOneWidget);
      await tester.tap(find.byTooltip('필터'));
      await tester.pumpAndSettle();
      expect(find.byType(DropdownButtonFormField<String>), findsNWidgets(4));
      await tester.tap(find.text('모든 과목'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('과목 A').last);
      await tester.pumpAndSettle();
      Navigator.of(tester.element(find.text('목록 필터'))).pop();
      await tester.pumpAndSettle();
      expect(find.text('확인할 과제 2'), findsOneWidget);
      await tester.tap(find.byTooltip('필터'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('모든 과목'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('과목 A').last);
      await tester.pumpAndSettle();
      await tester.ensureVisible(find.text('결과 1개 보기'));
      await tester.tap(find.text('결과 1개 보기'));
      await tester.pumpAndSettle();
      expect(find.text('확인할 과제 1'), findsOneWidget);
      expect(find.text('확인할 과제 2'), findsNothing);
      expect(tester.takeException(), isNull);
      await close(tester);
    },
  );
  testWidgets(
    'Timetable view keeps edit choices and alarm controls off the grid; back discards draft',
    (tester) async {
      await ready(tester, const TimetablePage());
      expect(find.byType(TimetableGrid), findsOneWidget);
      expect(find.byType(CheckboxListTile), findsNothing);
      expect(find.byType(SwitchListTile), findsNothing);
      await tester.tap(find.byTooltip('시간표 편집'));
      await tester.pumpAndSettle();
      expect(find.byType(TimetableGrid), findsNothing);
      expect(find.byType(CheckboxListTile), findsOneWidget);
      await tester.tap(find.byType(CheckboxListTile));
      await tester.pumpAndSettle();
      await tester.tap(find.byTooltip('시간표로 돌아가기'));
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 600)),
      );
      await tester.pumpAndSettle();
      expect(
        tester.widget<TimetableGrid>(find.byType(TimetableGrid)).entries.length,
        1,
      );
      await tester.tap(find.byTooltip('수업·자정 알림'));
      await tester.pumpAndSettle();
      expect(find.byType(SwitchListTile), findsNWidgets(2));
      expect(find.byType(TimetableGrid), findsNothing);
      expect(tester.takeException(), isNull);
      await close(tester);
    },
  );
  testWidgets('AI hub exposes chat without sending; settings are grouped', (
    tester,
  ) async {
    await ready(tester, const AiHubPage());
    expect(find.text('무엇을 도와드릴까요?'), findsOneWidget);
    expect(find.textContaining('분석 대기열'), findsNothing);
    await tester.tap(find.text('공지나 과제에 대해 질문하기'));
    await tester.pump(const Duration(milliseconds: 400));
    await tester.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 500)),
    );
    for (var tick = 0; tick < 40; tick++) {
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 40)),
      );
      await tester.pump(const Duration(milliseconds: 50));
      if (find.text('이번 주 마감은?').evaluate().isNotEmpty) break;
    }
    await tester.pumpAndSettle();
    expect(find.text('이번 주 마감은?'), findsOneWidget);
    await tester.ensureVisible(find.text('이번 주 마감은?'));
    await tester.tap(find.text('이번 주 마감은?'));
    await tester.pumpAndSettle();
    expect(
      tester.widget<TextField>(find.byType(TextField).last).controller!.text,
      '이번 주 마감은?',
    );
    expect(tester.takeException(), isNull);
    await close(tester);
    await ready(
      tester,
      SettingsHub(connected: true, connect: () {}, logout: () {}, test: () {}),
    );
    expect(find.text('학교 연결·수집'), findsOneWidget);
    // The feature-search box now sits on top; the group is further down.
    await tester.scrollUntilVisible(find.text('화면·위젯'), 300);
    expect(find.text('화면·위젯'), findsOneWidget);
    await tester.scrollUntilVisible(find.text('기록·지원'), 100);
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.text('기록·지원'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('기록·지원'));
    await tester.pumpAndSettle();
    // 활동 로그 moved to the developer options (hidden by default).
    expect(find.text('활동 로그'), findsNothing);
    expect(find.text('앱 업데이트'), findsOneWidget);
    await close(tester);
  });
  testWidgets('Chat data choice survives reopen in both directions', (
    tester,
  ) async {
    await ready(tester, const AiChatPage());
    expect(find.text('참고 자료 선택'), findsOneWidget);
    await tester.tap(find.text('참고 자료 선택'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('과제·공지 참고하기'));
    await tester.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 250)),
    );
    await tester.pumpAndSettle();
    expect(find.text('과제·공지 참고 중'), findsOneWidget);
    await close(tester);
    await ready(tester, const AiChatPage());
    expect(find.text('과제·공지 참고 중'), findsOneWidget);
    await tester.tap(find.text('과제·공지 참고 중'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('질문과 대화만 보내기'));
    await tester.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 250)),
    );
    await tester.pumpAndSettle();
    await close(tester);
    await ready(tester, const AiChatPage());
    expect(find.text('참고 자료 선택'), findsOneWidget);
    expect(find.byType(SwitchListTile), findsNothing);
    await close(tester);
  });
  testWidgets(
    'Primary campus action remains reachable after a long description',
    (tester) async {
      final item = CampusItem(
        key: 'long',
        type: 'LR',
        title: '긴 과제 설명',
        course: '과목 A',
        courseId: 'a',
        classNo: '1',
        contentsId: 'x',
        status: 'pending',
        context: {},
        body: List.filled(120, '확인할 안내 내용이에요.').join('\n'),
      );
      await ready(tester, DetailPage(item: item));
      final button = find.text('사이버캠퍼스 열기');
      expect(button, findsOneWidget);
      final before = tester.getRect(button);
      await tester.drag(find.byType(ListView), const Offset(0, -1000));
      await tester.pumpAndSettle();
      expect(tester.getRect(button), before);
      expect(tester.takeException(), isNull);
      await close(tester);
    },
  );
}

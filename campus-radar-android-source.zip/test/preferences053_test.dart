import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/main.dart';
import 'package:campus_radar/radar_theme.dart';
import 'package:campus_radar/task_display_preferences.dart';
import 'package:campus_radar/task_cleanup_settings.dart';
import 'package:campus_radar/app_storage.dart';
import 'package:campus_radar/campus_models.dart';
import 'package:campus_radar/task_categories.dart';
import 'package:campus_radar/lock_screen_settings_page.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    radarAccent.value = RadarAccent.teal;
    radarThemeMode.value = ThemeMode.system;
    showWaitingAssignments.value = true;
    temp = await Directory.systemTemp.createTemp('radar053-');
    await databaseFactory.setDatabasesPath(temp.path);
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          (call) async => call.method == 'read' ? 'synthetic' : null,
        );
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('campus_radar/native'),
          (call) async => null,
        );
  });
  tearDown(() async {
    radarAccent.value = RadarAccent.teal;
    radarThemeMode.value = ThemeMode.system;
    showWaitingAssignments.value = true;
    for (final name in [
      'plugins.it_nomads.com/flutter_secure_storage',
      'campus_radar/native',
    ]) {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(MethodChannel(name), null);
    }
    await temp.delete(recursive: true);
  });
  test(
    'Waiting preference persists without removing stored future assignments',
    () async {
      final now = DateTime.now().toUtc();
      final item = CampusItem(
        key: 'p',
        type: 'LR',
        title: 'future',
        course: 'c',
        courseId: 'c',
        classNo: '1',
        contentsId: 'p',
        status: 'pending',
        startsAt: now.add(const Duration(days: 1)),
        context: {},
      );
      final s = await Store.open();
      try {
        await s.replace([item]);
        await saveShowWaitingAssignments(false);
        await loadTaskDisplayPreferences();
        expect(showWaitingAssignments.value, false);
        expect((await s.items()).single.key, 'p');
        expect(item.availableAt(now), false);
      } finally {
        await s.db.close();
      }
    },
  );
  testWidgets('Lock hide conditions are read and saved independently', (
    tester,
  ) async {
    var settings = <String, dynamic>{
      'enabled': false,
      'allowed': true,
      'dismissOutside': false,
      'dismissSwipe': true,
      'hideOtherWindows': false,
      'preferTop': true,
    };
    Map<String, dynamic>? saved;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(const MethodChannel('campus_radar/native'), (
          call,
        ) async {
          if (call.method == 'lockSettings') return settings;
          if (call.method == 'lockConfigure') {
            saved = Map<String, dynamic>.from(call.arguments);
            settings = {...settings, ...saved!};
          }
          return null;
        });
    await tester.pumpWidget(const RadarApp(home: LockScreenSettingsPage()));
    await tester.pumpAndSettle();
    final toggle = find.widgetWithText(SwitchListTile, '카드 바깥 터치 시 숨기기');
    await tester.scrollUntilVisible(
      toggle,
      300,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.pumpAndSettle();
    await tester.tap(toggle);
    await tester.pumpAndSettle();
    expect(saved?['dismissOutside'], true);
    expect(saved?['dismissSwipe'], true);
    expect(saved?['hideOtherWindows'], false);
    expect(saved?['preferTop'], true);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox.shrink());
  });
  test(
    'All eight palettes have readable light and dark surfaces and buttons',
    () {
      double contrast(Color a, Color b) {
        final x = a.computeLuminance(), y = b.computeLuminance();
        return ((x > y ? x : y) + .05) / ((x < y ? x : y) + .05);
      }

      expect(RadarAccent.values.length, 8);
      expect(
        RadarAccent.values
            .map(
              (a) =>
                  radarTheme(Brightness.light, accent: a).colorScheme.primary,
            )
            .toSet()
            .length,
        8,
      );
      for (final accent in RadarAccent.values) {
        for (final brightness in Brightness.values) {
          final c = radarTheme(brightness, accent: accent).colorScheme;
          expect(
            contrast(c.onSurface, c.surface),
            greaterThan(7),
            reason: '${accent.name} $brightness text',
          );
          expect(
            contrast(c.onPrimary, c.primary),
            greaterThanOrEqualTo(4.5),
            reason: '${accent.name} $brightness button',
          );
        }
      }
    },
  );
  test(
    'Color and brightness persist independently, invalid legacy values fall back',
    () async {
      await saveRadarTheme(ThemeMode.dark);
      await saveRadarAccent(RadarAccent.purple);
      radarAccent.value = RadarAccent.teal;
      await loadRadarTheme();
      expect(radarAccent.value, RadarAccent.purple);
      expect(radarThemeMode.value, ThemeMode.dark);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('radarAccent', 'unsupported');
      await loadRadarTheme();
      expect(radarAccent.value, RadarAccent.teal);
      expect(radarThemeMode.value, ThemeMode.dark);
    },
  );
  testWidgets(
    'Changing color keeps the open route and applies app-wide immediately',
    (tester) async {
      await tester.pumpWidget(
        RadarApp(
          home: Builder(
            builder: (context) => Scaffold(
              body: TextButton(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => const AppearancePage(),
                  ),
                ),
                child: const Text('open theme'),
              ),
            ),
          ),
        ),
      );
      await tester.tap(find.text('open theme'));
      await tester.pumpAndSettle();
      await tester.ensureVisible(find.text('퍼플'));
      await tester.pumpAndSettle();
      await tester.tap(find.widgetWithText(ChoiceChip, '퍼플'));
      await tester.pumpAndSettle();
      expect(find.text('화면 테마'), findsOneWidget);
      expect(
        tester
            .widget<MaterialApp>(find.byType(MaterialApp))
            .theme!
            .colorScheme
            .primary,
        radarTheme(
          Brightness.light,
          accent: RadarAccent.purple,
        ).colorScheme.primary,
      );
      await tester.pageBack();
      await tester.pumpAndSettle();
      expect(find.text('open theme'), findsOneWidget);
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox.shrink());
    },
  );
  testWidgets(
    'Waiting setting hides category immediately, survives reload and preserves collected items',
    (tester) async {
      final now = DateTime.now().toUtc();
      final future = CampusItem(
        key: 'future',
        type: 'LR',
        title: 'future report',
        course: 'Synthetic',
        courseId: 'c',
        classNo: '1',
        contentsId: '1',
        status: 'pending',
        startsAt: now.add(const Duration(days: 1)),
        context: {},
      );
      await tester.runAsync(() async {
        final s = await Store.open();
        await s.replace([future]);
        await s.db.close();
      });
      await tester.pumpWidget(const RadarApp(home: Dashboard(autoSync: false)));
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 350)),
      );
      await tester.pumpAndSettle();
      await tester.tap(find.widgetWithText(NavigationDestination, '할 일'));
      await tester.pumpAndSettle();
      expect(find.text('제출 대기 1'), findsOneWidget);
      await tester.tap(find.text('제출 대기 1'));
      await tester.pumpAndSettle();
      expect(find.text('future report'), findsOneWidget);
      await tester.runAsync(() => saveShowWaitingAssignments(false));
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 200)),
      );
      await tester.pump(const Duration(milliseconds: 500));
      expect(find.textContaining('제출 대기 1'), findsNothing);
      expect(find.text('future report'), findsNothing);
      expect(future.availableAt(now), false);
      expect(categoryMatches(future, now, {}, waiting: true), true);
      await tester.runAsync(() => saveShowWaitingAssignments(true));
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 200)),
      );
      await tester.pump(const Duration(milliseconds: 500));
      expect(find.text('제출 대기 1'), findsOneWidget);
      expect(find.text('future report'), findsOneWidget);
      await tester.pumpWidget(const RadarApp(home: TaskCleanupSettings()));
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 150)),
      );
      await tester.pumpAndSettle();
      expect(find.text('제출 시작 전 과제 보기'), findsOneWidget);
      await tester.pumpWidget(const SizedBox.shrink());
    },
  );
}

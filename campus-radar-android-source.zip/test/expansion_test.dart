import 'dart:convert';
import 'dart:io';
import 'package:campus_radar/ai.dart';
import 'package:campus_radar/campus.dart';
import 'package:campus_radar/chat.dart';
import 'package:campus_radar/expansion_pages.dart';
import 'package:campus_radar/services.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  late Directory temp;
  late Store store;
  var account = 'synthetic-account';
  var secret = 'synthetic-key';
  setUp(() async {
    courseAliases = {};
    SharedPreferences.setMockInitialValues({});
    temp = await Directory.systemTemp.createTemp('radar-expansion-');
    await databaseFactory.setDatabasesPath(temp.path);
    store = await Store.open();
    account = 'synthetic-account';
    secret = 'synthetic-key';
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
          (c) async => c.method == 'read'
              ? (c.arguments['key'] == 'id' ? account : secret)
              : null,
        );
  });
  tearDown(() async {
    await store.db.close();
    await temp.delete(recursive: true);
    courseAliases = {};
  });
  CampusItem task(
    String key, {
    String course = 'c1',
    bool published = true,
    DateTime? starts,
  }) => CampusItem(
    key: key,
    type: 'LR',
    title: 'Task $key',
    course: '컴퓨터프로그래밍2',
    courseId: course,
    classNo: '1',
    contentsId: key,
    status: 'pending',
    due: DateTime.now().toUtc().add(const Duration(days: 2)),
    published: published,
    startsAt: starts,
    context: {'course_id': course, 'class_no': '1'},
  );
  Map<String, dynamic> answer(String text) => {
    'candidates': [
      {
        'finishReason': 'STOP',
        'content': {
          'parts': [
            {'text': text},
          ],
        },
      },
    ],
  };
  test(
    'Alias persists, preserves original serialized name, and clears',
    () async {
      final i = task('a');
      await setCourseAlias(i.course, '컴프2');
      expect(courseLabel(i.course), '컴프2');
      expect(i.toJson()['course'], '컴퓨터프로그래밍2');
      courseAliases = {};
      await loadCourseAliases();
      expect(courseLabel(i.course), '컴프2');
      await setCourseAlias(i.course, '');
      expect(courseLabel(i.course), i.course);
    },
  );
  test('Course catalog retains classes with no tasks or notices', () async {
    await store.setMeta(
      'courses',
      jsonEncode([
        {'course_id': 'empty', 'class_no': '1', 'course_nm': 'Empty class'},
      ]),
    );
    await store.replace([task('a')]);
    final courses = await readCourses(store);
    expect(courses.map(courseKey), containsAll(['empty:1', 'c1:1']));
  });
  test(
    'Chat context excludes hidden, future-start, and other-course tasks',
    () async {
      await store.replace([
        task('visible'),
        task('excluded'),
        task('hidden', published: false),
        task(
          'future',
          starts: DateTime.now().toUtc().add(const Duration(days: 1)),
        ),
        task('other', course: 'c2'),
      ]);
      await store.setMeta('excluded:excluded', 'yes');
      final data = jsonDecode(await chatContext(store, courseId: 'c1:1'));
      expect((data['items'] as List).map((i) => i['title']), ['Task visible']);
    },
  );
  test('Chat requires explicit consent before any transport', () async {
    var calls = 0;
    await expectLater(
      askCampusAi(
        store,
        [],
        'hello',
        transport: (k, r) async {
          calls++;
          return answer('hi');
        },
      ),
      throwsA(isA<AiFailure>()),
    );
    expect(calls, 0);
  });
  test(
    'No-sharing chat does not send current campus data or credentials as content',
    () async {
      await store.replace([task('private')]);
      await store.setMeta('aiChatConsent', '1');
      Map<String, dynamic>? captured;
      final value = await askCampusAi(
        store,
        [],
        'hello',
        transport: (k, r) async {
          expect(k, secret);
          captured = r;
          return answer('안녕하세요');
        },
      );
      expect(value, '안녕하세요');
      final body = jsonEncode(captured);
      expect(body, isNot(contains('Task private')));
      expect(body, isNot(contains(secret)));
      expect(body, isNot(contains(account)));
      expect(await store.meta('aiNetworkUntil'), '0');
    },
  );
  test(
    'Account changes discard in-flight chat response and release lease',
    () async {
      await store.setMeta('aiChatConsent', '1');
      await expectLater(
        askCampusAi(
          store,
          [],
          'hello',
          transport: (k, r) async {
            account = 'different-account';
            return answer('do not save');
          },
        ),
        throwsA(isA<AiFailure>()),
      );
      expect(await store.meta('aiNetworkUntil'), '0');
    },
  );
  test('Quota failure releases shared AI lease', () async {
    await store.setMeta('aiChatConsent', '1');
    await expectLater(
      askCampusAi(
        store,
        [],
        'hello',
        transport: (k, r) async =>
            throw const AiFailure('quota', code: 'quota'),
      ),
      throwsA(isA<AiFailure>()),
    );
    expect(await store.meta('aiNetworkUntil'), '0');
  });
  test('Blocked or empty chat output is not accepted', () {
    expect(
      () => chatResponse({
        'candidates': [
          {'finishReason': 'SAFETY'},
        ],
      }),
      throwsA(isA<AiFailure>()),
    );
    expect(() => chatResponse(answer('')), throwsA(isA<AiFailure>()));
  });
  test('Chat history sends bounded alternating conversational turns', () {
    final history = List.generate(
      30,
      (n) => {'role': n.isEven ? 'user' : 'model', 'text': 'turn$n'},
    );
    final r = chatRequest(history, 'latest', 'none');
    expect((r['contents'] as List).length, 13);
    expect(r['contents'].first['parts'].first['text'], 'turn18');
    expect(r['contents'].last['parts'].first['text'], 'latest');
  });
  testWidgets('Course page has four sections and visible alias action', (
    tester,
  ) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: CoursePage(
          course: {
            'course_id': 'c1',
            'class_no': '1',
            'course_nm': '컴퓨터프로그래밍2',
          },
        ),
      ),
    );
    await tester.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 250)),
    );
    await tester.pumpAndSettle();
    expect(find.text('과제'), findsOneWidget);
    expect(find.text('콘텐츠'), findsOneWidget);
    expect(find.text('공지'), findsOneWidget);
    expect(find.text('강의계획서'), findsOneWidget);
    expect(find.byTooltip('약자 설정'), findsOneWidget);
    await tester.pumpWidget(const SizedBox.shrink());
  });
  testWidgets('Lock settings preserve privacy and never enable automatically', (
    tester,
  ) async {
    final calls = <MethodCall>[];
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(bridge, (c) async {
          calls.add(c);
          return {
            'enabled': false,
            'allowed': false,
            'mode': 'compact',
            'position': 'right',
            'details': false,
          };
        });
    await tester.pumpWidget(const MaterialApp(home: LockScreenSettingsPage()));
    await tester.pumpAndSettle();
    expect(calls.every((c) => c.method == 'lockSettings'), isTrue);
    expect(find.text('접근성 서비스 설정 열기'), findsOneWidget);
    await tester.drag(find.byType(ListView), const Offset(0, -350));
    await tester.pumpAndSettle();
    expect(
      tester
          .widget<SwitchListTile>(
            find.widgetWithText(SwitchListTile, '과목명·과제명 표시'),
          )
          .value,
      isFalse,
    );
    await tester.pumpWidget(const SizedBox.shrink());
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(bridge, null);
  });
}

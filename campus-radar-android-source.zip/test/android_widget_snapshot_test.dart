import 'dart:convert';
import 'dart:io';

import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/platform/android_widget_snapshot.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

CampusItem makeItem({
  required String key,
  required String title,
  required String course,
  String type = 'LR',
  String status = 'pending',
  DateTime? due,
  DateTime? startsAt,
  bool published = true,
}) =>
    CampusItem(
      key: key,
      title: title,
      course: course,
      type: type,
      status: status,
      due: due,
      startsAt: startsAt,
      published: published,
      courseId: 'c',
      classNo: '1',
      contentsId: key,
      context: const {},
    );

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;

  group('WidgetSnapshotPayload.buildSnapshot', () {
    test('filters out excluded and unavailable items and formats discovered map', () {
      final now = DateTime.utc(2026, 11, 5, 10, 0);
      final items = [
        makeItem(
          key: 'task-1',
          title: '과제 1',
          course: '자료구조',
          due: DateTime.utc(2026, 11, 5, 12, 0),
        ),
        makeItem(
          key: 'task-excluded',
          title: '제외된 과제',
          course: '자료구조',
          due: DateTime.utc(2026, 11, 5, 14, 0),
        ),
        makeItem(
          key: 'task-future',
          title: '미래 시작 과제',
          course: '자료구조',
          startsAt: DateTime.utc(2026, 11, 5, 11, 0),
          due: DateTime.utc(2026, 11, 6, 12, 0),
        ),
      ];

      final meta = {
        'discovered:task-1': '2026-11-05T08:00:00Z',
        'discovered:task-excluded': '2026-11-05T08:00:00Z',
        'otherMeta': 'ignored',
      };

      final snapshot = WidgetSnapshotPayload.buildSnapshot(
        items: items,
        excludedKeys: {'task-excluded'},
        lastSuccess: '2026-11-05T09:30:00Z',
        connected: true,
        metaEntries: meta,
        now: now,
      );

      expect(snapshot['connected'], isTrue);
      expect(snapshot['last'], '2026-11-05T09:30:00Z');

      final active = snapshot['items'] as List<dynamic>;
      expect(active.length, 1);
      expect(active.first['key'], 'task-1');
      expect(active.first['title'], '과제 1');

      final discovered = snapshot['discovered'] as Map<String, String>;
      expect(discovered['discovered:task-1'], '2026-11-05T08:00:00Z');
      expect(discovered.containsKey('otherMeta'), isFalse);
    });
  });

  group('publishAndroidWidgetSnapshot and clearAndroidWidgetSnapshot', () {
    late Directory tempDir;

    setUp(() async {
      tempDir = await Directory.systemTemp.createTemp('widget-snapshot-test-');
      await databaseFactory.setDatabasesPath(tempDir.path);
      SharedPreferences.setMockInitialValues({});
    });

    tearDown(() async {
      if (await tempDir.exists()) {
        await tempDir.delete(recursive: true);
      }
    });

    test('publishes snapshot and timetable to SharedPreferences and clears on logout', () async {
      final store = await Store.open();
      try {
        await store.setMeta('initialized', 'yes');
        await store.setMeta(MetaKey.lastSuccess, '2026-11-05T09:00:00Z');
        await store.setMeta(
          MetaKey.timetableEntries,
          jsonEncode([
            {'course': '컴퓨터구조', 'weekday': 1, 'start': 600, 'end': 660},
          ]),
        );
        await store.setMeta('discovered:hw1', '2026-11-05T08:00:00Z');

        final item = makeItem(
          key: 'hw1',
          title: '어셈블리 과제',
          course: '컴퓨터구조',
          due: DateTime.utc(2026, 11, 6, 15, 0),
        );
        await store.db.insert('items', {
          'id': 'hw1',
          'payload': jsonEncode(item.toJson()),
        });

        final prefs = await SharedPreferences.getInstance();

        // Publish
        await publishAndroidWidgetSnapshot(store, prefs: prefs);

        final rawSnapshot = prefs.getString(PrefKey.widgetSnapshotJson);
        expect(rawSnapshot, isNotNull);

        final parsedSnapshot = jsonDecode(rawSnapshot!) as Map<String, dynamic>;
        expect(parsedSnapshot['connected'], isTrue);
        expect(parsedSnapshot['last'], '2026-11-05T09:00:00Z');
        final items = parsedSnapshot['items'] as List<dynamic>;
        expect(items.length, 1);
        expect(items.first['title'], '어셈블리 과제');

        final rawTimetable = prefs.getString(PrefKey.widgetTimetableJson);
        expect(rawTimetable, isNotNull);
        final timetable = jsonDecode(rawTimetable!) as List<dynamic>;
        expect(timetable.first['course'], '컴퓨터구조');

        // Clear
        await clearAndroidWidgetSnapshot(prefs: prefs);
        expect(prefs.getString(PrefKey.widgetSnapshotJson), isNull);
        expect(prefs.getString(PrefKey.widgetTimetableJson), isNull);
      } finally {
        await store.db.close();
      }
    });
  });
}

import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/updates.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const native = MethodChannel('campus_radar/native');
  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(native, null);
    installedAppVersion = appVersion;
    installedAppBuild = appBuild;
  });
  test('Fallback version and build match the APK source version', () {
    final source = File('pubspec.yaml').readAsStringSync();
    expect(
      RegExp(
        r'^version:\s*(\S+)',
        multiLine: true,
      ).firstMatch(source)!.group(1),
      '$appVersion+$appBuild',
    );
  });
  test('Installed package overrides stale display metadata', () async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          native,
          (call) async => {'name': '9.8.7', 'code': 987},
        );
    await loadInstalledVersion();
    expect(installedAppVersion, '9.8.7');
    expect(installedAppBuild, 987);
  });
  test(
    'Bridge failure preserves previously confirmed installed version',
    () async {
      installedAppVersion = '9.8.7';
      installedAppBuild = 987;
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(
            native,
            (call) async => throw PlatformException(code: 'unavailable'),
          );
      await loadInstalledVersion();
      expect(installedAppVersion, '9.8.7');
      expect(installedAppBuild, 987);
    },
  );
}

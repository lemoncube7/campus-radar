// P8 repro: home/list count contracts on the Dashboard (read-only QA).
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/home/home_navigation.dart';
import 'package:campus_radar/main.dart';
import 'package:campus_radar/core/ui_refresh.dart';

CampusItem item(String key, String type, String status, {DateTime? due}) =>
    CampusItem(
      key: key,
      type: type,
      title: 'T-$key',
      course: '가상 과목',
      courseId: 'c',
      classNo: '1',
      contentsId: key,
      status: status,
      due: due,
      context: const {},
    );

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  late Directory temp;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    homeNavigation.value = null;
    temp = await Directory.systemTemp.createTemp('p8-');
    await databaseFactory.setDatabasesPath(temp.path);
    final m = TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    m.setMockMethodCallHandler(
      const MethodChannel('plugins.it_nomads.com/flutter_secure_storage'),
      (c) async => c.method == 'read' ? 'synthetic' : null,
    );
    m.setMockMethodCallHandler(
      const MethodChannel('campus_radar/native'),
      (c) async => null,
    );
  });
  tearDown(() async {
    final m = TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    for (final ch in [
      'plugins.it_nomads.com/flutter_secure_storage',
      'campus_radar/native',
    ]) {
      m.setMockMethodCallHandler(MethodChannel(ch), null);
    }
    await temp.delete(recursive: true);
  });
  Future<void> settle(WidgetTester t) async {
    for (var i = 0; i < 8; i++) {
      await t.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 70)));
      await t.pump();
    }
  }

  Future<void> seed(List<CampusItem> items, Map<String, String> meta) async {
    final s = await Store.open();
    try {
      await s.replace(items);
      for (final e in meta.entries) {
        await s.setMeta(e.key, e.value);
      }
    } finally {
      await s.db.close();
    }
  }

  Future<void> pumpDash(WidgetTester t) async {
    t.view.physicalSize = const Size(800, 1400);  // ≥760: PC/tablet task list (phones use MobileTasksView)
    t.view.devicePixelRatio = 1;
    addTearDown(t.view.resetPhysicalSize);
    addTearDown(t.view.resetDevicePixelRatio);
    await t.pumpWidget(const RadarApp(home: Dashboard(autoSync: false)));
    await settle(t);
  }

  Future<void> close(WidgetTester t) async {
    await t.pumpWidget(const SizedBox.shrink());
    await settle(t);
  }

  testWidgets('home 24h count matches the 24h list it links to', (t) async {
    final soon = DateTime.now().toUtc().add(const Duration(hours: 3));
    await t.runAsync(() => seed([item('LQ:c:1:q', 'LQ', 'unknown', due: soon)], {}));
    await pumpDash(t);
    // The task list's "24시간 이내" filter (deadlineState) would include this quiz.
    expect(deadlineState(soon) == DeadlineState.withinDay, isTrue);
    expect(find.text('24시간 이내 1개 마감'), findsOneWidget,
        reason: 'home must lead with the 24h deadline it links to');
    expect(find.textContaining('24시간 이내 마감 없음'), findsNothing,
        reason: 'home claims no 24h deadline although a quiz is due in 3h');
    await close(t);
  });

  testWidgets('"숨김 N" chip equals rows shown under the hidden filter', (t) async {
    final later = DateTime.now().toUtc().add(const Duration(days: 3));
    await t.runAsync(() => seed(
      [item('LR:c:1:a', 'LR', 'pending', due: later)],
      {'notTask:LR:c:1:a': 'yes', 'excluded:LR:c:1:gone': 'yes'},
    ));
    await pumpDash(t);
    await t.tap(find.text('전체 보기'));
    await settle(t);
    final chip = find.textContaining('숨김 ');
    final label = (t.widget<Text>(chip.first)).data!;
    await t.tap(chip.first);
    await settle(t);
    // Hidden list should contain as many rows as the chip announced.
    final rows = t.widget<Text>(find.textContaining('개 · 공개')).data;
    expect(rows, startsWith('${label.substring(3)}개'), reason: 'chip said "$label"');
    await close(t);
  });

  testWidgets('due-sorted list shows each section heading once', (t) async {
    await t.runAsync(() => seed([
      item('LS:c:1:m1', 'LS', 'available'),
      item('LR:c:1:x', 'LR', 'pending'),
      item('LS:c:1:m2', 'LS', 'available'),
    ], {}));
    await pumpDash(t);
    await t.tap(find.text('전체 보기'));
    await settle(t);
    expect(find.text('3개 · 공개·시작된 항목만 표시'), findsOneWidget);
    final heads = t.widgetList<SectionHeading>(find.byType(SectionHeading))
        .map((h) => h.title).toList();
    expect(heads.toSet().length, heads.length, reason: 'headings: $heads');
    await close(t);
  });
}

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/home/modern_task_card.dart';
import 'package:campus_radar/tasks/task_evaluation.dart';

void main() {
  testWidgets('ModernTaskCard renders score badge and feedback when evaluated', (tester) async {
    final itemWithEvaluation = CampusItem(
      key: 'evaluated-task',
      type: 'LR',
      title: '데이터베이스 4주차 정규화 실습 과제',
      course: '데이터베이스',
      courseId: 'c10',
      classNo: '1',
      contentsId: 'cnt10',
      status: 'done',
      due: DateTime.utc(2026, 10, 20),
      evaluation: const TaskEvaluation(
        score: '95',
        maximum: '100',
        feedback: '정규형 단계별 전개가 명확하고 함수 종속 다이어그램이 우수합니다.',
      ),
      context: const {'course_id': 'c10', 'class_no': '1'},
    );

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: ModernTaskCard(
            item: itemWithEvaluation,
            onTap: () {},
          ),
        ),
      ),
    );

    expect(find.text('95/100점'), findsOneWidget);
    expect(find.byIcon(Icons.grade_rounded), findsOneWidget);
    expect(find.textContaining('피드백: 정규형 단계별 전개'), findsOneWidget);
  });
}

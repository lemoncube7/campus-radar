import 'dart:io';

import 'package:campus_radar/core/developer_mode.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/session/background_status_page.dart';
import 'package:campus_radar/settings/settings_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;

  late Directory tempDir;

  setUp(() async {
    tempDir = Directory.systemTemp.createTempSync('campus_dev_test_');
    await databaseFactory.setDatabasesPath(tempDir.path);
    SharedPreferences.setMockInitialValues({});
    await initDeveloperMode();
    developerModeNotifier.value = false;
  });

  tearDown(() {
    try {
      tempDir.deleteSync(recursive: true);
    } catch (_) {}
  });

  Future<void> settleAsync(WidgetTester tester) async {
    for (var i = 0; i < 10; i++) {
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 20)),
      );
      await tester.pump(const Duration(milliseconds: 50));
    }
  }

  Widget buildSettingsHub() {
    return MaterialApp(
      home: Scaffold(
        body: SettingsHub(
          connected: true,
          connect: () {},
          logout: () {},
          test: () {},
        ),
      ),
    );
  }

  testWidgets(
    '버전 7번 탭 → 켜짐·prefs 저장, 6번이면 안 켜짐, 끄기 동작',
    (tester) async {
      await tester.pumpWidget(buildSettingsHub());
      await settleAsync(tester);

      final versionFinder = find.textContaining('캠퍼스레이더');
      await tester.scrollUntilVisible(
        versionFinder,
        300,
        scrollable: find.byType(Scrollable).first,
      );
      await tester.pumpAndSettle();
      expect(versionFinder, findsOneWidget);

      // Tap 6 times with short delay (within 2s)
      for (var i = 1; i <= 6; i++) {
        await tester.tap(versionFinder);
        await tester.pump(const Duration(milliseconds: 100));
      }

      // After 6 taps, developer mode is still OFF
      expect(developerModeNotifier.value, isFalse);
      expect(isDeveloperMode, isFalse);
      final prefs = await SharedPreferences.getInstance();
      expect(prefs.getBool(PrefKey.developerMode), isNot(true));

      // 6th tap should show snackbar: "개발자 모드까지 1번 남았어요"
      expect(find.text('개발자 모드까지 1번 남았어요'), findsOneWidget);

      // 7th tap activates developer mode
      await tester.tap(versionFinder);
      await tester.pump(const Duration(milliseconds: 100));

      expect(developerModeNotifier.value, isTrue);
      expect(isDeveloperMode, isTrue);
      expect(prefs.getBool(PrefKey.developerMode), isTrue);
      expect(find.text('개발자 모드를 켰어요'), findsOneWidget);

      // 8th tap shows "이미 개발자 모드예요"
      await tester.tap(versionFinder);
      await tester.pump(const Duration(milliseconds: 100));
      expect(find.text('이미 개발자 모드예요'), findsOneWidget);

      // Verify "개발자 옵션" appears in SettingsHub
      await tester.pump(const Duration(milliseconds: 100));
      final devOptionFinder = find.text('개발자 옵션');
      await tester.scrollUntilVisible(
        devOptionFinder,
        -100,
        scrollable: find.byType(Scrollable).first,
      );
      expect(devOptionFinder, findsOneWidget);

      // Tap "개발자 옵션" to navigate into it
      await tester.tap(devOptionFinder);
      await settleAsync(tester);

      // Top item should be [개발자 모드 끄기]
      final turnOffFinder = find.text('개발자 모드 끄기');
      expect(turnOffFinder, findsOneWidget);

      // Tap "개발자 모드 끄기"
      await tester.tap(turnOffFinder);
      await settleAsync(tester);

      // Developer mode turned OFF and saved in prefs
      expect(developerModeNotifier.value, isFalse);
      expect(isDeveloperMode, isFalse);
      expect(prefs.getBool(PrefKey.developerMode), isFalse);

      // Navigated back to SettingsHub and "개발자 옵션" is hidden
      expect(find.text('개발자 옵션'), findsNothing);
    },
  );

  testWidgets(
    '꺼져 있을 때 설정에 활동 로그·알림 표시 테스트 안 보임, 켜면 개발자 옵션 안에 보임',
    (tester) async {
      // 1. 꺼져 있을 때
      developerModeNotifier.value = false;
      await tester.pumpWidget(buildSettingsHub());
      await settleAsync(tester);

      // 개발자 옵션이 보이지 않음
      expect(find.text('개발자 옵션'), findsNothing);

      // 활동 로그·알림 표시 테스트가 설정 메인에 보이지 않음
      expect(find.text('활동 로그'), findsNothing);
      expect(find.text('알림 표시 테스트'), findsNothing);

      // 기록·지원 안에도 활동 로그·알림 표시 테스트가 없어야 함
      final supportFinder = find.text('기록·지원');
      await tester.scrollUntilVisible(
        supportFinder,
        300,
        scrollable: find.byType(Scrollable).first,
      );
      expect(supportFinder, findsOneWidget);
      await tester.tap(supportFinder);
      await settleAsync(tester);

      expect(find.text('활동 로그'), findsNothing);
      expect(find.text('알림 표시 테스트'), findsNothing);
      expect(find.text('변경 이력'), findsOneWidget);
      expect(find.text('앱 업데이트'), findsOneWidget);
      expect(find.text('업데이트 내역'), findsOneWidget);

      // Pop back to SettingsHub
      Navigator.of(tester.element(find.text('변경 이력'))).pop();
      await settleAsync(tester);

      // 2. 켜져 있을 때
      await setDeveloperMode(true);
      await settleAsync(tester);

      final devOptions = find.text('개발자 옵션');
      await tester.scrollUntilVisible(
        devOptions,
        300,
        scrollable: find.byType(Scrollable).first,
      );
      expect(devOptions, findsOneWidget);
      await tester.tap(devOptions);
      await settleAsync(tester);

      // 개발자 옵션 화면 안에 활동 로그와 알림 표시 테스트가 보임
      expect(find.text('개발자 모드 끄기'), findsOneWidget);
      expect(find.text('활동 로그'), findsOneWidget);
      expect(find.text('알림 표시 테스트'), findsOneWidget);
    },
  );

  testWidgets(
    'background_status_page 상세 진단 섹션 조건',
    (tester) async {
      // 1. 꺼져 있을 때
      developerModeNotifier.value = false;
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(body: BackgroundStatusPage()),
        ),
      );
      await settleAsync(tester);

      expect(find.text('상세 진단·수집 시험'), findsNothing);

      // 2. 켜져 있을 때
      developerModeNotifier.value = true;
      await settleAsync(tester);

      expect(find.text('상세 진단·수집 시험'), findsOneWidget);
    },
  );
}

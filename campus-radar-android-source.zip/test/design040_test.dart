import 'package:campus_radar/app_storage.dart';
import 'package:campus_radar/course_labels.dart';
import 'package:campus_radar/campus_models.dart';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/main.dart';
import 'package:campus_radar/radar_theme.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  late Directory temp;
  const secure = MethodChannel('plugins.it_nomads.com/flutter_secure_storage');
  setUp(() async {
    temp = await Directory.systemTemp.createTemp('radar040-');
    await databaseFactory.setDatabasesPath(temp.path);
    SharedPreferences.setMockInitialValues({});
    radarThemeMode.value = ThemeMode.system;
    courseAliases = {'컴퓨터프로그래밍 2': '컴프2'};
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          secure,
          (c) async => c.method == 'read' ? 'synthetic' : null,
        );
  });
  tearDown(() async {
    final cleanup = await Store.open();
    await cleanup.db.close();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(secure, null);
    courseAliases = {};
    radarThemeMode.value = ThemeMode.system;
    await temp.delete(recursive: true);
  });
  test(
    'Theme preference survives reload and unknown preference follows system',
    () async {
      await saveRadarTheme(ThemeMode.dark);
      radarThemeMode.value = ThemeMode.light;
      await loadRadarTheme();
      expect(radarThemeMode.value, ThemeMode.dark);
      await (await SharedPreferences.getInstance()).setString(
        'radarTheme',
        'invalid',
      );
      await loadRadarTheme();
      expect(radarThemeMode.value, ThemeMode.system);
      for (final b in Brightness.values) {
        final c = radarTheme(b).colorScheme;
        final contrast =
            (c.onSurface.computeLuminance() + .05) /
            (c.surface.computeLuminance() + .05);
        expect(contrast > 1 ? contrast : 1 / contrast, greaterThan(7));
      }
    },
  );
  testWidgets(
    'Theme choice applies immediately throughout app and preserves navigation',
    (tester) async {
      await tester.pumpWidget(const RadarApp(home: AppearancePage()));
      await tester.pumpAndSettle();
      await tester.ensureVisible(find.text('다크'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('다크'));
      await tester.pumpAndSettle();
      expect(
        tester.widget<MaterialApp>(find.byType(MaterialApp)).themeMode,
        ThemeMode.dark,
      );
      expect(find.text('화면 테마'), findsOneWidget);
      expect(
        (await SharedPreferences.getInstance()).getString('radarTheme'),
        'dark',
      );
      await tester.pumpWidget(const SizedBox.shrink());
    },
  );
  testWidgets(
    'Completed assignment filter hides pending tasks and completed content',
    (tester) async {
      await tester.runAsync(() async {
        final s = await Store.open();
        await s.replace([
          for (var i = 0; i < 3; i++)
            CampusItem(
              key: 'filter$i',
              type: i == 2 ? 'LV' : 'LR',
              title: ['완료 과제 예시', '미완료 과제 예시', '완료 콘텐츠 예시'][i],
              course: '테스트',
              courseId: 'c',
              classNo: '1',
              contentsId: '$i',
              status: i == 1 ? 'pending' : 'done',
              context: {},
            ),
        ]);
        await s.db.close();
      });
      await tester.pumpWidget(const RadarApp(home: Dashboard(autoSync: false)));
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 350)),
      );
      await tester.pumpAndSettle();
      await tester.tap(find.widgetWithText(NavigationDestination, '할 일'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('제출 완료 과제'));
      await tester.pumpAndSettle();
      expect(find.text('완료 과제 예시'), findsOneWidget);
      expect(find.text('미완료 과제 예시'), findsNothing);
      expect(find.text('완료 콘텐츠 예시'), findsNothing);
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox.shrink());
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 250)),
      );
    },
  );
  for (final dark in [false, true]) {
    testWidgets(
      'Actual dashboard ${dark ? 'dark' : 'light'} shows tasks before summary, renders narrow enlarged text',
      (tester) async {
        final font = File('C:/Windows/Fonts/malgun.ttf');
        if (font.existsSync()) {
          await tester.runAsync(
            () =>
                (FontLoader('Roboto')..addFont(
                      Future.value(
                        ByteData.sublistView(font.readAsBytesSync()),
                      ),
                    ))
                    .load(),
          );
          await tester.runAsync(
            () =>
                (FontLoader('Ahem')..addFont(
                      Future.value(
                        ByteData.sublistView(font.readAsBytesSync()),
                      ),
                    ))
                    .load(),
          );
          final icons = File(
            '../../work/tools/flutter/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf',
          );
          if (icons.existsSync()) {
            await tester.runAsync(
              () =>
                  (FontLoader('MaterialIcons')..addFont(
                        Future.value(
                          ByteData.sublistView(icons.readAsBytesSync()),
                        ),
                      ))
                      .load(),
            );
          }
        }
        tester.view.physicalSize = const Size(390, 900);
        tester.view.devicePixelRatio = 1;
        radarThemeMode.value = dark ? ThemeMode.dark : ThemeMode.light;
        await tester.runAsync(() async {
          final s = await Store.open();
          final now = DateTime.now().toUtc();
          await s.replace([
            for (var i = 0; i < 3; i++)
              CampusItem(
                key: 'synthetic$i',
                type: i == 2 ? 'LV' : 'LR',
                title: ['7주차 실습 과제', '연습문제 제출', '온라인 강의 수강'][i],
                course: ['컴퓨터프로그래밍 2', '선형대수', '물리'][i],
                courseId: 'c$i',
                classNo: '1',
                contentsId: 'i$i',
                status: 'pending',
                context: {},
                due: now.add(Duration(hours: [3, 24, 72][i])),
              ),
          ]);
          await s.saveNotice(
            CampusNotice(
              id: 'synthetic',
              title: '중간고사 안내',
              course: '컴퓨터프로그래밍 2',
              body: '테스트 자료',
              context: {},
              published: now,
            ),
          );
          await s.setMeta('lastSuccess', now.toIso8601String());
          await s.db.close();
        });
        final key = GlobalKey();
        await tester.pumpWidget(
          RepaintBoundary(
            key: key,
            child: const RadarApp(home: Dashboard(autoSync: false)),
          ),
        );
        await tester.runAsync(
          () => Future<void>.delayed(const Duration(milliseconds: 350)),
        );
        await tester.pumpAndSettle();
        expect(find.text('먼저 할 일'), findsOneWidget);
        expect(find.text('컴프2'), findsWidgets);
        expect(find.text('7주차 실습 과제'), findsOneWidget);
        expect(tester.takeException(), isNull);
        // Optional review artifacts; all data above is synthetic.
        if (const bool.fromEnvironment('CAPTURE_DESIGN')) {
          final boundary =
              key.currentContext!.findRenderObject() as RenderRepaintBoundary;
          await tester.runAsync(() async {
            final img = await boundary.toImage(pixelRatio: 2);
            final bytes = await img.toByteData(format: ui.ImageByteFormat.png);
            final f = File('../../work/040-${dark ? 'dark' : 'light'}.png');
            await f.writeAsBytes(bytes!.buffer.asUint8List());
            img.dispose();
          });
        }
        tester.view.physicalSize = const Size(320, 740);
        await tester.pumpWidget(
          RadarApp(
            home: MediaQuery(
              data: MediaQueryData(
                size: const Size(320, 740),
                textScaler: TextScaler.linear(1.8),
              ),
              child: const Dashboard(autoSync: false),
            ),
          ),
        );
        await tester.runAsync(
          () => Future<void>.delayed(const Duration(milliseconds: 350)),
        );
        await tester.pumpAndSettle();
        expect(tester.takeException(), isNull);
        await tester.pumpWidget(const SizedBox.shrink());
        tester.view.resetPhysicalSize();
        tester.view.resetDevicePixelRatio();
      },
    );
  }
}

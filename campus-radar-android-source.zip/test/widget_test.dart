import 'package:campus_radar/core/startup_diagnostics.dart';
import 'package:campus_radar/navigation/app_router.dart';
import 'package:campus_radar/tasks/task_detail_page.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/main.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';

class _FakeDatabaseException implements DatabaseException {
  final String message;
  const _FakeDatabaseException(this.message);
  @override
  String toString() => message;
  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

void main() {
  test('retryDatabaseOpen retries busy errors with increasing delays', () async {
    final recorded = <Duration>[];
    var attempts = 0;
    final result = await retryDatabaseOpen(
      () async {
        attempts++;
        if (attempts < 4) {
          throw const _FakeDatabaseException(
            'DatabaseException(database is locked (code 5 SQLITE_BUSY))',
          );
        }
        return 'ok';
      },
      delay: (d) async => recorded.add(d),
      delays: startupBusyRetryDelays,
      maxWait: const Duration(seconds: 10),
    );
    expect(result, 'ok');
    expect(attempts, 4);
    expect(recorded, [
      const Duration(seconds: 1),
      const Duration(seconds: 2),
      const Duration(seconds: 3),
    ]);
  });
  testWidgets(
    'Startup DB lock retries on loading screen and opens without error',
    (tester) async {
      SharedPreferences.setMockInitialValues({});
      var attempts = 0;
      await tester.pumpWidget(
        MaterialApp(
          onGenerateRoute: buildAppRoute,
          home: StartupGate(
            initializer: () async {
              attempts++;
              if (attempts <= 2) {
                throw const _FakeDatabaseException(
                  'DatabaseException(database is locked (code 5 SQLITE_BUSY))',
                );
              }
              return null;
            },
          ),
        ),
      );
      await tester.pump();
      expect(attempts, 1);
      expect(find.text('기기 설정을 준비하고 있어요.'), findsOneWidget);
      expect(find.byType(CircularProgressIndicator), findsOneWidget);
      expect(
        find.text('다른 작업이 저장소를 사용하고 있어요. 잠시 후 다시 시도해 주세요.'),
        findsNothing,
      );
      expect(find.text('다시 시도'), findsNothing);

      // First retry after 1 second: still locked, still showing normal loading.
      await tester.pump(const Duration(seconds: 1));
      expect(attempts, 2);
      expect(find.text('기기 설정을 준비하고 있어요.'), findsOneWidget);
      expect(
        find.text('다른 작업이 저장소를 사용하고 있어요. 잠시 후 다시 시도해 주세요.'),
        findsNothing,
      );
      expect(find.text('다시 시도'), findsNothing);

      // Second retry after 2 more seconds: succeeds and opens Dashboard.
      await tester.pump(const Duration(seconds: 2));
      await tester.pump();
      expect(attempts, 3);
      expect(find.byType(Dashboard), findsOneWidget);
      expect(find.text('기기 설정을 준비하고 있어요.'), findsNothing);
      expect(
        find.text('다른 작업이 저장소를 사용하고 있어요. 잠시 후 다시 시도해 주세요.'),
        findsNothing,
      );
    },
  );
  testWidgets(
    'Startup DB lock shows busy advice and retry button after retries exhaust',
    (tester) async {
      var attempts = 0;
      await tester.pumpWidget(
        MaterialApp(
          onGenerateRoute: buildAppRoute,
          home: StartupGate(
            initializer: () async {
              attempts++;
              throw const _FakeDatabaseException(
                'DatabaseException(database is locked (code 5 SQLITE_BUSY))',
              );
            },
          ),
        ),
      );
      await tester.pump();
      expect(attempts, 1);
      expect(find.text('기기 설정을 준비하고 있어요.'), findsOneWidget);
      expect(find.text('다시 시도'), findsNothing);

      // Advance through 1s + 2s + 3s = 6s: still retrying on loading screen.
      for (final seconds in [1, 2, 3]) {
        await tester.pump(Duration(seconds: seconds));
        expect(find.text('기기 설정을 준비하고 있어요.'), findsOneWidget);
        expect(find.text('다시 시도'), findsNothing);
      }
      expect(attempts, 4);

      // Final 4s retry (total 10s) still fails -> shows advice + retry button.
      await tester.pump(const Duration(seconds: 4));
      await tester.pump();
      expect(attempts, 5);
      expect(
        find.text('다른 작업이 저장소를 사용하고 있어요. 잠시 후 다시 시도해 주세요.'),
        findsOneWidget,
      );
      expect(find.text('다시 시도'), findsOneWidget);
    },
  );
  testWidgets('Startup failure renders a retry screen instead of hiding UI', (
    tester,
  ) async {
    var attempts = 0;
    await tester.pumpWidget(
      MaterialApp(
        onGenerateRoute: buildAppRoute,
        home: StartupGate(
          initializer: () async {
            attempts++;
            throw PlatformException(code: 'invalid_icon');
          },
        ),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.text('캠퍼스레이더'), findsNWidgets(2));
    expect(find.textContaining('invalid_icon'), findsOneWidget);
    expect(find.text('다시 시도'), findsOneWidget);
    await tester.tap(find.text('다시 시도'));
    await tester.pumpAndSettle();
    expect(attempts, 2);
  });
  testWidgets('Item detail has deadline, state and campus shortcut', (
    tester,
  ) async {
    final item = CampusItem(
      key: 'test',
      type: 'LR',
      title: '과제 상세 테스트',
      course: '테스트 수업',
      courseId: 'c',
      classNo: '1',
      contentsId: 't',
      status: 'pending',
      body: '제출 안내',
      due: DateTime.utc(2026, 10, 21, 14, 59),
      context: {},
    );
    await tester.pumpWidget(
      MaterialApp(
        onGenerateRoute: buildAppRoute,
        home: DetailPage(item: item),
      ),
    );
    expect(find.text('과제 상세 테스트'), findsOneWidget);
    expect(find.text('미제출'), findsOneWidget);
    expect(find.text('사이버캠퍼스 열기'), findsOneWidget);
    await tester.tap(find.byType(PopupMenuButton<String>));
    await tester.pumpAndSettle();
    expect(find.text('목록에서 숨기기'), findsOneWidget);
    await tester.tap(find.text('목록에서 숨기기'));
    await tester.pumpAndSettle();
    expect(find.text('목록에서 숨길까요?'), findsOneWidget);
    await tester.tap(find.text('취소'));
    await tester.pumpAndSettle();
    expect(find.text('목록에서 숨기기'), findsNothing);
  });
  testWidgets('Excluded detail provides a restore action', (tester) async {
    final item = CampusItem(
      key: 'hidden',
      type: 'LR',
      title: '제외된 과제',
      course: '수업',
      courseId: 'c',
      classNo: '1',
      contentsId: 't',
      status: 'pending',
      context: {},
    );
    await tester.pumpWidget(
      MaterialApp(
        onGenerateRoute: buildAppRoute,
        home: DetailPage(item: item, excluded: true),
      ),
    );
    await tester.tap(find.byType(PopupMenuButton<String>));
    await tester.pumpAndSettle();
    expect(find.text('목록에 복구'), findsOneWidget);
    expect(find.text('숨김 · 알림 꺼짐'), findsOneWidget);
  });
  test('Korean campus time is parsed independently of device timezone', () {
    expect(
      campusDate('2026-10-21 23:59:00'),
      DateTime.utc(2026, 10, 21, 14, 59),
    );
    expect(campusDate('unknown'), isNull);
  });
  test('Persisted item preserves identity, status and UTC deadline', () {
    final i = CampusItem(
      key: 'LR:c:1:task',
      type: 'LR',
      title: '과제',
      course: '수업',
      courseId: 'c',
      classNo: '1',
      contentsId: 'task',
      status: 'pending',
      due: DateTime.utc(2026, 10, 21, 14, 59),
      context: {'report_no': 'task'},
    );
    final restored = CampusItem.fromJson(i.toJson());
    expect(restored.key, i.key);
    expect(restored.due, i.due);
    expect(restored.done, isFalse);
    expect(restored.context['report_no'], 'task');
  });
  test('HTML display text discards script markup', () {
    expect(textOf('<p>제출 <b>안내</b></p>'), '제출 안내');
  });
}

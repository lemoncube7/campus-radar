import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite/sqflite.dart';
import 'package:campus_radar/foreground_entry.dart';
import 'package:campus_radar/startup_diagnostics.dart';

class DbFault implements DatabaseException {
  final String message;
  DbFault(this.message);
  @override
  String toString() => message;
  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

void main() {
  test('foreground visit ignores permission dialogs and resumes only once', () {
    final gate = ForegroundEntry();
    expect(gate.update(AppLifecycleState.resumed), false);
    gate.update(AppLifecycleState.inactive);
    expect(gate.update(AppLifecycleState.resumed), false);
    gate.update(AppLifecycleState.paused);
    expect(gate.update(AppLifecycleState.resumed), true);
    expect(gate.update(AppLifecycleState.resumed), false);
  });
  test(
    'only transient database locks retry; full/corrupt never retry or reset',
    () async {
      var attempts = 0;
      final value = await retryDatabaseOpen(() async {
        if (++attempts < 3) throw DbFault('database is locked');
        return 'retained';
      }, delay: (_) async {});
      expect(value, 'retained');
      expect(attempts, 3);
      for (final error in [
        'database or disk is full',
        'database disk image is malformed',
      ]) {
        attempts = 0;
        await expectLater(
          retryDatabaseOpen(() async {
            attempts++;
            throw DbFault(error);
          }, delay: (_) async {}),
          throwsA(isA<DbFault>()),
        );
        expect(attempts, 1);
      }
    },
  );
  test(
    'startup diagnostic retains category and stage without SQL or secrets',
    () {
      final result = startupDiagnostic(
        DbFault('SQLITE_BUSY password=private select secrets'),
        '설정 복원',
      );
      expect(result['storageCode'], 'busy');
      expect(result.toString(), isNot(contains('private')));
      expect(storageFailureCode(DbFault('no such table: meta')), 'schema');
      expect(storageFailureCode(DbFault('sqlite_cantopen')), 'access');
    },
  );
}

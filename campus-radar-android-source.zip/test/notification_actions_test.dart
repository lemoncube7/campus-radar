import 'package:flutter_test/flutter_test.dart';

import 'package:campus_radar/core/notification_gateway.dart';

void main() {
  test('notification buttons route before the payload', () {
    expect(notificationTarget(notificationActionTasks, 'LR:x'), '_tasks');
    expect(notificationTarget(notificationActionReview, 'NOTICE:1'), '_review');
    expect(notificationTarget(null, 'NOTICE:1'), 'NOTICE:1');
    expect(notificationTarget('', null), isNull);
  });
}

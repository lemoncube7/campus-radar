import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:campus_radar/ai_protocol.dart';
import 'package:campus_radar/campus_models.dart';

void main() {
  test(
    'enumerated days inherit month and explicit year only inside one date list',
    () {
      for (final date in ['2026-10-26', '2026-10-28']) {
        validateAiAnchor(date, '', '2026년 10월 26일(월), 28일(수) 휴강');
      }
      for (final evidence in [
        '2026년 10월 26일(월), 28일(수) 휴강',
        '10월 26일 안내\n28일 휴강',
        '10월 26일 공지. 28일 이내 제출',
        '10월 26일, 28일 동안 준비',
      ]) {
        final date = evidence.startsWith('2026') ? '2027-10-28' : '2026-10-28';
        expect(
          () => validateAiAnchor(date, '', evidence),
          throwsA(isA<AiFailure>()),
          reason: evidence,
        );
      }
    },
  );
  test(
    'day-only selected body uses exact title date without requiring a timetable',
    () {
      final n = CampusNotice(
        id: 'example',
        title: '10월 26일(월), 28일(수) 휴강 안내',
        course: '예시',
        context: {},
        body: '이번 주 수요일(28일)에 시험이 있고 이번 주에는 수업을 진행하지 않습니다.',
        published: DateTime.utc(2026, 10, 25),
        bodyFetched: true,
      );
      Map<String, dynamic> response(String date) => {
        'candidates': [
          {
            'finishReason': 'STOP',
            'content': {
              'parts': [
                {
                  'text': jsonEncode({
                    'events': [
                      {
                        'title': '시험',
                        'date': date,
                        'time': '',
                        'category': 'exam',
                        'action': 'add',
                        'sourceIds': ['P1'],
                        'uncertainty': '',
                        'endDate': '',
                        'endTime': '',
                        'condition': 'required',
                      },
                    ],
                  }),
                },
              ],
            },
          },
        ],
      };
      final c = parseAiResponse(response('2026-10-28'), n).single;
      expect(c.sourceQuotes, contains(n.title));
      expect(c.date, '2026-10-28');
      expect(
        () => parseAiResponse(response('2026-10-27'), n),
        throwsA(isA<AiFailure>()),
      );
    },
  );
}

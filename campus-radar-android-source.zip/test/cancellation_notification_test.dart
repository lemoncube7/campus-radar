import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:campus_radar/ai/ai_cancellation_notification.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/ai/ai_state_models.dart';
import 'package:campus_radar/ai/ai_state_repository.dart';
import 'package:campus_radar/ai/notice_ai_service.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/navigation_key.dart';
import 'package:campus_radar/core/notification_gateway.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/main.dart';
import 'package:campus_radar/navigation/app_navigation.dart';
import 'package:campus_radar/navigation/app_router.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';
import 'package:campus_radar/schedule/timetable_exceptions.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late Directory tempDir;

  setUp(() async {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfiNoIsolate;
    tempDir = await Directory.systemTemp.createTemp('cancel_notif_test_');
    await databaseFactory.setDatabasesPath(tempDir.path);
    FlutterSecureStorage.setMockInitialValues({});
    SharedPreferences.setMockInitialValues({});
    final messenger =
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    messenger.setMockMethodCallHandler(
      const MethodChannel('window_manager'),
      (call) async => call.method == 'isMinimized' ? false : null,
    );
    messenger.setMockMethodCallHandler(
      const MethodChannel('campus_radar/native'),
      (_) async => null,
    );
  });

  tearDown(() async {
    final messenger =
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    messenger.setMockMethodCallHandler(
      const MethodChannel('window_manager'),
      null,
    );
    messenger.setMockMethodCallHandler(
      const MethodChannel('campus_radar/native'),
      null,
    );
    try {
      await tempDir.delete(recursive: true);
    } catch (_) {}
  });

  CampusNotice sampleNotice({
    String id = 'n101',
    String course = '알고리즘',
    Map<String, dynamic> context = const {'course_id': 'c1', 'class_no': '1'},
  }) => CampusNotice(
    id: id,
    title: '11월 10일 휴강 안내',
    course: course,
    body: '11월 10일 화요일 수업은 학회 참석으로 휴강합니다. 보강은 11월 14일 진행합니다.',
    bodyFetched: true,
    published: DateTime.utc(2026, 11, 5),
    context: context,
  );

  ScheduleCandidate sampleCancelCandidate({
    String title = '수업 휴강',
    String date = '2026-11-10',
    String time = '',
    String evidence = '11월 10일 화요일 수업은 학회 참석으로 휴강합니다.',
  }) => ScheduleCandidate(
    title: title,
    date: date,
    time: time,
    action: 'cancel',
    evidence: evidence,
    uncertainty: '',
    category: 'class',
  );

  Future<void> saveTimetable(Store store, List<ClassSlot> slots) async {
    await store.setMeta(
      MetaKey.timetableEntries,
      jsonEncode(slots.map((s) => s.toJson()).toList()),
    );
  }

  Future<void> pumpIO(WidgetTester tester, {int rounds = 12}) async {
    for (var i = 0; i < rounds; i++) {
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 15)),
      );
      await tester.pump(const Duration(milliseconds: 50));
    }
  }

  test(
    'cancellation payload encodes, parses, and stays distinct from NOTICE payloads',
    () {
      final notice = sampleNotice(id: 'n101');
      final candidate = sampleCancelCandidate();
      final key = candidateKey(notice, candidate);
      final payload = cancellationNotificationPayload(notice.id, key);

      expect(payload.startsWith('CANCEL:'), isTrue);
      expect(payload.startsWith('NOTICE:'), isFalse);

      final parsed = parseCancellationNotificationPayload(payload);
      expect(parsed, isNotNull);
      expect(parsed!.noticeId, 'n101');
      expect(parsed.candidateKey, key);

      final colonNotice = sampleNotice(id: '2026:c1:01:99');
      final colonKey = candidateKey(colonNotice, candidate);
      final colonPayload = cancellationNotificationPayload(
        colonNotice.id,
        colonKey,
      );
      final colonParsed = parseCancellationNotificationPayload(colonPayload);
      expect(colonParsed, isNotNull);
      expect(colonParsed!.noticeId, '2026:c1:01:99');
      expect(colonParsed.candidateKey, colonKey);

      for (final invalid in [
        null,
        '',
        'NOTICE:n101',
        'CANCEL:',
        'CANCEL:n101',
        'CANCEL:n101:',
        'CANCEL::abc',
        'CANCEL:n101:a:b',
        'CANCEL:%ZZ:abc',
      ]) {
        expect(parseCancellationNotificationPayload(invalid), isNull);
      }

      expect(applyCancellationAction.showsUserInterface, isTrue);
      expect(applyCancellationAction.title, '시간표에 반영');
      expect(notificationTarget(null, payload), payload);
      expect(
        notificationTarget(notificationActionApplyCancellation, payload),
        payload,
      );
    },
  );

  test(
    'notifies once when class cancellation matches timetable slot and prevents duplicates',
    () async {
      final store = await Store.open();
      addTearDown(() => store.db.close());

      await saveTimetable(store, const [
        ClassSlot(
          courseKey: 'c1:1',
          course: '알고리즘',
          weekday: 2, // Tuesday (2026-11-10 is Tuesday)
          start: 600,
          end: 690,
          room: '공5-401',
        ),
      ]);

      final notice = sampleNotice();
      await store.saveNotice(notice);
      final cancelMatch = sampleCancelCandidate();
      const makeupAdd = ScheduleCandidate(
        title: '보강 수업',
        date: '2026-11-14',
        time: '',
        action: 'add',
        evidence: '보강은 11월 14일 진행합니다.',
        uncertainty: '',
        category: 'class',
      );
      final unmatchedWeekday = sampleCancelCandidate(
        title: '다른 요일 휴강',
        date: '2026-11-11', // Wednesday: no slot
      );
      final events = [cancelMatch, makeupAdd, unmatchedWeekday];
      await rememberCandidates(store, notice, events);

      final sent = <Map<String, String>>[];
      var allowNotifications = false;

      // Respects disabled notification state without consuming the candidate.
      final blockedCount = await notifyConfirmedCancellations(
        store,
        notice,
        events,
        notifier: ({
          required key,
          required title,
          required body,
          required payload,
        }) async {
          if (!allowNotifications) return false;
          sent.add({
            'key': key,
            'title': title,
            'body': body,
            'payload': payload,
          });
          return true;
        },
      );
      expect(blockedCount, 0);
      expect(sent, isEmpty);

      if (Platform.isWindows) {
        SharedPreferences.setMockInitialValues({
          PrefKey.desktopNotifications: false,
        });
        expect(await cancellationNotificationsPermitted(), isFalse);
        SharedPreferences.setMockInitialValues({
          PrefKey.desktopNotifications: true,
        });
        expect(await cancellationNotificationsPermitted(), isTrue);
      }

      allowNotifications = true;
      final firstCount = await notifyConfirmedCancellations(
        store,
        notice,
        events,
        notifier: ({
          required key,
          required title,
          required body,
          required payload,
        }) async {
          sent.add({
            'key': key,
            'title': title,
            'body': body,
            'payload': payload,
          });
          return true;
        },
      );
      expect(firstCount, 1);
      expect(sent, hasLength(1));
      expect(sent.single['title'], '휴강 감지: 알고리즘');
      expect(sent.single['body'], '11월 10일(화) 수업 · 눌러서 시간표에 반영');
      expect(
        sent.single['payload'],
        cancellationNotificationPayload(
          notice.id,
          candidateKey(notice, cancelMatch),
        ),
      );

      // Duplicate call with same candidate sends nothing.
      final secondCount = await notifyConfirmedCancellations(
        store,
        notice,
        events,
        notifier: ({
          required key,
          required title,
          required body,
          required payload,
        }) async {
          sent.add({'key': key});
          return true;
        },
      );
      expect(secondCount, 0);
      expect(sent, hasLength(1));

      // Reworded candidate on the same notice for the same slot/date also sends nothing.
      final reworded = sampleCancelCandidate(title: '학회 참석 휴강');
      final thirdCount = await notifyConfirmedCancellations(
        store,
        notice,
        [reworded],
        notifier: ({
          required key,
          required title,
          required body,
          required payload,
        }) async {
          sent.add({'key': key});
          return true;
        },
      );
      expect(thirdCount, 0);
      expect(sent, hasLength(1));
    },
  );

  test(
    'skips candidates already applied to timetable or excluded by user',
    () async {
      final store = await Store.open();
      addTearDown(() => store.db.close());

      const slot = ClassSlot(
        courseKey: 'c1:1',
        course: '알고리즘',
        weekday: 2,
        start: 600,
        end: 690,
      );
      await saveTimetable(store, const [slot]);

      // 1) Candidate marked classCancellationApplied in AiStateRepository.
      final notice1 = sampleNotice(id: 'n1');
      final cand1 = sampleCancelCandidate();
      await store.saveNotice(notice1);
      await rememberCandidates(store, notice1, [cand1]);
      final key1 = candidateKey(notice1, cand1);
      await AiStateRepository(store).saveSchedule(
        key1,
        ConfirmedSchedule.fromJson({
          'status': 'excluded',
          'resolution': 'classCancellationApplied',
        }),
      );

      var calls = 0;
      await notifyConfirmedCancellations(
        store,
        notice1,
        [cand1],
        notifier: ({
          required key,
          required title,
          required body,
          required payload,
        }) async {
          calls++;
          return true;
        },
      );
      expect(calls, 0);

      // 2) Candidate excluded by user.
      final notice2 = sampleNotice(id: 'n2');
      final cand2 = sampleCancelCandidate();
      await store.saveNotice(notice2);
      await rememberCandidates(store, notice2, [cand2]);
      final key2 = candidateKey(notice2, cand2);
      await AiStateRepository(store).saveSchedule(
        key2,
        ConfirmedSchedule.fromJson({}).withDecision(ScheduleDecision.excluded),
      );
      await notifyConfirmedCancellations(
        store,
        notice2,
        [cand2],
        notifier: ({
          required key,
          required title,
          required body,
          required payload,
        }) async {
          calls++;
          return true;
        },
      );
      expect(calls, 0);

      // 3) Cancellation already present in CancellationRepository.
      final notice3 = sampleNotice(id: 'n3');
      final cand3 = sampleCancelCandidate();
      await store.saveNotice(notice3);
      await rememberCandidates(store, notice3, [cand3]);
      await CancellationRepository(store).apply([
        ClassCancellation(
          '2026-11-10:${slot.id}',
          slot.id,
          '2026-11-10',
          slot.course,
          notice3.title,
        ),
      ]);
      await notifyConfirmedCancellations(
        store,
        notice3,
        [cand3],
        notifier: ({
          required key,
          required title,
          required body,
          required payload,
        }) async {
          calls++;
          return true;
        },
      );
      expect(calls, 0);
    },
  );

  testWidgets(
    'notification tap opens pre-filled CancellationEditor, applies cancellation, and supports undo',
    (tester) async {
      final notice = sampleNotice();
      final candidate = sampleCancelCandidate();
      late String key;
      late String payload;
      await tester.runAsync(() async {
        final seed = await Store.open();
        try {
          await saveTimetable(seed, const [
            ClassSlot(
              courseKey: 'c1:1',
              course: '알고리즘',
              weekday: 2,
              start: 600,
              end: 690,
              room: '공5-401',
            ),
          ]);
          await seed.saveNotice(notice);
          await rememberCandidates(seed, notice, [candidate]);
          key = candidateKey(notice, candidate);
          payload = cancellationNotificationPayload(notice.id, key);
        } finally {
          await seed.db.close();
        }
      });

      await tester.pumpWidget(
        MaterialApp(
          navigatorKey: navKey,
          onGenerateRoute: buildAppRoute,
          home: const Scaffold(body: Text('홈')),
        ),
      );

      final routed = notificationTarget(
        notificationActionApplyCancellation,
        payload,
      );
      unawaited(openItem(routed));
      await pumpIO(tester);

      // Pre-filled CancellationEditor opens without auto-applying in background.
      expect(find.text('시간표에 휴강 반영'), findsOneWidget);
      expect(find.text(notice.title), findsOneWidget);
      expect(find.text('2026-11-10 · 알고리즘'), findsOneWidget);

      final beforeRows = await tester.runAsync(() async {
        final checkBefore = await Store.open();
        try {
          return await readClassCancellations(checkBefore);
        } finally {
          await checkBefore.db.close();
        }
      });
      expect(beforeRows, isEmpty);

      // User confirms save on CancellationEditor.
      await tester.tap(find.text('선택한 날짜·수업에 휴강 적용'));
      await pumpIO(tester);

      expect(find.text('홈'), findsOneWidget);
      expect(find.text('선택한 수업에 휴강을 반영했어요'), findsOneWidget);
      expect(find.text('실행 취소'), findsOneWidget);

      final appliedCheck = await tester.runAsync(() async {
        final afterApply = await Store.open();
        try {
          final saved = await readClassCancellations(afterApply);
          final state = await AiStateRepository(afterApply).schedule(key);
          return (saved: saved, state: state);
        } finally {
          await afterApply.db.close();
        }
      });
      expect(appliedCheck!.saved, hasLength(1));
      expect(appliedCheck.saved.single.date, '2026-11-10');
      expect(appliedCheck.state.decision, ScheduleDecision.excluded);
      expect(
        appliedCheck.state.toJson()['resolution'],
        'classCancellationApplied',
      );

      // User taps undo in SnackBar.
      await tester.tap(find.text('실행 취소'));
      await pumpIO(tester);
      await tester.pump(const Duration(seconds: 9));

      final undoCheck = await tester.runAsync(() async {
        final afterUndo = await Store.open();
        try {
          final saved = await readClassCancellations(afterUndo);
          final state = await AiStateRepository(afterUndo).schedule(key);
          return (saved: saved, state: state);
        } finally {
          await afterUndo.db.close();
        }
      });
      expect(undoCheck!.saved, isEmpty);
      expect(undoCheck.state.decision, ScheduleDecision.review);
      expect(undoCheck.state.toJson().containsKey('resolution'), isFalse);
    },
  );

  testWidgets(
    'cold launch opens pre-filled CancellationEditor and missing candidate opens review inbox',
    (tester) async {
      final notice = sampleNotice();
      final candidate = sampleCancelCandidate();
      late String payload;
      await tester.runAsync(() async {
        final seed = await Store.open();
        try {
          await saveTimetable(seed, const [
            ClassSlot(
              courseKey: 'c1:1',
              course: '알고리즘',
              weekday: 2,
              start: 600,
              end: 690,
            ),
          ]);
          await seed.saveNotice(notice);
          await rememberCandidates(seed, notice, [candidate]);
          final key = candidateKey(notice, candidate);
          payload = cancellationNotificationPayload(notice.id, key);
        } finally {
          await seed.db.close();
        }
      });

      // Cold launch via StartupGate with notification launch target.
      await tester.pumpWidget(
        RadarApp(
          home: StartupGate(
            initializer: () async => notificationTarget(
              notificationActionApplyCancellation,
              payload,
            ),
          ),
        ),
      );
      await pumpIO(tester);

      expect(find.text('시간표에 휴강 반영'), findsOneWidget);
      expect(find.text('2026-11-10 · 알고리즘'), findsOneWidget);

      // Navigate back and verify missing/deleted candidate opens review inbox.
      Navigator.of(navKey.currentContext!).pop();
      await pumpIO(tester);

      final missingPayload = cancellationNotificationPayload(
        'deleted-notice',
        'AI:deleted-notice:000000000000000000000000',
      );
      unawaited(openItem(missingPayload));
      await pumpIO(tester);

      expect(find.text('검토함'), findsOneWidget);
    },
  );
}

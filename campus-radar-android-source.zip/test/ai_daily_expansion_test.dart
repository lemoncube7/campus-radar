import 'package:campus_radar/app_router.dart';
import 'package:campus_radar/ai_daily_card.dart';
import 'package:campus_radar/app_storage.dart';
import 'package:campus_radar/school_time.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

Future<void> settle(WidgetTester tester) async {
  await tester.runAsync(
    () => Future<void>.delayed(const Duration(milliseconds: 100)),
  );
  await tester.pumpAndSettle();
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfiNoIsolate;
  testWidgets(
    'Cached long summary expands, scrolls, selects and reopens without storage collision',
    (tester) async {
      late Directory directory;
      final now = DateTime.now().toUtc();
      final last = now.toIso8601String();
      final summary = List.generate(
        40,
        (i) => '${i + 1}. 컴프2 과제와 물리 수업의 마감을 확인하세요.',
      ).join('\n');
      await tester.runAsync(() async {
        directory = await Directory.systemTemp.createTemp('daily0411-');
        await databaseFactory.setDatabasesPath(directory.path);
        final store = await Store.open();
        await store.setMeta('aiSummary', 'yes');
        await store.setMeta('lastSuccess', last);
        await store.db.close();
      });
      SharedPreferences.setMockInitialValues({
        'aiSummaryLast': last,
        'aiSummaryDay': schoolDay(now),
        'aiSummaryHour': now.millisecondsSinceEpoch ~/ 3600000,
        'aiSummaryExpires': now
            .add(const Duration(hours: 1))
            .millisecondsSinceEpoch,
        'aiSummaryText': summary,
      });
      final bucket = PageStorageBucket();
      await tester.pumpWidget(
        MaterialApp(
          onGenerateRoute: buildAppRoute,
          home: Scaffold(
            body: PageStorage(
              bucket: bucket,
              child: ListView(
                key: const PageStorageKey('today-scroll'),
                children: const [
                  SizedBox(height: 100),
                  AiDailyCard(),
                  SizedBox(height: 300),
                ],
              ),
            ),
          ),
        ),
      );
      await settle(tester);
      expect(find.text('수집된 목록에서 우선 확인할 일'), findsOneWidget);
      await tester.tap(find.text('AI 데일리 요약'));
      await settle(tester);
      expect(find.text(summary), findsOneWidget);
      expect(find.byType(SelectionArea), findsOneWidget);
      expect(tester.takeException(), isNull);
      await tester.drag(find.byType(ListView), const Offset(0, -700));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      await tester.drag(find.byType(ListView), const Offset(0, 2500));
      await tester.pumpAndSettle();
      await tester.tap(find.text('AI 데일리 요약'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('AI 데일리 요약'));
      await tester.pumpAndSettle();
      expect(find.text(summary), findsOneWidget);
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox.shrink());
      await tester.runAsync(() => directory.delete(recursive: true));
    },
  );
}

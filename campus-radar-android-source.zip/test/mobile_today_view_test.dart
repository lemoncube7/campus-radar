import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/home/mobile_today_view.dart';
import 'package:campus_radar/home/modern_task_card.dart';
import 'package:campus_radar/home/today_hero_briefing.dart';

void main() {
  CampusItem mockItem({
    required String key,
    required String title,
    required String course,
    DateTime? due,
    bool done = false,
  }) =>
      CampusItem(
        key: key,
        title: title,
        course: course,
        courseId: 'c-$course',
        classNo: '1',
        contentsId: key,
        context: {'course_id': 'c-$course', 'class_no': '1'},
        type: 'LR',
        status: done ? 'done' : 'pending',
        due: due,
      );

  group('TodayHeroBriefing', () {
    testWidgets('renders today briefing stats correctly', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: TodayHeroBriefing(
              now: DateTime.utc(2026, 11, 5, 9, 0),
              urgentCount: 2,
              todayCount: 1,
              pendingCount: 4,
              lastSyncTime: '2026-11-05T08:00:00Z',
            ),
          ),
        ),
      );

      expect(find.text('놓치지 않도록 지금 바로 확인하세요'), findsOneWidget);
      expect(find.text('24시간 이내 마감 2개'), findsOneWidget);
      expect(find.text('1개'), findsOneWidget); // 오늘 마감
      expect(find.text('4개'), findsOneWidget); // 미완료 할 일
      expect(find.text('동기화 완료'), findsOneWidget);
    });

    testWidgets('renders relaxed state when no urgent tasks exist', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: TodayHeroBriefing(
              now: DateTime.utc(2026, 11, 5, 9, 0),
              urgentCount: 0,
              todayCount: 0,
              pendingCount: 2,
            ),
          ),
        ),
      );

      expect(find.text('오늘의 학업 요약'), findsOneWidget);
      expect(find.text('24시간 이내 마감'), findsNothing);
      expect(find.text('0개'), findsOneWidget);
      expect(find.text('2개'), findsOneWidget);
    });
  });

  group('ModernTaskCard', () {
    testWidgets('renders task card with course tag, title and due badge', (tester) async {
      final item = mockItem(
        key: 't1',
        title: '알고리즘 과제 1 제출',
        course: '알고리즘',
        due: DateTime.utc(2026, 11, 5, 14, 59),
      );

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: ModernTaskCard(
              item: item,
              onTap: () {},
            ),
          ),
        ),
      );

      expect(find.text('알고리즘 과제 1 제출'), findsOneWidget);
      expect(find.byType(ModernTaskCard), findsOneWidget);
    });
  });

  group('MobileTodayView', () {
    testWidgets('shows empty placeholder when there are no pending tasks', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: MobileTodayView(
              now: DateTime.utc(2026, 11, 5, 9, 0),
              pendingItems: const [],
              urgentCount: 0,
              todayCount: 0,
              excludedKeys: const {},
              visibilityBusy: const {},
              isBusy: false,
              localRevision: 0,
              onRefresh: () {},
              onShowAllTasks: () {},
              onShowUrgentTasks: () {},
              onTaskTap: (_) {},
              onTaskVisibilityToggle: (_) {},
            ),
          ),
        ),
      );

      expect(find.text('앞으로 마감할 과제가 없어요!'), findsOneWidget);
      expect(find.text('전체 보기'), findsOneWidget);
    });
  });
}

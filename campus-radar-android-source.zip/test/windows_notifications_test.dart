import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:campus_radar/campus.dart';
import 'package:campus_radar/services.dart';

class TestWindowsAlerts extends FlutterLocalNotificationsPlatform
    implements FlutterLocalNotificationsWindows {
  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
  final shown = <int>[];
  final cancelled = <int>[];
  @override
  Future<void> show(
    int id,
    String? title,
    String? body, {
    String? payload,
    WindowsNotificationDetails? details,
  }) async {
    shown.add(id);
  }

  @override
  Future<void> cancel(int id) async {
    cancelled.add(id);
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  late Directory temp;
  late Store store;
  late TestWindowsAlerts alerts;
  setUp(() async {
    debugDefaultTargetPlatformOverride = TargetPlatform.windows;
    SharedPreferences.setMockInitialValues({});
    alerts = TestWindowsAlerts();
    FlutterLocalNotificationsPlatform.instance = alerts;
    temp = await Directory.systemTemp.createTemp('radar-windows-alerts-');
    await databaseFactory.setDatabasesPath(temp.path);
    store = await Store.open();
  });
  tearDown(() async {
    await store.db.close();
    await temp.delete(recursive: true);
    debugDefaultTargetPlatformOverride = null;
  });
  CampusItem item(int hours, {String status = 'pending'}) => CampusItem(
    key: 'windows-test',
    type: 'LR',
    title: 'Synthetic',
    course: 'Synthetic',
    courseId: 'c',
    classNo: '1',
    contentsId: 'x',
    status: status,
    due: DateTime.now().toUtc().add(Duration(hours: hours)),
    context: {},
  );
  Future<void> seed(CampusItem i) async {
    await store.replace([i]);
    await store.db.update('events', {'delivered': 1});
  }

  test(
    'Desktop future reminder is tracked without using unsupported OS scheduler',
    () async {
      final i = item(25);
      await seed(i);
      await reconcile(store);
      expect(alerts.shown, isEmpty);
      expect(
        (await SharedPreferences.getInstance()).getStringList('scheduled'),
        ['due:${i.key}:${i.due!.toIso8601String()}'],
      );
    },
  );
  test(
    'Desktop due reminder sends once, then completion removes tracked token',
    () async {
      final i = item(23);
      await seed(i);
      await reconcile(store);
      await reconcile(store);
      expect(alerts.shown.length, 1);
      await seed(item(23, status: 'done'));
      await reconcile(store);
      expect(alerts.shown.length, 1);
      expect(
        (await SharedPreferences.getInstance()).getStringList('scheduled'),
        isEmpty,
      );
    },
  );
}

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:campus_radar/home/onboarding_page.dart';
import 'package:campus_radar/home/setup_checklist.dart';
import 'package:campus_radar/schedule/calendar_settings_page.dart';

void main() {
  test('presets turn on what they promise', () {
    final all = presetPlan(SetupPreset.all);
    expect(all.deadlineLeads, [1440, 180]);
    expect([all.classAlerts, all.midnightSummary, all.dailySummary], [
      true,
      true,
      true,
    ]);
    final essential = presetPlan(SetupPreset.essential);
    expect(essential.deadlineLeads, [1440]);
    expect(essential.dailySummary, isFalse);
  });

  test('findDeviceCalendar prioritizes local/device calendar', () {
    final list = [
      {'id': 1, 'name': '회사 업무', 'account': 'work@corp.com'},
      {'id': 2, 'name': '내 캘린더', 'account': 'phone'},
      {'id': 3, 'name': '개인 일정', 'account': 'user@gmail.com'},
    ];
    final device = findDeviceCalendar(list);
    expect(device?['id'], 2);
    expect(device?['name'], '내 캘린더');

    // No device calendar: null, never an account calendar as fallback.
    final fallbackList = [
      {'id': 10, 'name': '구글 캘린더', 'account': 'user@gmail.com'},
    ];
    expect(findDeviceCalendar(fallbackList), isNull);
    expect(findDeviceCalendar([]), isNull);
  });

  test('findDeviceCalendar rejects account calendars and loose matches', () {
    // E-mail accounts are never device calendars, even with a device name.
    expect(
      findDeviceCalendar([
        {'id': 1, 'name': '내 캘린더', 'account': 'user@gmail.com'},
        {'id': 2, 'name': 'Phone', 'account': 'myphone@naver.com'},
      ]),
      isNull,
    );
    // Substrings and an empty account alone no longer match.
    expect(
      findDeviceCalendar([
        {'id': 3, 'name': '기기 동기화 일정', 'account': 'Exchange'},
        {'id': 4, 'name': '구독 캘린더', 'account': ''},
        {'id': 5, 'name': '팀', 'account': 'localhost-team'},
      ]),
      isNull,
    );
    // Exact device names still match.
    expect(
      findDeviceCalendar([
        {'id': 6, 'name': '업무', 'account': 'user@gmail.com'},
        {'id': 7, 'name': '내 캘린더', 'account': 'My calendar'},
      ])?['id'],
      7,
    );
    expect(
      findDeviceCalendar([
        {'id': 8, 'name': '내 캘린더', 'account': ''},
      ])?['id'],
      8,
    );
  });

  test('resolveTargetCalendar keeps the saved calendar if still listed', () {
    final list = [
      {'id': 1, 'name': '개인', 'account': 'user@gmail.com'},
      {'id': 2, 'name': '내 캘린더', 'account': 'phone'},
    ];
    // Saved account calendar is kept, not overwritten by the device one.
    expect(resolveTargetCalendar(list, 1)?['id'], 1);
    // Saved calendar gone or never set (-1 Android, '' iOS): device calendar.
    expect(resolveTargetCalendar(list, 99)?['id'], 2);
    expect(resolveTargetCalendar(list, -1)?['id'], 2);
    expect(resolveTargetCalendar(list, '')?['id'], 2);
    expect(resolveTargetCalendar(list, null)?['id'], 2);
    // Neither saved nor device calendar: null.
    expect(resolveTargetCalendar([list.first], 99), isNull);
    // Windows .ics target.
    expect(
      resolveTargetCalendar([
        {'id': 'ics', 'name': '일정 파일 (.ics)', 'account': '이 PC에 저장'},
      ], 'ics')?['id'],
      'ics',
    );
  });

  testWidgets('wizard walks through 6 steps and marks completion', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(const MaterialApp(home: OnboardingPage()));
    await tester.pump();
    FilledButton nextButton() =>
        tester.widget<FilledButton>(find.byType(FilledButton).last);

    // 1. Preset: locked until one is picked.
    expect(nextButton().onPressed, isNull);
    await tester.tap(find.text('지금 설정 그대로'));
    await tester.pump();
    expect(nextButton().onPressed, isNotNull);
    await tester.tap(find.text('다음'));
    await tester.pumpAndSettle();

    // 2. Guide: locked until the last card.
    expect(nextButton().onPressed, isNull);
    for (var i = 0; i < 3; i++) {
      await tester.tap(find.textContaining('끝까지 읽어 주세요'));
      await tester.pumpAndSettle();
    }
    expect(nextButton().onPressed, isNotNull);
    await tester.tap(find.text('다음'));
    await tester.pumpAndSettle();

    // 3. Permissions (Windows test host: nothing to grant)
    expect(find.text('꼭 필요한 권한'), findsOneWidget);
    await tester.tap(find.text('다음'));
    await tester.pumpAndSettle();

    // 4. Academic tools (Timetable & Home widget)
    expect(find.text('시간표와 홈 화면 위젯'), findsOneWidget);
    expect(find.text('주간 시간표'), findsOneWidget);
    expect(find.text('홈 화면 위젯'), findsOneWidget);
    await tester.tap(find.text('다음'));
    await tester.pumpAndSettle();

    // 5. AI & Cloud (Gemini, Google Drive & Device Calendar)
    expect(find.text('AI & 스마트 연동 (선택)'), findsOneWidget);
    expect(find.text('공지 속 시험·휴강 AI 분석'), findsOneWidget);
    expect(find.text('Google Drive 연결'), findsOneWidget);
    expect(find.text('스마트폰 기본 캘린더에 마감 등록'), findsOneWidget);
    await tester.tap(find.text('다음'));
    await tester.pumpAndSettle();

    // 6. Summary & Done.
    expect(find.text('준비 끝!'), findsOneWidget);
    expect(find.text('알림 설정은 바꾸지 않았어요.'), findsOneWidget);
    expect(find.text('홈 화면 위젯 확인 완료'), findsOneWidget);
    await tester.tap(find.text('시작하기'));
    await tester.pumpAndSettle();

    final prefs = await SharedPreferences.getInstance();
    expect(prefs.getBool(onboardingDoneKey), isTrue);
    expect(prefs.getBool(setupWidgetSeenKey), isTrue);
  });
}

import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/schedule/calendar_settings_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

class _FakeCalendarBridge {
  final bool allowed = true;
  Object? savedCalendarId;
  bool savedAuto;
  final List<Map<String, dynamic>> calendars;
  final List<Map<String, dynamic>> configureCalls = [];
  int syncCalls = 0;

  _FakeCalendarBridge({
    this.savedCalendarId = -1,
    this.savedAuto = false,
    required this.calendars,
  });

  void install() {
    desktopMethodHandler = null;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(bridge, (MethodCall call) async {
          switch (call.method) {
            case 'calendarPermission':
              return allowed;
            case 'calendarSettings':
              return <String, dynamic>{
                'allowed': allowed,
                'calendarId': savedCalendarId,
                'auto': savedAuto,
              };
            case 'calendarList':
              return calendars;
            case 'calendarConfigure':
              final args = Map<String, dynamic>.from(call.arguments as Map);
              savedCalendarId = args['calendarId'];
              savedAuto = args['auto'] == true;
              configureCalls.add(args);
              return null;
            case 'calendarSync':
              syncCalls++;
              return null;
            case 'calendarUnlink':
              savedCalendarId = -1;
              savedAuto = false;
              return null;
            default:
              return null;
          }
        });
  }

  void dispose() {
    desktopMethodHandler = null;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(bridge, null);
  }
}

Future<void> _scrollToVisible(
  WidgetTester tester,
  Finder finder, {
  double delta = 200,
}) async {
  await tester.scrollUntilVisible(
    finder,
    delta,
    scrollable: find.descendant(
      of: find.byType(ListView),
      matching: find.byType(Scrollable),
    ),
  );
  await tester.ensureVisible(finder);
  await tester.pumpAndSettle();
}

void main() {
  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  testWidgets('고급 항목은 기본으로 접혀 있고 펼치면 캘린더 목록과 기기 추천 표시를 보여준다', (
    tester,
  ) async {
    final fake = _FakeCalendarBridge(
      calendars: [
        {'id': 1, 'name': '내 캘린더', 'account': 'phone'},
        {'id': 2, 'name': '개인 일정', 'account': 'user@gmail.com'},
      ],
    )..install();
    addTearDown(fake.dispose);

    await tester.pumpWidget(const MaterialApp(home: CalendarSettingsPage()));
    await tester.pumpAndSettle();

    expect(find.text('기기 고정'), findsOneWidget);
    expect(find.text('고급: 저장할 캘린더 직접 고르기'), findsOneWidget);
    expect(find.byType(RadioListTile<Object>), findsNothing);
    expect(find.text('개인 일정'), findsNothing);
    expect(find.text('기기 · 추천'), findsNothing);

    await tester.ensureVisible(find.text('고급: 저장할 캘린더 직접 고르기'));
    await tester.tap(find.text('고급: 저장할 캘린더 직접 고르기'));
    await tester.pumpAndSettle();

    expect(find.byType(RadioListTile<Object>), findsNWidgets(2));
    expect(find.text('phone'), findsOneWidget);
    expect(find.text('기기 · 추천'), findsOneWidget);
    expect(find.text('개인 일정'), findsOneWidget);
    expect(find.text('user@gmail.com'), findsOneWidget);
    expect(
      tester.widget<RadioGroup<Object>>(find.byType(RadioGroup<Object>)).groupValue,
      1,
    );
  });

  testWidgets('계정 캘린더 선택 시 확인 대화상자가 뜨고 취소하면 유지하며 확인·되돌리기가 동작한다', (
    tester,
  ) async {
    final fake = _FakeCalendarBridge(
      calendars: [
        {'id': 1, 'name': '내 캘린더', 'account': 'phone'},
        {'id': 2, 'name': '개인 일정', 'account': 'user@gmail.com'},
      ],
    )..install();
    addTearDown(fake.dispose);

    await tester.pumpWidget(const MaterialApp(home: CalendarSettingsPage()));
    await tester.pumpAndSettle();

    await _scrollToVisible(tester, find.text('고급: 저장할 캘린더 직접 고르기'));
    await tester.tap(find.text('고급: 저장할 캘린더 직접 고르기'));
    await tester.pumpAndSettle();

    // 계정 캘린더 탭 → 확인 대화상자 표시 → 취소 시 선택 유지
    await _scrollToVisible(tester, find.text('개인 일정'));
    await tester.tap(find.text('개인 일정'));
    await tester.pumpAndSettle();

    expect(find.text('계정 캘린더에 저장할까요?'), findsOneWidget);
    expect(
      find.textContaining('동기화 설정에 따라 저장한 일정이 서버(예: Google)로 올라갈 수 있어요.'),
      findsOneWidget,
    );

    await tester.tap(find.text('취소'));
    await tester.pumpAndSettle();

    expect(find.text('계정 캘린더에 저장할까요?'), findsNothing);
    expect(
      tester.widget<RadioGroup<Object>>(find.byType(RadioGroup<Object>)).groupValue,
      1,
    );
    expect(fake.configureCalls, isEmpty);
    await _scrollToVisible(tester, find.text('저장 위치'), delta: -200);
    expect(find.text('기기 고정'), findsOneWidget);
    expect(find.text('직접 고른 캘린더'), findsNothing);

    // 다시 계정 캘린더 탭 → 확인 시 calendarId 저장 및 상단 카드 갱신
    await _scrollToVisible(tester, find.text('개인 일정'));
    await tester.tap(find.text('개인 일정'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('확인'));
    await tester.pumpAndSettle();

    expect(fake.savedCalendarId, 2);
    expect(fake.configureCalls.last['calendarId'], 2);
    expect(
      tester.widget<RadioGroup<Object>>(find.byType(RadioGroup<Object>)).groupValue,
      2,
    );
    await _scrollToVisible(tester, find.text('저장 위치'), delta: -200);
    expect(find.text('직접 고른 캘린더'), findsOneWidget);
    expect(find.text('기기 고정'), findsNothing);

    // 기기 캘린더로 되돌리기 버튼 동작 확인
    final revertButton = find.widgetWithText(TextButton, '기기 캘린더로 되돌리기');
    await _scrollToVisible(tester, revertButton);
    await tester.tap(revertButton);
    await tester.pumpAndSettle();

    expect(fake.savedCalendarId, 1);
    expect(
      tester.widget<RadioGroup<Object>>(find.byType(RadioGroup<Object>)).groupValue,
      1,
    );
    await _scrollToVisible(tester, find.text('저장 위치'), delta: -200);
    expect(find.text('기기 고정'), findsOneWidget);
    expect(find.text('직접 고른 캘린더'), findsNothing);
  });

  testWidgets('기기 캘린더가 없을 때 되돌리기 버튼이 비활성화되고 확인 후에만 자동 저장을 켤 수 있다', (
    tester,
  ) async {
    final fake = _FakeCalendarBridge(
      calendars: [
        {'id': 10, 'name': '구글 캘린더', 'account': 'user@gmail.com'},
      ],
    )..install();
    addTearDown(fake.dispose);

    await tester.pumpWidget(const MaterialApp(home: CalendarSettingsPage()));
    await tester.pumpAndSettle();

    expect(find.text('기기 캘린더를 찾지 못했어요'), findsOneWidget);
    final autoSwitch = find.widgetWithText(SwitchListTile, '과제·콘텐츠 마감 자동 전송');
    expect(tester.widget<SwitchListTile>(autoSwitch).onChanged, isNull);

    await _scrollToVisible(tester, find.text('고급: 저장할 캘린더 직접 고르기'));
    await tester.tap(find.text('고급: 저장할 캘린더 직접 고르기'));
    await tester.pumpAndSettle();

    final revertButton = find.widgetWithText(TextButton, '기기 캘린더로 되돌리기');
    expect(tester.widget<TextButton>(revertButton).onPressed, isNull);

    // 취소하면 여전히 자동 저장 비활성화
    await _scrollToVisible(tester, find.text('구글 캘린더'));
    await tester.tap(find.text('구글 캘린더'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('취소'));
    await tester.pumpAndSettle();
    expect(tester.widget<SwitchListTile>(autoSwitch).onChanged, isNull);

    // 확인하면 자동 저장 활성화 가능
    await _scrollToVisible(tester, find.text('구글 캘린더'));
    await tester.tap(find.text('구글 캘린더'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('확인'));
    await tester.pumpAndSettle();

    expect(fake.savedCalendarId, 10);
    await _scrollToVisible(tester, find.text('저장 위치'), delta: -200);
    expect(find.text('직접 고른 캘린더'), findsOneWidget);
    expect(find.text('기기 캘린더를 찾지 못했어요'), findsNothing);

    await _scrollToVisible(tester, autoSwitch);
    expect(tester.widget<SwitchListTile>(autoSwitch).onChanged, isNotNull);
    await tester.tap(autoSwitch);
    await tester.pumpAndSettle();
    expect(tester.widget<SwitchListTile>(autoSwitch).value, isTrue);

    await tester.tap(find.text('설정 저장·지금 동기화'));
    await tester.pumpAndSettle();
    expect(fake.savedCalendarId, 10);
    expect(fake.savedAuto, isTrue);
    expect(fake.syncCalls, 1);
  });

  testWidgets('저장된 계정 캘린더 ID가 있으면 열었을 때 우선 선택되고 직접 고른 캘린더로 표시된다', (
    tester,
  ) async {
    final fake = _FakeCalendarBridge(
      savedCalendarId: 2,
      savedAuto: true,
      calendars: [
        {'id': 1, 'name': '내 캘린더', 'account': 'phone'},
        {'id': 2, 'name': '개인 일정', 'account': 'user@gmail.com'},
      ],
    )..install();
    addTearDown(fake.dispose);

    await tester.pumpWidget(const MaterialApp(home: CalendarSettingsPage()));
    await tester.pumpAndSettle();

    expect(find.text('개인 일정'), findsOneWidget);
    expect(find.text('직접 고른 캘린더'), findsOneWidget);
    expect(find.text('기기 고정'), findsNothing);
  });

  testWidgets('계정 캘린더 이름과 계정이 같으면 확인 대화상자에 한 번만 표시된다', (
    tester,
  ) async {
    final fake = _FakeCalendarBridge(
      calendars: [
        {'id': 1, 'name': '내 캘린더', 'account': 'phone'},
        {
          'id': 2,
          'name': 'radar.test@example.com',
          'account': 'radar.test@example.com',
        },
      ],
    )..install();
    addTearDown(fake.dispose);

    await tester.pumpWidget(const MaterialApp(home: CalendarSettingsPage()));
    await tester.pumpAndSettle();

    await _scrollToVisible(tester, find.text('고급: 저장할 캘린더 직접 고르기'));
    await tester.tap(find.text('고급: 저장할 캘린더 직접 고르기'));
    await tester.pumpAndSettle();

    final targetTile = find.byType(RadioListTile<Object>).last;
    await _scrollToVisible(tester, targetTile);
    await tester.tap(targetTile);
    await tester.pumpAndSettle();

    expect(find.text('계정 캘린더에 저장할까요?'), findsOneWidget);
    expect(
      find.textContaining('radar.test@example.com 캘린더는 기기 전용이 아니라 계정에 연결된 캘린더예요.'),
      findsOneWidget,
    );
    expect(
      find.textContaining('radar.test@example.com (radar.test@example.com)'),
      findsNothing,
    );
  });
}

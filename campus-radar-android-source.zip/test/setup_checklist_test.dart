import 'package:flutter_test/flutter_test.dart';

import 'package:campus_radar/home/setup_checklist.dart';

void main() {
  test('setup steps reflect status and skip battery off Android', () {
    final steps = setupSteps(
      notificationsAllowed: true,
      powerWarnings: const ['배터리 최적화 예외가 아니에요.'],
      widgetSeen: false,
      hasTimetable: true,
      hasGeminiKey: false,
    );
    expect(
      {for (final s in steps) s.id: s.done},
      {
        'notify': true,
        'battery': false,
        'widget': false,
        'timetable': true,
        'gemini': false,
      },
    );
    final ios = setupSteps(
      notificationsAllowed: false,
      powerWarnings: const [],
      widgetSeen: true,
      hasTimetable: false,
      hasGeminiKey: true,
      android: false,
    );
    expect(ios.map((s) => s.id), isNot(contains('battery')));
  });
}

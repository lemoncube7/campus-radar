import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:campus_radar/settings/app_help_page.dart';

void main() {
  for (final (word, title) in [
    ('드라이브', 'Google Drive·외부 AI 연결'),
    ('필터', '할 일 표시 정리'),
    ('pdf', '자료실 모아보기'),
    ('락스타', '위젯 설정'),
  ]) {
    testWidgets('feature search: "$word" finds $title', (tester) async {
      await tester.pumpWidget(const MaterialApp(home: AppHelpPage()));
      await tester.enterText(find.byType(TextField), word);
      await tester.pump();
      expect(find.text(title), findsOneWidget);
    });
  }
}

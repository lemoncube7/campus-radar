import 'package:campus_radar/ai_daily_card.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets(
    'daily summary opens details without nested expansion or scroll-state collision',
    (t) async {
      final bucket = PageStorageBucket();
      late BuildContext storageContext;
      var visible = false;
      late StateSetter update;
      await t.pumpWidget(
        MaterialApp(
          home: PageStorage(
            bucket: bucket,
            child: Builder(
              builder: (context) {
                storageContext = context;
                return StatefulBuilder(
                  builder: (context, set) {
                    update = set;
                    return Scaffold(
                      body: ListView(
                        children: [
                          if (visible)
                            const DailySummarySection(
                              child: Text('summary content'),
                            ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ),
      );
      bucket.writeState(storageContext, 412.0);
      update(() => visible = true);
      await t.pumpAndSettle();
      expect(t.takeException(), isNull);
      await t.tap(find.text('하루 요약 보기'));
      await t.pumpAndSettle();
      expect(find.text('summary content').hitTestable(), findsOneWidget);
      await t.pageBack();
      await t.pumpAndSettle();
      update(() => visible = false);
      await t.pumpAndSettle();
      update(() => visible = true);
      await t.pumpAndSettle();
      expect(t.takeException(), isNull);
      await t.tap(find.text('하루 요약 보기'));
      await t.pumpAndSettle();
      expect(find.text('summary content').hitTestable(), findsOneWidget);
    },
  );
}

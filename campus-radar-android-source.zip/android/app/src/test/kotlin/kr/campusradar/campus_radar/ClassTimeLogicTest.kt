package kr.campusradar.campus_radar
import org.junit.Test
import org.junit.Assert.*
import java.time.*
class ClassTimeLogicTest {
 private val zone=ZoneId.of("Asia/Seoul")
 @Test fun classLeadAndWeeklyRollover(){
  val now=ZonedDateTime.of(2026,10,19,8,0,0,0,zone)
  assertEquals("2026-10-19T08:30+09:00[Asia/Seoul]",ClassTimeLogic.next(1,540,30,now,LocalDate.of(2026,12,31)).toString())
  assertEquals(LocalDate.of(2026,10,26),ClassTimeLogic.next(1,540,30,now.plusHours(1),LocalDate.of(2026,12,31))!!.toLocalDate())
 }
 @Test fun semesterEndStopsRecurrence(){assertNull(ClassTimeLogic.next(1,540,15,ZonedDateTime.of(2026,12,31,12,0,0,0,zone),LocalDate.of(2026,12,31)))}
 @Test fun midnightMeansBeginningOfNewDay(){val next=ClassTimeLogic.nextMidnight(ZonedDateTime.of(2026,10,18,23,59,0,0,zone));assertEquals(LocalDate.of(2026,10,19),next.toLocalDate());assertEquals(0,next.hour)}
 @Test fun leadMayFallOnPreviousDay(){assertEquals(23,ClassTimeLogic.next(1,15,60,ZonedDateTime.of(2026,10,18,22,0,0,0,zone),LocalDate.of(2026,12,31))!!.hour)}
}

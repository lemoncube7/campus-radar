package kr.campusradar.campus_radar

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.*
import android.widget.*
import org.json.JSONObject
import org.json.JSONTokener

/** Renders the exact CNU plan link. No portal credentials are given to this page. */
class SyllabusFetchActivity:Activity(){
 private lateinit var web:WebView
 private val handler=Handler(Looper.getMainLooper())
 private var finished=false
 private var previous=""
 private var stable=0
 private var capture=true
 private fun trusted(url:String):Boolean{val u=Uri.parse(url);return u.scheme=="https" && u.host in setOf("cnuit.cnu.ac.kr","tlsn.cnu.ac.kr") && u.userInfo==null}
 override fun onCreate(state:Bundle?){super.onCreate(state)
  val url=intent.getStringExtra("url")?:"";capture=intent.getBooleanExtra("capture",true)
  if(!trusted(url)){finish();return}
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  root.addView(Button(this).apply{text=if(capture)"계획서 가져오는 중 · 취소" else "앱으로 돌아가기";setOnClickListener{finish()}})
  web=WebView(this);root.addView(web,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
  web.settings.javaScriptEnabled=true;web.settings.domStorageEnabled=true
  web.settings.allowFileAccess=false;web.settings.allowContentAccess=false;web.settings.mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW
  web.webViewClient=object:WebViewClient(){
   override fun shouldOverrideUrlLoading(view:WebView,request:WebResourceRequest)=!trusted(request.url.toString())
   override fun shouldInterceptRequest(view:WebView,request:WebResourceRequest):WebResourceResponse?{return if(trusted(request.url.toString()))null else WebResourceResponse("text/plain","UTF-8",java.io.ByteArrayInputStream(byteArrayOf()))}
   override fun onPageFinished(view:WebView,url:String){if(capture&&trusted(url)){handler.removeCallbacks(poll);handler.postDelayed(poll,1200)}}
   override fun onReceivedError(view:WebView,request:WebResourceRequest,error:WebResourceError){if(request.isForMainFrame)fail("계획서 페이지를 열지 못했습니다.")}
  }
  web.loadUrl(url)
  if(capture)handler.postDelayed({fail("계획서 로딩 시간이 초과됐습니다. 원문 보기를 이용해 주세요.")},60000)
 }
 private val poll=object:Runnable{override fun run(){if(finished||isFinishing)return
  web.evaluateJavascript(EXTRACT){raw->try{
   val decoded=JSONTokener(raw).nextValue();val value=if(decoded is String)JSONObject(decoded)else JSONObject()
   val text=value.optString("text").take(120000);val fields=value.optInt("fields")
   val normalized=text.replace(Regex("\\s+"),"");val expected=(intent.getStringExtra("course")?:"").replace(Regex("\\s+"),"")
   val valid=fields>=8 && text.length>=400 && normalized.contains("교과목") && (expected.isEmpty() || normalized.contains(expected))
   stable=if(valid&&text==previous)stable+1 else 0;previous=text
   if(valid&&stable>=2){finished=true;handler.removeCallbacksAndMessages(null);setResult(RESULT_OK,Intent().putExtra("text",text).putExtra("sourceUrl",intent.getStringExtra("url")));finish()}else handler.postDelayed(this,1000)
  }catch(_:Exception){handler.postDelayed(this,1000)}}
 }}
 private fun fail(message:String){if(finished||isFinishing)return;finished=true;setResult(RESULT_CANCELED,Intent().putExtra("error",message));finish()}
 override fun onDestroy(){handler.removeCallbacksAndMessages(null);if(::web.isInitialized){web.stopLoading();web.destroy()};super.onDestroy()}
 companion object{
  private val EXTRACT="""(function(){var lines=[],fields=0;function walk(n){if(n.nodeType===3){var t=n.textContent.trim();if(t)lines.push(t);return;}if(n.nodeType!==1)return;var tag=n.tagName;if(['SCRIPT','STYLE','NOSCRIPT'].indexOf(tag)>=0)return;var s=getComputedStyle(n);if(s.display==='none'||s.visibility==='hidden')return;if(n.getAttribute('role')==='textbox'&&!n.querySelector('input,textarea')){var rv=n.getAttribute('aria-valuetext')||n.innerText||'';if(rv.trim()){lines.push(rv.trim());fields++;}return;}if(tag==='INPUT'||tag==='TEXTAREA'){if(['password','hidden','checkbox','radio','button','submit'].indexOf(n.type)>=0)return;var v=n.value||'';if(v.trim()){lines.push(v.trim());fields++;}return;}for(var c=n.firstChild;c;c=c.nextSibling)walk(c);}walk(document.body);return JSON.stringify({text:lines.join('\n'),fields:fields});})();"""
 }
}

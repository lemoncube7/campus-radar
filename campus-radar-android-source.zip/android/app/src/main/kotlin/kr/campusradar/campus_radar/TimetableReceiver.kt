package kr.campusradar.campus_radar

import android.app.*
import android.os.Build
import android.content.*
import android.database.sqlite.SQLiteDatabase
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.*
import java.time.*

class TimetableReceiver:BroadcastReceiver(){
 override fun onReceive(context:Context,intent:Intent){
  val pending=goAsync();Thread{try{TimetableWidget.updateAll(context);when(intent.action){"kr.campusradar.CLASS"->sendClass(context,intent.getStringExtra("slot")?:"");"kr.campusradar.MIDNIGHT"->sendMidnight(context)};schedule(context,true)}catch(_:Exception){RadarData.log(context,"시간표 알림 확인 실패","앱에서 시간표 설정을 다시 확인해 주세요.")}finally{pending.finish()}}.start()
 }
 companion object{
  fun settings(c:Context):Map<String,Any>{val p=c.getSharedPreferences("radar_timetable",0);return mapOf("exactAllowed" to (Build.VERSION.SDK_INT<31||c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()),"enabled" to p.getBoolean("enabled",false),"midnight" to p.getBoolean("midnight",false),"lead" to p.getInt("lead",30),"until" to p.getString("until","").orEmpty())}
  fun configure(c:Context,enabled:Boolean,midnight:Boolean,lead:Int,until:String){require(lead in listOf(15,30,60));LocalDate.parse(until);c.getSharedPreferences("radar_timetable",0).edit().putBoolean("enabled",enabled).putBoolean("midnight",midnight).putInt("lead",lead).putString("until",until).apply();schedule(c,true)}
  private fun entries(c:Context):List<JSONObject>{val path=c.getDatabasePath("campus.db");if(!path.exists())return emptyList();SQLiteDatabase.openDatabase(path.path,null,SQLiteDatabase.OPEN_READONLY).use{db->db.rawQuery("SELECT value FROM meta WHERE id='timetableEntries'",null).use{cursor->if(!cursor.moveToFirst())return emptyList();val a=JSONArray(cursor.getString(0));return (0 until a.length()).map{a.getJSONObject(it)}}}}
  private fun intent(c:Context,id:Int,action:String,slot:String=""):PendingIntent=PendingIntent.getBroadcast(c,id,Intent(c,TimetableReceiver::class.java).setAction(action).putExtra("slot",slot),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  private fun set(c:Context,at:Long,pi:PendingIntent){val am=c.getSystemService(AlarmManager::class.java);try{if(Build.VERSION.SDK_INT<31||am.canScheduleExactAlarms()){am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);return}}catch(_:SecurityException){};am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi)}
  @Synchronized fun schedule(c:Context,force:Boolean=false){
   val p=c.getSharedPreferences("radar_timetable",0)
   val rows=entries(c)
   val stamp=rows.toString()+settings(c).toString()
   if(!force&&p.getString("stamp","")==stamp)return
   val am=c.getSystemService(AlarmManager::class.java)
   p.getStringSet("ids",emptySet()).orEmpty().forEach{am.cancel(intent(c,it.toInt(),"kr.campusradar.CLASS"))}
   am.cancel(intent(c,8100,"kr.campusradar.MIDNIGHT"));val now=ZonedDateTime.now(RadarData.schoolZone);val until=try{LocalDate.parse(p.getString("until",""))}catch(_:Exception){now.toLocalDate().minusDays(1)}
   val ids=mutableSetOf<String>()
   if(p.getBoolean("enabled",false))for(row in rows){
    val at=ClassTimeLogic.next(row.getInt("weekday"),row.getInt("start"),p.getInt("lead",30),now,until)?:continue
    val id=8200+(row.getString("id").hashCode() and 0x3fffffff);ids.add(id.toString())
    set(c,at.toInstant().toEpochMilli(),intent(c,id,"kr.campusradar.CLASS",row.getString("id")))
   }
   if(p.getBoolean("midnight",false))set(c,ClassTimeLogic.nextMidnight(now).toInstant().toEpochMilli(),intent(c,8100,"kr.campusradar.MIDNIGHT"))
   p.edit().putStringSet("ids",ids).putString("stamp",stamp).apply()
  }
  private fun notify(c:Context,id:Int,title:String,body:String){
   val manager=NotificationManagerCompat.from(c);if(!manager.areNotificationsEnabled()){RadarData.log(c,"시간표 알림 건너뜀","알림 권한이 꺼져 있습니다.");return}
   c.getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("class_reminders","수업·자정 알림",NotificationManager.IMPORTANCE_DEFAULT))
   val n=NotificationCompat.Builder(c,"class_reminders").setSmallIcon(R.drawable.ic_stat_radar).setContentTitle(title).setContentText(body.lineSequence().firstOrNull()).setStyle(NotificationCompat.BigTextStyle().bigText(body)).setContentIntent(RadarData.launch(c,"_timetable",id)).setAutoCancel(true).build()
   try{manager.notify(id,n);RadarData.log(c,"$title 발송 요청",body)}catch(_:SecurityException){RadarData.log(c,"시간표 알림 건너뜀","알림 권한을 확인해 주세요.")}
  }
  private fun clock(n:Int)="%02d:%02d".format(n/60,n%60)
  fun sendClass(c:Context,key:String){
   val p=c.getSharedPreferences("radar_timetable",0);if(!p.getBoolean("enabled",false))return
   val now=ZonedDateTime.now(RadarData.schoolZone);val until=LocalDate.parse(p.getString("until",""));if(now.toLocalDate().isAfter(until))return
   val row=entries(c).firstOrNull{it.optString("id")==key}?:return
   val start=now.plusMinutes(p.getInt("lead",30).toLong()).toLocalDate().atStartOfDay(RadarData.schoolZone).plusMinutes(row.getInt("start").toLong())
   if(start.dayOfWeek.value!=row.getInt("weekday")||!start.isAfter(now)||Duration.between(now,start).toMinutes()>p.getInt("lead",30)+2)return
   val token="$key:${start.toLocalDate()}";if(p.getString("sent:$key","")==token)return
   val body="${RadarData.courseName(c,row)} · ${clock(row.getInt("start"))} 시작\n${row.optString("room")}\n강의계획서 기준 · 휴강·보강은 직접 확인"
   notify(c,8200+(key.hashCode() and 0x3fffffff),"곧 수업이 시작돼요",body);p.edit().putString("sent:$key",token).apply()
  }
  fun sendMidnight(c:Context,test:Boolean=false){
   val p=c.getSharedPreferences("radar_timetable",0);if(!test&&!p.getBoolean("midnight",false))return
   val s=RadarData.read(c);if(!s.connected)return
   val today=ZonedDateTime.now(RadarData.schoolZone).toLocalDate();if(!test&&p.getString("midnightSent","")==today.toString())return
   val until=try{LocalDate.parse(p.getString("until",""))}catch(_:Exception){today.minusDays(1)}
   val classes=if(today.isAfter(until))emptyList()else entries(c).filter{it.optInt("weekday")==today.dayOfWeek.value}.sortedBy{it.optInt("start")}
   val tasks=RadarData.pending(s).filter{RadarData.instant(it.optString("due"))?.atZone(RadarData.schoolZone)?.toLocalDate()==today}
   val lines=classes.map{"${clock(it.getInt("start"))} ${RadarData.courseName(c,it)} ${it.optString("room")}"}+tasks.map{"마감 ${RadarData.instant(it.optString("due"))?.atZone(RadarData.schoolZone)?.toLocalTime()} · ${RadarData.courseName(c,it)} ${it.optString("title")}"}
   val body="${today.monthValue}/${today.dayOfMonth} 수업 ${classes.size}개 · 미완료 마감 ${tasks.size}개\n"+lines.take(12).joinToString("\n")+"\n마지막 확인 ${RadarData.stamp(s)} (한국 시간)"
   notify(c,8100,"자정 · 오늘의 수업과 과제",body);if(!test)p.edit().putString("midnightSent",today.toString()).apply()
  }
 }
}

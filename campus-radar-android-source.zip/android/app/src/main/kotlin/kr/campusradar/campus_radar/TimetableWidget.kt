package kr.campusradar.campus_radar

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.os.Bundle
import android.database.sqlite.SQLiteDatabase
import android.graphics.*
import android.widget.RemoteViews
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.*

class TimetableWidget: AppWidgetProvider() {
 override fun onUpdate(context:Context, manager:AppWidgetManager, ids:IntArray) { ids.forEach { update(context,manager,it) } }
 override fun onAppWidgetOptionsChanged(context:Context, manager:AppWidgetManager, id:Int, options:Bundle) { update(context,manager,id) }
 companion object {
  fun updateAll(context:Context) {
   val manager=AppWidgetManager.getInstance(context)
   manager.getAppWidgetIds(android.content.ComponentName(context,TimetableWidget::class.java)).forEach {update(context,manager,it)}
  }
  private fun rows(context:Context):List<JSONObject> {
   if(!context.getDatabasePath("campus.db").exists())return emptyList()
   return SQLiteDatabase.openDatabase(context.getDatabasePath("campus.db").path,null,SQLiteDatabase.OPEN_READONLY).use { db->
    db.rawQuery("SELECT value FROM meta WHERE id=?",arrayOf("timetableEntries")).use {c->
     if(!c.moveToFirst()) emptyList() else JSONArray(c.getString(0)).let {a-> (0 until a.length()).map{a.getJSONObject(it)}.filter{it.optInt("weekday") in 1..7 && it.optInt("start") in 0..1439 && it.optInt("end") in 1..1440 && it.optInt("end")>it.optInt("start")} }
    }
   }
  }
  private fun update(context:Context, manager:AppWidgetManager, id:Int) {
   try {
    val options=manager.getAppWidgetOptions(id)
    val w=(options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,320)*2).coerceIn(400,1200)
    val h=(options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT,350)*2).coerceIn(400,1400)
    val bitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888)
    val canvas=Canvas(bitmap); canvas.drawColor(Color.rgb(247,249,253))
    val p=Paint(Paint.ANTI_ALIAS_FLAG)
    fun text(value:String,x:Float,y:Float,size:Float=22f,color:Int=Color.rgb(35,45,65)) {p.color=color;p.textSize=size;p.typeface=Typeface.create("sans-serif",Typeface.NORMAL);canvas.drawText(value,x,y,p)}
    val entries=rows(context)
    text("시간표",20f,35f,26f)
    if(entries.isEmpty()) text("앱에서 시간표 만들기를 눌러 주세요",20f,90f,22f)
    else {
     val days=max(5,entries.maxOf{it.optInt("weekday")})
     val first=min(9,entries.minOf{it.optInt("start")/60})
     val last=max(18,entries.maxOf{(it.optInt("end")+59)/60})
     val left=58f;val top=85f;val col=(w-left-10)/days;val hour=(h-top-15)/(last-first)
     val names=listOf("월","화","수","목","금","토","일")
     val today=java.time.ZonedDateTime.now(RadarData.schoolZone).dayOfWeek.value
     if(today<=days){p.color=Color.rgb(232,238,249);canvas.drawRect(left+(today-1)*col,top-28,left+today*col,h-15f,p)}
     for(d in 0 until days)text(names[d],left+d*col+col/2-10,68f,22f)
     for(t in first..last){val y=top+(t-first)*hour;p.color=Color.rgb(218,225,235);p.strokeWidth=1f;canvas.drawLine(left,y,w-10f,y,p);text("%02d".format(t),12f,y+7,18f)}
     val colors=listOf(0xffdce5ff.toInt(),0xffd2eee7.toInt(),0xffffe0cd.toInt(),0xffeadbfa.toInt(),0xffd6eaff.toInt(),0xffffdbea.toInt())
     val positions=mutableMapOf<String,Pair<Int,Int>>()
     for(day in 1..7){
      val rows=entries.filter{it.optInt("weekday")==day}.sortedWith(compareBy<JSONObject>{it.optInt("start")}.thenBy{it.optString("id")})
      var index=0
      while(index<rows.size){
       val group=mutableListOf(rows[index++]);var end=group.first().optInt("end")
       while(index<rows.size && rows[index].optInt("start")<end){val row=rows[index++];group.add(row);end=max(end,row.optInt("end"))}
       val ends=mutableListOf<Int>();val lanes=mutableMapOf<String,Int>()
       for(row in group){var lane=ends.indexOfFirst{it<=row.optInt("start")};if(lane<0){lane=ends.size;ends.add(row.optInt("end"))}else ends[lane]=row.optInt("end");lanes[row.optString("id")]=lane}
       for(row in group)positions[row.optString("id")]=Pair(lanes[row.optString("id")]!!,ends.size)
      }
     }
     for(e in entries){
      val position=positions[e.optString("id")]!!
      val cw=col/position.second
      val x=left+(e.optInt("weekday")-1)*col+position.first*cw+1
      val y=top+(e.optInt("start")-first*60)/60f*hour+1
      val bottom=top+(e.optInt("end")-first*60)/60f*hour-1
      p.color=colors[(e.optString("courseKey").hashCode() and 0x7fffffff)%colors.size]
      canvas.drawRoundRect(x,y,x+cw-2,bottom,7f,7f,p)
      canvas.save();canvas.clipRect(x+3,y+2,x+cw-4,bottom-2)
      val title=RadarData.courseName(context,e)
      val size=20f;p.textSize=size
      var line="";var yy=y+24
      for(ch in title){if(yy>y+48)break;if(p.measureText(line+ch)>cw-12 && line.isNotEmpty()){text(line,x+5,yy,size);yy+=24;line=""};line+=ch}
      if(line.isNotEmpty()){text(line,x+5,yy,size);yy+=24}
      text("%02d:%02d".format(e.optInt("start")/60,e.optInt("start")%60),x+5,yy,17f);yy+=21
      text(e.optString("room"),x+5,yy,17f)
      canvas.restore()
     }
    }
    val views=RemoteViews(context.packageName,R.layout.timetable_widget)
    views.setImageViewBitmap(R.id.timetable_image,bitmap)
    views.setViewVisibility(R.id.timetable_placeholder,android.view.View.GONE)
    views.setOnClickPendingIntent(R.id.timetable_image,RadarData.launch(context,"_timetable",8250))
    manager.updateAppWidget(id,views)
   }catch(e:Exception){RadarData.log(context,"시간표 위젯 오류",e.javaClass.simpleName,"system")}
  }
 }
}

package kr.campusradar.campus_radar

import java.time.*

object ClassTimeLogic {
 fun next(weekday:Int,minute:Int,lead:Int,now:ZonedDateTime,until:LocalDate):ZonedDateTime? {
  require(weekday in 1..7 && minute in 0..1439 && lead in listOf(15,30,60))
  for(offset in 0L..7L){val date=now.toLocalDate().plusDays(offset);if(date.isAfter(until))return null
   if(date.dayOfWeek.value==weekday){val alarm=date.atStartOfDay(now.zone).plusMinutes(minute.toLong()).minusMinutes(lead.toLong());if(alarm.isAfter(now))return alarm}
  };return null
 }
 fun nextMidnight(now:ZonedDateTime):ZonedDateTime=now.toLocalDate().plusDays(1).atStartOfDay(now.zone)
}

package kr.campusradar.campus_radar

import java.time.*

object ClassTimeLogic {
 fun next(weekday:Int,minute:Int,lead:Int,now:ZonedDateTime,until:LocalDate):ZonedDateTime? {
  require(weekday in 1..7 && minute in 0..1439 && lead in listOf(15,30,60))
  for(offset in 0L..7L){val date=now.toLocalDate().plusDays(offset);if(date.isAfter(until))return null
   if(date.dayOfWeek.value==weekday){val alarm=date.atStartOfDay(now.zone).plusMinutes(minute.toLong()).minusMinutes(lead.toLong());if(alarm.isAfter(now))return alarm}
  };return null
 }
 fun nextMidnight(now:ZonedDateTime):ZonedDateTime=now.toLocalDate().plusDays(1).atStartOfDay(now.zone)
 fun countdownStart(weekday:Int,minute:Int,lead:Int,now:ZonedDateTime,until:LocalDate,sentDate:String):ZonedDateTime? {
  if(weekday !in 1..7 || minute !in 0..1439 || lead !in listOf(15,30,60))return null
  for(offset in 0L..1L){
   val date=now.toLocalDate().plusDays(offset)
   if(date.isAfter(until)||date.dayOfWeek.value!=weekday||date.toString()!=sentDate)continue
   val start=date.atStartOfDay(now.zone).plusMinutes(minute.toLong())
   if(start.isAfter(now)&&!now.isBefore(start.minusMinutes(lead.toLong())))return start
  }
  return null
 }
 fun countdownText(start:Instant,now:Instant):String {
  val seconds=((Duration.between(now,start).toMillis().coerceAtLeast(0)+999)/1000)
  return "${seconds/60}분 %02d초".format(seconds%60)
 }
}

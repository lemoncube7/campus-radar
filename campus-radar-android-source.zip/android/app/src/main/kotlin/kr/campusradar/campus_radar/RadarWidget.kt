package kr.campusradar.campus_radar

import android.app.*
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.*
import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.os.Build
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject
import java.time.*
import java.time.format.DateTimeFormatter

/** Reads the same local database as Flutter; no credentials or network access. */
object RadarData {
 val schoolZone: ZoneId = ZoneId.of("Asia/Seoul")
 fun instant(value: String?): Instant? = try { if(value.isNullOrEmpty() || value == "null") null else OffsetDateTime.parse(value).toInstant() } catch(_:Exception) { null }
 fun available(item:JSONObject, now:Instant) = item.optBoolean("published",true) && (instant(item.optString("startsAt"))?.let{!it.isAfter(now)} ?: true)
 data class Snapshot(val items:List<JSONObject>, val last:String, val discovered:Map<String,String>, val connected:Boolean)
 fun read(context:Context):Snapshot {
  try {
   val raw = context.getSharedPreferences("FlutterSharedPreferences", 0)
    .getString("flutter.widgetSnapshotJson", null)
   if (!raw.isNullOrEmpty()) {
    val root = JSONObject(raw)
    val itemsArray = root.optJSONArray("items") ?: org.json.JSONArray()
    val items = ArrayList<JSONObject>(itemsArray.length())
    for (i in 0 until itemsArray.length()) {
     items.add(itemsArray.getJSONObject(i))
    }
    val discObj = root.optJSONObject("discovered")
    val discovered = mutableMapOf<String, String>()
    if (discObj != null) {
     val keys = discObj.keys()
     while (keys.hasNext()) {
      val k = keys.next()
      discovered[k] = discObj.optString(k)
     }
    }
    return Snapshot(items, root.optString("last", ""), discovered, root.optBoolean("connected", false))
   }
  } catch (e: Exception) {
   android.util.Log.w("CampusRadar", "widget snapshot fast-path fallback: ${e.message}")
  }
  val path=context.getDatabasePath("campus.db")
  if(!path.exists())return Snapshot(emptyList(),"",emptyMap(),false)
  SQLiteDatabase.openDatabase(path.path,null,SQLiteDatabase.OPEN_READWRITE or SQLiteDatabase.ENABLE_WRITE_AHEAD_LOGGING).use {db->
   db.rawQuery("PRAGMA busy_timeout=5000",null).use{it.moveToFirst()}
   db.beginTransactionNonExclusive()
   try {
    val meta=mutableMapOf<String,String>()
    db.rawQuery("SELECT id,value FROM meta",null).use {c->while(c.moveToNext())meta[c.getString(0)]=c.getString(1)}
    val items=mutableListOf<JSONObject>(); val now=Instant.now()
    db.rawQuery("SELECT payload FROM items",null).use{c->while(c.moveToNext()){
     val item=JSONObject(c.getString(0)); if(meta["notTask:"+item.optString("key")]!="yes" && meta["excluded:"+item.optString("key")]!="yes" && !autoHidden(item,meta,now) && available(item,now))items.add(item)
    }}
    db.setTransactionSuccessful()
    return Snapshot(items,meta["lastSuccess"]?:"",meta.filterKeys{it.startsWith("discovered:")},meta["initialized"]=="yes")
   } finally {db.endTransaction()}
  }
 }
 fun timetableEntries(context:Context):List<JSONObject> {
  try {
   val raw = context.getSharedPreferences("FlutterSharedPreferences", 0)
    .getString("flutter.widgetTimetableJson", null)
   if (!raw.isNullOrEmpty()) {
    val a = org.json.JSONArray(raw)
    val list = ArrayList<JSONObject>(a.length())
    for (i in 0 until a.length()) {
     val item = a.getJSONObject(i)
     if (item.optInt("weekday") in 1..7 && item.optInt("start") in 0..1439 && item.optInt("end") in 1..1440 && item.optInt("end") > item.optInt("start")) {
      list.add(item)
     }
    }
    return list
   }
  } catch (_: Exception) {}
  val path = context.getDatabasePath("campus.db")
  if (!path.exists()) return emptyList()
  return try {
   SQLiteDatabase.openDatabase(path.path, null, SQLiteDatabase.OPEN_READONLY).use { db ->
    db.rawQuery("SELECT value FROM meta WHERE id=?", arrayOf("timetableEntries")).use { c ->
     if (!c.moveToFirst()) emptyList()
     else org.json.JSONArray(c.getString(0)).let { a ->
      val list = ArrayList<JSONObject>(a.length())
      for (i in 0 until a.length()) {
       val item = a.getJSONObject(i)
       if (item.optInt("weekday") in 1..7 && item.optInt("start") in 0..1439 && item.optInt("end") in 1..1440 && item.optInt("end") > item.optInt("start")) {
        list.add(item)
       }
      }
      list
     }
    }
   }
  } catch (_: Exception) { emptyList() }
 }
 fun courseName(context:Context,item:JSONObject):String {
  val original=item.optString("course")
  return try{val raw=context.getSharedPreferences("FlutterSharedPreferences",0).getString("flutter.courseAliases","{}");JSONObject(raw?:"{}").let{a->val normalized=original.replace(Regex("\\s+"),"");val key=a.keys().asSequence().firstOrNull{it.replace(Regex("\\s+"),"")==normalized};a.optString(key?:original,original)}}catch(_:Exception){original}
 }
 fun autoHidden(item:JSONObject,meta:Map<String,String>,now:Instant):Boolean{
  val mode=meta["overduePolicy"]?:"confirm";if(mode!="immediate"&&mode!="day")return false
  if(item.optString("status")=="done")return false
  val due=instant(item.optString("due"))?:return false
  if(meta["overdueRestored:"+item.optString("key")]==item.optString("due"))return false
  return !now.isBefore(due.plusSeconds(if(mode=="day")86400 else 0))
 }
 // Same rule as CampusItem.openTask: quizzes/exams and tasks whose detail
 // failed to load have status "unknown" but may still be to do.
 fun pending(s:Snapshot)=s.items.filter{val st=it.optString("status");st=="pending"||(st=="unknown"&&it.optString("type")!="LS")}.sortedBy{instant(it.optString("due"))?:Instant.MAX}
 fun summary(s:Snapshot):String {
  val now=Instant.now();val today=now.atZone(schoolZone).toLocalDate();val p=pending(s)
  val todayCount=p.count{instant(it.optString("due"))?.let{d->d.isAfter(now) && d.atZone(schoolZone).toLocalDate()==today}?:false}
  val within=p.count{instant(it.optString("due"))?.let{d->d.isAfter(now)&&!d.isAfter(now.plusSeconds(86400))}?:false}
  val fresh=s.items.count{it.optString("type")=="LR" && instant(s.discovered["discovered:"+it.optString("key")])?.atZone(schoolZone)?.toLocalDate()==today}
  return "오늘 마감 ${todayCount}개 · 24시간 이내 ${within}개\n미완료 ${p.size}개 · 오늘 새 과제 ${fresh}개"
 }
 fun stamp(s:Snapshot)=NativeTimestamp.parse(s.last)?.atZone(schoolZone)?.format(DateTimeFormatter.ofPattern("M/d HH:mm"))?:"아직 수집 전"
 fun remaining(item:JSONObject):String {
  val due=instant(item.optString("due"))?:return "마감 미확인"
  val minutes=Duration.between(Instant.now(),due).toMinutes()
  return when {minutes<=0->"마감 지남";minutes>=1440->"${minutes/1440}일 ${(minutes%1440)/60}시간 남음";minutes>=60->"${minutes/60}시간 ${minutes%60}분 남음";else->"${minutes}분 남음"}
 }
 fun launch(context:Context,target:String,request:Int):PendingIntent = PendingIntent.getActivity(context,request,Intent(context,MainActivity::class.java).putExtra("radarTarget",target).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
 fun log(context:Context,title:String,detail:String,kind:String="notification") {
  android.util.Log.i("CampusRadar","[$kind] $title | ${detail.replace('\n',' ')}")
  try {SQLiteDatabase.openDatabase(context.getDatabasePath("campus.db").path,null,SQLiteDatabase.OPEN_READWRITE or SQLiteDatabase.ENABLE_WRITE_AHEAD_LOGGING).use { db->
   db.execSQL("INSERT INTO logs(at,kind,title,detail) VALUES(?,?,?,?)",arrayOf(Instant.now().toString(),kind,title,detail))
   db.execSQL("DELETE FROM logs WHERE id NOT IN (SELECT id FROM logs ORDER BY id DESC LIMIT 2000)")
  }}catch(e:Exception){android.util.Log.w("CampusRadar","activity log write failed: ${e.javaClass.simpleName}")}
 }
 /** Same as [log] with a short technical cause line (no tokens or content). */
 fun logError(context:Context,title:String,detail:String,error:Throwable,kind:String="app")=log(context,title,"$detail\n원인: ${cause(error)}",kind)
 /** For paths that rerun on every widget/overlay refresh: same cause is logged at most every 6 hours. */
 fun logOnce(context:Context,key:String,title:String,detail:String,error:Throwable,kind:String="app"){
  try{
   val p=context.getSharedPreferences("radar_log_once",0);val c=cause(error);val now=System.currentTimeMillis()
   val last=p.getString(key,"").orEmpty();val at=last.substringAfterLast('|',"0").toLongOrNull()?:0L
   if(last.substringBeforeLast('|')==c&&now-at<6*3600*1000L)return
   p.edit().putString(key,"$c|$now").apply()
  }catch(_:Exception){/* Dedupe is best-effort; still log below. */}
  logError(context,title,detail,error,kind)
 }
 fun cause(e:Throwable):String=when(e){
  is DriveHttpFailure->"Drive HTTP ${e.status}"
  is com.google.android.gms.common.api.ApiException->"Google 서비스 ${e.statusCode}"
  else->e.javaClass.simpleName+(e.message?.takeIf{it.length<=120&&!it.contains("Bearer")}?.let{" · $it"}?:"")
 }
}

class RadarWidget:AppWidgetProvider() {
 override fun onAppWidgetOptionsChanged(context:Context,manager:AppWidgetManager,id:Int,options:android.os.Bundle){WidgetWork.run{update(context,manager,id)}}
 override fun onUpdate(context:Context,manager:AppWidgetManager,ids:IntArray){WidgetWork.run{ids.forEach{update(context,manager,it)}}}
 companion object {
  fun updateAll(context:Context){CompactStudyWidget.updateAll(context);WidgetWork.run{val m=AppWidgetManager.getInstance(context);m.getAppWidgetIds(ComponentName(context,RadarWidget::class.java)).forEach{update(context,m,it)}}}
  private fun update(context:Context,manager:AppWidgetManager,id:Int){
   val views=RemoteViews(context.packageName,R.layout.radar_widget)
   val palette=WidgetStyle.read(context);WidgetStyle.background(views,R.id.radar_root,palette)
   val options=manager.getAppWidgetOptions(id)
   val width=options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,250)
   val height=options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT,250)
   val sizing=WidgetSizing.tasks(width,height,WidgetText.scale(context,"tasks"))
   val scale=WidgetText.scale(context,"tasks")*sizing.factor
   val pad=(sizing.padding*context.resources.displayMetrics.density).toInt()
   views.setViewPadding(R.id.radar_root,pad,pad,pad,pad)
   val today=LocalDate.now(RadarData.schoolZone)
   val dateLabel="${today.monthValue}/${today.dayOfMonth}"
   views.setTextViewText(R.id.radar_title,if(sizing.title)"해야 할 일 · $dateLabel" else dateLabel)
   views.setTextViewTextSize(R.id.radar_title,android.util.TypedValue.COMPLEX_UNIT_SP,(if(sizing.title)14f else 11f)*scale)
   views.setTextColor(R.id.radar_next,palette.secondary)
   views.setViewVisibility(R.id.radar_stamp,if(sizing.stamp)android.view.View.VISIBLE else android.view.View.GONE)
   views.setTextColor(R.id.radar_title,palette.text);views.setTextColor(R.id.radar_count,palette.primary);views.setTextColor(R.id.radar_stamp,palette.muted)
   views.setTextViewTextSize(R.id.radar_count,android.util.TypedValue.COMPLEX_UNIT_SP,16f*scale)
   val rows=intArrayOf(R.id.radar_row1,R.id.radar_row2,R.id.radar_row3,R.id.radar_row4)
   val titles=intArrayOf(R.id.radar_task1,R.id.radar_task2,R.id.radar_task3,R.id.radar_task4)
   val meta=intArrayOf(R.id.radar_meta1,R.id.radar_meta2,R.id.radar_meta3,R.id.radar_meta4)
   try {
    val s=RadarData.read(context);val pending=RadarData.pending(s);val now=Instant.now()
    val next=if(s.connected)try{
     CompactStudyWidget.next(context)?.takeIf{!it.second.toInstant().isAfter(now.plusSeconds(12*3600))}
    }catch(e:Exception){
     RadarData.logOnce(context,"radar-next-class","다음 수업 표시 실패","할 일은 계속 표시해요.",e)
     null
    }else null
    val visibleRows=WidgetSizing.tasks(width,height,WidgetText.scale(context,"tasks"),showNext=next!=null).rows
    if(next!=null){
     val (lesson,start)=next
     val time="%02d:%02d".format(start.hour,start.minute)
     val day=if(start.toLocalDate()==today)"" else "내일 "
     views.setViewVisibility(R.id.radar_next,android.view.View.VISIBLE)
     views.setTextViewText(R.id.radar_next,"다음 · $day$time · ${RadarData.courseName(context,lesson)}")
     views.setOnClickPendingIntent(R.id.radar_next,RadarData.launch(context,"_timetable",505))
    }
    views.setTextViewText(R.id.radar_count,if(s.connected)"미완료 ${pending.size}"else "연결 필요")
    views.setTextViewText(R.id.radar_stamp,"최근 확인 ${RadarData.stamp(s)}")
    views.setOnClickPendingIntent(R.id.radar_root,RadarData.launch(context,"_tasks",500))
    rows.forEachIndexed{index,row->
     val item=pending.getOrNull(index)
     views.setViewVisibility(row,if(index<visibleRows&&(item!=null||index==0))android.view.View.VISIBLE else android.view.View.GONE)
     views.setTextViewText(titles[index],item?.optString("title")?:(if(s.connected)"지금은 할 일이 없어요" else "앱에서 포털을 연결해 주세요"))
     views.setTextColor(titles[index],palette.text)
     views.setTextViewTextSize(titles[index],android.util.TypedValue.COMPLEX_UNIT_SP,13f*scale)
     views.setTextViewTextSize(meta[index],android.util.TypedValue.COMPLEX_UNIT_SP,11f*scale)
     views.setInt(titles[index],"setMaxLines",if(height<140)1 else 2)
     if(item!=null){
      val due=RadarData.instant(item.optString("due"));val stamp=due?.atZone(RadarData.schoolZone)
      val label=if(stamp==null)"마감 미확인" else {
       val date=if(stamp.toLocalDate()==today)"오늘" else "${stamp.monthValue}/${stamp.dayOfMonth}"
       val time="%02d:%02d".format(stamp.hour,stamp.minute)
       if(stamp.toInstant().isAfter(now))"$date $time" else "$date $time · 지남"
      }
      views.setTextViewText(meta[index],"$label · ${RadarData.courseName(context,item)}")
      views.setTextColor(meta[index],when{due==null->palette.muted;!due.isAfter(now)->palette.danger;!due.isAfter(now.plusSeconds(86400))->palette.secondary;else->palette.muted})
      views.setOnClickPendingIntent(row,RadarData.launch(context,item.optString("key"),501+index))
     }else {views.setTextViewText(meta[index],"눌러서 목록 확인");views.setTextColor(meta[index],palette.muted);views.setOnClickPendingIntent(row,RadarData.launch(context,"_tasks",500))}
    }
   }catch(e:Exception){views.setTextViewText(R.id.radar_count,"다시 확인");views.setTextViewText(R.id.radar_task1,"앱에서 목록을 확인해 주세요");views.setTextViewText(R.id.radar_meta1,"");RadarData.logOnce(context,"radar-widget","할 일 위젯 표시 실패","위젯에 '다시 확인'을 표시했어요.",e)}
   manager.updateAppWidget(id,views)
  }
 }
}

class DailySummaryReceiver:BroadcastReceiver(){
 override fun onReceive(context:Context,intent:Intent){
  if(intent.action=="kr.campusradar.DAILY"){
   try {send(context)}catch(_:Exception){RadarData.log(context,"하루 요약 실패","기기 내 목록을 읽지 못했어요.")}
  }
  schedule(context);RadarWidget.updateAll(context)
 }
 companion object {
  fun settings(context:Context):Map<String,Any>{val p=context.getSharedPreferences("radar_daily",0);return mapOf("enabled" to p.getBoolean("enabled",false),"hour" to p.getInt("hour",18),"minute" to p.getInt("minute",0))}
  fun configure(context:Context,enabled:Boolean,hour:Int,minute:Int){require(hour in 0..23 && minute in 0..59);context.getSharedPreferences("radar_daily",0).edit().putBoolean("enabled",enabled).putInt("hour",hour).putInt("minute",minute).apply();schedule(context)}
  fun schedule(context:Context){
   val alarm=context.getSystemService(AlarmManager::class.java)
   val pi=PendingIntent.getBroadcast(context,700,Intent(context,DailySummaryReceiver::class.java).setAction("kr.campusradar.DAILY"),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
   alarm.cancel(pi);val p=context.getSharedPreferences("radar_daily",0);if(!p.getBoolean("enabled",false))return
   val now=ZonedDateTime.now();var next=now.withHour(p.getInt("hour",18)).withMinute(p.getInt("minute",0)).withSecond(0).withNano(0)
   if(!next.isAfter(now))next=next.plusDays(1)
   alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next.toInstant().toEpochMilli(),pi)
  }
  fun send(context:Context){
   val s=RadarData.read(context);if(!s.connected){RadarData.log(context,"하루 요약 건너뜀","연결된 계정의 수집 기록이 없어요.");return}
   val manager=NotificationManagerCompat.from(context)
   if(!manager.areNotificationsEnabled()){RadarData.log(context,"하루 요약 건너뜀","알림 권한이 꺼져 있어요.");return}
   val nm=context.getSystemService(NotificationManager::class.java)
   nm.createNotificationChannel(NotificationChannel("daily_summary","데일리 과제 요약",NotificationManager.IMPORTANCE_DEFAULT))
   val p=context.getSharedPreferences("FlutterSharedPreferences",0)
   val utcHour=Instant.now().toEpochMilli()/3600000
   val cachedHour=p.getLong("flutter.aiSummaryHour",-100)
   val today=ZonedDateTime.now(ZoneId.of("Asia/Seoul")).toLocalDate().toString()
   val valid=p.getLong("flutter.aiSummaryExpires",0)>Instant.now().toEpochMilli() && p.getBoolean("flutter.aiSummaryEnabled",false) && p.getString("flutter.aiSummaryLast",null)==s.last && p.getString("flutter.aiSummaryDay",null)==today && utcHour-cachedHour in 0L..1L
   val extra=if(valid)p.getString("flutter.aiSummaryText","").orEmpty() else ""
   val body=RadarData.summary(s)+(if(extra.isNotBlank())"\nAI 우선 확인\n$extra" else "")+"\n마지막 확인 ${RadarData.stamp(s)} (한국 시간)"
   val notification=NotificationCompat.Builder(context,"daily_summary").setSmallIcon(R.drawable.ic_stat_radar).setContentTitle("오늘의 캠퍼스레이더").setContentText(body.lines().first()).setStyle(NotificationCompat.BigTextStyle().bigText(body)).setContentIntent(RadarData.launch(context,"_summary",700)).setAutoCancel(true).build()
   try{manager.notify(700,notification);RadarData.log(context,"하루 요약 발송 요청",body)}catch(_:SecurityException){RadarData.log(context,"하루 요약 건너뜀","알림 권한을 확인해 주세요.")}
  }
 }
}

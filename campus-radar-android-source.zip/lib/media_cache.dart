import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:path_provider/path_provider.dart';
import 'campus.dart';
import 'campus_media.dart';

/// Re-downloadable private cache, isolated by account. No public storage permission.
class MediaCache {
  final Directory root;
  MediaCache(this.root);
  static Future<MediaCache> open(String account) async {
    final base = await getTemporaryDirectory();
    final key = sha256.convert(utf8.encode(account)).toString();
    final root = Directory('${base.path}/campus_media/$key');
    await root.create(recursive: true);
    return MediaCache(root);
  }

  String key(CampusMedia m) =>
      sha256.convert(utf8.encode(m.identity)).toString();
  String safeName(String s) {
    var name = s.replaceAll(RegExp(r'[<>:"/\\|?*\x00-\x1f]'), '_').trim();
    if (name.length > 100) name = name.substring(name.length - 100);
    if (name.isEmpty || name == '.' || name == '..') name = 'attachment';
    return name;
  }

  File data(CampusMedia m) =>
      File('${root.path}/${key(m)}-${safeName(m.name)}');
  File record(CampusMedia m) => File('${root.path}/${key(m)}.json');
  Future<File?> local(CampusMedia m) async {
    final f = data(m);
    return await f.exists() && await record(m).exists() ? f : null;
  }

  Future<String> status(CampusMedia m) async {
    if (await local(m) != null) return '기기에 저장됨';
    try {
      return (jsonDecode(await record(m).readAsString()) as Map)['error'] ??
          '저장 대기';
    } catch (_) {
      return m.supported ? '저장 대기' : '외부 파일 · 원문에서 확인';
    }
  }

  Future<String> mime(CampusMedia m) async {
    try {
      return (jsonDecode(await record(m).readAsString()) as Map)['mime'] ??
          'application/octet-stream';
    } catch (_) {
      return 'application/octet-stream';
    }
  }

  Future<File> fetch(CampusClient client, CampusMedia m) async {
    final existing = await local(m);
    if (existing != null) return existing;
    if (!m.supported) throw CampusException('외부 이미지·파일은 원문에서 확인해 주세요.');
    if ((m.size ?? 0) > 50 * 1024 * 1024) {
      throw CampusException('파일당 50MB 저장 제한을 초과했습니다.');
    }
    final partial = File(
      '${data(m).path}.${DateTime.now().microsecondsSinceEpoch}.part',
    );
    try {
      final result = await client.downloadMedia(m);
      await trim(result.bytes.length);
      await partial.writeAsBytes(result.bytes, flush: true);
      await partial.rename(data(m).path);
      await record(m).writeAsString(jsonEncode({'mime': result.mime}));
      return data(m);
    } catch (e) {
      if (await partial.exists()) await partial.delete();
      if (await local(m) == null) {
        await record(m).writeAsString(
          jsonEncode({
            'error': e is CampusException ? e.message : '저장 실패 · 눌러서 재시도',
          }),
        );
      }
      rethrow;
    }
  }

  Future<void> trim(int incoming) async {
    final files = await root
        .list()
        .where(
          (f) =>
              f is File &&
              !f.path.endsWith('.json') &&
              !f.path.endsWith('.part'),
        )
        .cast<File>()
        .toList();
    final stats = <File, FileStat>{};
    var total = incoming;
    for (final f in files) {
      final st = await f.stat();
      stats[f] = st;
      total += st.size;
    }
    files.sort((a, b) => stats[a]!.modified.compareTo(stats[b]!.modified));
    for (final f in files) {
      if (total <= 300 * 1024 * 1024) break;
      total -= stats[f]!.size;
      await f.delete();
    }
  }
}

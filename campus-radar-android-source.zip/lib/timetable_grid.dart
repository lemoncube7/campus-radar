import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'campus.dart';
import 'timetable_model.dart';

class TimetableGrid extends StatelessWidget {
  final List<ClassSlot> entries;
  const TimetableGrid({super.key, required this.entries});
  @override
  Widget build(BuildContext context) {
    final days = math.max(
      5,
      entries.fold<int>(1, (a, e) => math.max(a, e.weekday)),
    );
    final first = entries.fold<int>(9, (a, e) => math.min(a, e.start ~/ 60));
    final last = entries.fold<int>(
      18,
      (a, e) => math.max(a, (e.end + 59) ~/ 60),
    );
    const hour = 54.0, left = 42.0, column = 100.0, header = 32.0;
    final colors = [
      Colors.indigo,
      Colors.teal,
      Colors.deepOrange,
      Colors.purple,
      Colors.blue,
      Colors.pink,
    ];
    final lanes = timetableLanes(entries);
    final keys = entries.map((e) => e.courseKey).toSet().toList()..sort();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: SizedBox(
          width: left + days * column,
          height: header + (last - first) * hour,
          child: Stack(
            children: [
              for (var day = 1; day <= days; day++)
                Positioned(
                  left: left + (day - 1) * column,
                  top: 0,
                  width: column,
                  child: Center(
                    child: Text(
                      weekNames[day - 1],
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              for (var h = first; h <= last; h++) ...[
                Positioned(
                  left: 0,
                  top: header + (h - first) * hour - 7,
                  child: Text(
                    '${h.toString().padLeft(2, '0')}:00',
                    style: Theme.of(context).textTheme.labelSmall,
                  ),
                ),
                Positioned(
                  left: left,
                  right: 0,
                  top: header + (h - first) * hour,
                  child: Divider(
                    height: 1,
                    color: Theme.of(context).dividerColor,
                  ),
                ),
              ],
              for (final e in entries) ...[
                Builder(
                  builder: (context) {
                    final position = lanes[e.id]!;
                    final width = column / position.count;
                    final color =
                        colors[keys.indexOf(e.courseKey) % colors.length];
                    return Positioned(
                      left:
                          left +
                          (e.weekday - 1) * column +
                          position.lane * width +
                          1,
                      top: header + (e.start - first * 60) / 60 * hour + 1,
                      width: width - 2,
                      height: math.max(12, (e.end - e.start) / 60 * hour - 2),
                      child: Tooltip(
                        message:
                            '${courseLabel(e.course)}\n${slotTime(e.start)}–${slotTime(e.end)} ${e.room}',
                        child: Container(
                          padding: const EdgeInsets.all(5),
                          decoration: BoxDecoration(
                            color: color.withValues(alpha: 0.18),
                            borderRadius: BorderRadius.circular(7),
                            border: Border.all(
                              color: color.withValues(alpha: 0.5),
                            ),
                          ),
                          child: ClipRect(
                            child: Text(
                              '${courseLabel(e.course)}\n${slotTime(e.start)}–${slotTime(e.end)}\n${e.room}',
                              style: Theme.of(context).textTheme.labelSmall,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

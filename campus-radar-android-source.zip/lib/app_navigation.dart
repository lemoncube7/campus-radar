import 'navigation_contract.dart';
import 'navigation_key.dart';
import 'app_storage.dart';
import 'course_labels.dart';
import 'campus_models.dart';
import 'desktop.dart';
import 'dart:async';
import 'dart:io';

Future<void> openItem(String? key) async {
  if (key == null) return;
  if (Platform.isWindows) {
    await desktopRuntime.show();
    if (key == '_desktop') return;
  }
  if (key.startsWith('NOTICE:')) {
    final s = await Store.open();
    CampusNotice? notice;
    try {
      notice = (await s.notices())
          .where((n) => n.id == key.substring(7))
          .firstOrNull;
    } finally {
      await s.db.close();
    }
    if (notice != null) {
      navKey.currentState?.pushNamed(
        NoticeDestination(notice: notice).path,
        arguments: NoticeDestination(notice: notice),
      );
    }
    return;
  }
  if (key == '_timetable') {
    navKey.currentState?.pushNamed(
      TimetableDestination().path,
      arguments: TimetableDestination(),
    );
    return;
  }
  if (key == '_summary') {
    navKey.currentState?.pushNamed(
      SummaryDestination().path,
      arguments: SummaryDestination(),
    );
    return;
  }
  final store = await Store.open();
  final item = (await store.items()).where((i) => i.key == key).firstOrNull;
  final excluded = (await store.excluded()).contains(key);
  await store.log(
    'notification',
    '알림 클릭',
    item == null
        ? '현재 목록에 없는 항목의 알림입니다.'
        : '${courseLabel(item.course)} · ${item.title}',
  );
  await store.db.close();
  if (item != null) {
    navKey.currentState?.pushNamed(
      TaskDestination(item: item, excluded: excluded).path,
      arguments: TaskDestination(item: item, excluded: excluded),
    );
  }
}

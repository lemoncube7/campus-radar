import 'package:campus_radar/core/demo_state.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/ai/ai_state_repository.dart';
import 'package:campus_radar/ai/ai_state_models.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/schedule/calendar_window.dart';
import 'dart:convert';

Future<Map<String, dynamic>> confirmAiCandidate(
  Store store,
  String key,
  CampusNotice notice,
  ScheduleCandidate candidate, {
  bool calendar = false,
  Future<void> Function()? beforeCommit,
}) async {
  final scope = await SessionScope.capture(store);
  if (candidate.action != 'add') {
    throw const AiFailure('변경·취소 일정은 기존 일정을 확인해 주세요.');
  }
  final old = Map<String, dynamic>.from(
    jsonDecode(await store.meta(MetaKey.aiState(key)) ?? '{}'),
  );
  final start =
      DateTime.tryParse(old['start'] ?? '') ??
      (candidate.date.isEmpty
          ? null
          : candidate.time.isEmpty
          ? strictDate(candidate.date)
          : DateTime.parse('${candidate.date}T${candidate.time}:00+09:00'));
  if (start == null) {
    throw const AiFailure('날짜를 먼저 입력해 주세요.', code: 'date_required');
  }
  final allDay = old['allDay'] as bool? ?? candidate.time.isEmpty;
  final title = courseEventTitle(
    old['title'] as String? ?? '[${notice.course}] ${candidate.title}',
    notice.course,
    oldLabel: old['courseLabel'] as String?,
  );
  if (calendar) {
    if (isDemoActive) {
      throw const AiFailure('체험 모드에서는 기기 캘린더에 저장하지 않아요. 앱 안에서만 확정해 볼 수 있어요.');
    }
    if (await bridge.invokeNative<bool>(NativeMethod.calendarPermission) !=
        true) {
      throw const AiFailure('캘린더 권한이 필요해요.');
    }
    final window = calendarWindow(
      start,
      allDay: allDay,
      deadline: old['deadline'] as bool? ?? candidate.deadline,
      end: old.containsKey('end')
          ? DateTime.tryParse(old['end'] ?? '')
          : candidate.endInstant,
    );
    await scope.verify();
    await beforeCommit?.call();
    await bridge.invokeNative(NativeMethod.calendarWrite, {
      'key': key,
      'title': title,
      'start': window.$1.millisecondsSinceEpoch,
      'end': window.$2.millisecondsSinceEpoch,
      'allDay': allDay,
      'description':
          '공지: ${notice.title}\n${candidate.description}\nhttps://dcs-learning.cnu.ac.kr/home',
    });
  }
  final next = {
    ...old,
    'status': 'confirmed',
    'courseName': notice.course,
    'courseLabel': courseLabel(notice.course),
    'title': title,
    'start': start.toUtc().toIso8601String(),
    'date': allDay
        ? start.toUtc().toIso8601String().substring(0, 10)
        : start
              .toUtc()
              .add(const Duration(hours: 9))
              .toIso8601String()
              .substring(0, 10),
    'allDay': allDay,
    'deadline': old['deadline'] as bool? ?? candidate.deadline,
    'end': old.containsKey('end')
        ? old['end']
        : candidate.endInstant?.toUtc().toIso8601String(),
    'calendarSent': calendar || old['calendarSent'] == true,
  };
  await scope.verify();
  await beforeCommit?.call();
  await AiStateRepository(
    store,
  ).saveSchedule(key, ConfirmedSchedule.fromJson(next));
  await store.log(
    'ai',
    calendar ? 'AI 일정 확정·캘린더 전송' : 'AI 일정 바로 확정',
    notice.title,
  );
  return old;
}

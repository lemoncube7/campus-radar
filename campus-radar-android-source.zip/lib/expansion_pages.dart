import 'dart:io';
import 'timetable_page.dart';
import 'package:flutter_markdown_plus/flutter_markdown_plus.dart';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'ai_pages.dart';
import 'ai.dart';
import 'campus.dart';
import 'chat.dart';
import 'main.dart';
import 'services.dart';

String courseKey(Map<String, dynamic> c) =>
    '${c['course_id']}:${c['class_no']}';
Future<List<Map<String, dynamic>>> readCourses(Store store) async {
  final courses = <String, Map<String, dynamic>>{};
  final raw = await store.meta('courses');
  if (raw != null) {
    for (final c in (jsonDecode(raw) as List)) {
      final row = Map<String, dynamic>.from(c);
      courses[courseKey(row)] = row;
    }
  }
  for (final i in await store.items()) {
    courses.putIfAbsent(
      courseKey(i.context),
      () => {...i.context, 'course_nm': i.course},
    );
  }
  for (final n in await store.notices()) {
    courses.putIfAbsent(
      courseKey(n.context),
      () => {...n.context, 'course_nm': n.course},
    );
  }
  return courses.values.toList()..sort(
    (a, b) => courseLabel(
      '${a['course_nm']}',
    ).compareTo(courseLabel('${b['course_nm']}')),
  );
}

class CoursesPage extends StatefulWidget {
  const CoursesPage({super.key});
  @override
  State<CoursesPage> createState() => _CoursesPageState();
}

class _CoursesPageState extends State<CoursesPage> {
  List<Map<String, dynamic>> courses = [];
  String? error;
  bool loading = true;
  @override
  void initState() {
    super.initState();
    unawaited(load());
  }

  Future<void> load() async {
    Store? store;
    try {
      await loadCourseAliases();
      store = await Store.open();
      final data = await readCourses(store);
      if (mounted) {
        setState(() {
          courses = data;
          error = null;
          loading = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          error = '과목 목록을 읽지 못했습니다.';
          loading = false;
        });
      }
    } finally {
      await store?.db.close();
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('내 과목'),
      actions: [
        if (Platform.isAndroid)
          IconButton(
            tooltip: '시간표·수업 알림',
            icon: const Icon(Icons.schedule),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const TimetablePage()),
            ),
          ),
        IconButton(
          tooltip: '전체 공지',
          icon: const Icon(Icons.campaign_outlined),
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const NoticesPage()),
          ),
        ),
        IconButton(
          tooltip: 'AI 채팅',
          icon: const Icon(Icons.chat_bubble_outline),
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AiChatPage()),
          ),
        ),
      ],
    ),
    body: loading
        ? const Center(child: CircularProgressIndicator())
        : RefreshIndicator(
            onRefresh: load,
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const Text('과목별로 과제·콘텐츠·공지·강의계획서를 확인하세요.'),
                const SizedBox(height: 16),
                if (error != null) Text(error!),
                if (courses.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(24),
                    child: Text('수집된 과목이 없습니다. 포털 연결 후 지금 확인을 눌러 주세요.'),
                  ),
                ...courses.map((c) {
                  final original = '${c['course_nm']}';
                  final label = courseLabel(original);
                  return Card(
                    child: ListTile(
                      leading: const Icon(Icons.menu_book_outlined),
                      title: Text(label),
                      subtitle: Text(
                        label == original ? '과제 · 콘텐츠 · 공지 · 강의계획서' : original,
                      ),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => CoursePage(course: c),
                          ),
                        );
                        await load();
                      },
                    ),
                  );
                }),
              ],
            ),
          ),
  );
}

class CoursePage extends StatefulWidget {
  final Map<String, dynamic> course;
  const CoursePage({super.key, required this.course});
  @override
  State<CoursePage> createState() => _CoursePageState();
}

class _CoursePageState extends State<CoursePage> {
  List<CampusItem> items = [];
  List<CampusNotice> notices = [];
  Set<String> excluded = {};
  bool loading = true, planBusy = false;
  String? error, planError;
  Map<String, dynamic>? plan;
  String get name => '${widget.course['course_nm']}';
  String get key => courseKey(widget.course);
  @override
  void initState() {
    super.initState();
    unawaited(load());
  }

  Future<void> load() async {
    Store? s;
    try {
      s = await Store.open();
      final all = await s.items();
      final ns = await s.notices();
      final ex = await s.excluded();
      final cache = await s.meta('coursePlan:$key');
      if (mounted) {
        setState(() {
          items = all
              .where(
                (i) =>
                    courseKey(i.context) == key &&
                    i.availableAt(DateTime.now().toUtc()),
              )
              .toList();
          notices = ns.where((n) => courseKey(n.context) == key).toList();
          excluded = ex;
          plan = cache == null
              ? null
              : Map<String, dynamic>.from(jsonDecode(cache));
          loading = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          error = '과목 정보를 읽지 못했습니다.';
          loading = false;
        });
      }
    } finally {
      await s?.db.close();
    }
  }

  Future<void> alias() async {
    var edited = courseAliases[name] ?? '';
    final value = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('과목 약자'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(name),
            const SizedBox(height: 12),
            TextFormField(
              initialValue: edited,
              onChanged: (value) => edited = value,
              maxLength: 30,
              autofocus: true,
              decoration: const InputDecoration(
                labelText: '예: 컴프2',
                helperText: '비우면 원래 과목명으로 표시합니다.',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, edited),
            child: const Text('저장'),
          ),
        ],
      ),
    );
    if (value == null) return;
    try {
      await setCourseAlias(name, value);
      final s = await Store.open();
      try {
        await s.log('app', '과목 약자 변경', name);
        await reconcile(s);
      } finally {
        await s.db.close();
      }
      if (mounted) setState(() {});
    } catch (_) {
      message('약자를 저장하지 못했습니다.');
    }
  }

  void message(String text) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
    }
  }

  Future<CampusClient> connected() async {
    final c = CampusClient();
    try {
      final id = await credentials.read(key: 'id'),
          pw = await credentials.read(key: 'pw');
      if (id == null || pw == null) throw CampusException('포털을 먼저 연결해 주세요.');
      await c.login(id, pw);
      return c;
    } catch (_) {
      c.close();
      rethrow;
    }
  }

  CampusItem get courseItem => CampusItem(
    key: 'COURSE:$key',
    type: 'COURSE',
    title: name,
    course: name,
    courseId: '${widget.course['course_id']}',
    classNo: '${widget.course['class_no']}',
    contentsId: '',
    status: 'unknown',
    context: widget.course,
  );
  Future<void> openCourse({bool syllabus = false}) async {
    CampusClient? c;
    try {
      c = await connected();
      final nav = await c.navigation(courseItem);
      if (syllabus) nav['url'] = '${CampusClient.learning}/std/coursePlan';
      await bridge.invokeMethod('openCampus', nav);
    } catch (e) {
      message(e is CampusException ? e.message : '강의실을 열지 못했습니다.');
    } finally {
      c?.close();
    }
  }

  Future<void> fetchPlan() async {
    setState(() => planBusy = true);
    final account = await credentials.read(key: 'id');
    CampusClient? c;
    Store? s;
    try {
      c = await connected();
      final response = await c.api(
        '/course/addSessionCourseInfo',
        widget.course,
      );
      final ctx = response['data'];
      final data = await c.api(
        '/coursePlan/getInfo',
        ctx is String
            ? Map<String, dynamic>.from(jsonDecode(ctx))
            : Map<String, dynamic>.from(ctx),
      );
      if (data is! Map || data['plan_info'] is! Map) {
        throw CampusException('강의계획서 본문이 제공되지 않았습니다. 원문에서 확인해 주세요.');
      }
      if (await credentials.read(key: 'id') != account) {
        throw CampusException('계정이 변경되어 저장을 중지했습니다.');
      }
      final link = data['link_course_info'] is Map
          ? data['link_course_info']['link_url']
          : null;
      String? linkedText;
      if (link is String && link.isNotEmpty) {
        final uri = Uri.tryParse(link);
        if (uri == null ||
            uri.scheme != 'https' ||
            !{'cnuit.cnu.ac.kr', 'tlsn.cnu.ac.kr'}.contains(uri.host) ||
            uri.userInfo.isNotEmpty) {
          throw CampusException('계획서 바로가기 주소를 확인하지 못했습니다.');
        }
        final fetched = await bridge
            .invokeMapMethod<String, dynamic>('fetchLinkedPlan', {
              'url': link,
              'course': name,
            })
            .timeout(const Duration(seconds: 75));
        linkedText = fetched?['text'] as String?;
        if (linkedText == null || linkedText.trim().isEmpty) {
          throw CampusException('실제 계획서 본문을 가져오지 못했습니다.');
        }
      }
      if (await credentials.read(key: 'id') != account) {
        throw CampusException('계정이 변경되어 저장을 중지했습니다.');
      }
      final result = <String, dynamic>{
        'linkedText': linkedText,
        'linkedUrl': link,
        'fetchedAt': DateTime.now().toUtc().toIso8601String(),
        'data': data,
      };
      s = await Store.open();
      await s.setMeta('coursePlan:$key', jsonEncode(result));
      await s.log(
        'sync',
        '강의계획서 저장',
        linkedText == null
            ? '사이버캠퍼스 본문'
            : '바로가기 실제 계획서 · ${linkedText.length}자',
      );
      if (mounted) {
        setState(() {
          plan = result;
          planError = null;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(
          () => planError = e is CampusException
              ? e.message
              : '강의계획서를 불러오지 못했습니다. 기존 저장본이 있으면 유지합니다.',
        );
      }
    } finally {
      c?.close();
      await s?.db.close();
      if (mounted) setState(() => planBusy = false);
    }
  }

  Widget tasks(String type) {
    final list = items
        .where((i) => i.type == type && !excluded.contains(i.key))
        .toList();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (list.isEmpty) const Text('현재 공개된 항목이 없습니다.'),
        ...list.map(
          (i) => Card(
            child: ListTile(
              title: Text(i.title),
              subtitle: Text('${remainingText(i)} · ${statusText(i)}'),
              leading: Icon(
                i.done
                    ? Icons.check_circle_outline
                    : Icons.radio_button_unchecked,
              ),
              onTap: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => DetailPage(item: i, excluded: false),
                  ),
                );
                await load();
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget planView() {
    final linkedText = plan?['linkedText'] as String?;
    final data = plan?['data'] as Map?;
    final info = data?['plan_info'] as Map?;
    const labels = {
      'lect_summary': '강의 개요',
      'lect_goal': '학습 목표',
      'lect_method': '강의 방법',
      'lect_reference': '참고 자료',
      'lect_eval': '평가 방법',
      'link_comment': '안내',
    };
    final weeks = data?['week_list'] as List? ?? [];
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Wrap(
          spacing: 8,
          children: [
            FilledButton.icon(
              onPressed: planBusy ? null : fetchPlan,
              icon: const Icon(Icons.refresh),
              label: Text(planBusy ? '불러오는 중…' : '강의계획서 불러오기'),
            ),
            OutlinedButton(
              onPressed: () async {
                final link = plan?['linkedUrl'];
                if (link is String && link.isNotEmpty) {
                  await bridge.invokeMethod('openLinkedPlan', {
                    'url': link,
                    'course': name,
                  });
                } else {
                  await openCourse(syllabus: true);
                }
              },
              child: const Text('강의계획서 원문 보기'),
            ),
          ],
        ),
        const SizedBox(height: 16),
        if (planError != null) Text(planError!),
        if (plan != null)
          Text('저장본 · ${koreanTime(DateTime.parse(plan!['fetchedAt']))}'),
        if (plan == null && !planBusy)
          const Text('버튼을 누르면 사이버캠퍼스의 강의계획서 바로가기가 여는 실제 계획서를 불러와 기기에 저장합니다.'),
        if (linkedText != null)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: SelectableText(linkedText),
          ),
        if (linkedText == null)
          ...labels.entries
              .where((e) => textOf(info?[e.key]).isNotEmpty)
              .map(
                (e) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        e.value,
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 6),
                      SelectableText(textOf(info?[e.key])),
                    ],
                  ),
                ),
              ),
        if (linkedText == null &&
            plan != null &&
            labels.keys.every((k) => textOf(info?[k]).isEmpty) &&
            weeks.isEmpty)
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text('텍스트 본문이 없습니다. 외부 링크·첨부 계획서는 원문 버튼으로 확인하세요.'),
          ),
        if (linkedText == null)
          ...weeks.map(
            (w) => Card(
              child: ListTile(
                title: Text(
                  '${w['week_no'] ?? ''}주차 · ${textOf(w['week_title'])}',
                ),
                subtitle: Text(textOf(w['week_materials'])),
              ),
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) => DefaultTabController(
    length: 4,
    child: Scaffold(
      appBar: AppBar(
        title: Text(courseLabel(name)),
        actions: [
          IconButton(
            tooltip: '약자 설정',
            onPressed: alias,
            icon: const Icon(Icons.edit_outlined),
          ),
          IconButton(
            tooltip: '이 과목 AI 질문',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AiChatPage(course: widget.course),
              ),
            ),
            icon: const Icon(Icons.chat_bubble_outline),
          ),
          IconButton(
            tooltip: '강의실 바로가기',
            onPressed: openCourse,
            icon: const Icon(Icons.open_in_new),
          ),
        ],
        bottom: const TabBar(
          isScrollable: true,
          tabs: [
            Tab(text: '과제'),
            Tab(text: '콘텐츠'),
            Tab(text: '공지'),
            Tab(text: '강의계획서'),
          ],
        ),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
          ? Center(child: Text(error!))
          : TabBarView(
              children: [
                tasks('LR'),
                tasks('LV'),
                ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    if (notices.isEmpty) const Text('수집된 공지가 없습니다.'),
                    ...notices.map(
                      (n) => Card(
                        child: ListTile(
                          title: Text(n.title),
                          subtitle: Text(
                            n.published == null
                                ? '게시일 미확인'
                                : koreanTime(n.published!),
                          ),
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => NoticeDetailPage(notice: n),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                planView(),
              ],
            ),
    ),
  );
}

class AiChatPage extends StatefulWidget {
  final Map<String, dynamic>? course;
  const AiChatPage({super.key, this.course});
  @override
  State<AiChatPage> createState() => _AiChatPageState();
}

class _AiChatPageState extends State<AiChatPage> {
  final input = TextEditingController();
  final scroll = ScrollController();
  List<Map<String, String>> history = [];
  bool loading = true, busy = false, share = false, consent = false;
  String? error;
  String get key =>
      'aiChat:${widget.course == null ? 'all' : courseKey(widget.course!)}';
  @override
  void initState() {
    super.initState();
    unawaited(load());
  }

  @override
  void dispose() {
    input.dispose();
    scroll.dispose();
    super.dispose();
  }

  Future<void> load() async {
    Store? s;
    try {
      s = await Store.open();
      final raw = await s.meta(key);
      final agreed = await s.meta('aiChatConsent') == '1';
      if (mounted) {
        setState(() {
          history = raw == null
              ? []
              : (jsonDecode(raw) as List)
                    .map((m) => Map<String, String>.from(m))
                    .toList();
          consent = agreed;
        });
      }
    } catch (_) {
      if (mounted) setState(() => error = '저장된 대화를 읽지 못했습니다.');
    } finally {
      await s?.db.close();
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> send() async {
    final question = input.text.trim();
    if (busy || question.isEmpty) return;
    if (!consent) {
      final accepted = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('AI 채팅 전송 동의'),
          content: const Text(
            '질문과 최근 대화가 개인 키를 통해 Google Gemini로 전송됩니다. ‘수집 정보 공유’를 켜면 해당 범위의 과제·콘텐츠와 저장된 공지 본문 일부도 함께 전송됩니다. 무료 API의 데이터 처리 조건을 확인해 주세요. 로그인 비밀번호와 API 키는 대화 자료에 포함하지 않습니다.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('취소'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('동의하고 질문'),
            ),
          ],
        ),
      );
      if (accepted != true) return;
      consent = true;
    }
    setState(() {
      busy = true;
      error = null;
    });
    Store? s;
    try {
      s = await Store.open();
      await s.setMeta('aiChatConsent', '1');
      final answer = await askCampusAi(
        s,
        history,
        question,
        includeData: share,
        courseId: widget.course == null ? null : courseKey(widget.course!),
      );
      final next = [
        ...history,
        {'role': 'user', 'text': question},
        {'role': 'model', 'text': answer},
      ];
      final retained = next
          .skip(next.length > 40 ? next.length - 40 : 0)
          .toList();
      await s.setMeta(key, jsonEncode(retained));
      if (mounted) {
        setState(() {
          history = retained;
          input.clear();
        });
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (scroll.hasClients) {
            scroll.animateTo(
              scroll.position.maxScrollExtent,
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOut,
            );
          }
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => error = e is AiFailure ? e.message : '채팅을 완료하지 못했습니다.');
      }
    } finally {
      await s?.db.close();
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> clear() async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('대화를 지울까요?'),
        content: const Text(
          '이 화면에 저장된 대화를 삭제합니다. 이미 전송된 데이터는 Google 측 보관 정책을 따릅니다.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('지우기'),
          ),
        ],
      ),
    );
    if (yes != true) return;
    final s = await Store.open();
    try {
      await s.setMeta(key, '[]');
      if (mounted) setState(() => history = []);
    } finally {
      await s.db.close();
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(
        widget.course == null
            ? 'AI 채팅'
            : '${courseLabel('${widget.course!['course_nm']}')} 질문',
      ),
      actions: [
        IconButton(
          tooltip: 'AI 설정',
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AiSettingsPage()),
          ),
          icon: const Icon(Icons.settings_outlined),
        ),
        IconButton(
          tooltip: '대화 지우기',
          onPressed: busy ? null : clear,
          icon: const Icon(Icons.delete_outline),
        ),
      ],
    ),
    body: SafeArea(
      child: Column(
        children: [
          SwitchListTile(
            title: Text(widget.course == null ? '수집 정보 공유' : '이 과목의 수집 정보 공유'),
            subtitle: const Text(
              '현재 자료 최대 60개·공지 25개. 끄더라도 이전 대화는 함께 전송돼요. 첨부는 제외해요.',
            ),
            value: share,
            onChanged: busy ? null : (v) => setState(() => share = v),
          ),
          if (share)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextButton(
                onPressed: busy
                    ? null
                    : () async {
                        final s = await Store.open();
                        try {
                          final preview = await chatContext(
                            s,
                            courseId: widget.course == null
                                ? null
                                : courseKey(widget.course!),
                          );
                          if (context.mounted) {
                            showDialog<void>(
                              context: context,
                              builder: (ctx) => AlertDialog(
                                title: const Text('현재 전송 자료'),
                                content: SingleChildScrollView(
                                  child: SelectableText(preview),
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.pop(ctx),
                                    child: const Text('닫기'),
                                  ),
                                ],
                              ),
                            );
                          }
                        } finally {
                          await s.db.close();
                        }
                      },
                child: const Text('전송 자료 미리보기'),
              ),
            ),
          Expanded(
            child: loading
                ? const Center(child: CircularProgressIndicator())
                : ListView(
                    controller: scroll,
                    padding: const EdgeInsets.all(16),
                    children: [
                      if (history.isEmpty)
                        const Padding(
                          padding: EdgeInsets.all(24),
                          child: Text(
                            '“이번 주에 먼저 할 과제는?”처럼 질문해 보세요. 내 과제에 대한 질문은 수집 정보 공유를 켜 주세요. AI는 제출이나 일정 변경을 실행하지 않습니다.',
                          ),
                        ),
                      ...history.map(
                        (m) => Align(
                          alignment: m['role'] == 'user'
                              ? Alignment.centerRight
                              : Alignment.centerLeft,
                          child: Container(
                            margin: const EdgeInsets.symmetric(vertical: 5),
                            padding: const EdgeInsets.all(14),
                            constraints: const BoxConstraints(maxWidth: 620),
                            decoration: BoxDecoration(
                              color: m['role'] == 'user'
                                  ? Theme.of(
                                      context,
                                    ).colorScheme.primaryContainer
                                  : Theme.of(
                                      context,
                                    ).colorScheme.surfaceContainerHighest,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: m['role'] == 'model'
                                ? MarkdownBody(
                                    data: displayCourseText(m['text']!),
                                    selectable: true,
                                    imageBuilder: (uri, title, alt) =>
                                        Text(alt ?? '이미지'),
                                    onTapLink: (text, href, title) async {
                                      if (href == null) return;
                                      final u = Uri.tryParse(href);
                                      if (u == null ||
                                          u.scheme != 'https' ||
                                          u.host.isEmpty ||
                                          u.userInfo.isNotEmpty) {
                                        return;
                                      }
                                      try {
                                        await bridge.invokeMethod(
                                          'openChatLink',
                                          {'url': u.toString()},
                                        );
                                      } catch (_) {
                                        if (context.mounted) {
                                          ScaffoldMessenger.of(
                                            context,
                                          ).showSnackBar(
                                            const SnackBar(
                                              content: Text('링크를 열지 못했습니다.'),
                                            ),
                                          );
                                        }
                                      }
                                    },
                                  )
                                : SelectableText(m['text']!),
                          ),
                        ),
                      ),
                    ],
                  ),
          ),
          if (error != null)
            Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                error!,
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            ),
          if (busy) const LinearProgressIndicator(),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Expanded(
                  child: TextField(
                    controller: input,
                    enabled: !busy,
                    maxLength: 2000,
                    minLines: 1,
                    maxLines: 4,
                    decoration: const InputDecoration(
                      hintText: '질문 입력',
                      counterText: '',
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(
                  tooltip: '질문 보내기',
                  onPressed: busy ? null : send,
                  icon: const Icon(Icons.send),
                ),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.only(bottom: 8),
            child: Text(
              '개인 Gemini 키 사용 · 대화는 기기에 최대 20회 보관',
              style: TextStyle(fontSize: 12),
            ),
          ),
        ],
      ),
    ),
  );
}

class LockScreenSettingsPage extends StatefulWidget {
  const LockScreenSettingsPage({super.key});
  @override
  State<LockScreenSettingsPage> createState() => _LockScreenSettingsPageState();
}

class _LockScreenSettingsPageState extends State<LockScreenSettingsPage>
    with WidgetsBindingObserver {
  bool enabled = false, allowed = false, details = false, busy = true;
  String mode = 'compact', position = 'right';
  double cardWidth = 270,
      cardHeight = 380,
      cardX = 100,
      cardY = 50,
      opacity = 80;
  String? error;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    unawaited(load());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) unawaited(load());
  }

  Future<void> load() async {
    try {
      final s =
          await bridge.invokeMapMethod<String, dynamic>('lockSettings') ?? {};
      if (mounted) {
        setState(() {
          enabled = s['enabled'] == true;
          allowed = s['allowed'] == true;
          details = s['details'] == true;
          mode = s['mode'] ?? 'compact';
          position = s['position'] ?? 'right';
          cardWidth = (s['width'] as num?)?.toDouble() ?? 270;
          cardHeight = (s['height'] as num?)?.toDouble() ?? 380;
          cardX =
              (s['x'] as num?)?.toDouble() ?? (position == 'left' ? 0 : 100);
          cardY = (s['y'] as num?)?.toDouble() ?? 50;
          opacity = (s['opacity'] as num?)?.toDouble() ?? 80;
          busy = false;
          error = null;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          busy = false;
          error = '기기 설정을 읽지 못했습니다.';
        });
      }
    }
  }

  Future<void> save(bool value) async {
    setState(() => busy = true);
    try {
      await bridge.invokeMethod('lockConfigure', {
        'enabled': value,
        'mode': mode,
        'details': details,
        'position': position,
        'width': cardWidth.round(),
        'height': cardHeight.round(),
        'x': cardX.round(),
        'y': cardY.round(),
        'opacity': opacity.round(),
      });
      await load();
    } catch (_) {
      if (mounted) {
        setState(() {
          error = '접근성 설정에서 캠퍼스레이더 잠금화면을 켠 후 다시 시도해 주세요.';
          busy = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('잠금화면 정보')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text(
          '휴대전화를 잠그고 화면을 켜면 마지막 수집한 과제 정보를 표시합니다. 잠금 해제를 대신하지 않으며, 화면을 켜거나 다른 앱 사용 중에 강제로 띄우지 않습니다.',
        ),
        const SizedBox(height: 16),
        SwitchListTile(
          title: const Text('잠금화면 카드 사용'),
          subtitle: const Text('접근성 서비스가 켜져 있어야 합니다. 기본값은 꺼짐입니다.'),
          value: enabled,
          onChanged: busy ? null : save,
        ),
        if (!allowed)
          FilledButton(
            onPressed: () => bridge.invokeMethod('lockPermission'),
            child: const Text('접근성 서비스 설정 열기'),
          ),
        const SizedBox(height: 16),
        DropdownButtonFormField<String>(
          key: ValueKey('mode:$mode'),
          initialValue: mode,
          decoration: const InputDecoration(labelText: '표시 방식'),
          items: const [
            DropdownMenuItem(value: 'compact', child: Text('작은 카드')),
            DropdownMenuItem(value: 'full', child: Text('전체 카드')),
          ],
          onChanged: busy
              ? null
              : (v) async {
                  setState(() => mode = v!);
                  await save(enabled);
                },
        ),
        const SizedBox(height: 16),
        SwitchListTile(
          title: const Text('과목명·과제명 표시'),
          subtitle: const Text(
            '끄면 개수만 표시합니다. 켜면 잠금 상태에서도 주변 사람이 내용을 볼 수 있습니다.',
          ),
          value: details,
          onChanged: busy
              ? null
              : (v) async {
                  setState(() => details = v);
                  await save(enabled);
                },
        ),
        if (mode == 'compact') ...[
          _adjuster(
            '배경 불투명도',
            opacity,
            0,
            100,
            '${opacity.round()}% · 글자는 선명하게 유지',
            (v) => opacity = v,
          ),
          const Text('작은 카드 크기와 위치'),
          const Text('화면 가장자리 안에서 배치됩니다. 내용이 길면 카드 안을 스크롤할 수 있습니다.'),
          _adjuster(
            '카드 폭',
            cardWidth,
            180,
            360,
            '${cardWidth.round()}',
            (v) => cardWidth = v,
          ),
          _adjuster(
            '카드 높이',
            cardHeight,
            180,
            640,
            '${cardHeight.round()}',
            (v) => cardHeight = v,
          ),
          _adjuster(
            '가로 위치',
            cardX,
            0,
            100,
            '${cardX.round()}% · 왼쪽 → 오른쪽',
            (v) => cardX = v,
          ),
          _adjuster(
            '세로 위치',
            cardY,
            0,
            100,
            '${cardY.round()}% · 위 → 아래',
            (v) => cardY = v,
          ),
        ] else
          const Text('전체 카드는 어느 방향으로든 스와이프하면 닫힙니다. 원래 잠금화면에서 잠금을 해제하세요.'),
        if (error != null) Text(error!),
        const SizedBox(height: 16),
        const Text(
          '접근성에서 ‘캠퍼스레이더 잠금화면’을 직접 켜 주세요. 화면 내용 읽기·입력 조작은 요청하지 않습니다. 작은 카드는 가로 스와이프로, 전체 카드는 어느 방향으로든 스와이프해 숨깁니다. 세로 스크롤로 카드 내용을 볼 수 있습니다.',
        ),
      ],
    ),
  );

  Widget _adjuster(
    String label,
    double value,
    double min,
    double max,
    String description,
    void Function(double) update,
  ) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const SizedBox(height: 16),
      Text('$label · $description'),
      Slider(
        semanticFormatterCallback: (v) => '$label ${v.round()}',
        value: value.clamp(min, max),
        min: min,
        max: max,
        divisions: ((max - min) / 10).round(),
        onChanged: busy ? null : (v) => setState(() => update(v)),
        onChangeEnd: busy ? null : (_) => save(enabled),
      ),
    ],
  );
}

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:campus_radar/updates/updates.dart' show appVersion;

const whatsNewSeenKey = 'whatsNewSeenVersion';

class WhatsNewItem {
  final IconData icon;
  final String title, body;
  const WhatsNewItem(this.icon, this.title, this.body);
}

/// Features worth pointing out after an update. Update this list with each
/// release that changes what people see; an empty list shows nothing.
const whatsNew = <WhatsNewItem>[
  WhatsNewItem(
    Icons.tune_rounded,
    '할 일 필터',
    '할 일 화면 오른쪽 위 [필터]에서 과목·마감 기간·정렬을 골라 볼 수 있어요.',
  ),
  WhatsNewItem(
    Icons.more_time_rounded,
    '추가 제출 기간 표시',
    '마감이 지나도 추가 제출이 열려 있으면 "추가 D-2"처럼 남은 시간을 보여 줘요.',
  ),
  WhatsNewItem(
    Icons.checklist_rounded,
    '처음 설정 체크리스트',
    '오늘 화면 위 카드에서 알림·배터리·위젯·시간표 설정을 한 번에 마칠 수 있어요.',
  ),
  WhatsNewItem(
    Icons.search_rounded,
    '기능 찾기',
    '더보기 맨 위에서 "휴강", "위젯", "드라이브"처럼 단어로 기능을 찾아요.',
  ),
];

/// Shows the sheet once per version for people updating from an earlier
/// one. A fresh install only records the version (the setup checklist
/// introduces the app instead).
Future<void> maybeShowWhatsNew(
  BuildContext context, {
  required bool existingUser,
}) async {
  if (whatsNew.isEmpty) return;
  final SharedPreferences prefs;
  try {
    prefs = await SharedPreferences.getInstance();
  } catch (_) {
    return;
  }
  final seen = prefs.getString(whatsNewSeenKey);
  if (seen == appVersion) return;
  await prefs.setString(whatsNewSeenKey, appVersion);
  if (!existingUser || !context.mounted) return;
  await showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (sheet) => SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '$appVersion에서 새로 생겼어요',
              style: Theme.of(sheet).textTheme.titleLarge,
            ),
            const SizedBox(height: 12),
            for (final item in whatsNew)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(item.icon),
                title: Text(item.title),
                subtitle: Text(item.body),
              ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => Navigator.pop(sheet),
                child: const Text('확인'),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

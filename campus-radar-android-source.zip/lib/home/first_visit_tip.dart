import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// One-time tip shown the first time a screen is opened. Explains gestures
/// and hidden menus (swipe to hide, ⋮ menus) that non-developers never find.
/// Dismissed for good with ✕; nothing is shown while preferences load.
class FirstVisitTip extends StatefulWidget {
  final String id;
  final IconData icon;
  final String text;
  const FirstVisitTip({
    super.key,
    required this.id,
    required this.text,
    this.icon = Icons.lightbulb_outline,
  });

  static String prefKey(String id) => 'tipSeen:$id';

  @override
  State<FirstVisitTip> createState() => _FirstVisitTipState();
}

class _FirstVisitTipState extends State<FirstVisitTip> {
  bool visible = false;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance()
        .then((p) {
          if (mounted && p.getBool(FirstVisitTip.prefKey(widget.id)) != true) {
            setState(() => visible = true);
          }
        })
        .catchError((_) {});
  }

  Future<void> close() async {
    setState(() => visible = false);
    try {
      await (await SharedPreferences.getInstance()).setBool(
        FirstVisitTip.prefKey(widget.id),
        true,
      );
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    if (!visible) return const SizedBox.shrink();
    final colors = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 6),
      child: Material(
        color: colors.secondaryContainer,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 10, 4, 10),
          child: Row(
            children: [
              Icon(widget.icon, color: colors.onSecondaryContainer, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  widget.text,
                  style: TextStyle(color: colors.onSecondaryContainer),
                ),
              ),
              IconButton(
                tooltip: '팁 닫기',
                visualDensity: VisualDensity.compact,
                onPressed: close,
                icon: Icon(
                  Icons.close,
                  size: 18,
                  color: colors.onSecondaryContainer,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

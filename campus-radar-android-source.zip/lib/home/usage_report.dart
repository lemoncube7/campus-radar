import 'package:flutter/material.dart';

import 'package:campus_radar/core/app_storage.dart';

class UsageCounts {
  final int alerts, checks, discovered;
  const UsageCounts(this.alerts, this.checks, this.discovered);
  bool get empty => alerts == 0 && checks == 0 && discovered == 0;
}

/// Counts for this month (KST) from the local activity log and new-item
/// marks. The log keeps the latest 2000 rows, so a busy month can undercount.
Future<UsageCounts> monthlyUsage(Store store, {DateTime? now}) async {
  final k = (now ?? DateTime.now()).toUtc().add(const Duration(hours: 9));
  final start = DateTime.utc(
    k.year,
    k.month,
  ).subtract(const Duration(hours: 9)).toIso8601String();
  int count(List<Map<String, Object?>> rows) => rows.length;
  final alerts = count(
    await store.db.query(
      'logs',
      columns: ['id'],
      where: "kind='notification' AND title LIKE '%발송%' AND at>=?",
      whereArgs: [start],
    ),
  );
  final checks = count(
    await store.db.query(
      'logs',
      columns: ['id'],
      where: "kind='sync' AND title LIKE '%수집 소요 시간%' AND at>=?",
      whereArgs: [start],
    ),
  );
  final discovered = count(
    await store.db.query(
      'meta',
      columns: ['id'],
      where: "id LIKE 'discovered:%' AND value>=?",
      whereArgs: [start],
    ),
  );
  return UsageCounts(alerts, checks, discovered);
}

/// "이번 달 캠퍼스레이더" line: shows what the app has been doing in the
/// background, so people trust (and keep) the automatic features.
class UsageReportCard extends StatefulWidget {
  const UsageReportCard({super.key});
  @override
  State<UsageReportCard> createState() => _UsageReportCardState();
}

class _UsageReportCardState extends State<UsageReportCard> {
  UsageCounts? counts;

  @override
  void initState() {
    super.initState();
    () async {
      try {
        final store = await Store.open();
        try {
          final c = await monthlyUsage(store);
          if (mounted) setState(() => counts = c);
        } finally {
          await store.db.close();
        }
      } catch (_) {}
    }();
  }

  @override
  Widget build(BuildContext context) {
    final c = counts;
    if (c == null || c.empty) return const SizedBox.shrink();
    final colors = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: Row(
        children: [
          Icon(Icons.insights_outlined, size: 18, color: colors.primary),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              '이번 달 캠퍼스레이더 · 알림 ${c.alerts}회 · 자동 확인 ${c.checks}회 · 새 항목 ${c.discovered}개 (최근 기록 기준)',
              style: Theme.of(
                context,
              ).textTheme.bodySmall?.copyWith(color: colors.onSurfaceVariant),
            ),
          ),
        ],
      ),
    );
  }
}

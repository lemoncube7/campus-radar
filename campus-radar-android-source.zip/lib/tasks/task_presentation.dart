import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/courses/course_colors.dart';
import 'package:flutter/material.dart';

class DesktopTaskPreview extends StatelessWidget {
  final CampusItem item;
  final VoidCallback close, open;
  const DesktopTaskPreview({
    super.key,
    required this.item,
    required this.close,
    required this.open,
  });
  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.fromLTRB(0, 16, 16, 16),
    child: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  courseLabel(item.course),
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ),
              IconButton(
                tooltip: '선택 닫기',
                onPressed: close,
                icon: const Icon(Icons.close),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(item.title, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          if (!item.isMaterial)
            Text(item.due == null ? '마감 미확인' : koreanTime(item.due!)),
          Text(
            '${remainingText(item)} · ${statusText(item)}',
            style: TextStyle(color: deadlineColor(item, context)),
          ),
          const Divider(height: 32),
          Expanded(
            child: SingleChildScrollView(
              child: SelectableText(
                item.body.isEmpty
                    ? '상세 화면에서 원문을 불러와 확인할 수 있어요.'
                    : textOf(item.body),
              ),
            ),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: open,
            icon: const Icon(Icons.open_in_new),
            label: const Text('상세 내용·강의실 바로가기'),
          ),
        ],
      ),
    ),
  );
}

class RadarTaskCard extends StatelessWidget {
  final CampusItem item;
  final bool compact;
  final bool excluded;
  final VoidCallback onTap;
  final VoidCallback? onVisibilityToggle;
  const RadarTaskCard({
    super.key,
    required this.item,
    this.compact = false,
    this.excluded = false,
    required this.onTap,
    this.onVisibilityToggle,
  });
  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final accent = deadlineColor(item, context);
    final courseColor = courseAccent('${item.courseId}:${item.classNo}');
    if (compact) {
      // Two text lines instead of five: where/what/when, then state details.
      // The remaining time moves to a badge that always carries words, so the
      // deadline is never conveyed by colour alone.
      final badge = dueBadge(item);
      final details = [
        excluded ? '숨김' : statusText(item),
        if (item.isMaterial) remainingText(item),
        if (item.progress.isNotEmpty) item.progress,
        if (item.type == 'LV' && item.attendanceRequired != null)
          item.attendanceRequired! ? '출석 반영' : '출석 미반영',
      ];
      return _swipeToToggle(
        context,
        Column(
          children: [
            ListTile(
              onLongPress: onVisibilityToggle == null
                  ? null
                  : () => _showItemSheet(context),
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 4,
                vertical: 4,
              ),
              leading: Icon(
                item.done
                    ? Icons.check_circle_outline
                    : item.type == 'LR'
                    ? Icons.assignment_outlined
                    : item.isMaterial
                    ? Icons.folder_outlined
                    : item.type == 'LV'
                    ? Icons.play_circle_outline
                    : Icons.task_alt_outlined,
                color: accent,
                size: 24,
              ),
              title: Text(
                item.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.titleSmall,
              ),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      [
                        courseLabel(item.course),
                        item.kindLabel,
                        if (!item.isMaterial)
                          item.due == null
                              ? '마감 미확인'
                              : formatDateShort(item.due!),
                      ].join(' · '),
                      style: Theme.of(context).textTheme.labelMedium,
                    ),
                    Text(
                      details.join(' · '),
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: colors.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (badge != null) DueBadge(text: badge, color: accent),
                  onVisibilityToggle == null
                      ? const Icon(Icons.chevron_right)
                      : PopupMenuButton<String>(
                          tooltip: '항목 메뉴',
                          onSelected: (_) => onVisibilityToggle?.call(),
                          itemBuilder: (_) => [
                            PopupMenuItem(
                              value: 'visibility',
                              child: Text(excluded ? '목록에 복구' : '목록에서 숨기기'),
                            ),
                          ],
                        ),
                ],
              ),
              onTap: onTap,
            ),
            const Divider(height: 1),
          ],
        ),
      );
    }
    final urgent =
        item.attendanceRequired != false &&
        (deadlineState(item.due) == DeadlineState.withinDay ||
            deadlineState(item.due) == DeadlineState.overdue);
    return _swipeToToggle(
      context,
      Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          onLongPress: onVisibilityToggle == null
              ? null
              : () => _showItemSheet(context),
          child: IntrinsicHeight(
            child: Row(
              children: [
                Container(
                  width: 4,
                  color: urgent && !item.done
                      ? accent
                      : colors.primary.withValues(alpha: .3),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Wrap(
                          spacing: 10,
                          runSpacing: 6,
                          crossAxisAlignment: WrapCrossAlignment.center,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 3,
                              ),
                              decoration: BoxDecoration(
                                color: courseColor.withValues(alpha: .12),
                                borderRadius: BorderRadius.circular(7),
                              ),
                              child: Text(
                                courseLabel(item.course),
                                style: TextStyle(
                                  color:
                                      Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Color.lerp(
                                          courseColor,
                                          Colors.white,
                                          .45,
                                        )
                                      : courseColor,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            Text(
                              remainingText(item),
                              style: TextStyle(
                                color: urgent
                                    ? accent
                                    : colors.onSurfaceVariant,
                                fontSize: 12,
                                fontWeight: urgent
                                    ? FontWeight.w700
                                    : FontWeight.w400,
                              ),
                            ),
                          ],
                        ),
                        if (!excluded &&
                            !item.done &&
                            deadlineState(item.due) == DeadlineState.overdue &&
                            onVisibilityToggle != null)
                          TextButton.icon(
                            onPressed: onVisibilityToggle,
                            icon: const Icon(Icons.check, size: 16),
                            label: const Text('확인하고 숨기기'),
                          ),
                        if (item.type == 'LV')
                          Text(
                            item.attendanceLabel,
                            style: Theme.of(context).textTheme.labelSmall,
                          ),
                        if (item.waitingAt(DateTime.now().toUtc()))
                          Text(
                            '제출 시작 ${formatDate(item.startsAt!)}',
                            style: Theme.of(context).textTheme.labelSmall,
                          ),
                        const SizedBox(height: 9),
                        Text(
                          item.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.titleMedium
                              ?.copyWith(fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(height: 7),
                        Text(
                          item.isMaterial
                              ? '자료실 · ${remainingText(item)}'
                              : '${item.kindLabel} · ${item.due == null ? '마감 미확인' : formatDate(item.due!)}',
                          style: Theme.of(context).textTheme.bodySmall
                              ?.copyWith(color: colors.onSurfaceVariant),
                        ),
                        if (excluded || item.done || item.status == 'unknown')
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(
                              excluded ? '숨김' : statusText(item),
                              style: TextStyle(color: accent, fontSize: 12),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
                if (onVisibilityToggle != null)
                  PopupMenuButton<String>(
                    tooltip: '항목 메뉴',
                    onSelected: (_) => onVisibilityToggle?.call(),
                    itemBuilder: (_) => [
                      PopupMenuItem(
                        value: 'visibility',
                        child: Text(excluded ? '목록에 복구' : '목록에서 숨기기'),
                      ),
                    ],
                  )
                else
                  Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: Icon(
                      Icons.chevron_right,
                      size: 20,
                      color: colors.onSurfaceVariant,
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Swipe left to hide (or restore) — a shortcut for the visible ⋮ menu,
  /// which stays. The list reloads after the toggle, so the row is not
  /// dismissed here.
  Widget _swipeToToggle(BuildContext context, Widget child) {
    final toggle = onVisibilityToggle;
    if (toggle == null) return child;
    final colors = Theme.of(context).colorScheme;
    return Dismissible(
      key: ValueKey('swipe-${item.key}'),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        color: colors.secondaryContainer,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              excluded
                  ? Icons.visibility_outlined
                  : Icons.visibility_off_outlined,
              color: colors.onSecondaryContainer,
            ),
            const SizedBox(width: 8),
            Text(
              excluded ? '목록에 복구' : '목록에서 숨기기',
              style: TextStyle(color: colors.onSecondaryContainer),
            ),
          ],
        ),
      ),
      confirmDismiss: (_) async {
        toggle();
        return false;
      },
      child: child,
    );
  }

  Future<void> _showItemSheet(BuildContext context) => showModalBottomSheet(
    context: context,
    showDragHandle: true,
    builder: (sheet) => SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            title: Text(
              item.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            subtitle: Text(courseLabel(item.course)),
          ),
          ListTile(
            leading: const Icon(Icons.open_in_new),
            title: const Text('열기'),
            onTap: () {
              Navigator.pop(sheet);
              onTap();
            },
          ),
          ListTile(
            leading: Icon(
              excluded
                  ? Icons.visibility_outlined
                  : Icons.visibility_off_outlined,
            ),
            title: Text(excluded ? '목록에 복구' : '목록에서 숨기기'),
            onTap: () {
              Navigator.pop(sheet);
              onVisibilityToggle?.call();
            },
          ),
        ],
      ),
    ),
  );
}

/// Remaining-time badge for list rows. Within a day it counts hours/minutes;
/// beyond that it counts Korean calendar days, so a deadline tomorrow is D-1
/// however late tonight it is.
/// The extended deadline while an unfinished item is past its normal due date
/// but inside the school's 추가 제출 window; null otherwise.
DateTime? extraDeadline(CampusItem i, {DateTime? now}) {
  final at = (now ?? DateTime.now()).toUtc();
  final extra = i.additionalDue;
  if (i.done || i.due == null || extra == null) return null;
  if (i.due!.isAfter(at) || !extra.isAfter(at)) return null;
  final start = i.additionalStartsAt;
  if (start != null && start.isAfter(at)) return null;
  return extra;
}

/// Deadline that matters now: the 추가 제출 end inside that window.
DateTime? effectiveDue(CampusItem i, {DateTime? now}) =>
    extraDeadline(i, now: now) ?? i.due;

String? dueBadge(CampusItem i, {DateTime? now}) {
  if (i.isMaterial) return null;
  if (i.done) return '완료';
  if (i.due == null) return '마감 미확인';
  final at = now ?? DateTime.now();
  final extra = extraDeadline(i, now: at);
  if (extra != null) {
    final left = extra.difference(at);
    if (left.inHours < 24) {
      return '추가 ${left.inHours < 1 ? '${left.inMinutes < 1 ? 1 : left.inMinutes}분' : '${left.inHours}시간'}';
    }
    final k = extra.toUtc().add(const Duration(hours: 9));
    final n = at.toUtc().add(const Duration(hours: 9));
    return '추가 D-${DateTime.utc(k.year, k.month, k.day).difference(DateTime.utc(n.year, n.month, n.day)).inDays}';
  }
  final diff = i.due!.difference(at);
  if (diff <= Duration.zero) return '마감 지남';
  if (diff.inHours < 1) {
    return '${diff.inMinutes < 1 ? 1 : diff.inMinutes}분 남음';
  }
  if (diff.inHours < 24) return '${diff.inHours}시간 남음';
  DateTime kstDay(DateTime t) {
    final k = t.toUtc().add(const Duration(hours: 9));
    return DateTime.utc(k.year, k.month, k.day);
  }

  return 'D-${kstDay(i.due!).difference(kstDay(at)).inDays}';
}

class DueBadge extends StatelessWidget {
  final String text;
  final Color color;
  const DueBadge({super.key, required this.text, required this.color});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
    decoration: BoxDecoration(
      color: color.withValues(alpha: .14),
      borderRadius: BorderRadius.circular(8),
    ),
    child: Text(
      text,
      style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700),
    ),
  );
}

const _weekdays = ['월', '화', '수', '목', '금', '토', '일'];

/// List-row date in Korean time without the per-row "(한국 시간)" suffix; the
/// screen states the time zone once.
String formatDateShort(DateTime date) {
  final d = date.toUtc().add(const Duration(hours: 9));
  return '${d.month}/${d.day}(${_weekdays[d.weekday - 1]}) ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
}

String formatDate(DateTime date) {
  final d = date.toUtc().add(const Duration(hours: 9));
  return '${d.month}/${d.day} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')} (한국 시간)';
}

String statusText(CampusItem i) => i.isMaterial
    ? '자료'
    : i.isOther && i.status == 'unknown'
    ? '참여 상태 미확인'
    : i.status == 'unknown'
    ? '상태 확인 불가'
    : i.done
    ? (i.type == 'LR' ? '제출 완료' : '완료')
    : (i.type == 'LR' ? '미제출' : '미완료');

String deadlineLabel(CampusItem item) {
  if (item.isMaterial) return '자료실 자료';
  if (item.done) return '완료';
  return switch (deadlineState(item.due)) {
    DeadlineState.overdue => '마감 지남',
    DeadlineState.withinDay => '1일 이내 남음',
    DeadlineState.remaining => '아직 남음',
    DeadlineState.unknown => '마감 미확인',
  };
}

Color deadlineColor(CampusItem item, [BuildContext? context]) {
  if (item.attendanceRequired == false && !item.done) {
    return context == null
        ? Colors.grey
        : Theme.of(context).colorScheme.onSurfaceVariant;
  }
  if (context != null && Theme.of(context).brightness == Brightness.dark) {
    if (item.done) return const Color(0xff8fd4b5);
    return switch (deadlineState(item.due)) {
      DeadlineState.overdue => const Color(0xffffa8a0),
      DeadlineState.withinDay => const Color(0xffffc080),
      DeadlineState.remaining => const Color(0xff91cbc5),
      DeadlineState.unknown => const Color(0xffb9c7ca),
    };
  }
  if (item.done) return Colors.green.shade800;
  return switch (deadlineState(item.due)) {
    DeadlineState.overdue => Colors.red.shade800,
    DeadlineState.withinDay => Colors.orange.shade900,
    DeadlineState.remaining => Colors.blue.shade800,
    DeadlineState.unknown => Colors.grey.shade700,
  };
}

Color deadlineBackground(CampusItem item, [BuildContext? context]) {
  if (context != null) return Theme.of(context).colorScheme.surface;
  if (item.done) return Colors.green.shade50;
  return switch (deadlineState(item.due)) {
    DeadlineState.overdue => Colors.red.shade50,
    DeadlineState.withinDay => Colors.orange.shade50,
    DeadlineState.remaining => Colors.blue.shade50,
    DeadlineState.unknown => Colors.grey.shade100,
  };
}

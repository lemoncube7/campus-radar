import 'package:flutter/material.dart';

import 'package:campus_radar/home/first_visit_tip.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/tasks/task_presentation.dart'
    show effectiveDue, extraDeadline;
import 'package:campus_radar/home/bouncy_tap.dart';
import 'package:campus_radar/home/modern_task_card.dart';

/// Highly interactive, modern mobile view for the 'Tasks' (할 일) tab.
/// Features pill-shaped category tabs with live counts, bouncy tap micro-interactions,
/// instant inline search, section grouping by deadline, and smooth gestures.
class MobileTasksView extends StatefulWidget {
  final List<CampusItem> items;
  final Set<String> excludedKeys;
  final Set<String> visibilityBusy;
  final bool isBusy;
  final VoidCallback onRefresh;
  final void Function(CampusItem item) onTaskTap;
  final void Function(CampusItem item) onTaskVisibilityToggle;

  const MobileTasksView({
    super.key,
    required this.items,
    required this.excludedKeys,
    required this.visibilityBusy,
    required this.isBusy,
    required this.onRefresh,
    required this.onTaskTap,
    required this.onTaskVisibilityToggle,
  });

  @override
  State<MobileTasksView> createState() => _MobileTasksViewState();
}

class _MobileTasksViewState extends State<MobileTasksView> {
  String selectedCategory =
      'all'; // all, urgent, assignment, video, done, hidden
  String sortBy = 'due'; // due, course, title
  String query = '';
  // Filter sheet (earlier task list features, kept behind one button).
  String course = ''; // '' = every course
  String deadline = ''; // '', overdue, withinDay, remaining, unknown
  bool showWaiting = true; // assignments whose submission has not opened yet
  String doneKind = ''; // '', task, content (only for the 완료 tab)

  bool get filtersActive =>
      course.isNotEmpty ||
      deadline.isNotEmpty ||
      !showWaiting ||
      doneKind.isNotEmpty ||
      sortBy != 'due';
  final TextEditingController searchController = TextEditingController();

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final now = DateTime.now().toUtc();

    // 1. Calculate live counts for each filter pill
    // Same rule as DashboardCounts.pending (today screen and PC list): only
    // published, open to-do items. Materials (LS) and unpublished rows used to
    // inflate 전체 to 86 while the today screen showed 4 (emulator, 11/7).
    final totalPending = widget.items
        .where(
          (i) =>
              !widget.excludedKeys.contains(i.key) &&
              i.availableAt(now) &&
              i.openTask &&
              !i.isMaterial,
        )
        .toList();

    final urgentItems = totalPending.where((i) {
      final due = effectiveDue(i, now: now);
      return due != null &&
          due.isAfter(now) &&
          due.difference(now).inHours <= 24;
    }).toList();

    final assignmentItems = totalPending.where((i) => i.type == 'LR').toList();
    final videoItems = totalPending.where((i) => i.type == 'LV').toList();
    // Completed work only; a material row has no submission to complete.
    final doneItems = widget.items
        .where((i) => i.done && !i.isMaterial)
        .toList();
    final hiddenItems = widget.items
        .where((i) => widget.excludedKeys.contains(i.key))
        .toList();

    // 2. Filter list according to selection
    List<CampusItem> filtered = [];
    switch (selectedCategory) {
      case 'urgent':
        filtered = urgentItems;
        break;
      case 'assignment':
        filtered = assignmentItems;
        break;
      case 'video':
        filtered = videoItems;
        break;
      case 'done':
        filtered = doneItems;
        break;
      case 'hidden':
        filtered = hiddenItems;
        break;
      case 'all':
      default:
        filtered = totalPending;
        break;
    }

    // 2-1. Filter sheet options
    if (course.isNotEmpty) {
      filtered = filtered.where((i) => i.course == course).toList();
    }
    if (deadline.isNotEmpty) {
      filtered = filtered.where((i) {
        final due = i.due;
        return switch (deadline) {
          'overdue' => due != null && !due.isAfter(now),
          'withinDay' =>
            due != null && due.isAfter(now) && due.difference(now).inHours < 24,
          'remaining' => due != null && due.difference(now).inHours >= 24,
          'unknown' => due == null,
          _ => true,
        };
      }).toList();
    }
    if (!showWaiting) {
      filtered = filtered.where((i) => !i.waitingAt(now)).toList();
    }
    if (selectedCategory == 'done' && doneKind.isNotEmpty) {
      filtered = filtered
          .where((i) => doneKind == 'content' ? i.type == 'LV' : i.type != 'LV')
          .toList();
    }

    // 3. Search query filter
    if (query.trim().isNotEmpty) {
      final q = query.trim().toLowerCase();
      filtered = filtered
          .where(
            (i) =>
                i.title.toLowerCase().contains(q) ||
                i.course.toLowerCase().contains(q),
          )
          .toList();
    }

    // 4. Sort items
    filtered.sort((a, b) {
      if (sortBy == 'course') return a.course.compareTo(b.course);
      if (sortBy == 'title') return a.title.compareTo(b.title);
      // by due; past deadlines go last, as on the today screen and PC list,
      // so weeks-old misses do not push this week's work off the screen.
      // 추가 제출 items lead as one group: already past the normal deadline.
      final aLate = extraDeadline(a, now: now) != null;
      final bLate = extraDeadline(b, now: now) != null;
      if (aLate != bLate) return aLate ? -1 : 1;
      // 추가 제출 window counts by its extended deadline, not as a miss.
      final aEff = effectiveDue(a, now: now), bEff = effectiveDue(b, now: now);
      final aPast = aEff != null && !aEff.isAfter(now);
      final bPast = bEff != null && !bEff.isAfter(now);
      if (aPast != bPast) return aPast ? 1 : -1;
      if (aPast) return bEff!.compareTo(aEff); // most recent miss first
      final aDue = aEff ?? DateTime.utc(2100);
      final bDue = bEff ?? DateTime.utc(2100);
      return aDue.compareTo(bDue);
    });

    return RefreshIndicator(
      onRefresh: () async => widget.onRefresh(),
      child: Column(
        children: [
          // ── Search & Sort Row ──
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      color: colorScheme.surfaceContainerHighest.withValues(
                        alpha: 0.5,
                      ),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: TextField(
                      controller: searchController,
                      onChanged: (val) => setState(() => query = val),
                      decoration: InputDecoration(
                        hintText: '과제 또는 과목 검색',
                        hintStyle: theme.textTheme.bodyMedium?.copyWith(
                          color: colorScheme.onSurfaceVariant.withValues(
                            alpha: 0.7,
                          ),
                        ),
                        prefixIcon: Icon(
                          Icons.search_rounded,
                          size: 20,
                          color: colorScheme.onSurfaceVariant,
                        ),
                        suffixIcon: query.isNotEmpty
                            ? IconButton(
                                icon: const Icon(Icons.clear_rounded, size: 18),
                                onPressed: () {
                                  searchController.clear();
                                  setState(() => query = '');
                                },
                              )
                            : null,
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                          vertical: 12,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                // Sort Toggle Menu Button
                BouncyTap(
                  onTap: () => _showFilterSheet(context),
                  child: Container(
                    height: 44,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: filtersActive
                          ? colorScheme.primaryContainer
                          : colorScheme.surfaceContainerHighest.withValues(
                              alpha: 0.5,
                            ),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.tune_rounded,
                          size: 18,
                          color: colorScheme.onSurfaceVariant,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          filtersActive ? '필터 •' : '필터',
                          style: theme.textTheme.labelMedium?.copyWith(
                            color: colorScheme.onSurfaceVariant,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // ── Horizontal Filter Pill Tabs with Counts ──
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              children: [
                _buildPillTab(
                  'all',
                  '전체',
                  totalPending.length,
                  colorScheme,
                  theme,
                ),
                const SizedBox(width: 8),
                if (urgentItems.isNotEmpty) ...[
                  _buildPillTab(
                    'urgent',
                    '🔥 마감임박',
                    urgentItems.length,
                    colorScheme,
                    theme,
                    isUrgent: true,
                  ),
                  const SizedBox(width: 8),
                ],
                _buildPillTab(
                  'assignment',
                  '과제',
                  assignmentItems.length,
                  colorScheme,
                  theme,
                ),
                const SizedBox(width: 8),
                _buildPillTab(
                  'video',
                  '동영상',
                  videoItems.length,
                  colorScheme,
                  theme,
                ),
                const SizedBox(width: 8),
                _buildPillTab(
                  'done',
                  '완료',
                  doneItems.length,
                  colorScheme,
                  theme,
                ),
                const SizedBox(width: 8),
                if (hiddenItems.isNotEmpty)
                  _buildPillTab(
                    'hidden',
                    '숨김',
                    hiddenItems.length,
                    colorScheme,
                    theme,
                  ),
              ],
            ),
          ),

          const SizedBox(height: 4),
          const FirstVisitTip(
            id: 'tasks',
            icon: Icons.swipe_left_outlined,
            text: '카드를 왼쪽으로 밀면 목록에서 숨겨져요. 오른쪽 위 [필터]로 과목·마감별로 골라 볼 수 있어요.',
          ),

          // ── Tasks Scroll List ──
          Expanded(
            child: filtered.isEmpty
                ? _buildEmptyState(colorScheme, theme)
                : ListView.builder(
                    padding: EdgeInsets.fromLTRB(
                      16,
                      8,
                      16,
                      80 + MediaQuery.paddingOf(context).bottom,
                    ),
                    itemCount: filtered.length,
                    itemBuilder: (context, index) {
                      final item = filtered[index];
                      // Show section header if sorting by due
                      final showHeader =
                          sortBy == 'due' &&
                          (index == 0 ||
                              _sectionFor(item, now) !=
                                  _sectionFor(filtered[index - 1], now));

                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (showHeader)
                            Padding(
                              padding: const EdgeInsets.fromLTRB(4, 16, 4, 6),
                              child: Text(
                                _sectionFor(item, now),
                                style: theme.textTheme.labelLarge?.copyWith(
                                  color: colorScheme.primary,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: -0.2,
                                ),
                              ),
                            ),
                          ModernTaskCard(
                            item: item,
                            excluded: widget.excludedKeys.contains(item.key),
                            onTap: () => widget.onTaskTap(item),
                            onVisibilityToggle:
                                widget.visibilityBusy.contains(item.key)
                                ? null
                                : () => widget.onTaskVisibilityToggle(item),
                          ),
                        ],
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildPillTab(
    String key,
    String label,
    int count,
    ColorScheme colorScheme,
    ThemeData theme, {
    bool isUrgent = false,
  }) {
    final selected = selectedCategory == key;

    final bgColor = selected
        ? (isUrgent ? colorScheme.error : colorScheme.primary)
        : (isUrgent
              ? colorScheme.errorContainer.withValues(alpha: 0.35)
              : colorScheme.surfaceContainerHighest.withValues(alpha: 0.5));

    final textColor = selected
        ? (isUrgent ? colorScheme.onError : colorScheme.onPrimary)
        : (isUrgent ? colorScheme.error : colorScheme.onSurfaceVariant);

    return BouncyTap(
      onTap: () => setState(() => selectedCategory = key),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected
                ? Colors.transparent
                : colorScheme.outlineVariant.withValues(alpha: 0.4),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              label,
              style: theme.textTheme.labelMedium?.copyWith(
                color: textColor,
                fontWeight: selected ? FontWeight.bold : FontWeight.w500,
              ),
            ),
            const SizedBox(width: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
              decoration: BoxDecoration(
                color: selected
                    ? Colors.white.withValues(alpha: 0.25)
                    : colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                '$count',
                style: theme.textTheme.labelSmall?.copyWith(
                  color: textColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 10,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(ColorScheme colorScheme, ThemeData theme) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: colorScheme.primaryContainer.withValues(alpha: 0.3),
                shape: BoxShape.circle,
              ),
              child: Icon(
                query.isNotEmpty
                    ? Icons.search_off_rounded
                    : Icons.check_circle_outline_rounded,
                size: 40,
                color: colorScheme.primary,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              query.isNotEmpty ? '검색 결과가 없어요' : '선택한 조건에 맞는 과제가 없어요',
              style: theme.textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              query.isNotEmpty
                  ? '다른 단어로 검색하거나 필터를 재설정해 보세요.'
                  : '모든 할 일을 마쳤거나 해당하는 항목이 없습니다.',
              style: theme.textTheme.bodySmall?.copyWith(
                color: colorScheme.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
            if (query.isNotEmpty ||
                selectedCategory != 'all' ||
                filtersActive) ...[
              const SizedBox(height: 16),
              TextButton(
                onPressed: () {
                  searchController.clear();
                  setState(() {
                    query = '';
                    selectedCategory = 'all';
                    course = '';
                    deadline = '';
                    showWaiting = true;
                    doneKind = '';
                    sortBy = 'due';
                  });
                },
                child: const Text('필터 초기화'),
              ),
            ],
          ],
        ),
      ),
    );
  }

  String _sectionFor(CampusItem item, DateTime now) {
    if (item.done) return '완료된 항목';
    if (item.due == null) return '마감 미확인';
    if (extraDeadline(item, now: now) != null) return '추가 제출 기간';
    final diff = item.due!.difference(now);
    if (diff.isNegative) return '마감 지난 항목';
    if (diff.inHours <= 24) return '24시간 이내 마감';
    if (diff.inDays <= 3) return '3일 이내 마감';
    if (diff.inDays <= 7) return '이번 주 마감';
    return '다음 주 이후 마감';
  }

  void _showFilterSheet(BuildContext context) {
    final courses = widget.items.map((i) => i.course).toSet().toList()..sort();
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (sheetContext, setSheet) {
          void update(VoidCallback change) {
            setState(change);
            setSheet(() {});
          }

          Widget group(
            String title,
            String value,
            Map<String, String> options,
            void Function(String) pick,
          ) => Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: Theme.of(sheetContext).textTheme.titleSmall),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    for (final e in options.entries)
                      ChoiceChip(
                        label: Text(e.value),
                        selected: value == e.key,
                        onSelected: (_) => update(() => pick(e.key)),
                      ),
                  ],
                ),
              ],
            ),
          );

          return SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        '할 일 필터',
                        style: Theme.of(sheetContext).textTheme.titleMedium,
                      ),
                      const Spacer(),
                      TextButton(
                        onPressed: filtersActive
                            ? () => update(() {
                                course = '';
                                deadline = '';
                                showWaiting = true;
                                doneKind = '';
                                sortBy = 'due';
                              })
                            : null,
                        child: const Text('초기화'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  group('과목', course, {
                    '': '전체',
                    for (final c in courses) c: c,
                  }, (v) => course = v),
                  group('마감', deadline, const {
                    '': '전체',
                    'overdue': '마감 지남',
                    'withinDay': '24시간 이내',
                    'remaining': '아직 남음',
                    'unknown': '마감 미확인',
                  }, (v) => deadline = v),
                  group('정렬', sortBy, const {
                    'due': '마감순',
                    'course': '과목순',
                    'title': '제목순',
                  }, (v) => sortBy = v),
                  group('완료 탭에서 보기', doneKind, const {
                    '': '전체',
                    'task': '과제 등',
                    'content': '콘텐츠(동영상)',
                  }, (v) => doneKind = v),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('제출 대기 과제 보기'),
                    subtitle: const Text('공개됐지만 제출이 아직 시작되지 않은 과제'),
                    value: showWaiting,
                    onChanged: (v) => update(() => showWaiting = v),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () => Navigator.pop(sheetContext),
                      child: const Text('적용'),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ignore: unused_element
  void _showSortMenu(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    '정렬 방식',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.timer_outlined),
                title: const Text('마감 임박순'),
                trailing: sortBy == 'due'
                    ? const Icon(Icons.check, color: Colors.blue)
                    : null,
                onTap: () {
                  setState(() => sortBy = 'due');
                  Navigator.pop(ctx);
                },
              ),
              ListTile(
                leading: const Icon(Icons.school_outlined),
                title: const Text('과목순'),
                trailing: sortBy == 'course'
                    ? const Icon(Icons.check, color: Colors.blue)
                    : null,
                onTap: () {
                  setState(() => sortBy = 'course');
                  Navigator.pop(ctx);
                },
              ),
              ListTile(
                leading: const Icon(Icons.sort_by_alpha_rounded),
                title: const Text('과제명순'),
                trailing: sortBy == 'title'
                    ? const Icon(Icons.check, color: Colors.blue)
                    : null,
                onTap: () {
                  setState(() => sortBy = 'title');
                  Navigator.pop(ctx);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import 'package:campus_radar/ai/ai_cancellation_notification.dart';
import 'package:campus_radar/ai/ai_inbox_repository.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/ai/ai_state_models.dart';
import 'package:campus_radar/ai/ai_state_repository.dart';
import 'package:campus_radar/ai/chat_threads.dart';
import 'package:campus_radar/campus/campus_media.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/demo_state.dart';
import 'package:campus_radar/core/developer_mode.dart';
import 'package:campus_radar/core/operation_token.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/courses/course_aliases.dart';
import 'package:campus_radar/courses/course_colors.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/settings/radar_theme.dart';
import 'package:campus_radar/tasks/task_display_preferences.dart';

export 'package:campus_radar/core/demo_state.dart'
    show
        compileTimeDemoMode,
        demoModeNotifier,
        isDemoActive,
        isRuntimeDemoActive,
        initDemoState;

/// True when either `--dart-define=DEMO=true` or runtime demo mode is active.
bool get demoMode => isDemoActive;

const demoChatOfflineReply =
    '체험 모드에서는 미리 준비된 답만 보여요. 포털과 개인 Gemini 키를 연결하면 내 과제·공지·시간표를 바탕으로 직접 질문할 수 있어요.';

const _courses = [
  ('d1', '인공지능과 미래사회', 4, 540, 630, '교404A'),
  ('d2', '물리학개론', 4, 990, 1080, '교301'),
  ('d3', '선형대수', 1, 660, 750, '공5405'),
  ('d4', '논리와비판적사고', 1, 540, 630, '교207'),
  ('d5', '어드벤처디자인', 2, 900, 1020, '공5412'),
];

const _extraSlots = [
  ('d1', '인공지능과 미래사회', 2, 600, 690, '교404A'),
  ('d3', '선형대수', 3, 660, 750, '공5405'),
  ('d2', '물리학개론', 5, 840, 930, '교301'),
];

String _ymd(DateTime utcDate) =>
    '${utcDate.year.toString().padLeft(4, '0')}-${utcDate.month.toString().padLeft(2, '0')}-${utcDate.day.toString().padLeft(2, '0')}';

Future<void> enterDemoMode({
  String entrySource = 'dashboard',
  @visibleForTesting Future<void> Function()? seedAction,
}) async {
  await beginDemoActivation(entrySource: entrySource);
  try {
    if (seedAction != null) {
      await seedAction();
    } else {
      await seedDemo(force: true);
    }
    finishDemoActivation();
  } catch (_) {
    await cancelDemoActivation();
    rethrow;
  }
}

Future<String> exitDemoMode() async {
  final entrySource = await deactivateDemoState();
  await initDeveloperMode();
  await loadRadarTheme();
  await loadTaskDisplayPreferences().catchError((_) {});
  await loadCourseAliases();
  await loadCourseColors();
  return entrySource;
}

/// Sends a one-shot example cancellation notification reusing the production
/// cancellation notification builder and sender. Returns `sent: false` when
/// notification permission is disabled so the caller can show guidance instead.
Future<({bool sent, String? payload})> sendDemoCancellationExampleNotification({
  CancellationNotifier notifier = showCancellationNotification,
}) async {
  if (!isDemoActive) return (sent: false, payload: null);
  final store = await Store.open();
  try {
    final snapshot = await AiInboxRepository(store).read();
    final match = snapshot.candidates.where((row) {
      final c = row['candidate'] as ScheduleCandidate;
      return c.category == 'class' && c.action == 'cancel';
    }).firstOrNull;
    if (match == null) return (sent: false, payload: null);
    final notice = match['notice'] as CampusNotice;
    final candidate = match['candidate'] as ScheduleCandidate;
    final key = match['key'] as String;
    final slots = decodeSlots(await store.meta(MetaKey.timetableEntries));
    final planned = matchCandidateCancellations(slots, notice, candidate);
    if (planned.isEmpty) return (sent: false, payload: null);
    final message = formatCancellationNotification(notice, planned);
    final payload = cancellationNotificationPayload(notice.id, key);
    final sent = await notifier(
      key: key,
      title: message.title,
      body: message.body,
      payload: payload,
    );
    return (sent: sent, payload: payload);
  } finally {
    await store.db.close();
  }
}

Future<void> seedDemo({bool force = false, DateTime? nowOverride}) async {
  if (!isDemoActive) return;
  final store = await Store.open();
  try {
    if (!force && await store.meta(MetaKey.lastSuccess) != null) return;
    final now = (nowOverride ?? DateTime.now()).toUtc();
    final kstNow = now.add(const Duration(hours: 9));
    final todayKst = DateTime.utc(kstNow.year, kstNow.month, kstNow.day);
    final endOfTodayUtc = todayKst
        .add(const Duration(hours: 23, minutes: 59, seconds: 50))
        .subtract(const Duration(hours: 9));
    final remainingToday = endOfTodayUtc.difference(now);
    final todayDueOffset = remainingToday > const Duration(hours: 3)
        ? const Duration(hours: 3)
        : remainingToday > const Duration(minutes: 2)
        ? remainingToday - const Duration(minutes: 1)
        : const Duration(seconds: 30);

    Map<String, dynamic> ctx(String id) => {'course_id': id, 'class_no': '1'};
    String courseName(String id) =>
        _courses.firstWhere((c) => c.$1 == id).$2;

    CampusItem item(
      String id,
      String type,
      String title,
      String course,
      Duration? due, {
      String status = 'pending',
      Duration? extra,
      String body = '',
      String externalUrl = '',
      List<CampusMedia> media = const [],
    }) => CampusItem.fromJson({
      'key': '$type:$course:1:$id',
      'type': type,
      'title': title,
      'course': courseName(course),
      'courseId': course,
      'classNo': '1',
      'contentsId': id,
      'status': status,
      if (due != null) 'due': now.add(due).toIso8601String(),
      // 추가 제출 window: opened at the normal deadline, ends at `extra`.
      if (due != null && extra != null)
        'additionalStartsAt': now.add(due).toIso8601String(),
      if (extra != null) 'additionalDue': now.add(extra).toIso8601String(),
      'published': true,
      'attendanceRequired': type == 'LV' ? true : null,
      if (body.isNotEmpty) 'body': body,
      if (externalUrl.isNotEmpty) 'externalUrl': externalUrl,
      if (media.isNotEmpty) 'media': media.map((m) => m.toJson()).toList(),
      'context': ctx(course),
    });

    await store.replace([
      // 오늘 마감 과제 (KST 기준 오늘 안에 마감 보장)
      item(
        'r0',
        'LR',
        '10주차 개념 확인 퀴즈 정리 제출',
        'd1',
        todayDueOffset,
        body: '강의 핵심 키워드 3가지를 A4 1페이지 이내로 정리해 오늘 자정 전까지 제출하세요.',
      ),
      item(
        'r1',
        'LR',
        '10주차 팀 활동 보고서 제출',
        'd5',
        const Duration(hours: 20),
        body: '조별 프로토타입 회의 결과와 역할 분담표를 PDF로 제출합니다.',
      ),
      item(
        'r2',
        'LR',
        '(과제2) 머신러닝 학습 방법 리포트',
        'd1',
        const Duration(days: 4),
        body: '지도학습과 비지도학습 사례를 비교 분석해 제출해 주세요.',
      ),
      // 출석 인정 강의 영상
      item('v0', 'LV', '10주차 핵심 개념 강의 영상', 'd1', const Duration(days: 2)),
      item('v1', 'LV', '9-2. 연습문제', 'd4', const Duration(days: 5)),
      item('v2', 'LV', '8주차 강의 영상', 'd2', const Duration(days: 9)),
      // 제출 완료 과제
      item('r3', 'LR', '중간 과제', 'd3', const Duration(days: -3), status: 'done'),
      // 마감 지남 미제출 과제
      item(
        'r6',
        'LR',
        '7주차 연습문제 풀이 제출',
        'd2',
        const Duration(hours: -8),
        body: '교재 7장 연습문제 1~5번 풀이 과정을 스캔해 업로드하세요.',
      ),
      // 추가 제출 기간 진행 중 과제
      item(
        'r4',
        'LR',
        '9주차 실습 보고서 (추가 제출)',
        'd3',
        const Duration(days: -1),
        extra: const Duration(days: 3),
        body: '정규 마감 이후 추가 제출 기간이 열려 있습니다(감점 기준은 강의계획서 참고).',
      ),
      item(
        'r5',
        'LR',
        '토론 정리문 (추가 제출 마감 임박)',
        'd4',
        const Duration(days: -2),
        extra: const Duration(hours: 10),
        body: '수업 중 진행한 찬반 토론의 논거 요약을 추가 제출 기간 안에 등록해 주세요.',
      ),
      // 강의 자료 (LS)
      item(
        'm1',
        'LS',
        '10주차 트랜스포머와 생성형 AI 강의안',
        'd1',
        null,
        status: 'done',
        body: '수업 전 1~18쪽 슬라이드를 미리 읽고 참석하면 이해에 도움이 됩니다.',
        media: const [
          CampusMedia(
            name: '10주차_트랜스포머와_생성형AI.pdf',
            url: 'https://dcs-learning.cnu.ac.kr/demo/ai_week10.pdf',
            size: 2480000,
          ),
        ],
      ),
      item(
        'm2',
        'LS',
        '고윳값과 대각화 요약 노트 및 연습문제 해답',
        'd3',
        null,
        status: 'done',
        body: '선형대수 9~10주차 핵심 정리 및 예제 풀이 모음입니다.',
        media: const [
          CampusMedia(
            name: '선형대수_고윳값_요약노트.pdf',
            url: 'https://dcs-learning.cnu.ac.kr/demo/linalg_eigen.pdf',
            size: 1320000,
          ),
        ],
      ),
      item(
        'm3',
        'LS',
        '팀 프로젝트 중간 발표 템플릿 및 참고 링크',
        'd5',
        null,
        status: 'done',
        body: '발표 시간은 팀당 8분이며 질의응답 3분으로 진행합니다.',
        externalUrl: 'https://dcs-learning.cnu.ac.kr/home',
        media: const [
          CampusMedia(
            name: '어드벤처디자인_발표템플릿.pptx',
            url: 'https://dcs-learning.cnu.ac.kr/demo/design_template.pptx',
            size: 3150000,
          ),
        ],
      ),
    ]);

    // 다가오는 월요일(논리와비판적사고 09:00~10:30 수업)과 시험일 계산
    final daysUntilMon = (DateTime.monday - todayKst.weekday + 7) % 7;
    final nextMon = todayKst.add(
      Duration(days: daysUntilMon == 0 ? 7 : daysUntilMon),
    );
    final cancelDateStr = _ymd(nextMon);
    final cancelQuote =
        '${nextMon.month}월 ${nextMon.day}일 09:00~10:30 수업은 학회 참석으로 휴강합니다.';

    final examDay = todayKst.add(const Duration(days: 10));
    final examDateStr = _ymd(examDay);
    final examQuote =
        '${examDay.month}월 ${examDay.day}일 10:00~11:30 교404A에서 지필 시험을 진행합니다.';

    final demoNotices = [
      CampusNotice(
        id: 'n3',
        title: '휴강 공지',
        course: courseName('d4'),
        context: ctx('d4'),
        published: now.subtract(const Duration(hours: 3)),
        read: false,
        body: '안녕하세요, 논리와비판적사고 수강생 여러분.\n$cancelQuote\n보강 일정은 추후 공지하겠습니다.',
        bodyHtml: '<p>안녕하세요, 논리와비판적사고 수강생 여러분.</p><p>$cancelQuote</p>',
        bodyFetched: true,
      ),
      CampusNotice(
        id: 'n4',
        title: '기말 지필 시험 일정 안내',
        course: courseName('d1'),
        context: ctx('d1'),
        published: now.subtract(const Duration(hours: 8)),
        read: false,
        body: '인공지능과 미래사회 시험 일정을 안내합니다.\n$examQuote\n학생증을 지참해 주세요.',
        bodyHtml: '<p>인공지능과 미래사회 시험 일정을 안내합니다.</p><p>$examQuote</p>',
        bodyFetched: true,
      ),
      CampusNotice(
        id: 'n0',
        title: '보강 안내',
        course: courseName('d1'),
        context: ctx('d1'),
        published: now.subtract(const Duration(hours: 18)),
        read: false,
        body: '지난주 공휴일 수업분에 대한 온라인 보강 영상이 강의실에 업로드되었습니다.',
        bodyHtml: '<p>지난주 공휴일 수업분에 대한 온라인 보강 영상이 강의실에 업로드되었습니다.</p>',
        bodyFetched: true,
      ),
      CampusNotice(
        id: 'n1',
        title: '중간고사 성적 공개',
        course: courseName('d2'),
        context: ctx('d2'),
        published: now.subtract(const Duration(hours: 36)),
        read: true,
        body: '사이버캠퍼스 성적 메뉴에서 중간고사 점수를 확인할 수 있습니다.',
        bodyHtml: '<p>사이버캠퍼스 성적 메뉴에서 중간고사 점수를 확인할 수 있습니다.</p>',
        bodyFetched: true,
      ),
      CampusNotice(
        id: 'n2',
        title: '팀 편성 결과',
        course: courseName('d3'),
        context: ctx('d3'),
        published: now.subtract(const Duration(hours: 60)),
        read: true,
        body: '실습 조 편성이 확정되었습니다. 자료실의 조별 명단을 확인해 주세요.',
        bodyHtml: '<p>실습 조 편성이 확정되었습니다. 자료실의 조별 명단을 확인해 주세요.</p>',
        bodyFetched: true,
      ),
    ];

    await store.replaceNotices(demoNotices);
    for (final n in demoNotices) {
      await store.saveNotice(n);
    }

    await store.setMeta(
      MetaKey.courses,
      jsonEncode([
        for (final c in _courses)
          {'course_id': c.$1, 'class_no': '1', 'course_nm': c.$2},
      ]),
    );
    await store.setMeta(
      MetaKey.timetableEntries,
      jsonEncode([
        for (final c in [..._courses, ..._extraSlots])
          ClassSlot(
            courseKey: '${c.$1}:1',
            course: c.$2,
            weekday: c.$3,
            start: c.$4,
            end: c.$5,
            room: c.$6,
            source: 'demo',
          ).toJson(),
      ]),
    );

    // 세션 및 AI 기본 설정 (네트워크 호출 없이 검토함·채팅 열람 가능하도록 설정)
    await store.setMeta(MetaKey.sessionEpoch, freshToken());
    await store.setMeta(MetaKey.sessionBlocked, 'no');
    await store.setMeta(MetaKey.aiConsent, aiConsentVersion);
    await store.setMeta(MetaKey.aiAuto, 'no');
    await store.setMeta(MetaKey.aiChatConsent, '1');
    await store.setMeta(MetaKey.aiChatShare, 'yes');

    // 검토함 미처리 휴강 후보 1개 + 시험 후보 1개 (실제 ScheduleCandidate.parse 검증 통과)
    final cancelNotice = demoNotices[0];
    final cancelCandidate = ScheduleCandidate.parse(
      {
        'title': '논리와비판적사고 휴강',
        'date': cancelDateStr,
        'time': '09:00',
        'endDate': cancelDateStr,
        'endTime': '10:30',
        'action': 'cancel',
        'category': 'class',
        'condition': 'required',
        'evidence': cancelQuote,
        'sourceQuotes': [cancelQuote],
        'uncertainty': '',
      },
      '${cancelNotice.title}\n${cancelNotice.body}',
    );
    final cancelKey = candidateKey(cancelNotice, cancelCandidate);
    await store.setMeta(
      MetaKey.aiCandidate(cancelKey),
      jsonEncode({
        'key': cancelKey,
        'notice': cancelNotice.toJson(),
        'candidate': cancelCandidate.toJson(),
      }),
    );
    await store.setMeta(
      MetaKey.aiState(cancelKey),
      jsonEncode({'status': 'review'}),
    );
    await AiStateRepository(store).saveJob(
      cancelNotice.id,
      AiJob.fromJson({
        'status': 'done',
        'fingerprint': noticeFingerprint(cancelNotice),
        'validationVersion': aiValidationVersion,
        'checked': now.toIso8601String(),
        'title': cancelNotice.title,
        'count': 1,
      }),
    );

    final examNotice = demoNotices[1];
    final examCandidate = ScheduleCandidate.parse(
      {
        'title': '인공지능과 미래사회 기말 지필 시험',
        'date': examDateStr,
        'time': '10:00',
        'endDate': examDateStr,
        'endTime': '11:30',
        'action': 'add',
        'category': 'exam',
        'condition': 'required',
        'evidence': examQuote,
        'sourceQuotes': [examQuote],
        'uncertainty': '',
      },
      '${examNotice.title}\n${examNotice.body}',
    );
    final examKey = candidateKey(examNotice, examCandidate);
    await store.setMeta(
      MetaKey.aiCandidate(examKey),
      jsonEncode({
        'key': examKey,
        'notice': examNotice.toJson(),
        'candidate': examCandidate.toJson(),
      }),
    );
    await store.setMeta(
      MetaKey.aiState(examKey),
      jsonEncode({'status': 'review'}),
    );
    await AiStateRepository(store).saveJob(
      examNotice.id,
      AiJob.fromJson({
        'status': 'done',
        'fingerprint': noticeFingerprint(examNotice),
        'validationVersion': aiValidationVersion,
        'checked': now.toIso8601String(),
        'title': examNotice.title,
        'count': 1,
      }),
    );

    // AI 채팅 미리 준비된 스레드 1개
    await saveChatThread(
      store,
      'aiChat:all',
      ChatThread(
        'demo-thread-1',
        '이번 주 먼저 챙길 마감과 휴강 공지 요약해 줘',
        [
          {
            'role': 'user',
            'text': '이번 주 먼저 챙길 마감과 휴강 공지 요약해 줘',
          },
          {
            'role': 'model',
            'text':
                '현재 수집된 예시 목록 기준으로 먼저 확인할 항목이에요.\n\n'
                '1. **인공지능과 미래사회** · ‘10주차 개념 확인 퀴즈 정리 제출’ — **오늘 마감**이므로 가장 먼저 제출 여부를 확인해 주세요.\n'
                '2. **논리와비판적사고** · ‘토론 정리문 (추가 제출 마감 임박)’ — 추가 제출 기간이 곧 끝나니 놓치지 마세요.\n'
                '3. **휴강 후보 안내** — ‘논리와비판적사고’ **${nextMon.month}월 ${nextMon.day}일 09:00** 수업에 대한 휴강 공지가 감지되어 **검토함**에 대기 중이에요. 검토함에서 확인 후 시간표에 반영할 수 있어요.',
          },
        ],
      ),
    );

    await store.setMeta(MetaKey.lastSuccess, now.toIso8601String());
  } finally {
    await store.db.close();
  }
}

/// Root section requested by the simulator workflow (Documents/demo_tab).
Future<int?> demoStartTab() async {
  if (!isDemoActive) return null;
  try {
    final dir = await getApplicationDocumentsDirectory();
    return int.tryParse(
      (await File('${dir.path}/demo_tab').readAsString()).trim(),
    );
  } catch (_) {
    return null;
  }
}

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:campus_radar/core/storage_keys.dart';

final ValueNotifier<bool> developerModeNotifier = ValueNotifier<bool>(false);

bool get isDeveloperMode => developerModeNotifier.value;

Future<bool> initDeveloperMode() async {
  try {
    final prefs = await SharedPreferences.getInstance();
    await prefs.reload();
    final active = prefs.getBool(PrefKey.developerMode) == true;
    developerModeNotifier.value = active;
    return active;
  } catch (_) {
    return developerModeNotifier.value;
  }
}

Future<void> setDeveloperMode(bool enabled) async {
  developerModeNotifier.value = enabled;
  try {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(PrefKey.developerMode, enabled);
  } catch (_) {}
}

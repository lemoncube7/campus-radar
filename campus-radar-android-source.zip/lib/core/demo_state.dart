import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';

import 'package:campus_radar/core/storage_keys.dart';

/// Compile-time flag (`--dart-define=DEMO=true`) kept for simulator/screenshot CI.
const compileTimeDemoMode = bool.fromEnvironment('DEMO');

const demoDbName = 'campus_demo.db';
const realDbName = 'campus.db';

const demoActivePrefKey = 'demoModeActive';
const demoEntrySourcePrefKey = 'demoEntrySource';
const demoPrefsBackupPrefKey = 'demoPrefsBackupJson';

const _demoInternalPrefKeys = <String>{
  demoActivePrefKey,
  demoEntrySourcePrefKey,
  demoPrefsBackupPrefKey,
};

/// Real home/lock widget caches read directly by Android Kotlin AppWidgets.
/// Never overwritten during demo mode and never deleted on demo exit.
const _protectedWidgetPrefKeys = <String>{
  PrefKey.widgetSnapshotJson,
  PrefKey.widgetTimetableJson,
};

/// Runtime reactive flag for user-entered demo ("체험 모드").
final ValueNotifier<bool> demoModeNotifier = ValueNotifier<bool>(false);

bool _preparingDemo = false;

/// True when either `--dart-define=DEMO=true` or runtime demo mode is active.
bool get isDemoActive =>
    compileTimeDemoMode || _preparingDemo || demoModeNotifier.value;

/// True when the user entered runtime demo mode (shows top "체험 중" banner).
bool get isRuntimeDemoActive => demoModeNotifier.value;

String get activeDatabaseFileName => isDemoActive ? demoDbName : realDbName;

Future<String> demoDatabasePath() async =>
    '${await getDatabasesPath()}/$demoDbName';

Future<String> realDatabasePath() async =>
    '${await getDatabasesPath()}/$realDbName';

/// Restores persisted runtime demo state on app launch or background isolate start.
Future<bool> initDemoState() async {
  try {
    final prefs = await SharedPreferences.getInstance();
    await prefs.reload();
    final active = prefs.getBool(demoActivePrefKey) == true;
    if (demoModeNotifier.value != active) {
      demoModeNotifier.value = active;
    }
  } catch (_) {
    // In environments without SharedPreferences, fall back to compile-time flag.
  }
  return isDemoActive;
}

Map<String, dynamic> _encodePrefSnapshot(SharedPreferences prefs) {
  final snapshot = <String, dynamic>{};
  for (final key in prefs.getKeys()) {
    if (_demoInternalPrefKeys.contains(key) ||
        _protectedWidgetPrefKeys.contains(key)) {
      continue;
    }
    final raw = prefs.get(key);
    if (raw is bool) {
      snapshot[key] = {'t': 'bool', 'v': raw};
    } else if (raw is int) {
      snapshot[key] = {'t': 'int', 'v': raw};
    } else if (raw is double) {
      snapshot[key] = {'t': 'double', 'v': raw};
    } else if (raw is String) {
      snapshot[key] = {'t': 'string', 'v': raw};
    } else if (raw is List) {
      snapshot[key] = {
        't': 'list',
        'v': raw.map((e) => '$e').toList(),
      };
    }
  }
  return snapshot;
}

Future<void> _restorePrefSnapshot(
  SharedPreferences prefs,
  String? backupRaw,
) async {
  if (backupRaw == null || backupRaw.isEmpty) {
    for (final key in _demoInternalPrefKeys) {
      await prefs.remove(key);
    }
    return;
  }
  Map<String, dynamic> backup;
  try {
    backup = Map<String, dynamic>.from(jsonDecode(backupRaw) as Map);
  } catch (_) {
    for (final key in _demoInternalPrefKeys) {
      await prefs.remove(key);
    }
    return;
  }
  final existingKeys = prefs.getKeys().toList();
  for (final key in existingKeys) {
    if (_protectedWidgetPrefKeys.contains(key)) continue;
    if (!backup.containsKey(key)) {
      await prefs.remove(key);
    }
  }
  for (final entry in backup.entries) {
    final key = entry.key;
    if (_protectedWidgetPrefKeys.contains(key) ||
        _demoInternalPrefKeys.contains(key)) {
      continue;
    }
    final spec = entry.value;
    if (spec is! Map) continue;
    final type = spec['t'];
    final val = spec['v'];
    if (type == 'bool' && val is bool) {
      await prefs.setBool(key, val);
    } else if (type == 'int' && val is num) {
      await prefs.setInt(key, val.toInt());
    } else if (type == 'double' && val is num) {
      await prefs.setDouble(key, val.toDouble());
    } else if (type == 'string' && val is String) {
      await prefs.setString(key, val);
    } else if (type == 'list' && val is List) {
      await prefs.setStringList(key, val.map((e) => '$e').toList());
    }
  }
}

Future<void> deleteDemoDatabaseFiles() async {
  final path = await demoDatabasePath();
  if (File(path).existsSync()) {
    try {
      await deleteDatabase(path);
    } catch (_) {}
  }
  for (final suffix in ['', '-wal', '-shm', '-journal']) {
    final file = File('$path$suffix');
    try {
      if (file.existsSync()) file.deleteSync();
    } catch (_) {}
  }
}

/// Snapshots current non-widget SharedPreferences, wipes any leftover demo DB,
/// and marks demo preparation active before seeding `campus_demo.db`.
Future<void> beginDemoActivation({String entrySource = 'dashboard'}) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  if (prefs.getBool(demoActivePrefKey) != true) {
    final backup = _encodePrefSnapshot(prefs);
    await prefs.setString(demoPrefsBackupPrefKey, jsonEncode(backup));
    await prefs.setString(demoEntrySourcePrefKey, entrySource);
    await prefs.setBool(demoActivePrefKey, true);
  }
  await deleteDemoDatabaseFiles();
  _preparingDemo = true;
}

/// Publishes runtime demo state to UI listeners once `campus_demo.db` is ready.
void finishDemoActivation() {
  _preparingDemo = false;
  demoModeNotifier.value = true;
}

Future<void> cancelDemoActivation() async {
  await deactivateDemoState();
}

/// Deletes `campus_demo.db`, restores pre-demo SharedPreferences, switches
/// runtime demo state off, and returns the pre-entry source screen identifier.
Future<String> deactivateDemoState() async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  final entrySource = prefs.getString(demoEntrySourcePrefKey) ?? 'dashboard';
  final backupRaw = prefs.getString(demoPrefsBackupPrefKey);
  _preparingDemo = false;
  demoModeNotifier.value = false;
  await deleteDemoDatabaseFiles();
  await _restorePrefSnapshot(prefs, backupRaw);
  return entrySource;
}

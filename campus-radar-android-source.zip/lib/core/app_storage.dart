import 'package:campus_radar/core/demo_state.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/operation_token.dart';
import 'package:campus_radar/core/startup_diagnostics.dart';

enum AiSetting { aiConsent, aiChatConsent, aiAuto, aiSummary, aiAutoApprove }

class Store {
  final Database db;
  Store(this.db);
  String? aiRequestOwner;
  static Future<Store> open() async => Store(
    await retryDatabaseOpen(
      () async => openDatabase(
        '${await getDatabasesPath()}/$activeDatabaseFileName',
        version: 2,
        singleInstance: false,
        onConfigure: (db) async {
          await db.rawQuery('PRAGMA busy_timeout = 5000');
        },
        onCreate: (db, _) async {
          await db.execute(
            'CREATE TABLE items (id TEXT PRIMARY KEY, payload TEXT NOT NULL)',
          );
          await db.execute(
            'CREATE TABLE meta (id TEXT PRIMARY KEY, value TEXT NOT NULL)',
          );
          await db.execute(
            'CREATE TABLE events (id TEXT PRIMARY KEY, payload TEXT NOT NULL, delivered INTEGER NOT NULL DEFAULT 0)',
          );
          await createHistoryTables(db);
        },
        onUpgrade: (db, oldVersion, newVersion) async {
          if (oldVersion < 2) await createHistoryTables(db);
        },
      ),
    ),
  );
  static Future<void> createHistoryTables(Database db) async {
    await db.execute(
      'CREATE TABLE notices (id TEXT PRIMARY KEY, payload TEXT NOT NULL)',
    );
    await db.execute(
      'CREATE TABLE logs (id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL, detail TEXT NOT NULL)',
    );
  }

  Future<void> log(String kind, String title, String detail) async {
    await db.transaction((txn) async {
      await txn.insert('logs', {
        'at': DateTime.now().toUtc().toIso8601String(),
        'kind': kind,
        'title': title,
        'detail': detail,
      });
      await txn.rawDelete(
        'DELETE FROM logs WHERE id NOT IN (SELECT id FROM logs ORDER BY id DESC LIMIT 2000)',
      );
    });
  }

  Future<List<Map<String, Object?>>> logs(String kind) => db.query(
    'logs',
    where: kind == 'all'
        ? null
        : kind == 'notification'
        ? 'kind=?'
        : 'kind!=?',
    whereArgs: kind == 'all' ? null : ['notification'],
    orderBy: 'id DESC',
    limit: 2000,
  );
  Future<List<CampusNotice>> notices() async =>
      (await db.query('notices'))
          .map(
            (row) =>
                CampusNotice.fromJson(jsonDecode(row['payload'] as String)),
          )
          .toList()
        ..sort(
          (a, b) => (b.published ?? DateTime.utc(1970)).compareTo(
            a.published ?? DateTime.utc(1970),
          ),
        );
  Future<void> saveNotice(CampusNotice notice) => db.insert('notices', {
    'id': notice.id,
    'payload': jsonEncode(notice.toJson()),
  }, conflictAlgorithm: ConflictAlgorithm.replace);
  Future<void> replaceNotices(List<CampusNotice> list) async {
    await db.transaction((txn) async {
      final old = {
        for (final row in await txn.query('notices'))
          row['id'] as String: CampusNotice.fromJson(
            jsonDecode(row['payload'] as String),
          ),
      };
      final initialized = (await txn.query(
        'meta',
        where: 'id=?',
        whereArgs: ['noticesInitialized'],
      )).isNotEmpty;
      await txn.delete('notices');
      for (final notice in list) {
        if (initialized && !old.containsKey(notice.id)) {
          await txn.insert('events', {
            'id': 'notice:${notice.id}',
            'payload': jsonEncode({
              'kind': 'notice',
              'notice': notice.toJson(),
            }),
            'delivered': 0,
          }, conflictAlgorithm: ConflictAlgorithm.ignore);
        }
        final cached = CampusNotice(
          id: notice.id,
          title: notice.title,
          course: notice.course,
          context: notice.context,
          published: notice.published,
          read: notice.read,
          body: old[notice.id]?.body ?? '',
          bodyHtml: old[notice.id]?.bodyHtml ?? '',
          media: old[notice.id]?.media ?? const [],
          // A list refresh is not proof that the cached body is current, but an
          // unchanged row keeps it: resetting it made every collection re-read
          // 12 bodies (~4 s on device) despite the 6-hour body refresh window.
          bodyFetched:
              old[notice.id] != null &&
              old[notice.id]!.bodyFetched &&
              old[notice.id]!.title == notice.title &&
              old[notice.id]!.published == notice.published,
        );
        await txn.insert('notices', {
          'id': notice.id,
          'payload': jsonEncode(cached.toJson()),
        });
      }
      await txn.insert('meta', {
        'id': 'noticesInitialized',
        'value': 'yes',
      }, conflictAlgorithm: ConflictAlgorithm.replace);
    });
  }

  Future<String?> meta(String key) async {
    final r = await db.query('meta', where: 'id=?', whereArgs: [key]);
    return r.isEmpty ? null : r.first['value'] as String;
  }

  Future<void> setAiSetting(AiSetting setting, String value) =>
      setMeta(setting.name, value);

  /// [undo] reverts a just-made hide: it is not a deliberate restore, so the
  /// item stays subject to automatic hiding of past deadlines.
  Future<void> setTaskExcluded(
    String key,
    bool excluded, {
    bool undo = false,
  }) async {
    await setMeta(MetaKey.excluded(key), excluded ? 'yes' : 'no');
    if (!excluded && !undo) {
      final item = (await items()).where((i) => i.key == key).firstOrNull;
      await setMeta(
        MetaKey.overdueRestored(key),
        item?.due?.toIso8601String() ?? '',
      );
    }
  }

  Future<void> setMeta(String k, String v) async {
    if (const {
          'aiConsent',
          'aiChatConsent',
          'aiAuto',
          'aiSummary',
          'aiAutoApprove',
        }.contains(k) &&
        await meta(k) != v) {
      await db.insert('meta', {
        'id': 'sessionEpoch',
        'value': freshToken(),
      }, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await db.insert('meta', {
      'id': k,
      'value': v,
    }, conflictAlgorithm: ConflictAlgorithm.replace);
    if (k.startsWith('excluded:') || k.startsWith('notTask:')) {
      await setMeta(
        MetaKey.aiSummaryRevision,
        '${DateTime.now().microsecondsSinceEpoch}',
      );
      if (!isDemoActive) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.remove(PrefKey.aiSummaryText);
      }
    }
  }

  Future<List<CampusItem>> items() async =>
      (await db.query('items'))
          .map((r) => CampusItem.fromJson(jsonDecode(r['payload'] as String)))
          .toList()
        ..sort(
          (a, b) => (a.due ?? DateTime.utc(2100)).compareTo(
            b.due ?? DateTime.utc(2100),
          ),
        );
  Future<Set<String>> notTasks() async => (await db.query(
    'meta',
    where: 'id LIKE ? AND value=?',
    whereArgs: ['notTask:%', 'yes'],
  )).map((r) => (r['id'] as String).substring(8)).toSet();

  /// Bookkeeping keys for past days and past deadlines are only needed until
  /// the moment passes; without pruning they grow for the whole semester.
  Future<void> pruneStaleMeta(DateTime now) async {
    final cutoff = now.toUtc().subtract(const Duration(days: 7));
    final day = cutoff
        .add(const Duration(hours: 9))
        .toIso8601String()
        .substring(0, 10);
    final rows = await db.query(
      'meta',
      columns: ['id'],
      where: 'id LIKE ? OR id LIKE ?',
      whereArgs: ['desktopClassSent:%', 'due:%'],
    );
    for (final r in rows) {
      final id = r['id'] as String;
      final stale = id.startsWith('desktopClassSent:')
          ? id.split(':')[1].compareTo(day) < 0
          : (DateTime.tryParse(
                  RegExp(r'\d{4}-\d{2}-\d{2}T\S+$').firstMatch(id)?[0] ?? '',
                )?.isBefore(cutoff) ??
                false);
      if (stale) await db.delete('meta', where: 'id=?', whereArgs: [id]);
    }
  }

  Future<Set<String>> excluded({bool includeNotTasks = true}) async {
    final values = {
      for (final r in await db.query('meta'))
        r['id'] as String: r['value'] as String,
    };
    final result = values.entries
        .where((e) => e.key.startsWith('excluded:') && e.value == 'yes')
        .map((e) => e.key.substring('excluded:'.length))
        .toSet();
    if (includeNotTasks) result.addAll(await notTasks());
    final policy = values['overduePolicy'] ?? 'confirm';
    if (policy == 'immediate' || policy == 'day') {
      final now = DateTime.now().toUtc();
      for (final item in await items()) {
        if (item.due == null || item.done || !item.availableAt(now)) continue;
        if (values[MetaKey.overdueRestored(item.key)] ==
            item.due!.toIso8601String()) {
          continue;
        }
        if (!now.isBefore(
          item.due!.add(Duration(hours: policy == 'day' ? 24 : 0)),
        )) {
          result.add(item.key);
        }
      }
    }
    return result;
  }

  String? _leaseOwner;
  Future<void> releaseLease() async {
    final owner = _leaseOwner;
    if (owner == null) return;
    await db.transaction((txn) async {
      final rows = await txn.query(
        'meta',
        where: 'id=?',
        whereArgs: ['leaseOwner'],
      );
      if (rows.isNotEmpty && rows.single['value'] == owner) {
        await txn.delete(
          'meta',
          where: 'id IN (?,?)',
          whereArgs: ['lease', 'leaseOwner'],
        );
      }
    });
    _leaseOwner = null;
  }

  Future<bool> acquire() => db.transaction((txn) async {
    final row = await txn.query('meta', where: 'id=?', whereArgs: ['lease']);
    final lease = row.isEmpty
        ? 0
        : int.tryParse(row.first['value'] as String) ?? 0;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (lease > now) return false;
    await txn.insert('meta', {
      'id': 'lease',
      'value': '${now + 600000}',
    }, conflictAlgorithm: ConflictAlgorithm.replace);
    final token = freshToken();
    await txn.insert('meta', {
      'id': 'leaseOwner',
      'value': token,
    }, conflictAlgorithm: ConflictAlgorithm.replace);
    _leaseOwner = token;
    return true;
  });
  Future<void> replace(List<CampusItem> incoming) async {
    await db.transaction((txn) async {
      final now = DateTime.now().toUtc();
      final old = {
        for (final r in await txn.query('items'))
          r['id'] as String: CampusItem.fromJson(
            jsonDecode(r['payload'] as String),
          ),
      };
      final initialized = (await txn.query(
        'meta',
        where: 'id=?',
        whereArgs: ['initialized'],
      )).isNotEmpty;
      final row = await txn.query(
        'meta',
        where: 'id=?',
        whereArgs: ['visibleIds'],
      );
      final previousVisible = row.isEmpty
          ? old.values
                .where((i) => i.availableAt(now))
                .map((i) => i.key)
                .toSet()
          : (jsonDecode(row.first['value'] as String) as List)
                .cast<String>()
                .toSet();
      final resourcesInitialized = (await txn.query(
        'meta',
        where: 'id=?',
        whereArgs: ['resourcesInitialized'],
      )).isNotEmpty;
      for (final item in incoming) {
        if (!item.availableAt(now)) continue;
        if (initialized &&
            (item.type == 'LR' || item.type == 'LS' && resourcesInitialized) &&
            !previousVisible.contains(item.key)) {
          await txn.insert('events', {
            'id': 'new:${item.key}',
            'payload': jsonEncode(item.toJson()),
            'delivered': 0,
          }, conflictAlgorithm: ConflictAlgorithm.replace);
          await txn.insert('meta', {
            'id': MetaKey.discovered(item.key),
            'value': now.toIso8601String(),
          }, conflictAlgorithm: ConflictAlgorithm.replace);
        }
        final before = old[item.key];
        if (initialized &&
            before != null &&
            previousVisible.contains(item.key)) {
          final changes = itemChanges(before, item);
          if (changes.isNotEmpty) {
            final detail = changes.join('\n');
            await txn.insert('events', {
              'id': 'change:${item.key}:${now.microsecondsSinceEpoch}',
              'payload': jsonEncode({
                'item': item.toJson(),
                'kind': 'change',
                'detail': detail,
                'at': now.toIso8601String(),
              }),
              'delivered': 0,
            });
          }
        }
      }
      await txn.insert('meta', {
        'id': 'visibleIds',
        'value': jsonEncode(
          incoming.where((i) => i.availableAt(now)).map((i) => i.key).toList(),
        ),
      }, conflictAlgorithm: ConflictAlgorithm.replace);
      await txn.delete('items');
      for (final item in incoming) {
        await txn.insert('items', {
          'id': item.key,
          'payload': jsonEncode(item.toJson()),
        });
      }
      for (final entry in {
        'initialized': 'yes',
        'resourcesInitialized': 'yes',
        'lastSuccess': DateTime.now().toUtc().toIso8601String(),
        'lastError': '',
      }.entries) {
        await txn.insert('meta', {
          'id': entry.key,
          'value': entry.value,
        }, conflictAlgorithm: ConflictAlgorithm.replace);
      }
    });
  }
}

import 'package:flutter/material.dart';
import 'navigation_contract.dart';
import 'task_detail_page.dart';
import 'notice_pages.dart';
import 'course_page.dart';
import 'timetable_page.dart';
import 'daily_summary_page.dart';
import 'ai_inbox_page.dart';
import 'ai_settings_page.dart';

/// Only the application composition root imports concrete destination builders.
Route<dynamic>? buildAppRoute(RouteSettings settings) {
  final target = settings.arguments;
  if (target is! AppDestination || settings.name != target.path) return null;
  final Widget page = switch (target) {
    TaskDestination(:final item, :final excluded) => DetailPage(
      item: item,
      excluded: excluded,
    ),
    NoticeDestination(:final notice) => NoticeDetailPage(notice: notice),
    CourseDestination(:final course) => CoursePage(course: course),
    TimetableDestination() => const TimetablePage(),
    SummaryDestination(:final settings) => DailySummaryPage(settings: settings),
    AiInboxDestination(:final embedded, :final home, :final records) =>
      AiInboxPage(embedded: embedded, home: home, records: records),
    AiSettingsDestination() => const AiSettingsPage(),
  };
  return MaterialPageRoute<dynamic>(settings: settings, builder: (_) => page);
}

import 'dart:io';
import 'calendar_settings_page.dart';
import 'schedule_calendar.dart';
import 'notification_settings_page.dart';
import 'background_status_page.dart';
import 'widget_settings_page.dart';
import 'ios_widget_settings.dart';
import 'radar_theme.dart';
import 'task_cleanup_settings.dart';
import 'history_page.dart';
import 'package:flutter/material.dart';
import 'navigation_contract.dart';
import 'task_detail_page.dart';
import 'notice_pages.dart';
import 'course_page.dart';
import 'timetable_page.dart';
import 'daily_summary_page.dart';
import 'ai_inbox_page.dart';
import 'ai_settings_page.dart';
import 'update_page.dart';

/// Only the application composition root imports concrete destination builders.
Route<dynamic>? buildAppRoute(RouteSettings settings) {
  final target = settings.arguments;
  if (target is! AppDestination || settings.name != target.path) return null;
  final Widget page = switch (target) {
    TaskDestination(:final item, :final excluded) => DetailPage(
      item: item,
      excluded: excluded,
    ),
    NoticeDestination(:final notice) => NoticeDetailPage(notice: notice),
    CourseDestination(:final course) => CoursePage(course: course),
    TimetableDestination() => const TimetablePage(),
    UpdateDestination() => const UpdatePage(),
    SummaryDestination(:final settings) => DailySummaryPage(settings: settings),
    AiInboxDestination(
      :final embedded,
      :final home,
      :final records,
      :final noticeId,
      :final candidateId,
      :final initialFilter,
    ) =>
      AiInboxPage(
        embedded: embedded,
        home: home,
        records: records,
        noticeId: noticeId,
        candidateId: candidateId,
        initialFilter: initialFilter,
      ),
    AiSettingsDestination() => const AiSettingsPage(),
    HelpToolDestination(:final tool) => switch (tool) {
      HelpTool.ai => const AiSettingsPage(),
      HelpTool.calendarSettings => const CalendarSettingsPage(),
      HelpTool.review => const AiInboxPage(
        showTools: false,
        compactReview: true,
      ),
      HelpTool.calendar => Scaffold(
        appBar: AppBar(title: const Text('캘린더')),
        body: const ScheduleCalendar(),
      ),
      HelpTool.notices => const NoticesPage(),
      HelpTool.timetable => const TimetablePage(),
      HelpTool.notifications => const NotificationSettingsPage(),
      HelpTool.background => const BackgroundStatusPage(),
      HelpTool.widgets =>
        Platform.isIOS
            ? Scaffold(
                appBar: AppBar(title: const Text('위젯 설정')),
                body: const SingleChildScrollView(
                  padding: EdgeInsets.all(20),
                  child: IosWidgetSettings(),
                ),
              )
            : const WidgetSettingsPage(),
      HelpTool.appearance => const AppearancePage(),
      HelpTool.tasks => const TaskCleanupSettings(),
      HelpTool.history => const HistoryPage(notificationsOnly: false),
    },
  };
  return MaterialPageRoute<dynamic>(settings: settings, builder: (_) => page);
}

import 'navigation_contract.dart';
import 'ui_formatters.dart';
import 'calendar_draft_page.dart';
import 'ai_protocol.dart';
import 'notice_ai_service.dart';
import 'course_labels.dart';
import 'campus_models.dart';
import 'ai_recovery_page.dart';
import 'package:flutter/material.dart';

class NoticeAnalysisPage extends StatefulWidget {
  final CampusNotice notice;
  const NoticeAnalysisPage({super.key, required this.notice});
  @override
  State<NoticeAnalysisPage> createState() => _NoticeAnalysisState();
}

class _NoticeAnalysisState extends State<NoticeAnalysisPage> {
  List<ScheduleCandidate>? events;
  bool busy = false;
  String? error;
  AiFailure? failure;
  Future<void> analyze() async {
    setState(() {
      busy = true;
      error = null;
      failure = null;
      events = null;
    });
    try {
      final result = await NoticeAi.analyze(widget.notice);
      if (mounted) setState(() => events = result);
    } catch (e) {
      if (mounted) {
        setState(() {
          error = userError(e);
          failure = e is AiFailure ? e : null;
        });
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('AI 일정 후보')),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Text(
          widget.notice.title,
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        const Text(
          '분석하면 이 공지의 텍스트를 Gemini에 보냅니다. 결과는 후보이며 원문을 확인해야 합니다. 같은 본문은 저장한 결과를 사용합니다.',
        ),
        FilledButton(
          onPressed: busy ? null : analyze,
          child: Text(busy ? '분석 중…' : '공지 분석·저장 결과 보기'),
        ),
        TextButton(
          onPressed: busy
              ? null
              : () => navigateTo(context, AiSettingsDestination()),
          child: const Text('개인 키·외부 전송 설정'),
        ),
        if (busy) const LinearProgressIndicator(),
        if (error != null) ...[
          Text(error!),
          FilledButton.tonal(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AiRecoveryPage(
                  notice: widget.notice,
                  job: {
                    'status': 'failed',
                    'error': error,
                    'errorCode': failure?.code,
                    'errorDetail': failure?.detail,
                  },
                ),
              ),
            ),
            child: const Text('실패 원인·해결 방법'),
          ),
        ],
        if (events?.isEmpty == true)
          const Text('추출된 일정이 없습니다. 이미지·첨부와 원문을 확인하세요.'),
        ...?events?.map(
          (c) => Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    c.title,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text(
                    '${c.action == "cancel"
                        ? "취소"
                        : c.action == "change"
                        ? "변경 — 기존 일정 확인 필요"
                        : "새 일정"} · ${c.date.isEmpty ? "날짜 확인 필요" : c.date} ${c.time.isEmpty ? "시각 미지정" : c.time}',
                  ),
                  const SizedBox(height: 8),
                  SelectableText('근거: ${c.evidence}'),
                  if (c.conditionLabel.isNotEmpty)
                    Chip(label: Text(c.conditionLabel)),
                  if (c.periodLabel.isNotEmpty) Text(c.periodLabel),
                  if (c.inferenceLabel.isNotEmpty) Text(c.inferenceLabel),
                  if (c.uncertainty.isNotEmpty) Text('확인할 점: ${c.uncertainty}'),
                  if (c.action != 'add')
                    const Text(
                      '변경·취소는 이전에 저장한 일정과 연결을 확인한 후 캘린더에서 직접 반영하세요. 새 일정으로 자동 추가하지 않습니다.',
                    ),
                  if (c.action == 'add')
                    TextButton(
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => CalendarDraftPage(
                            courseName: widget.notice.course,
                            itemKey: candidateKey(widget.notice, c),
                            title:
                                '[${courseLabel(widget.notice.course)}] ${c.title}',
                            description:
                                'AI 후보를 사용자가 확인한 일정\n${c.description}\n공지: ${widget.notice.title}\nhttps://dcs-learning.cnu.ac.kr/home',
                            start: c.date.isEmpty
                                ? null
                                : c.time.isEmpty
                                ? strictDate(c.date)
                                : DateTime.parse(
                                    '${c.date}T${c.time}:00+09:00',
                                  ),
                            allDay: c.time.isEmpty,
                            deadline: c.deadline,
                            end: c.endInstant,
                          ),
                        ),
                      ),
                      child: const Text('날짜 확인·캘린더 추가'),
                    ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 24),
        const Text('공지 원문', style: TextStyle(fontWeight: FontWeight.bold)),
        SelectableText(widget.notice.body),
      ],
    ),
  );
}

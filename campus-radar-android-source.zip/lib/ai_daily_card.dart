import 'navigation_contract.dart';
import 'app_storage.dart';
import 'school_time.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'ai_automation.dart';

class DailySummarySection extends StatelessWidget {
  final Widget? child;
  const DailySummarySection({super.key, this.child});

  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: const Icon(Icons.auto_awesome_outlined),
      title: const Text('하루 요약 보기'),
      subtitle: const Text('오늘 현황과 AI 요약을 자세히 확인해요'),
      trailing: const Icon(Icons.chevron_right),
      onTap: () => child == null
          ? navigateTo(context, const SummaryDestination())
          : Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => Scaffold(
                  appBar: AppBar(title: const Text('하루 요약')),
                  body: child,
                ),
              ),
            ),
    ),
  );
}

class AiDailyCard extends StatefulWidget {
  const AiDailyCard({super.key});
  @override
  State<AiDailyCard> createState() => _AiDailyCardState();
}

class _AiDailyCardState extends State<AiDailyCard> {
  String? text;
  bool enabled = false, busy = false;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    Store? s;
    try {
      s = await Store.open();
      final on = await s.meta('aiSummary') == 'yes';
      final p = await SharedPreferences.getInstance();
      await p.reload();
      final last = await s.meta('lastSuccess');
      final now = DateTime.now().toUtc();
      final hour = p.getInt('aiSummaryHour') ?? -99;
      final valid =
          on &&
          p.getString('aiSummaryLast') == last &&
          p.getString('aiSummaryDay') == schoolDay(now) &&
          (p.getInt('aiSummaryExpires') ?? 0) > now.millisecondsSinceEpoch &&
          now.millisecondsSinceEpoch ~/ 3600000 - hour >= 0 &&
          now.millisecondsSinceEpoch ~/ 3600000 - hour <= 1;
      if (mounted) {
        setState(() {
          enabled = on;
          text = valid ? p.getString('aiSummaryText') : null;
        });
      }
    } catch (_) {
      if (mounted) setState(() => text = null);
    } finally {
      await s?.db.close();
    }
  }

  Future<void> generate() async {
    setState(() => busy = true);
    Store? s;
    try {
      s = await Store.open();
      await s.setMeta('aiSummaryFailHash', '');
      await prepareAiSummary(s);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('요약을 준비하지 못했습니다. 잠시 후 다시 확인해 주세요.')),
        );
      }
    } finally {
      await s?.db.close();
      if (mounted) setState(() => busy = false);
    }
    await load();
  }

  @override
  Widget build(BuildContext context) => Card(
    child: ExpansionTile(
      key: const PageStorageKey<String>('ai-daily-summary-expansion'),
      leading: const Icon(Icons.auto_awesome),
      title: const Text('오늘 요약'),
      subtitle: Text(
        enabled
            ? (text == null
                  ? '기본 현황을 확인하세요 · AI 요약 준비 대기'
                  : '수집된 목록에서 우선 확인할 일')
            : '선택 기능 · AI 설정에서 켤 수 있어요',
      ),
      childrenPadding: const EdgeInsets.all(16),
      expandedCrossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (text != null) SelectionArea(child: Text(text!)),
        if (enabled)
          TextButton(
            onPressed: busy ? null : generate,
            child: Text(busy ? '준비 중…' : '지금 요약 준비'),
          ),
        TextButton(
          onPressed: () => navigateTo(context, AiSettingsDestination()),
          child: const Text('AI 설정'),
        ),
      ],
    ),
  );
}

import 'dart:convert';
import 'dart:io';

import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/demo_state.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Pure data builders for Android lock-free widget snapshots.
class WidgetSnapshotPayload {
  static Map<String, dynamic> buildSnapshot({
    required List<CampusItem> items,
    required Set<String> excludedKeys,
    required String? lastSuccess,
    required bool connected,
    required Map<String, String> metaEntries,
    DateTime? now,
  }) {
    final current = now ?? DateTime.now().toUtc();
    final activeItems = items
        .where((i) => !excludedKeys.contains(i.key) && i.availableAt(current))
        .map((i) => i.toJson())
        .toList();

    final discovered = <String, String>{};
    for (final entry in metaEntries.entries) {
      if (entry.key.startsWith('discovered:')) {
        discovered[entry.key] = entry.value;
      }
    }

    return {
      'items': activeItems,
      'last': lastSuccess ?? '',
      'discovered': discovered,
      'connected': connected,
    };
  }
}

/// Publishes a JSON snapshot of items, metadata, and timetable into SharedPreferences
/// so Android AppWidgets and background receivers can read data instantly without
/// touching SQLite or contending for DB locks (eliminating widget ANRs).
Future<void> publishAndroidWidgetSnapshot(
  Store store, {
  SharedPreferences? prefs,
  DateTime? now,
}) async {
  if (isDemoActive) return;
  if (!Platform.isAndroid && prefs == null) return;
  try {
    final p = prefs ?? await SharedPreferences.getInstance();
    final items = await store.items();
    final excluded = await store.excluded();
    final lastSuccess = await store.meta(MetaKey.lastSuccess);
    final initialized = await store.meta('initialized');
    final isConnected = initialized == 'yes';

    final metaRows = await store.db.query('meta');
    final metaEntries = {
      for (final r in metaRows)
        r['id'] as String: r['value'] as String,
    };

    final snapshot = WidgetSnapshotPayload.buildSnapshot(
      items: items,
      excludedKeys: excluded,
      lastSuccess: lastSuccess,
      connected: isConnected,
      metaEntries: metaEntries,
      now: now,
    );

    await p.setString(PrefKey.widgetSnapshotJson, jsonEncode(snapshot));

    final timetable = metaEntries[MetaKey.timetableEntries];
    if (timetable != null && timetable.isNotEmpty) {
      await p.setString(PrefKey.widgetTimetableJson, timetable);
    }
  } catch (_) {
    // Best effort: Android widget falls back to SQLite campus.db if snapshot is missing
  }
}

/// Cleans up widget snapshot cache on account disconnect or reset.
Future<void> clearAndroidWidgetSnapshot({SharedPreferences? prefs}) async {
  if (isDemoActive) return;
  if (!Platform.isAndroid && prefs == null) return;
  try {
    final p = prefs ?? await SharedPreferences.getInstance();
    await p.remove(PrefKey.widgetSnapshotJson);
    await p.remove(PrefKey.widgetTimetableJson);
  } catch (_) {}
}

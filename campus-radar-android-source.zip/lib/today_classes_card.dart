import 'navigation_contract.dart';
import 'native_contract.dart';
import 'app_storage.dart';
import 'native_bridge.dart';
import 'course_labels.dart';
import 'package:flutter/material.dart';
import 'timetable_model.dart';

class TodayClassesCard extends StatefulWidget {
  const TodayClassesCard({super.key});
  @override
  State<TodayClassesCard> createState() => _TodayClassesState();
}

class _TodayClassesState extends State<TodayClassesCard> {
  List<ClassSlot> rows = [];
  bool loaded = false;
  bool expired = false;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    Store? store;
    try {
      store = await Store.open();
      final entries = decodeSlots(await store.meta('timetableEntries'));
      final settings = await bridge.invokeNativeMap<String, dynamic>(
        NativeMethod.timetableSettings,
      );
      final now = DateTime.now().toUtc().add(const Duration(hours: 9));
      final until = DateTime.tryParse(settings?['until'] ?? '');
      final past =
          until != null &&
          DateTime(now.year, now.month, now.day).isAfter(until);
      if (mounted) {
        setState(() {
          expired = past;
          rows = entries.where((e) => e.weekday == now.weekday).toList()
            ..sort((a, b) => a.start.compareTo(b.start));
          loaded = true;
        });
      }
    } catch (_) {
      if (mounted) setState(() => loaded = true);
    } finally {
      await store?.db.close();
    }
  }

  Future<void> open() async {
    await navigateTo(context, TimetableDestination());
    await load();
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now().toUtc().add(const Duration(hours: 9));
    final minute = now.hour * 60 + now.minute;
    final upcoming = rows.where((e) => e.end > minute).toList();
    return Card(
      margin: const EdgeInsets.only(top: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.schedule, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '오늘 수업',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                TextButton(onPressed: open, child: const Text('시간표')),
              ],
            ),
            if (!loaded)
              const LinearProgressIndicator()
            else if (expired)
              const Text('시간표 종료일이 지났어요. 새 학기 시간표를 확인해 주세요.')
            else if (rows.isEmpty)
              const Text('저장된 시간표에 오늘 수업이 없어요.')
            else if (upcoming.isEmpty)
              const Text('저장된 오늘 수업을 모두 마쳤어요.')
            else
              ...upcoming
                  .take(2)
                  .map(
                    (e) => ListTile(
                      contentPadding: EdgeInsets.zero,
                      dense: true,
                      title: Text(courseLabel(e.course)),
                      subtitle: Text(
                        '${slotTime(e.start)}–${slotTime(e.end)}${e.room.isEmpty ? '' : ' · ${e.room}'}',
                      ),
                      trailing: Text(e.start <= minute ? '수업 중' : '다음 수업'),
                      onTap: open,
                    ),
                  ),
            const SizedBox(height: 4),
            Text(
              '저장한 강의계획서 기준 · 휴강·보강은 원문 확인',
              style: Theme.of(context).textTheme.labelSmall,
            ),
          ],
        ),
      ),
    );
  }
}

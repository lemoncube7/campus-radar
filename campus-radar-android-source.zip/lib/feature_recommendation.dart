import 'package:flutter/material.dart';
import 'feature_discovery.dart';
import 'timetable_page.dart';
import 'ai_chat_page.dart';
import 'ai_settings_page.dart';
import 'calendar_settings_page.dart';
import 'radar_theme.dart';
import 'task_cleanup_settings.dart';
import 'history_page.dart';

class FeatureRecommendation extends StatefulWidget {
  const FeatureRecommendation({super.key});
  @override
  State<FeatureRecommendation> createState() => _FeatureRecommendationState();
}

class _FeatureRecommendationState extends State<FeatureRecommendation> {
  DiscoverFeature? tip;
  bool loading = false;
  bool reloadPending = false;
  @override
  void initState() {
    super.initState();
    FeatureDiscovery.changed.addListener(refresh);
    load();
  }

  @override
  void dispose() {
    FeatureDiscovery.changed.removeListener(refresh);
    super.dispose();
  }

  void refresh() {
    if (mounted) setState(() {});
    load();
  }

  Future<void> load({bool another = false}) async {
    if (loading) {
      reloadPending = true;
      return;
    }
    loading = true;
    try {
      final value = await FeatureDiscovery.choose(another: another);
      if (mounted) setState(() => tip = value);
    } catch (_) {
    } finally {
      loading = false;
      if (reloadPending && mounted) {
        reloadPending = false;
        load();
      }
    }
  }

  (String, String, IconData, Widget) describe(DiscoverFeature f) => switch (f) {
    DiscoverFeature.timetable => (
      '시간표 만들기',
      '강의계획서에서 시간표를 만들고 수업 전 알림을 받아 보세요.',
      Icons.calendar_view_week,
      const TimetablePage(),
    ),
    DiscoverFeature.chat => (
      'AI에게 물어보기',
      '동의한 수집 정보를 바탕으로 과제와 수업에 관해 질문할 수 있어요.',
      Icons.chat_bubble_outline,
      const AiChatPage(),
    ),
    DiscoverFeature.ai => (
      '공지에서 일정 찾기',
      '개인 Gemini 키를 연결하면 공지 속 일정을 정리할 수 있어요.',
      Icons.auto_awesome,
      const AiSettingsPage(),
    ),
    DiscoverFeature.calendar => (
      '캘린더로 보내기',
      '과제 마감과 확인한 AI 일정을 내 캘린더에 함께 표시해 보세요.',
      Icons.event_available,
      const CalendarSettingsPage(),
    ),
    DiscoverFeature.theme => (
      '내 색상으로 바꾸기',
      '8가지 색상과 라이트·다크로 앱 분위기를 바꿀 수 있어요.',
      Icons.palette_outlined,
      const AppearancePage(),
    ),
    DiscoverFeature.tasks => (
      '할 일 표시 정리하기',
      '제출 대기 표시와 기한 지난 항목, 출석 미반영 콘텐츠를 정리해 보세요.',
      Icons.playlist_remove,
      const TaskCleanupSettings(),
    ),
    DiscoverFeature.history => (
      '수집·알림 기록 보기',
      '마지막 수집 결과와 알림 처리, 실패 이유를 확인할 수 있어요.',
      Icons.history,
      const HistoryPage(notificationsOnly: false),
    ),
  };
  @override
  Widget build(BuildContext context) {
    final feature = tip;
    if (feature == null || !FeatureDiscovery.enabled.value) {
      return const SizedBox.shrink();
    }
    final (title, body, icon, page) = describe(feature);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('이 기능도 써보세요', style: Theme.of(context).textTheme.labelLarge),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(icon),
              title: Text(title),
              subtitle: Text(body),
              trailing: const Icon(Icons.chevron_right),
              onTap: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute<void>(builder: (_) => page),
                );
                await load();
              },
            ),
            Wrap(
              spacing: 12,
              children: [
                TextButton(
                  onPressed: () => load(another: true),
                  child: const Text('다른 기능 보기'),
                ),
                TextButton(
                  onPressed: () async {
                    try {
                      await FeatureDiscovery.setEnabled(false);
                      await load();
                    } catch (_) {}
                  },
                  child: const Text('추천 끄기'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class DiscoverySettings extends StatefulWidget {
  const DiscoverySettings({super.key});
  @override
  State<DiscoverySettings> createState() => _DiscoverySettingsState();
}

class _DiscoverySettingsState extends State<DiscoverySettings> {
  @override
  void initState() {
    super.initState();
    FeatureDiscovery.choose().catchError((_) => null);
  }

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<bool>(
    valueListenable: FeatureDiscovery.enabled,
    builder: (context, value, _) => SwitchListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 8),
      title: const Text('오늘 화면의 기능 추천'),
      subtitle: const Text('방문하지 않은 기능을 기기 안의 기록으로 추천합니다.'),
      value: value,
      onChanged: (v) async {
        try {
          await FeatureDiscovery.setEnabled(v);
        } catch (_) {
          if (context.mounted) {
            ScaffoldMessenger.of(
              context,
            ).showSnackBar(const SnackBar(content: Text('추천 설정을 저장하지 못했어요.')));
          }
        }
      },
    ),
  );
}

import 'ai_recovery.dart';
import 'widget_text_page.dart';
import 'ai_recovery_page.dart';
import 'timetable_page.dart';
import 'ui_refresh.dart';
import 'desktop.dart';
import 'radar_theme.dart';
import 'ai_confirm.dart';
import 'updates.dart';
import 'expansion_pages.dart';
import 'dart:io';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'ai.dart';
import 'ai_automation.dart';
import 'ai_pages.dart';
import 'campus.dart';
import 'services.dart';
import 'main.dart';
import 'features.dart';

class AutomationControls extends StatefulWidget {
  const AutomationControls({super.key});
  @override
  State<AutomationControls> createState() => _AutomationControlsState();
}

class _AutomationControlsState extends State<AutomationControls> {
  bool auto = false, summary = false, busy = true;
  String scope = 'recent', message = '';
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    Store? s;
    try {
      s = await Store.open();
      final a = await s.meta('aiAuto') == 'yes',
          d = await s.meta('aiSummary') == 'yes',
          sc = await s.meta('aiScope') ?? 'recent';
      if (mounted) {
        setState(() {
          auto = a;
          summary = d;
          scope = sc;
          busy = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          busy = false;
          message = "설정을 읽지 못했습니다. 화면을 다시 열어 주세요.";
        });
      }
    } finally {
      await s?.db.close();
    }
  }

  Future<void> save() async {
    setState(() => busy = true);
    final s = await Store.open();
    try {
      if ((auto || summary) &&
          (await credentials.read(key: 'geminiApiKey') == null ||
              await s.meta('aiConsent') != aiConsentVersion)) {
        throw const AiFailure('먼저 위에서 개인 키와 공지 외부 전송 동의를 저장해 주세요.');
      }
      final oldScope = await s.meta('aiScope');
      if (auto && (await s.meta('aiAuto') != 'yes' || oldScope != scope)) {
        if (scope == 'new') {
          await s.setMeta(
            'aiBaseline',
            jsonEncode((await s.notices()).map((n) => n.id).toList()),
          );
        }
        await s.db.delete('meta', where: 'id LIKE ?', whereArgs: ['aiQueue:%']);
      }
      await s.setMeta('aiScope', scope);
      await s.setMeta('aiAuto', auto ? 'yes' : 'no');
      await s.setMeta('aiSummary', summary ? 'yes' : 'no');
      final p = await SharedPreferences.getInstance();
      await p.setBool('aiSummaryEnabled', summary);
      if (!summary) {
        await p.remove('aiSummaryText');
        await s.setMeta('aiSummaryText', '');
      }
      await enqueueNotices(s);
      await s.log(
        'ai',
        'AI 자동화 설정 저장',
        '공지 자동 분석 ${auto ? "켬" : "끔"} · 요약 ${summary ? "켬" : "끔"} · 범위 $scope',
      );
      if (auto || summary) {
        await scheduleSummaryWarmup(
          p.getInt('aiDailyHour') ?? 18,
          p.getInt('aiDailyMinute') ?? 0,
          p.getBool('aiDailyEnabled') ?? false,
        );
        await scheduleAiWork();
        unawaited(processAiWork());
      }
      if (mounted) {
        setState(
          () => message = '저장했습니다. AI 일정함에서 진행 상황을 확인하세요. 실행 중 요청은 완료 후 중지됩니다.',
        );
      }
    } catch (e) {
      if (mounted) setState(() => message = userError(e));
    } finally {
      await s.db.close();
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Divider(height: 40),
      const Text(
        '자동 분석과 요약',
        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
      ),
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('공지 자동 순차 분석'),
        subtitle: const Text(
          '선택 범위의 공지 본문을 가져와 Google에 전송합니다. 분석 결과는 일정함에 모으며 캘린더에 자동 등록하지 않습니다.',
        ),
        value: auto,
        onChanged: busy ? null : (v) => setState(() => auto = v),
      ),
      DropdownButtonFormField<String>(
        key: ValueKey(scope),
        initialValue: scope,
        decoration: const InputDecoration(labelText: '처음 분석할 공지 범위'),
        items: const [
          DropdownMenuItem(value: 'new', child: Text('설정 이후 신규 공지만')),
          DropdownMenuItem(value: 'recent', child: Text('최근 7일 (권장)')),
          DropdownMenuItem(value: 'all', child: Text('현재 수집된 학기 전체')),
        ],
        onChanged: busy ? null : (v) => setState(() => scope = v ?? 'recent'),
      ),
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('AI 데일리 요약 사용'),
        subtitle: const Text(
          '미완료 과제·콘텐츠의 과목명·제목·마감·상태를 Google에 전송하는 데 동의합니다. LLM이 우선 항목을 고르고 실제 일정 값은 앱이 표시합니다. 실패하면 기본 요약을 사용합니다.',
        ),
        value: summary,
        onChanged: busy ? null : (v) => setState(() => summary = v),
      ),
      if (message.isNotEmpty) Text(message),
      FilledButton.tonal(
        onPressed: busy ? null : save,
        child: const Text('자동화 설정 저장·시작'),
      ),
    ],
  );
}

class AiHubPage extends StatelessWidget {
  const AiHubPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('AI 도우미'),
      actions: [
        IconButton(
          tooltip: 'AI 설정',
          icon: const Icon(Icons.tune),
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AiSettingsPage()),
          ),
        ),
      ],
    ),
    body: const AiInboxPage(embedded: true, home: true),
  );
}

class AiInboxPage extends StatefulWidget {
  final bool embedded, home, records;
  const AiInboxPage({
    super.key,
    this.embedded = false,
    this.home = false,
    this.records = false,
  });
  @override
  State<AiInboxPage> createState() => _AiInboxState();
}

class _AiInboxState extends State<AiInboxPage> with WidgetsBindingObserver {
  Timer? timer;
  bool loading = true, auto = false;
  String filter = 'review', error = '', recentQuestion = '';
  String? blockedCode;
  List<Map<String, dynamic>> candidates = [], jobs = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    load();
    timer = Timer.periodic(const Duration(seconds: 3), (_) {
      if (WidgetsBinding.instance.lifecycleState == AppLifecycleState.resumed) {
        load();
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  bool reading = false;
  Future<void> load() async {
    if (reading) return;
    reading = true;
    Store? s;
    try {
      s = await Store.open();
      final notices = await s.notices();
      final list = <Map<String, dynamic>>[], queue = <Map<String, dynamic>>[];
      final records = await s.db.query(
        'meta',
        where: 'id LIKE ?',
        whereArgs: ['aiCandidate:%'],
      );
      final seen = <String>{};
      for (final r in records) {
        final record = Map<String, dynamic>.from(
          jsonDecode(r['value'] as String),
        );
        final n = CampusNotice.fromJson(
          Map<String, dynamic>.from(record['notice']),
        );
        final c = ScheduleCandidate.parse(
          Map<String, dynamic>.from(record['candidate']),
          '${n.title}\n${n.body}',
        );
        final k = record['key'] as String,
            st = jsonDecode(await s.meta('aiState:$k') ?? '{}') as Map;
        final current = notices.where((x) => x.id == n.id).firstOrNull;
        final stale =
            current == null ||
            noticeFingerprint(current) != noticeFingerprint(n);
        if (stale && st['status'] != 'confirmed') continue;
        seen.add(k);
        list.add({'notice': n, 'candidate': c, 'key': k, 'state': st});
      }
      for (final n in notices) {
        final raw = await s.meta('aiCache:${n.id}:${noticeFingerprint(n)}');
        if (raw != null) {
          for (final e in jsonDecode(raw) as List) {
            final c = ScheduleCandidate.parse(
              Map<String, dynamic>.from(e),
              '${n.title}\n${n.body}',
            );
            final k = candidateKey(n, c);
            final state = jsonDecode(await s.meta('aiState:$k') ?? '{}') as Map;
            if (seen.add(k)) {
              list.add({'notice': n, 'candidate': c, 'key': k, 'state': state});
            }
          }
        }
        final q = await s.meta('aiQueue:${n.id}');
        if (q != null) {
          queue.add({'id': n.id, ...Map<String, dynamic>.from(jsonDecode(q))});
        }
      }
      final enabled = await s.meta('aiAuto') == 'yes';
      final chat = jsonDecode(await s.meta('aiChat:all') ?? '[]') as List;
      final lastQuestion = chat.where((m) => m['role'] == 'user').lastOrNull;
      final blocked = queue
          .where(
            (j) => j['status'] == 'failed' && j['errorCode'] == 'credentials',
          )
          .firstOrNull;
      if (mounted) {
        setState(() {
          candidates = list;
          jobs = queue;
          recentQuestion = lastQuestion?['text'] as String? ?? '';
          blockedCode = blocked?['errorCode'] as String?;
          auto = enabled;
          loading = false;
          error = '';
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          error = '일정함을 읽지 못했습니다. 다시 확인해 주세요.';
          loading = false;
        });
      }
    } finally {
      await s?.db.close();
      reading = false;
    }
  }

  Future<void> state(String key, String value) async {
    final s = await Store.open();
    try {
      final old = jsonDecode(await s.meta('aiState:$key') ?? '{}') as Map;
      await s.setMeta('aiState:$key', jsonEncode({...old, 'status': value}));
    } finally {
      await s.db.close();
    }
    await load();
  }

  final saving = <String>{};
  Future<void> quickConfirm(
    Map<String, dynamic> row, {
    bool calendar = false,
  }) async {
    final key = row['key'] as String;
    if (saving.contains(key)) return;
    if (!calendar && (row['state'] as Map)['status'] != 'confirmed') {
      final store = await Store.open();
      String? choice;
      try {
        choice = await store.meta('aiCalendarDefault');
      } finally {
        await store.db.close();
      }
      if (choice == null && mounted) {
        final selected = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('일정을 어디에 추가할까요?'),
            content: const Text('다음부터 이 선택을 기본으로 사용해요. AI 설정에서 변경할 수 있어요.'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('앱 일정함'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('캘린더에도 추가'),
              ),
            ],
          ),
        );
        if (selected == null) return;
        choice = selected ? 'yes' : 'no';
        final saved = await Store.open();
        try {
          await saved.setMeta('aiCalendarDefault', choice);
        } finally {
          await saved.db.close();
        }
      }
      if (!mounted) return;
      calendar = choice == 'yes';
    }
    final c = row['candidate'] as ScheduleCandidate;
    final n = row['notice'] as CampusNotice;
    if (c.date.isEmpty && (row['state'] as Map)['start'] == null) {
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => CalendarDraftPage(
            courseName: n.course,
            itemKey: key,
            title: '[${courseLabel(n.course)}] ${c.title}',
            description: '공지: ${n.title}\n${c.description}',
            allDay: true,
            closeAfterSave: true,
            saveToCalendar: calendar,
          ),
        ),
      );
      await load();
      return;
    }
    setState(() => saving.add(key));
    Store? store;
    try {
      store = await Store.open();
      final old = await confirmAiCandidate(
        store,
        key,
        n,
        c,
        calendar: calendar,
      );
      await load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              calendar
                  ? (Platform.isWindows ? '일정 파일을 저장했습니다.' : '캘린더에 저장했습니다.')
                  : '일정에 추가했어요.',
            ),
            action: calendar
                ? null
                : SnackBarAction(
                    label: '실행 취소',
                    onPressed: () async {
                      final s = await Store.open();
                      try {
                        await s.setMeta('aiState:$key', jsonEncode(old));
                      } finally {
                        await s.db.close();
                      }
                      await load();
                    },
                  ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(e is AiFailure ? e.message : '일정을 저장하지 못했습니다.'),
          ),
        );
      }
    } finally {
      await store?.db.close();
      if (mounted) setState(() => saving.remove(key));
    }
  }

  Future<void> pause() async {
    final s = await Store.open();
    try {
      if (!auto &&
          (await credentials.read(key: 'geminiApiKey') == null ||
              await s.meta('aiConsent') != aiConsentVersion)) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('AI 설정에서 키와 전송 동의를 먼저 저장하세요.')),
          );
        }
        return;
      }
      await s.setMeta('aiAuto', auto ? 'no' : 'yes');
      await s.log(
        'ai',
        auto ? 'AI 대기열 일시 중지' : 'AI 대기열 재개',
        '진행 중 요청은 완료 후 중지됩니다.',
      );
    } finally {
      await s.db.close();
    }
    if (!auto) {
      await scheduleAiWork();
      unawaited(processAiWork());
    }
    await load();
  }

  Future<void> openRecovery(Map<String, dynamic> job) async {
    final store = await Store.open();
    CampusNotice? notice;
    try {
      notice = (await store.notices())
          .where((n) => n.id == job['id'])
          .firstOrNull;
    } finally {
      await store.db.close();
    }
    if (!mounted) return;
    if (notice == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('원문 공지가 현재 수집 목록에 없어요. 공지를 다시 수집해 주세요.')),
      );
      return;
    }
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AiRecoveryPage(notice: notice!, job: job),
      ),
    );
    await load();
  }

  Future<void> retry(String id) async {
    if (!auto) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('대기열을 재개한 뒤 재시도해 주세요.')));
      return;
    }
    final s = await Store.open();
    try {
      final q = jsonDecode(await s.meta('aiQueue:$id') ?? '{}') as Map;
      await s.setMeta('aiCooldown', '0');
      await s.setMeta(
        'aiQueue:$id',
        jsonEncode({...q, 'status': 'pending', 'attempts': 0, 'retryAt': ''}),
      );
    } finally {
      await s.db.close();
    }
    await scheduleAiWork();
    unawaited(processAiWork());
    await load();
  }

  @override
  Widget build(BuildContext context) {
    final list = candidates.where((r) {
      if (widget.records) return false;
      final status = (r['state'] as Map)['status'] ?? 'review';
      return filter == 'all' || status == filter;
    }).toList();
    return Scaffold(
      appBar: widget.embedded
          ? null
          : AppBar(
              title: Text(widget.records ? 'AI 분석 기록' : 'AI 일정함'),
              actions: [
                IconButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const AiSettingsPage()),
                  ),
                  icon: const Icon(Icons.tune),
                  tooltip: 'AI 설정',
                ),
                IconButton(
                  onPressed: load,
                  icon: const Icon(Icons.refresh),
                  tooltip: '새로고침',
                ),
              ],
            ),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            if (widget.home) ...[
              Text(
                '무엇을 도와줄까?',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 8),
              const Text('수집한 공지에서 일정을 찾고, 과제에 대한 질문을 도와드려요.'),
              const SizedBox(height: 16),
              Text(
                '확인할 일정 ${candidates.where((r) => ((r['state'] as Map)['status'] ?? 'review') == 'review').length}개',
                style: Theme.of(context).textTheme.titleLarge,
              ),
            ],
            if (auto &&
                jobs.any((j) => ['pending', 'running'].contains(j['status'])))
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text(
                  '공지 ${jobs.where((j) => ['pending', 'running'].contains(j['status'])).length}개를 확인하고 있어요 · 연결 오류는 자동 재시도해요',
                ),
              ),
            if (!widget.records && jobs.any((j) => j['status'] == 'failed'))
              Card(
                child: ListTile(
                  leading: const Icon(Icons.info_outline),
                  title: Text(
                    '분석 문제 ${jobs.where((j) => j['status'] == 'failed').length}개',
                  ),
                  subtitle: const Text('실패 원인 확인 · 원문 보기 · 직접 추가 · 자료 추가 재분석'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const AiInboxPage(records: true),
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 12),
            if (!widget.records && !widget.home)
              Wrap(
                spacing: 6,
                children: [
                  for (final f in {
                    'review': '확인 필요',
                    'confirmed': '추가한 일정',
                    'hold': '보류',
                    'excluded': '제외',
                    'all': '전체',
                  }.entries)
                    ChoiceChip(
                      label: Text(f.value),
                      selected: filter == f.key,
                      onSelected: (_) => setState(() => filter = f.key),
                    ),
                ],
              ),
            if (loading) const LinearProgressIndicator(),
            if (error.isNotEmpty) Text(error),
            if (!widget.records && !loading && list.isEmpty)
              const Padding(
                padding: EdgeInsets.all(30),
                child: Text('새로 확인할 일정이 없어요.'),
              ),
            for (final row in widget.home ? list.take(3) : list)
              Builder(
                builder: (context) {
                  final n = row['notice'] as CampusNotice,
                      c = row['candidate'] as ScheduleCandidate;
                  final st = row['state'] as Map;
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            courseLabel(n.course),
                            style: Theme.of(context).textTheme.labelMedium,
                          ),
                          Text(
                            courseEventTitle(
                              st['title'] ?? c.title,
                              n.course,
                              oldLabel: st['courseLabel'] as String?,
                            ),
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          Text(
                            '${st['date'] ?? (c.date.isEmpty ? '날짜 확인 필요' : c.date)} ${st['start'] != null && st['allDay'] != true
                                ? formatDate(DateTime.parse(st['start']))
                                : st['allDay'] == true
                                ? '종일'
                                : c.time} · ${c.action == 'add'
                                ? '새 일정'
                                : c.action == 'change'
                                ? '변경 확인'
                                : '취소 확인'}',
                          ),
                          if (st['calendarSent'] == true)
                            Chip(
                              label: Text(
                                Platform.isWindows ? '일정 파일 저장됨' : '캘린더 전송됨',
                              ),
                            ),
                          if (c.conditionLabel.isNotEmpty)
                            Chip(label: Text(c.conditionLabel)),
                          if (c.periodLabel.isNotEmpty) Text(c.periodLabel),
                          if (c.inferenceLabel.isNotEmpty)
                            Text(c.inferenceLabel),
                          if (c.uncertainty.isNotEmpty) Text(c.uncertainty),
                          ExpansionTile(
                            tilePadding: EdgeInsets.zero,
                            title: const Text('근거·공지 원문'),
                            children: [
                              SelectableText('근거: ${c.evidence}\n\n${n.body}'),
                            ],
                          ),
                          Wrap(
                            spacing: 6,
                            children: [
                              if (c.action == 'add' &&
                                  st['status'] != 'confirmed')
                                FilledButton(
                                  onPressed: saving.contains(row['key'])
                                      ? null
                                      : () => quickConfirm(row),
                                  child: Text(
                                    c.date.isEmpty && st['start'] == null
                                        ? '날짜 확인·추가'
                                        : '일정에 추가',
                                  ),
                                ),
                              if (c.action == 'add' &&
                                  st['status'] == 'confirmed')
                                OutlinedButton(
                                  onPressed: saving.contains(row['key'])
                                      ? null
                                      : () => quickConfirm(row, calendar: true),
                                  child: Text(
                                    st['calendarSent'] == true
                                        ? '캘린더 갱신'
                                        : (Platform.isWindows
                                              ? '일정 파일 저장'
                                              : '캘린더 저장'),
                                  ),
                                ),
                              if (c.action == 'add')
                                TextButton(
                                  onPressed: () async {
                                    await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => CalendarDraftPage(
                                          courseName: n.course,
                                          itemKey: row['key'] as String,
                                          closeAfterSave: true,
                                          title: courseEventTitle(
                                            st['title'] ??
                                                '[${n.course}] ${c.title}',
                                            n.course,
                                            oldLabel:
                                                st['courseLabel'] as String?,
                                          ),
                                          description:
                                              '공지: ${n.title}\n${c.description}\nhttps://dcs-learning.cnu.ac.kr/home',
                                          start:
                                              DateTime.tryParse(
                                                st['start'] ?? '',
                                              ) ??
                                              (c.date.isEmpty
                                                  ? null
                                                  : c.time.isEmpty
                                                  ? strictDate(c.date)
                                                  : DateTime.parse(
                                                      '${c.date}T${c.time}:00+09:00',
                                                    )),
                                          deadline:
                                              st['deadline'] as bool? ??
                                              c.deadline,
                                          end: st.containsKey('end')
                                              ? DateTime.tryParse(
                                                  st['end'] ?? '',
                                                )
                                              : c.endInstant,
                                          allDay:
                                              st['allDay'] as bool? ??
                                              c.time.isEmpty,
                                        ),
                                      ),
                                    );
                                    await load();
                                  },
                                  child: const Text('수정'),
                                ),
                              if (c.action != 'add')
                                const Text('기존 캘린더 일정을 직접 확인해 변경·취소를 반영하세요.'),
                              PopupMenuButton<String>(
                                tooltip: '일정 더보기',
                                onSelected: (v) =>
                                    state(row['key'] as String, v),
                                itemBuilder: (_) => const [
                                  PopupMenuItem(
                                    value: 'hold',
                                    child: Text('보류'),
                                  ),
                                  PopupMenuItem(
                                    value: 'excluded',
                                    child: Text('제외'),
                                  ),
                                ],
                              ),
                              if (filter != 'review')
                                TextButton(
                                  onPressed: () =>
                                      state(row['key'] as String, 'review'),
                                  child: const Text('다시 검토'),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            if (widget.home) ...[
              TextButton(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AiInboxPage()),
                ),
                child: const Text('일정함 전체 보기'),
              ),
              const SizedBox(height: 16),
              const Divider(),
              FilledButton.icon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AiChatPage()),
                ),
                icon: const Icon(Icons.chat_bubble_outline),
                label: const Text('공지나 과제에 대해 질문하기'),
              ),
              Wrap(
                spacing: 8,
                children: [
                  for (final q in ['이번 주 해야 할 일', '최근 공지 요약', '놓치기 쉬운 일정'])
                    ActionChip(
                      label: Text(q),
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AiChatPage(initialQuestion: q),
                        ),
                      ),
                    ),
                ],
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('최근 대화'),
                subtitle: Text(
                  recentQuestion.isEmpty ? '질문을 시작해 보세요' : recentQuestion,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AiChatPage()),
                ),
              ),
            ],
            const SizedBox(height: 24),
            if (widget.records)
              TextButton(
                onPressed: pause,
                child: Text(auto ? '자동 분석 일시 중지' : '자동 분석 재개'),
              ),
            if (widget.records) ...[
              const Text(
                '확인 필요한 항목',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              if (!jobs.any((j) => j['status'] == 'failed'))
                const Text('해결할 분석 문제가 없어요.'),
              for (final j in jobs.where((j) => j['status'] == 'failed'))
                Card(
                  child: ListTile(
                    title: Text(j['title'] ?? '공지'),
                    subtitle: Text(recoveryExplanation(recoveryCode(j))),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => openRecovery(j),
                  ),
                ),
              for (final j in jobs.where(
                (j) => ['pending', 'running'].contains(j['status']),
              ))
                ListTile(
                  title: Text(j['title'] ?? '공지'),
                  subtitle: Text(
                    j['status'] == 'running'
                        ? '분석 중'
                        : '자동 재시도 대기 · ${j['error'] ?? ''}',
                  ),
                  onTap: () => openRecovery(j),
                ),
              ExpansionTile(
                title: const Text('완료·제외 기록'),
                children: [
                  for (final j in jobs.where(
                    (j) =>
                        !['failed', 'pending', 'running'].contains(j['status']),
                  ))
                    ListTile(
                      title: Text(j['title'] ?? '공지'),
                      subtitle: Text(
                        {
                              'done': '완료 · 발견한 일정은 일정함에서 확인',
                              'empty': '완료 · 추가할 일정 없음',
                              'excluded': '사용자가 분석 제외',
                              'manual': '사용자가 직접 일정 추가',
                            }[j['status']] ??
                            '${j['status']}',
                      ),
                      onTap: () => openRecovery(j),
                    ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class AiDailyCard extends StatefulWidget {
  const AiDailyCard({super.key});
  @override
  State<AiDailyCard> createState() => _AiDailyCardState();
}

class _AiDailyCardState extends State<AiDailyCard> {
  String? text;
  bool enabled = false, busy = false;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    Store? s;
    try {
      s = await Store.open();
      final on = await s.meta('aiSummary') == 'yes';
      final p = await SharedPreferences.getInstance();
      await p.reload();
      final last = await s.meta('lastSuccess');
      final now = DateTime.now().toUtc();
      final hour = p.getInt('aiSummaryHour') ?? -99;
      final valid =
          on &&
          p.getString('aiSummaryLast') == last &&
          p.getString('aiSummaryDay') == schoolDay(now) &&
          (p.getInt('aiSummaryExpires') ?? 0) > now.millisecondsSinceEpoch &&
          now.millisecondsSinceEpoch ~/ 3600000 - hour >= 0 &&
          now.millisecondsSinceEpoch ~/ 3600000 - hour <= 1;
      if (mounted) {
        setState(() {
          enabled = on;
          text = valid ? p.getString('aiSummaryText') : null;
        });
      }
    } catch (_) {
      if (mounted) setState(() => text = null);
    } finally {
      await s?.db.close();
    }
  }

  Future<void> generate() async {
    setState(() => busy = true);
    Store? s;
    try {
      s = await Store.open();
      await s.setMeta('aiSummaryFailHash', '');
      await prepareAiSummary(s);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('요약을 준비하지 못했습니다. 잠시 후 다시 확인해 주세요.')),
        );
      }
    } finally {
      await s?.db.close();
      if (mounted) setState(() => busy = false);
    }
    await load();
  }

  @override
  Widget build(BuildContext context) => Card(
    child: ExpansionTile(
      key: const PageStorageKey<String>('ai-daily-summary-expansion'),
      leading: const Icon(Icons.auto_awesome),
      title: const Text('AI 데일리 요약'),
      subtitle: Text(
        enabled
            ? (text == null
                  ? '기본 현황을 확인하세요 · AI 요약 준비 대기'
                  : '수집된 목록에서 우선 확인할 일')
            : '선택 기능 · AI 설정에서 켤 수 있어요',
      ),
      childrenPadding: const EdgeInsets.all(16),
      expandedCrossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (text != null) SelectionArea(child: Text(text!)),
        if (enabled)
          TextButton(
            onPressed: busy ? null : generate,
            child: Text(busy ? '준비 중…' : '지금 요약 준비'),
          ),
        TextButton(
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AiSettingsPage()),
          ),
          child: const Text('AI 설정'),
        ),
      ],
    ),
  );
}

class SettingsHub extends StatelessWidget {
  final bool connected;
  final VoidCallback connect, logout, test;
  const SettingsHub({
    super.key,
    required this.connected,
    required this.connect,
    required this.logout,
    required this.test,
  });
  @override
  Widget build(BuildContext context) {
    void page(Widget w) =>
        Navigator.push(context, MaterialPageRoute(builder: (_) => w));
    return Scaffold(
      appBar: AppBar(title: const Text('설정')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SectionHeading('계정', subtitle: '이 기기의 포털 연결'),
          Card(
            child: ListTile(
              leading: Icon(
                connected ? Icons.verified_user_outlined : Icons.person_outline,
              ),
              title: Text(connected ? '포털 연결됨' : '포털 연결 필요'),
              subtitle: const Text('계정은 이 기기의 보안 저장소에 보관합니다.'),
              trailing: connected ? null : const Icon(Icons.chevron_right),
              onTap: connected ? null : connect,
            ),
          ),
          const SectionHeading('알림·표시', subtitle: '알림과 화면을 내 방식대로'),
          if (Platform.isAndroid)
            _setting(
              context,
              Icons.text_fields,
              '위젯 글씨 크기',
              '과제·콘텐츠 · 시간표 · 잠금화면',
              () => page(const WidgetTextPage()),
            ),
          _setting(
            context,
            Icons.palette_outlined,
            '화면 테마',
            '시스템 설정 · 라이트 · 다크',
            () => page(const AppearancePage()),
          ),
          if (Platform.isAndroid)
            _setting(
              context,
              Icons.schedule,
              '시간표·수업 알림',
              '강의계획서 시간표 · 수업 전 · 자정 요약',
              () => page(const TimetablePage()),
            ),
          if (Platform.isWindows)
            _setting(
              context,
              Icons.desktop_windows_outlined,
              'PC 실행 설정',
              '자동 수집 · 시작 프로그램 · 트레이 · 알림',
              () => page(const DesktopSettingsPage()),
            ),
          if (Platform.isAndroid)
            _setting(
              context,
              Icons.lock_outline,
              '잠금화면 정보',
              '전체 카드·작은 카드 선택',
              () => page(const LockScreenSettingsPage()),
            ),
          _setting(
            context,
            Icons.notifications_outlined,
            '데일리 알림',
            '매일 요약 시각·알림 테스트',
            () => page(const DailySummaryPage(settings: true)),
          ),
          const SectionHeading('연결', subtitle: 'AI와 캘린더 선택 기능'),
          _setting(
            context,
            Icons.auto_awesome,
            'AI 분석·자동화',
            '개인 키, 분석 범위, 데일리 요약',
            () => page(const AiSettingsPage()),
          ),
          _setting(
            context,
            Icons.calendar_month_outlined,
            Platform.isWindows ? '일정 파일 내보내기' : '캘린더 전송',
            Platform.isWindows ? '.ics 파일로 저장하고 캘린더에서 가져오기' : '저장할 캘린더와 자동 전송',
            () => page(
              Platform.isWindows
                  ? const DesktopCalendarPage()
                  : const CalendarSettingsPage(),
            ),
          ),
          const SectionHeading('앱 관리', subtitle: '업데이트와 동작 기록'),
          _setting(
            context,
            Icons.battery_charging_full,
            Platform.isWindows ? 'PC 자동 수집 상태' : '배터리·백그라운드 상태',
            Platform.isWindows
                ? '트레이 실행과 최근 자동 확인'
                : (Platform.isIOS ? '백그라운드 앱 새로 고침과 최근 수집' : '앱 배터리 제한과 수집 예약'),
            () => page(
              Platform.isWindows
                  ? const DesktopSettingsPage()
                  : const BackgroundStatusPage(),
            ),
          ),
          _setting(
            context,
            Icons.history,
            '활동 로그',
            '수집·알림·AI·캘린더·업데이트',
            () => page(const HistoryPage(notificationsOnly: false)),
          ),
          _setting(
            context,
            Icons.change_circle_outlined,
            '변경 이력',
            '과제와 콘텐츠의 변경 사항',
            () => page(const ChangesPage()),
          ),
          _setting(
            context,
            Icons.system_update_alt,
            '앱 업데이트',
            '현재 $installedAppVersion ($installedAppBuild) · ${channelLabel(appReleaseChannel)}',
            () => page(
              Platform.isWindows
                  ? const DesktopUpdatePage()
                  : const UpdatePage(),
            ),
          ),
          if (connected)
            _setting(
              context,
              Icons.notifications_active_outlined,
              '알림 표시 테스트',
              '기기에 테스트 알림 요청',
              test,
            ),
          ExpansionTile(
            title: const Text('기능 바로가기'),
            children: [
              _setting(
                context,
                Icons.school_outlined,
                '과목·약자 설정',
                '과목별 과제·공지·강의계획서',
                () => page(const CoursesPage()),
              ),
              _setting(
                context,
                Icons.chat_bubble_outline,
                'AI 채팅',
                '수집한 정보에 대해 질문하기',
                () => page(const AiChatPage()),
              ),
            ],
          ),
          const Divider(),
          if (connected)
            _setting(
              context,
              Icons.logout,
              '로그아웃',
              '계정·앱 데이터 삭제 범위를 확인합니다.',
              logout,
            ),
        ],
      ),
    );
  }

  Widget _setting(
    BuildContext c,
    IconData icon,
    String title,
    String subtitle,
    VoidCallback action,
  ) => ListTile(
    contentPadding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
    leading: Icon(icon),
    title: Text(title),
    subtitle: Text(subtitle),
    trailing: const Icon(Icons.chevron_right),
    onTap: action,
  );
}

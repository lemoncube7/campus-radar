import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/campus/academic_attachment.dart';
import 'dart:convert';
import 'package:archive/archive.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/freeboard_models.dart';
import 'package:campus_radar/courses/course_catalog.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';
import 'package:campus_radar/campus/material_catalog.dart';

class AcademicExport {
  final Map<String, String> documents;
  final String profileId;
  final Map<String, List<int>> originals;
  const AcademicExport(
    this.documents,
    this.profileId, [
    this.originals = const {},
  ]);
  List<int> zip() {
    final archive = Archive();
    for (final e in documents.entries) {
      final bytes = utf8.encode(e.value);
      archive.addFile(ArchiveFile(e.key, bytes.length, bytes));
    }
    for (final e in originals.entries) {
      archive.addFile(ArchiveFile(e.key, e.value.length, e.value));
    }
    return ZipEncoder().encode(archive);
  }
}

/// A readable, bounded snapshot. No generic model/context serialization.
AcademicExport packAcademicDocuments({
  required String profileId,
  required DateTime at,
  required DateTime? collectedAt,
  required Map<String, String> documents,
  List<String> warnings = const [],
  bool fixture = false,
  Map<String, List<int>> originals = const {},
}) {
  if (!RegExp(r'^[a-f0-9]{32}$').hasMatch(profileId)) {
    throw const FormatException('내보내기 프로필이 올바르지 않아요.');
  }
  if (documents.length > 250) throw const FormatException('문서 수가 너무 많습니다.');
  var total = 0;
  for (final e in documents.entries) {
    if (!RegExp(r'^(?:과목/)?[^/\\\x00-\x1f]+\.(txt|md)$').hasMatch(e.key) ||
        e.key.contains('..') ||
        e.key == '캠퍼스레이더 시작.txt') {
      throw const FormatException('문서 경로가 올바르지 않아요.');
    }
    final n = utf8.encode(e.value).length;
    total += n;
    if (n > 1048576 || total > 8388608) {
      throw const FormatException(
        '내보낼 자료가 크기 제한(문서 1MB·전체 8MB)을 넘었어요. 일부만 저장하지 않았어요.',
      );
    }
  }
  var binaryBytes = 0;
  if (originals.length > 5) {
    throw const FormatException('원본은 한 번에 최대 5개까지 포함할 수 있어요.');
  }
  for (final e in originals.entries) {
    if (!RegExp(r'^원본/[a-f0-9]{16}\.[a-z0-9]{1,8}$').hasMatch(e.key) ||
        e.value.length > 10 * 1024 * 1024) {
      throw const FormatException('원본 파일 경로/크기 제한을 확인해 주세요.');
    }
    binaryBytes += e.value.length;
  }
  if (binaryBytes > 20 * 1024 * 1024) {
    throw const FormatException('원본 합계는 최대 20MB이에요.');
  }
  final index = {
    'formatVersion': 1,
    'profileId': profileId,
    'fixture': fixture,
    'exportedAt': at.toUtc().toIso8601String(),
    'collectedAt': collectedAt?.toUtc().toIso8601String(),
    'timezone': 'Asia/Seoul',
    'warnings': warnings,
    // Rules travel with the data so an AI that reads this file through a
    // storage connector answers correctly without an installed skill.
    'readingRules': academicReadingRules,
    'documents': [
      for (final e in documents.entries)
        {
          // Extracted attachments have opaque paths; their first line names
          // the course and material.
          'title': e.key.startsWith('과목/첨부_')
              ? e.value.split('\n').first
              : e.key.replaceAll('.txt', '').replaceAll('.md', ''),
          'path': e.key,
        },
    ],
    'attachments': originals.isEmpty
        ? '첨부 원본 미포함 · 자료 인덱스/선택한 추출 텍스트 확인'
        : '사용자가 선택한 원본 ${originals.length}개 포함',
    'originalFiles': originals.keys.toList(),
    'refresh': '수동 스냅샷 · 새 내보내기 전까지 갱신되지 않음',
  };
  return AcademicExport(
    {
      '캠퍼스레이더 시작.txt':
          'CAMPUS_RADAR_START_V1\n${const JsonEncoder.withIndent('  ').convert(index)}',
      ...documents,
    },
    profileId,
    originals,
  );
}

String safeCourseFolderName(String name, [Set<String>? used]) {
  var safe = name.replaceAll(RegExp(r'[^가-힣A-Za-z0-9 _-]'), '_').trim();
  if (safe.isEmpty) safe = '과목';
  safe = safe.substring(0, safe.length.clamp(0, 50));
  var candidate = safe;
  var counter = 2;
  while (used != null && used.contains(candidate)) {
    candidate = '${safe}_$counter';
    counter++;
  }
  used?.add(candidate);
  return candidate;
}

String safeAttachmentFileName(String name) {
  var safe = name.replaceAll(RegExp(r'[/\\:*?"<>|\x00-\x1f]'), '_').trim();
  if (safe.isEmpty) safe = '첨부파일';
  return safe;
}

Map<String, String> buildCourseFolderMap(Iterable<String> courses) {
  final sorted = courses.toSet().toList()..sort();
  final used = <String>{};
  final result = <String, String>{};
  for (final c in sorted) {
    result[c] = safeCourseFolderName(c, used);
  }
  return result;
}

class DriveAttachmentPath {
  final String course;
  final String safeCourse;
  final String fileName;
  final String driveKey;
  final String zipKey;

  const DriveAttachmentPath({
    required this.course,
    required this.safeCourse,
    required this.fileName,
    required this.driveKey,
    required this.zipKey,
  });
}

Map<String, DriveAttachmentPath> resolveDriveAttachmentPaths(
  Iterable<StudyMaterial> materials, {
  Iterable<String>? allCourses,
  Map<String, String>? contentHashes,
}) {
  final courses = <String>{
    ...?allCourses,
    for (final m in materials) m.course,
  };
  final courseFolderMap = buildCourseFolderMap(courses);

  final materialsWithMedia = materials.where((m) => m.media != null).toList();
  final byCourse = <String, List<StudyMaterial>>{};
  for (final m in materialsWithMedia) {
    (byCourse[m.course] ??= []).add(m);
  }

  final result = <String, DriveAttachmentPath>{};
  final sortedCourses = byCourse.keys.toList()..sort();
  for (final course in sortedCourses) {
    final list = byCourse[course]!;
    list.sort((a, b) {
      final da = a.date?.toIso8601String() ?? '';
      final db = b.date?.toIso8601String() ?? '';
      final cmpDate = da.compareTo(db);
      if (cmpDate != 0) return cmpDate;
      final cmpTitle = a.title.compareTo(b.title);
      if (cmpTitle != 0) return cmpTitle;
      return a.id.compareTo(b.id);
    });

    final safeCourse = courseFolderMap[course] ?? safeCourseFolderName(course);
    final usedFileNames = <String>{};
    final attachmentToCandidate = <String, String>{};

    for (final m in list) {
      final rawName = m.media!.name;
      final clean = safeAttachmentFileName(rawName);

      // Identity is based on content hash (if available) or raw media identity (url + form + name).
      final attachmentKey = contentHashes?[m.id] ??
          contentHashes?[m.media!.identity] ??
          m.media!.identity;

      String candidate;
      if (attachmentToCandidate.containsKey(attachmentKey)) {
        // Reuse the same filename for identical attachment referenced across multiple assignments/notices.
        candidate = attachmentToCandidate[attachmentKey]!;
      } else {
        candidate = clean;
        if (usedFileNames.contains(candidate)) {
          final dot = clean.lastIndexOf('.');
          final hasExt = dot > 0;
          final base = hasExt ? clean.substring(0, dot) : clean;
          final ext = hasExt ? clean.substring(dot) : '';
          var counter = 2;
          candidate = '$base ($counter)$ext';
          while (usedFileNames.contains(candidate)) {
            counter++;
            candidate = '$base ($counter)$ext';
          }
        }
        usedFileNames.add(candidate);
        attachmentToCandidate[attachmentKey] = candidate;
      }

      final driveKey = '자료/$safeCourse/$candidate';
      final zipKey = '$safeCourse/$candidate';

      result[m.id] = DriveAttachmentPath(
        course: course,
        safeCourse: safeCourse,
        fileName: candidate,
        driveKey: driveKey,
        zipKey: zipKey,
      );
    }
  }

  return result;
}

String attachmentOriginalLocation({
  required String course,
  required String fileName,
  String? safeCourse,
  bool isSeparateUploaded = false,
  bool isZipUploaded = false,
  bool isFormMedia = false,
}) {
  final effectiveSafeCourse = safeCourse ?? safeCourseFolderName(course);
  if (isSeparateUploaded) {
    return 'Drive 원본: 자료/$effectiveSafeCourse/$fileName';
  }
  if (isZipUploaded) {
    return 'Drive 원본: 캠퍼스레이더 첨부원본.zip 안 $effectiveSafeCourse/$fileName';
  }
  if (isFormMedia) {
    return 'Drive 원본 없음 (학교 로그인이 필요해 링크로 받을 수 없어요)';
  }
  return 'Drive 원본 없음';
}

Future<AcademicExport> buildAcademicExport(
  Store store,
  String profileId, {
  DateTime? now,
  bool includeLinks = true,
  bool markdown = false,
  Set<String>? selectedCourses,
  bool exportTasks = true,
  bool exportNotices = true,
  bool exportMaterials = true,
  bool exportTimetable = true,
  bool exportPlans = true,
  bool exportFreeboard = false,
  Map<String, String> freeboardOriginals = const {},
  Map<String, Map<String, dynamic>> linkChecks = const {},
  Map<String, AttachmentText> attachmentTexts = const {},
  Map<String, List<int>> originals = const {},
  List<String> attachmentWarnings = const [],
  Set<String> uploadedOriginals = const {},
  Set<String> zipOriginals = const {},
  Map<String, DriveAttachmentPath>? attachmentPaths,
}) async {
  final at = (now ?? DateTime.now()).toUtc();
  final collected = DateTime.tryParse(
    await store.meta(MetaKey.lastSuccess) ?? '',
  );
  if (collected == null) throw const FormatException('먼저 학교 자료를 한 번 수집해 주세요.');
  final hidden = await store.excluded(), nonTasks = await store.notTasks();
  bool chosen(String name) =>
      selectedCourses == null || selectedCourses.contains(name);
  final items = exportTasks
      ? (await store.items()).where((i) => chosen(i.course)).toList()
      : <CampusItem>[];
  final notices = exportNotices
      ? (await store.notices()).where((n) => chosen(n.course)).toList()
      : <CampusNotice>[];
  final freeboard = exportFreeboard
      ? (await store.freeboardPosts()).where((p) => chosen(p.course)).toList()
      : <CampusFreeboardPost>[];
  if (freeboard.length > 1000) throw const FormatException('자유게시판 자료 건수 제한을 초과했어요.');
  final freeboardDocs = <String, StringBuffer>{};
  for (final post in freeboard) {
    final out = freeboardDocs.putIfAbsent(post.course,
      () => StringBuffer('${post.course} · 자유게시판\n다른 학생이 작성한 글이 포함되어 있어요. 공식 공지와 구별하세요. 첨부 원본은 기기에 받은 파일만 전송 대상이며 완료 여부는 Drive 전송 상태를 확인하세요.\n\n'));
    out.writeln('## ${post.title}\n작성자: ${post.author.isEmpty ? '미확인' : post.author}\n작성일: ${post.published == null ? '미확인' : koreanTime(post.published!)}');
    out.writeln(post.bodyFetched ? post.body : '본문 미수집: 기기에서 아직 읽지 못한 글이에요. 내용을 추측하지 마세요.');
    if (post.media.isNotEmpty) out.writeln('첨부 이름: ${post.media.map((m) => m.name).join(', ')}');
    for (final media in post.media) {
      out.writeln('${media.name}: ${freeboardOriginals[freeboardAttachmentId(post.courseKey, media)] ?? 'Drive 원본 없음 (기기에 받은 원본이 없거나 전송 준비가 되지 않았어요)'}');
    }
    if (post.hasAttachment && post.media.isEmpty) out.writeln('첨부 있음: 이름 미수집');
    out.writeln();
  }
  if (items.length > 2000 || notices.length > 500) {
    throw const FormatException('자료 건수 제한을 초과했어요.');
  }
  String date(DateTime? d) => d == null ? '미확인' : koreanTime(d);
  final overview = StringBuffer(
    '학업 현황 · 저장된 자료 기준\n수집: ${date(collected)}\n내보냄: ${date(at)}\n'
    '숨김/할 일 아님/시작 전 상태를 반드시 구별하세요.\n'
    '과목별 세부 공지, 강의계획서 및 자료실 다운로드 링크는 "과목/[과목명].txt" 문서에 정리되어 있어요.\n\n',
  );
  for (final i in items) {
    overview.writeln(
      '${i.course} | ${i.title}\n종류: ${i.type} · 상태: ${i.status} · 공개: ${i.published}\n시작: ${date(i.startsAt)} · 마감: ${date(i.due)} · 추가 제출 마감: ${date(i.additionalDue)}\n숨김: ${hidden.contains(i.key)} · 할 일 아님: ${nonTasks.contains(i.key)} · 출석 반영: ${i.attendanceRequired ?? '미확인'}\n',
    );
  }
  final slots = decodeSlots(await store.meta(MetaKey.timetableEntries))
      .where(
        (e) =>
            exportTimetable &&
            chosen(e.course) &&
            !e.courseKey.startsWith('personal:'),
      )
      .toList();
  final cancellationRead = await CancellationRepository(store).read();
  final schedule = StringBuffer(
    '내 주간 시간표 · Asia/Seoul\n개인 반복 일정과 친구 시간표는 제외했어요.\n\n',
  );
  for (final s in slots) {
    schedule.writeln(
      '${s.course} | ${weekNames[s.weekday - 1]} ${slotTime(s.start)}–${slotTime(s.end)} | ${s.room}',
    );
  }
  schedule.writeln('\n저장된 날짜별 휴강 (아래 날짜만 제외, 보강 추측 금지)');
  for (final c in cancellationRead.entries) {
    final slot = slots.where((s) => s.id == c.slotId).firstOrNull;
    if (slot != null) {
      schedule.writeln(
        '${c.date} | ${slot.course} | ${slotTime(slot.start)}–${slotTime(slot.end)}',
      );
    }
  }
  final courseDocs = <String, StringBuffer>{};
  StringBuffer doc(String course) => courseDocs.putIfAbsent(
    course,
    () => StringBuffer(
      '$course\n약칭: ${courseLabel(course)}\n수집: ${date(collected)}\n첨부 원본은 포함되지 않았어요.\n\n',
    ),
  );
  for (final n in notices) {
    doc(n.course).writeln(
      '## 공지: ${n.title}\n게시: ${date(n.published)} · 본문 수집: ${n.bodyFetched}\n${n.body}\n',
    );
  }
  final allStudyMaterials = await studyMaterials(store, now: at);
  final paths = attachmentPaths ?? resolveDriveAttachmentPaths(allStudyMaterials);
  final materials = allStudyMaterials
      .where((m) => exportMaterials && chosen(m.course))
      .toList();
  for (final m in materials) {
    final d = doc(m.course);
    if (m.sourceType == 'NT' && m.body.isNotEmpty) continue;
    final typeName = m.sourceType == 'LS' ? '자료실' : '${m.sourceType} 자료';
    d.writeln('## $typeName: ${m.title}');
    if (m.media != null) {
      final media = m.media!;
      final sizeKb = media.size != null ? ' (${(media.size! / 1024).round()}KB)' : '';
      d.writeln('첨부: ${media.name}$sizeKb');
      final directUrl = includeLinks ? directAcademicUrl(media) : null;
      if (directUrl != null) {
        d.writeln('다운로드 링크: $directUrl (로그인/인증 없이 즉시 다운로드 가능)');
      }
      final pathInfo = paths[m.id];
      final safeCourse = pathInfo?.safeCourse ?? safeCourseFolderName(m.course);
      final fileName = pathInfo?.fileName ?? safeAttachmentFileName(media.name);
      final separateKey = pathInfo?.driveKey ?? '자료/$safeCourse/$fileName';
      final zipKey = pathInfo?.zipKey ?? '$safeCourse/$fileName';
      final isSeparate = uploadedOriginals.contains(separateKey) || uploadedOriginals.contains(zipKey);
      final isZip = zipOriginals.contains(zipKey) || zipOriginals.contains('캠퍼스레이더 첨부원본.zip 안 $zipKey');
      final loc = attachmentOriginalLocation(
        course: m.course,
        safeCourse: safeCourse,
        fileName: fileName,
        isSeparateUploaded: isSeparate,
        isZipUploaded: isZip,
        isFormMedia: media.form.isNotEmpty,
      );
      d.writeln(loc);
    }
    if (m.externalUrl.isNotEmpty && includeLinks) {
      d.writeln('외부 링크: ${m.externalUrl}');
    }
    if (m.body.isNotEmpty) {
      d.writeln(m.body);
    }
    d.writeln();
  }
  for (final c in (await readCourses(
    store,
  )).where((c) => exportPlans && chosen('${c['course_nm']}'))) {
    final raw = await store.meta(MetaKey.coursePlan(courseKey(c)));
    if (raw == null) continue;
    final plan = jsonDecode(raw) as Map;
    if (plan['linkedText'] is String) {
      doc('${c['course_nm']}').writeln(
        '## 저장된 강의계획서\n계획서 수집: ${plan['fetchedAt'] ?? '미확인'}\n${plan['linkedText']}\n',
      );
    }
  }
  final fileIndex = StringBuffer(
    '첨부 자료 인덱스\n학교 직접 링크도 현재 AI 도구에서 읽히지 않을 수 있어요. 상태는 기기 네트워크의 관측 결과이며 LLM 읽기 성공을 뜻하지 않아요.\n',
  );
  final extracted = <String, String>{};
  for (final m in materials.where((m) => m.media != null)) {
    final media = m.media!;
    final check = linkChecks[m.id];
    final status =
        check?['status'] as String? ??
        (media.form.isNotEmpty ? 'postRequired' : 'unknown');
    fileIndex.writeln(
      '\n## ${m.course} · ${m.title}\n첨부: ${m.name} · ${media.size ?? '크기 미확인'}바이트\n접근: ${attachmentAccessLabel(status)} · 검사 시각: ${check?['checkedAt'] ?? '없음'}',
    );
    final url = includeLinks ? directAcademicUrl(media) : null;
    if (url != null) {
      fileIndex.writeln('다운로드 링크: $url (로그인/인증 없이 즉시 다운로드 가능)');
    }
    final pathInfo = paths[m.id];
    final safeCourse = pathInfo?.safeCourse ?? safeCourseFolderName(m.course);
    final fileName = pathInfo?.fileName ?? safeAttachmentFileName(media.name);
    final separateKey = pathInfo?.driveKey ?? '자료/$safeCourse/$fileName';
    final zipKey = pathInfo?.zipKey ?? '$safeCourse/$fileName';
    final isSeparate = uploadedOriginals.contains(separateKey) || uploadedOriginals.contains(zipKey);
    final isZip = zipOriginals.contains(zipKey) || zipOriginals.contains('캠퍼스레이더 첨부원본.zip 안 $zipKey');
    final loc = attachmentOriginalLocation(
      course: m.course,
      safeCourse: safeCourse,
      fileName: fileName,
      isSeparateUploaded: isSeparate,
      isZipUploaded: isZip,
      isFormMedia: media.form.isNotEmpty,
    );
    fileIndex.writeln(loc);
    final text = attachmentTexts[m.id];
    if (text != null) {
      fileIndex.writeln('텍스트 추출: ${text.note} · 일부 추출: ${text.partial}');
      if (text.text.trim().isNotEmpty) {
        final path = '과목/첨부_${m.id.substring(0, 16)}.txt';
        extracted[path] =
            '${m.course} · ${m.title}\n첨부: ${m.name}\n$loc\n추출 방식: ${text.note} · 일부 추출: ${text.partial}\n${text.text}';
        fileIndex.writeln(
          '추출 문서: ${markdown ? path.replaceAll('.txt', '.md') : path}',
        );
      }
    }
    final original = originals.keys
        .where((p) => p.startsWith('원본/${m.id.substring(0, 16)}.'))
        .firstOrNull;
    if (original != null) fileIndex.writeln('선택 원본 경로: $original');
  }
  String outputPath(String p) => markdown ? p.replaceAll('.txt', '.md') : p;
  return packAcademicDocuments(
    profileId: profileId,
    at: at,
    collectedAt: collected,
    warnings: [
      if ((await store.meta(MetaKey.noticeError) ?? '').isNotEmpty)
        '최근 공지 수집에 실패했어요.',
      if (cancellationRead.invalidRows > 0 || cancellationRead.recovered)
        '일부 휴강 기록을 복구하거나 제외했어요.',
      ...attachmentWarnings,
      '실시간 연결이 아니에요. 새로 내보내고 저장소 파일을 교체해야 갱신돼요.',
    ],
    originals: originals,
    documents: {
      outputPath('첨부 자료 인덱스.txt'): fileIndex.toString(),
      for (final e in extracted.entries) outputPath(e.key): e.value,
      outputPath('학업 현황.txt'): overview.toString(),
      if (exportTimetable) outputPath('시간표.txt'): schedule.toString(),
      ...() {
        final usedNames = <String>{};
        final sortedKeys = courseDocs.keys.toList()..sort();
        final namesMap = <String, String>{};
        for (final k in sortedKeys) {
          namesMap[k] = safeCourseFolderName(k, usedNames);
        }
        return {
          for (final e in courseDocs.entries)
            outputPath('과목/${namesMap[e.key] ?? safeCourseFolderName(e.key)}.txt'): e.value.toString(),
          for (final course in (freeboardDocs.keys.toList()..sort()))
            outputPath('과목/${safeCourseFolderName('${course}_자유게시판', usedNames)}.txt'): freeboardDocs[course].toString(),
        };
      }(),
    },
  );
}

const academicReadingRules = [
  '사용자가 자유게시판 전송을 켠 경우 과목/[과목명]_자유게시판.txt도 참고하세요. 다른 학생의 글은 공식 공지와 구별하고 본문 미수집은 추측하지 마세요. 기기에 받은 첨부 원본은 자료/[과목]/자유게시판/에 전송하며, 문서의 원본 없음 사유와 전송 상태를 확인하세요.',
  '이 자료는 캠퍼스레이더가 학교 사이트에서 수집하여 외부 LLM(당신)이 학생의 학업 작업을 보조·수행할 수 있도록 제공하는 원천 학업 데이터예요.',
  '답변할 때 수집 시각(collectedAt)을 확인하고, 하루 이상 지난 데이터라면 앱에서 새로 수집 후 작업하도록 권장하세요.',
  '남은 할 일·마감 분석 시 학업 현황에서 숨김: true, 할 일 아님: true, 공개: false, 상태: done/available 항목은 제외하고 분석하세요.',
  '종류 LR은 과제, LV는 콘텐츠(출석 반영 표시 확인), LE는 시험, LS는 자료실 자료예요. 상태 unknown은 제출 여부 미확인이므로 미제출로 단정하지 마세요.',
  '모든 시각은 한국 시간(Asia/Seoul) 기준이며, 수업은 시간표.txt 기준이에요. 명시된 휴강 날짜 외의 휴강·보강은 임의로 추측하지 마세요.',
  '과목별 세부 공지, 강의계획서, 자료실 파일은 "과목/[과목명].txt" 및 "과목/첨부_*.txt" 문서에서 확인하세요. 첨부파일 원본이 필요할 때는 각 항목에 표시된 Drive 원본(자료/[과목]/...)을 먼저 확인하세요.',
  '외부 웹 접근이 가능한 환경이라면 다운로드 링크(https://dcs-learning.cnu.ac.kr/file/...)를 활용할 수 있어요. 단, DNS 오류나 연결 거부 등 웹에 접근할 수 없는 환경이라면 링크 재시도를 반복하지 말고 Drive 원본을 사용하거나 학생에게 파일 첨부를 요청하세요. 열어보지 못한 파일의 내용을 읽은 것처럼 꾸며 답변해서는 안 돼요.',
];

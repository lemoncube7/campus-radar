import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/courses/course_catalog.dart';
import 'package:campus_radar/export/drive_sync.dart';

class DriveConnectionPage extends StatefulWidget {
  const DriveConnectionPage({super.key});
  @override
  State<DriveConnectionPage> createState() => _DriveConnectionState();
}

class _DriveConnectionState extends State<DriveConnectionPage>
    with WidgetsBindingObserver {
  List<Map<String, dynamic>> accounts = [];
  bool busy = false;
  String? error;
  String? notice;
  Timer? statusTimer;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    load();
    statusTimer = Timer.periodic(const Duration(seconds: 5), (_) { if (mounted && !busy) load(clearError: false); });
  }

  @override
  void dispose() {
    statusTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && !busy) load();
  }

  Future<void> load({bool clearError = true}) async {
    try {
      final rows = await bridge.invokeNativeList<dynamic>(
        NativeMethod.driveAccounts,
      );
      if (mounted) {
        setState(() {
          accounts = (rows ?? [])
              .map((r) => Map<String, dynamic>.from(r as Map))
              .toList();
          if (clearError) error = null;
        });
      }
    } catch (_) {
      if (mounted) setState(() => error = 'Drive 연결 상태를 읽지 못했어요. 다시 확인해 주세요.');
    }
  }

  Future<void> run(Future<void> Function() action) async {
    if (busy) return;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      await action();
    } catch (e) {
      final shown = e is PlatformException
          ? (e.message ?? 'Google 연결을 확인해 주세요.')
          : e is FormatException
          ? e.message
          : '처리를 마치지 못했어요. 기존 연결은 유지해요.';
      if (mounted) setState(() => error = shown);
      await systemLog('Drive 연결 화면 작업 실패', shown, kind: 'app', error: e);
    } finally {
      if (mounted) {
        setState(() => busy = false);
        await load(clearError: false);
      }
    }
  }

  Future<void> connect([String? email]) => run(() async {
    final row = await bridge.invokeNativeMap<String, dynamic>(
      NativeMethod.driveConnect,
      {'email': email},
    );
    if (row != null && mounted) await edit(row);
  });
  Future<void> edit(Map<String, dynamic> row) async {
    final account = await credentials.read(key: 'id');
    if (account == null) throw const FormatException('먼저 학교 계정을 연결해 주세요.');
    final s = await Store.open();
    List<String> courses;
    try {
      courses = (await readCourses(
        s,
      )).map((c) => '${c['course_nm']}').toSet().toList();
    } finally {
      await s.db.close();
    }
    Map<String, dynamic> options = {};
    try {
      if (row['options'] is String) {
        options = Map<String, dynamic>.from(jsonDecode(row['options']) as Map);
      }
    } catch (_) {
      /* Use visible defaults for an invalid setting. */
    }
    final selected = Set<String>.from(
      (options['courses'] as List?)?.cast<String>() ?? [],
    );
    var allCourses = selected.isEmpty;
    var enabled = row['enabled'] == true, consent = false;
    for (final key in ['tasks', 'notices', 'materials', 'plans', 'timetable']) {
      options[key] = options[key] != false;
    }
    options['links'] = options['links'] == true;
    options['texts'] = options['texts'] == true;
    if (!mounted) return;
    final accepted = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          title: const Text('자동으로 보낼 자료'),
          content: SizedBox(
            width: 480,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${row['email']}의 비공개 캠퍼스레이더 폴더에 저장해요. 여러 계정을 각각 연결할 수 있어요.',
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('자동 갱신'),
                    value: enabled,
                    onChanged: (v) => set(() => enabled = v),
                  ),
                  for (final item in const {
                    'tasks': '과제·콘텐츠 상태',
                    'notices': '공지 본문',
                    'materials': '자료 본문·첨부 목록',
                    'plans': '저장된 강의계획서',
                    'timetable': '수업 시간표·휴강',
                    'links': '학교 원본 링크 (식별자 포함 가능)',
                    'texts': '기기에 저장된 첨부 텍스트 (최대 10개, 그림·표 일부 누락 가능)',
                  }.entries)
                    CheckboxListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(item.value),
                      value: options[item.key] == true,
                      onChanged: (v) =>
                          set(() => options[item.key] = v == true),
                    ),
                  CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('모든 과목'),
                    value: allCourses,
                    onChanged: (v) => set(() => allCourses = v == true),
                  ),
                  if (!allCourses)
                    for (final course in courses)
                      CheckboxListTile(
                        contentPadding: EdgeInsets.zero,
                        title: Text(course),
                        value: selected.contains(course),
                        onChanged: (v) => set(
                          () => v == true
                              ? selected.add(course)
                              : selected.remove(course),
                        ),
                      ),
                  const Text(
                    '키·쿠키·구조화된 점수·개인 일정·친구 시간표는 제외해요. 본문 자체에 개인정보가 있을 수 있어요. 범위를 줄이면 기존 자동 내보내기 문서는 휴지통으로 옮겨요. 연결 해제는 이미 올린 자료를 삭제하지 않아요.',
                  ),
                  CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('이 계정에 선택한 자료를 자동 전송하는 데 동의해요'),
                    value: consent,
                    onChanged: (v) => set(() => consent = v == true),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('취소'),
            ),
            FilledButton(
              onPressed:
                  (!enabled || consent) && (allCourses || selected.isNotEmpty)
                  ? () => Navigator.pop(ctx, true)
                  : null,
              child: const Text('설정 저장'),
            ),
          ],
        ),
      ),
    );
    if (accepted != true) return;
    options['courses'] = allCourses ? <String>[] : selected.toList();
    await bridge.invokeNative(NativeMethod.driveConfigure, {
      'id': row['id'],
      'enabled': enabled,
      'accountHash': driveAccountHash(account),
      'options': options,
    });
    if (enabled) await prepareDriveSnapshot(manual: true);
  }

  Future<void> disconnect(Map row) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('이 계정의 자동 전송을 해제할까요?'),
        content: const Text(
          '앱에서 연결을 지우고 전송을 중지해요. Drive에 이미 저장한 파일은 남아요. Google 권한은 Google 계정의 연결된 앱에서 별도로 철회할 수 있어요.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(c, true),
            child: const Text('연결 해제'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await bridge.invokeNative(NativeMethod.driveDisconnect, {
        'id': row['id'],
      });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Drive 자동 연결'),
      actions: [
        IconButton(
          onPressed: busy ? null : load,
          icon: const Icon(Icons.refresh),
          tooltip: '상태 다시 확인',
        ),
      ],
    ),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text(
          '한 번 연결하면 자료가 바뀔 때 갱신해요.',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const Text(
          'AI마다 사용하는 계정이 달라도 각각 연결할 수 있어요. 수집 성공과 앱 정보 변경 후 자료를 준비하며, Android가 허용하는 백그라운드 작업에서 전송해요. 각 AI의 Drive 연결은 별도로 설정해 주세요.',
        ),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: busy ? null : () => connect(),
          icon: const Icon(Icons.add),
          label: Text(busy ? '처리 중…' : 'Google 계정 연결'),
        ),
        if (notice != null) Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: Text(notice!)),
        if (error != null)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(
              error!,
              style: TextStyle(color: Theme.of(context).colorScheme.error),
            ),
          ),
        for (final row in accounts)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${row['email']}',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  Text(row['enabled'] == true ? '자동 전송 켜짐' : '자동 전송 꺼짐'),
                  Text(
                    (row['lastSuccess'] as String?)?.isNotEmpty == true
                        ? '마지막 완료: ${DateTime.tryParse(row['lastSuccess'])?.toLocal() ?? row['lastSuccess']}'
                        : '아직 전송 완료 기록이 없어요.',
                  ),
                  if ((row['error'] as String?)?.isNotEmpty == true)
                    Text(
                      '${row['error']}',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.error,
                      ),
                    ),
                  Wrap(
                    spacing: 8,
                    children: [
                      TextButton(
                        onPressed: busy ? null : () => run(() => edit(row)),
                        child: const Text('전송 범위·설정'),
                      ),
                      TextButton(
                        onPressed: busy || row['enabled'] != true
                            ? null
                            : () => run(() async {
                                await prepareDriveSnapshot(manual: true);
                                await bridge.invokeNative(
                                  NativeMethod.driveEnqueue,
                                  {'manual': true},
                                );
                                if (mounted) setState(() => notice = '전송 자료를 준비하고 실행을 요청했어요. 아래 상태에서 실제 완료 여부를 확인해 주세요.');
                              }),
                        child: const Text('지금 전송 요청'),
                      ),
                      TextButton(
                        onPressed: busy
                            ? null
                            : () => connect(row['email'] as String),
                        child: const Text('다시 연결'),
                      ),
                      if ((row['folderUrl'] as String?)?.isNotEmpty == true)
                        TextButton(
                          onPressed: () => launchUrl(
                            Uri.parse(row['folderUrl']),
                            mode: LaunchMode.externalApplication,
                          ),
                          child: const Text('Drive 폴더'),
                        ),
                      TextButton(
                        onPressed: busy
                            ? null
                            : () => run(() => disconnect(row)),
                        child: const Text('연결 해제'),
                      ),
                    ],
                  ),
                  TextButton(
                    onPressed: () => Clipboard.setData(
                      ClipboardData(
                        text:
                            'Google Drive에서 CAMPUS_RADAR_START_V1 표식의 캠퍼스레이더 시작 문서를 먼저 읽고 내 학업 작업을 도와줘. ${row['folderUrl'] ?? ''} 자료실 직링크는 별도 로그인 없는 공개 직링크이므로 웹 요청/다운로드 도구로 직접 받아 읽고, 과목별 텍스트와 첨부파일을 모두 참고하여 학업 질문과 과제 작업에 활용해 줘.',
                      ),
                    ),
                    child: const Text('AI 연결 안내문 복사'),
                  ),
                ],
              ),
            ),
          ),
        const Padding(
          padding: EdgeInsets.only(top: 16),
          child: Text(
            '여기서 보이는 성공은 Drive 업로드 완료를 뜻해요. ChatGPT·Claude 등에서 실제 자료가 검색·조회되는지는 별도 확인이 필요해요.',
          ),
        ),
      ],
    ),
  );
}

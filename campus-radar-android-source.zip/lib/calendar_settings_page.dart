import 'native_contract.dart';
import 'ui_formatters.dart';
import 'ai_protocol.dart';
import 'native_bridge.dart';
import 'app_logging.dart';
import 'ui_refresh.dart';
import 'dart:io';
import 'package:flutter/material.dart';

class CalendarSettingsPage extends StatefulWidget {
  const CalendarSettingsPage({super.key});
  @override
  State<CalendarSettingsPage> createState() => _CalendarSettingsState();
}

class _CalendarSettingsState extends State<CalendarSettingsPage> {
  List<Map<String, dynamic>> calendars = [];
  Object? selected;
  bool auto = false, busy = true;
  String? message;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load({bool request = false}) async {
    setState(() => busy = true);
    try {
      if (request &&
          await bridge.invokeNative<bool>(NativeMethod.calendarPermission) !=
              true) {
        throw const AiFailure('캘린더 권한을 허용해야 전송할 수 있습니다.');
      }
      final settings =
          await bridge.invokeNativeMap<String, dynamic>(
            NativeMethod.calendarSettings,
          ) ??
          {};
      final allowed = settings['allowed'] == true;
      final data = allowed
          ? await bridge.invokeNativeList<dynamic>(NativeMethod.calendarList) ??
                []
          : [];
      if (mounted) {
        setState(() {
          calendars = data
              .map((c) => Map<String, dynamic>.from(c as Map))
              .toList();
          final id = settings['calendarId'];
          selected = calendars.any((c) => c['id'] == id) ? id : null;
          auto = settings['auto'] == true;
          message = allowed
              ? (calendars.isEmpty
                    ? '저장할 수 있는 캘린더가 없습니다. 캘린더 앱에서 계정을 먼저 연결해 주세요.'
                    : null)
              : '캘린더 권한을 허용하고 저장할 캘린더를 선택하세요.';
        });
      }
    } catch (e) {
      if (mounted) setState(() => message = userError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> save() async {
    if (selected == null) {
      setState(() => message = '저장할 캘린더를 선택해 주세요.');
      return;
    }
    setState(() => busy = true);
    try {
      await bridge.invokeNative(NativeMethod.calendarConfigure, {
        'calendarId': selected,
        'auto': auto,
      });
      await systemLog(
        '캘린더 설정 저장',
        auto ? '미완료·공개·시작된 항목의 앞으로 남은 마감 자동 전송 켜짐' : '자동 전송 꺼짐 · 개별 전송 가능',
      );
      await bridge.invokeNative(NativeMethod.calendarSync);
      if (mounted) setState(() => message = '저장했습니다. 결과는 캘린더와 수집 로그에서 확인하세요.');
    } catch (e) {
      if (mounted) setState(() => message = userError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> unlink() async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('캘린더 연결을 해제할까요?'),
        content: const Text(
          '자동 전송과 기존 일정 갱신을 중지합니다. 캘린더에 저장한 일정은 삭제하지 않습니다. 다시 연결해 자동 전송하면 기존 일정과 중복될 수 있습니다.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('연결 해제'),
          ),
        ],
      ),
    );
    if (yes != true) return;
    await bridge.invokeNative(NativeMethod.calendarUnlink);
    await load();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(Platform.isWindows ? '일정 파일 저장' : '캘린더 전송 설정')),
    bottomNavigationBar: PinnedAction(
      child: FilledButton(
        onPressed: busy ? null : save,
        child: Text(busy ? '동기화 중…' : '설정 저장·지금 동기화'),
      ),
    ),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Text(
          Platform.isIOS
              ? 'Apple·Google 등 iPhone에 연결된 캘린더에 저장합니다. 연결된 일정의 중복 방지와 갱신을 위해 캘린더 접근 권한이 필요합니다.'
              : '삼성·Google 캘린더 등 기기에 연결된 캘린더에 저장합니다. 계정 캘린더를 선택하면 해당 계정의 동기화 설정에 따라 일정이 서버로 동기화될 수 있습니다.',
        ),
        const SizedBox(height: 12),
        FilledButton.tonal(
          onPressed: busy ? null : () => load(request: true),
          child: const Text('캘린더 권한 허용·목록 새로고침'),
        ),
        const SectionHeading('저장할 캘린더', subtitle: '이 기기에 연결된 캘린더에서 선택'),
        RadioGroup<Object>(
          groupValue: selected,
          onChanged: (v) {
            if (!busy) setState(() => selected = v);
          },
          child: Column(
            children: calendars
                .map(
                  (c) => RadioListTile<Object>(
                    value: c['id'] as Object,
                    title: Text(c['name'] as String),
                    subtitle: Text(c['account'] as String),
                    enabled: !busy,
                  ),
                )
                .toList(),
          ),
        ),
        const SectionHeading('자동 전송'),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('과제·콘텐츠 마감 자동 전송'),
          subtitle: const Text(
            '새로 수집한 미완료 항목 중 공개·시작된 미래 마감만 추가합니다. 연결된 항목은 이후 수집 시 기한·제목·완료 상태를 갱신합니다.',
          ),
          value: auto,
          onChanged: busy ? null : (v) => setState(() => auto = v),
        ),
        const Text(
          'AI 일정은 원문 확인 후 개별 저장합니다. 목록 제외·로그아웃·연결 해제는 이미 저장한 캘린더 일정을 삭제하지 않습니다. 캘린더에서 직접 지운 연결 일정은 자동으로 다시 만들지 않습니다. 캘린더 알림은 추가하지 않으며 기존 앱 알림을 유지합니다.',
        ),
        if (message != null)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(message!),
          ),
        TextButton(
          onPressed: busy ? null : unlink,
          child: const Text('기존 연결 해제'),
        ),
      ],
    ),
  );
}

import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/session/session_probe_policy.dart';
import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/core/operation_token.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/session/school_lifetime_observer.dart';
import 'package:campus_radar/session/session_lifetime_repository.dart';

const reconnectChoices = <int>[15, 30, 60, 120, 240, 360, 480, 720, 1440];

class CampusReconnectDeferred extends CampusException {
  CampusReconnectDeferred(super.message);
}

Future<int?> schoolReconnectMinutes() async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  if (prefs.getBool(PrefKey.schoolReconnectManual) == true) return null;
  final value = prefs.getInt(PrefKey.schoolReconnectMinutes);
  return reconnectChoices.contains(value) ? value : 120;
}

Future<void> saveSchoolReconnectMinutes(int? minutes) async {
  if (minutes != null && !reconnectChoices.contains(minutes)) {
    throw ArgumentError.value(minutes);
  }
  final prefs = await SharedPreferences.getInstance();
  if (minutes == null) {
    await prefs.setBool(PrefKey.schoolReconnectManual, true);
    await prefs.remove(PrefKey.schoolReconnectMinutes);
  } else {
    await prefs.setInt(PrefKey.schoolReconnectMinutes, minutes);
    await prefs.setBool(PrefKey.schoolReconnectManual, false);
  }
}

String _sessionKey(String account) =>
    'schoolSession:${sha256.convert(utf8.encode(account))}';

/// Only explicit authentication evidence starts a hold. Network and schema
/// errors leave the encrypted snapshot intact and never trigger a login retry.
Future<void> _markLost(Store store, SessionScope scope) async {
  await scope.verify();
  if (await store.meta(MetaKey.schoolSessionLostEpoch) == scope.epoch &&
      await store.meta(MetaKey.schoolSessionLostAt) != null) {
    return;
  }
  await store.setMeta(MetaKey.schoolSessionLostEpoch, scope.epoch);
  await store.setMeta(
    MetaKey.schoolSessionLostAt,
    DateTime.now().toUtc().toIso8601String(),
  );
  await store.log(
    'sync',
    '학교 세션 재연결 보류',
    '학교 인증이 종료됐어요. 다른 기기에서 로그인했을 수 있어 설정한 시간만큼 재로그인을 미뤄요. 원인은 확정할 수 없으며 기존 목록은 유지해요.',
  );
}

Future<void> rememberSchoolSession(
  Map<String, dynamic> snapshot,
  String account,
) async {
  final store = await Store.open();
  try {
    final scope = await SessionScope.capture(store);
    if (scope.account != account) throw SessionChanged();
    final observationId = freshToken();
    await credentials.write(
      key: _sessionKey(account),
      value: jsonEncode({
        'epoch': scope.epoch,
        'snapshot': snapshot,
        'observationId': observationId,
      }),
    );
    await scope.verify();
    try {
      await SessionLifetimeRepository(store).change(scope.epoch, (state) {
        final now = DateTime.now().toUtc().millisecondsSinceEpoch;
        state.beginSession(observationId, now, freshlyLoggedIn: true);
        state.beginValidation('credential-verification', now);
        state.validated('credential-verification', now);
      });
    } catch (_) {
      // Unreadable optional diagnostics must not break credential saving.
    }
    await store.setMeta(MetaKey.schoolSessionLostAt, '');
    await store.setMeta(MetaKey.schoolSessionLostEpoch, '');
  } finally {
    await store.db.close();
  }
}

/// Windows "폰 자료(Drive)" mode: the PC must not log into the school, or it
/// would compete with the phone's session. Set by the Drive viewer.
Future<bool> pcDriveMode() async {
  if (!Platform.isWindows) return false;
  try {
    final prefs = await SharedPreferences.getInstance();
    await prefs.reload();
    return prefs.getString('pcDataSource') == 'drive';
  } catch (_) {
    // Unreadable preferences (tests, broken store): behave as before Drive
    // mode existed instead of failing the edit or school action.
    return false;
  }
}

const pcDriveModeMessage =
    '지금 PC는 폰 자료(Drive) 보기 모드라 학교에 접속하지 않아요. 이 기능은 홈의 ‘직접 로그인’으로 바꾼 뒤 써 주세요.';

const pcViewOnlyMessage =
    'PC는 폰 자료(Drive) 보기 모드라 여기서 바꾸지 않아요. 폰에서 바꾸면 다음 확인 때 PC에도 반영돼요.';

/// Edits made on a Drive-viewer PC would not reach the phone and would be
/// replaced by the next check, so they are refused instead.
Future<void> ensurePcEditable() async {
  if (await pcDriveMode()) throw CampusException(pcViewOnlyMessage);
}

extension ReusableSchoolSession on CampusClient {
  Future<void> connectSchool(
    String account,
    String password, {
    bool reconnectNow = false,
    bool allowFreshLogin = true,
    bool forSessionTest = false,
  }) async {
    if (await pcDriveMode()) throw CampusException(pcDriveModeMessage);
    final prefs = await SharedPreferences.getInstance();
    await prefs.reload();
    if (forSessionTest &&
        !SessionProbePolicy.fromPreferences(prefs).activeAt(DateTime.now())) {
      throw CampusReconnectDeferred('전용 세션 테스트가 종료되어 연결을 시작하지 않았어요.');
    }
    if (SessionProbePolicy.fromPreferences(prefs).activeAt(DateTime.now()) &&
        !forSessionTest &&
        !reconnectNow) {
      // Manual reads may reuse the session and restart the idle clock, but a
      // stale automatic job must not replace the test's session by logging in.
      allowFreshLogin = false;
    }
    final store = await Store.open();
    final owner = freshToken();
    var locked = false;
    var observationId = freshToken();
    SchoolLifetimeObserver? observer;
    try {
      final scope = await SessionScope.capture(store);
      if (scope.account != account) throw SessionChanged();
      Future<void> persistUpdatedSession() async {
        final current = await Store.open();
        try {
          final active = await SessionScope.capture(current);
          if (active.account != account || active.epoch != scope.epoch) {
            throw SessionChanged();
          }
          await credentials.write(
            key: _sessionKey(account),
            value: jsonEncode({
              'epoch': scope.epoch,
              'snapshot': exportSession(),
              'observationId': observationId,
            }),
          );
          await active.verify();
        } finally {
          await current.db.close();
        }
      }

      // A separate auth lease avoids concurrent UI/worker fresh logins. Never
      // reuse the collection lease, which synchronize already owns.
      locked = await store.db.transaction((txn) async {
        final rows = await txn.query(
          'meta',
          where: 'id=?',
          whereArgs: ['schoolAuthLease'],
        );
        final until = rows.isEmpty
            ? 0
            : int.tryParse('${rows.first['value']}') ?? 0;
        final now = DateTime.now().millisecondsSinceEpoch;
        if (until > now) return false;
        await txn.rawInsert(
          'INSERT OR REPLACE INTO meta(id,value) VALUES(?,?)',
          [
            'schoolAuthLease',
            '${now + const Duration(minutes: 5).inMilliseconds}',
          ],
        );
        await txn.rawInsert(
          'INSERT OR REPLACE INTO meta(id,value) VALUES(?,?)',
          ['schoolAuthLeaseOwner', owner],
        );
        return true;
      });
      if (!locked) {
        throw CampusException('다른 학교 연결을 준비하고 있어요. 잠시 뒤 다시 확인해 주세요.');
      }
      await scope.verify();
      final lostAt =
          await store.meta(MetaKey.schoolSessionLostEpoch) == scope.epoch
          ? DateTime.tryParse(
              await store.meta(MetaKey.schoolSessionLostAt) ?? '',
            )
          : null;
      if (!reconnectNow &&
          await store.meta(MetaKey.schoolLoginRejectedEpoch) == scope.epoch) {
        // Retrying a rejected password on every automatic sync risks locking
        // the school account. Wait for the user to reconnect or open the app.
        throw CampusReconnectDeferred(
          '학교 로그인이 거절되어 자동 연결을 멈췄어요. 비밀번호를 확인하고 포털을 다시 연결해 주세요.',
        );
      }
      if (lostAt != null && !reconnectNow) {
        final minutes = await schoolReconnectMinutes();
        if (minutes == null) {
          throw CampusReconnectDeferred(
            '학교 세션이 끊겨 자동 재로그인을 보류했어요. 백그라운드 상태에서 재연결 대기 시간을 선택하거나 포털을 다시 연결해 주세요.',
          );
        }
        final until = lostAt.add(Duration(minutes: minutes));
        if (DateTime.now().toUtc().isBefore(until)) {
          throw CampusReconnectDeferred(
            '다른 기기 접속을 보호하기 위해 재로그인을 기다리고 있어요. 약 ${until.difference(DateTime.now().toUtc()).inMinutes + 1}분 후 다음 수집에서 다시 연결해요.',
          );
        }
      }
      final saved = await credentials.read(key: _sessionKey(account));
      // Opening the app or tapping refresh (reconnectNow) also tries the saved
      // session first; only a dead session costs a fresh login (~1 s).
      if (saved != null && lostAt == null) {
        Map<String, dynamic> envelope;
        try {
          envelope = Map<String, dynamic>.from(jsonDecode(saved) as Map);
          if (envelope['epoch'] == scope.epoch) {
            observationId =
                envelope['observationId'] as String? ?? observationId;
            restoreSession(
              Map<String, dynamic>.from(envelope['snapshot'] as Map),
            );
          }
        } catch (_) {
          // Do not silently replace an unreadable session by logging in.
          throw CampusException('저장한 학교 연결 정보를 읽지 못했어요. 포털을 다시 연결해 주세요.');
        }
        if (envelope['epoch'] == scope.epoch) {
          authenticationLost = () async {
            final current = await Store.open();
            try {
              final active = await SessionScope.capture(current);
              if (active.epoch != scope.epoch || active.account != account) {
                throw SessionChanged();
              }
              await _markLost(current, active);
              await observer?.failed(CampusAuthenticationLost());
            } finally {
              await current.db.close();
            }
          };
          observer = await SchoolLifetimeObserver.attach(
            this,
            scope.epoch,
            observationId,
            fresh: false,
          );
          var reused = true;
          if (reconnectNow) {
            // A session ended elsewhere (e.g. a PC login) is expected here:
            // log in again instead of pausing reconnection.
            final strict = authenticationLost;
            authenticationLost = null;
            try {
              await fetchCourses();
            } on CampusAuthenticationLost catch (e) {
              reused = false;
              await observer.failed(e);
              clearSession();
              diagnostic?.call('Saved school session expired; logging in');
            }
            authenticationLost = strict;
          } else {
            await fetchCourses(); // Authenticated, read-only endpoint, not /home.
          }
          if (reused) {
            await observer.validated();
            await scope.verify();
            await credentials.write(
              key: _sessionKey(account),
              value: jsonEncode({
                'epoch': scope.epoch,
                'snapshot': exportSession(),
                'observationId': observationId,
              }),
            );
            diagnostic?.call('School session reused');
            sessionUpdated = persistUpdatedSession;
            return;
          }
        }
      }
      if (!allowFreshLogin) {
        throw CampusReconnectDeferred(
          '세션 탐색은 새로 로그인하지 않아요. 기존 세션이 없어 탐색을 보류했어요.',
        );
      }
      if (forSessionTest) {
        await prefs.reload();
        if (!SessionProbePolicy.fromPreferences(
          prefs,
        ).activeAt(DateTime.now())) {
          throw CampusReconnectDeferred('전용 세션 테스트가 종료되어 로그인하지 않았어요.');
        }
      }
      authenticationLost = null;
      sessionUpdated = null;
      if (lostAt != null) {
        // A failed reconnection attempt must not cause a rapid login loop.
        await store.setMeta(
          MetaKey.schoolSessionLostAt,
          DateTime.now().toUtc().toIso8601String(),
        );
      }
      try {
        await login(account, password);
      } on CampusLoginRejected {
        await store.setMeta(MetaKey.schoolLoginRejectedEpoch, scope.epoch);
        rethrow;
      }
      await store.setMeta(MetaKey.schoolLoginRejectedEpoch, '');
      await scope.verify();
      await credentials.write(
        key: _sessionKey(account),
        value: jsonEncode({
          'epoch': scope.epoch,
          'snapshot': exportSession(),
          'observationId': observationId,
        }),
      );
      await store.setMeta(MetaKey.schoolSessionLostAt, '');
      await store.setMeta(MetaKey.schoolSessionLostEpoch, '');
      authenticationLost = () async {
        final current = await Store.open();
        try {
          final active = await SessionScope.capture(current);
          if (active.epoch != scope.epoch || active.account != account) {
            throw SessionChanged();
          }
          await _markLost(current, active);
          await observer?.failed(CampusAuthenticationLost());
        } finally {
          await current.db.close();
        }
      };
      // Persist the login result before the first read: a network failure on
      // that read must not discard a valid new login and kick another device
      // again on the next attempt.
      sessionUpdated = persistUpdatedSession;
      observer = await SchoolLifetimeObserver.attach(
        this,
        scope.epoch,
        observationId,
        fresh: true,
      );
      await fetchCourses();
      await observer.validated();
      diagnostic?.call('School session newly connected');
    } catch (error) {
      if (error is! CampusReconnectDeferred) await observer?.failed(error);
      rethrow;
    } finally {
      if (locked) {
        await store.db.transaction((txn) async {
          final rows = await txn.query(
            'meta',
            where: 'id=?',
            whereArgs: ['schoolAuthLeaseOwner'],
          );
          if (rows.isNotEmpty && rows.single['value'] == owner) {
            await txn.delete(
              'meta',
              where: 'id IN (?,?)',
              whereArgs: ['schoolAuthLease', 'schoolAuthLeaseOwner'],
            );
          }
        });
      }
      await store.db.close();
    }
  }
}

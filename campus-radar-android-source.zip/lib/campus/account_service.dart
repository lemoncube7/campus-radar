import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/platform/android_widget_snapshot.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/notification_gateway.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/courses/course_colors.dart';
import 'package:campus_radar/core/network_resilience.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/core/background_contract.dart';
import 'package:campus_radar/session/session_lifetime_probe.dart';

/// Logout policy has no widget lifecycle or dialog dependencies. Each step
/// reports failure independently. The saved login is deleted last and only
/// after collected data is gone, so a failed wipe leaves the user logged in
/// and able to retry instead of handing the data to the next account.
Future<List<String>> performAccountLogout() async {
  Store? scopeStore;
  var dataWiped = false;
  final failures = await completeLogout([
    (
      '세션 차단',
      () async {
        ActiveRequests.cancelAll();
        scopeStore = await Store.open();
        await SessionScope.rotate(scopeStore!, blocked: true);
      },
    ),
    if (Platform.isAndroid)
      ('AI 작업 취소', () => Workmanager().cancelByTag('campus-ai')),
    if (Platform.isAndroid)
      ('세션 탐색 취소', () => Workmanager().cancelByUniqueName(sessionLifetimeTask)),
    if (!Platform.isWindows)
      ('수집 작업 취소', () => Workmanager().cancelByUniqueName(periodicTask)),
    if (Platform.isAndroid)
      (
        '진단 작업 취소',
        () => Workmanager().cancelByUniqueName('campus-radar-probe'),
      ),
    if (Platform.isAndroid || Platform.isIOS)
      (
        '캘린더 연결 해제',
        () async {
          await bridge.invokeNative(NativeMethod.calendarUnlink);
        },
      ),
    if (Platform.isAndroid)
      (
        '잠금화면 해제',
        () async {
          await bridge.invokeNative(NativeMethod.lockConfigure, {
            'enabled': false,
            'mode': 'compact',
            'position': 'right',
            'details': false,
          });
        },
      ),
    (
      '자동 내보내기 대기 자료 삭제',
      () async {
        final root = await getApplicationSupportDirectory();
        for (final entry in root.listSync().whereType<File>()) {
          if (entry.uri.pathSegments.last.startsWith('drive-texts-')) {
            await entry.delete();
          }
        }
        final file = File('${root.path}/drive-export-v1.json');
        if (await file.exists()) await file.delete();
      },
    ),
    (
      '첨부 캐시 삭제',
      () async {
        final root = Directory(
          '${(await getTemporaryDirectory()).path}/campus_media',
        );
        if (await root.exists()) await root.delete(recursive: true);
      },
    ),
    (
      '웹 로그인 삭제',
      () async {
        await bridge.invokeNative(NativeMethod.clearWebSession);
      },
    ),
    (
      '수집 정보 삭제',
      () async {
        scopeStore ??= await Store.open();
        await scopeStore!.db.transaction((txn) async {
          for (final table in ['items', 'events', 'notices', 'logs']) {
            await txn.delete(table);
          }
          await txn.delete(
            'meta',
            where: 'id NOT IN (?,?)',
            whereArgs: ['sessionEpoch', 'sessionBlocked'],
          );
        });
        dataWiped = true;
      },
    ),
    // After the wipe, so reminders a sync scheduled meanwhile are removed too.
    ('알림 취소', () => notifications.cancelAll()),
    (
      '요약·과목 설정 삭제',
      () async {
        final prefs = await SharedPreferences.getInstance();
        for (final key in [
          'scheduled',
          'courseAliases',
          'courseColorOverrides',
          'aiSummaryText',
          'aiSummaryLast',
          'aiSummaryDay',
        ]) {
          await prefs.remove(key);
        }
        await clearAndroidWidgetSnapshot(prefs: prefs);
        courseAliases = {};
        courseColorOverrides.clear();
        await prefs.setBool(PrefKey.aiSummaryEnabled, false);
        await prefs.setBool(PrefKey.aiDailyEnabled, false);
      },
    ),
    if (Platform.isAndroid || Platform.isIOS)
      (
        '매일 알림 해제',
        () async {
          await bridge.invokeNative(NativeMethod.setDailySettings, {
            'enabled': false,
            'hour': 18,
            'minute': 0,
          });
        },
      ),
    if (Platform.isAndroid || Platform.isIOS)
      (
        '위젯 갱신',
        () async {
          await bridge.invokeNative(NativeMethod.refreshWidget);
        },
      ),
    (
      '로그인 정보 삭제',
      () async {
        if (!dataWiped) throw StateError('collected data not wiped');
        await credentials.deleteAll();
        if (await credentials.read(key: 'id') != null ||
            await credentials.read(key: 'pw') != null ||
            await credentials.read(key: 'geminiApiKey') != null) {
          throw StateError('credential deletion failed');
        }
      },
    ),
  ]);
  await scopeStore?.db.close();
  return failures;
}

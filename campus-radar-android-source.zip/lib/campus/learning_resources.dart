import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/campus/campus_media.dart';

bool taskTypeMatches(CampusItem item, String selected) =>
    selected.isEmpty ||
    (selected == 'OTHER' ? item.isOther : item.type == selected);
const learningTypeChoices = {
  '': '전체',
  'LR': '과제',
  'LV': '콘텐츠',
  'LS': '자료실',
  'OTHER': '기타',
};

String safeExternalLink(Object? value, {bool cloud = false}) {
  final u = Uri.tryParse('${value ?? ''}');
  if (u == null ||
      !{'http', 'https'}.contains(u.scheme) ||
      u.host.isEmpty ||
      u.userInfo.isNotEmpty) {
    return '';
  }
  if (!cloud) return u.toString();
  // Never export opaque viewer signatures, tickets or sessions to the plugin.
  return u
      .replace(
        queryParameters: {
          for (final e in u.queryParameters.entries)
            if (const {'v', 't', 'list', 'page'}.contains(e.key))
              e.key: e.value,
        },
        fragment: '',
      )
      .toString();
}

String contentProgress(Map<String, dynamic> m) {
  final minutes = num.tryParse('${m['study_time'] ?? ''}');
  final seconds = num.tryParse('${m['lv_complete_rst'] ?? ''}');
  if (minutes == null || minutes <= 0) return '';
  final learned = m['complete_yn'] == 'Y'
      ? minutes.toInt()
      : seconds == null
      ? null
      : (seconds / 60).floor();
  return learned == null
      ? '학습 기준 ${minutes.toInt()}분'
      : '학습 $learned/${minutes.toInt()}분';
}

CampusItem? parseAdditionalLearning(
  Map<String, dynamic> m,
  Map<String, dynamic> c,
  Map<String, dynamic> base,
) {
  final type = '${m['module_type']}';
  if (!const {'LS', 'LD', 'LT', 'LQ', 'LE'}.contains(type)) return null;
  final id =
      m[const {
        'LS': 'boarditem_no',
        'LD': 'discuss_no',
        'LT': 'team_project_no',
        'LQ': 'exam_no',
        'LE': 'exam_no',
      }[type]] ??
      m['contents_id'];
  if (id == null || '$id'.isEmpty) return null;
  String value(List<String> fields) {
    for (final f in fields) {
      if (m[f] != null && '${m[f]}'.isNotEmpty) return '${m[f]}';
    }
    return '';
  }

  DateTime? date(List<String> fields) {
    final s = value(fields);
    return campusDate(s.length == 10 ? '$s 00:00' : s);
  }

  final body = value([
    'boarditem_content',
    'discuss_content',
    'team_project_content',
    'exam_content',
    'weekseq_content',
  ]);
  final context = <String, dynamic>{
    ...base,
    'course_id': c['course_id'],
    'class_no': c['class_no'],
    'module_type': type,
    'contents_id': '$id',
    'weekseq_no': m['weekseq_no'],
    if (type == 'LS') 'boarditem_no': id,
    if (type == 'LD') 'discuss_no': id,
    if (type == 'LT') 'team_project_no': id,
    if (type == 'LQ' || type == 'LE') 'exam_no': id,
  };
  return CampusItem(
    key: '$type:${c['course_id']}:${c['class_no']}:$id',
    type: type,
    title: textOf(
      value([
        'boarditem_title',
        'discuss_topic',
        'team_project_title',
        'exam_title',
        'weekseq_nm',
      ]),
    ),
    course: textOf(c['course_nm']),
    courseId: str(c, 'course_id'),
    classNo: str(c, 'class_no'),
    contentsId: '$id',
    status: type == 'LS' ? 'available' : 'unknown',
    body: campusBodyPieces(
      body,
    ).map((p) => p.text).where((s) => s.isNotEmpty).join('\n\n'),
    bodyHtml: body,
    media: extractCampusMedia(
      body,
      m['attach_file_list'],
      notice: type == 'LS',
    ),
    startsAt: date([
          'insert_dt',
          'reg_dt',
          'ins_dt',
          'boarditem_reg_dt',
          'discuss_str_dt',
          'str_dt',
          'exam_sdate',
          'apply_str_dt',
        ]) ??
        moduleStart(m),
    due: type == 'LS'
        ? null
        : (date(['discuss_end_dt', 'end_dt', 'exam_edate', 'apply_end_dt']) ??
              campusDate(
                '${m['weekseq_end_dt']} ${m['weekseq_end_dt_hour']}:${m['weekseq_end_dt_min']}:00',
              )),
    published:
        m['learning_open_yn'] != 'N' &&
        m['status'] != 'B' &&
        m['hide_yn'] != 'Y' &&
        m['delete_yn'] != 'Y' &&
        m['complete_delete_yn'] != 'Y',
    externalUrl: safeExternalLink(m['contents_url']),
    context: context,
  );
}

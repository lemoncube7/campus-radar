import 'dart:convert';
import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'services.dart';

const appVersion = '0.4.6';
const appBuild = 25;
String installedAppVersion = appVersion;
int installedAppBuild = appBuild;

/// The OS package is authoritative; constants are only an offline fallback.
Future<void> loadInstalledVersion() async {
  try {
    final info = await bridge
        .invokeMapMethod<String, dynamic>('versionInfo')
        .timeout(const Duration(seconds: 2));
    final name = info?['name'];
    final code = info?['code'];
    if (name is String &&
        name.trim().isNotEmpty &&
        code is num &&
        code.toInt() > 0) {
      installedAppVersion = name;
      installedAppBuild = code.toInt();
    }
  } catch (_) {
    // Preserve the last known package version when the native bridge is unavailable.
  }
}

const appReleaseChannel = String.fromEnvironment(
  'RELEASE_CHANNEL',
  defaultValue: 'stable',
);
String channelLabel(String c) => c == 'development' ? '개발 버전' : '정식 릴리스';
const updateRoot =
    'https://raw.githubusercontent.com/lemoncube7/campus-radar/main/updates';
typedef ManifestLoader = Future<Map<String, dynamic>?> Function(String channel);
Map<String, dynamic> validateUpdate(Map<String, dynamic> m, String channel) {
  if (m['versionCode'] is! int ||
      (m['versionCode'] as int) < 1 ||
      m['versionName'] is! String ||
      m['apkUrl'] is! String ||
      !RegExp(r'^[a-fA-F0-9]{64}$').hasMatch(m['sha256']?.toString() ?? '')) {
    throw const FormatException('업데이트 정보 형식이 잘못됐습니다.');
  }
  final uri = Uri.tryParse(m['apkUrl']);
  if (uri == null ||
      uri.scheme != 'https' ||
      uri.host.isEmpty ||
      uri.userInfo.isNotEmpty) {
    throw const FormatException('업데이트 파일은 HTTPS 주소여야 합니다.');
  }
  if (m['channel'] != null && m['channel'] != channel) {
    throw const FormatException('업데이트 채널이 일치하지 않습니다.');
  }
  return {...m, 'channel': channel};
}

Future<Map<String, dynamic>?> loadUpdateManifest(String channel) async {
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
  try {
    final uri = Uri.parse('$updateRoot/$channel.json').replace(
      queryParameters: {'check': '${DateTime.now().millisecondsSinceEpoch}'},
    );
    final req = await client.getUrl(uri);
    req.headers.set('Cache-Control', 'no-cache');
    final response = await req.close().timeout(const Duration(seconds: 10));
    if (response.statusCode == 404) {
      await response.drain<void>();
      return null;
    }
    if (response.statusCode != 200) {
      throw const FormatException('업데이트 서버에 연결하지 못했습니다.');
    }
    final bytes = <int>[];
    await for (final chunk in response.timeout(const Duration(seconds: 10))) {
      bytes.addAll(chunk);
      if (bytes.length > 100000) {
        throw const FormatException('업데이트 정보가 너무 큽니다.');
      }
    }
    return validateUpdate(
      Map<String, dynamic>.from(jsonDecode(utf8.decode(bytes))),
      channel,
    );
  } finally {
    client.close(force: true);
  }
}

Future<String> updateChannel() async {
  final p = await SharedPreferences.getInstance();
  await p.reload();
  return p.getString('updateChannel') ??
      (appReleaseChannel == 'development' ? 'development' : 'stable');
}

Map<String, dynamic>? chooseUpdate(
  Iterable<Map<String, dynamic>> manifests,
  String channel,
  int current,
) {
  final eligible =
      manifests
          .where(
            (m) =>
                m['versionCode'] > current &&
                (m['channel'] == 'stable' || channel == 'development'),
          )
          .toList()
        ..sort(
          (a, b) =>
              (b['versionCode'] as int).compareTo(a['versionCode'] as int),
        );
  return eligible.firstOrNull;
}

Future<Map<String, dynamic>?> cachedUpdate({int? current}) async {
  if (current == null) await loadInstalledVersion();
  final p = await SharedPreferences.getInstance();
  await p.reload();
  final channel = await updateChannel();
  final values = <Map<String, dynamic>>[];
  for (final c in ['stable', if (channel == 'development') 'development']) {
    try {
      final raw = p.getString('updateInfo:$c');
      if (raw != null) {
        values.add(
          validateUpdate(Map<String, dynamic>.from(jsonDecode(raw)), c),
        );
      }
    } catch (_) {}
  }
  return chooseUpdate(values, channel, current ?? installedAppBuild);
}

Future<void> checkForUpdates(
  Store store, {
  ManifestLoader loader = loadUpdateManifest,
}) async {
  final p = await SharedPreferences.getInstance();
  await p.reload();
  final channel = await updateChannel();
  var failures = 0;
  String? detail;
  for (final c in ['stable', if (channel == 'development') 'development']) {
    try {
      final m = await loader(c);
      if (m == null) {
        await p.remove('updateInfo:$c');
      } else {
        await p.setString('updateInfo:$c', jsonEncode(validateUpdate(m, c)));
      }
    } catch (_) {
      failures++;
      detail = '업데이트 정보를 가져오지 못했습니다. 마지막으로 확인한 정보는 유지합니다.';
    }
  }
  await p.setString(
    'updateCheckedAt',
    DateTime.now().toUtc().toIso8601String(),
  );
  await p.setString('updateCheckError', failures == 0 ? '' : detail!);
  final candidate = await cachedUpdate();
  await store.log(
    'app',
    failures > 0
        ? '업데이트 자동 확인 일부 실패'
        : candidate == null
        ? '업데이트 확인 완료'
        : '업데이트 가능',
    '${channelLabel(channel)} 채널 · ${candidate == null ? '새 버전 없음' : '${candidate['versionName']} (${channelLabel(candidate['channel'])})'}',
  );
}

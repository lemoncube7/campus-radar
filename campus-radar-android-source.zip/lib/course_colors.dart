import 'package:flutter/material.dart';

const courseAccentColors = [
  Color(0xff4566b0),
  Color(0xff2a8d80),
  Color(0xffc36b43),
  Color(0xff8f62b5),
  Color(0xff3e84b8),
  Color(0xffb55880),
];
Color courseAccent(String key) {
  var value = 0;
  for (final unit in key.codeUnits) {
    value = (31 * value + unit) & 0x7fffffff;
  }
  return courseAccentColors[value % courseAccentColors.length];
}

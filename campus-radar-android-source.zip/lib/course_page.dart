import 'adaptive_content.dart';
import 'syllabus_reader.dart';
import 'task_display_preferences.dart';
import 'task_categories.dart';
import 'campus_session.dart';
import 'syllabus_loader.dart';
import 'navigation_contract.dart';
import 'native_contract.dart';
import 'ai_chat_page.dart';
import 'task_presentation.dart';
import 'course_catalog.dart';
import 'app_storage.dart';
import 'native_bridge.dart';
import 'app_credentials.dart';
import 'course_aliases.dart';
import 'course_labels.dart';
import 'campus_models.dart';
import 'session_scope.dart';
import 'plan_fetch.dart';
import 'package:flutter/services.dart';
import 'timetable_model.dart';
import 'ui_refresh.dart';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'campus.dart';
import 'services.dart';

class CoursePage extends StatefulWidget {
  final Map<String, dynamic> course;
  const CoursePage({super.key, required this.course});
  @override
  State<CoursePage> createState() => _CoursePageState();
}

class _CoursePageState extends State<CoursePage> {
  List<CampusItem> items = [];
  List<CampusNotice> notices = [];
  Set<String> excluded = {};
  bool loading = true, planBusy = false, showCompleted = false;
  String courseTaskType = '';
  String? error, planError;
  Map<String, dynamic>? plan;
  String get name => '${widget.course['course_nm']}';
  String get key => courseKey(widget.course);
  @override
  void initState() {
    super.initState();
    unawaited(load());
  }

  Future<void> load() async {
    Store? s;
    try {
      s = await Store.open();
      final all = await s.items();
      final ns = await s.notices();
      final ex = await s.excluded();
      final cache = await s.meta('coursePlan:$key');
      if (mounted) {
        setState(() {
          items = all
              .where(
                (i) =>
                    courseKey(i.context) == key &&
                    (i.availableAt(DateTime.now().toUtc()) ||
                        showWaitingAssignments.value &&
                            waitingAssignment(i, DateTime.now().toUtc())),
              )
              .toList();
          notices = ns.where((n) => courseKey(n.context) == key).toList();
          excluded = ex;
          plan = cache == null
              ? null
              : Map<String, dynamic>.from(jsonDecode(cache));
          loading = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          error = '과목 정보를 읽지 못했습니다.';
          loading = false;
        });
      }
    } finally {
      await s?.db.close();
    }
  }

  Future<void> alias() async {
    var edited = courseAliases[name] ?? '';
    final value = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('과목 약자'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(name),
            const SizedBox(height: 12),
            TextFormField(
              initialValue: edited,
              onChanged: (value) => edited = value,
              maxLength: 30,
              autofocus: true,
              decoration: const InputDecoration(
                labelText: '예: 컴프2',
                helperText: '비우면 원래 과목명으로 표시합니다.',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, edited),
            child: const Text('저장'),
          ),
        ],
      ),
    );
    if (value == null) return;
    try {
      await setCourseAlias(name, value);
      final s = await Store.open();
      try {
        await s.log('app', '과목 약자 변경', name);
        await reconcile(s);
      } finally {
        await s.db.close();
      }
      if (mounted) setState(() {});
    } catch (_) {
      message('약자를 저장하지 못했습니다.');
    }
  }

  void message(String text) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
    }
  }

  Future<CampusClient> connected() async {
    final c = CampusClient();
    try {
      final id = await credentials.read(key: 'id'),
          pw = await credentials.read(key: 'pw');
      if (id == null || pw == null) throw CampusException('포털을 먼저 연결해 주세요.');
      await c.connectSchool(id, pw);
      return c;
    } catch (_) {
      c.close();
      rethrow;
    }
  }

  CampusItem get courseItem => CampusItem(
    key: 'COURSE:$key',
    type: 'COURSE',
    title: name,
    course: name,
    courseId: '${widget.course['course_id']}',
    classNo: '${widget.course['class_no']}',
    contentsId: '',
    status: 'unknown',
    context: widget.course,
  );
  Future<void> openCourse({bool syllabus = false}) async {
    CampusClient? c;
    try {
      c = await connected();
      final nav = await c.navigation(courseItem);
      if (syllabus) nav['url'] = '${CampusClient.learning}/std/coursePlan';
      await bridge.invokeNative(NativeMethod.openCampus, nav);
    } catch (e) {
      message(e is CampusException ? e.message : '강의실을 열지 못했습니다.');
    } finally {
      c?.close();
    }
  }

  Future<void> fetchPlan() async {
    setState(() => planBusy = true);
    final account = await credentials.read(key: 'id');
    CampusClient? c;
    Store? s;
    var stage = '로그인';
    final watch = Stopwatch()..start();
    try {
      s = await Store.open();
      final scope = await SessionScope.capture(s);
      c = await retryPlanConnection(() => connected());
      stage = '과목 선택';
      final response = await retryPlanConnection(
        () => c!.api('/course/addSessionCourseInfo', widget.course),
      );
      stage = '계획서 주소 조회';
      final ctx = response['data'];
      final data = await c!.api(
        '/coursePlan/getInfo',
        ctx is String
            ? Map<String, dynamic>.from(jsonDecode(ctx))
            : Map<String, dynamic>.from(ctx),
      );
      if (data is! Map || data['plan_info'] is! Map) {
        throw CampusException('강의계획서 본문이 제공되지 않았습니다. 원문에서 확인해 주세요.');
      }
      if (await credentials.read(key: 'id') != account) {
        throw CampusException('계정이 변경되어 저장을 중지했습니다.');
      }
      final link = data['link_course_info'] is Map
          ? data['link_course_info']['link_url']
          : null;
      String? linkedText;
      List<List<List<String>>> linkedTables = [];
      stage = '실제 계획서 로딩·본문 인식';
      if (link is String && link.isNotEmpty) {
        linkedText = await loadLinkedSyllabus(
          link,
          name,
          onTables: (tables) => linkedTables = tables,
        );
      }
      if (await credentials.read(key: 'id') != account) {
        throw CampusException('계정이 변경되어 저장을 중지했습니다.');
      }
      final result = <String, dynamic>{
        'linkedText': linkedText,
        'linkedTables': linkedTables,
        'linkedUrl': link,
        'fetchedAt': DateTime.now().toUtc().toIso8601String(),
        'data': data,
      };
      await scope.verify();
      await s.setMeta('coursePlan:$key', jsonEncode(result));
      await s.log(
        'sync',
        '강의계획서 저장',
        linkedText == null
            ? '사이버캠퍼스 본문'
            : '바로가기 실제 계획서 · ${linkedText.length}자',
      );
      if (mounted) {
        setState(() {
          plan = result;
          planError = null;
        });
      }
    } catch (e) {
      try {
        s ??= await Store.open();
        await s.log(
          'sync',
          '강의계획서 불러오기 실패',
          '$stage · ${watch.elapsed.inSeconds}초 · ${e.runtimeType} · ${e is PlatformException ? e.code : ""}',
        );
      } catch (_) {}
      if (mounted) setState(() => planError = '$stage: ${planFailure(e)}');
    } finally {
      c?.close();
      await s?.db.close();
      if (mounted) setState(() => planBusy = false);
    }
  }

  Widget tasks(String type) {
    final list =
        items
            .where(
              (i) =>
                  (courseTaskType.isEmpty || i.type == courseTaskType) &&
                  !excluded.contains(i.key) &&
                  (showCompleted || !i.done),
            )
            .toList()
          ..sort(
            (a, b) => (a.due ?? DateTime.utc(2100)).compareTo(
              b.due ?? DateTime.utc(2100),
            ),
          );
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text(name, style: Theme.of(context).textTheme.bodySmall),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          children: [
            for (final kind in {'': '전체', 'LR': '과제', 'LV': '콘텐츠'}.entries)
              ChoiceChip(
                label: Text(kind.value),
                selected: courseTaskType == kind.key,
                onSelected: (_) => setState(() => courseTaskType = kind.key),
              ),
            FilterChip(
              label: const Text('완료 포함'),
              selected: showCompleted,
              onSelected: (value) => setState(() => showCompleted = value),
            ),
          ],
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Text('${list.length}개 · 마감 빠른 순'),
        ),
        if (list.isEmpty)
          const Padding(
            padding: EdgeInsets.all(20),
            child: Text('현재 조건에 해당하는 할 일이 없어요.'),
          ),
        for (final item in list)
          RadarTaskCard(
            item: item,
            compact: true,
            onTap: () async {
              await navigateTo(context, TaskDestination(item: item));
              await load();
            },
          ),
      ],
    );
  }

  Widget planView() {
    final linkedText = plan?['linkedText'] as String?;
    final data = plan?['data'] as Map?;
    final info = data?['plan_info'] as Map?;
    const labels = {
      'lect_summary': '강의 개요',
      'lect_goal': '학습 목표',
      'lect_method': '강의 방법',
      'lect_reference': '참고 자료',
      'lect_eval': '평가 방법',
      'link_comment': '안내',
    };
    final weeks = data?['week_list'] as List? ?? [];
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Wrap(
          spacing: 8,
          children: [
            FilledButton.icon(
              onPressed: planBusy ? null : fetchPlan,
              icon: const Icon(Icons.refresh),
              label: Text(planBusy ? '불러오는 중…' : '강의계획서 불러오기'),
            ),
            OutlinedButton(
              onPressed: () async {
                final link = plan?['linkedUrl'];
                if (link is String && link.isNotEmpty) {
                  await bridge.invokeNative(NativeMethod.openLinkedPlan, {
                    'url': link,
                    'course': name,
                  });
                } else {
                  await openCourse(syllabus: true);
                }
              },
              child: const Text('강의계획서 원문 보기'),
            ),
          ],
        ),
        const SizedBox(height: 16),
        if (planError != null) Text(planError!),
        if (plan != null)
          Text(
            '저장본 · ${DateTime.tryParse('${plan!['fetchedAt']}') == null ? '저장 시각 미확인' : koreanTime(DateTime.parse(plan!['fetchedAt']))}',
          ),
        if (plan == null && !planBusy)
          const Text('버튼을 누르면 사이버캠퍼스의 강의계획서 바로가기가 여는 실제 계획서를 불러와 기기에 저장합니다.'),
        if (linkedText != null) ...[
          const SectionHeading('수업 시간·강의실'),
          if (parsePlanSlots(linkedText, key, name).isEmpty)
            const Text('명시된 수업 시각을 찾지 못했습니다. 원문을 확인해 주세요.'),
          ...parsePlanSlots(linkedText, key, name).map(
            (e) => ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.schedule),
              title: Text(
                '${weekNames[e.weekday - 1]} ${slotTime(e.start)}–${slotTime(e.end)}',
              ),
              subtitle: Text(e.room.isEmpty ? '강의실 미확인' : e.room),
            ),
          ),
          const SectionHeading('강의계획서'),
        ],
        if (linkedText != null)
          Card(
            child: ListTile(
              leading: const Icon(Icons.description_outlined),
              title: const Text('강의계획서 전체 읽기'),
              subtitle: Text(
                parseSyllabusTables(plan?['linkedTables']).isEmpty
                    ? '텍스트 저장본 · 다시 불러오면 표 구조도 저장해요'
                    : '표와 항목 구분을 유지한 읽기 화면',
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => SyllabusReader(
                    course: courseLabel(name),
                    text: linkedText,
                    tables: plan?['linkedTables'],
                  ),
                ),
              ),
            ),
          ),
        if (linkedText == null)
          ...labels.entries
              .where((e) => textOf(info?[e.key]).isNotEmpty)
              .map(
                (e) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        e.value,
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 6),
                      SelectableText(textOf(info?[e.key])),
                    ],
                  ),
                ),
              ),
        if (linkedText == null &&
            plan != null &&
            labels.keys.every((k) => textOf(info?[k]).isEmpty) &&
            weeks.isEmpty)
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text('텍스트 본문이 없습니다. 외부 링크·첨부 계획서는 원문 버튼으로 확인하세요.'),
          ),
        if (linkedText == null)
          ...weeks.map(
            (w) => Card(
              child: ListTile(
                title: Text(
                  '${w['week_no'] ?? ''}주차 · ${textOf(w['week_title'])}',
                ),
                subtitle: Text(textOf(w['week_materials'])),
              ),
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) => DefaultTabController(
    length: 3,
    child: Scaffold(
      appBar: AppBar(
        title: Text(courseLabel(name)),
        actions: [
          IconButton(
            tooltip: '약자 설정',
            onPressed: alias,
            icon: const Icon(Icons.edit_outlined),
          ),
          IconButton(
            tooltip: '이 과목 AI 질문',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AiChatPage(course: widget.course),
              ),
            ),
            icon: const Icon(Icons.chat_bubble_outline),
          ),
          IconButton(
            tooltip: '강의실 바로가기',
            onPressed: openCourse,
            icon: const Icon(Icons.open_in_new),
          ),
        ],
        bottom: const TabBar(
          isScrollable: false,
          tabs: [
            Tab(icon: Icon(Icons.checklist, size: 18), text: '할 일'),
            Tab(icon: Icon(Icons.campaign_outlined, size: 18), text: '공지'),
            Tab(
              icon: Icon(Icons.description_outlined, size: 18),
              text: '수업 정보',
            ),
          ],
        ),
      ),
      body: AdaptiveContent(
        child: loading
            ? const Center(child: CircularProgressIndicator())
            : error != null
            ? Center(child: Text(error!))
            : TabBarView(
                children: [
                  tasks(''),
                  ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      if (notices.isEmpty) const Text('수집된 공지가 없습니다.'),
                      ...notices.map(
                        (n) => Card(
                          child: ListTile(
                            title: Text(n.title),
                            subtitle: Text(
                              n.published == null
                                  ? '게시일 미확인'
                                  : koreanTime(n.published!),
                            ),
                            onTap: () => navigateTo(
                              context,
                              NoticeDestination(notice: n),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  planView(),
                ],
              ),
      ),
    ),
  );
}

import 'package:campus_radar/home/usage_report.dart';
import 'package:campus_radar/export/drive_connection_page.dart';
import 'package:campus_radar/export/academic_export_page.dart';
import 'package:campus_radar/core/adaptive_content.dart';
import 'package:campus_radar/session/session_exploration_page.dart';
import 'package:campus_radar/settings/permissions_page.dart';
import 'package:campus_radar/schedule/timetable_page.dart';
import 'package:campus_radar/updates/release_history_page.dart';
import 'package:campus_radar/settings/app_help_page.dart';
import 'package:campus_radar/home/feature_recommendation.dart';
import 'package:campus_radar/ai/ai_chat_page.dart';
import 'package:campus_radar/notices/notice_pages.dart';
import 'package:campus_radar/home/home_navigation.dart';
import 'package:campus_radar/navigation/workspace_navigation.dart';
import 'package:campus_radar/platform/ios_widget_settings.dart';
import 'package:campus_radar/tasks/task_cleanup_settings.dart';
import 'package:campus_radar/settings/notification_settings_page.dart';
import 'package:campus_radar/settings/widget_settings_page.dart';
import 'package:campus_radar/ai/ai_settings_page.dart';
import 'package:campus_radar/schedule/calendar_settings_page.dart';
import 'package:campus_radar/tasks/changes_page.dart';
import 'package:campus_radar/settings/history_page.dart';
import 'package:campus_radar/session/background_status_page.dart';
import 'package:campus_radar/updates/update_page.dart';
import 'package:campus_radar/core/ui_refresh.dart';
import 'package:campus_radar/platform/desktop.dart';
import 'package:campus_radar/settings/radar_theme.dart';
import 'package:campus_radar/updates/updates.dart';
import 'package:campus_radar/core/demo_mode.dart';
import 'package:campus_radar/core/developer_mode.dart';
import 'dart:io';
import 'package:flutter/material.dart';

class SettingsHub extends StatelessWidget {
  final bool connected;
  final VoidCallback connect, logout, test;
  final VoidCallback? onStartDemo;
  final bool embedded;
  const SettingsHub({
    super.key,
    required this.connected,
    required this.connect,
    required this.logout,
    required this.test,
    this.onStartDemo,
    this.embedded = false,
  });
  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.paddingOf(context).bottom;

    void page(Widget w) =>
        Navigator.push(context, MaterialPageRoute(builder: (_) => w));
    void group(String title, List<Widget> children) => page(
      Scaffold(
        appBar: AppBar(title: Text(title)),
        body: AdaptiveContent(
          child: ListView(
            padding: EdgeInsets.fromLTRB(20, 20, 20, 80 + bottomInset),
            children: children,
          ),
        ),
      ),
    );

    final content = AdaptiveContent(
      child: ListView(
        padding: EdgeInsets.fromLTRB(20, 20, 20, 80 + bottomInset),
        children: [
          // Search box first: people look for a feature by a word
          // ("휴강", "위젯", "드라이브"), not by the menu it lives in.
          Material(
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(16),
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => page(const AppHelpPage(autofocus: true)),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 14,
                ),
                child: Row(
                  children: [
                    const Icon(Icons.search),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        '기능 찾기 — 휴강, 위젯, 드라이브, 필터…',
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const UsageReportCard(),
          ListTile(
            leading: const Icon(Icons.explore_outlined),
            title: const Text('기능 안내·빠른 설정'),
            subtitle: const Text('하고 싶은 일을 고르면 설정을 순서대로 열어 줘요'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => page(const AppHelpPage()),
          ),
          const FeatureRecommendation(),
          const SectionHeading('바로 열기', subtitle: '필요할 때 찾는 도구'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ActionChip(
                avatar: const Icon(Icons.fact_check_outlined, size: 18),
                label: const Text('검토함'),
                onPressed: () =>
                    openWorkspaceTool(context, ScheduleView.review),
              ),
              ActionChip(
                avatar: const Icon(Icons.table_chart_outlined, size: 18),
                label: const Text('시간표'),
                onPressed: () =>
                    openWorkspaceTool(context, ScheduleView.timetable),
              ),
              ActionChip(
                avatar: const Icon(Icons.chat_bubble_outline, size: 18),
                label: const Text('AI 채팅'),
                onPressed: () => page(const AiChatPage()),
              ),
              ActionChip(
                avatar: const Icon(Icons.campaign_outlined, size: 18),
                label: const Text('모든 공지'),
                onPressed: () => page(const NoticesPage()),
              ),
              ActionChip(
                avatar: const Icon(Icons.calendar_month_outlined, size: 18),
                label: const Text('캘린더'),
                onPressed: () =>
                    openWorkspaceTool(context, ScheduleView.calendar),
              ),
            ],
          ),
          const SizedBox(height: 24),
          const SectionHeading('설정', subtitle: '연결과 표시를 내 방식대로'),
          _setting(
            context,
            Icons.account_circle_outlined,
            '학교 연결·수집',
            connected ? '포털 연결됨 · 수집 간격 · 재연결 대기' : '포털 계정 연결',
            () => group('학교 연결·수집', [
              ListTile(
                leading: Icon(
                  connected
                      ? Icons.verified_user_outlined
                      : Icons.person_outline,
                ),
                title: Text(connected ? '포털 연결됨' : '포털 연결 필요'),
                subtitle: const Text('계정은 이 기기의 보안 저장소에 보관해요.'),
                onTap: connected
                    ? null
                    : () {
                        Navigator.pop(context);
                        connect();
                      },
              ),
              _setting(
                context,
                Icons.battery_charging_full,
                Platform.isWindows ? 'PC 자동 수집 상태' : '자동 수집·세션 설정',
                '최근 성공 · 수집 간격 · 재연결 대기',
                () => page(const BackgroundStatusPage()),
              ),
              if (!Platform.isWindows)
                _setting(
                  context,
                  Icons.verified_user_outlined,
                  '알림·백그라운드 권한',
                  '허용 상태 확인과 기기 설정',
                  () => page(const PermissionsPage()),
                ),
              if (Platform.isWindows)
                _setting(
                  context,
                  Icons.desktop_windows,
                  'PC 실행 설정',
                  '자동 수집 · 시작 프로그램 · 트레이',
                  () => page(const DesktopSettingsPage()),
                ),
              if (connected)
                _setting(
                  context,
                  Icons.login,
                  '로그인 다시 연결',
                  '현재 계정의 비밀번호를 다시 입력해요. 목록은 유지해요.',
                  () {
                    Navigator.pop(context);
                    connect();
                  },
                ),
              if (connected)
                _setting(
                  context,
                  Icons.logout,
                  '로그아웃',
                  '계정·앱 데이터 삭제 범위를 확인해요.',
                  () {
                    Navigator.pop(context);
                    logout();
                  },
                ),
            ]),
          ),
          ValueListenableBuilder<bool>(
            valueListenable: demoModeNotifier,
            builder: (context, _, _) {
              if (isDemoActive) return const SizedBox.shrink();
              return _setting(
                context,
                Icons.visibility_outlined,
                '체험 모드 보기',
                '예시 데이터로 기능 둘러보기',
                () => onStartDemo?.call(),
              );
            },
          ),
          _setting(
            context,
            Icons.notifications_outlined,
            '알림',
            '마감 · 새 항목 · 수업 전 · 하루 요약',
            () => page(const NotificationSettingsPage()),
          ),
          _setting(
            context,
            Icons.palette_outlined,
            '화면·위젯',
            '테마 · 홈 화면 · 잠금화면',
            () => group('화면·위젯', [
              _setting(
                context,
                Icons.palette_outlined,
                '화면 테마',
                '컬러 1·컬러 2 · 시스템 설정 · 라이트 · 다크',
                () => page(const AppearancePage()),
              ),
              if (Platform.isAndroid)
                _setting(
                  context,
                  Icons.widgets_outlined,
                  '위젯·잠금화면',
                  '크기 · 위치 · 투명도 · 글씨 크기',
                  () => page(const WidgetSettingsPage()),
                ),
              if (Platform.isIOS)
                _setting(
                  context,
                  Icons.widgets_outlined,
                  'iPhone 위젯',
                  '공유 자료와 위젯 연결',
                  () => page(const IosWidgetSettings()),
                ),
              const DiscoverySettings(),
            ]),
          ),
          _setting(
            context,
            Icons.checklist,
            '할 일·시간표',
            '제출 대기 · 마감 지난 항목 · 수업·휴강',
            () => group('할 일·시간표', [
              _setting(
                context,
                Icons.checklist,
                '할 일 표시·정리',
                '제출 대기 표시 · 마감 지난 항목 · 출석 정보',
                () => page(const TaskCleanupSettings()),
              ),
              _setting(
                context,
                Icons.table_chart_outlined,
                '주간 시간표',
                '수업 시간 · 강의실 · 휴강',
                () => page(const TimetablePage()),
              ),
              _setting(
                context,
                Icons.notifications_outlined,
                '수업 전·자정 알림',
                '시간표 기준 알림 시각과 카운트다운',
                () => page(const TimetablePage(initialMode: 2)),
              ),
            ]),
          ),
          _setting(
            context,
            Icons.auto_awesome,
            'AI·캘린더',
            '공지 분석 → 일정 검토 → 캘린더 전송',
            () => group('AI·캘린더', [
              _setting(
                context,
                Icons.auto_awesome_outlined,
                'AI·자동 승인',
                '개인 키 · 공지 분석 · 자동 승인 · 요약',
                () => page(const AiSettingsPage()),
              ),
              _setting(
                context,
                Icons.calendar_month_outlined,
                Platform.isWindows ? '일정 파일 내보내기' : '캘린더 전송',
                '저장 위치와 자동 전송 설정',
                () => page(
                  Platform.isWindows
                      ? const DesktopCalendarPage()
                      : const CalendarSettingsPage(),
                ),
              ),
            ]),
          ),
          // ChatGPT is a separate service from the in-app AI (Gemini);
          // keep its entries apart so the two are not confused.
          _setting(
            context,
            Icons.forum_outlined,
            'AI 도우미 연결 (ChatGPT·Claude)',
            '내 과제·공지를 ChatGPT·Claude에서 조회',
            () => group('AI 도우미 연결 (ChatGPT·Claude)', [
              if (Platform.isAndroid)
                _setting(
                  context,
                  Icons.cloud_upload_outlined,
                  'Drive 자동 연결',
                  '여러 Google 계정 · 선택 자료 자동 갱신',
                  () => page(const DriveConnectionPage()),
                ),
              _setting(
                context,
                Icons.folder_copy_outlined,
                'AI 도우미용 자료 내보내기',
                '내 저장소에 보관 · ChatGPT·Claude 학업 도우미',
                () => page(const AcademicExportPage()),
              ),
            ]),
          ),
          _setting(
            context,
            Icons.history,
            '기록·지원',
            '변경 이력 · 업데이트',
            () => group('기록·지원', [
              _setting(
                context,
                Icons.track_changes,
                '변경 이력',
                '과제와 콘텐츠의 변경 사항',
                () => page(const ChangesPage()),
              ),
              _setting(
                context,
                Icons.system_update,
                '앱 업데이트',
                '현재 $installedAppVersion ($installedAppBuild) · ${channelLabel(appReleaseChannel)}',
                () => page(
                  Platform.isWindows
                      ? const DesktopUpdatePage()
                      : const UpdatePage(),
                ),
              ),
              _setting(
                context,
                Icons.history,
                '업데이트 내역',
                '버전별 변경 사항 · 정식/개발 버전',
                () => page(const ReleaseHistoryPage()),
              ),
            ]),
          ),
          ValueListenableBuilder<bool>(
            valueListenable: developerModeNotifier,
            builder: (context, devMode, _) {
              if (!devMode) return const SizedBox.shrink();
              return _setting(
                context,
                Icons.developer_mode,
                '개발자 옵션',
                '고급 진단·실험 기능',
                () => group('개발자 옵션', [
                  _setting(
                    context,
                    Icons.power_settings_new,
                    '개발자 모드 끄기',
                    '개발자 옵션을 숨겨요',
                    () async {
                      await setDeveloperMode(false);
                      if (context.mounted) {
                        Navigator.pop(context);
                      }
                    },
                  ),
                  _setting(
                    context,
                    Icons.receipt_long,
                    '활동 로그',
                    '수집·알림·AI·캘린더·업데이트',
                    () => page(const HistoryPage(notificationsOnly: false)),
                  ),
                  _setting(
                    context,
                    Icons.notification_add_outlined,
                    '알림 표시 테스트',
                    '기기에 테스트 알림 요청',
                    test,
                  ),
                  if (Platform.isAndroid)
                    _setting(
                      context,
                      Icons.science_outlined,
                      '세션 유지 시간 탐색',
                      '학교 세션이 얼마나 유지되는지 측정하는 실험 기능',
                      () => page(const SessionExplorationPage()),
                    ),
                ]),
              );
            },
          ),
          const SizedBox(height: 24),
          const _VersionFooter(),
        ],
      ),
    );

    if (embedded) return content;

    return Scaffold(
      appBar: AppBar(title: const Text('더보기')),
      body: content,
    );
  }

  Widget _setting(
    BuildContext c,
    IconData icon,
    String title,
    String subtitle,
    VoidCallback action,
  ) => Card(
    clipBehavior: Clip.antiAlias,
    child: ListTile(
      contentPadding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
      leading: Container(
        padding: const EdgeInsets.all(9),
        decoration: BoxDecoration(
          color: Theme.of(c).colorScheme.primaryContainer,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(icon, color: Theme.of(c).colorScheme.onPrimaryContainer),
      ),
      title: Text(
        title,
        style: Theme.of(
          c,
        ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
      ),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.chevron_right),
      onTap: action,
    ),
  );
}

class _VersionFooter extends StatefulWidget {
  const _VersionFooter();

  @override
  State<_VersionFooter> createState() => _VersionFooterState();
}

class _VersionFooterState extends State<_VersionFooter> {
  int _tapCount = 0;
  DateTime? _lastTap;

  void _handleTap() async {
    if (developerModeNotifier.value) {
      final messenger = ScaffoldMessenger.of(context);
      messenger.clearSnackBars();
      messenger.showSnackBar(
        const SnackBar(
          content: Text('이미 개발자 모드예요'),
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    final now = DateTime.now();
    if (_lastTap == null ||
        now.difference(_lastTap!) > const Duration(seconds: 2)) {
      _tapCount = 1;
    } else {
      _tapCount++;
    }
    _lastTap = now;

    if (_tapCount >= 3 && _tapCount <= 6) {
      final remaining = 7 - _tapCount;
      final messenger = ScaffoldMessenger.of(context);
      messenger.clearSnackBars();
      messenger.showSnackBar(
        SnackBar(
          content: Text('개발자 모드까지 $remaining번 남았어요'),
          duration: const Duration(seconds: 2),
        ),
      );
    } else if (_tapCount >= 7) {
      _tapCount = 0;
      await setDeveloperMode(true);
      if (mounted) {
        final messenger = ScaffoldMessenger.of(context);
        messenger.clearSnackBars();
        messenger.showSnackBar(
          const SnackBar(
            content: Text('개발자 모드를 켰어요'),
            duration: Duration(seconds: 2),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: _handleTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Text(
          '캠퍼스레이더 $installedAppVersion · ${channelLabel(appReleaseChannel)}',
          style: Theme.of(context).textTheme.labelSmall,
        ),
      ),
    );
  }
}

import 'dart:convert';
import 'package:flutter/material.dart';
import 'campus.dart';
import 'services.dart';
import 'expansion_pages.dart';
import 'timetable_model.dart';

class TimetablePage extends StatefulWidget {
  const TimetablePage({super.key});
  @override
  State<TimetablePage> createState() => _TimetableState();
}

class _TimetableState extends State<TimetablePage> {
  List<ClassSlot> entries = [], candidates = [];
  List<Map<String, dynamic>> courses = [];
  bool loading = true, enabled = false, midnight = false, exactAllowed = true;
  int lead = 30;
  String? message;
  DateTime until = DateTime(
    DateTime.now().year,
    DateTime.now().month <= 6 ? 6 : 12,
    DateTime.now().month <= 6 ? 30 : 31,
  );
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    Store? s;
    try {
      s = await Store.open();
      final list = await readCourses(s);
      final saved = decodeSlots(await s.meta('timetableEntries'));
      final proposed = <String, ClassSlot>{};
      for (final c in list) {
        final k = courseKey(c),
            raw = await s.meta('coursePlan:${courseKey(c)}');
        if (raw == null) continue;
        final plan = jsonDecode(raw);
        final text = plan['linkedText'] as String?;
        if (text == null) continue;
        for (final row in parsePlanSlots(text, k, '${c['course_nm']}')) {
          proposed[row.id] = row;
        }
      }
      final p =
          await bridge.invokeMapMethod<String, dynamic>('timetableSettings') ??
          {};
      if (mounted) {
        setState(() {
          courses = list;
          entries = saved;
          candidates = proposed.values.toList();
          exactAllowed = p['exactAllowed'] == true;
          enabled = p['enabled'] == true;
          midnight = p['midnight'] == true;
          lead = p['lead'] ?? 30;
          until = DateTime.tryParse(p['until'] ?? '') ?? until;
          loading = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          loading = false;
          message = '시간표를 읽지 못했습니다. 다시 확인해 주세요.';
        });
      }
    } finally {
      await s?.db.close();
    }
  }

  Future<void> save() async {
    final s = await Store.open();
    try {
      await s.setMeta(
        'timetableEntries',
        jsonEncode(entries.map((e) => e.toJson()).toList()),
      );
      await s.log('system', '시간표 저장', '확인한 수업 ${entries.length}개 · 강의계획서 기준');
    } finally {
      await s.db.close();
    }
    await bridge.invokeMethod('setTimetableSettings', {
      'enabled': enabled,
      'midnight': midnight,
      'lead': lead,
      'until':
          '${until.year}-${until.month.toString().padLeft(2, '0')}-${until.day.toString().padLeft(2, '0')}',
    });
    if (mounted) setState(() => message = '저장했습니다. 수업 시간·휴강·보강은 원문과 함께 확인하세요.');
  }

  Future<void> importPlans() async {
    final selected = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            const ListTile(title: Text('시간표를 가져올 과목 선택')),
            ...courses.map(
              (c) => ListTile(
                title: Text(courseLabel('${c['course_nm']}')),
                subtitle: const Text('강의계획서 탭에서 불러온 뒤 돌아오세요'),
                onTap: () => Navigator.pop(ctx, c),
              ),
            ),
          ],
        ),
      ),
    );
    if (selected == null || !mounted) return;
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => CoursePage(course: selected)),
    );
    await load();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('시간표·수업 알림'),
      actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))],
    ),
    body: loading
        ? const Center(child: CircularProgressIndicator())
        : ListView(
            padding: const EdgeInsets.all(20),
            children: [
              const Text(
                '강의계획서에서 시간표 가져오기',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const Text(
                '실제 강의계획서를 불러오면 요일과 시각을 읽습니다. 원문을 확인하고 저장한 수업만 알림에 사용합니다. 교시 번호만 있는 경우는 시각을 추정하지 않습니다.',
              ),
              OutlinedButton.icon(
                onPressed: importPlans,
                icon: const Icon(Icons.download),
                label: const Text('과목의 강의계획서 불러오기'),
              ),
              if (candidates.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(12),
                  child: Text('추출된 시간이 없습니다. 강의계획서를 먼저 불러오세요.'),
                ),
              ...candidates.map(
                (e) => CheckboxListTile(
                  title: Text(
                    '${courseLabel(e.course)} · ${weekNames[e.weekday - 1]} ${slotTime(e.start)}–${slotTime(e.end)}',
                  ),
                  subtitle: Text('원문: ${e.source}'),
                  value: entries.any((x) => x.id == e.id),
                  onChanged: (v) => setState(() {
                    entries.removeWhere((x) => x.id == e.id);
                    if (v == true) entries.add(e);
                  }),
                ),
              ),
              if (!exactAllowed)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          '정확한 알림 권한이 꺼져 있습니다. 수업 전·자정 알림이 늦어질 수 있습니다.',
                        ),
                        TextButton(
                          onPressed: () async {
                            await bridge.invokeMethod('openExactAlarmSettings');
                          },
                          child: const Text('정확한 알림 설정 열기'),
                        ),
                        TextButton(
                          onPressed: load,
                          child: const Text('권한 상태 다시 확인'),
                        ),
                      ],
                    ),
                  ),
                ),
              const Divider(),
              const Text(
                '저장한 시간표',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              ...entries.map(
                (e) => ListTile(
                  title: Text(courseLabel(e.course)),
                  subtitle: Text(
                    '${weekNames[e.weekday - 1]} ${slotTime(e.start)}–${slotTime(e.end)} ${e.room}',
                  ),
                  trailing: IconButton(
                    tooltip: '시간표에서 제거',
                    icon: const Icon(Icons.remove_circle_outline),
                    onPressed: () => setState(
                      () => entries.removeWhere((x) => x.id == e.id),
                    ),
                  ),
                ),
              ),
              SwitchListTile(
                title: const Text('수업 시작 전 알림'),
                subtitle: const Text('저장한 매주 수업 시간 기준 · 휴강·보강은 자동 반영하지 않습니다.'),
                value: enabled,
                onChanged: (v) => setState(() => enabled = v),
              ),
              DropdownButtonFormField<int>(
                initialValue: lead,
                decoration: const InputDecoration(labelText: '알림 시점'),
                items: [15, 30, 60]
                    .map(
                      (n) =>
                          DropdownMenuItem(value: n, child: Text('수업 $n분 전')),
                    )
                    .toList(),
                onChanged: (v) => setState(() => lead = v ?? 30),
              ),
              ListTile(
                title: const Text('시간표 알림 종료일'),
                subtitle: Text(
                  '${until.year}/${until.month}/${until.day} · 방학 중 반복 방지',
                ),
                trailing: const Icon(Icons.calendar_today),
                onTap: () async {
                  final d = await showDatePicker(
                    context: context,
                    initialDate: until,
                    firstDate: DateTime.now().subtract(const Duration(days: 1)),
                    lastDate: DateTime.now().add(const Duration(days: 730)),
                  );
                  if (d != null) setState(() => until = d);
                },
              ),
              SwitchListTile(
                title: const Text('자정에 오늘 수업·과제 알림'),
                subtitle: const Text(
                  '한국 시간 00:00에 막 시작한 날의 수업과 미완료 마감 항목을 알려줍니다. 마지막 수집 기준이며 절전 시 늦어질 수 있습니다.',
                ),
                value: midnight,
                onChanged: (v) => setState(() => midnight = v),
              ),
              if (message != null) Text(message!),
              FilledButton(
                onPressed: () async {
                  try {
                    if (enabled || midnight) {
                      await requestNotificationPermission();
                    }
                    await save();
                  } catch (_) {
                    if (mounted) {
                      setState(() => message = '저장하지 못했습니다. 알림 설정을 확인해 주세요.');
                    }
                  }
                },
                child: const Text('확인한 시간표·알림 저장'),
              ),
              TextButton(
                onPressed: () async {
                  await bridge.invokeMethod('testMidnightSummary');
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('자정 요약 형식으로 알림을 요청했습니다.')),
                    );
                  }
                },
                child: const Text('자정 요약 알림 테스트'),
              ),
            ],
          ),
  );
}

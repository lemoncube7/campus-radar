import 'campus_session.dart';
import 'cancellation_repository.dart';
import 'feature_discovery.dart';
import 'timetable_cancellations_page.dart';
import 'timetable_exceptions.dart';
import 'dart:io';
import 'syllabus_loader.dart';
import 'navigation_contract.dart';
import 'native_contract.dart';
import 'course_catalog.dart';
import 'app_storage.dart';
import 'native_bridge.dart';
import 'app_credentials.dart';
import 'notification_gateway.dart';
import 'course_labels.dart';
import 'session_scope.dart';
import 'plan_fetch.dart';
import 'dart:convert';
import 'ai_automation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'campus.dart';
import 'timetable_model.dart';
import 'timetable_grid.dart';
import 'ui_refresh.dart';

class TimetablePage extends StatefulWidget {
  final int initialMode;
  const TimetablePage({super.key, this.initialMode = 0});
  @override
  State<TimetablePage> createState() => _TimetableState();
}

class _TimetableState extends State<TimetablePage> {
  List<ClassSlot> entries = [], candidates = [];
  List<ClassCancellation> cancellations = [];
  List<Map<String, dynamic>> courses = [];
  bool loading = true, enabled = false, midnight = false, exactAllowed = true;
  int lead = 30, countdownAfter = 0;
  String? message;
  bool building = false;
  String progress = '';
  int mode = 0;

  List<ClassSlot> get weekEntries => classesThisWeek(
    entries,
    cancellations,
    DateTime.now().toUtc().add(const Duration(hours: 9)),
  );

  Future<void> buildTimetable() async {
    if (building) return;
    setState(() {
      building = true;
      message = null;
    });
    final client = CampusClient();
    Store? store;
    final failures = <String>[];
    final missing = <String>[];
    try {
      store = await Store.open();
      final scope = await SessionScope.capture(store);
      final account = await credentials.read(key: 'id');
      final password = await credentials.read(key: 'pw');
      if (account == null || password == null) {
        throw CampusException('포털을 먼저 연결해 주세요.');
      }
      final list = await readCourses(store);
      if (list.isEmpty) throw CampusException('먼저 동기화하여 수강 과목을 가져와 주세요.');
      await client.connectSchool(account, password);
      final currentKeys = list.map(courseKey).toSet();
      var merged = entries
          .where((row) => currentKeys.contains(row.courseKey))
          .toList();
      Future<dynamic> readPlan(Map<String, dynamic> course) async {
        for (var attempt = 0; attempt < 2; attempt++) {
          try {
            final response = await client.api(
              '/course/addSessionCourseInfo',
              course,
            );
            final raw = response['data'];
            final session = Map<String, dynamic>.from(
              raw is String ? jsonDecode(raw) : raw,
            );
            return await client.api('/coursePlan/getInfo', session);
          } on CampusException catch (e) {
            if (attempt == 1 || !e.message.contains('로그인 만료')) rethrow;
            await client.connectSchool(account, password);
          }
        }
        throw CampusException('강의계획서 요청 실패');
      }

      for (var index = 0; index < list.length; index++) {
        if (!mounted) return;
        final course = list[index];
        final name = '${course['course_nm']}';
        final key = courseKey(course);
        setState(
          () => progress = '${index + 1}/${list.length} · ${courseLabel(name)}',
        );
        if (await credentials.read(key: 'id') != account) {
          throw CampusException('계정이 변경되어 중지했습니다.');
        }
        try {
          final data = await retryPlanConnection(() => readPlan(course));
          final link = data is Map && data['link_course_info'] is Map
              ? data['link_course_info']['link_url']
              : null;
          if (link is! String || link.isEmpty) {
            throw CampusException('실제 계획서 주소 없음');
          }
          final text = await loadLinkedSyllabus(link, name);
          if (await credentials.read(key: 'id') != account) {
            throw CampusException('계정 변경');
          }
          await scope.verify();
          await store.setMeta(
            'coursePlan:$key',
            jsonEncode({
              'linkedText': text,
              'linkedUrl': link,
              'fetchedAt': DateTime.now().toUtc().toIso8601String(),
              'data': data,
            }),
          );
          final slots = parsePlanSlots(text, key, name);
          merged = replaceCourseSlots(merged, key, slots);
          if (slots.isEmpty) missing.add(courseLabel(name));
        } on PlatformException catch (e) {
          if (e.code == 'syllabus_cancelled') {
            throw CampusException('시간표 만들기를 취소했습니다. 기존 시간표는 유지합니다.');
          }
          failures.add('${courseLabel(name)}: ${planFailure(e)}');
          await store.log('sync', '강의계획서 불러오기 실패', '시간표 생성 · ${e.code}');
        } catch (e) {
          failures.add('${courseLabel(name)}: ${planFailure(e)}');
          await store.log('sync', '강의계획서 불러오기 실패', '시간표 생성 · ${e.runtimeType}');
        }
      }
      if (await credentials.read(key: 'id') != account) {
        throw CampusException('계정이 변경되어 중지했습니다.');
      }
      if (!mounted) return;
      await scope.verify();
      setState(() => entries = merged);
      await save();
      await load();
      await store.log(
        'sync',
        '전체 강의계획서 시간표 생성',
        '${list.length}과목 · 수업 ${merged.length}개 · 실패 ${failures.length}개',
      );
      if (mounted) {
        setState(
          () => message =
              '시간표 저장 완료 · 수업 ${merged.length}개${missing.isEmpty ? '' : '\n시간 미확인: ${missing.join(', ')}'}${failures.isEmpty ? '' : '\n불러오기 실패(기존 유지): ${failures.join(', ')}'}',
        );
      }
    } catch (e) {
      if (mounted) {
        setState(
          () => message = e is CampusException
              ? e.message
              : '시간표를 만들지 못했습니다. 기존 시간표는 유지합니다.',
        );
      }
    } finally {
      client.close();
      await store?.db.close();
      if (mounted) {
        setState(() {
          building = false;
          progress = '';
        });
      }
    }
  }

  DateTime until = DateTime(
    DateTime.now().year,
    DateTime.now().month <= 6 ? 6 : 12,
    DateTime.now().month <= 6 ? 30 : 31,
  );
  @override
  void initState() {
    super.initState();
    FeatureDiscovery.record(DiscoverFeature.timetable);
    mode = widget.initialMode;
    load();
  }

  Future<void> load() async {
    Store? s;
    try {
      s = await Store.open();
      final list = await readCourses(s);
      final saved = decodeSlots(await s.meta('timetableEntries'));
      final cancelled = await readClassCancellations(s);
      final proposed = <String, ClassSlot>{};
      for (final c in list) {
        final k = courseKey(c),
            raw = await s.meta('coursePlan:${courseKey(c)}');
        if (raw == null) continue;
        final plan = jsonDecode(raw);
        final text = plan['linkedText'] as String?;
        if (text == null) continue;
        for (final row in parsePlanSlots(text, k, '${c['course_nm']}')) {
          proposed[row.id] = row;
        }
      }
      final p =
          await bridge.invokeNativeMap<String, dynamic>(
            NativeMethod.timetableSettings,
          ) ??
          {};
      if (mounted) {
        setState(() {
          courses = list;
          entries = saved;
          cancellations = cancelled;
          candidates = proposed.values.toList();
          exactAllowed = p['exactAllowed'] == true;
          enabled = p['enabled'] == true;
          midnight = p['midnight'] == true;
          lead = p['lead'] ?? 30;
          countdownAfter = p['countdownAfter'] ?? 0;
          until = DateTime.tryParse(p['until'] ?? '') ?? until;
          loading = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          loading = false;
          message = '시간표를 읽지 못했습니다. 다시 확인해 주세요.';
        });
      }
    } finally {
      await s?.db.close();
    }
  }

  Future<void> save() async {
    final s = await Store.open();
    try {
      await s.setMeta(
        'timetableEntries',
        jsonEncode(entries.map((e) => e.toJson()).toList()),
      );
      await s.setMeta(
        'timetableSavedAt',
        DateTime.now().toUtc().toIso8601String(),
      );
      await s.log('system', '시간표 저장', '확인한 수업 ${entries.length}개 · 강의계획서 기준');
      if (await s.meta('aiAuto') == 'yes') {
        try {
          await enqueueNotices(s);
          await scheduleAiWork();
        } catch (_) {
          await s.log('ai', '시간표 변경 후 AI 재분석 대기', '다음 수집 때 변경된 시간표를 다시 확인합니다.');
        }
      }
    } finally {
      await s.db.close();
    }
    await bridge.invokeNative(NativeMethod.refreshWidget);
    await bridge.invokeNative(NativeMethod.setTimetableSettings, {
      'enabled': enabled,
      'midnight': midnight,
      'lead': lead,
      'countdownAfter': countdownAfter,
      'until':
          '${until.year}-${until.month.toString().padLeft(2, '0')}-${until.day.toString().padLeft(2, '0')}',
    });
    if (mounted) setState(() => message = '저장했습니다. 수업 시간·휴강·보강은 원문과 함께 확인하세요.');
  }

  Future<void> importPlans() async {
    final selected = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            const ListTile(title: Text('시간표를 가져올 과목 선택')),
            ...courses.map(
              (c) => ListTile(
                title: Text(courseLabel('${c['course_nm']}')),
                subtitle: const Text('강의계획서 탭에서 불러온 뒤 돌아오세요'),
                onTap: () => Navigator.pop(ctx, c),
              ),
            ),
          ],
        ),
      ),
    );
    if (selected == null || !mounted) return;
    await navigateTo(context, CourseDestination(course: selected));
    await load();
  }

  Future<void> finishEditing() async {
    try {
      if (enabled || midnight) await requestNotificationPermission();
      await save();
      if (mounted) setState(() => mode = 0);
    } catch (_) {
      if (mounted) setState(() => message = '저장하지 못했습니다. 다시 시도해 주세요.');
    }
  }

  Future<void> backToGrid() async {
    await load();
    if (mounted) setState(() => mode = 0);
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: mode == 0 && !building,
    onPopInvokedWithResult: (popped, result) {
      if (!popped && !building) backToGrid();
    },
    child: Scaffold(
      appBar: AppBar(
        title: Text(
          mode == 1
              ? '시간표 편집'
              : mode == 2
              ? '수업·자정 알림'
              : '시간표',
        ),
        leading: mode == 0
            ? null
            : IconButton(
                tooltip: '시간표로 돌아가기',
                onPressed: backToGrid,
                icon: const Icon(Icons.arrow_back),
              ),
        actions: [
          if (mode == 0) ...[
            IconButton(
              tooltip: '날짜별 휴강 관리',
              icon: const Icon(Icons.event_busy),
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const TimetableCancellationsPage(),
                  ),
                );
                await load();
              },
            ),
            IconButton(
              tooltip: '시간표 편집',
              onPressed: building ? null : () => setState(() => mode = 1),
              icon: const Icon(Icons.edit_outlined),
            ),
            IconButton(
              tooltip: '수업·자정 알림',
              onPressed: building ? null : () => setState(() => mode = 2),
              icon: const Icon(Icons.notifications_outlined),
            ),
            PopupMenuButton<String>(
              enabled: !building,
              onSelected: (v) {
                if (v == 'build') {
                  buildTimetable();
                } else {
                  importPlans();
                }
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'build', child: Text('강의계획서에서 다시 만들기')),
                PopupMenuItem(value: 'plans', child: Text('과목별 강의계획서 확인')),
              ],
            ),
          ],
        ],
      ),
      bottomNavigationBar: mode == 0 || loading || building
          ? null
          : PinnedAction(
              child: FilledButton(
                onPressed: finishEditing,
                child: Text(mode == 1 ? '시간표 저장' : '알림 설정 저장'),
              ),
            ),
      body: loading || building
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const CircularProgressIndicator(),
                  const SizedBox(height: 16),
                  Text(building ? '강의계획서 불러오는 중\n$progress' : '불러오는 중'),
                ],
              ),
            )
          : ListView(
              key: ValueKey('timetable-mode-$mode'),
              padding: const EdgeInsets.all(20),
              children: [
                if (message != null)
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Text(message!),
                    ),
                  ),
                if (mode == 0) ...[
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          '나의 주간 시간표',
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                      ),
                      Text('${weekEntries.length}개 수업'),
                    ],
                  ),
                  if (entries.isEmpty)
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          children: [
                            const Icon(Icons.calendar_month_outlined, size: 44),
                            const SizedBox(height: 16),
                            const Text('강의계획서로 시간표를 만들어 보세요.'),
                            const SizedBox(height: 8),
                            const Text(
                              '모든 수강 과목의 실제 계획서를 순서대로 가져옵니다. 시간 미확인·실패 과목은 결과에 알려드려요.',
                            ),
                            const SizedBox(height: 20),
                            FilledButton.icon(
                              onPressed: buildTimetable,
                              icon: const Icon(Icons.auto_awesome_outlined),
                              label: const Text('시간표 만들기'),
                            ),
                          ],
                        ),
                      ),
                    )
                  else
                    TimetableGrid(entries: weekEntries),
                  if (Platform.isAndroid)
                    OutlinedButton.icon(
                      onPressed: () async {
                        final added = await bridge.invokeNative<bool>(
                          NativeMethod.pinTimetableWidget,
                        );
                        if (mounted && added != true) {
                          setState(
                            () => message =
                                '홈 화면을 길게 누른 뒤 위젯 → 캠퍼스레이더 시간표를 추가하세요.',
                          );
                        }
                      },
                      icon: const Icon(Icons.widgets_outlined),
                      label: const Text('홈 화면에 시간표 추가'),
                    ),
                  const SizedBox(height: 12),
                  const Text('이번 주 시간표 · 적용한 날짜별 휴강 제외 · 보강은 원문 확인'),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.notifications_outlined),
                    title: const Text('수업·자정 알림'),
                    subtitle: Text(
                      '수업 전 ${enabled ? '$lead분' : '알림 꺼짐'} · 자정 요약 ${midnight ? '켜짐' : '꺼짐'}',
                    ),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => setState(() => mode = 2),
                  ),
                ],
                if (mode == 1) ...[
                  const Text('표에 표시할 수업을 선택하세요. 저장 전에는 위젯·알림에 반영되지 않습니다.'),
                  TextButton.icon(
                    onPressed: importPlans,
                    icon: const Icon(Icons.description_outlined),
                    label: const Text('과목별 원문 확인'),
                  ),
                  if (entries.isEmpty && candidates.isEmpty)
                    const Padding(
                      padding: EdgeInsets.all(24),
                      child: Text('추출된 시간이 없습니다. 시간표 화면에서 시간표 만들기를 실행해 주세요.'),
                    ),
                  ...{
                    for (final e in [...entries, ...candidates]) e.id: e,
                  }.values.map(
                    (e) => CheckboxListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(courseLabel(e.course)),
                      subtitle: Text(
                        '${weekNames[e.weekday - 1]} ${slotTime(e.start)}–${slotTime(e.end)} ${e.room}\n원문: ${e.source}',
                      ),
                      value: entries.any((x) => x.id == e.id),
                      onChanged: (v) => setState(() {
                        entries.removeWhere((x) => x.id == e.id);
                        if (v == true) entries.add(e);
                      }),
                    ),
                  ),
                ],
                if (mode == 2) ...[
                  if (Platform.isWindows)
                    const Padding(
                      padding: EdgeInsets.only(bottom: 16),
                      child: Text(
                        'PC에서 앱이 실행 중일 때만 알립니다. 절전·종료 중에는 알림이 오지 않으며, 실행 중 약 1분마다 확인합니다.',
                      ),
                    ),
                  if (Platform.isIOS)
                    const Padding(
                      padding: EdgeInsets.only(bottom: 16),
                      child: Text(
                        'iPhone은 가까운 수업·자정 알림을 최대 24개 예약합니다. 앱 실행·수집·시간표 변경 시 갱신하며, 백그라운드 실행 시각은 iOS가 결정합니다.',
                      ),
                    ),
                  if (Platform.isAndroid && !exactAllowed)
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              '정확한 알림 권한이 꺼져 있습니다. 수업 전·자정 알림이 늦어질 수 있습니다.',
                            ),
                            TextButton(
                              onPressed: () async {
                                await bridge.invokeNative(
                                  NativeMethod.openExactAlarmSettings,
                                );
                              },
                              child: const Text('정확한 알림 설정 열기'),
                            ),
                            TextButton(
                              onPressed: load,
                              child: const Text('권한 상태 다시 확인'),
                            ),
                          ],
                        ),
                      ),
                    ),
                  SwitchListTile(
                    title: const Text('수업 시작 전 알림'),
                    subtitle: const Text('저장한 시간표 기준 · 확인해서 반영한 휴강은 제외합니다.'),
                    value: enabled,
                    onChanged: (v) => setState(() => enabled = v),
                  ),
                  DropdownButtonFormField<int>(
                    initialValue: lead,
                    decoration: const InputDecoration(labelText: '알림 시점'),
                    items: [15, 30, 60]
                        .map(
                          (n) => DropdownMenuItem(
                            value: n,
                            child: Text('수업 $n분 전'),
                          ),
                        )
                        .toList(),
                    onChanged: (v) => setState(() => lead = v ?? 30),
                  ),
                  if (Platform.isAndroid) ...[
                    const SizedBox(height: 16),
                    Text('수업 시작 후 카운트다운 유지: $countdownAfter분'),
                    const Text('0분이면 시작할 때 종료합니다. 늘리면 시작 후에도 -분·초로 표시합니다.'),
                    Slider(
                      value: countdownAfter.toDouble(),
                      min: 0,
                      max: 120,
                      divisions: 120,
                      label: '$countdownAfter분',
                      onChanged: (v) =>
                          setState(() => countdownAfter = v.round()),
                    ),
                  ],
                  ListTile(
                    title: const Text('시간표 알림 종료일'),
                    subtitle: Text(
                      '${until.year}/${until.month}/${until.day} · 방학 중 반복 방지',
                    ),
                    trailing: const Icon(Icons.calendar_today),
                    onTap: () async {
                      final d = await showDatePicker(
                        context: context,
                        initialDate: until,
                        firstDate: DateTime(2000),
                        lastDate: DateTime.now().add(const Duration(days: 730)),
                      );
                      if (d != null) setState(() => until = d);
                    },
                  ),
                  SwitchListTile(
                    title: const Text('자정에 오늘 수업·과제 알림'),
                    subtitle: const Text(
                      '한국 시간 00:00에 막 시작한 날의 수업과 미완료 마감 항목을 알려줍니다. 마지막 수집 기준이며 절전 시 늦어질 수 있습니다.',
                    ),
                    value: midnight,
                    onChanged: (v) => setState(() => midnight = v),
                  ),

                  ExpansionTile(
                    title: const Text('알림 테스트'),
                    children: [
                      TextButton(
                        onPressed: () async {
                          await bridge.invokeNative(
                            NativeMethod.testMidnightSummary,
                          );
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('자정 요약 형식으로 알림을 요청했습니다.'),
                              ),
                            );
                          }
                        },
                        child: const Text('자정 요약 알림 테스트'),
                      ),
                    ],
                  ),
                ],
              ],
            ),
    ),
  );
}

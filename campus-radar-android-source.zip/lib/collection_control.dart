import 'package:shared_preferences/shared_preferences.dart';

const automaticSchoolConnectionKey = 'automaticSchoolConnection';
const schoolCollectionIntervals = <int>[15, 30, 60, 120];
Future<int> schoolCollectionMinutes() async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  final minutes = prefs.getInt('schoolCollectionMinutes');
  return schoolCollectionIntervals.contains(minutes) ? minutes! : 60;
}

Future<void> saveSchoolCollectionMinutes(int minutes) async {
  if (!schoolCollectionIntervals.contains(minutes)) {
    throw ArgumentError.value(minutes);
  }
  final prefs = await SharedPreferences.getInstance();
  await prefs.setInt('schoolCollectionMinutes', minutes);
}

Future<bool> automaticSchoolConnectionEnabled() async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  return (prefs.getBool(automaticSchoolConnectionKey) ?? true) &&
      !(prefs.getBool('schoolLifetimeProbeEnabled') ?? false);
}

/// Keep the original setting intact while the exclusive test masks auto sync.
Future<bool> automaticSchoolConnectionPreference() async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  return prefs.getBool(automaticSchoolConnectionKey) ?? true;
}

Future<void> saveAutomaticSchoolConnection(bool enabled) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setBool(automaticSchoolConnectionKey, enabled);
}

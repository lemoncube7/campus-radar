import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/courses/course_colors.dart';
import 'package:campus_radar/courses/materials_page.dart';
import 'package:campus_radar/campus/learning_resources.dart';
import 'package:campus_radar/core/adaptive_content.dart';
import 'package:campus_radar/core/demo_state.dart';
import 'package:campus_radar/campus/syllabus_reader.dart';
import 'package:campus_radar/tasks/task_display_preferences.dart';
import 'package:campus_radar/tasks/task_categories.dart';
import 'package:campus_radar/campus/campus_session.dart';
import 'package:campus_radar/campus/syllabus_loader.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/ai/ai_chat_page.dart';
import 'package:campus_radar/tasks/task_presentation.dart';
import 'package:campus_radar/courses/course_catalog.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/app_credentials.dart';
import 'package:campus_radar/courses/course_aliases.dart';
import 'package:campus_radar/courses/course_labels.dart';
import 'package:campus_radar/campus/campus_models.dart';
import 'package:campus_radar/core/session_scope.dart';
import 'package:campus_radar/campus/plan_fetch.dart';
import 'package:flutter/services.dart';
import 'package:campus_radar/schedule/timetable_model.dart';
import 'package:campus_radar/schedule/cancellation_repository.dart';
import 'package:campus_radar/schedule/today_class_model.dart';
import 'package:campus_radar/core/ui_refresh.dart';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:campus_radar/campus/campus.dart';
import 'package:campus_radar/campus/services.dart';

class CoursePage extends StatefulWidget {
  final Map<String, dynamic> course;
  const CoursePage({super.key, required this.course});
  @override
  State<CoursePage> createState() => _CoursePageState();
}

class _CoursePageState extends State<CoursePage>
    with SingleTickerProviderStateMixin {
  late final TabController courseTabs;
  List<CampusItem> items = [];
  List<CampusNotice> notices = [];
  Set<String> excluded = {}, notTasks = {};
  bool showNotTasks = Platform.isWindows;
  bool loading = true, planBusy = false, showCompleted = Platform.isWindows;
  String courseTaskType = '', taskSortMode = 'due';
  String? error, planError;
  Map<String, dynamic>? plan;
  String get name => '${widget.course['course_nm']}';
  String get key => courseKey(widget.course);
  @override
  void initState() {
    super.initState();
    courseTabs = TabController(length: 4, vsync: this)
      ..addListener(() {
        if (mounted) setState(() {});
      });
    unawaited(
      loadCourseColors()
          .then((_) {
            if (mounted) setState(() {});
          })
          .catchError((_) {}),
    );
    unawaited(load());
  }

  @override
  void dispose() {
    courseTabs.dispose();
    super.dispose();
  }

  String? nextClass;

  Future<void> load() async {
    Store? s;
    try {
      s = await Store.open();
      final all = await s.items();
      final ns = await s.notices();
      final ex = await s.excluded(includeNotTasks: false);
      final nonTasks = await s.notTasks();
      final cache = await s.meta(MetaKey.coursePlan(key));
      final next = nextCourseClassLabel(
        decodeSlots(await s.meta(MetaKey.timetableEntries)),
        await readClassCancellations(s),
        key,
        DateTime.now().toUtc().add(const Duration(hours: 9)),
      );
      if (mounted) {
        setState(() {
          nextClass = next;
          items = all
              .where(
                (i) =>
                    courseKey(i.context) == key &&
                    (i.availableAt(DateTime.now().toUtc()) ||
                        showWaitingAssignments.value &&
                            waitingAssignment(i, DateTime.now().toUtc())),
              )
              .toList();
          notices = ns.where((n) => courseKey(n.context) == key).toList()
            ..sort((a, b) => (b.published ?? DateTime.utc(2000)).compareTo(a.published ?? DateTime.utc(2000)));
          excluded = ex;
          notTasks = nonTasks;
          plan = cache == null
              ? null
              : Map<String, dynamic>.from(jsonDecode(cache));
          loading = false;
        });
      }
      final prefs = await SharedPreferences.getInstance();
      final prefNotTasks = prefs.getBool('courseShowNotTasks');
      final prefCompleted = prefs.getBool('courseShowCompleted');
      final prefSortMode = prefs.getString('courseTaskSortMode');
      if (mounted) {
        setState(() {
          if (prefNotTasks != null) showNotTasks = prefNotTasks;
          if (prefCompleted != null) showCompleted = prefCompleted;
          if (prefSortMode != null) taskSortMode = prefSortMode;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          error = '과목 정보를 읽지 못했어요.';
          loading = false;
        });
      }
    } finally {
      await s?.db.close();
    }
  }

  Future<void> chooseColor() async {
    final selected = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(
          '과목 색상 · ${courseColorOverrides.containsKey(key) ? '사용자 지정' : '자동'}',
        ),
        content: Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            for (final color in [
              ...courseAccentColors,
              const Color(0xffb52b44),
              const Color(0xff7a792c),
              const Color(0xff64748b),
              const Color(0xffb9811c),
              const Color(0xff267aaf),
              const Color(0xff7353a6),
            ])
              Semantics(
                label: '색상 ${color.toARGB32().toRadixString(16)}',
                selected: courseAccent(key) == color,
                button: true,
                child: InkWell(
                  onTap: () => Navigator.pop(ctx, color.toARGB32()),
                  child: Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: color,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Theme.of(context).colorScheme.outline,
                        width: 2,
                      ),
                    ),
                    child: courseAccent(key) == color
                        ? Icon(
                            Icons.check,
                            color: color.computeLuminance() > 0.5
                                ? Colors.black
                                : Colors.white,
                          )
                        : null,
                  ),
                ),
              ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, 0),
            child: const Text('자동 색상으로 복구'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('취소'),
          ),
        ],
      ),
    );
    if (selected == null) return;
    try {
      await saveCourseColor(key, selected == 0 ? null : Color(selected));
      if (mounted) setState(() {});
      await bridge.invokeNative(NativeMethod.refreshWidget);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('색상 반영을 완료하지 못했어요.')));
      }
    }
  }

  Future<void> alias() async {
    var edited = courseAliases[name] ?? '';
    final value = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('과목 약자'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(name),
            const SizedBox(height: 12),
            TextFormField(
              initialValue: edited,
              onChanged: (value) => edited = value,
              maxLength: 30,
              autofocus: true,
              decoration: const InputDecoration(
                labelText: '예: 컴프2',
                helperText: '비우면 원래 과목명으로 표시해요.',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, edited),
            child: const Text('저장'),
          ),
        ],
      ),
    );
    if (value == null) return;
    try {
      await setCourseAlias(name, value);
      final s = await Store.open();
      try {
        await s.log('app', '과목 약자 변경', name);
        await reconcile(s);
      } finally {
        await s.db.close();
      }
      if (mounted) setState(() {});
    } catch (e) {
      await systemLog('과목 약자 저장 실패', '약자를 저장하지 못했어요.', kind: 'app', error: e);
      message('약자를 저장하지 못했어요.');
    }
  }

  void message(String text) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
    }
  }

  Future<CampusClient> connected() async {
    if (isDemoActive) throw CampusException('체험 모드에서는 학교 사이트를 열 수 없어요.');
    final c = CampusClient();
    try {
      final id = await credentials.read(key: 'id'),
          pw = await credentials.read(key: 'pw');
      if (id == null || pw == null) throw CampusException('포털을 먼저 연결해 주세요.');
      await c.connectSchool(id, pw);
      return c;
    } catch (_) {
      c.close();
      rethrow;
    }
  }

  CampusItem get courseItem => CampusItem(
    key: 'COURSE:$key',
    type: 'COURSE',
    title: name,
    course: name,
    courseId: '${widget.course['course_id']}',
    classNo: '${widget.course['class_no']}',
    contentsId: '',
    status: 'unknown',
    context: widget.course,
  );
  Future<void> openCourse({bool syllabus = false}) async {
    if (isDemoActive) {
      message('체험 모드에서는 학교 사이트를 열 수 없어요.');
      return;
    }
    CampusClient? c;
    try {
      c = await connected();
      final nav = await c.navigation(courseItem);
      if (syllabus) nav['url'] = '${CampusClient.learning}/std/coursePlan';
      await bridge.invokeNative(NativeMethod.openCampus, nav);
    } catch (e) {
      await systemLog('강의실 열기 실패', '학교 페이지를 열지 못했어요.', kind: 'app', error: e);
      message(e is CampusException ? e.message : '강의실을 열지 못했어요.');
    } finally {
      c?.close();
    }
  }

  Future<void> fetchPlan() async {
    if (isDemoActive) {
      message('체험 모드에서는 학교 사이트를 열 수 없어요.');
      return;
    }
    setState(() => planBusy = true);
    final account = await credentials.read(key: 'id');
    CampusClient? c;
    Store? s;
    var stage = '로그인';
    final watch = Stopwatch()..start();
    try {
      s = await Store.open();
      final scope = await SessionScope.capture(s);
      c = await retryPlanConnection(() => connected());
      stage = '과목 선택';
      final response = await retryPlanConnection(
        () => c!.api('/course/addSessionCourseInfo', widget.course),
      );
      stage = '계획서 주소 조회';
      final ctx = response['data'];
      final data = await c!.api(
        '/coursePlan/getInfo',
        ctx is String
            ? Map<String, dynamic>.from(jsonDecode(ctx))
            : Map<String, dynamic>.from(ctx),
      );
      if (data is! Map || data['plan_info'] is! Map) {
        throw CampusException('강의계획서 본문이 제공되지 않았어요. 원문에서 확인해 주세요.');
      }
      if (await credentials.read(key: 'id') != account) {
        throw CampusException('계정이 변경되어 저장을 중지했어요.');
      }
      final link = data['link_course_info'] is Map
          ? data['link_course_info']['link_url']
          : null;
      String? linkedText;
      List<List<List<String>>> linkedTables = [];
      stage = '실제 계획서 로딩·본문 인식';
      if (link is String && link.isNotEmpty) {
        linkedText = await loadLinkedSyllabus(
          link,
          name,
          onTables: (tables) => linkedTables = tables,
        );
      }
      if (await credentials.read(key: 'id') != account) {
        throw CampusException('계정이 변경되어 저장을 중지했어요.');
      }
      final result = <String, dynamic>{
        'linkedText': linkedText,
        'linkedTables': linkedTables,
        'linkedUrl': link,
        'fetchedAt': DateTime.now().toUtc().toIso8601String(),
        'data': data,
      };
      await scope.verify();
      await s.setMeta(MetaKey.coursePlan(key), jsonEncode(result));
      await s.log(
        'sync',
        '강의계획서 저장',
        linkedText == null
            ? '사이버캠퍼스 본문'
            : '바로가기 실제 계획서 · ${linkedText.length}자',
      );
      if (mounted) {
        setState(() {
          plan = result;
          planError = null;
        });
      }
    } catch (e) {
      try {
        s ??= await Store.open();
        await s.log(
          'sync',
          '강의계획서 불러오기 실패',
          '$stage · ${watch.elapsed.inSeconds}초 · ${e.runtimeType} · ${e is PlatformException ? e.code : ""}',
        );
      } catch (_) {
        // Logging must not mask the original failure shown to the user.
      }
      if (mounted) setState(() => planError = '$stage: ${planFailure(e)}');
    } finally {
      c?.close();
      await s?.db.close();
      if (mounted) setState(() => planBusy = false);
    }
  }

  Widget tasks(String type) {
    final now = DateTime.now().toUtc();
    final list =
        items
            .where(
              (i) =>
                  taskTypeMatches(i, courseTaskType) &&
                  !excluded.contains(i.key) &&
                  (showNotTasks || !notTasks.contains(i.key)) &&
                  (showCompleted || !i.done),
            )
            .toList()
          ..sort((a, b) {
            if (taskSortMode == 'published') {
              final aDate = a.startsAt ?? a.due ?? DateTime.utc(2000);
              final bDate = b.startsAt ?? b.due ?? DateTime.utc(2000);
              final c = bDate.compareTo(aDate);
              if (c != 0) return c;
              return naturalCompare(a.title, b.title);
            } else if (taskSortMode == 'title') {
              return naturalCompare(a.title, b.title);
            } else if (taskSortMode == 'title_desc') {
              return naturalCompare(b.title, a.title);
            }
            final aPast = (a.due != null && !a.due!.isAfter(now)) || a.done;
            final bPast = (b.due != null && !b.due!.isAfter(now)) || b.done;
            if (aPast != bPast) return aPast ? 1 : -1;
            final due = (a.due ?? DateTime.utc(2100)).compareTo(
              b.due ?? DateTime.utc(2100),
            );
            if (due != 0) return due;
            return naturalCompare(a.title, b.title);
          });
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        // Course header: what is next and how much is open, one action.
        Card(
          margin: EdgeInsets.zero,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(name, style: Theme.of(context).textTheme.bodySmall),
                      const SizedBox(height: 4),
                      Text(
                        nextClass == null ? '다음 수업 정보 없음' : '다음 수업 $nextClass',
                        style: Theme.of(context).textTheme.titleSmall,
                      ),
                      Text(
                        '미완료 ${items.where((i) => i.openTask && !excluded.contains(i.key) && !notTasks.contains(i.key)).length}개',
                        style: Theme.of(context).textTheme.labelMedium,
                      ),
                    ],
                  ),
                ),
                TextButton.icon(
                  onPressed: openCourse,
                  icon: const Icon(Icons.open_in_new, size: 18),
                  label: const Text('강의실 열기'),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        // One scrolling row; materials have their own tab (자료).
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            spacing: 8,
            children: [
              for (final kind in learningTypeChoices.entries)
                ChoiceChip(
                  label: Text(kind.value),
                  selected: courseTaskType == kind.key,
                  onSelected: (_) => setState(() => courseTaskType = kind.key),
                ),
              FilterChip(
                label: const Text('할 일 아님 포함'),
                selected: showNotTasks,
                onSelected: (value) async {
                  setState(() => showNotTasks = value);
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setBool('courseShowNotTasks', value);
                },
              ),
              FilterChip(
                label: const Text('완료 포함'),
                selected: showCompleted,
                onSelected: (value) async {
                  setState(() => showCompleted = value);
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setBool('courseShowCompleted', value);
                },
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  '${list.length}개 · ${taskSortMode == "published" ? "게시일 최신순" : taskSortMode == "title_desc" ? "최신주차순" : taskSortMode == "title" ? "주차순" : "제출 마감순"}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ),
              PopupMenuButton<String>(
                tooltip: '정렬 기준',
                initialValue: taskSortMode,
                onSelected: (v) async {
                  setState(() => taskSortMode = v);
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setString('courseTaskSortMode', v);
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.sort, size: 18),
                      const SizedBox(width: 4),
                      Text(
                        taskSortMode == 'published'
                            ? '게시일순'
                            : taskSortMode == 'title_desc'
                                ? '최신주차순'
                                : taskSortMode == 'title'
                                    ? '주차순'
                                    : '제출 마감순',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                itemBuilder: (context) => const [
                  PopupMenuItem(
                    value: 'due',
                    child: Text('제출 마감순 (마감 임박 우선)'),
                  ),
                  PopupMenuItem(
                    value: 'published',
                    child: Text('게시일순 (최신 등록 우선)'),
                  ),
                  PopupMenuItem(
                    value: 'title',
                    child: Text('주차순 (1주차부터)'),
                  ),
                  PopupMenuItem(
                    value: 'title_desc',
                    child: Text('주차순 (최신주차부터)'),
                  ),
                ],
              ),
            ],
          ),
        ),
        if (list.isEmpty)
          const Padding(
            padding: EdgeInsets.all(20),
            child: Text('현재 조건에 해당하는 할 일이 없어요.'),
          ),
        for (final item in list)
          RadarTaskCard(
            item: item,
            compact: true,
            onTap: () async {
              await navigateTo(context, TaskDestination(item: item));
              await load();
            },
          ),
      ],
    );
  }

  Widget planView() {
    final linkedText = plan?['linkedText'] as String?;
    final data = plan?['data'] as Map?;
    final info = data?['plan_info'] as Map?;
    const labels = {
      'lect_summary': '강의 개요',
      'lect_goal': '학습 목표',
      'lect_method': '강의 방법',
      'lect_reference': '참고 자료',
      'lect_eval': '평가 방법',
      'link_comment': '안내',
    };
    final weeks = data?['week_list'] as List? ?? [];
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Wrap(
          spacing: 8,
          children: [
            FilledButton.icon(
              onPressed: planBusy ? null : fetchPlan,
              icon: const Icon(Icons.refresh),
              label: Text(planBusy ? '불러오는 중…' : '강의계획서 불러오기'),
            ),
            OutlinedButton(
              onPressed: () async {
                final link = plan?['linkedUrl'];
                if (link is String && link.isNotEmpty) {
                  await bridge.invokeNative(NativeMethod.openLinkedPlan, {
                    'url': link,
                    'course': name,
                  });
                } else {
                  await openCourse(syllabus: true);
                }
              },
              child: const Text('강의계획서 원문 보기'),
            ),
          ],
        ),
        const SizedBox(height: 16),
        if (planError != null) Text(planError!),
        if (plan != null)
          Text(
            '저장본 · ${DateTime.tryParse('${plan!['fetchedAt']}') == null ? '저장 시각 미확인' : koreanTime(DateTime.parse(plan!['fetchedAt']))}',
          ),
        if (plan == null && !planBusy)
          const Text('버튼을 누르면 사이버캠퍼스의 강의계획서 바로가기가 여는 실제 계획서를 불러와 기기에 저장해요.'),
        if (linkedText != null) ...[
          const SectionHeading('수업 시간·강의실'),
          if (parsePlanSlots(linkedText, key, name).isEmpty)
            const Text('명시된 수업 시각을 찾지 못했어요. 원문을 확인해 주세요.'),
          ...parsePlanSlots(linkedText, key, name).map(
            (e) => ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.schedule),
              title: Text(
                '${weekNames[e.weekday - 1]} ${slotTime(e.start)}–${slotTime(e.end)}',
              ),
              subtitle: Text(e.room.isEmpty ? '강의실 미확인' : e.room),
            ),
          ),
          const SectionHeading('강의계획서'),
        ],
        if (linkedText != null)
          Card(
            child: ListTile(
              leading: const Icon(Icons.description_outlined),
              title: const Text('강의계획서 전체 읽기'),
              subtitle: Text(
                parseSyllabusTables(plan?['linkedTables']).isEmpty
                    ? '텍스트 저장본 · 다시 불러오면 표 구조도 저장해요'
                    : '표와 항목 구분을 유지한 읽기 화면',
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => SyllabusReader(
                    course: courseLabel(name),
                    text: linkedText,
                    tables: plan?['linkedTables'],
                  ),
                ),
              ),
            ),
          ),
        if (linkedText == null)
          ...labels.entries
              .where((e) => textOf(info?[e.key]).isNotEmpty)
              .map(
                (e) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        e.value,
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 6),
                      SelectableText(textOf(info?[e.key])),
                    ],
                  ),
                ),
              ),
        if (linkedText == null &&
            plan != null &&
            labels.keys.every((k) => textOf(info?[k]).isEmpty) &&
            weeks.isEmpty)
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text('텍스트 본문이 없어요. 외부 링크·첨부 계획서는 원문 버튼으로 확인하세요.'),
          ),
        if (linkedText == null)
          ...weeks.map(
            (w) => Card(
              child: ListTile(
                title: Text(
                  '${w['week_no'] ?? ''}주차 · ${textOf(w['week_title'])}',
                ),
                subtitle: Text(textOf(w['week_materials'])),
              ),
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(courseLabel(name)),
      // Frequent actions stay as icons; rarely used display settings move to
      // a named menu instead of two more unlabeled icons.
      actions: [
        IconButton(
          tooltip: '이 과목 AI 질문',
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => AiChatPage(course: widget.course),
            ),
          ),
          icon: const Icon(Icons.chat_bubble_outline),
        ),
        PopupMenuButton<String>(
          tooltip: '과목 설정',
          onSelected: (v) => switch (v) {
            'color' => chooseColor(),
            'open' => openCourse(),
            _ => alias(),
          },
          itemBuilder: (_) => [
            const PopupMenuItem(
              value: 'open',
              child: ListTile(
                leading: Icon(Icons.open_in_new),
                title: Text('강의실 바로가기'),
              ),
            ),
            PopupMenuItem(
              value: 'color',
              child: ListTile(
                leading: Icon(Icons.circle, color: courseAccent(key)),
                title: const Text('과목 색상'),
              ),
            ),
            const PopupMenuItem(
              value: 'alias',
              child: ListTile(
                leading: Icon(Icons.edit_outlined),
                title: Text('약자 설정'),
              ),
            ),
          ],
        ),
      ],
      bottom: TabBar(
        controller: courseTabs,
        isScrollable: false,
        tabs: [
          Tab(icon: Icon(Icons.checklist, size: 18), text: '할 일'),
          Tab(icon: Icon(Icons.campaign_outlined, size: 18), text: '공지'),
          Tab(icon: Icon(Icons.folder_outlined, size: 18), text: '자료'),
          Tab(icon: Icon(Icons.description_outlined, size: 18), text: '수업 정보'),
        ],
      ),
    ),
    body: AdaptiveContent(
      child: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
          ? Center(child: Text(error!))
          : TabBarView(
              controller: courseTabs,
              children: [
                tasks(''),
                ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    if (notices.isEmpty) const Text('수집된 공지가 없어요.'),
                    ...notices.map(
                      (n) => Card(
                        child: ListTile(
                          title: Text(n.title),
                          subtitle: Text(
                            n.published == null
                                ? '게시일 미확인'
                                : koreanTime(n.published!),
                          ),
                          onTap: () =>
                              navigateTo(context, NoticeDestination(notice: n)),
                        ),
                      ),
                    ),
                  ],
                ),
                MaterialsPage(
                  course: name,
                  embedded: true,
                  active: courseTabs.index == 2,
                ),
                planView(),
              ],
            ),
    ),
  );
}

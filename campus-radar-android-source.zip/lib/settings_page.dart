import 'feature_recommendation.dart';
import 'ios_widget_settings.dart';
import 'task_cleanup_settings.dart';
import 'notification_settings_page.dart';
import 'widget_settings_page.dart';
import 'ai_settings_page.dart';
import 'calendar_settings_page.dart';
import 'changes_page.dart';
import 'history_page.dart';
import 'background_status_page.dart';
import 'update_page.dart';
import 'ui_refresh.dart';
import 'desktop.dart';
import 'radar_theme.dart';
import 'updates.dart';
import 'dart:io';
import 'package:flutter/material.dart';

class SettingsHub extends StatelessWidget {
  final bool connected;
  final VoidCallback connect, logout, test;
  const SettingsHub({
    super.key,
    required this.connected,
    required this.connect,
    required this.logout,
    required this.test,
  });
  @override
  Widget build(BuildContext context) {
    void page(Widget w) =>
        Navigator.push(context, MaterialPageRoute(builder: (_) => w));
    return Scaffold(
      appBar: AppBar(title: const Text('설정')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SectionHeading('계정', subtitle: '이 기기의 포털 연결'),
          Card(
            child: ListTile(
              leading: Icon(
                connected ? Icons.verified_user_outlined : Icons.person_outline,
              ),
              title: Text(connected ? '포털 연결됨' : '포털 연결 필요'),
              subtitle: const Text('계정은 이 기기의 보안 저장소에 보관합니다.'),
              trailing: connected ? null : const Icon(Icons.chevron_right),
              onTap: connected ? null : connect,
            ),
          ),
          const SectionHeading('알림·표시', subtitle: '알림과 화면을 내 방식대로'),
          if (Platform.isAndroid)
            _setting(
              context,
              Icons.widgets_outlined,
              '위젯·잠금화면',
              '홈 화면 위젯 · 잠금화면 카드 · 글씨 크기',
              () => page(const WidgetSettingsPage()),
            ),
          if (Platform.isIOS)
            _setting(
              context,
              Icons.widgets_outlined,
              '홈·잠금화면 위젯',
              '할 일 · 다음 수업 · 시간표',
              () => page(const IosWidgetSettings()),
            ),
          _setting(
            context,
            Icons.playlist_remove_outlined,
            '할 일 표시·정리',
            '제출 대기 표시 · 기한 지난 항목 · 출석 정보',
            () => page(const TaskCleanupSettings()),
          ),
          _setting(
            context,
            Icons.palette_outlined,
            '화면 테마',
            '8가지 색상 · 시스템 설정 · 라이트 · 다크',
            () => page(const AppearancePage()),
          ),
          const DiscoverySettings(),
          if (Platform.isWindows)
            _setting(
              context,
              Icons.desktop_windows_outlined,
              'PC 실행 설정',
              '자동 수집 · 시작 프로그램 · 트레이 · 알림',
              () => page(const DesktopSettingsPage()),
            ),
          _setting(
            context,
            Icons.notifications_outlined,
            '알림',
            '마감·새 항목 · 수업 전 · 하루 요약',
            () => page(const NotificationSettingsPage()),
          ),
          const SectionHeading('연결', subtitle: 'AI와 캘린더 선택 기능'),
          _setting(
            context,
            Icons.auto_awesome,
            'AI 연결·일정 자동 정리',
            '개인 키, 분석 범위, 데일리 요약',
            () => page(const AiSettingsPage()),
          ),
          _setting(
            context,
            Icons.calendar_month_outlined,
            Platform.isWindows ? '일정 파일 내보내기' : '캘린더 전송',
            Platform.isWindows ? '.ics 파일로 저장하고 캘린더에서 가져오기' : '저장할 캘린더와 자동 전송',
            () => page(
              Platform.isWindows
                  ? const DesktopCalendarPage()
                  : const CalendarSettingsPage(),
            ),
          ),
          const SectionHeading('앱 관리', subtitle: '업데이트와 동작 기록'),
          _setting(
            context,
            Icons.battery_charging_full,
            Platform.isWindows ? 'PC 자동 수집 상태' : '배터리·백그라운드 상태',
            Platform.isWindows
                ? '트레이 실행과 최근 자동 확인'
                : (Platform.isIOS ? '백그라운드 앱 새로 고침과 최근 수집' : '앱 배터리 제한과 수집 예약'),
            () => page(
              Platform.isWindows
                  ? const DesktopSettingsPage()
                  : const BackgroundStatusPage(),
            ),
          ),
          _setting(
            context,
            Icons.history,
            '활동 로그',
            '수집·알림·AI·캘린더·업데이트',
            () => page(const HistoryPage(notificationsOnly: false)),
          ),
          _setting(
            context,
            Icons.change_circle_outlined,
            '변경 이력',
            '과제와 콘텐츠의 변경 사항',
            () => page(const ChangesPage()),
          ),
          _setting(
            context,
            Icons.system_update_alt,
            '앱 업데이트',
            '현재 $installedAppVersion ($installedAppBuild) · ${channelLabel(appReleaseChannel)}',
            () => page(
              Platform.isWindows
                  ? const DesktopUpdatePage()
                  : const UpdatePage(),
            ),
          ),
          if (connected)
            _setting(
              context,
              Icons.notifications_active_outlined,
              '알림 표시 테스트',
              '기기에 테스트 알림 요청',
              test,
            ),
          const Divider(),
          if (connected)
            _setting(
              context,
              Icons.logout,
              '로그아웃',
              '계정·앱 데이터 삭제 범위를 확인합니다.',
              logout,
            ),
        ],
      ),
    );
  }

  Widget _setting(
    BuildContext c,
    IconData icon,
    String title,
    String subtitle,
    VoidCallback action,
  ) => ListTile(
    contentPadding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
    leading: Icon(icon),
    title: Text(title),
    subtitle: Text(subtitle),
    trailing: const Icon(Icons.chevron_right),
    onTap: action,
  );
}

import 'ai_inbox_repository.dart';
import 'navigation_contract.dart';
import 'ai_chat_page.dart';
import 'calendar_draft_page.dart';
import 'ai_state_repository.dart';
import 'ai_state_models.dart';
import 'ai_protocol.dart';
import 'task_presentation.dart';
import 'app_storage.dart';
import 'app_credentials.dart';
import 'course_labels.dart';
import 'campus_models.dart';
import 'ai_recovery.dart';
import 'ai_recovery_page.dart';
import 'ai_confirm.dart';
import 'dart:io';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'ai_automation.dart';

class AiInboxPage extends StatefulWidget {
  final bool embedded, home, records;
  const AiInboxPage({
    super.key,
    this.embedded = false,
    this.home = false,
    this.records = false,
  });
  @override
  State<AiInboxPage> createState() => _AiInboxState();
}

class _AiInboxState extends State<AiInboxPage> with WidgetsBindingObserver {
  Timer? timer;
  bool loading = true, auto = false;
  String filter = 'review', error = '', recentQuestion = '';
  String? blockedCode;
  List<Map<String, dynamic>> candidates = [], jobs = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    load();
    timer = Timer.periodic(const Duration(seconds: 3), (_) {
      if (WidgetsBinding.instance.lifecycleState == AppLifecycleState.resumed) {
        load();
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  bool reading = false;
  Future<void> load() async {
    if (reading) return;
    reading = true;
    Store? s;
    try {
      s = await Store.open();
      final snapshot = await AiInboxRepository(s).read();
      if (mounted) {
        setState(() {
          candidates = snapshot.candidates;
          jobs = snapshot.jobs;
          recentQuestion = snapshot.recentQuestion;
          blockedCode = snapshot.blockedCode;
          auto = snapshot.enabled;
          loading = false;
          error = '';
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          error = '일정함을 읽지 못했습니다. 다시 확인해 주세요.';
          loading = false;
        });
      }
    } finally {
      await s?.db.close();
      reading = false;
    }
  }

  Future<void> state(String key, ScheduleDecision value) async {
    final s = await Store.open();
    try {
      final old = await AiStateRepository(s).schedule(key);
      await AiStateRepository(s).saveSchedule(key, old.withDecision(value));
    } finally {
      await s.db.close();
    }
    await load();
  }

  final saving = <String>{};
  Future<void> quickConfirm(
    Map<String, dynamic> row, {
    bool calendar = false,
  }) async {
    final key = row['key'] as String;
    if (saving.contains(key)) return;
    if (!calendar && (row['state'] as Map)['status'] != 'confirmed') {
      final store = await Store.open();
      String? choice;
      try {
        choice = await store.meta('aiCalendarDefault');
      } finally {
        await store.db.close();
      }
      if (choice == null && mounted) {
        final selected = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('일정을 어디에 추가할까요?'),
            content: const Text('다음부터 이 선택을 기본으로 사용해요. AI 설정에서 변경할 수 있어요.'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('앱 일정함'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('캘린더에도 추가'),
              ),
            ],
          ),
        );
        if (selected == null) return;
        choice = selected ? 'yes' : 'no';
        final saved = await Store.open();
        try {
          await saved.setMeta('aiCalendarDefault', choice);
        } finally {
          await saved.db.close();
        }
      }
      if (!mounted) return;
      calendar = choice == 'yes';
    }
    final c = row['candidate'] as ScheduleCandidate;
    final n = row['notice'] as CampusNotice;
    if (c.date.isEmpty && (row['state'] as Map)['start'] == null) {
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => CalendarDraftPage(
            courseName: n.course,
            itemKey: key,
            title: '[${courseLabel(n.course)}] ${c.title}',
            description: '공지: ${n.title}\n${c.description}',
            allDay: true,
            closeAfterSave: true,
            saveToCalendar: calendar,
          ),
        ),
      );
      await load();
      return;
    }
    setState(() => saving.add(key));
    Store? store;
    try {
      store = await Store.open();
      final old = await confirmAiCandidate(
        store,
        key,
        n,
        c,
        calendar: calendar,
      );
      await load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              calendar
                  ? (Platform.isWindows ? '일정 파일을 저장했습니다.' : '캘린더에 저장했습니다.')
                  : '일정에 추가했어요.',
            ),
            action: calendar
                ? null
                : SnackBarAction(
                    label: '실행 취소',
                    onPressed: () async {
                      final s = await Store.open();
                      try {
                        await AiStateRepository(
                          s,
                        ).saveSchedule(key, ConfirmedSchedule.fromJson(old));
                      } finally {
                        await s.db.close();
                      }
                      await load();
                    },
                  ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(e is AiFailure ? e.message : '일정을 저장하지 못했습니다.'),
          ),
        );
      }
    } finally {
      await store?.db.close();
      if (mounted) setState(() => saving.remove(key));
    }
  }

  Future<void> pause() async {
    final s = await Store.open();
    try {
      if (!auto &&
          (await credentials.read(key: 'geminiApiKey') == null ||
              await s.meta('aiConsent') != aiConsentVersion)) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('AI 설정에서 키와 전송 동의를 먼저 저장하세요.')),
          );
        }
        return;
      }
      await s.setAiSetting(AiSetting.aiAuto, auto ? 'no' : 'yes');
      await s.log(
        'ai',
        auto ? 'AI 대기열 일시 중지' : 'AI 대기열 재개',
        '진행 중 요청은 완료 후 중지됩니다.',
      );
    } finally {
      await s.db.close();
    }
    if (!auto) {
      await scheduleAiWork();
      unawaited(processAiWork());
    }
    await load();
  }

  Future<void> openRecovery(Map<String, dynamic> job) async {
    final store = await Store.open();
    CampusNotice? notice;
    try {
      notice = (await store.notices())
          .where((n) => n.id == job['id'])
          .firstOrNull;
    } finally {
      await store.db.close();
    }
    if (!mounted) return;
    if (notice == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('원문 공지가 현재 수집 목록에 없어요. 공지를 다시 수집해 주세요.')),
      );
      return;
    }
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AiRecoveryPage(notice: notice!, job: job),
      ),
    );
    await load();
  }

  Future<void> retry(String id) async {
    if (!auto) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('대기열을 재개한 뒤 재시도해 주세요.')));
      return;
    }
    final s = await Store.open();
    try {
      final q = jsonDecode(await s.meta('aiQueue:$id') ?? '{}') as Map;
      await s.setMeta('aiCooldown', '0');
      await AiStateRepository(s).saveJob(
        id,
        AiJob.fromJson(q).withStatus(
          AiJobStatus.pending,
          fields: {'attempts': 0, 'retryAt': ''},
        ),
      );
    } finally {
      await s.db.close();
    }
    await scheduleAiWork();
    unawaited(processAiWork());
    await load();
  }

  @override
  Widget build(BuildContext context) {
    final list = candidates.where((r) {
      if (widget.records) return false;
      final status = (r['state'] as Map)['status'] ?? 'review';
      return filter == 'all' || status == filter;
    }).toList();
    return Scaffold(
      appBar: widget.embedded
          ? null
          : AppBar(
              title: Text(widget.records ? 'AI 분석 기록' : 'AI 일정함'),
              actions: [
                IconButton(
                  onPressed: () => navigateTo(context, AiSettingsDestination()),
                  icon: const Icon(Icons.tune),
                  tooltip: 'AI 설정',
                ),
                IconButton(
                  onPressed: load,
                  icon: const Icon(Icons.refresh),
                  tooltip: '새로고침',
                ),
              ],
            ),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            if (widget.home) ...[
              Text(
                '무엇을 도와줄까?',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 8),
              const Text('수집한 공지에서 일정을 찾고, 과제에 대한 질문을 도와드려요.'),
              const SizedBox(height: 16),
              Text(
                '확인할 일정 ${candidates.where((r) => ((r['state'] as Map)['status'] ?? 'review') == 'review').length}개',
                style: Theme.of(context).textTheme.titleLarge,
              ),
            ],
            if (auto &&
                jobs.any((j) => ['pending', 'running'].contains(j['status'])))
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text(
                  '공지 ${jobs.where((j) => ['pending', 'running'].contains(j['status'])).length}개를 확인하고 있어요 · 연결 오류는 자동 재시도해요',
                ),
              ),
            if (!widget.records && jobs.any((j) => j['status'] == 'failed'))
              Card(
                child: ListTile(
                  leading: const Icon(Icons.info_outline),
                  title: Text(
                    '분석 문제 ${jobs.where((j) => j['status'] == 'failed').length}개',
                  ),
                  subtitle: const Text('실패 원인 확인 · 원문 보기 · 직접 추가 · 자료 추가 재분석'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () =>
                      navigateTo(context, AiInboxDestination(records: true)),
                ),
              ),
            const SizedBox(height: 12),
            if (!widget.records && !widget.home)
              Wrap(
                spacing: 6,
                children: [
                  for (final f in {
                    'review': '확인 필요',
                    'confirmed': '추가한 일정',
                    'hold': '보류',
                    'excluded': '제외',
                    'all': '전체',
                  }.entries)
                    ChoiceChip(
                      label: Text(f.value),
                      selected: filter == f.key,
                      onSelected: (_) => setState(() => filter = f.key),
                    ),
                ],
              ),
            if (loading) const LinearProgressIndicator(),
            if (error.isNotEmpty) Text(error),
            if (!widget.records && !loading && list.isEmpty)
              const Padding(
                padding: EdgeInsets.all(30),
                child: Text('새로 확인할 일정이 없어요.'),
              ),
            for (final row in widget.home ? list.take(3) : list)
              Builder(
                builder: (context) {
                  final n = row['notice'] as CampusNotice,
                      c = row['candidate'] as ScheduleCandidate;
                  final st = row['state'] as Map;
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            courseLabel(n.course),
                            style: Theme.of(context).textTheme.labelMedium,
                          ),
                          Text(
                            courseEventTitle(
                              st['title'] ?? c.title,
                              n.course,
                              oldLabel: st['courseLabel'] as String?,
                            ),
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          Text(
                            '${st['date'] ?? (c.date.isEmpty ? '날짜 확인 필요' : c.date)} ${st['start'] != null && st['allDay'] != true
                                ? formatDate(DateTime.parse(st['start']))
                                : st['allDay'] == true
                                ? '종일'
                                : c.time} · ${c.action == 'add'
                                ? '새 일정'
                                : c.action == 'change'
                                ? '변경 확인'
                                : '취소 확인'}',
                          ),
                          if (row['approvalReview'] is Map &&
                              row['approvalReview']['approved'] == false)
                            Text('수동 검토: ${row['approvalReview']['reason']}'),
                          if (st['approvalMode'] == 'automatic')
                            const Chip(label: Text('Gemini 검토 · 자동 승인')),
                          if (st['approvalReason'] is String)
                            Text(st['approvalReason'] as String),
                          if (st['calendarSent'] == true)
                            Chip(
                              label: Text(
                                Platform.isWindows ? '일정 파일 저장됨' : '캘린더 전송됨',
                              ),
                            ),
                          if (c.conditionLabel.isNotEmpty)
                            Chip(label: Text(c.conditionLabel)),
                          if (c.periodLabel.isNotEmpty) Text(c.periodLabel),
                          if (c.inferenceLabel.isNotEmpty)
                            Text(c.inferenceLabel),
                          if (c.uncertainty.isNotEmpty) Text(c.uncertainty),
                          ExpansionTile(
                            tilePadding: EdgeInsets.zero,
                            title: const Text('근거·공지 원문'),
                            children: [
                              SelectableText('근거: ${c.evidence}\n\n${n.body}'),
                            ],
                          ),
                          Wrap(
                            spacing: 6,
                            children: [
                              if (c.action == 'add' &&
                                  st['status'] != 'confirmed')
                                FilledButton(
                                  onPressed: saving.contains(row['key'])
                                      ? null
                                      : () => quickConfirm(row),
                                  child: Text(
                                    c.date.isEmpty && st['start'] == null
                                        ? '날짜 확인·추가'
                                        : '일정에 추가',
                                  ),
                                ),
                              if (c.action == 'add' &&
                                  st['status'] == 'confirmed')
                                OutlinedButton(
                                  onPressed: saving.contains(row['key'])
                                      ? null
                                      : () => quickConfirm(row, calendar: true),
                                  child: Text(
                                    st['calendarSent'] == true
                                        ? '캘린더 갱신'
                                        : (Platform.isWindows
                                              ? '일정 파일 저장'
                                              : '캘린더 저장'),
                                  ),
                                ),
                              if (c.action == 'add')
                                TextButton(
                                  onPressed: () async {
                                    await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => CalendarDraftPage(
                                          courseName: n.course,
                                          itemKey: row['key'] as String,
                                          closeAfterSave: true,
                                          title: courseEventTitle(
                                            st['title'] ??
                                                '[${n.course}] ${c.title}',
                                            n.course,
                                            oldLabel:
                                                st['courseLabel'] as String?,
                                          ),
                                          description:
                                              '공지: ${n.title}\n${c.description}\nhttps://dcs-learning.cnu.ac.kr/home',
                                          start:
                                              DateTime.tryParse(
                                                st['start'] ?? '',
                                              ) ??
                                              (c.date.isEmpty
                                                  ? null
                                                  : c.time.isEmpty
                                                  ? strictDate(c.date)
                                                  : DateTime.parse(
                                                      '${c.date}T${c.time}:00+09:00',
                                                    )),
                                          deadline:
                                              st['deadline'] as bool? ??
                                              c.deadline,
                                          end: st.containsKey('end')
                                              ? DateTime.tryParse(
                                                  st['end'] ?? '',
                                                )
                                              : c.endInstant,
                                          allDay:
                                              st['allDay'] as bool? ??
                                              c.time.isEmpty,
                                        ),
                                      ),
                                    );
                                    await load();
                                  },
                                  child: const Text('수정'),
                                ),
                              if (c.action != 'add')
                                const Text('기존 캘린더 일정을 직접 확인해 변경·취소를 반영하세요.'),
                              PopupMenuButton<String>(
                                tooltip: '일정 더보기',
                                onSelected: (v) => state(
                                  row['key'] as String,
                                  ScheduleDecision.values.byName(v),
                                ),
                                itemBuilder: (_) => const [
                                  PopupMenuItem(
                                    value: 'hold',
                                    child: Text('보류'),
                                  ),
                                  PopupMenuItem(
                                    value: 'excluded',
                                    child: Text('제외'),
                                  ),
                                ],
                              ),
                              if (filter != 'review')
                                TextButton(
                                  onPressed: () => state(
                                    row['key'] as String,
                                    ScheduleDecision.review,
                                  ),
                                  child: const Text('다시 검토'),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            if (widget.home) ...[
              TextButton(
                onPressed: () => navigateTo(context, AiInboxDestination()),
                child: const Text('일정함 전체 보기'),
              ),
              const SizedBox(height: 16),
              const Divider(),
              FilledButton.icon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AiChatPage()),
                ),
                icon: const Icon(Icons.chat_bubble_outline),
                label: const Text('공지나 과제에 대해 질문하기'),
              ),
              Wrap(
                spacing: 8,
                children: [
                  for (final q in ['이번 주 해야 할 일', '최근 공지 요약', '놓치기 쉬운 일정'])
                    ActionChip(
                      label: Text(q),
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AiChatPage(initialQuestion: q),
                        ),
                      ),
                    ),
                ],
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('최근 대화'),
                subtitle: Text(
                  recentQuestion.isEmpty ? '질문을 시작해 보세요' : recentQuestion,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AiChatPage()),
                ),
              ),
            ],
            const SizedBox(height: 24),
            if (widget.records)
              TextButton(
                onPressed: pause,
                child: Text(auto ? '자동 분석 일시 중지' : '자동 분석 재개'),
              ),
            if (widget.records) ...[
              const Text(
                '확인 필요한 항목',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              if (!jobs.any((j) => j['status'] == 'failed'))
                const Text('해결할 분석 문제가 없어요.'),
              for (final j in jobs.where((j) => j['status'] == 'failed'))
                Card(
                  child: ListTile(
                    title: Text(j['title'] ?? '공지'),
                    subtitle: Text(recoveryExplanation(recoveryCode(j))),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => openRecovery(j),
                  ),
                ),
              for (final j in jobs.where(
                (j) => ['pending', 'running'].contains(j['status']),
              ))
                ListTile(
                  title: Text(j['title'] ?? '공지'),
                  subtitle: Text(
                    j['status'] == 'running'
                        ? '분석 중'
                        : '자동 재시도 대기 · ${j['error'] ?? ''}',
                  ),
                  onTap: () => openRecovery(j),
                ),
              ExpansionTile(
                title: const Text('완료·제외 기록'),
                children: [
                  for (final j in jobs.where(
                    (j) =>
                        !['failed', 'pending', 'running'].contains(j['status']),
                  ))
                    ListTile(
                      title: Text(j['title'] ?? '공지'),
                      subtitle: Text(
                        {
                              'done': '완료 · 발견한 일정은 일정함에서 확인',
                              'empty': '완료 · 추가할 일정 없음',
                              'excluded': '사용자가 분석 제외',
                              'manual': '사용자가 직접 일정 추가',
                            }[j['status']] ??
                            '${j['status']}',
                      ),
                      onTap: () => openRecovery(j),
                    ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

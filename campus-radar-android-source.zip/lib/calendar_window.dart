/// KST calendar windows shared by quick confirmation and the edit screen.
(DateTime, DateTime) calendarWindow(
  DateTime anchor, {
  bool allDay = false,
  bool deadline = false,
  DateTime? end,
}) {
  if (end != null && end.isAfter(anchor)) return (anchor, end);
  if (allDay) return (anchor, anchor.add(const Duration(days: 1)));
  final k = anchor.toUtc().add(const Duration(hours: 9));
  final midnight = DateTime.utc(
    k.year,
    k.month,
    k.day,
  ).subtract(const Duration(hours: 9));
  final after = anchor.add(const Duration(minutes: 10));
  // A late-night point event must not spill into the following calendar date.
  if (!deadline && !after.isAfter(midnight.add(const Duration(days: 1)))) {
    return (anchor, after);
  }
  final before = anchor.subtract(const Duration(minutes: 10));
  return (
    anchor.isAtSameMomentAs(midnight)
        ? before
        : (before.isBefore(midnight) ? midnight : before),
    anchor,
  );
}

import 'navigation_contract.dart';
import 'native_contract.dart';
import 'notice_analysis_page.dart';
import 'task_presentation.dart';
import 'app_storage.dart';
import 'native_bridge.dart';
import 'app_credentials.dart';
import 'course_labels.dart';
import 'campus_models.dart';
import 'session_scope.dart';
import 'network_resilience.dart';
import 'media_widgets.dart';
import 'ui_refresh.dart';
import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'campus.dart';

class NoticesPage extends StatefulWidget {
  const NoticesPage({super.key});
  @override
  State<NoticesPage> createState() => _NoticesPageState();
}

class _NoticesPageState extends State<NoticesPage> {
  List<CampusNotice> notices = [];
  Map<String, String> aiStates = {};
  String query = '', course = '', error = '';
  bool loading = true;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final store = await Store.open();
    try {
      final data = await store.notices();
      final failure = await store.meta('noticeError');
      final statuses = <String, String>{};
      for (final n in data) {
        final q =
            jsonDecode(await store.meta('aiQueue:${n.id}') ?? '{}') as Map;
        statuses[n.id] =
            {
              'pending': 'AI 대기',
              'running': 'AI 분석 중',
              'done': 'AI 후보 있음',
              'empty': '일정 없음',
              'failed': 'AI 실패',
            }[q['status']] ??
            '미분석';
      }
      if (mounted) {
        setState(() {
          notices = data;
          aiStates = statuses;
          error = failure ?? '';
          loading = false;
          if (!data.any((n) => n.course == course)) course = '';
        });
      }
    } finally {
      await store.db.close();
    }
  }

  @override
  Widget build(BuildContext context) {
    final courses = notices.map((n) => n.course).toSet().toList()..sort();
    final visible = notices
        .where(
          (n) =>
              (course.isEmpty || n.course == course) &&
              '${courseLabel(n.course)} ${n.title}'.toLowerCase().contains(
                query.toLowerCase(),
              ),
        )
        .toList();
    return Scaffold(
      appBar: AppBar(
        title: const Text('공지 모아보기'),
        actions: [
          IconButton(
            onPressed: load,
            icon: const Icon(Icons.refresh),
            tooltip: '저장된 목록 새로고침',
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                const Text('최근 수집한 현재 학기 공지입니다. 새 공지는 메인 화면의 지금 확인으로 수집합니다.'),
                TextField(
                  decoration: const InputDecoration(
                    labelText: '공지·과목 검색',
                    prefixIcon: Icon(Icons.search),
                  ),
                  onChanged: (v) => setState(() => query = v),
                ),
                DropdownButton<String>(
                  isExpanded: true,
                  value: course,
                  items: [
                    const DropdownMenuItem(value: '', child: Text('모든 과목')),
                    ...courses.map(
                      (c) => DropdownMenuItem(
                        value: c,
                        child: Text(
                          courseLabel(c),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ),
                  ],
                  onChanged: (v) => setState(() => course = v ?? ''),
                ),
                if (error.isNotEmpty)
                  Text(
                    error,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.error,
                    ),
                  ),
              ],
            ),
          ),
          if (loading) const LinearProgressIndicator(),
          Expanded(
            child: RefreshIndicator(
              onRefresh: load,
              child: ListView.builder(
                physics: const AlwaysScrollableScrollPhysics(),
                itemCount: visible.isEmpty ? 1 : visible.length,
                itemBuilder: (context, index) {
                  if (visible.isEmpty) {
                    return const Padding(
                      padding: EdgeInsets.all(24),
                      child: Text('표시할 공지가 없습니다. 메인 화면에서 지금 확인을 눌러 주세요.'),
                    );
                  }
                  final n = visible[index];
                  final day = n.published == null
                      ? '게시일 미확인'
                      : formatDate(n.published!).split(' ').first;
                  final previous = index == 0
                      ? ''
                      : visible[index - 1].published == null
                      ? '게시일 미확인'
                      : formatDate(
                          visible[index - 1].published!,
                        ).split(' ').first;
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      if (day != previous)
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: SectionHeading(day),
                        ),
                      Card(
                        margin: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 4,
                        ),
                        child: ListTile(
                          leading: Icon(
                            n.read
                                ? Icons.drafts_outlined
                                : Icons.mark_email_unread_outlined,
                          ),
                          title: Text(
                            n.title,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          subtitle: Text(
                            '${courseLabel(n.course)}\n${n.published == null ? '게시 시각 미확인' : formatDate(n.published!)} · ${n.read ? '학교 기준 확인함' : '학교 기준 미확인'}',
                          ),
                          isThreeLine: true,
                          trailing: Text(
                            aiStates[n.id] ?? '미분석',
                            style: Theme.of(context).textTheme.labelSmall,
                          ),
                          onTap: () async {
                            await navigateTo(
                              context,
                              NoticeDestination(notice: n),
                            );
                            await load();
                          },
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class NoticeDetailPage extends StatefulWidget {
  final CampusNotice notice;
  const NoticeDetailPage({super.key, required this.notice});
  @override
  State<NoticeDetailPage> createState() => _NoticeDetailPageState();
}

class _NoticeDetailPageState extends State<NoticeDetailPage> {
  late CampusNotice notice = widget.notice;
  bool loading = true, opening = false;
  String? error;
  @override
  void initState() {
    super.initState();
    loadBody();
  }

  Future<CampusClient> client() async {
    final id = await credentials.read(key: 'id'),
        pw = await credentials.read(key: 'pw');
    if (id == null || pw == null) throw CampusException('포털을 먼저 연결해 주세요.');
    final c = CampusClient();
    try {
      await c.login(id, pw);
      return c;
    } catch (_) {
      c.close();
      rethrow;
    }
  }

  Future<void> loadBody({bool force = false}) async {
    if (notice.bodyFetched && notice.bodyHtml.isNotEmpty && !force) {
      setState(() => loading = false);
      return;
    }
    setState(() {
      loading = true;
      error = null;
    });
    CampusClient? c;
    final sourceStore = await Store.open();
    SessionScope? scope;
    Timer? watch;
    final account = await credentials.read(key: 'id');
    try {
      scope = await SessionScope.capture(sourceStore);
      c = await client();
      watch = scope.watch(() => c?.close());
      final data = await c.fetchNoticeBody(notice);
      if (await credentials.read(key: 'id') != account) {
        throw CampusException('계정이 변경되어 공지 저장을 중지했습니다.');
      }
      final store = await Store.open();
      try {
        await scope.verify();
        await store.saveNotice(data);
        await store.log(
          'received',
          '공지 본문 수집',
          '${data.course} · ${data.title}',
        );
      } finally {
        await store.db.close();
      }
      if (mounted) setState(() => notice = data);
    } catch (e) {
      if (mounted) {
        setState(
          () => error = e is CampusException
              ? e.message
              : '${networkFailureMessage(e)} 저장된 본문은 유지합니다.',
        );
      }
    } finally {
      watch?.cancel();
      c?.close();
      await sourceStore.db.close();
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> openCampus() async {
    setState(() => opening = true);
    CampusClient? c;
    try {
      c = await client();
      await bridge.invokeNative(
        NativeMethod.openCampus,
        await c.navigation(notice.item),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              e is CampusException ? e.message : '사이버캠퍼스를 열지 못했습니다.',
            ),
          ),
        );
      }
    } finally {
      c?.close();
      if (mounted) setState(() => opening = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('공지 상세'),
      actions: [
        IconButton(
          tooltip: '본문·첨부 새로고침',
          onPressed: loading ? null : () => loadBody(force: true),
          icon: const Icon(Icons.refresh),
        ),
      ],
    ),
    bottomNavigationBar: PinnedAction(
      child: FilledButton.icon(
        onPressed: opening ? null : openCampus,
        icon: const Icon(Icons.open_in_new),
        label: Text(opening ? '연결 중…' : '사이버캠퍼스 열기'),
      ),
    ),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Text(courseLabel(notice.course)),
        const SizedBox(height: 8),
        Text(
          notice.title,
          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        if (notice.published != null) Text(formatDate(notice.published!)),
        const SizedBox(height: 20),
        if (loading) const LinearProgressIndicator(),
        if (error != null) ...[
          Text(error!),
          TextButton(
            onPressed: () => loadBody(force: true),
            child: const Text('본문 다시 불러오기'),
          ),
        ],
        if (!notice.bodyFetched && notice.body.isNotEmpty)
          const Text('저장된 본문입니다. 최신 내용을 확인하고 있어요.'),
        CampusBodyView(
          body: notice.body.isEmpty && notice.media.isEmpty
              ? (loading ? '본문을 불러오는 중입니다.' : '본문이 없습니다.')
              : notice.body,
          bodyHtml: notice.bodyHtml,
          media: notice.media,
        ),
        const SizedBox(height: 24),
        if (Platform.isAndroid || Platform.isIOS)
          FilledButton.tonalIcon(
            onPressed: loading || opening
                ? null
                : () async {
                    if (!notice.bodyFetched) await loadBody();
                    if (!context.mounted ||
                        error != null ||
                        !notice.bodyFetched) {
                      return;
                    }
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => NoticeAnalysisPage(notice: notice),
                      ),
                    );
                  },
            icon: const Icon(Icons.auto_awesome),
            label: const Text('AI 일정 분석'),
          ),
        const SizedBox(height: 12),
        const Text(
          '댓글과 외부 학습 도구의 자료는 사이버캠퍼스에서 확인하세요.',
          style: TextStyle(fontSize: 12),
        ),
      ],
    ),
  );
}

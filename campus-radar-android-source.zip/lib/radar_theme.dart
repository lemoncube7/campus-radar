import 'adaptive_content.dart';
import 'dart:async';
import 'dart:io';
import 'native_bridge.dart';
import 'native_contract.dart';
import 'feature_discovery.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum RadarAccent {
  teal('청록', Color(0xff197e7b)),
  blue('블루', Color(0xff2864bd)),
  indigo('인디고', Color(0xff4c50ad)),
  purple('퍼플', Color(0xff8852b3)),
  rose('로즈', Color(0xffb34670)),
  orange('오렌지', Color(0xffa95a1c)),
  green('그린', Color(0xff3d7950)),
  slate('슬레이트', Color(0xff546678));

  final String label;
  final Color seed;
  const RadarAccent(this.label, this.seed);
}

void refreshNativeAccent() {
  if (Platform.isAndroid) {
    unawaited(
      bridge
          .invokeNative(NativeMethod.themeRefresh)
          .timeout(const Duration(seconds: 2))
          .then<void>((_) {}, onError: (Object _) {}),
    );
  }
}

RadarAccent defaultSecondaryAccent(RadarAccent primary) => switch (primary) {
  RadarAccent.teal || RadarAccent.blue => RadarAccent.orange,
  RadarAccent.indigo => RadarAccent.rose,
  RadarAccent.purple || RadarAccent.slate => RadarAccent.teal,
  RadarAccent.rose || RadarAccent.orange => RadarAccent.blue,
  RadarAccent.green => RadarAccent.purple,
};
final radarSecondaryAccent = ValueNotifier<RadarAccent>(RadarAccent.orange);
Future<void> saveRadarSecondaryAccent(RadarAccent accent) async {
  if (!await (await SharedPreferences.getInstance()).setString(
    'radarSecondaryAccent',
    accent.name,
  )) {
    throw StateError('보조 색상을 저장하지 못했습니다.');
  }
  radarSecondaryAccent.value = accent;
  refreshNativeAccent();
}

final radarAccent = ValueNotifier<RadarAccent>(RadarAccent.teal);
Future<void> saveRadarAccent(RadarAccent accent) async {
  if (!await (await SharedPreferences.getInstance()).setString(
    'radarAccent',
    accent.name,
  )) {
    throw StateError('색상 테마를 저장하지 못했습니다.');
  }
  radarAccent.value = accent;
  refreshNativeAccent();
}

final radarThemeMode = ValueNotifier<ThemeMode>(ThemeMode.system);

Future<void> loadRadarTheme() async {
  final prefs = await SharedPreferences.getInstance();
  final value = prefs.getString('radarTheme');
  radarAccent.value =
      RadarAccent.values
          .where((c) => c.name == prefs.getString('radarAccent'))
          .firstOrNull ??
      RadarAccent.teal;
  radarSecondaryAccent.value =
      RadarAccent.values
          .where((c) => c.name == prefs.getString('radarSecondaryAccent'))
          .firstOrNull ??
      defaultSecondaryAccent(radarAccent.value);
  radarThemeMode.value =
      ThemeMode.values.where((m) => m.name == value).firstOrNull ??
      ThemeMode.system;
}

Future<void> saveRadarTheme(ThemeMode mode) async {
  final saved = await (await SharedPreferences.getInstance()).setString(
    'radarTheme',
    mode.name,
  );
  if (!saved) throw StateError('화면 테마를 저장하지 못했습니다.');
  radarThemeMode.value = mode;
}

ThemeData radarTheme(
  Brightness brightness, {
  RadarAccent? accent,
  RadarAccent? secondaryAccent,
}) {
  final selected = accent ?? radarAccent.value;
  final legacy = selected == RadarAccent.teal;
  final generated = ColorScheme.fromSeed(
    seedColor: selected.seed,
    brightness: brightness,
  );
  final dark = brightness == Brightness.dark;
  final bg = legacy ? Color(dark ? 0xff141a1c : 0xfff5f8f8) : generated.surface;
  final surface = legacy
      ? Color(dark ? 0xff1d2528 : 0xffffffff)
      : generated.surfaceContainerLow;
  final primaryColors = !legacy
      ? generated.copyWith(surface: surface)
      : ColorScheme.fromSeed(
          seedColor: const Color(0xff197e7b),
          brightness: brightness,
        ).copyWith(
          primary: Color(dark ? 0xff78d5cb : 0xff167b76),
          onPrimary: Color(dark ? 0xff073c39 : 0xffffffff),
          surface: surface,
          onSurface: Color(dark ? 0xffe6eeee : 0xff192729),
          onSurfaceVariant: Color(dark ? 0xffafc0c2 : 0xff586b6f),
          outlineVariant: Color(dark ? 0xff364449 : 0xffdce5e6),
        );
  final companion = ColorScheme.fromSeed(
    seedColor: (secondaryAccent ?? radarSecondaryAccent.value).seed,
    brightness: brightness,
  );
  final colors = primaryColors.copyWith(
    secondary: companion.primary,
    onSecondary: companion.onPrimary,
    secondaryContainer: companion.primaryContainer,
    onSecondaryContainer: companion.onPrimaryContainer,
    tertiary: companion.tertiary,
    onTertiary: companion.onTertiary,
    tertiaryContainer: companion.tertiaryContainer,
    onTertiaryContainer: companion.onTertiaryContainer,
  );
  final base = ThemeData(
    useMaterial3: true,
    colorScheme: colors,
    brightness: brightness,
  );
  return base.copyWith(
    scaffoldBackgroundColor: bg,
    textTheme: base.textTheme.apply(
      bodyColor: colors.onSurface,
      displayColor: colors.onSurface,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: bg,
      foregroundColor: colors.onSurface,
      surfaceTintColor: Colors.transparent,
      centerTitle: false,
      elevation: 0,
      titleTextStyle: TextStyle(
        color: colors.onSurface,
        fontSize: 24,
        fontWeight: FontWeight.w700,
      ),
    ),
    cardTheme: CardThemeData(
      color: surface,
      elevation: 0,
      margin: const EdgeInsets.symmetric(vertical: 5),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: colors.outlineVariant.withValues(alpha: .65)),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: surface,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: colors.outlineVariant),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: colors.outlineVariant),
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: surface,
      surfaceTintColor: Colors.transparent,
      indicatorColor: colors.primary.withValues(alpha: .13),
      height: 72,
      labelTextStyle: WidgetStateProperty.resolveWith(
        (s) => TextStyle(
          fontSize: 12,
          fontWeight: s.contains(WidgetState.selected)
              ? FontWeight.w700
              : FontWeight.w400,
          color: s.contains(WidgetState.selected)
              ? colors.primary
              : colors.onSurfaceVariant,
        ),
      ),
    ),
    dividerTheme: DividerThemeData(color: colors.outlineVariant, thickness: .7),
    chipTheme: base.chipTheme.copyWith(
      side: BorderSide.none,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
    ),
    listTileTheme: ListTileThemeData(
      iconColor: colors.onSurfaceVariant,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: colors.secondary,
        side: BorderSide(color: colors.secondary.withValues(alpha: .6)),
        minimumSize: const Size(44, 48),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size(44, 48),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    ),
  );
}

class AppearancePage extends StatefulWidget {
  const AppearancePage({super.key});
  @override
  State<AppearancePage> createState() => _AppearanceState();
}

class _AppearanceState extends State<AppearancePage> {
  @override
  void initState() {
    super.initState();
    FeatureDiscovery.record(DiscoverFeature.theme);
  }

  Future<void> save(Future<void> Function() action) async {
    try {
      await action();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('색상 설정을 저장하지 못했어요. 다시 시도해 주세요.')),
        );
      }
    }
  }

  Widget palette(
    String title,
    String subtitle,
    ValueNotifier<RadarAccent> selected,
    Future<void> Function(RadarAccent) apply,
  ) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(title, style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 4),
      Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
      const SizedBox(height: 10),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          for (final accent in RadarAccent.values)
            Tooltip(
              message: '$title ${accent.label}',
              child: ChoiceChip(
                label: Text(accent.label),
                avatar: CircleAvatar(backgroundColor: accent.seed, radius: 9),
                selected: selected.value == accent,
                selectedColor: identical(selected, radarSecondaryAccent)
                    ? Theme.of(context).colorScheme.secondaryContainer
                    : Theme.of(context).colorScheme.primaryContainer,
                labelStyle: TextStyle(
                  fontWeight: selected.value == accent
                      ? FontWeight.w700
                      : FontWeight.normal,
                ),
                onSelected: (_) => save(() => apply(accent)),
              ),
            ),
        ],
      ),
    ],
  );
  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: Listenable.merge([
      radarAccent,
      radarSecondaryAccent,
      radarThemeMode,
    ]),
    builder: (context, _) {
      final colors = Theme.of(context).colorScheme;
      return Scaffold(
        appBar: AppBar(
          title: const Text('화면 테마'),
          bottom: PreferredSize(
            preferredSize: Size.fromHeight(
              100 * MediaQuery.textScalerOf(context).scale(1).clamp(1, 2),
            ),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '색상 미리보기',
                    style: Theme.of(context).textTheme.labelSmall,
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: colors.primary,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            '컬러 1 · 주요 행동',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: colors.onPrimary,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: colors.secondaryContainer,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: colors.secondary.withValues(alpha: .5),
                            ),
                          ),
                          child: Text(
                            '컬러 2 · 수업·일정',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: colors.onSecondaryContainer,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
        body: AdaptiveContent(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              palette(
                '컬러 1',
                '주요 버튼과 선택한 메뉴에 사용해요.',
                radarAccent,
                saveRadarAccent,
              ),
              const SizedBox(height: 24),
              palette(
                '컬러 2',
                '수업·일정과 보조 강조에 사용해요.',
                radarSecondaryAccent,
                saveRadarSecondaryAccent,
              ),
              const SizedBox(height: 24),
              ExpansionTile(
                tilePadding: EdgeInsets.zero,
                title: const Text('추천 조합'),
                children: [
                  for (final pair in const [
                    (RadarAccent.teal, RadarAccent.orange),
                    (RadarAccent.blue, RadarAccent.rose),
                    (RadarAccent.indigo, RadarAccent.teal),
                  ])
                    ListTile(
                      leading: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CircleAvatar(
                            backgroundColor: pair.$1.seed,
                            radius: 8,
                          ),
                          const SizedBox(width: 5),
                          CircleAvatar(
                            backgroundColor: pair.$2.seed,
                            radius: 8,
                          ),
                        ],
                      ),
                      title: Text('${pair.$1.label} + ${pair.$2.label}'),
                      onTap: () => save(() async {
                        await saveRadarAccent(pair.$1);
                        await saveRadarSecondaryAccent(pair.$2);
                      }),
                    ),
                ],
              ),
              const SizedBox(height: 16),
              Text('밝기', style: Theme.of(context).textTheme.titleMedium),
              RadioGroup<ThemeMode>(
                groupValue: radarThemeMode.value,
                onChanged: (v) {
                  if (v != null) save(() => saveRadarTheme(v));
                },
                child: Card(
                  child: Column(
                    children: [
                      for (final m in ThemeMode.values)
                        RadioListTile<ThemeMode>(
                          value: m,
                          title: Text(switch (m) {
                            ThemeMode.system => '시스템 설정 따르기',
                            ThemeMode.light => '라이트',
                            ThemeMode.dark => '다크',
                          }),
                          secondary: Icon(switch (m) {
                            ThemeMode.system => Icons.brightness_auto_outlined,
                            ThemeMode.light => Icons.light_mode_outlined,
                            ThemeMode.dark => Icons.dark_mode_outlined,
                          }),
                        ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}

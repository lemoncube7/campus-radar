import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

final radarThemeMode = ValueNotifier<ThemeMode>(ThemeMode.system);

Future<void> loadRadarTheme() async {
  final value = (await SharedPreferences.getInstance()).getString('radarTheme');
  radarThemeMode.value =
      ThemeMode.values.where((m) => m.name == value).firstOrNull ??
      ThemeMode.system;
}

Future<void> saveRadarTheme(ThemeMode mode) async {
  final saved = await (await SharedPreferences.getInstance()).setString(
    'radarTheme',
    mode.name,
  );
  if (!saved) throw StateError('화면 테마를 저장하지 못했습니다.');
  radarThemeMode.value = mode;
}

ThemeData radarTheme(Brightness brightness) {
  final dark = brightness == Brightness.dark;
  final bg = Color(dark ? 0xff141a1c : 0xfff5f8f8);
  final surface = Color(dark ? 0xff1d2528 : 0xffffffff);
  final colors =
      ColorScheme.fromSeed(
        seedColor: const Color(0xff197e7b),
        brightness: brightness,
      ).copyWith(
        primary: Color(dark ? 0xff78d5cb : 0xff167b76),
        onPrimary: Color(dark ? 0xff073c39 : 0xffffffff),
        surface: surface,
        onSurface: Color(dark ? 0xffe6eeee : 0xff192729),
        onSurfaceVariant: Color(dark ? 0xffafc0c2 : 0xff586b6f),
        outlineVariant: Color(dark ? 0xff364449 : 0xffdce5e6),
      );
  final base = ThemeData(
    useMaterial3: true,
    colorScheme: colors,
    brightness: brightness,
  );
  return base.copyWith(
    scaffoldBackgroundColor: bg,
    textTheme: base.textTheme.apply(
      bodyColor: colors.onSurface,
      displayColor: colors.onSurface,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: bg,
      foregroundColor: colors.onSurface,
      surfaceTintColor: Colors.transparent,
      centerTitle: false,
      elevation: 0,
      titleTextStyle: TextStyle(
        color: colors.onSurface,
        fontSize: 24,
        fontWeight: FontWeight.w700,
      ),
    ),
    cardTheme: CardThemeData(
      color: surface,
      elevation: 0,
      margin: const EdgeInsets.symmetric(vertical: 5),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: colors.outlineVariant.withValues(alpha: .65)),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: surface,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: colors.outlineVariant),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: colors.outlineVariant),
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: surface,
      surfaceTintColor: Colors.transparent,
      indicatorColor: colors.primary.withValues(alpha: .13),
      height: 72,
      labelTextStyle: WidgetStateProperty.resolveWith(
        (s) => TextStyle(
          fontSize: 12,
          fontWeight: s.contains(WidgetState.selected)
              ? FontWeight.w700
              : FontWeight.w400,
          color: s.contains(WidgetState.selected)
              ? colors.primary
              : colors.onSurfaceVariant,
        ),
      ),
    ),
    dividerTheme: DividerThemeData(color: colors.outlineVariant, thickness: .7),
    chipTheme: base.chipTheme.copyWith(
      side: BorderSide.none,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
    ),
    listTileTheme: ListTileThemeData(
      iconColor: colors.onSurfaceVariant,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size(44, 48),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    ),
  );
}

class AppearancePage extends StatelessWidget {
  const AppearancePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('화면 테마')),
    body: ValueListenableBuilder<ThemeMode>(
      valueListenable: radarThemeMode,
      builder: (context, mode, _) => ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            '조용한 레이더',
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 8),
          const Text('편안하게 읽을 수 있는 화면을 선택하세요.'),
          const SizedBox(height: 24),
          RadioGroup<ThemeMode>(
            groupValue: mode,
            onChanged: (value) async {
              if (value == null) return;
              try {
                await saveRadarTheme(value);
              } catch (_) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('테마를 저장하지 못했습니다. 다시 시도해 주세요.'),
                    ),
                  );
                }
              }
            },
            child: Card(
              child: Column(
                children: [
                  for (final m in ThemeMode.values)
                    RadioListTile<ThemeMode>(
                      value: m,
                      title: Text(switch (m) {
                        ThemeMode.system => '시스템 설정 따르기',
                        ThemeMode.light => '라이트',
                        ThemeMode.dark => '다크',
                      }),
                      secondary: Icon(switch (m) {
                        ThemeMode.system => Icons.brightness_auto_outlined,
                        ThemeMode.light => Icons.light_mode_outlined,
                        ThemeMode.dark => Icons.dark_mode_outlined,
                      }),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

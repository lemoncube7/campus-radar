import 'dart:convert';

class ClassSlot {
  final String courseKey, course, source, room;
  final int weekday, start, end;
  const ClassSlot({
    required this.courseKey,
    required this.course,
    required this.weekday,
    required this.start,
    required this.end,
    this.room = '',
    this.source = '',
  });
  String get id => '$courseKey:$weekday:$start';
  Map<String, dynamic> toJson() => {
    'id': id,
    'courseKey': courseKey,
    'course': course,
    'weekday': weekday,
    'start': start,
    'end': end,
    'room': room,
    'source': source,
  };
  factory ClassSlot.fromJson(Map<String, dynamic> j) => ClassSlot(
    courseKey: j['courseKey'],
    course: j['course'],
    weekday: j['weekday'],
    start: j['start'],
    end: j['end'],
    room: j['room'] ?? '',
    source: j['source'] ?? '',
  );
}

String slotTime(int minutes) =>
    '${(minutes ~/ 60).toString().padLeft(2, '0')}:${(minutes % 60).toString().padLeft(2, '0')}';
const weekNames = ['월', '화', '수', '목', '금', '토', '일'];

/// Only explicit weekday + clock ranges are accepted. Period numbers are ambiguous.
List<ClassSlot> parsePlanSlots(String text, String key, String course) {
  text = text.replaceAll(r'\n', '\n');
  final heading = RegExp(
    r'강의\s*시간표(?:\s*\([^)]*\))?|강의\s*시간(?:\s*\([^)]*\))?|수업\s*시간표',
  ).firstMatch(text);
  if (heading != null) {
    text = text.substring(heading.end);
    final stop = RegExp(
      r'수업\s*운영\s*방식|수업\s*방식|강의\s*목표|교과목\s*개요|교재|교수',
    ).firstMatch(text);
    text = text.substring(
      0,
      stop?.start ?? (text.length < 800 ? text.length : 800),
    );
  }
  final result = <String, ClassSlot>{};
  final pattern = RegExp(
    r'(?<![가-힣0-9])([월화수목금토일](?:\s*[,·/]\s*[월화수목금토일])*)\s*(?:요일)?\s*[:：]?\s*(\d{1,2}):(\d{2})\s*[~∼～–—\-]\s*(\d{1,2}):(\d{2})(?:\s*\(([^)\n]{1,80})\))?',
  );
  for (final m in pattern.allMatches(text)) {
    final h1 = int.parse(m[2]!),
        n1 = int.parse(m[3]!),
        h2 = int.parse(m[4]!),
        n2 = int.parse(m[5]!);
    if (h1 > 23 || h2 > 23 || n1 > 59 || n2 > 59) continue;
    final start = h1 * 60 + n1, end = h2 * 60 + n2;
    if (end <= start) continue;
    for (final day in RegExp('[월화수목금토일]').allMatches(m[1]!)) {
      final slot = ClassSlot(
        courseKey: key,
        course: course,
        weekday: weekNames.indexOf(day[0]!) + 1,
        start: start,
        end: end,
        room: m[6] ?? '',
        source: m[0]!,
      );
      result[slot.id] = slot;
    }
  }
  return result.values.toList()..sort(
    (a, b) => a.weekday != b.weekday
        ? a.weekday.compareTo(b.weekday)
        : a.start.compareTo(b.start),
  );
}

List<ClassSlot> decodeSlots(String? raw) => raw == null
    ? []
    : (jsonDecode(raw) as List)
          .map((j) => ClassSlot.fromJson(Map<String, dynamic>.from(j)))
          .toList();

import 'campus_media.dart';
import 'dart:convert';
import 'dart:io';
import 'package:cookie_jar/cookie_jar.dart';
import 'package:encrypt/encrypt.dart' as enc;
import 'package:html/parser.dart' as html;

Map<String, String> courseAliases = {};
String courseLabel(String name) {
  final direct = courseAliases[name];
  if (direct != null) return direct;
  final normalized = name.replaceAll(RegExp(r'\s+'), '');
  for (final e in courseAliases.entries) {
    if (e.key.replaceAll(RegExp(r'\s+'), '') == normalized) return e.value;
  }
  return name;
}

String displayCourseText(String text) {
  var result = text;
  final entries = courseAliases.entries.toList()
    ..sort((a, b) => b.key.length.compareTo(a.key.length));
  for (final e in entries) {
    result = result.replaceAll(e.key, e.value);
  }
  return result;
}

String courseEventTitle(String title, String original, {String? oldLabel}) {
  final label = courseLabel(original);
  final bracket = RegExp(r'^\[([^\]]+)\]').firstMatch(title);
  if (bracket != null) {
    final inner = bracket.group(1)!;
    final time = RegExp(r'\s+\d{2}:\d{2}$').firstMatch(inner)?.group(0) ?? '';
    final course = inner
        .substring(0, inner.length - time.length)
        .replaceAll(RegExp(r'\s+'), '');
    if ({
      original,
      if (oldLabel != null) oldLabel,
    }.any((p) => p.replaceAll(RegExp(r'\s+'), '') == course)) {
      return '[$label$time]${title.substring(bracket.end)}';
    }
  }
  return title;
}

String textOf(Object? value) =>
    html.parse(value?.toString() ?? '').body?.text.trim() ?? '';
String str(Map<String, dynamic> m, String key) => m[key]?.toString() ?? '';

enum DeadlineState { unknown, overdue, withinDay, remaining }

String koreanTime(DateTime date) {
  final d = date.toUtc().add(const Duration(hours: 9));
  return '${d.year}/${d.month}/${d.day} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')} (한국 시간)';
}

DeadlineState deadlineState(DateTime? due, {DateTime? now}) {
  if (due == null) return DeadlineState.unknown;
  final remaining = due.difference(now ?? DateTime.now());
  if (remaining <= Duration.zero) return DeadlineState.overdue;
  if (remaining <= const Duration(days: 1)) return DeadlineState.withinDay;
  return DeadlineState.remaining;
}

DateTime? campusDate(String value) {
  final match = RegExp(
    r'(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2})(?::(\d{2}))?',
  ).firstMatch(value);
  if (match == null) return null;
  return DateTime.tryParse(
    '${match[1]}T${match[2]}:${match[3] ?? '00'}+09:00',
  )?.toUtc();
}

DateTime? laterDate(DateTime? a, DateTime? b) => a == null
    ? b
    : b == null
    ? a
    : a.isAfter(b)
    ? a
    : b;
DateTime? moduleStart(Map<String, dynamic> m) {
  DateTime? parse(dynamic value) {
    if (value == null) return null;
    final text = value.toString();
    return campusDate(text.length == 10 ? '$text 00:00' : text);
  }

  final weekly = m['weekseq_str_dt'] == null
      ? null
      : parse(
          '${m['weekseq_str_dt']} ${m['weekseq_str_dt_hour'] ?? '00'}:${m['weekseq_str_dt_min'] ?? '00'}',
        );
  return laterDate(weekly, parse(m['apply_str_dt']));
}

String remainingText(CampusItem i, {DateTime? now}) {
  if (i.done) return '완료';
  if (i.due == null) return '마감 미확인';
  final diff = i.due!.difference(now ?? DateTime.now());
  if (diff <= Duration.zero) return '기한 지남';
  if (diff.inDays > 0) return '${diff.inDays}일 ${diff.inHours % 24}시간 남음';
  if (diff.inHours > 0) return '${diff.inHours}시간 ${diff.inMinutes % 60}분 남음';
  return '${diff.inMinutes < 1 ? 1 : diff.inMinutes}분 남음';
}

List<String> itemChanges(CampusItem before, CampusItem after) {
  final changes = <String>[];
  if (before.due != after.due) {
    changes.add(
      '마감: ${before.due == null ? "미확인" : koreanTime(before.due!)} → ${after.due == null ? "미확인" : koreanTime(after.due!)}',
    );
  }
  if (before.title != after.title) {
    changes.add('제목: ${before.title} → ${after.title}');
  }
  String normalize(String v) => v.replaceAll(RegExp(r'\s+'), ' ').trim();
  if (normalize(before.body) != normalize(after.body)) {
    changes.add('설명 변경\n이전: ${before.body}\n변경: ${after.body}');
  }
  return changes;
}

class CampusItem {
  final String key,
      type,
      title,
      course,
      courseId,
      classNo,
      contentsId,
      status,
      body;
  final DateTime? due, startsAt;
  final bool published;
  final String bodyHtml;
  final List<CampusMedia> media;
  final Map<String, dynamic> context;
  CampusItem({
    required this.key,
    required this.type,
    required this.title,
    required this.course,
    required this.courseId,
    required this.classNo,
    required this.contentsId,
    required this.status,
    this.body = '',
    this.bodyHtml = '',
    this.media = const [],
    this.due,
    this.startsAt,
    this.published = true,
    required this.context,
  });
  bool get done => status == 'done';
  bool availableAt(DateTime now) =>
      published && (startsAt == null || !startsAt!.isAfter(now));
  Map<String, dynamic> toJson() => {
    'key': key,
    'type': type,
    'title': title,
    'course': course,
    'courseId': courseId,
    'classNo': classNo,
    'contentsId': contentsId,
    'status': status,
    'body': body,
    'bodyHtml': bodyHtml,
    'media': media.map((m) => m.toJson()).toList(),
    'due': due?.toIso8601String(),
    'startsAt': startsAt?.toIso8601String(),
    'published': published,
    'context': context,
  };
  factory CampusItem.fromJson(Map<String, dynamic> m) => CampusItem(
    key: m['key'],
    type: m['type'],
    title: m['title'],
    course: m['course'],
    courseId: m['courseId'],
    classNo: m['classNo'],
    contentsId: m['contentsId'],
    status: m['status'],
    body: m['body'] ?? '',
    bodyHtml: m['bodyHtml'] ?? '',
    media: (m['media'] as List? ?? [])
        .map((v) => CampusMedia.fromJson(Map<String, dynamic>.from(v)))
        .toList(),
    due: m['due'] == null ? null : DateTime.parse(m['due']),
    startsAt: DateTime.tryParse(m['startsAt'] ?? ''),
    published: m['published'] != false,
    context: Map<String, dynamic>.from(m['context']),
  );
}

class CampusException implements Exception {
  final String message;
  CampusException(this.message);
  @override
  String toString() => message;
}

class CampusNotice {
  final String id, title, course, body, bodyHtml;
  final List<CampusMedia> media;
  final DateTime? published;
  final bool read, bodyFetched;
  final Map<String, dynamic> context;
  CampusNotice({
    required this.id,
    required this.title,
    required this.course,
    required this.context,
    this.published,
    this.read = false,
    this.body = '',
    this.bodyHtml = '',
    this.media = const [],
    this.bodyFetched = false,
  });
  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'course': course,
    'body': body,
    'bodyHtml': bodyHtml,
    'media': media.map((m) => m.toJson()).toList(),
    'published': published?.toIso8601String(),
    'read': read,
    'bodyFetched': bodyFetched,
    'context': context,
  };
  factory CampusNotice.fromJson(Map<String, dynamic> m) => CampusNotice(
    id: m['id'],
    title: m['title'],
    course: m['course'],
    body: m['body'] ?? '',
    bodyHtml: m['bodyHtml'] ?? '',
    media: (m['media'] as List? ?? [])
        .map((v) => CampusMedia.fromJson(Map<String, dynamic>.from(v)))
        .toList(),
    published: DateTime.tryParse(m['published'] ?? ''),
    read: m['read'] == true,
    bodyFetched: m['bodyFetched'] == true,
    context: Map<String, dynamic>.from(m['context']),
  );
  CampusItem get item => CampusItem(
    key: 'NT:$id',
    type: 'NT',
    title: title,
    course: course,
    courseId: str(context, 'course_id'),
    classNo: str(context, 'class_no'),
    contentsId: id,
    status: read ? 'read' : 'unread',
    body: body,
    bodyHtml: bodyHtml,
    media: media,
    context: context,
  );
}

class CampusClient {
  final void Function(String)? diagnostic;
  CampusClient({this.diagnostic});
  static const learning = 'https://dcs-learning.cnu.ac.kr';
  static const loginHost = 'https://dcs-lcms.cnu.ac.kr';
  final HttpClient http = HttpClient()
    ..connectionTimeout = const Duration(seconds: 20);
  final CookieJar jar = CookieJar();
  String transportKey = '';
  List<Map<String, dynamic>> courseList = [];
  Future<String> request(
    Uri url, {
    Map<String, String>? form,
    int redirects = 0,
  }) async {
    if (url.scheme != 'https' ||
        !{'dcs-learning.cnu.ac.kr', 'dcs-lcms.cnu.ac.kr'}.contains(url.host)) {
      throw CampusException('예상하지 못한 로그인 이동 주소입니다.');
    }
    if (redirects > 10) throw CampusException('로그인 이동이 반복됩니다.');
    final req = await http.openUrl(form == null ? 'GET' : 'POST', url);
    req.followRedirects = false;
    req.headers.set(
      HttpHeaders.userAgentHeader,
      'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/130.0.0.0 Mobile Safari/537.36',
    );
    req.cookies.addAll(await jar.loadForRequest(url));
    if (form != null) {
      req.headers.set(
        HttpHeaders.contentTypeHeader,
        'application/x-www-form-urlencoded; charset=UTF-8',
      );
      req.headers.set('Origin', '${url.scheme}://${url.host}');
      req.headers.set('Referer', '${url.scheme}://${url.host}/home');
      req.headers.set('X-Requested-With', 'XMLHttpRequest');
      final bytes = utf8.encode(
        form.entries
            .map(
              (e) =>
                  '${Uri.encodeQueryComponent(e.key)}=${Uri.encodeQueryComponent(e.value)}',
            )
            .join('&'),
      );
      req.contentLength = bytes.length;
      req.add(bytes);
    }
    final response = await req.close().timeout(const Duration(seconds: 30));
    await jar.saveFromResponse(url, response.cookies);
    final body = await utf8.decoder
        .bind(response)
        .join()
        .timeout(const Duration(seconds: 30));
    final location = response.headers.value(HttpHeaders.locationHeader);
    if (response.isRedirect && location != null) {
      return request(
        url.resolve(location),
        form: response.statusCode == 307 || response.statusCode == 308
            ? form
            : null,
        redirects: redirects + 1,
      );
    }
    if (response.statusCode != 200) {
      throw CampusException('서버 응답 오류 (${response.statusCode}, ${url.path})');
    }
    return body;
  }

  Future<dynamic> api(
    String route,
    Map<String, dynamic>? payload, {
    String host = learning,
  }) async {
    diagnostic?.call('API ${Uri.parse(route).path}');
    final cipher = enc.Encrypter(
      enc.AES(enc.Key.fromUtf8(transportKey), mode: enc.AESMode.cbc),
    );
    final form = payload == null
        ? <String, String>{}
        : {
            'e': cipher
                .encrypt(jsonEncode(payload), iv: enc.IV.allZerosOfLength(16))
                .base64,
          };
    final raw = await request(Uri.parse('$host/api/v1$route'), form: form);
    Map<String, dynamic> result;
    try {
      result = jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      throw CampusException('로그인 만료 또는 데이터 형식 변경으로 수집하지 못했습니다.');
    }
    if (result['header']?['code'] != 200) {
      throw CampusException('사이버캠퍼스 요청이 거절됐습니다. 계정 또는 사이트 상태를 확인해 주세요.');
    }
    return result['body'];
  }

  Future<void> login(String id, String password) async {
    final page = html.parse(await request(Uri.parse('$learning/home')));
    final aesPath = page
        .querySelectorAll('script[src]')
        .map((e) => e.attributes['src']!)
        .where((s) => s.contains('gibberish-aes'))
        .firstOrNull;
    if (aesPath == null) throw CampusException('로그인 페이지 구조가 변경됐습니다.');
    final js = await request(Uri.parse(loginHost).resolve(aesPath));
    transportKey =
        RegExp(
          r"function getSecKey\(\)\s*\{\s*return '([^']+)'",
        ).firstMatch(js)?.group(1) ??
        '';
    if (transportKey.length != 32) {
      throw CampusException('로그인 통신 형식을 확인하지 못했습니다.');
    }
    final payload = <String, dynamic>{
      'redirect_url': '$learning/home',
      'key': page.querySelector('input[name=key]')?.attributes['value'] ?? '',
      'univ_no': 'CNU',
      'org_password': '',
      'user_id': id,
      'user_password': password,
      'cnu_auth': 'Y',
      'user_ip':
          page.querySelector('input[name=user_ip]')?.attributes['value'] ?? '',
    };
    final data = await api(
      '/user/apiCnuAuthLogin?redirectUrl=${Uri.encodeComponent('$learning/home')}',
      payload,
      host: loginHost,
    );
    if (data is! Map || data['redirect_url'] == null) {
      throw CampusException(
        '로그인이 승인되지 않았습니다. 아이디·비밀번호를 확인하고, 추가 인증이 필요한 경우 사이버캠퍼스에서 확인해 주세요.',
      );
    }
    final home = await request(Uri.parse(data['redirect_url']));
    if (home.contains('name="loginForm"')) {
      throw CampusException('로그인에 실패했습니다. 아이디·비밀번호 또는 학교의 추가 인증 여부를 확인해 주세요.');
    }
  }

  Future<List<CampusItem>> fetchItems() async {
    final terms = await api('/term/getYearTermList', null);
    final term = (terms['list'] as List)
        .cast<Map>()
        .where((m) => m['current_term_yn'] == 'Y')
        .firstOrNull;
    if (term == null) throw CampusException('현재 학기를 찾지 못했습니다.');
    final base = <String, dynamic>{
      'term_year': term['term_year'],
      'term_cd': term['term_cd'],
    };
    final courses = await api('/course/getStdMyCourseList', {
      ...base,
      'is_current': 'Y',
    });
    courseList = (courses['course_list'] as List)
        .map(
          (c) => <String, dynamic>{
            ...base,
            'course_id': c['course_id'],
            'class_no': c['class_no'],
            'course_nm': textOf(c['course_nm']),
          },
        )
        .toList();
    diagnostic?.call(
      'Course count: ${(courses['course_list'] as List).length}',
    );
    final result = <String, CampusItem>{};
    final reports = <String, Map<String, dynamic>>{};
    for (final raw in courses['course_list'] as List) {
      final c = Map<String, dynamic>.from(raw);
      await api('/course/addSessionCourseInfo', {
        'course_id': c['course_id'],
        'class_no': c['class_no'],
        ...base,
      });
      final weeks = await api('/week/getStdWeekList', {
        'course_id': c['course_id'],
        'class_no': c['class_no'],
        'is_current': 'N',
      });

      void visit(dynamic node) {
        if (node is List) {
          for (final child in node) {
            visit(child);
          }
        } else if (node is Map) {
          final m = Map<String, dynamic>.from(node);
          if (m['module_type'] != null) {
            diagnostic?.call('Module: ${m['module_type']}');
          }
          if (m['module_type'] == 'LR') {
            final reportId = m['report_no'] ?? m['contents_id'];
            if (reportId == null || reportId.toString().isEmpty) {
              throw CampusException('과제 식별자를 확인하지 못했습니다.');
            }
            final key = '${c['course_id']}:${c['class_no']}:$reportId';
            reports[key] = {
              ...m,
              'course_id': c['course_id'],
              'class_no': c['class_no'],
              'course_nm': c['course_nm'],
              'contents_id': reportId,
              'item_title_temp': m['report_nm'] ?? m['weekseq_nm'],
            };
          }
          if (m['module_type'] == 'LV' && m['weekseq_no'] != null) {
            final contentId =
                m['contents_id']?.toString() ?? str(m, 'weekseq_no');
            final key =
                'LV:${c['course_id']}:${c['class_no']}:${m['contents_id']}:${m['weekseq_no']}';
            final context = <String, dynamic>{
              ...base,
              'course_id': c['course_id'],
              'class_no': c['class_no'],
              'weekseq_no': m['weekseq_no'],
              'contents_id': m['contents_id'],
              'module_type': 'LV',
            };
            result[key] = CampusItem(
              key: key,
              type: 'LV',
              title: textOf(m['weekseq_nm']),
              course: textOf(c['course_nm']),
              courseId: str(c, 'course_id'),
              classNo: str(c, 'class_no'),
              contentsId: contentId,
              startsAt: moduleStart(m),
              published: m['learning_open_yn'] != 'N',
              status: m.containsKey('complete_yn')
                  ? m['complete_yn'] == 'Y'
                        ? 'done'
                        : 'pending'
                  : 'unknown',
              body: textOf(m['weekseq_content']),
              due: campusDate(
                '${m['weekseq_end_dt']} ${m['weekseq_end_dt_hour']}:${m['weekseq_end_dt_min']}:00',
              ),
              context: context,
            );
          }
          for (final value in m.values) {
            if (value is List || value is Map) visit(value);
          }
        }
      }

      if (weeks is! Map || weeks['week_list'] is! List) {
        throw CampusException('콘텐츠 목록 형식이 변경됐습니다.');
      }
      visit(weeks['week_list']);
      // Assignments outside the weekly curriculum are listed separately.
      final extra = await api('/week/getStdEtcList', {
        'course_id': c['course_id'],
        'is_current': 'N',
      });
      if (extra is! Map || extra['etc_list'] is! List) {
        throw CampusException('기타 학습요소 목록 형식이 변경됐습니다.');
      }
      visit(extra['etc_list']);
    }
    for (final m in reports.values) {
      final context = <String, dynamic>{
        ...base,
        'course_id': m['course_id'],
        'class_no': m['class_no'],
        'report_no': m['contents_id'],
        'weekseq_no': m['weekseq_no'],
        'item_id': m['item_id'],
      };
      await api('/course/addSessionCourseInfo', context);
      final detail = await api('/task/detail', context);
      final submitted = await api('/task/stdDetail', context);
      if (detail is! Map ||
          !detail.containsKey('report_no') ||
          (submitted != null && submitted is! Map)) {
        throw CampusException('과제 상세 형식이 변경됐습니다.');
      }
      final status = submitted == null || submitted['report_apply_no'] == null
          ? 'pending'
          : submitted['apply_yn'] == 'Y' && submitted['temp_yn'] != 'Y'
          ? 'done'
          : submitted['temp_yn'] == 'Y' || submitted['apply_yn'] == 'N'
          ? 'pending'
          : 'unknown';
      final key = 'LR:${m['course_id']}:${m['class_no']}:${m['contents_id']}';
      result[key] = CampusItem(
        key: key,
        type: 'LR',
        title: textOf(detail['report_nm'] ?? m['item_title_temp']),
        course: textOf(m['course_nm']),
        courseId: str(m, 'course_id'),
        classNo: str(m, 'class_no'),
        contentsId: str(m, 'contents_id'),
        status: status,
        startsAt: laterDate(
          moduleStart(m),
          campusDate(
            '${detail['report_apply_str_dt']} ${detail['report_apply_str_tm'] ?? '00:00'}',
          ),
        ),
        published: m['learning_open_yn'] != 'N',
        body: textOf(detail['report_content']),
        bodyHtml: '${detail['report_content'] ?? ''}',
        media: extractCampusMedia(
          '${detail['report_content'] ?? ''}',
          detail['attach_file_list'],
          notice: false,
        ),
        due:
            campusDate(
              '${detail['report_apply_end_dt']} ${detail['report_apply_end_tm']}',
            ) ??
            campusDate(str(m, 'info')),
        context: context,
      );
    }
    return result.values.toList()..sort(
      (a, b) =>
          (a.due ?? DateTime.utc(2100)).compareTo(b.due ?? DateTime.utc(2100)),
    );
  }

  Future<Map<String, dynamic>> navigation(CampusItem item) async {
    final ctx = await api('/course/addSessionCourseInfo', item.context);
    final cookies = <Map<String, String>>[];
    for (final host in [learning, loginHost]) {
      for (final c in await jar.loadForRequest(Uri.parse('$host/'))) {
        cookies.add({'url': host, 'cookie': c.toString()});
      }
    }
    return {
      'context': ctx['data'],
      'cookies': cookies,
      'url': item.type == 'NT'
          ? '$learning/std/noticeDetail?no=${Uri.encodeQueryComponent(item.contentsId)}'
          : '$learning${item.type == 'LR' ? '/std/taskView' : '/std/course'}',
      'target': item.contentsId,
    };
  }

  Future<List<CampusNotice>> fetchNotices() async {
    final terms = await api('/term/getYearTermList', null);
    final term = (terms['list'] as List)
        .cast<Map>()
        .where((m) => m['current_term_yn'] == 'Y')
        .firstOrNull;
    if (term == null) throw CampusException('공지의 현재 학기를 찾지 못했습니다.');
    final notices = <String, CampusNotice>{};
    for (var offset = 0; offset < 10000; offset += 100) {
      final data = await api('/board/std/notice/list', {
        'type': 'notice',
        'term_year': term['term_year'],
        'term_cd': term['term_cd'],
        'limit': 100,
        'offset': offset,
      });
      if (data is! Map || data['list'] is! List) {
        throw CampusException('공지 목록 형식이 변경됐습니다.');
      }
      final rows = data['list'] as List;
      for (final raw in rows) {
        final row = Map<String, dynamic>.from(raw);
        final id = str(row, 'boarditem_no');
        if (id.isEmpty || notices.containsKey(id)) {
          throw CampusException('공지 페이지를 정확하게 확인하지 못했습니다.');
        }
        notices[id] = CampusNotice(
          id: id,
          title: textOf(row['boarditem_title']),
          course: textOf(row['course_nm']),
          published: campusDate(str(row, 'insert_dt')),
          read: row['read_yn'] == 'Y',
          context: {
            'term_year': term['term_year'],
            'term_cd': term['term_cd'],
            'course_id': row['course_id'],
            'class_no': row['class_no'],
          },
        );
      }
      final total = int.tryParse('${data['tot_cnt']}');
      if ((total != null && notices.length >= total) || rows.length < 100) {
        return notices.values.toList()..sort(
          (a, b) => (b.published ?? DateTime.utc(1970)).compareTo(
            a.published ?? DateTime.utc(1970),
          ),
        );
      }
    }
    throw CampusException('공지 수가 많아 전체 수집을 끝내지 못했습니다.');
  }

  Future<CampusNotice> fetchNoticeBody(CampusNotice notice) async {
    final context = await api('/course/addSessionCourseInfo', notice.context);
    final session = context is Map && context['data'] is Map
        ? Map<String, dynamic>.from(context['data'])
        : <String, dynamic>{};
    final info = await api('/board/notice/info', {
      ...notice.context,
      ...session,
      'no': notice.id,
    });
    if (info is! Map || !info.containsKey('boarditem_content')) {
      throw CampusException('공지 본문을 확인하지 못했습니다.');
    }
    return CampusNotice(
      id: notice.id,
      title: notice.title,
      course: notice.course,
      context: notice.context,
      published: notice.published,
      read: notice.read,
      body: textOf(info['boarditem_content']),
      bodyHtml: '${info['boarditem_content'] ?? ''}',
      media: extractCampusMedia(
        '${info['boarditem_content'] ?? ''}',
        info['attach_file_list'],
        notice: true,
      ),
      bodyFetched: true,
    );
  }

  Future<({List<int> bytes, String mime})> downloadMedia(
    CampusMedia media, {
    int limit = 50 * 1024 * 1024,
  }) async {
    if (media.image && media.url.startsWith('data:') && media.supported) {
      if (media.url.length > limit * 2) {
        throw CampusException('이미지 크기 제한을 초과했습니다.');
      }
      final bytes = base64Decode(media.url.split(',').last);
      if (bytes.length > limit) throw CampusException('이미지 크기 제한을 초과했습니다.');
      return (
        bytes: bytes,
        mime: media.url.substring(5, media.url.indexOf(';')),
      );
    }
    var url = Uri.parse(media.url);
    var form = media.form;
    for (var hop = 0; hop < 6; hop++) {
      if (!allowedMediaUri(url)) {
        throw CampusException('외부 이미지·파일은 사이버캠퍼스에서 확인해 주세요.');
      }
      final req = await http.openUrl(form.isEmpty ? 'GET' : 'POST', url);
      req.followRedirects = false;
      req.cookies.addAll(await jar.loadForRequest(url));
      req.headers.set(HttpHeaders.refererHeader, '$learning/home');
      req.headers.set(HttpHeaders.userAgentHeader, 'Mozilla/5.0 CampusRadar');
      if (form.isNotEmpty) {
        final cipher = enc.Encrypter(
          enc.AES(enc.Key.fromUtf8(transportKey), mode: enc.AESMode.cbc),
        );
        final e = cipher
            .encrypt(jsonEncode(form), iv: enc.IV.allZerosOfLength(16))
            .base64;
        req.headers.contentType = ContentType(
          'application',
          'x-www-form-urlencoded',
          charset: 'utf-8',
        );
        req.write('e=${Uri.encodeQueryComponent(e)}');
      }
      final res = await req.close().timeout(const Duration(seconds: 25));
      await jar.saveFromResponse(url, res.cookies);
      if (res.isRedirect) {
        final location = res.headers.value('location');
        await res.listen((_) {}).cancel();
        if (location == null) throw CampusException('파일 이동 주소가 없습니다.');
        url = url.resolve(location);
        if (res.statusCode != 307 && res.statusCode != 308) form = {};
        continue;
      }
      if (res.statusCode != 200 || res.contentLength > limit) {
        await res.listen((_) {}).cancel();
        throw CampusException(
          res.contentLength > limit
              ? '파일당 50MB 저장 제한을 초과했습니다.'
              : '파일 응답 오류 (${res.statusCode})',
        );
      }
      var mime =
          res.headers.contentType?.mimeType ?? 'application/octet-stream';
      if (mime == 'text/html' || mime == 'application/json') {
        await res.listen((_) {}).cancel();
        throw CampusException('파일 대신 로그인 또는 오류 응답이 왔습니다. 다시 수집해 주세요.');
      }
      final bytes = <int>[];
      await for (final chunk in res.timeout(const Duration(seconds: 25))) {
        bytes.addAll(chunk);
        if (bytes.length > limit) {
          throw CampusException('파일당 50MB 저장 제한을 초과했습니다.');
        }
      }
      if (bytes.isEmpty) throw CampusException('파일 내용이 비어 있습니다.');
      // Some CMS downloads use octet-stream for valid image bytes.
      if (media.image) {
        if (bytes.length >= 8 &&
            bytes[0] == 137 &&
            bytes[1] == 80 &&
            bytes[2] == 78 &&
            bytes[3] == 71) {
          mime = 'image/png';
        } else if (bytes.length >= 3 &&
            bytes[0] == 255 &&
            bytes[1] == 216 &&
            bytes[2] == 255) {
          mime = 'image/jpeg';
        } else if (bytes.length >= 6 &&
            ascii
                .decode(bytes.take(6).toList(), allowInvalid: true)
                .startsWith('GIF8')) {
          mime = 'image/gif';
        } else if (bytes.length >= 12 &&
            ascii.decode(bytes.take(4).toList(), allowInvalid: true) ==
                'RIFF' &&
            ascii.decode(bytes.sublist(8, 12), allowInvalid: true) == 'WEBP') {
          mime = 'image/webp';
        } else {
          throw CampusException(
            '지원하는 이미지 형식(PNG·JPEG·GIF·WebP)이 아닙니다. 원문에서 확인해 주세요.',
          );
        }
      }
      if (mime == 'application/octet-stream' &&
          utf8
              .decode(bytes.take(256).toList(), allowMalformed: true)
              .trimLeft()
              .toLowerCase()
              .startsWith('<!doctype html')) {
        throw CampusException('파일 대신 로그인 화면이 왔습니다. 다시 수집해 주세요.');
      }
      return (bytes: bytes, mime: mime);
    }
    throw CampusException('파일 이동이 반복됩니다.');
  }

  void close() => http.close(force: true);
}

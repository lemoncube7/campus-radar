import 'package:html/parser.dart' as html;
import 'campus_media.dart';

String textOf(Object? value) =>
    html.parse(value?.toString() ?? '').body?.text.trim() ?? '';
String str(Map<String, dynamic> m, String key) => m[key]?.toString() ?? '';

enum DeadlineState { unknown, overdue, withinDay, remaining }

String koreanTime(DateTime date) {
  final d = date.toUtc().add(const Duration(hours: 9));
  return '${d.year}/${d.month}/${d.day} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')} (한국 시간)';
}

DeadlineState deadlineState(DateTime? due, {DateTime? now}) {
  if (due == null) return DeadlineState.unknown;
  final remaining = due.difference(now ?? DateTime.now());
  if (remaining <= Duration.zero) return DeadlineState.overdue;
  if (remaining <= const Duration(days: 1)) return DeadlineState.withinDay;
  return DeadlineState.remaining;
}

DateTime? campusDate(String value) {
  final match = RegExp(
    r'(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2})(?::(\d{2}))?',
  ).firstMatch(value);
  if (match == null) return null;
  return DateTime.tryParse(
    '${match[1]}T${match[2]}:${match[3] ?? '00'}+09:00',
  )?.toUtc();
}

DateTime? laterDate(DateTime? a, DateTime? b) => a == null
    ? b
    : b == null
    ? a
    : a.isAfter(b)
    ? a
    : b;
DateTime? moduleStart(Map<String, dynamic> m) {
  DateTime? parse(dynamic value) {
    if (value == null) return null;
    final text = value.toString();
    return campusDate(text.length == 10 ? '$text 00:00' : text);
  }

  final weekly = m['weekseq_str_dt'] == null
      ? null
      : parse(
          '${m['weekseq_str_dt']} ${m['weekseq_str_dt_hour'] ?? '00'}:${m['weekseq_str_dt_min'] ?? '00'}',
        );
  return laterDate(weekly, parse(m['apply_str_dt']));
}

String remainingText(CampusItem i, {DateTime? now}) {
  if (i.done) return '완료';
  if (i.due == null) return '마감 미확인';
  final diff = i.due!.difference(now ?? DateTime.now());
  if (diff <= Duration.zero) return '기한 지남';
  if (diff.inDays > 0) return '${diff.inDays}일 ${diff.inHours % 24}시간 남음';
  if (diff.inHours > 0) return '${diff.inHours}시간 ${diff.inMinutes % 60}분 남음';
  return '${diff.inMinutes < 1 ? 1 : diff.inMinutes}분 남음';
}

List<String> itemChanges(CampusItem before, CampusItem after) {
  final changes = <String>[];
  if (before.due != after.due) {
    changes.add(
      '마감: ${before.due == null ? "미확인" : koreanTime(before.due!)} → ${after.due == null ? "미확인" : koreanTime(after.due!)}',
    );
  }
  if (before.title != after.title) {
    changes.add('제목: ${before.title} → ${after.title}');
  }
  String normalize(String v) => v.replaceAll(RegExp(r'\s+'), ' ').trim();
  if (normalize(before.body) != normalize(after.body)) {
    changes.add('설명 변경\n이전: ${before.body}\n변경: ${after.body}');
  }
  return changes;
}

class CampusItem {
  final String key,
      type,
      title,
      course,
      courseId,
      classNo,
      contentsId,
      status,
      body;
  final DateTime? due, startsAt;
  final bool published;
  final bool? attendanceRequired;
  final String bodyHtml;
  final List<CampusMedia> media;
  final Map<String, dynamic> context;
  CampusItem({
    required this.key,
    required this.type,
    required this.title,
    required this.course,
    required this.courseId,
    required this.classNo,
    required this.contentsId,
    required this.status,
    this.body = '',
    this.bodyHtml = '',
    this.media = const [],
    this.due,
    this.startsAt,
    this.published = true,
    this.attendanceRequired,
    required this.context,
  });
  String get attendanceLabel => attendanceRequired == true
      ? '출석 반영'
      : attendanceRequired == false
      ? '출석 미반영'
      : '출석 반영 여부 미확인';
  bool get done => status == 'done';
  bool availableAt(DateTime now) =>
      published && (startsAt == null || !startsAt!.isAfter(now));
  Map<String, dynamic> toJson() => {
    'key': key,
    'type': type,
    'title': title,
    'course': course,
    'courseId': courseId,
    'classNo': classNo,
    'contentsId': contentsId,
    'status': status,
    'body': body,
    'bodyHtml': bodyHtml,
    'media': media.map((m) => m.toJson()).toList(),
    'due': due?.toIso8601String(),
    'startsAt': startsAt?.toIso8601String(),
    'published': published,
    'attendanceRequired': attendanceRequired,
    'context': context,
  };
  factory CampusItem.fromJson(Map<String, dynamic> m) => CampusItem(
    key: m['key'],
    type: m['type'],
    title: m['title'],
    course: m['course'],
    courseId: m['courseId'],
    classNo: m['classNo'],
    contentsId: m['contentsId'],
    status: m['status'],
    body: m['body'] ?? '',
    bodyHtml: m['bodyHtml'] ?? '',
    media: (m['media'] as List? ?? [])
        .map((v) => CampusMedia.fromJson(Map<String, dynamic>.from(v)))
        .toList(),
    due: m['due'] == null ? null : DateTime.parse(m['due']),
    startsAt: DateTime.tryParse(m['startsAt'] ?? ''),
    published: m['published'] != false,
    attendanceRequired: m['attendanceRequired'] as bool?,
    context: Map<String, dynamic>.from(m['context']),
  );
}

class CampusNotice {
  final String id, title, course, body, bodyHtml;
  final List<CampusMedia> media;
  final DateTime? published;
  final bool read, bodyFetched;
  final Map<String, dynamic> context;
  CampusNotice({
    required this.id,
    required this.title,
    required this.course,
    required this.context,
    this.published,
    this.read = false,
    this.body = '',
    this.bodyHtml = '',
    this.media = const [],
    this.bodyFetched = false,
  });
  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'course': course,
    'body': body,
    'bodyHtml': bodyHtml,
    'media': media.map((m) => m.toJson()).toList(),
    'published': published?.toIso8601String(),
    'read': read,
    'bodyFetched': bodyFetched,
    'context': context,
  };
  factory CampusNotice.fromJson(Map<String, dynamic> m) => CampusNotice(
    id: m['id'],
    title: m['title'],
    course: m['course'],
    body: m['body'] ?? '',
    bodyHtml: m['bodyHtml'] ?? '',
    media: (m['media'] as List? ?? [])
        .map((v) => CampusMedia.fromJson(Map<String, dynamic>.from(v)))
        .toList(),
    published: DateTime.tryParse(m['published'] ?? ''),
    read: m['read'] == true,
    bodyFetched: m['bodyFetched'] == true,
    context: Map<String, dynamic>.from(m['context']),
  );
  CampusItem get item => CampusItem(
    key: 'NT:$id',
    type: 'NT',
    title: title,
    course: course,
    courseId: str(context, 'course_id'),
    classNo: str(context, 'class_no'),
    contentsId: id,
    status: read ? 'read' : 'unread',
    body: body,
    bodyHtml: bodyHtml,
    media: media,
    context: context,
  );
}

import 'package:flutter/widgets.dart';

/// Permission dialogs briefly make the app inactive; they are not a new visit.
class ForegroundEntry {
  bool _away = false;
  bool update(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.hidden) {
      _away = true;
    }
    if (state != AppLifecycleState.resumed) return false;
    final reopened = _away;
    _away = false;
    return reopened;
  }
}

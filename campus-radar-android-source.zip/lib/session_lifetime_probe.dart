import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';
import 'app_credentials.dart';
import 'app_storage.dart';
import 'campus.dart';
import 'campus_session.dart';
import 'session_lifetime_repository.dart';
import 'session_scope.dart';

const sessionLifetimeTask = 'campus-radar-session-lifetime';

/// Retire the experiment without changing the user's normal collection choice.
Future<void> retireSessionExploration() async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  if (prefs.getBool('schoolLifetimeProbeEnabled') == true) {
    await prefs.setBool('schoolLifetimeProbeEnabled', false);
  }
}

Future<bool> sessionLifetimeProbeEnabled() async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  return prefs.getBool('schoolLifetimeProbeEnabled') ?? false;
}

Future<void> setSessionLifetimeProbe(bool enabled) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setBool('schoolLifetimeProbeEnabled', enabled);
  await registerSessionLifetimeProbe();
}

Future<void> registerSessionLifetimeProbe() async {
  if (!Platform.isAndroid) return;
  if (!await sessionLifetimeProbeEnabled()) {
    await Workmanager().cancelByUniqueName(sessionLifetimeTask);
    return;
  }
  // This wakes an eligibility check, not a school request every 15 minutes.
  await Workmanager().registerPeriodicTask(
    sessionLifetimeTask,
    sessionLifetimeTask,
    frequency: const Duration(minutes: 15),
    existingWorkPolicy: ExistingPeriodicWorkPolicy.keep,
    constraints: Constraints(networkType: NetworkType.connected),
  );
}

/// Returns successfully for a hold/offline interval: the next periodic wakeup
/// checks persisted eligibility. The exclusive flag masks ordinary auto sync;
/// only this worker may prepare/reconnect the session under the chosen hold.
Future<void> runSessionLifetimeProbe() async {
  if (!await sessionLifetimeProbeEnabled()) {
    return;
  }
  final store = await Store.open();
  final client = CampusClient();
  try {
    final scope = await SessionScope.capture(store);
    final id = await credentials.read(key: 'id');
    final pw = await credentials.read(key: 'pw');
    if (id == null || pw == null) return;
    final lostAt = await store.meta('schoolSessionLostEpoch') == scope.epoch
        ? DateTime.tryParse(await store.meta('schoolSessionLostAt') ?? '')
        : null;
    if (lostAt != null) {
      final minutes = await schoolReconnectMinutes();
      if (minutes == null ||
          DateTime.now().toUtc().isBefore(
            lostAt.add(Duration(minutes: minutes)),
          )) {
        return;
      }
    }
    var prepare = false;
    final reserved = await SessionLifetimeRepository(store).change(
      scope.epoch,
      (state) {
        prepare =
            lostAt != null ||
            state.session.isEmpty ||
            state.lastValidatedAt == null ||
            state.lost;
        return state.reserveProbe(
          DateTime.now().toUtc().millisecondsSinceEpoch,
          prepareSession: prepare,
        );
      },
    );
    if (!reserved) return;
    if (!await sessionLifetimeProbeEnabled()) {
      return;
    }
    await scope.verify();
    await client.connectSchool(
      id,
      pw,
      allowFreshLogin: prepare,
      forSessionTest: true,
    );
    await store.log(
      'sync',
      '세션 지속시간 탐색 성공',
      prepare
          ? '전용 테스트의 기준 연결을 준비했어요. 기존 세션을 우선 사용하고, 필요한 초기 로그인·재연결은 설정한 대기 정책을 따릅니다.'
          : '기존 세션으로 수강 과목을 확인했어요. 실제 연결 간격으로 관측값을 갱신했으며 새 로그인은 하지 않았어요.',
    );
  } on CampusReconnectDeferred {
    await store.log(
      'sync',
      '세션 지속시간 탐색 보류',
      '학교 재연결 대기 중이거나 다른 연결이 준비 중이에요. 다음 작업에서 확인해요.',
    );
  } on SessionChanged {
    // Old-account worker must not write diagnostics into the new account.
  } catch (error) {
    await store.log(
      'sync',
      '세션 지속시간 탐색 중단',
      '실패 종류: ${error.runtimeType}. 통신 오류를 세션 만료 시간으로 계산하지 않으며 즉시 재로그인하지 않아요.',
    );
  } finally {
    client.close();
    await store.db.close();
  }
}

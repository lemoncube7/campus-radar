import 'session_scope.dart';
import 'calendar_window.dart';
import 'dart:convert';
import 'ai.dart';
import 'campus.dart';
import 'services.dart';

Future<Map<String, dynamic>> confirmAiCandidate(
  Store store,
  String key,
  CampusNotice notice,
  ScheduleCandidate candidate, {
  bool calendar = false,
}) async {
  final scope = await SessionScope.capture(store);
  if (candidate.action != 'add') {
    throw const AiFailure('변경·취소 일정은 기존 일정을 확인해 주세요.');
  }
  final old = Map<String, dynamic>.from(
    jsonDecode(await store.meta('aiState:$key') ?? '{}'),
  );
  final start =
      DateTime.tryParse(old['start'] ?? '') ??
      (candidate.date.isEmpty
          ? null
          : candidate.time.isEmpty
          ? strictDate(candidate.date)
          : DateTime.parse('${candidate.date}T${candidate.time}:00+09:00'));
  if (start == null) {
    throw const AiFailure('날짜를 먼저 입력해 주세요.', code: 'date_required');
  }
  final allDay = old['allDay'] as bool? ?? candidate.time.isEmpty;
  final title = courseEventTitle(
    old['title'] as String? ?? '[${notice.course}] ${candidate.title}',
    notice.course,
    oldLabel: old['courseLabel'] as String?,
  );
  if (calendar) {
    if (await bridge.invokeMethod<bool>('calendarPermission') != true) {
      throw const AiFailure('캘린더 권한이 필요합니다.');
    }
    final window = calendarWindow(
      start,
      allDay: allDay,
      deadline: old['deadline'] as bool? ?? candidate.deadline,
      end: old.containsKey('end')
          ? DateTime.tryParse(old['end'] ?? '')
          : candidate.endInstant,
    );
    await scope.verify();
    await bridge.invokeMethod('calendarWrite', {
      'key': key,
      'title': title,
      'start': window.$1.millisecondsSinceEpoch,
      'end': window.$2.millisecondsSinceEpoch,
      'allDay': allDay,
      'description':
          '공지: ${notice.title}\n${candidate.description}\nhttps://dcs-learning.cnu.ac.kr/home',
    });
  }
  final next = {
    ...old,
    'status': 'confirmed',
    'courseName': notice.course,
    'courseLabel': courseLabel(notice.course),
    'title': title,
    'start': start.toUtc().toIso8601String(),
    'date': allDay
        ? start.toUtc().toIso8601String().substring(0, 10)
        : start
              .toUtc()
              .add(const Duration(hours: 9))
              .toIso8601String()
              .substring(0, 10),
    'allDay': allDay,
    'deadline': old['deadline'] as bool? ?? candidate.deadline,
    'end': old.containsKey('end')
        ? old['end']
        : candidate.endInstant?.toUtc().toIso8601String(),
    'calendarSent': calendar || old['calendarSent'] == true,
  };
  await scope.verify();
  await store.setMeta('aiState:$key', jsonEncode(next));
  await store.log(
    'ai',
    calendar ? 'AI 일정 확정·캘린더 전송' : 'AI 일정 바로 확정',
    notice.title,
  );
  return old;
}

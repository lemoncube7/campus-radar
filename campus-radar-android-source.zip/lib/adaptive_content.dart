import 'package:flutter/material.dart';

/// Constrain only the content, leaving navigation and scrollables full-height.
class AdaptiveContent extends StatelessWidget {
  final Widget child;
  final double maxWidth;
  const AdaptiveContent({super.key, required this.child, this.maxWidth = 880});
  @override
  Widget build(BuildContext context) => Align(
    alignment: Alignment.topCenter,
    child: ConstrainedBox(
      constraints: BoxConstraints(maxWidth: maxWidth),
      child: SizedBox(width: double.infinity, child: child),
    ),
  );
}

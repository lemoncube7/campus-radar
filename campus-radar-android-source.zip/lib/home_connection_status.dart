import 'package:flutter/material.dart';
import 'background_status_page.dart';
import 'services.dart';
import 'task_presentation.dart';

class HomeConnectionStatus extends StatelessWidget {
  final bool testing, automatic, busy;
  final String? last, error;
  final Future<void> Function() refresh;
  const HomeConnectionStatus({
    super.key,
    required this.testing,
    required this.automatic,
    required this.busy,
    required this.last,
    required this.error,
    required this.refresh,
  });
  @override
  Widget build(BuildContext context) {
    final problem = error?.isNotEmpty == true;
    final needsAttention = testing || problem || !automatic;
    final stamp = DateTime.tryParse(last ?? '');
    final message = testing
        ? '세션 테스트 중 · 평소 수집 일시 중지'
        : problem
        ? '최근 수집을 마치지 못했어요. 저장된 내용은 유지돼요.'
        : !automatic
        ? '자동 수집을 꺼 두었어요.'
        : stamp == null
        ? '아직 수집된 기록이 없어요.'
        : '마지막 확인 ${formatDate(stamp)}';
    Future<void> settings() async {
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const BackgroundStatusPage()),
      );
      await refresh();
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: needsAttention
              ? Theme.of(context).colorScheme.surfaceContainerHigh
              : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Padding(
          padding: EdgeInsets.all(needsAttention ? 12 : 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('포털 연결됨', style: Theme.of(context).textTheme.labelSmall),
              Row(
                children: [
                  Icon(
                    testing
                        ? Icons.science_outlined
                        : problem
                        ? Icons.sync_problem
                        : !automatic
                        ? Icons.pause_circle_outline
                        : Icons.sync,
                    size: 18,
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      message,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ),
                  if (testing)
                    TextButton(
                      onPressed: busy
                          ? null
                          : () async {
                              try {
                                await setExclusiveSessionLifetimeTest(false);
                                await refresh();
                              } catch (_) {
                                if (context.mounted) await settings();
                              }
                            },
                      child: const Text('테스트 종료'),
                    )
                  else
                    TextButton(
                      onPressed: settings,
                      child: Text(needsAttention ? '연결 확인' : '상태'),
                    ),
                ],
              ),
              if (problem && !testing)
                Text(
                  error!,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              if (needsAttention && stamp != null)
                Text(
                  '마지막 성공 ${formatDate(stamp)}',
                  style: Theme.of(context).textTheme.labelSmall,
                ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'auto_approval_settings.dart';
import 'navigation_contract.dart';
import 'native_contract.dart';
import 'automation_settings_card.dart';
import 'ui_formatters.dart';
import 'ai_protocol.dart';
import 'app_storage.dart';
import 'native_bridge.dart';
import 'app_credentials.dart';
import 'ui_refresh.dart';
import 'dart:io';
import 'ios_features.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';
import 'ai_automation.dart';
import 'package:flutter/material.dart';

class AiSettingsPage extends StatefulWidget {
  const AiSettingsPage({super.key});
  @override
  State<AiSettingsPage> createState() => _AiSettingsState();
}

class _AiSettingsState extends State<AiSettingsPage> {
  final keyInput = TextEditingController();
  bool saved = false, consent = false, busy = true;
  int requests = 0;
  String? message;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final key = await credentials.read(key: 'geminiApiKey');
      final store = await Store.open();
      try {
        final agreed = await store.meta('aiConsent') == aiConsentVersion;
        final day = DateTime.now()
            .toUtc()
            .add(const Duration(hours: 9))
            .toIso8601String()
            .substring(0, 10);
        final count =
            int.tryParse(await store.meta('aiRequests:$day') ?? '0') ?? 0;
        if (mounted) {
          setState(() {
            saved = key?.isNotEmpty == true;
            consent = agreed;
            requests = count;
            busy = false;
          });
        }
      } finally {
        await store.db.close();
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          busy = false;
          message = '설정을 읽지 못했습니다.';
        });
      }
    }
  }

  Future<void> save({bool remove = false}) async {
    if (!remove && (!consent || (!saved && keyInput.text.trim().isEmpty))) {
      setState(() => message = '개인 키 입력과 외부 전송 동의를 확인해 주세요.');
      return;
    }
    setState(() => busy = true);
    try {
      if (remove) {
        await credentials.delete(key: 'geminiApiKey');
      } else if (keyInput.text.trim().isNotEmpty) {
        final key = keyInput.text.trim();
        if (key.length < 20 || key.contains(RegExp(r'\s'))) {
          throw const AiFailure('API 키 형식을 확인해 주세요.');
        }
        await credentials.write(key: 'geminiApiKey', value: key);
      }
      final store = await Store.open();
      try {
        await store.setAiSetting(
          AiSetting.aiConsent,
          remove ? '' : aiConsentVersion,
        );
        if (!remove && keyInput.text.trim().isNotEmpty) {
          final jobs = await store.db.query(
            'meta',
            where: 'id LIKE ?',
            whereArgs: ['aiQueue:%'],
          );
          for (final row in jobs) {
            final job = Map<String, dynamic>.from(
              jsonDecode(row['value'] as String),
            );
            if (job['status'] == 'failed' &&
                job['errorCode'] == 'credentials') {
              await store.setMeta(
                row['id'] as String,
                jsonEncode({
                  ...job,
                  'status': 'pending',
                  'attempts': 0,
                  'retryAt': '',
                  'error': '',
                }),
              );
            }
          }
          await store.setMeta('aiCooldown', '0');
          await scheduleAiWork();
        }

        if (remove) {
          await store.setAiSetting(AiSetting.aiAuto, 'no');
          await store.setAiSetting(AiSetting.aiAutoApprove, 'no');
          await store.setAiSetting(AiSetting.aiSummary, 'no');
          final p = await SharedPreferences.getInstance();
          await p.setBool('aiSummaryEnabled', false);
          await p.remove('aiSummaryText');
          if (Platform.isAndroid) await Workmanager().cancelByTag('campus-ai');
          if (Platform.isIOS) await updateIosFeatures();
        }
        await store.log(
          'ai',
          remove ? 'AI 키 삭제' : 'AI 설정 저장',
          remove
              ? 'AI 새 분석을 비활성화했습니다. 기존 분석 결과는 남습니다.'
              : '개인 키를 기기 보안 저장소에 저장했습니다.',
        );
      } finally {
        await store.db.close();
      }
      keyInput.clear();
      if (mounted) {
        setState(() {
          saved = !remove;
          consent = !remove;
          message = remove ? '키를 삭제했습니다.' : '저장했습니다. 아래에서 자동 분석과 요약을 켤 수 있어요.';
        });
      }
    } catch (e) {
      if (mounted) setState(() => message = userError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    keyInput.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('AI 공지 분석 설정')),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Text(
          saved ? 'AI 키 설정' : 'AI 시작하기',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        const Text(
          '개인 API 키를 입력한 사람만 사용하는 선택 기능입니다. 키가 없어도 과제 알림과 캘린더는 사용할 수 있습니다.',
        ),
        const SizedBox(height: 12),
        Card(
          child: ListTile(
            leading: Icon(saved ? Icons.key : Icons.key_off_outlined),
            title: Text(saved ? 'API 키 저장됨' : 'API 키 미등록'),
            subtitle: const Text('개인 Gemini 키 · 저장된 값은 다시 표시하지 않습니다.'),
          ),
        ),
        const SectionHeading('키와 전송 동의'),
        TextField(
          controller: keyInput,
          obscureText: true,
          enableSuggestions: false,
          autocorrect: false,
          decoration: InputDecoration(
            labelText: saved ? '키 변경 (변경할 때만 입력)' : 'Gemini API 키',
          ),
        ),
        const SizedBox(height: 12),
        const Text(
          'AI Studio에서 결제가 연결되지 않은 무료 등급 프로젝트의 키를 사용하세요. 유료 프로젝트의 키는 과금될 수 있습니다. 앱은 Google의 프로젝트 등급이나 전체 잔여량을 확인할 수 없습니다.',
        ),
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          value: consent,
          onChanged: busy ? null : (v) => setState(() => consent = v ?? false),
          title: const Text('공지 외부 전송에 동의'),
          subtitle: const Text(
            '수동 분석 또는 자동 분석을 켜면 제목·과목명·게시 시각·본문과 같은 과목의 저장된 시간표를 Google Gemini에 보냅니다. 시간표로 추정한 값은 후보에 따로 표시합니다. 포털 계정·쿠키는 보내지 않습니다. 무료 API 입력·출력은 Google 제품 개선에 사용될 수 있습니다.',
          ),
        ),
        const Text(
          '이미지·첨부파일은 분석하지 않습니다. AI가 만든 날짜와 할 일은 원문을 확인한 뒤 캘린더에 저장하세요.',
        ),
        const SizedBox(height: 12),
        Text(
          '오늘 이 앱에서 보낸 분석 요청: $requests회 (한국 날짜 기준, 실패 포함)\nGoogle 프로젝트 전체 사용량·잔여량과는 다릅니다.',
        ),
        if (message != null)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(message!),
          ),
        FilledButton(onPressed: busy ? null : save, child: const Text('저장')),
        if (saved)
          TextButton(
            onPressed: busy ? null : () => save(remove: true),
            child: const Text('키 삭제·AI 사용 중지'),
          ),
        ListTile(
          title: const Text('분석 기록'),
          subtitle: const Text('처리 결과·실패 원인·재시도'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => navigateTo(context, AiInboxDestination(records: true)),
        ),
        ListTile(
          title: const Text('일정 추가 기본 위치'),
          subtitle: const Text('앱 일정함 또는 휴대전화 캘린더'),
          onTap: () async {
            final v = await showDialog<bool>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: const Text('일정 추가 기본 위치'),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(ctx, false),
                    child: const Text('앱 일정함'),
                  ),
                  FilledButton(
                    onPressed: () => Navigator.pop(ctx, true),
                    child: const Text('캘린더에도 추가'),
                  ),
                ],
              ),
            );
            if (v == null) return;
            final store = await Store.open();
            try {
              await store.setMeta('aiCalendarDefault', v ? 'yes' : 'no');
            } finally {
              await store.db.close();
            }
          },
        ),
        if (!busy) AutoApprovalSettings(key: ValueKey('approval-$saved')),
        const SectionHeading('자동화', subtitle: '사용할 기능만 선택하세요.'),
        if (!busy) AutomationControls(key: ValueKey(saved)),
        const SizedBox(height: 12),
        for (final link in const {
          '키 발급·무료 등급 확인': 'https://aistudio.google.com/api-keys',
          '사용량 한도 확인': 'https://aistudio.google.com/rate-limit',
        }.entries)
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(link.key),
            subtitle: Text(link.value),
            trailing: const Icon(Icons.open_in_new),
            onTap: () async {
              try {
                await bridge.invokeNative(NativeMethod.openExternalUrl, {
                  'url': link.value,
                });
              } catch (_) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('브라우저를 열지 못했습니다. 잠시 후 다시 시도해 주세요.'),
                    ),
                  );
                }
              }
            },
          ),
      ],
    ),
  );
}

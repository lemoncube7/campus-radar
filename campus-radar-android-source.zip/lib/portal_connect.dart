import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'campus.dart';

typedef ReadCredential = Future<String?> Function(String key);
typedef WriteCredential = Future<void> Function(String key, String? value);

/// Validate remotely before touching either of the previously saved credentials.
Future<void> verifyAndSavePortal({
  required String id,
  required String password,
  required Future<void> Function(String, String) authenticate,
  required ReadCredential read,
  required WriteCredential write,
}) async {
  if (id.trim().isEmpty || password.isEmpty) {
    throw CampusException('아이디와 비밀번호를 모두 입력해 주세요.');
  }
  await authenticate(id.trim(), password);
  final previousId = await read('id'), previousPw = await read('pw');
  try {
    await write('pw', password);
    await write('id', id.trim());
    if (await read('id') != id.trim() || await read('pw') != password) {
      throw StateError('credential readback');
    }
  } catch (_) {
    try {
      await write('pw', previousPw);
      await write('id', previousId);
    } catch (_) {
      throw CampusException(
        '보안 저장소 오류로 계정 저장을 완료하지 못했습니다. 앱을 다시 열어 연결 상태를 확인해 주세요.',
      );
    }
    throw CampusException('계정을 저장하지 못했습니다. 기존 계정은 유지했습니다. 다시 시도해 주세요.');
  }
}

String portalConnectionError(Object e) {
  if (e is SocketException) return '네트워크에 연결하지 못했습니다. 인터넷 연결을 확인해 주세요.';
  if (e is TimeoutException) return '학교 서버 응답이 늦어지고 있습니다. 잠시 후 다시 시도해 주세요.';
  if (e is HandshakeException) {
    return '학교 서버와 보안 연결을 맺지 못했습니다. 잠시 후 다시 시도해 주세요.';
  }
  if (e is CampusException) return e.message;
  return '연결을 완료하지 못했습니다. 잠시 후 다시 시도해 주세요.';
}

class PortalConnectSheet extends StatefulWidget {
  final Future<void> Function(String, String) connect;
  const PortalConnectSheet({super.key, required this.connect});
  @override
  State<PortalConnectSheet> createState() => _PortalConnectSheetState();
}

class _PortalConnectSheetState extends State<PortalConnectSheet> {
  final id = TextEditingController(), pw = TextEditingController();
  bool busy = false, obscure = true;
  String? error;
  @override
  void dispose() {
    id.dispose();
    pw.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    if (busy) return;
    if (id.text.trim().isEmpty || pw.text.isEmpty) {
      setState(() => error = '아이디와 비밀번호를 모두 입력해 주세요.');
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() {
      busy = true;
      error = null;
    });
    try {
      await widget.connect(id.text.trim(), pw.text);
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) setState(() => error = portalConnectionError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: !busy,
    child: SafeArea(
      child: SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(
          24,
          0,
          24,
          24 + MediaQuery.viewInsetsOf(context).bottom,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('충남대 포털 연결', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 8),
            const Text('로그인을 확인한 뒤 계정을 저장합니다.'),
            const SizedBox(height: 24),
            TextField(
              controller: id,
              enabled: !busy,
              autocorrect: false,
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(
                labelText: '학번 / 아이디',
                prefixIcon: Icon(Icons.person_outline),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: pw,
              enabled: !busy,
              obscureText: obscure,
              autocorrect: false,
              enableSuggestions: false,
              onSubmitted: (_) => submit(),
              decoration: InputDecoration(
                labelText: '포털 비밀번호',
                prefixIcon: const Icon(Icons.lock_outline),
                suffixIcon: IconButton(
                  tooltip: obscure ? '비밀번호 보기' : '비밀번호 숨기기',
                  onPressed: busy
                      ? null
                      : () => setState(() => obscure = !obscure),
                  icon: Icon(
                    obscure
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined,
                  ),
                ),
              ),
            ),
            if (error != null)
              Padding(
                padding: const EdgeInsets.only(top: 16),
                child: Semantics(
                  liveRegion: true,
                  child: Text(
                    error!,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.error,
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 16),
            const Text(
              '계정은 이 기기에 암호화해 저장합니다. 사이버캠퍼스 확인에 사용하며 개발자 서버로 보내지 않습니다.',
            ),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: busy ? null : submit,
              child: Text(busy ? '로그인 확인 중…' : '포털 연결'),
            ),
            TextButton(
              onPressed: busy ? null : () => Navigator.pop(context, false),
              child: const Text('나중에'),
            ),
          ],
        ),
      ),
    ),
  );
}

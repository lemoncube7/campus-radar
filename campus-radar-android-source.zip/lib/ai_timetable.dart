import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'campus.dart';
import 'services.dart';
import 'timetable_model.dart';

String schoolDate(DateTime day) => day.toIso8601String().substring(0, 10);

/// Send only saved, valid class slots. No raw syllabus, portal identifiers or credentials.
Future<Map<String, dynamic>> aiTimetableContext(
  Store store, {
  CampusNotice? notice,
  String? courseId,
  DateTime? now,
}) async {
  List<ClassSlot> slots;
  try {
    slots = decodeSlots(await store.meta('timetableEntries'));
  } catch (_) {
    slots = [];
  }
  slots = slots
      .where(
        (s) =>
            s.weekday >= 1 &&
            s.weekday <= 7 &&
            s.start >= 0 &&
            s.end < 1440 &&
            s.end > s.start &&
            s.course.isNotEmpty,
      )
      .toList();
  final id = notice?.context['course_id'],
      section = notice?.context['class_no'];
  if (notice != null) {
    if (id != null && section != null) {
      slots = slots.where((s) => s.courseKey == '$id:$section').toList();
    } else {
      final named = slots
          .where(
            (s) =>
                s.course.replaceAll(RegExp(r'\s+'), '') ==
                notice.course.replaceAll(RegExp(r'\s+'), ''),
          )
          .toList();
      slots = named.map((s) => s.courseKey).toSet().length == 1 ? named : [];
    }
  } else if (courseId != null) {
    slots = slots.where((s) => s.courseKey == courseId).toList();
  }
  slots.sort(
    (a, b) => '${a.course}:${a.weekday}:${a.start}'.compareTo(
      '${b.course}:${b.weekday}:${b.start}',
    ),
  );
  slots = slots.take(notice == null ? 64 : 24).toList();
  final reference = notice == null
      ? (now ?? DateTime.now()).toUtc()
      : notice.published?.toUtc();
  final school = reference?.add(const Duration(hours: 9));
  final mapped = <Map<String, dynamic>>[];
  for (final row in slots.indexed) {
    final s = row.$2;
    final next = school == null
        ? null
        : nextClassStart(school, s.weekday, s.start);
    mapped.add({
      'id': 'T${row.$1 + 1}',
      'course': s.course,
      'weekday': s.weekday,
      'start': slotTime(s.start),
      'end': slotTime(s.end),
      'room': s.room,
      if (next != null) 'nextDate': schoolDate(next),
    });
  }
  final occurrences = <Map<String, dynamic>>[];
  if (school != null) {
    for (var offset = 0; offset < 15; offset++) {
      final day = DateTime.utc(
        school.year,
        school.month,
        school.day,
      ).add(Duration(days: offset));
      for (final s in mapped.where((s) => s['weekday'] == day.weekday)) {
        final start = DateTime.parse('${schoolDate(day)}T${s['start']}:00Z');
        if (!start.isAfter(school)) continue;
        occurrences.add({
          'slotId': s['id'],
          'course': s['course'],
          'date': schoolDate(day),
          'start': s['start'],
          'end': s['end'],
          'room': s['room'],
        });
      }
    }
    occurrences.sort(
      (a, b) =>
          '${a['date']} ${a['start']}'.compareTo('${b['date']} ${b['start']}'),
    );
  }
  return {
    'referenceAt': reference?.toIso8601String(),
    'referenceBasis': notice == null ? '현재 시각' : '공지 게시 시각',
    'timezone': 'Asia/Seoul',
    'savedAt': await store.meta('timetableSavedAt'),
    'limits':
        '사용자가 저장한 정규 시간표. 휴강·보강·학기 종료를 자동 반영한 실제 출석 일정이 아님. 공지의 명시 날짜·시각 우선.',
    'slots': mapped,
    'upcoming': occurrences.take(64).toList(),
  };
}

DateTime nextClassStart(DateTime school, int weekday, int minute) {
  var result = DateTime.utc(
    school.year,
    school.month,
    school.day,
    minute ~/ 60,
    minute % 60,
  ).add(Duration(days: (weekday - school.weekday + 7) % 7));
  if (!result.isAfter(school)) result = result.add(const Duration(days: 7));
  return result;
}

String timetableContextHash(Map<String, dynamic> context) => sha256
    .convert(
      utf8.encode(
        jsonEncode({
          'slots': context['slots'],
          'referenceAt': context['referenceAt'],
        }),
      ),
    )
    .toString();

/// Establish provenance from the context actually sent, never from model-supplied proof.
Map<String, dynamic> groundTimetableInference(
  Map<String, dynamic> event,
  String evidence,
  Map<String, dynamic> context,
) {
  final fields = event['inferredFields'] ?? [];
  final ids = event['timetableIds'] ?? [];
  if (fields is! List ||
      fields.length > 4 ||
      fields.any((f) => !['date', 'time', 'endDate', 'endTime'].contains(f)) ||
      ids is! List ||
      ids.length > 1) {
    throw const FormatException('시간표 추정 형식 오류');
  }
  if (fields.isEmpty) return {};
  if (ids.isEmpty || !RegExp(r'수업|강의|시간|교시').hasMatch(evidence)) {
    throw const FormatException('시간표 추정에는 정규 수업을 가리키는 공지 근거가 필요합니다.');
  }
  final slots = List<Map<String, dynamic>>.from(context['slots'] ?? []);
  final selected = <Map<String, dynamic>>[];
  for (final id in ids.toSet()) {
    final matches = slots.where((s) => s['id'] == id).toList();
    if (matches.length != 1) {
      throw const FormatException('전송하지 않은 시간표를 선택했습니다.');
    }
    selected.add(matches.single);
  }
  final date = DateTime.tryParse('${event['date']}T00:00:00Z');
  if (date == null || selected.any((s) => s['weekday'] != date.weekday)) {
    throw const FormatException('일정 날짜의 요일과 해당 과목 시간표가 다릅니다.');
  }
  if (fields.contains('date')) {
    final anchor = DateTime.tryParse(
      '${context['referenceAt']}',
    )?.toUtc().add(const Duration(hours: 9));
    if (anchor == null) {
      throw const FormatException('공지 게시 시각이 없어 다음 수업 날짜를 정할 수 없습니다.');
    }
    final compact = evidence.replaceAll(RegExp(r'\s+'), '');
    if (RegExp(r'다음(수업|강의|시간)').hasMatch(compact)) {
      final upcoming = List<Map<String, dynamic>>.from(
        context['upcoming'] ?? [],
      );
      if (upcoming.isEmpty ||
          upcoming.first['date'] != event['date'] ||
          !selected.any((s) => s['id'] == upcoming.first['slotId'])) {
        throw const FormatException('다음 수업은 공지 게시 후 첫 수업을 기준으로 해야 합니다.');
      }
    } else if (compact.contains('다음주') || compact.contains('이번주')) {
      final monday = DateTime.utc(anchor.year, anchor.month, anchor.day)
          .subtract(Duration(days: anchor.weekday - 1))
          .add(Duration(days: compact.contains('다음주') ? 7 : 0));
      if (date.isBefore(monday) ||
          !date.isBefore(monday.add(const Duration(days: 7)))) {
        throw const FormatException('공지에서 말한 주와 추정한 수업 날짜가 다릅니다.');
      }
    } else {
      throw const FormatException('날짜를 추정할 상대 수업 표현이 없습니다.');
    }
  }
  for (final field in ['time', 'endTime']) {
    if (!fields.contains(field)) continue;
    final allowed = selected
        .map((s) => s[field == 'endTime' ? 'end' : 'start'])
        .toSet();
    if (field == 'time' &&
        RegExp(r'수업\s*(종료|끝)|강의\s*(종료|끝)').hasMatch(evidence)) {
      allowed.addAll(selected.map((s) => s['end']));
    }
    if (!allowed.contains(event[field])) {
      throw const FormatException('추정 시각과 저장된 수업 시간이 다릅니다.');
    }
  }
  if ((fields.contains('endDate') ||
          fields.contains('endTime') ||
          fields.contains('date') && '${event['endDate'] ?? ''}'.isNotEmpty) &&
      event['endDate'] != event['date']) {
    throw const FormatException('정규 수업의 종료 날짜는 시작 날짜와 같아야 합니다.');
  }
  final basis = selected
      .map(
        (s) =>
            '${s['course']} ${weekNames[(s['weekday'] as int) - 1]} ${s['start']}–${s['end']}',
      )
      .join(' / ');
  return {
    'fields': fields.toSet().toList(),
    'date': event['date'],
    'time': event['time'],
    'endDate': event['endDate'] ?? '',
    'endTime': event['endTime'] ?? '',
    'basis': '시간표로 추정: $basis · ${context['referenceBasis']} 기준. 휴강·보강은 원문 확인.',
    'referenceAt': context['referenceAt'],
    'savedAt': context['savedAt'],
  };
}

import 'dart:convert';
import 'package:html/parser.dart' as html;
import 'package:html/dom.dart';

const campusMediaHosts = {'dcs-learning.cnu.ac.kr', 'dcs-lcms.cnu.ac.kr'};
bool allowedMediaUri(Uri u) =>
    u.scheme == 'https' &&
    campusMediaHosts.contains(u.host) &&
    u.userInfo.isEmpty &&
    (!u.hasPort || u.port == 443);

class CampusMedia {
  final String name, url;
  final bool image;
  final int? size;
  final Map<String, String> form;
  const CampusMedia({
    required this.name,
    required this.url,
    this.image = false,
    this.size,
    this.form = const {},
  });
  String get identity => jsonEncode([url, form, name]);
  bool get supported =>
      allowedMediaUri(Uri.tryParse(url) ?? Uri()) ||
      (image &&
          RegExp(r'^data:image/(png|jpeg|gif|webp);base64,').hasMatch(url));
  Map<String, dynamic> toJson() => {
    'name': name,
    'url': url,
    'image': image,
    'size': size,
    'form': form,
  };
  factory CampusMedia.fromJson(Map<String, dynamic> j) => CampusMedia(
    name: j['name'] as String,
    url: j['url'] as String,
    image: j['image'] == true,
    size: j['size'] as int?,
    form: Map<String, String>.from(j['form'] ?? {}),
  );
}

String resolveMediaUrl(String s) {
  try {
    return Uri.parse(
      'https://dcs-learning.cnu.ac.kr/',
    ).resolve(s.trim()).toString();
  } catch (_) {
    return s;
  }
}

/// Only metadata is retained. No scripts, cookies, viewer tokens or student details.
List<CampusMedia> extractCampusMedia(
  String body,
  dynamic files, {
  required bool notice,
}) {
  final result = <CampusMedia>[];
  final doc = html.parseFragment(body);
  for (final e in doc.querySelectorAll('img')) {
    final cms = e.attributes['data-cms-no'];
    final src = e.attributes['src'] ?? e.attributes['data-src'] ?? '';
    if ((cms == null || cms.isEmpty) && src.isEmpty) continue;
    result.add(
      CampusMedia(
        name: e.attributes['alt']?.trim().isNotEmpty == true
            ? e.attributes['alt']!
            : '본문 이미지 ${result.where((m) => m.image).length + 1}',
        url: cms != null && cms.isNotEmpty
            ? 'https://dcs-lcms.cnu.ac.kr/api/v1/share/downloadFile'
            : resolveMediaUrl(src),
        image: true,
        form: cms != null && cms.isNotEmpty ? {'file_no': cms} : {},
      ),
    );
  }
  if (files is List) {
    for (final f in files.whereType<Map>()) {
      final name = '${f['file_name'] ?? '첨부파일'}';
      final cms = '${f['cms_file_no'] ?? ''}';
      final path = '${f['save_name'] ?? ''}';
      if (f['upload_type'] == 'cms' && cms.isNotEmpty) {
        result.add(
          CampusMedia(
            name: name,
            url:
                'https://dcs-lcms.cnu.ac.kr/api/v1/${notice ? 'file/downloadSingleFile' : 'share/downloadFile'}',
            form: {'file_no': cms},
            size: int.tryParse('${f['file_size']}'),
          ),
        );
      } else if (path.isNotEmpty) {
        result.add(
          CampusMedia(
            name: name,
            url: resolveMediaUrl(
              path.startsWith('/file') ? path : '/file$path',
            ),
            size: int.tryParse('${f['file_size']}'),
          ),
        );
      }
    }
  }
  for (final a in doc.querySelectorAll('a[href]')) {
    final href = a.attributes['href']!;
    final u = Uri.tryParse(resolveMediaUrl(href));
    if (u == null ||
        !RegExp(
          r'\.(pdf|hwp|hwpx|docx?|xlsx?|pptx?|zip|txt|png|jpe?g)(?:$|\?)',
          caseSensitive: false,
        ).hasMatch(u.toString())) {
      continue;
    }
    result.add(
      CampusMedia(
        name: a.text.trim().isEmpty ? u.pathSegments.last : a.text.trim(),
        url: u.toString(),
      ),
    );
  }
  final seen = <String>{};
  return result.where((m) => seen.add(m.identity)).toList();
}

class BodyPiece {
  final String text;
  final int? imageIndex;
  const BodyPiece(this.text, [this.imageIndex]);
}

List<BodyPiece> campusBodyPieces(String body) {
  final pieces = <BodyPiece>[];
  var buffer = StringBuffer();
  var imageIndex = 0;
  void flush() {
    final t = buffer.toString().replaceAll(RegExp(r'\n{3,}'), '\n\n').trim();
    if (t.isNotEmpty) pieces.add(BodyPiece(t));
    buffer = StringBuffer();
  }

  void walk(Node n) {
    if (n is Text) {
      buffer.write(n.text);
      return;
    }
    if (n is Element) {
      if ({
        'script',
        'style',
        'iframe',
        'object',
        'embed',
      }.contains(n.localName)) {
        return;
      }
      if (n.localName == 'img') {
        if ((n.attributes['src'] ?? n.attributes['data-src'] ?? '')
                .isNotEmpty ||
            (n.attributes['data-cms-no'] ?? '').isNotEmpty) {
          flush();
          pieces.add(BodyPiece('', imageIndex++));
        }
        return;
      }
      if (n.localName == 'br') {
        buffer.writeln();
        return;
      }
      if ({
        'p',
        'div',
        'li',
        'tr',
        'h1',
        'h2',
        'h3',
        'figure',
      }.contains(n.localName)) {
        buffer.writeln();
      }
      for (final c in n.nodes) {
        walk(c);
      }
      if (n.localName == 'td' || n.localName == 'th') buffer.write('  ');
      if ({
        'p',
        'div',
        'li',
        'tr',
        'h1',
        'h2',
        'h3',
        'figure',
      }.contains(n.localName)) {
        buffer.writeln();
      }
      return;
    }
    for (final c in n.nodes) {
      walk(c);
    }
  }

  walk(html.parseFragment(body));
  flush();
  return pieces;
}

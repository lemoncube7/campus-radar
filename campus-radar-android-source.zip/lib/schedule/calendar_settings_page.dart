import 'package:campus_radar/core/storage_keys.dart';
import 'package:campus_radar/home/feature_discovery.dart';
import 'package:campus_radar/core/app_storage.dart';
import 'package:campus_radar/navigation/navigation_contract.dart';
import 'package:campus_radar/core/native_contract.dart';
import 'package:campus_radar/core/ui_formatters.dart';
import 'package:campus_radar/ai/ai_protocol.dart';
import 'package:campus_radar/core/native_bridge.dart';
import 'package:campus_radar/core/app_logging.dart';
import 'package:campus_radar/core/ui_refresh.dart';
import 'dart:io';
import 'package:flutter/material.dart';

// The native calendar list only exposes `account` (Android ACCOUNT_NAME,
// iOS source title, Windows fixed label), not ACCOUNT_TYPE. So device
// calendars are matched by exact, known names instead of substrings:
// a substring such as 'phone' or '기기' also matches account calendars
// (e.g. 'myphone@gmail.com', '기기 동기화 일정').
const _deviceAccountNames = {
  // Not verified on every OEM/iOS locale; widen only with a real device
  // sample. The first four were substrings in f64bfdb.
  'phone',
  'local',
  'device',
  'sec.contact',
  'my calendar', // expected Samsung local calendar name (English)
  '내 캘린더', // expected Samsung local calendar name (Korean)
  'on my iphone', // expected iOS local source title
  '나의 iphone',
  '이 pc에 저장', // Windows .ics export target (lib/platform/desktop.dart)
};

// Display names accepted only when the account name is empty. An empty
// account alone is not enough: it only means the provider gave no name.
const _deviceCalendarNames = {'my calendar', '내 캘린더', '기기 캘린더', '디바이스 캘린더'};

/// Whether [c] looks like a calendar stored on this device rather than in an
/// online account. Calendars whose account is an e-mail address are never
/// treated as device calendars.
bool isDeviceCalendar(Map<String, dynamic> c) {
  final account = (c['account'] as String? ?? '').trim().toLowerCase();
  final name = (c['name'] as String? ?? '').trim().toLowerCase();
  if (account.contains('@')) return false;
  if (_deviceAccountNames.contains(account)) return true;
  return account.isEmpty && _deviceCalendarNames.contains(name);
}

/// Finds the on-device/local calendar from the available list.
/// Returns null when none matches; callers must not fall back to an
/// account calendar, so nothing is saved to an external account silently.
Map<String, dynamic>? findDeviceCalendar(List<Map<String, dynamic>> list) {
  for (final c in list) {
    if (isDeviceCalendar(c)) return c;
  }
  return null;
}

/// Calendar to save into: the one already linked ([savedId] from
/// `calendarSettings`) while it is still listed, otherwise the device
/// calendar. Returns null when neither exists.
Map<String, dynamic>? resolveTargetCalendar(
  List<Map<String, dynamic>> list,
  Object? savedId,
) {
  if (savedId != null) {
    for (final c in list) {
      if (c['id'] == savedId) return c;
    }
  }
  return findDeviceCalendar(list);
}

class CalendarSettingsPage extends StatefulWidget {
  const CalendarSettingsPage({super.key});
  @override
  State<CalendarSettingsPage> createState() => _CalendarSettingsState();
}

class _CalendarSettingsState extends State<CalendarSettingsPage> {
  List<Map<String, dynamic>> calendars = [];
  Object? selected;
  bool auto = false, busy = true, aiAuto = false;
  String? message;
  @override
  void initState() {
    super.initState();
    FeatureDiscovery.record(DiscoverFeature.calendar);
    load();
  }

  Future<void> load({bool request = false}) async {
    setState(() => busy = true);
    try {
      if (request &&
          await bridge.invokeNative<bool>(NativeMethod.calendarPermission) !=
              true) {
        throw const AiFailure('캘린더 권한을 허용해야 전송할 수 있어요.');
      }
      final settings =
          await bridge.invokeNativeMap<String, dynamic>(
            NativeMethod.calendarSettings,
          ) ??
          {};
      bool ai = false;
      Store? store;
      try {
        store = await Store.open();
        ai = await store.meta(MetaKey.aiCalendarDefault) == 'yes';
      } catch (_) {
        // Calendar settings remain available when local AI meta is unavailable.
      } finally {
        await store?.db.close();
      }
      final allowed = settings['allowed'] == true;
      final data = allowed
          ? await bridge.invokeNativeList<dynamic>(NativeMethod.calendarList) ??
                []
          : [];
      if (mounted) {
        setState(() {
          calendars = data
              .map((c) => Map<String, dynamic>.from(c as Map))
              .toList();
          // Keep the calendar the user already linked; only when it is gone
          // use the device calendar. Never fall back to an account calendar.
          final target = resolveTargetCalendar(
            calendars,
            settings['calendarId'],
          );
          selected = target?['id'];
          auto = settings['auto'] == true && target != null;
          aiAuto = ai;
          message = allowed
              ? (calendars.isEmpty
                    ? '저장할 수 있는 캘린더가 없어요. 캘린더 앱에서 계정을 먼저 연결해 주세요.'
                    : target == null
                    ? '자동 전송을 켜려면 기기 캘린더가 필요해요.'
                    : null)
              : '캘린더 권한을 허용하면 기기 캘린더를 찾아 저장해요.';
        });
      }
    } catch (e) {
      if (mounted) setState(() => message = userError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> save() async {
    if (selected == null) {
      setState(() => message = '기기 캘린더를 찾지 못해 저장하지 않았어요. 외부 계정 캘린더에는 자동으로 저장하지 않아요.');
      return;
    }
    setState(() => busy = true);
    try {
      await bridge.invokeNative(NativeMethod.calendarConfigure, {
        'calendarId': selected,
        'auto': auto,
      });
      Store? store;
      try {
        store = await Store.open();
        await store.setMeta(MetaKey.aiCalendarDefault, aiAuto ? 'yes' : 'no');
      } catch (_) {
        // Keep native calendar configuration working even if local meta fails.
      } finally {
        await store?.db.close();
      }
      await systemLog(
        '캘린더 설정 저장',
        auto ? '미완료·공개·시작된 항목의 앞으로 남은 마감 자동 전송 켜짐' : '자동 전송 꺼짐 · 개별 전송 가능',
      );
      await bridge.invokeNative(NativeMethod.calendarSync);
      if (mounted) setState(() => message = '저장했어요. 결과는 캘린더와 수집 로그에서 확인하세요.');
    } catch (e) {
      if (mounted) setState(() => message = userError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> unlink() async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('캘린더 연결을 해제할까요?'),
        content: const Text(
          '자동 전송과 기존 일정 갱신을 중지해요. 캘린더에 저장한 일정은 삭제하지 않아요. 다시 연결해 자동 전송하면 기존 일정과 중복될 수 있어요.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('연결 해제'),
          ),
        ],
      ),
    );
    if (yes != true) return;
    await bridge.invokeNative(NativeMethod.calendarUnlink);
    await load();
  }

  String _calendarDisplayName(Map<String, dynamic> c) {
    final name = (c['name'] as String? ?? '').trim();
    return name.isEmpty ? '캘린더' : name;
  }

  String _calendarAccountText(Map<String, dynamic> c) {
    final account = (c['account'] as String? ?? '').trim();
    return account.isEmpty ? '계정 정보 없음' : account;
  }

  Future<void> selectCalendar(Object nextId) async {
    if (busy || nextId == selected) return;
    Map<String, dynamic>? target;
    for (final c in calendars) {
      if (c['id'] == nextId) {
        target = c;
        break;
      }
    }
    if (target == null) return;
    if (!isDeviceCalendar(target)) {
      final name = _calendarDisplayName(target);
      final account = (target['account'] as String? ?? '').trim();
      final label =
          (account.isEmpty || account.toLowerCase() == name.toLowerCase())
              ? name
              : '$name ($account)';
      final yes = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('계정 캘린더에 저장할까요?'),
          content: Text(
            '$label 캘린더는 기기 전용이 아니라 계정에 연결된 캘린더예요.\n\n'
            '그 계정의 동기화 설정에 따라 저장한 일정이 서버(예: Google)로 올라갈 수 있어요.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('취소'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('확인'),
            ),
          ],
        ),
      );
      if (yes != true || !mounted) return;
    }
    await applyCalendarSelection(target);
  }

  Future<void> applyCalendarSelection(Map<String, dynamic> target) async {
    final id = target['id'];
    if (id == null) return;
    setState(() => busy = true);
    try {
      await bridge.invokeNative(NativeMethod.calendarConfigure, {
        'calendarId': id,
        'auto': auto,
      });
      if (mounted) {
        setState(() {
          selected = id;
          message = isDeviceCalendar(target)
              ? '기기 캘린더로 변경했어요.'
              : '선택한 캘린더로 변경했어요.';
        });
      }
    } catch (e) {
      if (mounted) setState(() => message = userError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(Platform.isWindows ? '일정 파일 저장' : '캘린더 전송 설정')),
    bottomNavigationBar: PinnedAction(
      child: FilledButton(
        onPressed: busy ? null : save,
        child: Text(busy ? '동기화 중…' : '설정 저장·지금 동기화'),
      ),
    ),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Text(
          Platform.isIOS
              ? 'iPhone에만 저장되는 기기 캘린더에 저장해요. iCloud·Google 등 계정 캘린더는 자동으로 고르지 않아요. 연결된 일정의 중복 방지와 갱신을 위해 캘린더 접근 권한이 필요해요.'
              : '계정에 연결되지 않은 스마트폰 기기 캘린더에 저장해요. Google 등 계정 캘린더는 자동으로 고르지 않아요. 이미 연결해 둔 캘린더가 있으면 그 연결을 그대로 써요.',
        ),
        const SizedBox(height: 12),
        FilledButton.tonal(
          onPressed: busy ? null : () => load(request: true),
          child: const Text('캘린더 권한 허용·목록 새로고침'),
        ),
        const SectionHeading('저장 위치', subtitle: '기본으로 스마트폰 기기 캘린더에 저장'),
        Builder(
          builder: (context) {
            final target = resolveTargetCalendar(calendars, selected);
            if (target == null) {
              return const Card(
                child: ListTile(
                  leading: Icon(Icons.warning_amber_rounded),
                  title: Text('기기 캘린더를 찾지 못했어요'),
                  subtitle: Text(
                    '외부 계정 캘린더에는 자동으로 저장하지 않아요. 기본 캘린더 앱과 권한을 확인하거나 아래 고급 설정에서 직접 골라 주세요.',
                  ),
                ),
              );
            }
            if (!isDeviceCalendar(target)) {
              final account = (target['account'] as String? ?? '').trim();
              return Card(
                child: ListTile(
                  isThreeLine: true,
                  leading: const Icon(Icons.event_outlined),
                  title: Text(_calendarDisplayName(target)),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const SizedBox(height: 6),
                      const Chip(
                        visualDensity: VisualDensity.compact,
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        label: Text('직접 고른 캘린더'),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        account.isNotEmpty
                            ? '계정 ($account) · 이 계정의 동기화 설정에 따라 서버로 올라갈 수 있어요.'
                            : '이 계정의 동기화 설정에 따라 서버로 올라갈 수 있어요.',
                      ),
                    ],
                  ),
                ),
              );
            }
            final deviceCal = target;
            return Card(
              child: ListTile(
                isThreeLine: true,
                leading: const Icon(Icons.phone_android),
                title: Text(deviceCal['name'] as String? ?? '기기 기본 캘린더'),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(height: 6),
                    const Chip(
                      visualDensity: VisualDensity.compact,
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      avatar: Icon(Icons.lock_outline, size: 14),
                      label: Text('기기 고정'),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      (deviceCal['account'] as String? ?? '').isNotEmpty
                          ? '기기 계정 (${deviceCal['account']})'
                          : '외부 서버 전송 없이 기기 로컬 캘린더에 안전하게 저장돼요',
                    ),
                  ],
                ),
              ),
            );
          },
        ),
        Builder(
          builder: (context) {
            final deviceCalendar = findDeviceCalendar(calendars);
            return ExpansionTile(
              tilePadding: EdgeInsets.zero,
              title: const Text('고급: 저장할 캘린더 직접 고르기'),
              subtitle: const Text('원하면 연결된 다른 캘린더를 직접 선택할 수 있어요'),
              children: [
                if (calendars.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 8),
                    child: Text(
                      '표시할 캘린더가 없어요. 위에서 캘린더 권한 허용·목록 새로고침을 눌러 주세요.',
                    ),
                  )
                else
                  RadioGroup<Object>(
                    groupValue: selected,
                    onChanged: (v) {
                      if (v != null && !busy) selectCalendar(v);
                    },
                    child: Card(
                      child: Column(
                        children: [
                          for (final c in calendars)
                            if (c['id'] != null)
                              RadioListTile<Object>(
                                value: c['id'] as Object,
                                enabled: !busy,
                                title: Text(_calendarDisplayName(c)),
                                subtitle: Text(_calendarAccountText(c)),
                                secondary: isDeviceCalendar(c)
                                    ? const Chip(label: Text('기기 · 추천'))
                                    : null,
                              ),
                        ],
                      ),
                    ),
                  ),
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton(
                    onPressed: busy || deviceCalendar == null
                        ? null
                        : () => applyCalendarSelection(deviceCalendar),
                    child: const Text('기기 캘린더로 되돌리기'),
                  ),
                ),
              ],
            );
          },
        ),
        const SectionHeading('자동 전송'),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('과제·콘텐츠 마감 자동 전송'),
          subtitle: const Text(
            '새로 수집한 미완료 항목 중 공개·시작된 미래 마감만 추가해요. 연결된 항목은 이후 수집 시 마감·제목·완료 상태를 갱신해요.',
          ),
          value: auto && selected != null,
          onChanged: busy || selected == null
              ? null
              : (v) => setState(() => auto = v),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('확정한 공지 일정도 캘린더에 전송'),
          subtitle: const Text(
            '직접 확정하거나 자동 승인한 새 일정의 기본 위치예요. 기존 일정을 일괄 재전송하지 않아요.',
          ),
          value: aiAuto,
          onChanged: busy
              ? null
              : (v) async {
                  Store? store;
                  try {
                    store = await Store.open();
                    await store.setMeta(MetaKey.aiCalendarDefault, v ? 'yes' : 'no');
                    if (mounted) setState(() => aiAuto = v);
                  } catch (_) {
                    if (mounted) {
                      setState(() => message = '공지 일정 전송 설정을 저장하지 못했어요.');
                    }
                  } finally {
                    await store?.db.close();
                  }
                },
        ),
        TextButton(
          onPressed: () => navigateTo(context, AiSettingsDestination()),
          child: const Text('공지 일정 자동 승인 설정'),
        ),
        const Text(
          '숨기기·로그아웃·연결 해제를 해도 캘린더에 저장한 일정은 지워지지 않아요. 캘린더에서 직접 지운 일정은 다시 만들지 않아요.',
        ),
        if (message != null)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(message!),
          ),
        TextButton(
          onPressed: busy ? null : unlink,
          child: const Text('기존 연결 해제'),
        ),
      ],
    ),
  );
}

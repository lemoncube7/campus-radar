import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:crypto/crypto.dart';
import 'package:archive/archive.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'updates.dart';
import 'desktop.dart';

const windowsFeed =
    'https://raw.githubusercontent.com/lemoncube7/campus-radar/main/updates/windows.json';
Map<String, dynamic> validateDesktopManifest(Map<String, dynamic> m) {
  final u = Uri.tryParse(m['zipUrl']?.toString() ?? '');
  if (m['versionCode'] is! int ||
      (m['versionCode'] as int) < 1 ||
      m['versionName'] is! String ||
      m['platform'] != 'windows' ||
      m['architecture'] != 'x64' ||
      !RegExp(r'^[a-fA-F0-9]{64}$').hasMatch(m['sha256']?.toString() ?? '') ||
      u == null ||
      u.scheme != 'https' ||
      u.host != 'github.com' ||
      u.userInfo.isNotEmpty ||
      !u.path.startsWith('/lemoncube7/campus-radar/releases/download/') ||
      u.path !=
          '/lemoncube7/campus-radar/releases/download/windows-v${m['versionName']}/campus-radar-windows.zip') {
    throw const FormatException('Windows 업데이트 정보를 확인하지 못했습니다.');
  }
  return {...m, 'channel': 'stable'};
}

Future<Map<String, dynamic>?> cachedDesktopUpdate() async {
  try {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('desktopUpdate');
    if (raw == null) return null;
    final m = validateDesktopManifest(
      Map<String, dynamic>.from(jsonDecode(raw)),
    );
    return (m['versionCode'] as int) > appBuild ? m : null;
  } catch (_) {
    return null;
  }
}

Future<List<int>> desktopDownload(Uri uri, {required int limit}) async {
  final c = HttpClient()..connectionTimeout = const Duration(seconds: 15);
  try {
    final req = await c.getUrl(uri);
    req.headers.set('Cache-Control', 'no-cache');
    final res = await req.close().timeout(const Duration(seconds: 30));
    if (res.statusCode != 200) {
      throw const FormatException('다운로드 서버 응답을 확인해 주세요.');
    }
    if (res.contentLength > limit) {
      throw const FormatException('파일 크기 제한을 초과했습니다.');
    }
    final bytes = <int>[];
    await for (final chunk in res.timeout(const Duration(seconds: 30))) {
      bytes.addAll(chunk);
      if (bytes.length > limit) {
        throw const FormatException('파일 크기 제한을 초과했습니다.');
      }
    }
    return bytes;
  } finally {
    c.close(force: true);
  }
}

Future<Map<String, dynamic>?> checkDesktopUpdate({bool silent = false}) async {
  try {
    final data = await desktopDownload(
      Uri.parse(windowsFeed).replace(
        queryParameters: {'check': '${DateTime.now().millisecondsSinceEpoch}'},
      ),
      limit: 100000,
    );
    final m = validateDesktopManifest(
      Map<String, dynamic>.from(jsonDecode(utf8.decode(data))),
    );
    final p = await SharedPreferences.getInstance();
    await p.setString('desktopUpdate', jsonEncode(m));
    if (!silent) {
      await desktopLog(
        'Windows 업데이트 확인',
        '최신 ${m['versionName']} (${m['versionCode']})',
      );
    }
    return (m['versionCode'] as int) > appBuild ? m : null;
  } catch (_) {
    if (silent) return null;
    rethrow;
  }
}

void validateDesktopArchive(
  Archive archive,
  String destination, {
  required Map<String, dynamic> manifest,
}) {
  var total = 0;
  final root = path.normalize(path.absolute(destination));
  for (final file in archive) {
    final name = file.name.replaceAll('\\', '/');
    final target = path.normalize(path.join(root, name));
    if (file.isSymbolicLink ||
        name.startsWith('/') ||
        name.contains(':') ||
        !path.isWithin(root, target)) {
      throw const FormatException('업데이트 파일 경로가 올바르지 않습니다.');
    }
    total += file.size;
    if (total > 400 * 1024 * 1024) {
      throw const FormatException('업데이트 압축 해제 크기를 초과했습니다.');
    }
  }
  final exe = archive.findFile('campus_radar.exe'),
      info = archive.findFile('windows-version.json');
  if (exe == null || info == null || exe.size < 10000) {
    throw const FormatException('Windows 실행 파일이 없습니다.');
  }
  final m = jsonDecode(utf8.decode(info.content));
  if (m['versionCode'] != manifest['versionCode'] ||
      m['versionName'] != manifest['versionName']) {
    throw const FormatException('업데이트 버전이 일치하지 않습니다.');
  }
}

Future<void> installDesktopUpdate(Map<String, dynamic> raw) async {
  final manifest = validateDesktopManifest(raw);
  final bytes = await desktopDownload(
    Uri.parse(manifest['zipUrl'] as String),
    limit: 150 * 1024 * 1024,
  );
  if (sha256.convert(bytes).toString().toLowerCase() !=
      (manifest['sha256'] as String).toLowerCase()) {
    throw const FormatException('파일 무결성 확인에 실패했습니다.');
  }
  final staging = await (await getTemporaryDirectory()).createTemp(
    'campus-radar-update-',
  );
  final archive = ZipDecoder().decodeBytes(bytes, verify: true);
  validateDesktopArchive(archive, staging.path, manifest: manifest);
  for (final entry in archive) {
    final target = path.join(staging.path, entry.name.replaceAll('\\', '/'));
    if (entry.isFile) {
      final f = File(target);
      await f.parent.create(recursive: true);
      await f.writeAsBytes(entry.content, flush: true);
    } else {
      await Directory(target).create(recursive: true);
    }
  }
  final support = await getApplicationSupportDirectory();
  final script = File(path.join(support.path, 'apply-update.ps1'));
  await script.writeAsString(desktopUpdaterScript, flush: true);
  await desktopLog(
    'Windows 업데이트 설치 준비',
    '${manifest['versionName']} · SHA256 및 압축 경로 확인 완료',
  );
  await Process.start('powershell.exe', [
    '-NoProfile',
    '-NonInteractive',
    '-WindowStyle',
    'Hidden',
    '-ExecutionPolicy',
    'Bypass',
    '-File',
    script.path,
    '-Target',
    path.dirname(Platform.resolvedExecutable),
    '-Stage',
    staging.path,
    '-WaitPid',
    '$pid',
  ], mode: ProcessStartMode.detached);
  await desktopRuntime.quit();
}

// A local, fixed updater for the selected, hash-verified release. It never deletes user data.
const desktopUpdaterScript = r'''
param([Parameter(Mandatory=$true)][string]$Target,[Parameter(Mandatory=$true)][string]$Stage,[Parameter(Mandatory=$true)][int]$WaitPid)
$ErrorActionPreference='Stop'
$targetRoot=[IO.Path]::GetFullPath($Target).TrimEnd('\')
$stageRoot=[IO.Path]::GetFullPath($Stage).TrimEnd('\')
if($targetRoot -eq [IO.Path]::GetPathRoot($targetRoot).TrimEnd('\')){throw 'Invalid install folder'}
if(!(Test-Path -LiteralPath (Join-Path $targetRoot 'campus_radar.exe')) -or !(Test-Path -LiteralPath (Join-Path $stageRoot 'windows-version.json'))){throw 'Missing application'}
Wait-Process -Id $WaitPid -Timeout 60 -ErrorAction SilentlyContinue
if(Get-Process -Id $WaitPid -ErrorAction SilentlyContinue){throw 'Application is still running'}
$backup=Join-Path $stageRoot 'previous-files'
$files=@(Get-ChildItem -LiteralPath $stageRoot -Recurse -File)
$written=@()
try{
 foreach($file in $files){
  $source=[IO.Path]::GetFullPath($file.FullName)
  if(!$source.StartsWith($stageRoot+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Invalid source'}
  $relative=$source.Substring($stageRoot.Length+1)
  $dest=[IO.Path]::GetFullPath((Join-Path $targetRoot $relative))
  if(!$dest.StartsWith($targetRoot+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Invalid target'}
  $old=Join-Path $backup $relative
  if(Test-Path -LiteralPath $dest){New-Item -ItemType Directory -Force -Path ([IO.Path]::GetDirectoryName($old))|Out-Null;Copy-Item -LiteralPath $dest -Destination $old -Force}
  New-Item -ItemType Directory -Force -Path ([IO.Path]::GetDirectoryName($dest))|Out-Null
  $written+=@{Destination=$dest;Backup=$old}
  Copy-Item -LiteralPath $source -Destination $dest -Force
 }
 Start-Process -FilePath (Join-Path $targetRoot 'campus_radar.exe') -WorkingDirectory $targetRoot -WindowStyle Hidden
}catch{
 foreach($entry in $written){if(Test-Path -LiteralPath $entry.Backup){Copy-Item -LiteralPath $entry.Backup -Destination $entry.Destination -Force}}
 $_|Out-File -LiteralPath (Join-Path $stageRoot 'update-error.txt') -Encoding utf8
 Start-Process -FilePath (Join-Path $targetRoot 'campus_radar.exe') -WorkingDirectory $targetRoot -WindowStyle Hidden
}
''';

class DesktopUpdatePage extends StatefulWidget {
  const DesktopUpdatePage({super.key});
  @override
  State<DesktopUpdatePage> createState() => _DesktopUpdateState();
}

class _DesktopUpdateState extends State<DesktopUpdatePage> {
  bool busy = false;
  Map<String, dynamic>? update;
  String? message;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Windows 업데이트')),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Text(
          '현재 $appVersion ($appBuild)',
          style: Theme.of(context).textTheme.headlineSmall,
        ),
        const SizedBox(height: 12),
        const Text(
          'Windows 배포 파일을 확인합니다. 업데이트하면 앱을 잠시 종료하고 새 파일로 바꾼 뒤 다시 실행합니다. 계정·수집 자료는 별도 앱 데이터 폴더에 유지합니다.',
        ),
        const SizedBox(height: 16),
        FilledButton(
          onPressed: busy
              ? null
              : () async {
                  setState(() {
                    busy = true;
                    message = null;
                  });
                  try {
                    final m = await checkDesktopUpdate();
                    if (mounted) {
                      setState(() {
                        update = m;
                        message = m == null
                            ? '최신 버전입니다.'
                            : '${m['versionName']} 업데이트가 있습니다.';
                      });
                    }
                  } catch (_) {
                    if (mounted) {
                      setState(
                        () =>
                            message = '업데이트 정보를 불러오지 못했습니다. 네트워크 연결을 확인해 주세요.',
                      );
                    }
                  } finally {
                    if (mounted) setState(() => busy = false);
                  }
                },
          child: const Text('업데이트 확인'),
        ),
        if (message != null)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Text(message!),
          ),
        if (update != null)
          FilledButton.tonal(
            onPressed: busy
                ? null
                : () async {
                    setState(() => busy = true);
                    try {
                      await installDesktopUpdate(update!);
                    } catch (_) {
                      if (mounted) {
                        setState(() {
                          busy = false;
                          message =
                              '업데이트를 설치하지 못했습니다. 현재 버전을 유지합니다. 설치 폴더 쓰기 권한과 네트워크를 확인해 주세요.';
                        });
                      }
                    }
                  },
            child: const Text('다운로드·업데이트'),
          ),
      ],
    ),
  );
}

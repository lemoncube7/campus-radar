import 'dart:async';
import 'package:flutter/material.dart';
import 'app_storage.dart';
import 'ai_inbox_repository.dart';
import 'ai_protocol.dart';
import 'campus_models.dart';
import 'course_labels.dart';
import 'home_navigation.dart';
import 'navigation_contract.dart';

class HomeAgendaCard extends StatefulWidget {
  const HomeAgendaCard({super.key});
  @override
  State<HomeAgendaCard> createState() => _HomeAgendaState();
}

class _HomeAgendaState extends State<HomeAgendaCard> {
  List<Map<String, dynamic>> upcoming = [];
  int review = 0;
  int failed = 0;
  Timer? timer;
  @override
  void initState() {
    super.initState();
    load();
    timer = Timer.periodic(const Duration(seconds: 15), (_) => load());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> load() async {
    if (!mounted) return;
    Store? store;
    try {
      store = await Store.open();
      if (!mounted) return;
      final snapshot = await AiInboxRepository(store).read();
      final today = DateTime.now()
          .toUtc()
          .add(const Duration(hours: 9))
          .toIso8601String()
          .substring(0, 10);
      final rows =
          snapshot.candidates.where((r) {
            final st = r['state'] as Map;
            final c = r['candidate'] as ScheduleCandidate;
            return st['status'] == 'confirmed' &&
                ((st['date'] as String? ?? c.date).compareTo(today) >= 0);
          }).toList()..sort(
            (a, b) => '${a['state']['start'] ?? a['candidate'].date}'.compareTo(
              '${b['state']['start'] ?? b['candidate'].date}',
            ),
          );
      if (mounted) {
        setState(() {
          upcoming = rows.take(3).toList();
          failed = snapshot.jobs.where((j) => j['status'] == 'failed').length;
          review = snapshot.candidates
              .where(
                (r) => ((r['state'] as Map)['status'] ?? 'review') == 'review',
              )
              .length;
        });
      }
    } catch (_) {
    } finally {
      await store?.db.close();
    }
  }

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      if (failed > 0)
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.info_outline),
          title: Text('정리가 멈춘 공지 $failed개'),
          subtitle: const Text('원인과 해결 방법을 확인해 주세요.'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () async {
            await navigateTo(context, const AiInboxDestination(records: true));
            await load();
          },
        ),
      if (review > 0)
        Card(
          child: ListTile(
            leading: const Icon(Icons.fact_check_outlined),
            title: Text('확인할 일정 $review개'),
            subtitle: const Text('날짜·조건을 확인하고 일정에 추가하세요.'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => homeNavigation.value = const HomeRequest(
              view: ScheduleView.review,
            ),
          ),
        ),
      if (upcoming.isNotEmpty) ...[
        Row(
          children: [
            Expanded(
              child: Text(
                '다가오는 일정',
                style: Theme.of(context).textTheme.titleLarge,
              ),
            ),

            TextButton(
              onPressed: () => homeNavigation.value = const HomeRequest(
                view: ScheduleView.calendar,
              ),
              child: const Text('전체 보기'),
            ),
          ],
        ),
        for (final row in upcoming)
          Builder(
            builder: (context) {
              final n = row['notice'] as CampusNotice;
              final c = row['candidate'] as ScheduleCandidate;
              final st = row['state'] as Map;
              return Card(
                child: ListTile(
                  leading: const Icon(Icons.event_outlined),
                  title: Text(
                    courseEventTitle(
                      st['title'] as String? ?? c.title,
                      n.course,
                      oldLabel: st['courseLabel'] as String?,
                    ),
                  ),
                  subtitle: Text(
                    '${st['date'] ?? c.date} · ${st['approvalMode'] == 'automatic' ? '자동 추가됨' : '추가한 일정'}',
                  ),
                  onTap: () async {
                    await navigateTo(
                      context,
                      AiInboxDestination(
                        initialFilter: 'all',
                        candidateId: row['key'] as String,
                      ),
                    );
                    await load();
                  },
                ),
              );
            },
          ),
      ],
    ],
  );
}

import 'package:flutter/material.dart';
import 'campus_models.dart';

sealed class AppDestination {
  const AppDestination();
  String get path;
}

class TaskDestination extends AppDestination {
  final CampusItem item;
  final bool excluded;
  const TaskDestination({required this.item, this.excluded = false});
  @override
  String get path => '/radar/task';
}

class NoticeDestination extends AppDestination {
  final CampusNotice notice;
  const NoticeDestination({required this.notice});
  @override
  String get path => '/radar/notice';
}

class CourseDestination extends AppDestination {
  final Map<String, dynamic> course;
  const CourseDestination({required this.course});
  @override
  String get path => '/radar/course';
}

class TimetableDestination extends AppDestination {
  const TimetableDestination();
  @override
  String get path => '/radar/timetable';
}

class SummaryDestination extends AppDestination {
  final bool settings;
  const SummaryDestination({this.settings = false});
  @override
  String get path => '/radar/summary';
}

class AiInboxDestination extends AppDestination {
  final bool embedded, home, records;
  const AiInboxDestination({
    this.embedded = false,
    this.home = false,
    this.records = false,
  });
  @override
  String get path => '/radar/ai/inbox';
}

class AiSettingsDestination extends AppDestination {
  const AiSettingsDestination();
  @override
  String get path => '/radar/ai/settings';
}

Future<T?> navigateTo<T>(BuildContext context, AppDestination target) =>
    Navigator.of(context).pushNamed<T>(target.path, arguments: target);
